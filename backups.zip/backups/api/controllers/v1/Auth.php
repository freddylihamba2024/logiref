<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require  'Middleware.php';
/**
 * Description of Auth
 *
 * @author alvin Bauma
 */
class Auth extends Middleware {
    
        

    public function __construct() 
    {
            parent::__construct();
            $this->headers = apache_request_headers();
            $this->load->model('MY_Main');
            $this->load->model('MY_Logiref_Main');
            $this->load->model('MY_Logiref_Ebcdc');
            $this->load->model('main/main_model');
            $this->load->model('logiref/logiref_model');
            $this->load->model('api/users_model');
            $this->api_key = isset($this->headers['Api-Key']) ? $this->headers['Api_Key'] : "";
            $this->api_channel = isset($this->headers['Api_Channel']) ? $this->headers['Api_Channel'] : "";
            
            if (!isset($this->api_key) or $this->api_key != REST_Controller::API_KEY) $this->key_invalid = true;
            
            
    }
    

    public function login_post() 
    {

            //$this->verifyApiKey();  
			
	
			
            $message_error = null;
            $status = null;
            $code = null;
            
            $password = $this->input->post('password');
            //Encrypt password
            $key = "1234567890123456";
            $iv = "1234567890123456";
            $_POST['identifiant'] = $login = $this->input->post('login');
			
            $_POST['passcode'] = $encrypt = openssl_encrypt($password, 'aes-128-cbc', $key, 0, $iv);
            
			$log_data=json_encode($_POST);
			$this->save_log($log_data,"login_request");

            if (empty($login) || empty($password)) 
            {
                    $message_error = "Please fill in the login and password fields";
                    $code = 501;
            } 
            else 
            {
                    $status = $this->main_model->login();
                    
                    if ($this->main_model->loggedin() == TRUE) 
                    {   
							$this->users_model->get_privilegies();
                            
                            //Save login time
                            $log_data['Login_19']= gmdate('Y-m-d H:s');
                            $userid = $this->session->userdata('user_id');
                            $log_data['Lastsession_23'] = $this->session->session_id;
                            $this->main_model->save_profile($log_data, $userid);

                            //Get user informations
                            $user_data = $this->session->userdata();

                            //Data token ti generate
                            $token_data['user_id'] = $user_data['user_id'];
                            $token_data['account_id'] = $user_data['account_id'];
                            $token_data['branch_channel'] = $_SESSION['Logiref_guichet'];
							
                            
                            //generate Token
                            $tokenGenerated = $this->set_token($token_data);

                            //######## Login Okey Code 200###########
                            $data = [
                                    "code" => REST_Controller::HTTP_OK,
                                    "status"=>'success',
                                    "description" => "Token generated successfully",
                                    "message" => "Token generated successfully",
                                    "line" => 1,
                                    "data" => [
                                        "token" => $tokenGenerated
                                    ]
                            ];
							
                            $this->response($data, REST_Controller::HTTP_OK);
							

                    } 
                    else 
                    {
                            $message_error = "Incorrect username/password combination";
                            $code = 501;
                    }
            }
            
            //SI il y a une erreur
            if($message_error != null && $code != null)
            {
                    $data = [
                            "code" => $code,
                            "status" => "failed",
                            "description" => $message_error,
                            "message" => $message_error,
                            "data" => null
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
			
			
					$log_data=json_encode($data);
					$this->save_log($log_data,"login_response");
            
              
    }
    
    
}
