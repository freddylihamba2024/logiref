<?php
require  'Middleware.php';

/**
 * Description of Actualite
 *
 * @author alvinbm
 */
class Main extends Middleware {

    public function __construct() {
        parent::__construct();
        $this->load->model('MY_Logiref_Main');
        $this->load->model('logiref/logiref_model');
        
    }

    public function services_get($regie = null, $province=NULL) 
    {
            
            if($regie != null)
            {

                    if(!in_array($regie, ["dgi", "dgda", "dgrad", "dgrk"]))
                    {
                            $this->error_message("la regie que vous avez renseigné n'est pas valide");
                    }
                    else
                    {
                            $services =  $this->logiref_model->get_dropdown("services", strtoupper($regie), $province=NULL, true);
                            //######## Login Okey Code 200###########
                            $data = [
                                    "code" => REST_Controller::HTTP_OK,
                                    "description" => "success",
                                    "regie" => strtoupper($regie),
                                    "line" => count($services[strtoupper($regie)]),
                                    "data" => [
                                        "services" => $services[strtoupper($regie)],
                                    ]
                            ];
                            $this->response($data, REST_Controller::HTTP_OK);
                    }
            }
            else
            {
                    $this->error_message("Veuillez renseigner la regie svp !");
            }

        
        
    }
    

}
