<?php
require  'Middleware.php';
/**
 * Description of LogirefMakePayment
 * This endpoint is used to verify the existence of a note.
 * @author alvin Bauma
 */
class LogirefMakeReversement extends Middleware {

    public function __construct() {
        parent::__construct();
    }
    
    
    public function index_post() 
    {
            $request = json_decode(file_get_contents('php://input'));
            $action = null;
            $payments = null;
            $userid = null;
            
            if($request)
            {
                    $action = strtolower($request->action);
                    $payments = $request->payments;
                    $userid = $request->user;
                    
                    if($action != null)
                    {
                            if($note)
                            {
                                    $return = $this->check_request($regie, $note);
                                    
                                    if($return)
                                    {   
                                            if($regie == "dgi") $this->post_note_dgi($note->logiref_id,$note->means, $note->reference);
                                            if($regie == "dgda") $this->post_note_dgda($note->logiref_id,$note->means, $note->reference);
                                            if($regie == "dgrad") $this->post_note_dgrad($note->logiref_id,$note->means, $note->reference);
                                            if($regie == "dgrk") $this->post_note_dgrk($note->charge, $note->charge_currency, $note->logiref_id, $note->customer_account, $note->customer_account_currency);
                                    }
                            }
                            else
                            {
                                    $this->error_message("No information from the note was found");
                            }
                    }
                    else
                    {
                            $this->error_message("The tax authority that you have entered does not exist");
                    }
            }
            else 
            {
                    $this->error_message("No document related to this information was found, No parameter getted");
            }
            
    }
    
    
    
    private function post_note_dgrk($amount, $currency, $logiref_id, $customer_account, $customer_account_currency) 
    {
      
            //Calcul des frais bancaires
            

            //Générer les premières écritures comptable du bulletin


            //Intégration des premières écritures
            

            //Confimration du bulletin dans sydonia
            
            
            // Générer et enregistrer l'éclatement
           
    }
    
    private function post_note_dgi($logiref_id, $means, $reference) 
    {
            //Appel du paiement par son logirefid
            $paiement = $this->encaissement_model->get_paiement_by_logirefid($logiref_id);
            
            if($paiement->Checkerid_10 != 0 )
            {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $return->regie = 'DGI';
                    $return->proof = '';
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "status" => "success",
                            "message" => "Declaration already paid.",
                            "data" => $return
                    ];

                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    $result = $this->make_validation_dgi($paiement);
                    
                    if($result == 200)
                    {
                            ######## Payment was made successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logiref_id;
                            $return->regie = 'DGI';
                            
                            $data = [

                                    "code" => REST_Controller::HTTP_OK,
                                    "status" => "success",
                                    "message" => "Declaration was paid successfully.",
                                    "data" => $return
                            ];

                            $this->response($data, REST_Controller::HTTP_OK);
                    }
                    else
                    {
                            ######## Payment was made successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logiref_id;
                            $return->regie = 'DGI';
                            
                            $data = [

                                    "code" => REST_Controller::HTTP_OK,
                                    "status" => "error",
                                    "message" => "The declaration has not been validated, an error has occured.",
                                    "data" => $return
                            ];

                            $this->response($data, REST_Controller::HTTP_OK);
                    }
            }
    }
    
    
    private function post_note_dgrad($logiref_id, $means, $reference) 
    {   
            //Appel du paiement par son logirefid
            $paiement = $this->encaissement_model->get_paiement_by_logirefid($logiref_id);
            
            if($paiement->Checkerid_10 != 0 )
            {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $return->regie = 'DGRAD';
                    $return->proof = '';
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "status" => "success",
                            "message" => "Declaration already paid.",
                            "data" => $return
                    ];
                    
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    $result = $this->make_validation_dgrad($paiement);
                    
                    if($result == 200)
                    {
                            ######## Payment was made successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logiref_id;
                            $return->regie = 'DGRAD';
                            
                            $data = [

                                    "code" => REST_Controller::HTTP_OK,
                                    "status" => "success",
                                    "message" => "Declaration was paid successfully.",
                                    "data" => $return
                            ];

                            $this->response($data, REST_Controller::HTTP_OK);
                    }
                    else
                    {
                            ######## Payment was made successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logiref_id;
                            $return->regie = 'DGRAD';
                            
                            $data = [

                                    "code" => 300,
                                    "status" => "error",
                                    "message" => "The declaration has not been validated, an error has occured.",
                                    "data" => $return
                            ];

                            $this->response($data, REST_Controller::HTTP_OK);
                    }
            }
    }
    
    private function post_note_dgda($logiref_id, $mode, $reference) 
    {
            //Appel du bulletin par son logirefid
            $bulletin = $this->integration_model->get_declaration_by_logirefid($logiref_id);
            $data_bl = array();
            $data_bl['Status_2'] = '2';
            $data_bl['Lot_22'] = 'mobile';
            $this->integration_model->update_bulletin($data_bl, $bulletin->Id_0);
            
            $proof = array();
            
            if($bulletin == "" || $bulletin == NULL)
            {
                    $this->error_message("No declaration found for this logiref_id", "E303");
            }
            else 
            {
                    $_POST['Amount'] = $bulletin->Amount_12;
                    $_POST['designation'] = $bulletin->Designation_23;
                    $_POST['Year'] = $bulletin->Year_5;
                    $_POST['Series'] = $bulletin->Serie_7;
                    $_POST['Number'] = $bulletin->Number_8;
                    $_POST['Agent'] = $bulletin->Agent_10;
                    $_POST['Office'] = $bulletin->Office_6;
                    $_POST['Nif'] = $bulletin->Nif_9;
                    $_POST['Bank'] = $bulletin->Bank_11;
                    $_POST['devise'] = "CDF";
                    
                    // Calcul de la commission du lot
                    $agence = $bulletin->Agence_32;
                    $response = array();
                    $cdata['regie'] = "DGDA";
                    $cdata['service']= $_POST['Office'];
                    $cdata['recette']= NULL;
                    $cdata['devise'] = "CDF";
                    $cdata['guichet'] = $agence;
                    $cdata['montant'] = $_POST['Amount'];
                    $cdata['compte'] = "";
                    $cdata['compteDevise'] = "";

                    $response = $this->data('get_commission', $cdata);
                    
                    $comptes_ppm = $this->accounts_model->get_comptes_array_ppm();
                    $compte_cgu = isset($comptes_ppm['DGDA']['CPM']['CDF']) ? $comptes_ppm['DGDA']['CPM']['CDF'] : '00000000000000000000000';
                    
                    
                    $_POST['Compte_guichet'] = $compte_cgu;
                    $_POST['Commission'] = isset($response[0]) ? $response[0] : 0;
                    $_POST['Devise_commission'] = isset($response[1]) ? $response[1] : "CDF";
                    $_POST['Total_amount'] = isset($response[2]) ? $response[2] : "CDF";
                    $_POST['Mode'] = "7";
                    $_POST['lot'] = "mobile";
                    $_POST['reference'] = $reference;
                    $_POST['Paiementid'] = $bulletin->Id_0;
                    $_POST['Agence'] = $agence;
                    $_SESSION['Logiref_guichet'] = $agence;
                    $_POST['bank_account'] = "";
                    $_POST['Devise_account'] = "";
                    $_POST['account_name'] = "";
                    $_POST['Taux'] = $bulletin->Taux_31;
                    
                    $_POST['DateL'] = gmdate('Y-m-d');

                    $user = $this->session->userdata('user_id');
                    
                    $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                    
                    $response = $this->curl_model->call_bank_comptant_single($credentials);
                    $response = trim($response);

                    if($response=='E003') $this->error_message("No declaration found based on the information entered", $response);
                    elseif ($response=='E11') $this->error_message("The amount is incorrect",$response);
                    elseif ($response=='E13') $this->error_message("No declaration found based on the information entered",$response);
                    elseif ($response=='E34') $this->error_message("The declaration is already paid",$response);
                    elseif ($response=='E21') $this->error_message("Office Code not found",$response);
                    elseif ($response=='E22') $this->error_message("No declaration found based on the information entered",$response);
                    elseif ($response=='E404') $this->error_message("Sydonia is not available",$response);
                    elseif ($response=='E000') $this->error_message("You are not allowed to make the payment",$response);
                    else
                    {
                            $bulletin = $this->integration_model->get_paiement_sydonia($response);
                            
                            $return= $this->get_proof_of_payment($bulletin->Id_0);
                            
                            $description = "";
                            
                            if($return === "E003") $description = "Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!";
                            else if($return === "E34") $description = "Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!";
                            else if($return === "E22") $description = "Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!";
                            else if($return === "E11") $description = "Montant a payer incorrect. Veuillez renseigner des informations correctes!";
                            else if($return === "E002") $description ="Erreur fatal E002...!";
                            else if($return === "E001") $description ="Impossible d'imprimer la quittance veuillez contacter votre administrateur!";
                            else if($return === "E003") $description = "Erreur fatal E003...!";
                            else if($return === "E005")$description = "Serveur SYDONIA 41.215.253.187 pas disponible...!";
                            else if($return === "E000")$description = "Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!";
                            else if($return === "E404" || $return ==="E41") $description = "serveur SYDONIA 41.215.253.187 pas disponible...!";
                            else if($return === "") $description = "serveur SYDONIA 41.215.253.187 pas disponible...!";
                            else{
                                    
                                    $bulletin = $this->integration_model->get_paiement_sydonia($response);
                                    
                                    if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                                    {
                                            $quittance = "10.34.1.37/api/endpoints/sydonia/".$bulletin->Pdfcontent_18;
                                            
                                            $proof = array(
                                                        "proof_path" =>$quittance,
                                                        "description" =>"Quittance retrieved successfully"
                                                    );
                                    }
                                    else
                                    {
                                            $proof = array(
                                                        "proof_path" =>"",
                                                        "description" =>"Error : quittance not retrieved"
                                                    );
                                    }
                                    
                            }
                            
                            if(!isset($quittance))
                            {
                                   $proof = array(
                                                    "proof_path" =>"",
                                                    "description" =>"Error :".$description.""
                                            ); 
                            }

                            ######## Payment was made successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logiref_id;
                            $return->regie = 'DGDA';
                            $return->proof = $proof;
                            $data = [

                                    "code" => REST_Controller::HTTP_OK,
                                    "status" => "success",
                                    "message" => "Payment was made successfully",
                                    "data" => $return
                            ];

                            $this->response($data, REST_Controller::HTTP_OK);
                            
                            $this->save_breakdown_bulletin($logiref_id);
                    }
            }
            
    }
    
    public function make_validation_dgrad($paiement)
    {
            $_SESSION['Logiref_groupe']='banks';
            $data_to_update['Status_2'] = 5;
            
            $this->encaissement_model->update_payment_tresor($data_to_update, $paiement->Logirefid_4);
            
            $infos = json_decode($paiement->Notereference_30, true);
            
            $data['Beneficaire_15'] = 'DGRAD';
            $data['Logirefid_4'] = $paiement->Logirefid_4;
            $data['Account_3'] = $paiement->Account_3;
            $data['Id_0'] = $paiement->Id_0;
            
            $response = $this->curl_model->call_bank_virement($data);
            $return = json_decode($response, true);

            if(isset($return['response']) && $return['response'] =='200')
            {
                    $result = json_decode($paiement->Notereference_30, true);

                    foreach ($return as $row)
                    {
                            $result['Num_evenement'] = $row['Num_evenement'];
                            break;
                    }

                    $logirefid = $data['Logirefid_4'];

                    $data = array();
                    
                    $data['Notereference_30'] = json_encode($result);
                    $data['Id_0'] = $paiement->Id_0;
                    $data['Logirefid_4'] = $logirefid;
                    $data['Status_2'] = 1;
                    $data['Checkerid_10'] = $this->session->userdata("user_id");
                    $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                    
                    $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);
                    
                    return 200;
            }
            else
            {
                    return 300;
            }
    }
    
    public function make_validation_dgi($paiement)
    {
            $_SESSION['Logiref_groupe']='banks';
            $data_to_update['Status_2'] = 5;
            
            $this->encaissement_model->update_payment_tresor($data_to_update, $paiement->Logirefid_4);
            $infos = json_decode($paiement->Notereference_30, true);
            
            $data['Beneficaire_15'] = 'DGI';
            $data['Logirefid_4'] = $paiement->Logirefid_4;
            $data['Account_3'] = $paiement->Account_3;
            $data['Id_0'] = $paiement->Id_0;
            
            $response = $this->curl_model->call_bank_virement($data);
            $return = json_decode($response, true);

            if(isset($return['response']) && $return['response'] =='200')
            {
                    $result = json_decode($paiement->Notereference_30, true);
                    
                    foreach ($return as $row)
                    {
                            $result['Num_evenement'] = $row['Num_evenement'];
                            break;
                    }

                    $logirefid = $data['Logirefid_4'];

                    $data = array();
                    
                    $data['Notereference_30'] = json_encode($result);
                    $data['Id_0'] = $paiement->Id_0;
                    $data['Logirefid_4'] = $logirefid;
                    $data['Status_2'] = 1;
                    $data['Checkerid_10'] = $this->session->userdata("user_id");
                    $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                    
                    $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);
                    
                    return 200;
            }
            else
            {
                    return 300;
            }
    }
    
    public function save_breakdown_bulletin($logiref_id)
    {   
            # If form is validate successfullly
            
            $data = array();
            
            //Appel du bulletin par son logirefid
            $bulletin = $this->integration_model->get_declaration_by_logirefid($logiref_id);
            
            $_SESSION['Logiref_agence'] = 1;
			
            $_SESSION['Logiref_guichet'] = $bulletin->Agence_32;
            
            $data = $this->data_model->sydonia_migrate_bl($bulletin->Id_0);
            
            $object = json_encode($data);
            $data = json_decode($object, true);
            
            $data['Status_2'] = 1;
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Account_3'] = $this->session->userdata('account_id');

            $data['Taux_41'] = $bulletin->Taux_31;

            //Formatting amount
            $data['Montant_11'] = $bulletin->Amount_12;
            $data['Notemontant_28'] = $bulletin->Amount_12;
            
            $data['Guichet_21'] = $bulletin->Agence_32;
			
            $data['Commission_23'] = $bulletin->Commission_26;

            #Contre valeur en CDF
            $data['Devise_42'] = 'CDF';
            $data['Contrevaleur_22'] = $data['Montant_11'];
            $data['Beneficaire_15'] = 'DGDA';
            
            $data['Notereference_30'] = json_encode($data['Notereference_30']);

            # SAVE PAYMENT
            
            if(isset($data['total_amount']))unset($data['total_amount']);
            unset($data['frais_bcc']);
            if(isset($data['CGU']))unset($data['CGU']);
            if(isset($data['Total']))unset($data['Total']);
            

            $prefix = 1;
            $logirefid = $logiref_id;
            $end_execution = NULL;

            # Comptabilisation
            # Prmiere partie - 

            $agence_src= $bulletin->Agence_32;

            $case = $this->comptabilisation_model->get_use_case($data);
            $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

            #SAVE PAYMENT DE CHAQUE TAXE
            #Comptes CGU & CPT
            $compte_cpt = isset($comptes['Tmb']['CSO'][$data['Devise_12']]) ? $comptes['Tmb']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
            
            $comptes_ppm = $this->accounts_model->get_comptes_array_ppm();

            #SAVE PAYMENT DE CHAQUE TAXE
            #Comptes CGU & CPT
            $compte_cgu = isset($comptes_ppm['DGDA']['CPM']['CDF']) ? $comptes_ppm['DGDA']['CPM']['CDF'] : '00000000000000000000000';

            #Taxes comptes
            unset($comptes);
            $comptes = array();
            $agence_src= $bulletin->Agence_32;
            $instructions = array();

            $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

            $type_recettes = $this->logiref_model->get_dropdown("type_recette");

            $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

            $taxes = array();
            $frais_bcc = 0;
            
            # For getting taxesPaid as an object
            $return = $this->data_model->sydonia_migrate_bl($bulletin->Id_0);
            
            $taxesPaid = $return->Notereference_30['taxesPaid'];
            
            if(is_array($taxesPaid) && count($taxesPaid) > 0)
            {
                    $taxes = $taxesPaid;
            }
            elseif(is_object($taxesPaid) && $taxesPaid !="")
            {
                    $taxes[] = $taxesPaid;
            }

            #Serie et numero du bulletin
            $noteid = $data['Typerecette_17'];

            foreach($taxes as $taxe)
            {
                    $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                    $data['Contrevaleur_22'] = $taxe->taxeAmount;
                    $data['Montant_11'] = $taxe->taxeAmount;
                    $data['Typerecette_17'] = $taxe->taxeCode;
                    $pid = "";

                    if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                    {
                            $check_payement_tresor = $this->encaissement_model->check_bulletin_tresor($data['Sydonia_44'], $taxe->taxeCode, $noteid);

                            if(empty($check_payement_tresor))
                            {
                                    $data['Tresor_45'] = '1';
                                    $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                    $type_rectte = $type_recettes[$taxe->taxeCode];
                                    
                                    $frais = $taxe->taxeAmount * 0.0005;
                                    $frais_bcc += $frais;
                                    
                                    $pid = $this->encaissement_model->save_payment_tresor($data, NULL);
                                    $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                    $instructions[] = $instruction;
                            }
                    }
                    else if(isset($beneficiaires[$taxe->taxeCode]))
                    {
                            $check_payement_propres = $this->encaissement_model->check_bulletin_propres($data['Sydonia_44'], $taxe->taxeCode, $noteid);

                            if(empty($check_payement_propres))
                            {
                                    $data['Tresor_45'] = '0';
                                    $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                    $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                    $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                    $instructions[] = $instruction;
                            }
                    }
                    else
                    {
                            $check_payement_propres = $this->encaissement_model->check_bulletin_propres($data['Sydonia_44'], $taxe->taxeCode, $noteid);

                            if($check_payement_propres)
                            {
                                    $data['Missmatch_46'] = 1;
                                    $data['Tresor_45'] = '0';
                                    $data['Beneficaire_15'] = $taxe->taxeCode;

                                    $pid = $this->encaissement_model->save_payment_propres($data, NULL);

                                    $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                    $instructions[] = $instruction;
                            }
                    }
                    $data['Id_0'] = $pid;

                    $prefix++;
            }
            
            $this->save_fraisbcc_infos($frais_bcc, $bulletin, $logiref_id);

            if(!empty($instructions))
            {
                    # priority for integrating the counting in cbs
                    $priority = 1;

                    $end_execution = $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                    unset($instructions);
            }

            if($end_execution)
            {
                    $bl_data['Status_2'] = '2';
                    $bl_data['Lot_22'] = 'mobile';
                    
                    $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
            }
            
            //$this->validate_breakdown($data['Sydonia_44']);
            
            $this->data("paiement_sms", $bulletin);

            return $data['Sydonia_44'];
    }
    
    public function save_fraisbcc_infos($fraisbcc, $bulletin, $logiref_id)
    {
            $frais_forfaitaire = $bulletin->Amount_12 * 0.001; 
            
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Status_2'] =1;
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Type_4'] = $bulletin->Type_4;
            $data['Year_5'] = $bulletin->Year_5;
            $data['Office_6'] = $bulletin->Office_6;
            $data['Serie_7'] = $bulletin->Serie_7;
            $data['Number_8'] = $bulletin->Number_8;
            $data['Nif_9'] = $bulletin->Nif_9;
            $data['Agent_10'] = $bulletin->Agent_10;
            $data['Bank_11'] = $bulletin->Bank_11;
            $data['Amount_12'] = $bulletin->Amount_12;
            $data['Fraisbcc_13']= $fraisbcc;
            $data['Fraisbcc_14']= $frais_forfaitaire;
            $data['Amount_15']= $bulletin->Amount_25;
            $data['Logirefid_16']= $logiref_id;
            
            $this->integration_model->save_frais_bcc($data, NULL);
    }
    
    public function validate_breakdown($id)
    {
            $code = '';

            if(isset($id) && $id != "")
            {
                    #Is this a validation? Yes if it's a validator or the supervisor
                    $bulletin = $this->integration_model->get_paiement_sydonia($id);
                    $agence_src= $bulletin->Agence_32;
                    $data['Beneficaire_15'] = 'DGDA';
                    $data['Sydonia_44'] = $id;
                    
                    $comptes_ppm = $this->accounts_model->get_comptes_array_ppm();
                    $data['account_cgu'] = isset($comptes_ppm['DGDA']['CPM']['CDF']) ? $comptes_ppm['DGDA']['CPM']['CDF'] : '00000000000000000000000';
                    
                    # Priority of transactions to send to the API set to 1.
                    $data['Priority'] = 1;
                    if($bulletin->Lot_22 != "" && $bulletin->Lot_22 == "mobile")
                    {
                            $data['Type'] = 'lot';
                    }

                    #Invocation of the api transfer
                    @set_time_limit(300);

                    $response = $this->curl_model->call_bank_virement($data);
                    $return = json_decode($response, true);
                    if(isset($return['response']) && $return['response'] == "200")
                    {
                            $code = 200;

                            $data_to_validate['Status_2'] = 1;
                            $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');

                            # Update the paiement related to the bulletin
                            $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                            $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                            if($tid)
                            {
                                    $bl_data['Status_2'] = '3';
                                    $bl = $this->integration_model->update_bulletin($bl_data, $id);
                            }
                    }
                    elseif(isset($return['response']) && $return['response'] == "ST-UPLD113")
                    {
                            $code = $return['response'];
                    }
                    elseif(isset($return['response']) && $return['response'] == "DE-TUD-055")
                    {
                            $code = $return['response'];
                    }
                    elseif(isset($return['response']) && $return['response'] == "DE-TUD-099")
                    {
                            $code = $return['response'];
                    }
                    elseif(isset($return['response']) && $return['response'] == "AC-IBLCYWOT")
                    {
                            $code = $return['response'];
                    }
                    elseif(isset($return['response']) && $return['response'] !="")
                    {
                            $code = $return['response'];
                    }

                    if(isset($id) && $id > 0) 
                    {
                            $retour = array('code'=>$code, 'id'=>$id);
                            return json_encode($retour);
                    }
                    else
                    {
                            return 0;
                    }
            }
    }
    
    public function get_proof_of_payment($id)
    {
            $user = $this->session->userdata('user_id');
            $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
            $encrytions = json_decode($credentials->Password_18);
            #initialisation
            $apidata = array();
            $bl = $id;

            $bulletin = $this->integration_model->get_paiement_sydonia($bl);

            if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
            {
                    $quittance = $bulletin->Pdfcontent_18;
                    echo $quittance;
            }
            else
            {
                    $declaration = json_decode($bulletin->Results_13);
                    $apidata['ReceiptSerial'] = $declaration->receiptSerial;
                    $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                    $apidata['ReceiptDate'] = $declaration->receiptDate;
                    $apidata['Office'] = $bulletin->Office_6;
                    $apidata['Account'] = $this->session->userdata('account_id');
                    $apidata['Paiementid'] = $bl;
                    $apidata['User'] = $this->session->userdata('user_id');
                    $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                    $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                    $apidata['code_bank'] = (isset($encrytions->codebank))? $encrytions->codebank:'';				


                    $response = $this->curl_model->call_dgda_quittance($apidata);

                    if($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000")
                    {
                            return $response;
                    }
                    else
                    {
                            $bulletin = $this->integration_model->get_paiement_sydonia($bl);

                            if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                            {
                                    $quittance = $bulletin->Pdfcontent_18;
                                    return $quittance;
                            }
                            else
                            {
                                    return "E406";
                            }
                    }
            }
    }
    
    
    public function save_note_dgi($encaissement)
    {
            
    }
    
    public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
    {
            if($obj == "get_commission")
            {
                    $cdata = $data;
                    $montant1 = str_replace(' ','',$cdata['montant']);
                    $montant2 = str_replace(',','.',$montant1);
                    $cdata['montant'] = $montant2;
                    $oDeivise = $cdata['devise'];
                    #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                    $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte'], $cdata['compteDevise']);
                    
                    if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                    {
                            $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                            $com['devise'] = $cdata['devise'];
                    }
                    elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                    {
                            $com['com'] = $rules['Valeur'];
                            $com['devise'] = $rules['Unite'];
                    }

                    if(!empty($com) && $com['com']!=0)
                    {
                            $cdata['commission'] = $com['com'];
                            $cdata['devise'] = $com['devise'];
                    }
                    else
                    {
                            $cdata['commission'] = $cdata['montant']*0;
                            $cdata['devise'] = $cdata['devise'];
                    }

//                      //Montant total
                    
                    $taux['Dollar_4']  = 2000;
                    

                    if($cdata['devise'] == $oDeivise)
                    {
                            $tva = $cdata['commission'] * 0.16;
                            $cdata['total'] = $cdata['montant'] + $cdata['commission'] + $tva;
                    }
                    else if($cdata['devise'] == 'USD')
                    {
                            $tva = $cdata['commission'] * 0.16;
                            $cdata['total'] = $cdata['montant'] + ($cdata['commission']*$taux['Dollar_4']) + $tva;
                    }
                    else if(result[1] == 'CDF')
                    {
                            $tva = $cdata['commission'] * 0.16;
                            $cdata['total'] = $cdata['montant'] + ($cdata['commission']/$taux['Dollar_4']) + $tva;;
                    }
                    else 
                    {
                            $cdata['total'] = 0;
                    }

                    $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                    return $ar; exit;
            }
            elseif($obj == "number_letter")
            {
                    $value = $this->number_letter->converter($data, $arg);

                    return $value;
            }
            elseif($obj == "paiement_sms")
            {
                    if($data->Beneficaire_15 == 'DGI')
                    {
                            $nif = $data->Nif_13;
                            $designation = $data->Designation_14;
                            $declaration_number = $data->Noteid_26;
                            $amount = $data->Montant_11;
                            $date = $data->Datevaleur_31;
                            $service = $data->Service_16;
                            $period = $data->Datevaleur_31;

                            $services = $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);

                            $service = isset($services['DGI'][$service]) ? $services['DGI'][$service] : "";

                            $sms = "Paiement ".$data->Beneficaire_15." de ".$data->Devise_12." ".$amount." pour ".$service;
                            $sms .= " =>".$designation."; Doc =>".$declaration_number;
                            $sms .= "; le ".$date."; Periode =>".$period;
                            
                            $data_to_send = array();
                            
                            $data_to_send['phone'] = $data->Phone_50;
                            $data_to_send['message'] = $sms;
                            
                            $this->curl_model->call_bank_send_sms($data_to_send);

                            $data_to_save = array();

                            $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');
                            $data_to_save['Status_2'] = 1;
                            $data_to_save['Account_3'] = $_SESSION['account_id'];
                            $data_to_save['Creator_4'] = $_SESSION['user_id'];


                            $data_to_save['Logirefid_7'] = $data->Logirefid_4;
                            $data_to_save['Paiementid_9'] = $data->Id_0;
                            $data_to_save['Message_8'] = $sms;
                    }
                    elseif($data->Beneficaire_15 == 'DGRAD')
                    {
                            $designation = $data->Designation_14;
                            $declaration_number = $data->Noteid_26;
                            $amount = $data->Montant_11;
                            $date = $data->Datevaleur_31;
                            $service = $data->Service_16;

                            $services = $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);

                            $service = isset($services['DGRAD'][$service]) ? $services['DGRAD'][$service] : "";

                            $sms = "Paiement ".$data->Beneficaire_15." de ".$data->Devise_12." ".$amount." pour ".$service;
                            $sms .= " =>".$designation."; Doc =>".$declaration_number;
                            $sms .= "; le ".$date.";";
                            
                            $data_to_send = array();
                            
                            $data_to_send['phone'] = $data->Phone_37;
                            $data_to_send['message'] = $sms;
                            
                            $this->curl_model->call_bank_send_sms($data_to_send);

                            $data_to_save = array();

                            $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');
                            $data_to_save['Status_2'] = 1;
                            $data_to_save['Account_3'] = $_SESSION['account_id'];
                            $data_to_save['Creator_4'] = $_SESSION['user_id'];


                            $data_to_save['Logirefid_7'] = $data->Logirefid_4;
                            $data_to_save['Paiementid_9'] = $data->Id_0;
                            $data_to_save['Message_8'] = $sms;
                    }
                    else
                    {
                            $designation = $data->Designation_23;
                            $declaration_number = $data->Serie_7."".$data->Number_8;
                            $amount = $data->Amount_12;
                            $date = $gmdate('d-m-Y');
                            $service = $data->Office_6;

                            $services = $this->logiref_model->get_dropdown("services", "DGDA", $province=NULL, true);

                            $service = isset($services['DGDA'][$service]) ? $services['DGDA'][$service] : "";

                            $sms = "Paiement DGDA de CDF ".$amount." pour ".$service;
                            $sms .= " =>".$designation."; BL =>".$declaration_number;
                            $sms .= "; le ".$date.";";
                            
                            $data_to_send = array();
                            
                            $data_to_send['phone'] = $data->Phone_50;
                            $data_to_send['message'] = $sms;
                            
                            $this->curl_model->call_bank_send_sms($data_to_send);

                            $data_to_save = array();

                            $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');
                            $data_to_save['Status_2'] = 1;
                            $data_to_save['Account_3'] = $_SESSION['account_id'];
                            $data_to_save['Creator_4'] = $_SESSION['user_id'];


                            $data_to_save['Logirefid_7'] = $data->Logirefid_34;
                            $data_to_save['Paiementid_9'] = $data->Id_0;
                            $data_to_save['Message_8'] = $sms;
                    }

                    $this->integration_model->save_paiement_sms($data_to_save);
            }
    }
    
    public function check_request($regie, $note)
    {
            if($regie == "dgi")
            {
                    if(isset($note->logiref_id) && isset($note->means) && isset($note->reference))
                    {
                            //$log_request = var_export($note, true);
                            //$this->save_log($log_request,"make_payment_dgi");
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }

            }
            elseif($regie == "dgda")
            {
                    if(isset($note->logiref_id) && isset($note->means) && isset($note->reference))
                    {
                            //$log_request = var_export($note, true);
                            //$this->save_log($log_request,"make_payment_dgda");
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrad")
            {
                    
                    if(isset($note->logiref_id) && isset($note->means) && isset($note->reference))
                    {
                            //$log_request = var_export($note, true);
                            //$this->save_log($log_request,"make_payment_dgrad");
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrk")
            {
                    if(isset($note->declaration_id) && isset($note->branch_code))
                    {
                            //$log_request = var_export($note, true);
                            //$this->save_log($log_request,"make_payment_dgrk");
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
    }
   
}
