<?php
require  'Middleware.php';
/**
 * Description of LogirefList
 * This endpoint allows you to retrieve the list of services, taxes.
 * @author alvin Bauma
 */
class LogirefList extends Middleware {

    public function __construct() {
        parent::__construct();
    }
    
    
    public function index_get() 
    {
            $regie = $this->input->get("regie");
            $type = $this->input->get("type");
            $nb = $this->input->get("nb");
            $page = $this->input->get("page");

            if (!empty($regie) && !empty($type))
            {
                    if($type == "service") $this->get_services($regie);
                    elseif ($type == "taxe" || $type == "taxe") $this->get_taxes($regie);
                    else $this->error_message("Impossible de récuperer les informations. le type de liste demandé n'est pas valide");
            }
            else
            {
                    $this->error_message("Impossible de récuperer les informations. Un ou plusieurs paramètres ne sont pas renseigné");
            }
        
    }






    private function get_services($regie = null, $province=NULL) 
    {
            
            if($regie != null)
            {

                    if(!in_array(strtolower($regie), $this->regies))
                    {
                            $this->error_message("la regie que vous avez renseigné n'est pas valide");
                    }
                    else
                    {
                            $services =  $this->logiref_model->get_dropdown("services", strtoupper($regie), $province=NULL, true);
                            
                            $data_services = null;
                            foreach ($services[strtoupper($regie)] as $sKey=>$sValue)
                            {
                                    if($sKey == null || $sValue == "") continue;
                                    $service = new stdClass();
                                    $service->code = $sKey;
                                    $service->designation = $sValue;
                                    $data_services []= $service;
                            }
                            
                            //######## Services retrieved Code 2000###########
                            $data = [
                                    "code" => REST_Controller::HTTP_OK,
                                    "description" => "success",
                                    "regie" => strtoupper($regie),
                                    "line" => count($data_services),
                                    "data" => [
                                        "services" => $data_services,
                                    ]
                            ];
                            $this->response($data, REST_Controller::HTTP_OK);
                    }
            }
            else
            {
                    $this->error_message("Veuillez renseigner la regie svp !");
            }

        
        
    }
    
    
    private function get_taxes($regie = null, $province=NULL) 
    {
            
            if($regie != null)
            {

                    if(!in_array(strtolower($regie), $this->regies))
                    {
                            $this->error_message("la regie que vous avez renseigné n'est pas valide");
                    }
                    else
                    {
                            $taxes =  $this->logiref_model->get_dropdown("recettes", strtoupper($regie));
                            $data_taxes = null;
                            foreach ($taxes[strtoupper($regie)] as $tKey=>$tValue)
                            {
                                    if($tKey == null || $tKey == "") continue;
                                    $taxe = new stdClass();
                                    $taxe->code = $tKey;
                                    $taxe->designation = $tValue;
                                    $data_taxes []= $taxe;
                            }
                            //######## Taxes retrieved Code 200###########
                            $data = [
                                    "code" => REST_Controller::HTTP_OK,
                                    "description" => "success",
                                    "regie" => strtoupper($regie),
                                    "line" => count($data_taxes),
                                    "data" => [
                                        "taxes" => $data_taxes,
                                    ]
                            ];
                            $this->response($data, REST_Controller::HTTP_OK);
                    }
            }
            else
            {
                    $this->error_message("Veuillez renseigner la regie svp !");
            }

        
        
    }
}
