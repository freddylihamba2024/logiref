<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require 'Middleware.php';
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of LogirefCheckPassport
 *
 * @author macbookpro
 */
class LogirefCheckPassport extends Middleware
{
    
        public function __contruct()
        {
                parent::__construct();
        } 
        
        public function index_post()
        {
                $request = json_decode(file_get_contents('php://input'));

                if($request)
                {
                        $return = $this->check_request($request);
                     
                        if($return)
                        {
                                $this->get_note_passport($request->reference_number);
                        }
                        else
                        {
                                $this->error_message("Failed to read the request, please check your request !");
                        }
                        
                }
                else 
                {
                        $this->error_message("No document related to this information was found, No parameter getted");
                }
        }
        
        public function get_note_passport($reference)
        {
                
                $note_exist = $this->integration_model->get_note_by_ref($reference);
                
                if(isset($note_exist->Id_0))
                {   
                        $response = $note_exist->Id_0;
						
                        $encaissement = $this->data_model->logirad_migrate_note($response);
                }
                else
                {   
                        $note_data = array();
                        $note_data['Reference_8'] = $reference;
                        $note_data['Account'] = $this->session->userdata('account_id');
                        $note_data['User'] = $this->session->userdata('user_id');

                        # Invocation of the API LOGIRAD
//                      $response = $this->curl_model->call_dgrad_notes($note_data);
                        $response = $this->curl_model->call_dgrad_notes_passport($note_data);   
                        
                }
                if($response == "E302")
                {
                        # Declaration not found
                        /* $this->error_message("Declaration not found", 302); */
						
						$data = [
								"code" => '302',
								"status"=>'invalid',
								"description" => "Declaration not found.",
								"message" => "Declaration not found.",
								"data" => null
						];
						
						$this->response($data, REST_Controller::HTTP_OK);

                }
                elseif($response == "E308")
                {
                        # Declaration not found
                        $this->error_message("An error occurred while executing the query from the DGRAD server", 308);
                }
                elseif($response=="E002")
                {
                        # The declaration has not been saved in the database
                        $this->error_message("The declaration has not been saved in the database, please retry", 500);
                }
                elseif($response == "E000" || $response == "" || $response == false)
                {
                        # The DGRAD server is not available
                        $this->error_message("DGRAD server not available", 404);
                }
				elseif($response == "E404")
				{
						$data = [
								"code" => '404',
								"status"=>'invalid',
								"description" => "Declaration not found.",
								"message" => "Declaration not found.",
								"data" => null
						];
						
						$this->response($data, REST_Controller::HTTP_OK);
				}
                else
                {
                    
                        $encaissement = $this->data_model->logirad_migrate_note($response);
						
                        
                        $code_service = isset($encaissement->Service_16) ? $encaissement->Service_16 : "";

                        # Retrieve the branch based on the service code
                        $guichet = $this->branches_model->get_branche_by_service();
                        
                        $guichet = current($guichet);

                        $branch_name = isset($guichet->Nom_4) ? $guichet->Nom_4 : "";
                        $_SESSION['Logiref_guichet'] = isset($guichet->Id_0) ? $guichet->Id_0 : "";
                        $_SESSION['Logiref_agence'] = isset($guichet->Agence_5) ? $guichet->Agence_5 : "";

                        if(isset($guichet->Id_0) ? $guichet->Id_0 : "")
                        {
                                # Retrieve the exchange rate
                                $this->rates_model->get_easybusy_exchange_rates();

                                $_POST['Montant'] = $amount = $encaissement->Montant_11;
                                $_POST['Devise'] = $currency = $encaissement->Devise_12;
                                
                                $_POST['Noteid'] = $reference = $encaissement->Noteid_26;
                                $_POST['Designation'] = $designation = $encaissement->Designation_14;
                                $_POST['Service'] = $service = $encaissement->Service_16;
                                $_POST['Recette'] = $recette = $encaissement->Typerecette_17;
                                $_POST['Notereference'] = $encaissement->Notereference_30;
                                $_POST['Notedate'] = $encaissement->Notedate_27;
                                $_POST['Email'] = $encaissement->Email_54;
                                $_POST['Telephone'] = $encaissement->Msisdn_55;

                                #Retrieve the Eazzybiz account configured based on branch channel configured
                                $token_data = $this->authorization_token->validateToken();
                               
                                $branch_channel = isset($token_data['data']->branch_channel) ? $token_data['data']->branch_channel : "";
                                $_POST['branch_channel']=$branch_channel;
								
                                $agence_dst=NULL;
                                $agence_src = $branch_channel;
								
								
                                //$list = "'CSP'";
								$list = NULL;
								
                                $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
                                $compte_eazzybiz = isset($comptes['Ebcdc']['CSP'][$currency]) ? $comptes['Ebcdc']['CSP'][$currency] : "";
                                
                                if($compte_eazzybiz !="")
                                {
                                        # Compte GL to return to the to request
                                        $compte_gl = str_replace('-', "", $compte_eazzybiz);

                                        $paiement = $this->encaissement_model->check_paiement();
                                        $paiement = current($paiement);

                                        
                                        if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !="")
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                $taux = $taux['Dollar_4'];

                                                if(isset($paiement->Checkerid_10) &&  $paiement->Checkerid_10 != 0)
                                                {
                                                        $note_exist = $this->integration_model->get_note_by_ref($reference);

                                                        $taux = $paiement->Taux_41;
														
                                                        $frais_bbc = 0;

                                                        if($paiement->Devise_34 == 'USD')
                                                        {
                                                                if($paiement->Devise_24 == 'CDF') 
                                                                {
                                                                        $tva = $paiement->Commission_23 * 0.16;
                                                                        $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc;
                                                                        $total = $total/$taux;
                                                                        $paiement->Commission_23 = $paiement->Commission_23/$taux;
                                                                }
                                                                else
                                                                {
                                                                        $tva = $paiement->Commission_23 * 0.16;
                                                                        $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + 0.83;
                                                                }

                                                                $commission_array = array();
                                                                $commission_array['amount'] = $paiement->Commission_23;
                                                                $commission_array['currency'] = $paiement->Devise_24;

                                                                $note_details = json_decode($note_exist->Result_8);
																
																
                                                                
                                                               
                                                                $not_details = new stdClass();
                                                                $not_details->tax_number = $note_details->logiradData->numeroNotePerception;
                                                                $not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
                                                                $not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
                                                                $not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
                                                                $not_details->designation = $note_details->logiradData->detailAssujetti->designation;

                                                                $return = new stdClass();
                                                                $return->logiref_id = $paiement->Logirefid_4;
                                                                $return->note_amount = $paiement->Montant_11;
                                                                $return->currency = $currency;
                                                                $return->commission = 5.17;
                                                                $return->vat =0.83;
                                                                //$return->bcc_fees = $frais_bbc;
                                                                $return->tota_amount = $total;
                                                                $return->exchange_rate = $taux;
                                                                $return->compte_gl = $compte_gl;
                                                                $return->dec_details = $not_details;

                                                                $data = [
                                                                        "code" => '202',
                                                                        "status"=>'paid',
                                                                        "description" => "Declaration is already paid.",
                                                                        "message" => "Declaration is paid.",
                                                                        "data" => $return
                                                                ];
                                                                $this->response($data, REST_Controller::HTTP_OK);
                                                        }
                                                        else
                                                        {
                                                                if($paiement->Devise_24 == 'USD') 
                                                                {
                                                                        $paiement->Commission_23 = $paiement->Commission_23 * $taux;
                                                                        $tva = $paiement->Commission_23 * 0.16;
                                                                }
                                                                else
                                                                {
                                                                        $tva = $paiement->Commission_23 * 0.16;
                                                                }

                                                                $note_details = json_decode($note_exist->Result_8);

                                                                $not_details = new stdClass();
                                                                $not_details->tax_number = $note_details->logiradData->numeroNotePerception;
                                                                $not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
                                                                $not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
                                                                $not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
                                                                $not_details->designation = $note_details->logiradData->detailAssujetti->designation;
																
																$total=$paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + 0.83;

                                                                $return = new stdClass();
                                                                $return->logiref_id = $paiement->Logirefid_4;
                                                                $return->note_amount = $paiement->Montant_11;
                                                                $return->currency = $currency;
                                                                $return->commission = 5.17;
                                                                $return->vat = 0.83;
                                                                //$return->bcc_fees = $frais_bbc;
                                                                $return->total_amount = $total;
                                                                $return->exchange_rate = $taux;
                                                                $return->compte_gl = $compte_gl;
                                                                $return->dec_details = $not_details;


                                                                $data = [
                                                                        "code" => '202',
                                                                        "status"=>'paid',
                                                                        "description" => "Declaration is already paid.",
                                                                        "message" => "Declaration is already paid.",
                                                                        "data" => $return
                                                                ];
                                                                $this->response($data, REST_Controller::HTTP_OK);
                                                        }
                                                }
                                                else 
                                                {
														
                                                        // Calcul de la commission
                                                        $agence = $_SESSION['Logiref_guichet'];
                                                        $response = array();
                                                        $cdata['regie'] = "DGRAD";
                                                        $cdata['service']= $service;
                                                        $cdata['recette']= $recette;
                                                        $cdata['devise'] = $currency;
                                                        $cdata['guichet'] = $agence;
                                                        $cdata['montant'] = $amount;

                                                        $response = $this->data('get_commission', $cdata, $taux);
                                                        
                                                        /* if($currency == 'CDF')
                                                        {
                                                                $frais_bbc = $amount * 0.005;
                                                        }
                                                        else
                                                        { */
                                                         $frais_bbc = 0;
                                                        /* } */
                                                        
                                                       
                                                        if($currency == "USD" || $currency == "CDF")
                                                        {
                                                                if($currency == "CDF")
                                                                {
                                                                        if(isset($response[1]) && $response[1] =="USD")
                                                                        {
                                                                                $response[0] =  $response[0] * $taux;

                                                                                $commission = array(
                                                                                                "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                                "currency"=> 'CDF',

                                                                                            );
                                                                        }
                                                                        else 
                                                                        {
                                                                                $commission = array(
                                                                                                "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                                "currency"=> isset($response[1]) ? $response[1] : 'CDF',

                                                                                            );
                                                                        }
																		
                                                                        $response[2] = $frais_bbc + $response[2];
                                                                        $response[2] = $response[2];

                                                                        $taux = 1;
                                                                }
                                                                elseif($currency=="USD")
                                                                {
                                                                        if(isset($response[1]) && $response[1] =="USD")
                                                                        {
                                                                                $response[0] = number_format($response[0],2,".","");
                                                                                $commission = array(
                                                                                                "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                                "currency"=> $response[1],

                                                                                            );
                                                                        }
                                                                        elseif(isset($response[1]) && $response[1] =="CDF")
                                                                        {
                                                                                //$response[0] =  $response[0]/$taux;

                                                                                $response[0] = number_format($response[0],2,".","");

                                                                                $commission = array(
                                                                                                "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                                "currency"=> 'USD'

                                                                                            );
                                                                        }
																		
                                                                        $response[2] = number_format($response[2],0);
                                                                }
																
                                                                $paiement = $this->encaissement_model->check_paiement();
                
                                                                $paiement = current($paiement);

                                                                $note_exist = $this->integration_model->get_note_by_ref($reference);
																
																
                                                                
                                                                if(isset($paiement->Id_0) && $paiement->Id_0 !="")
                                                                {
                                                                        $note_details = json_decode($note_exist->Result_8);
                                                                        
                                                                        $total=$paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + 0.83;
																		
                                                                        if(isset($response[0]) && $response[0] > 0)
                                                                        {
                                                                                $tva = $response[0] * 0.16;
                                                                        }
                                                                        else 
                                                                        {
                                                                                $tva = 0;
                                                                        }
                                                                        
                                              
                                                                        $not_details = new stdClass();
                                                                        $not_details->tax_number = $note_details->logiradData->numeroNotePerception;
                                                                        $not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
                                                                        $not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
                                                                        $not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
                                                                        $not_details->designation = $note_details->logiradData->detailAssujetti->designation;

                                                                        $return = new stdClass();
                                                                        $return->logiref_id = $paiement->Logirefid_4;
                                                                        $return->note_amount = $paiement->Montant_11;
                                                                        $return->currency = $currency;
                                                                        $return->commission = 5.17;
                                                                        $return->vat =0.83;
                                                                        //$return->bcc_fees = $frais_bbc;
                                                                        //$return->total_amount = isset($response[2]) ? $response[2] : 0;
																		$return->total_amount = $total;
                                                                        $return->exchange_rate = $taux;
                                                                        $return->compte_gl = $compte_gl;
                                                                        $return->dec_details = $not_details;

                                                                        $data = [
                                                                                "code" => REST_Controller::HTTP_OK,
                                                                                "status"=>'valid',
                                                                                "description" => "The request has been executed successfully.",
                                                                                "message" => "The request has been executed successfully.",
                                                                                "data" => $return
                                                                        ];
                                                                        $this->response($data, REST_Controller::HTTP_OK);
                                                                        
                                                                        

                                                                }
                                                                else
                                                                {
                                                                        $total=$commission['amount'] + $response[2] + 0.83;
																	
                                                                        //Initialisation du paiement dans la table tresor
                                                                        $_POST['Total_amount'] =$total;
                                                                        $_POST['Commission'] = $commission['amount'];
                                                                        $_POST['Devise_commission'] = $commission['currency'];
                                                                        $_POST['total_amount'] =$total;

                                                                        $note_details = json_decode($note_exist->Result_8);


                                                                        $note['Logirefid_4'] = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');

                                                                        $return = $this->init_note_passport($note['Logirefid_4'], $compte_eazzybiz);
                                                                   
                                                                        if($return == 'E200')
                                                                        {
                                                                                ######## Declaration retrieved code 200 ###########
                                                                                $note_details = json_decode($note_exist->Result_8);

                                                                                if(isset($response[0]) && $response[0] > 0)
                                                                                {
                                                                                        $tva = $response[0] * 0.16;
                                                                                }
                                                                                else 
                                                                                {
                                                                                        $tva = 0;
                                                                                }

                                                                                $not_details = new stdClass();
                                                                                $not_details->tax_number = $note_details->logiradData->numeroNotePerception;
                                                                                $not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
                                                                                $not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
                                                                                $not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
                                                                                $not_details->designation = $note_details->logiradData->detailAssujetti->designation;

                                                                                $return = new stdClass();
                                                                                $return->logiref_id = $note['Logirefid_4'];
                                                                                $return->note_amount = $_POST['Montant'];
                                                                                $return->currency = $currency;
                                                                                $return->commission = 5.17;
                                                                                $return->vat = 0.83;
                                                                                //$return->bcc_fees = $frais_bbc;
                                                                                //$return->total_amount = isset($response[2]) ? $response[2] : 0;
																				$return->total_amount = $total;
                                                                                $return->exchange_rate = $taux;
                                                                                $return->compte_gl = $compte_gl;
                                                                                $return->dec_details = $not_details;


                                                                                $data = [
                                                                                        "code" => REST_Controller::HTTP_OK,
                                                                                        "status"=>'valid',
                                                                                        "description" => "The request has been executed successfully.",
                                                                                        "message" => "The request has been executed successfully.",
                                                                                        "data" => $return
                                                                                ];
                                                                                $this->response($data, REST_Controller::HTTP_OK);

                                                                        }
                                                                        elseif($return == 'E401')
                                                                        {
                                                                                $this->error_message("The payment verification failed, please try again.");
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->error_message("Failed to read the request, please check your request !");
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                $data = [
                                                        "code" => 304,
                                                        "status"=>'error',
                                                        "description" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                                        "message" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                                        "data" => $return
                                                ];
                                                $this->response($data, 304);
                                        }
                                }
                                else
                                {
                                        $this->error_message("The Eazzybiz account is not configured in logiref, please kindly contact the administrator for this purpose.", 306);
                                }
                        }
                        else
                        {
                                $this->error_message("No branch found for the code service ".$code_service.", please kindly contact the administartor for further information.", 307);
                        }
                }
        }
        
        public function init_note_passport($logirefid, $compte_eazzybiz)
        {
                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                $data['Status_2'] = 0;
                $data['Account_3'] = $this->session->userdata('account_id');
                $data['Logirefid_4'] = $logirefid;
                $data['Makerid_9'] = $this->session->userdata('user_id');
                $data['Montant_11'] = $_POST['Montant'];
                $data['Devise_12'] = $_POST['Devise'];
                $data['Designation_14'] = $_POST['Designation'];
                $data['Beneficaire_15'] = 'DGRAD';
                $data['Service_16'] = $_POST['Service'];
                $data['Typerecette_17'] = $_POST['Recette'];
                $data['Mode_19'] = 7;
                $data['Agence_20'] = $_SESSION['Logiref_agence'];
                $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                $data['Contrevaleur_22'] = $_POST['Montant'];
                $data['Notetype_25'] = 1;
                $data['Noteid_26'] = $_POST['Noteid'];
                $data['Notedate_27'] = $_POST['Notedate'];
                $data['Notemontant_28'] = $_POST['Montant'];
                $data['Notedevise_29'] =  $_POST['Devise'];
                $data['Datevaleur_31'] = gmdate('Y-m-d');
				$data['Commission_23'] = 5.17;
                //$data['Commission_23'] = $_POST['Commission'];
                $data['Devise_24'] = $_POST['Devise_commission'];
                $data['Devise_34'] = $_POST['Devise'];
                
                $data['Sydonia_44'] = '0';
                $data['Tresor_45'] = 1;
                $data['Type_57'] = 'mobile';
                $data['Email_54']=$_POST['Email'];
                $data['Msisdn_55']=$_POST['Telephone'];

                #Comptes suspens Eazzybiz
                $data['Compte_33'] = $compte_eazzybiz;
				
				$taux = json_decode($_SESSION['Bank_rates'], true);
				$taux = $taux['Dollar_4'];
				
				$data['Taux_41'] = $taux;
                
                $note_reference = $_POST['Notereference'];
				
				$note_reference = json_decode($note_reference, true);

                $infos = array();

                $infos['NumeroTitre'] = "";
                $infos['Motif'] = "";
                $infos['standard'] = $_POST['Recette'];
                $infos['totalMontant'] = $_POST['total_amount'];
                $infos['totalDevise'] = "USD";
				$infos['QuotasTresor'] = isset($note_reference ["QuotasTresor"]) ? $note_reference ["QuotasTresor"] : '';
				$infos['QuotasComite'] =  isset($note_reference['QuotasComite'])?$note_reference['QuotasComite']:'';
				$infos['QuotasPrestataire'] = isset($note_reference['QuotasPrestataire'])?$note_reference['QuotasPrestataire']:'';
				$infos['QuotasService'] = isset($note_reference['QuotasService'])?$note_reference['QuotasService']:'';
											

                $data["Notereference_30"] = json_encode($infos);

                $periode = $data['Notedate_27'];
               
                $agence_dst=NULL;
                $agence_src =  $_POST['branch_channel'];
				
                $list = NULL;
                $comptes_recettes = NULL;

                $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
                
                $date_emission = isset($data['Notedate_27']) ? $data['Notedate_27'] : "";

                $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRAD", NULL, NULL, $date_emission);
				
                $nid = $this->encaissement_model->save_payment_tresor($data, NULL);
                
                if(!empty($instructions))
                {
                        $end_execution = $this->comptabilisation_model->save_instructions_dgrad($nid, $data, $instructions, $data['Logirefid_4'],0);
						
						if($end_execution)
						{
								$instructions2 = $this->comptabilisation_model->get_instructions_dgrad_passport($data, $comptes,'DGRAD', $date_emission);
								
								$this->comptabilisation_model->save_instructions_dgrad($nid, $data, $instructions2, $data['Logirefid_4'],1);
						}
						
                }

                if($nid > 0)
                {
                        return 'E200';
                }
                else
                {
                        return 'E401';
                }
        }
        
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_commission")
                {
                        $cdata = $data;
                        $taux = $arg;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];

                        $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte'], $cdata['compteDevise']);
   
                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        //Montant total
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;


                        if($cdata['devise'] == $oDeivise && $oDeivise=='CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                        }
                        else if($cdata['devise'] == $oDeivise && $oDeivise =='USD')
                        {
								if($cdata['recette'] == "27421600")
                                {
                                        $cdata['commission'] = $cdata['commission'];
                                        $cdata['devise']='USD';

                                        $cdata['total'] = $cdata['montant'] + $cdata['commission'] + 0.83;        

                                }
								else
								{
										# Convert amount to cdf to get the total in cdf
										$cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];

										# Convert commission to cdf. the commission has to be in cdf no matter what the case is.
										$cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
										$cdata['devise']='CDF';

										$cdata['total'] = $cdata['montant'] + $cdata['commission'] + 0.83;
								}
                               
                        }
                        else if($cdata['devise'] == 'USD' && $oDeivise =='CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission']*$taux['Dollar_4'];
                                $cdata['devise']='CDF';

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);

                        }
                        else if($cdata['devise'] == 'CDF' && $oDeivise =='USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
                        $cdata['commission'] = 5.17;
                        $cdata['total'] = $data['montant'];

						
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
						
						
                        return $ar; exit;
                }
        }
        
        public function check_request($request)
        {   
                $log_request = var_export($request, true);
                
                $this->save_log($log_request,"check_passport");

                if(isset($request->reference_number) && $request->reference_number!="")
                {
                        return true;
                }
                else
                {
                        return false;
              
                }
             
        }
        
}