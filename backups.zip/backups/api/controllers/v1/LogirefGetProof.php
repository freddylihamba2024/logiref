<?php
require  'Middleware.php';
/**
 * Description of LogirefCheckDocument
 * This endpoint is used to verify the existence of a note.
 * @author alvin Bauma
 */
class LogirefGetProof extends Middleware {

    public function __construct() {
        parent::__construct();
        
        $this->load->library('m_pdf');
        $this->load->library('ciqrcode');
    }
    
    
    public function index_post() 
    {
            $request = json_decode(file_get_contents('php://input'));
            
            $regie = null;
            $note = null;
            
            if($request)
            {
                    $regie = strtolower($request->regie);
                    $note = $request->note;
                    
                    if($regie != null && in_array($regie, $this->regies))
                    {
                            if($note->logiref_id)
                            {
                                    if($regie == "dgi") $this->get_proof_dgi($note->logiref_id);
                                    if($regie == "dgda") $this->get_proof_dgda($note->logiref_id);
                                    if($regie == "dgrad") $this->get_proof_dgrad($note->logiref_id);
                                    if($regie == "dgrk") $this->get_proof_dgrk($note->logiref_id);
                            }
                            else
                            {
                                    $this->error_message("No information from this logirefid was found");
                            }
                    }
                    else
                    {
                            $this->error_message("The tax authority that you have entered does not exist");
                    }
            }
            else 
            {
                    $this->error_message("No document related to this information was found, No parameter getted");
            }
            
    }
    
    private function get_proof_dgi($logirefid) 
    {
            $paiement = $this->encaissement_model->get_paiement_tresor_by_logirefid($logirefid);
            
            $_SESSION['Logiref_groupe']='banks';
            $_SESSION['Logiref_guichet'] = $paiement->Agence_20;
            $_SESSION['Logiref_agence'] = $paiement->Guichet_21;
            
            $id = $paiement->Id_0;
            
            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($paiement->Id_0);
            
            # Suite numerique
            if($id !='')
            {
                    $number = '';
                    $nb = strlen($id);

                    $iteration = 10 - $nb;

                    for($i=1; $i<=$iteration; $i++)
                    {
                                    $number .= '0';
                    }
                    $number = $number.$id;

                    $this->data['number'] = $number;
            }
            
            $guichets = $this->branches_model->get_dropdown("guichets");
            
            $users= $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
            $bureau= $this->data['bureau'] =$this->logiref_model->get_dropdown("services");
            # Display the amaount in letter
            $montant = number_format($encaissement->Montant_11,2,","," ");
            $this->data['number_letter'] = $this->data('number_letter',$montant, $encaissement->Devise_12);
            
            //creation de qrcode
            $dir = "./drive/logiref/". $this->session->userdata('account_id')."/". $this->session->userdata('user_id')."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if(is_dir($dir)==false)
            {
                    mkdir($dir,0777,true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28.' '.$this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11.' '.$this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if(isset($cbs_return["Num_evenement"]))
            {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            }
            else
            {
                $param ['identifiant'] = NULL;
            }
            $param['ville_agence'] = $guichet->Ville_7.'/'.$guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28,2,","," ").' '.$this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11,2,","," ").' '.$this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI")
            {   
                    $param ['referencenote'] = NULL;
                    $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15.' '.$services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                    $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17.' '. $periode_mois.'/'. $periode_annee;
                    $param['articlebudgetaire'] = NULL;
            }
            if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD")
            {
                    $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                    $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15.' '.$bureau[$this->data['encaissement']->Service_16];
                    $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                    $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/'.$this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir."/".$this->session->userdata('account_id').'.jpeg';

            $this->ciqrcode->generate($params);
            
            $html = $this->load->view('ebcdc/banks/impression/_attestation_dgrad', $this->data, true);
            
            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');		
            $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('',1);
            $pdf->WriteHTML($html,2);
            
            $pdf->Output($pdfFilePath, "F");
            
            $file = file_get_contents($pdfFilePath);
            
            $filebase64 = base64_encode($file);
            
            if(isset($filebase64) && $filebase64 != "")
            {
                    ######## proof created successfully ###########
                    $return = new stdClass();
                    $return->logiref_id = $note['Logirefid_4'];
                    $return->regie = 'DGI';
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "description" => "success",
                            "data" => [
                                "format"=>"byte",
                                "proof" => $filebase64,
                            ]
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    // L'initialisation du bulletin n'a pas été effectué : message erreur à retourner
                    $this->error_message("The proof has not been generated");
            }
    }
    
    private function get_proof_dgrad($logirefid) 
    {
            $paiement = $this->encaissement_model->get_paiement_tresor_by_logirefid($logirefid);
            
            $_SESSION['Logiref_groupe']='banks';
            $_SESSION['Logiref_guichet'] = $paiement->Agence_20;
            $_SESSION['Logiref_agence'] = $paiement->Guichet_21;
            
            $id = $paiement->Id_0;
            
            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($paiement->Id_0);
            
            # Suite numerique
            if($id !='')
            {
                    $number = '';
                    $nb = strlen($id);

                    $iteration = 10 - $nb;

                    for($i=1; $i<=$iteration; $i++)
                    {
                                    $number .= '0';
                    }
                    $number = $number.$id;

                    $this->data['number'] = $number;
            }
            
            $guichets = $this->branches_model->get_dropdown("guichets");
            
            $users= $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
            $bureau= $this->data['bureau'] =$this->logiref_model->get_dropdown("services");
            # Display the amaount in letter
            $montant = number_format($encaissement->Montant_11,2,","," ");
            $this->data['number_letter'] = $this->data('number_letter',$montant, $encaissement->Devise_12);
            
            //creation de qrcode
            $dir = "./drive/logiref/". $this->session->userdata('account_id')."/". $this->session->userdata('user_id')."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if(is_dir($dir)==false)
            {
                    mkdir($dir,0777,true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28.' '.$this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11.' '.$this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if(isset($cbs_return["Num_evenement"]))
            {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            }
            else
            {
                $param ['identifiant'] = NULL;
            }
            $param['ville_agence'] = $guichet->Ville_7.'/'.$guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28,2,","," ").' '.$this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11,2,","," ").' '.$this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI")
            {   
                    $param ['referencenote'] = NULL;
                    $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15.' '.$services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                    $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17.' '. $periode_mois.'/'. $periode_annee;
                    $param['articlebudgetaire'] = NULL;
            }
            if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD")
            {
                    $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                    $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15.' '.$bureau[$this->data['encaissement']->Service_16];
                    $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                    $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/'.$this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir."/".$this->session->userdata('account_id').'.jpeg';

            $this->ciqrcode->generate($params);
            
            $html = $this->load->view('ebcdc/banks/impression/_attestation_dgrad', $this->data, true);
            
            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');		
            $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('',1);
            $pdf->WriteHTML($html,2);
            
            $pdf->Output($pdfFilePath, "F");
            
            $file = file_get_contents($pdfFilePath);
            
            $filebase64 = base64_encode($file);
            
            if(isset($filebase64) && $filebase64 != "")
            {
                    ######## proof created successfully ###########
                    $return = new stdClass();
                    $return->logiref_id = $note['Logirefid_4'];
                    $return->regie = 'DGRAD';
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "description" => "success",
                            "data" => [
                                "format"=>"byte",
                                "proof" => $filebase64,
                            ]
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    // L'initialisation du bulletin n'a pas été effectué : message erreur à retourner
                    $this->error_message("The proof has not been generated");
            }
    }
    
    private function get_proof_dgda($logirefid) 
    {
            $bulletin = $this->integration_model->get_declaration_by_logirefid($logirefid);
            
            $user = $this->session->userdata('user_id');
            $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
            $encrytions = json_decode($credentials->Password_18);
                        
            $declaration = json_decode($bulletin->Results_13);
            $apidata['ReceiptSerial'] = $declaration->receiptSerial;
            $apidata['ReceiptNumber'] = $declaration->receiptNumber;
            $apidata['ReceiptDate'] = $declaration->receiptDate;
            $apidata['Office'] = $bulletin->Office_6;
            $apidata['Account'] = $this->session->userdata('account_id');
            $apidata['Paiementid'] = $bulletin->Id_0;
            $apidata['User'] = $this->session->userdata('user_id');
            $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
            $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
            $apidata['code_bank'] = (isset($encrytions->codebank))? $encrytions->codebank:'';
            
            $response = $this->curl_model->call_dgda_quittance($apidata);
            
            
            if ($response=='E406') $this->error_message("La quittance n\'a pas &eacute;t&eacute; g&eacute;n&eacute;r&eacute;e, une erreur est survenue lors de la récupération. Veuillez r&eacute;essayer s\'il vous pla&icirc;t !",$response);
            elseif ($response=='E404' || $response=='E41' || $response=='E005') $this->error_message("serveur SYDONIA 41.215.253.187 pas disponible...!",$response);
            elseif ($response=='E001' || $response=='E003') $this->error_message("Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides",$response);
            
            $bulletin = $this->integration_model->get_declaration_by_logirefid($logirefid);
            
            if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
            {
                    $quittance = $bulletin->Pdfcontent_18;
                    
                    $quittance = "./api/endpoints/sydonia/".$quittance;
            
                    $file = file_get_contents($quittance);

                    $filebase64 = base64_encode($file);

                    if(isset($filebase64) && $filebase64 != "")
                    {
                            ######## proof created successfully ###########
                            $return = new stdClass();
                            $return->logiref_id = $logirefid;
                            $return->regie = 'DGDA';
                            $data = [
                                    "code" => REST_Controller::HTTP_OK,
                                    "description" => "success",
                                    "data" => [
                                        "format"=>"byte",
                                        "proof" => $filebase64,
                                    ]
                            ];
                            $this->response($data, REST_Controller::HTTP_OK);
                    }
                    else
                    {
                            // L'initialisation du bulletin n'a pas été effectué : message erreur à retourner
                            $this->error_message("The proof has not been generated");
                    }
            }
            else
            {
                    // L'initialisation du bulletin n'a pas été effectué : message erreur à retourner
                    $this->error_message("The proof has not been generated");
            }
    }

    
    public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
    {
            if($obj == "number_letter")
            {
                $value = $this->number_letter->converter($data, $arg);

                return $value;
            }
    }
    
    public function check_request($regie, $note)
    {
            if($regie == "dgi")
            {
                    if(isset($note->logiref_id))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgda")
            {
                    if(isset($note->logiref_id))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrad")
            {
                    
                    if(isset($note->logiref_id))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrk")
            {
                    if(isset($note->declaration_id) && isset($note->branch_code))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
    }

}

