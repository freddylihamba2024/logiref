<?php
require  'Middleware.php';
/**
 * Description of LogirefCheckCode
 * This endpoint allows you to retrieve information about a service or a tax from its code
 * @author alvin Bauma
 */
class LogirefCheckCode extends Middleware {

    public function __construct() {
        parent::__construct();
    }
    
    
    public function index_get() 
    {
            $regie = strtolower($this->input->get("regie"));
            $typeCode = strtolower($this->input->get("typeCode"));
            $code = $this->input->get("code");
            
            if (!empty($typeCode) && !empty($code) && !empty($regie) && in_array($regie, $this->regies) && in_array($typeCode, $this->params_logireflist) )
            {
                    $this->get_code($regie, $typeCode, $code);
            }
            else
            {
                    $this->error_message("Impossible de récuperer les informations. Veuillez renseigner tous les champs requis svp");
            }
        
    }


    
    private function get_code($regie, $typeCode, $code) 
    {
            $data_code = null;
            if($typeCode == "taxe" || $typeCode == "tax")
            {
                    $taxe =  $this->logiref_model->get_recette_info_by_code($code, $regie);
                    if($taxe)
                    {
                            $data_code = new stdClass();
                            $data_code->id = $taxe->Id_0;
                            $data_code->code = $taxe->Code_7;
                            $data_code->designation = $taxe->Recette_6;
                    }
                    
            }
            elseif ($typeCode == "service")
            {
                    $service = $this->logiref_model->get_service_info_by_code($code, $regie);
                    if($service)
                    {
                            $data_code = new stdClass();
                            $data_code->id = $service->Id_0;
                            $data_code->code = $service->Code_7;
                            $data_code->designation = $service->Service_5;
                    }
            }
            
            if($data_code)
            {
                
                    //######## Code retrieved Code 200 ###########
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "description" => "success",
                            "line" => 1,
                            "data" => [
                                "client" => $data_code,
                            ]
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    $this->error_message("No information related to this code was found");
            }
    }
}
