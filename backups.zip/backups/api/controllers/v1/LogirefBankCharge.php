<?php
require  'Middleware.php';
/**
 * Description of LogirefBankCharge
 * This endpoint allows you to retrieve the bank commission depending on 
 * the amount, currency, agency, tax authority, service and payment receipt,
 * @author alvin Bauma
 */
class LogirefBankCharge extends Middleware {

    public function __construct() {
        parent::__construct();
    }
    
    
    public function index_get() 
    {
            $montant = $this->input->get("montant");
            $devise = $this->input->get("devise");
            $regie = $this->input->get("regie");
            $service = $this->input->get("service");
            $recette = $this->input->get("recette");
            $agence = $this->input->get("agence");
            
            if (!empty($montant) && !empty($devise) && !empty($regie) && !empty($service) && !empty($recette) && !empty($agence))
            {
                    $this->get_bank_charge($montant, $devise, $regie, $service, $recette, $agence);
            }
            else
            {
                    $this->error_message("Impossible de récuperer les informations. Veuillez renseigner tous les champs requis svp");
            }
        
    }


    
    private function get_bank_charge($montant, $devise, $regie, $service, $recette, $agence) 
    {
        
            $bank_charge =  $this->fees_model->get_bank_charges($regie, $service, $recette, $devise, $montant, $agence);
            
            if($bank_charge)
            {
                
                    $data_bc = new stdClass();
                    $data_bc->amount = $bank_charge['Valeur'];
                    $data_bc->currency = $bank_charge['Unite'];

                    //######## NIF retrieved Code 200 ###########
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "description" => "success",
                            "line" => 1,
                            "data" => [
                                "client" => $data_bc,
                            ]
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    $this->error_message("Impossible de récuperer la commission bancaire. Veuillez verifier les paramètres fournis svp");
            }
    }
}
