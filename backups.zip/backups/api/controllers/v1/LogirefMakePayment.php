<?php

require 'Middleware.php';

/**
 * Description of LogirefMakePayment
 * This endpoint is used to verify the existence of a note.
 * @author alvin Bauma
 */
class LogirefMakePayment extends Middleware {

    public function __construct() {
        parent::__construct();
	    $this->load->model('api/cashcloud_comptabilisation_model');
    }

    public function index_post() {
        $request = json_decode(file_get_contents('php://input'));
        $regie = null;
        $note = null;

        if ($request) {
            $regie = strtolower($request->tax_authority);
            $note = $request->note;

            if ($regie != null && in_array($regie, $this->regies)) {
                if ($note) {
                    $return = $this->check_request($regie, $note);

                    if ($return) {
                        if ($regie == "dgi")
                            $this->post_note_dgi($note->logiref_id, $note->customer_email, $note->customer_msisdn);
                        if ($regie == "dgda")
                            $this->post_note_dgda($note->logiref_id, $note->customer_email, $note->customer_msisdn);
                        if ($regie == "dgrad")
                            $this->post_note_dgrad($note->logiref_id, $note->customer_email, $note->customer_msisdn);
                    }
                } else {
                    $this->error_message("Failed to read the request, please check your request ");
                }
            } else {
                $this->error_message("The tax authority that you have entered does not exist");
            }
        } else {
            $this->error_message("Bad request, please kindly check your request");
        }
    }

    private function post_note_dgrk($logiref_id) {
        //Fonction a activer apres integration avec la DGRK
        return NULL;
    }

    private function post_note_dgi($logiref_id, $customer_email, $customer_number) {
        //Appel du paiement par son logirefid
		$data_return=[];
        $paiement = $this->encaissement_model->get_paiement_by_logirefid($logiref_id);

        if ($paiement->Checkerid_10 != 0) {
            ######## Payment was made successfully ###########
            $return = new stdClass();
            $return->logiref_id = $logiref_id;
            $return->proof = '';
            $data_return = [
                "code" => '202',
                "status" => "success",
                "message" => "Declaration already paid.",
                "data" => $return
            ];

            $this->response($data_return, REST_Controller::HTTP_OK);
        } elseif (isset($paiement->Montant_11)) {
            $result = $this->make_validation_dgi($paiement, $customer_email, $customer_number);
            $result = json_decode($result, true);

            if (isset($result['code_transaction']) && $result['code_transaction'] == 200) {
                if (isset($result['code_transaction']) && $result['code_transaction'] == 200) {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $proof = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $proof->code = 200;
                    $proof->message = 'The proof was sent successfully to the customer by email';

                    $data_return = [
                        "code" => REST_Controller::HTTP_OK,
                        "status" => "success",
                        "message" => "Declaration was paid successfully.",
                        "data" => $return,
                        "proof" => $proof
                    ];

                    $this->response($data_return, REST_Controller::HTTP_OK);
                } else {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $proof = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $proof->code = 300;
                    $proof->message = 'The proof was not sent to the customer';

                    $data_return = [
                        "code" => REST_Controller::HTTP_OK,
                        "status" => "success",
                        "message" => "Declaration was paid successfully.",
                        "data" => $return,
                        "proof" => $proof
                    ];

                    $this->response($data_return, REST_Controller::HTTP_OK);
                }
            } else {
                ######## Payment failed###########
                $return = new stdClass();
                $return->logiref_id = $logiref_id;

                $data_return = [
                    "code" => 300,
                    "status" => "failed",
                    "message" => "The declaration has not been validated, an error occured while the integration of transactions in Finacle",
                    "data" => null,
                    "proof" => null
                ];

                $this->response($data_return, 300);
            }
        } else {
            $this->error_message("No declaration found for logirefid " . $logiref_id . " ", 307,'make_payment_dgi');
        }
		$log_response = var_export($data_return, true);
		$this->save_log($log_response,'make_payment_dgi');
    }

    private function post_note_dgrad($logiref_id, $customer_email, $customer_number) {
        //Appel du paiement par son logirefid
		$data_return=[];
        $paiement = $this->encaissement_model->get_paiement_by_logirefid($logiref_id);

        if ($paiement->Checkerid_10 != 0) {
            ######## Payment was made successfully ###########
            $return = new stdClass();
            $return->logiref_id = $logiref_id;
            $return->proof = '';
            $data_return = [
                "code" => '202',
                "status" => "success",
                "message" => "Declaration already paid.",
                "data" => $return
            ];

            $this->response($data_return, REST_Controller::HTTP_OK);
        } elseif (isset($paiement->Montant_11)) {
            $result = $this->make_validation_dgrad($paiement, $customer_email, $customer_number);
            $result = json_decode($result, true);

            if (isset($result['code_transaction']) && $result['code_transaction'] == 200) {
                if (isset($result['code_transaction']) && $result['code_transaction'] == 200) {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $proof = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $proof->code = 200;
                    $proof->message = 'The proof was sent successfully to the customer by email';

                    $data_return = [
                        "code" => REST_Controller::HTTP_OK,
                        "status" => "success",
                        "message" => "Declaration was paid successfully.",
                        "data" => $return,
                        "proof" => $proof
                    ];

                    $this->response($data_return, REST_Controller::HTTP_OK);
                } else {
                    ######## Payment was made successfully ###########
                    $return = new stdClass();
                    $proof = new stdClass();
                    $return->logiref_id = $logiref_id;
                    $proof->code = 300;
                    $proof->message = 'The proof was not sent to the customer';

                    $data_return = [
                        "code" => REST_Controller::HTTP_OK,
                        "status" => "success",
                        "message" => "Declaration was paid successfully.",
                        "data" => $return,
                        "proof" => $proof
                    ];

                    $this->response($data_return, REST_Controller::HTTP_OK);
                }
            } else {
                ######## Payment failed ###########
                $return = new stdClass();
                $return->logiref_id = $logiref_id;

                $data_return = [
                    "code" => 300,
                    "status" => "failed",
                    "message" => "The note has not been validated, an error occured while the integration of transactions in Finacle.",
                    "data" => null,
                    "proof" => null
                ];

                $this->response($data_return, 300);
            }
        } else {
            $this->error_message("No declaration found for logirefid " . $logiref_id . " ", 307,'make_payment_dgrad');
        }
		$log_response = var_export($data_return, true);
		$this->save_log($log_response,'make_payment_dgrad');
    }

    private function post_note_dgda($logiref_id, $customer_email, $customer_msisdn) {
        //Appel du bulletin par son logirefid
		
        $bulletin = $this->integration_model->get_declaration_by_logirefid($logiref_id);
		
        $data_return=[];
        
        if ($bulletin == "" || $bulletin == NULL) {
            $this->error_message("No declaration found for this logiref_id", "E303",'make_payment_dgda');
        } 
        elseif(isset($bulletin->Status_2) && ($bulletin->Status_2 == '2' || $bulletin->Status_2 == '3' || $bulletin->Status_2 == '4'))
        {
                $this->error_message("This bulletin has already been paid", "E304",'make_payment_dgda');
        }
        elseif (isset($bulletin->Amount_12)) {
            $_POST['Amount'] = $bulletin->Amount_12;
            $_POST['designation'] = $bulletin->Designation_23;
            $_POST['Year'] = $bulletin->Year_5;
            $_POST['Series'] = $bulletin->Serie_7;
            $_POST['Number'] = $bulletin->Number_8;
            $_POST['Agent'] = $bulletin->Agent_10;
            $_POST['Office'] = $bulletin->Office_6;
            $_POST['Nif'] = $bulletin->Nif_9;
            $_POST['Bank'] = $bulletin->Bank_11;
            $_POST['devise'] = "CDF";

            $_POST['Compte_guichet'] = isset($bulletin->Account_24) ? $bulletin->Account_24 : '00000000000000000000000';
            $_POST['Commission'] = isset($bulletin->Commission_26) ? $bulletin->Commission_26 : 0;
            $_POST['Devise_commission'] = isset($bulletin->Devise_27) ? $bulletin->Devise_27 : "CDF";
            $_POST['Total_amount'] = isset($bulletin->Amount_25) ? $bulletin->Amount_25 : 0;
            $_POST['Mode'] = "7";
            $_POST['lot'] = "mobile";
            $_POST['reference'] = $logiref_id;
            $_POST['Paiementid'] = $bulletin->Id_0;
            $_POST['Agence'] = $bulletin->Agence_32;
            $_SESSION['Logiref_guichet'] = $bulletin->Agence_32;
            $_POST['bank_account'] = isset($bulletin->Account_28) ? $bulletin->Account_28 : "00000000000000000000000";
            $_POST['Devise_account'] = isset($bulletin->Devise_29) ? $bulletin->Devise_29 : "CDF";
            $_POST['account_name'] = "";
            $_POST['Taux'] = $bulletin->Taux_31;

            $_POST['DateL'] = gmdate('Y-m-d');
            $user = $this->session->userdata('user_id');
			
            $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);

            $response = $this->curl_model->call_bank_comptant_single_mobile($credentials);
			
            $response = trim($response);
            
            $result = json_decode($response, true);
			
            //simulation
            if (isset($result['code']) && $result['code'] != 'OK') {
                $this->error_message($result['message'], $result['code']);
            } else {
                $bulletin = $this->integration_model->get_paiement_sydonia($result['id']);
				
                $bulletin = json_decode($bulletin->Results_13);
				
                $details = isset($bulletin->declarationsPaid) ? $bulletin->declarationsPaid : "";
               
                $return_breakdown = $this->save_breakdown_bulletin($logiref_id, $bulletin->Account_28);
				
                if ($return_breakdown != 0 && $return_breakdown != 'E500') {
					
                    $bcc_fees=$bulletin->totalAmount * 0.0005;
					
                    # Payment validation 
                    $return_validation = $this->validate_breakdown($result['id']);

                    # Retrieve the proof
                    $return_proof = $this->get_proof_of_payment($result['id']);

                    $description = "";
                    # Get the note line to retrieve the path of the payment proof
                    $bulletin = $this->integration_model->get_paiement_sydonia($result['id']);

                    if (isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 != "") {
                        $pdfFilePath = './api/endpoints/sydonia/' . $bulletin->Pdfcontent_18;
                        $designation = isset($bulletin->Designation_23) ? $bulletin->Designation_23 : $bulletin->Nif_9;
                        $customer = isset($designation) ? $designation : "Customer";

                        $url_via_sms = str_replace("./", "https://logireftest.cd.ebsafrica.com/", $pdfFilePath);
                        //$return_sms = $this->data('paiement_sms', 'DGDA', $url_via_sms, $customer_msisdn);

                        //$return_email = $this->mail->mail_send_proof($customer_email, $customer, "en", $pdfFilePath, "DGDA", $bulletin->Amount_12, 'CDF');
						
						$this->mail->mail_send_proof($customer_email, $customer, "fr", $pdfFilePath, "DGDA", $bulletin->Amount_12, 'CDF');
                        
						######## Payment was made successfully ###########
                        $return = new stdClass();
                        $return->logiref_id = $logiref_id;
						$return->bcc_fees=$bcc_fees;
						$return->currency="CDF";

                        $data_return = [
                            "code" => REST_Controller::HTTP_OK,
                            "status" => "success",
                            "message" => "Declaration was paid successfully.",
                            "data" => $return
                        ];

                        $this->response($data_return, REST_Controller::HTTP_OK);
                    } else {
						
						$pdfFilePath = './api/endpoints/sydonia/' . $bulletin->Pdfcontent_18;
                        $designation = isset($bulletin->Designation_23) ? $bulletin->Designation_23 : $bulletin->Nif_9;
                        $customer = isset($designation) ? $designation : "Customer";
						
						$this->mail->mail_send_proof($customer_email, $customer, "fr", $pdfFilePath, "DGDA", $bulletin->Amount_12, 'CDF');
						
                        ######## Payment was made successfully ###########
                        $return = new stdClass();
						$return->bcc_fees=$bcc_fees;
						$return->currency="CDF";
                        $return->logiref_id = $logiref_id;

                        $data_return = [
                            "code" => REST_Controller::HTTP_OK,
                            "status" => "success",
                            "message" => "Declaration was paid successfully.",
                            "data" => $return
                        ];

                        $this->response($data_return, REST_Controller::HTTP_OK);
						
						
                    }
                } elseif ($return_breakdown == 'E500') {
                    $this->error_message("Payment already saved, please kindly contact the administrator !", 500,'make_payment_dgda');
                } else {
                    $this->error_message("Payment has not been saved, an error ocurred !", 400,'make_payment_dgda');
                }
            }
        } else {
            $this->error_message("No declaration found for logirefid " . $logiref_id . " ", 307,'make_payment_dgda');
        }
			$log_response = var_export($data_return, true);
			$this->save_log($log_response,'make_payment_dgda');
    }

    public function make_validation_dgrad($paiement, $customer_email, $customer_number) {
        $_SESSION['Logiref_groupe'] = 'banks';
        $data_to_update['Status_2'] = 5;

        $this->encaissement_model->update_payment_tresor($data_to_update, $paiement->Logirefid_4);

        $infos = json_decode($paiement->Notereference_30, true);

        $data['Beneficaire_15'] = 'DGRAD';
        $data['Logirefid_4'] = $paiement->Logirefid_4;
        $data['Account_3'] = $paiement->Account_3;
        $data['Id_0'] = $paiement->Id_0;

        $response = $this->curl_model->call_bank_virement($data);
        $return = json_decode($response, true);

        if (isset($return['response']) && $return['response'] == '200') {
            $result = json_decode($paiement->Notereference_30, true);

            foreach ($return as $row) {
                $result['Num_evenement'] = $row['Num_evenement'];
                break;
            }

            $logirefid = $data['Logirefid_4'];

            $data = array();

            $data['Notereference_30'] = json_encode($result);
            $data['Id_0'] = $paiement->Id_0;
            $data['Logirefid_4'] = $logirefid;
            $data['Status_2'] = 1;
            $data['Checkerid_10'] = $this->session->userdata("user_id");
            $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

            $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->cashcloud_comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

            # Suite numerique
            if ($id != '') {
                $number = '';
                $nb = strlen($id);

                $iteration = 10 - $nb;

                for ($i = 1; $i <= $iteration; $i++) {
                    $number .= '0';
                }
                $number = $number . $id;

                $this->data['number'] = $number;
            }

            $guichets = $this->branches_model->get_dropdown("guichets");
            $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';
            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);
            $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");
            # Display the amaount in letter
            $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

            # Treatment of information returned by the CBS
            $cbs_return = $this->integration_model->get_cbs_returns($id);
            if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                $cbs_return = json_decode($cbs_return->Result_6, true);
                $this->data['cbs_return'] = $cbs_return;
            }
            $infos = json_decode($encaissement->Notereference_30, true);
            $date = explode('/', $infos["standard"]);

            if (count($date) == 3) {
                $periode_mois = $date[1];
                $periode_annee = $date[0];
            } elseif (count($date) == 2) {
                $periode_mois = $date[0];
                $periode_annee = $date[1];
            } else {
                $periode_mois = "";
                $periode_annee = "";
            }

            //creation de qrcode
            $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if (is_dir($dir) == false) {
                mkdir($dir, 0777, true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if (isset($cbs_return["Num_evenement"])) {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            } else {
                $param ['identifiant'] = NULL;
            }

            $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") {
                $param ['referencenote'] = NULL;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                $param['articlebudgetaire'] = NULL;
            }
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") {
                $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y', strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/' . $this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

            $this->ciqrcode->generate($params);

            $service_type = $this->logiref_model->get_dropdown("type_services");

            if ($encaissement->Beneficaire_15 == "DGRAD") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dgrad', $this->data, true);
            }
            if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27022470") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_taxegardienage', $this->data, true);
            }

            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');
            $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('', 1);
            $pdf->WriteHTML($html, 2);

            $pdf->Output($pdfFilePath, "F");

            $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

            $customer = isset($designation) ? $designation : "Customer";

            $url_via_sms = str_replace("./", "https://logireftest.cd.ebsafrica.com/", $pdfFilePath);
            $return_sms = $this->data('paiement_sms', 'DGRAD', $url_via_sms, $customer_number);

            $return = $this->mail->mail_send_proof($customer_email, $customer, "en", $pdfFilePath, "DGRAD", $encaissement->Montant_11, $encaissement->Devise_12);

            if ($return == true) {
                $function_return['code_email'] = 200;
                $function_return['code_transaction'] = 200;
            } else {
                $function_return['code_email'] = 300;
                $function_return['code_transaction'] = 200;
            }

            return json_encode($function_return);
        } else {
            $logirefid = $data['Logirefid_4'];

            $data = array();

            $data['Notereference_30'] = json_encode($result);
            $data['Id_0'] = $paiement->Id_0;
            $data['Logirefid_4'] = $logirefid;
            $data['Status_2'] = 1;
            $data['Checkerid_10'] = $this->session->userdata("user_id");
            $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

            $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->cashcloud_comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

            # Suite numerique
            if ($id != '') {
                $number = '';
                $nb = strlen($id);

                $iteration = 10 - $nb;

                for ($i = 1; $i <= $iteration; $i++) {
                    $number .= '0';
                }
                $number = $number . $id;

                $this->data['number'] = $number;
            }

            $guichets = $this->branches_model->get_dropdown("guichets");
            $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';
            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);
            $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");
            # Display the amaount in letter
            $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

            # Treatment of information returned by the CBS
            $cbs_return = $this->integration_model->get_cbs_returns($id);
            if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                $cbs_return = json_decode($cbs_return->Result_6, true);
                $this->data['cbs_return'] = $cbs_return;
            }
            $infos = json_decode($encaissement->Notereference_30, true);
            $date = explode('/', $infos["standard"]);

            if (count($date) == 3) {
                $periode_mois = $date[1];
                $periode_annee = $date[0];
            } elseif (count($date) == 2) {
                $periode_mois = $date[0];
                $periode_annee = $date[1];
            } else {
                $periode_mois = "";
                $periode_annee = "";
            }

            //creation de qrcode
            $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if (is_dir($dir) == false) {
                mkdir($dir, 0777, true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if (isset($cbs_return["Num_evenement"])) {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            } else {
                $param ['identifiant'] = NULL;
            }

            $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") {
                $param ['referencenote'] = NULL;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                $param['articlebudgetaire'] = NULL;
            }
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") {
                $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y', strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/' . $this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

            $this->ciqrcode->generate($params);

            $service_type = $this->logiref_model->get_dropdown("type_services");

            if ($encaissement->Beneficaire_15 == "DGRAD") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dgrad', $this->data, true);
            }
            if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27022470") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_taxegardienage', $this->data, true);
            }

            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');
            $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('', 1);
            $pdf->WriteHTML($html, 2);

            $pdf->Output($pdfFilePath, "F");

            $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

            $customer = isset($designation) ? $designation : "Customer";

            $url_via_sms = str_replace("./", "https://logireftest.cd.ebsafrica.com/", $pdfFilePath);
            $return_sms = $this->data('paiement_sms', 'DGRAD', $url_via_sms, $customer_number);

            $return = $this->mail->mail_send_proof($customer_email, $customer, "en", $pdfFilePath, "DGRAD", $encaissement->Montant_11, $encaissement->Devise_12);

            if ($return == true) {
                $function_return['code_email'] = 200;
                $function_return['code_transaction'] = 300;
            } else {
                $function_return['code_email'] = 300;
                $function_return['code_transaction'] = 300;
            }

            return json_encode($function_return);
        }
    }

    public function make_validation_dgi($paiement, $customer_email, $customer_number) {
        $_SESSION['Logiref_groupe'] = 'banks';
        $data_to_update['Status_2'] = 5;
        $data_to_update['Email_54'] = $customer_email;
        $data_to_update['Msisdn_55'] = $customer_number;

        $this->encaissement_model->update_payment_tresor($data_to_update, $paiement->Id_0);

        $infos = json_decode($paiement->Notereference_30, true);

        $data['Beneficaire_15'] = 'DGI';
        $data['Logirefid_4'] = $paiement->Logirefid_4;
        $data['Account_3'] = $paiement->Account_3;
        $data['Id_0'] = $paiement->Id_0;

        $function_return = array();

        $response = $this->curl_model->call_bank_virement($data);
        $return = json_decode($response, true);

        if (isset($return['response']) && $return['response'] == '200') {
            $result = json_decode($paiement->Notereference_30, true);

            foreach ($return as $row) {
                $result['Num_evenement'] = $row['Num_evenement'];
                break;
            }

            $logirefid = $data['Logirefid_4'];

            $data = array();

            $data['Notereference_30'] = json_encode($result);
            $data['Id_0'] = $paiement->Id_0;
            $data['Logirefid_4'] = $logirefid;
            $data['Status_2'] = 1;
            $data['Checkerid_10'] = $this->session->userdata("user_id");
            $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
            $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->cashcloud_comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

            # Suite numerique
            if ($id != '') {
                $number = '';
                $nb = strlen($id);

                $iteration = 10 - $nb;

                for ($i = 1; $i <= $iteration; $i++) {
                    $number .= '0';
                }
                $number = $number . $id;

                $this->data['number'] = $number;
            }

            $guichets = $this->branches_model->get_dropdown("guichets");
            $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);

            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';

            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);

            $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");

            # Display the amaount in letter
            $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

            # Treatment of information returned by the CBS
            $cbs_return = $this->integration_model->get_cbs_returns($id);
            if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                $cbs_return = json_decode($cbs_return->Result_6, true);
                $this->data['cbs_return'] = $cbs_return;
            }
            $infos = json_decode($encaissement->Notereference_30, true);
            $date = explode('/', $infos["standard"]);

            if (count($date) == 3) {
                $periode_mois = $date[1];
                $periode_annee = $date[0];
            } elseif (count($date) == 2) {
                $periode_mois = $date[0];
                $periode_annee = $date[1];
            } else {
                $periode_mois = "";
                $periode_annee = "";
            }

            //creation de qrcode
            $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if (is_dir($dir) == false) {
                mkdir($dir, 0777, true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if (isset($cbs_return["Num_evenement"])) {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            } else {
                $param ['identifiant'] = NULL;
            }

            $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") {
                $param ['referencenote'] = NULL;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                $param['articlebudgetaire'] = NULL;
            }
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") {
                $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y', strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/' . $this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

            $this->ciqrcode->generate($params);

            $service_type = $this->logiref_model->get_dropdown("type_services");

            if ($encaissement->Beneficaire_15 == "DGI" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 == "AMRA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge_amra', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "DGE" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 == "TVA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "DGE" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 != "TVA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge_htva', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CDI" && $encaissement->Typerecette_17 != "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cdi', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] == "DGE" || $service_type[$encaissement->Service_16] == "CDI") && $encaissement->Typerecette_17 == "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_iprier', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CIS" && $encaissement->Typerecette_17 == "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cis', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CIS" && $encaissement->Typerecette_17 != "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cis', $this->data, true);
            }

            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');
            $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('', 1);
            $pdf->WriteHTML($html, 2);

            $pdf->Output($pdfFilePath, "F");

            $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

            $customer = isset($designation) ? $designation : "Customer";

            $url_via_sms = str_replace("./", "https://logireftest.cd.ebsafrica.com/", $pdfFilePath);

            $return_sms = $this->data('paiement_sms', 'DGI', $url_via_sms, $customer_number);

            $return = $this->mail->mail_send_proof($customer_email, $customer, "en", $pdfFilePath, "DGI", $encaissement->Montant_11, $encaissement->Devise_12);

            if ($return == true) {
                $function_return['code_email'] = 200;
                $function_return['code_transaction'] = 200;
            } else {
                $function_return['code_email'] = 300;
                $function_return['code_transaction'] = 200;
            }

            return json_encode($function_return);
        } else {
            $logirefid = $data['Logirefid_4'];

            $data = array();

            $data['Notereference_30'] = json_encode($result);
            $data['Id_0'] = $paiement->Id_0;
            $data['Logirefid_4'] = $logirefid;
            $data['Status_2'] = 1;
            $data['Checkerid_10'] = $this->session->userdata("user_id");
            $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
            $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

            //now pass the data//
            $this->data['typeDoc'] = $this->logiref_model->documents;
            $this->data['devises'] = $this->logiref_model->devises;
            $this->data['modes'] = $this->logiref_model->modes;
            $this->data['months'] = $this->cashcloud_comptabilisation_model->months;
            $this->data['users'] = $this->main_model->get_dropdown('users');
            $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
            $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

            # Suite numerique
            if ($id != '') {
                $number = '';
                $nb = strlen($id);

                $iteration = 10 - $nb;

                for ($i = 1; $i <= $iteration; $i++) {
                    $number .= '0';
                }
                $number = $number . $id;

                $this->data['number'] = $number;
            }

            $guichets = $this->branches_model->get_dropdown("guichets");
            $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
            $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
            $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);

            $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
            $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';

            $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
            $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);

            $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");

            # Display the amaount in letter
            $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

            # Treatment of information returned by the CBS
            $cbs_return = $this->integration_model->get_cbs_returns($id);
            if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                $cbs_return = json_decode($cbs_return->Result_6, true);
                $this->data['cbs_return'] = $cbs_return;
            }
            $infos = json_decode($encaissement->Notereference_30, true);
            $date = explode('/', $infos["standard"]);

            if (count($date) == 3) {
                $periode_mois = $date[1];
                $periode_annee = $date[0];
            } elseif (count($date) == 2) {
                $periode_mois = $date[0];
                $periode_annee = $date[1];
            } else {
                $periode_mois = "";
                $periode_annee = "";
            }

            //creation de qrcode
            $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
            if (is_dir($dir) == false) {
                mkdir($dir, 0777, true);
            }
            $checkerid = $this->data['encaissement']->Checkerid_10;

            $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
            $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

            $param ['banque'] = $this->session->userdata('account_id');
            if (isset($cbs_return["Num_evenement"])) {
                $param ['identifiant'] = $cbs_return["Num_evenement"];
            } else {
                $param ['identifiant'] = NULL;
            }

            $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
            $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

            $param['designation'] = $this->data['encaissement']->Designation_14;
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") {
                $param ['referencenote'] = NULL;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                $param['articlebudgetaire'] = NULL;
            }
            if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") {
                $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                $param['motif_de_paiement'] = NULL;
            }

            $param['referencepaiement'] = $this->data['encaissement']->Reference_32;
            $param['date_demission'] = strftime('%d/%m/%Y', strtotime($encaissement->Datevaleur_31));
            $param['verification'] = 'https://taxes.cd.ebsafrica.com/' . $this->data['encaissement']->Noteid_26;

            $params['data'] = json_encode($param);
            $params['level'] = 'L';
            $params['size'] = '4';
            $this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

            $this->ciqrcode->generate($params);

            $service_type = $this->logiref_model->get_dropdown("type_services");

            if ($encaissement->Beneficaire_15 == "DGI" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 == "AMRA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge_amra', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "DGE" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 == "TVA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "DGE" && $encaissement->Typerecette_17 != "IPRIER" && $encaissement->Typerecette_17 != "TVA") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_dge_htva', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CDI" && $encaissement->Typerecette_17 != "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cdi', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] == "DGE" || $service_type[$encaissement->Service_16] == "CDI") && $encaissement->Typerecette_17 == "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_iprier', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CIS" && $encaissement->Typerecette_17 == "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cis', $this->data, true);
            } elseif ($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] == "CIS" && $encaissement->Typerecette_17 != "IPRIER") {
                $html = $this->load->view('ebcdc/banks/impression/_attestation_cis', $this->data, true);
            }

            $account_id = $this->session->userdata('account_id');
            $user_id = $this->session->userdata('user_id');
            $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            $pdf->WriteHTML('', 1);
            $pdf->WriteHTML($html, 2);

            $pdf->Output($pdfFilePath, "F");

            $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

            $customer = isset($designation) ? $designation : "Customer";

            $url_via_sms = str_replace("./", "https://logireftest.cd.ebsafrica.com/", $pdfFilePath);

            $return_sms = $this->data('paiement_sms', 'DGI', $url_via_sms, $customer_number);

            $return = $this->mail->mail_send_proof($customer_email, $customer, "en", $pdfFilePath, "DGI", $encaissement->Montant_11, $encaissement->Devise_12);

            if ($return == true) {
                $function_return['code_email'] = 200;
                $function_return['code_transaction'] = 300;
            } else {
                $function_return['code_email'] = 300;
                $function_return['code_transaction'] = 300;
            }

            return json_encode($function_return);
        }
    }

    public function save_breakdown_bulletin($logiref_id, $customer_account) {
		
        //Appel du bulletin par son logirefid
        $bulletin = $this->integration_model->get_declaration_by_logirefid($logiref_id);
		
		// Check whether the payment has already been saved or not
		$return = $this->encaissement_model->get_paiement_propres_by_sydoniaid($bulletin->Id_0);
		
		if(empty($return))
		{
				$service = $bulletin->Office_6;
				
				$branch_info = $this->branches_model->get_branche_by_dgda_service($service);
			
				if(isset($branch_info[0]->Id_0))
				{
						$_SESSION['Logiref_agence'] = $branch_info[0]->Agence_5;
						$_SESSION['Logiref_guichet'] = $branch_info[0]->Id_0;
				}
				else
				{
						$_SESSION['Logiref_agence'] = 1;
						$_SESSION['Logiref_guichet'] = 62; // Agence SIEGE;
				}

				$agence_src = $bulletin->Agence_32;
				$comptes_array = $this->accounts_model->get_comptes_array("'CGU','CFB', 'TVA', 'FBC', 'CSO' ", $agence_src, NULL);
				
				# First comptabilisation
				if ($bulletin->Designation_23 != "")
					$data['Designation_14'] = $bulletin->Designation_23;
				else
					$data['Designation_14'] = $bulletin->Nif_9;
				$data['Beneficaire_15'] = 'DGDA';
				$data['Agence_20'] = $_SESSION['Logiref_agence'];
				$data['Guichet_21'] = $_SESSION['Logiref_guichet'];
				$data['Mode_19'] = $bulletin->Mode_30;
				$data['Typerecette_17'] = $bulletin->Year_5 . $bulletin->Serie_7 . $bulletin->Number_8;
				$data['Service_16'] = $bulletin->Office_6;
				$data['Devise_34'] = $bulletin->Devise_29;
				$data['Montant_11'] = $bulletin->Amount_12;

				$data['Devise_12'] = 'CDF';
				$data['Compte_33'] = $bulletin->Account_28;
				$data['Noteid_26'] = $bulletin->Year_5 . $bulletin->Serie_7 . $bulletin->Number_8;
				$data['Notedate_27'] = '';

				$data['Commission_23'] = $bulletin->Commission_26;
				$data['Devise_24'] = $bulletin->Devise_27;
				$data['Nif_13'] = $bulletin->Nif_9;

				$instructions = $this->cashcloud_comptabilisation_model->get_instructions_case_2($data, $comptes_array, "DGDA");

				if (!empty($instructions)) {
					# priority for integrating the counting in cbs
					$priority = 1;
					$this->cashcloud_comptabilisation_model->save_instructions($bulletin->Id_0, $data, $instructions, $bulletin->Logirefid_36, $priority);
				}

				$instructions_rec = array();
				$data = array();

				$data = $this->data_model->sydonia_migrate_bl($bulletin->Id_0);
				
				$object = json_encode($data);
				$data = json_decode($object, true);

				$data['Status_2'] = 1;
				$data['Date_1'] = gmdate('Y-m-d H:i:s');
				$data['Account_3'] = $this->session->userdata('account_id');

				$data['Taux_41'] = $bulletin->Taux_31;

				//Formatting amount
				$data['Montant_11'] = $bulletin->Amount_12;
				$data['Notemontant_28'] = $bulletin->Amount_12;

				$data['Guichet_21'] = $bulletin->Agence_32;

				$data['Commission_23'] = $bulletin->Commission_26;

				#Contre valeur en CDF
				$data['Devise_42'] = 'CDF';
				$data['Contrevaleur_22'] = $data['Montant_11'];
				$data['Beneficaire_15'] = 'DGDA';

				$data['Notereference_30'] = json_encode($data['Notereference_30']);
				
				# SAVE PAYMENT

				if (isset($data['total_amount']))
					unset($data['total_amount']);
				if (isset($data['frais_bcc']))
					unset($data['frais_bcc']);
				if (isset($data['CGU']))
					unset($data['CGU']);
				if (isset($data['Total']))
					unset($data['Total']);
				if (isset($data['Reservation_34']))
					unset($data['Reservation_34']);


				$prefix = 1;
				$logirefid = $logiref_id;
				$end_execution = NULL;

				# Comptabilisation
				# Prmiere partie - 
				#SAVE PAYMENT DE CHAQUE TAXE
				#Comptes CGU, CPT & CSO
				$compte_cso = isset($comptes_array['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes_array['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000';
				$compte_cgu = isset($comptes_array['DGDA']['CGU'][$data['Devise_12']]) ? $comptes_array['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
				
				#Taxes comptes
				unset($comptes);
				$comptes = array();
				$agence_src = $bulletin->Agence_32;
				$instructions = array();

				$comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
				
				$type_recettes = $this->logiref_model->get_dropdown("type_recette");
				$beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

				$taxes = array();
				$frais_bcc = 0;

				# For getting taxesPaid as an object
				$return = $this->data_model->sydonia_migrate_bl($bulletin->Id_0);
				$taxesPaid = $return->Notereference_30['taxesPaid'];
			  
				if (is_array($taxesPaid) && count($taxesPaid) > 0) {
					$taxes = $taxesPaid;
				} elseif (is_object($taxesPaid) && $taxesPaid != "") {
					$taxes[] = $taxesPaid;
				}
				
				$frais_bcc = 0;

				foreach ($taxes as $taxe) {
					if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
					{
							$amount = $taxe->taxeAmount * 0.0005;

							$frais_bcc = $amount + $frais_bcc;
					}
				}
				
				$data['frais_bcc'] = $frais_bcc;
				$data['Compte_33'] = $bulletin->Account_28;

				$instruction = $this->cashcloud_comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes_array);
				
				# Frais BCC
				if (!empty($instruction)) {
					# priority for integrating the counting in cbs
					$priority = 1;

					$this->cashcloud_comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instruction, $data['Logirefid_4'], $priority);
				}
				unset($data['frais_bcc']);

				#Serie et numero du bulletin
				$noteid = $data['Typerecette_17'];
				
				foreach ($taxes as $taxe) {
					
					if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) {
						$pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
					} else {
						$pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
					}
				}

				if (!empty($pkeys_tresor)) {
					$pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
					$pkeys_tresor_exist = $this->encaissement_model->check_bulletin_tresor($pkeys_tresor);
					if (!empty($pkeys_tresor_exist)) {
						foreach ($pkeys_tresor_exist as $row) {
							$pkeys_tresor_exist[] = $row->Paiementkey_52;
						}
					}
				}
				if (!empty($pkeys_propre)) {
					$pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
					$pkeys_propre_exist = $this->encaissement_model->check_bulletin_propres($pkeys_propre);
					
					if (!empty($pkeys_propre_exist)) {
						foreach ($pkeys_propre_exist as $row) {
							$pkeys_propre_exist[] = $row->Paiementkey_52;
						}
					}
				}

				$data_tresor = array();
				$data_propre = array();

				foreach ($taxes as $taxe) {
					$data['Logirefid_4'] = $logirefid . '-' . $prefix;
					$data['Contrevaleur_22'] = $taxe->taxeAmount;
					$data['Montant_11'] = $taxe->taxeAmount;
					$data['Typerecette_17'] = $taxe->taxeCode;
					$data['Paiementkey_52'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;

					$pid = "";
					
					if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) {
					   
						if (!in_array($data['Paiementkey_52'], $pkeys_tresor_exist)) {
							
							$data['Tresor_45'] = '1';
							$data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

							$type_rectte = $type_recettes[$taxe->taxeCode];
							
							$data_tresor[] = $data;
							$instructions_recettes = $this->cashcloud_comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cso, $compte_cgu, $type_rectte);
							
							$instructions_rec[] = $instructions_recettes;
						}
					} else if (isset($beneficiaires[$taxe->taxeCode])) {
						
						if (!in_array($data['Paiementkey_52'], $pkeys_propre_exist)) {
							
							$data['Tresor_45'] = '0';
							$data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

							$data_propre[] = $data;
							$instructions_recettes = $this->cashcloud_comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cso, $compte_cgu, "PROPRES");
							
							$instructions_rec[] = $instructions_recettes;
						}
					} else {
					
						if (!in_array($data['Paiementkey_52'], $pkeys_propre_exist)) {
							$data['Missmatch_46'] = 1;
							$data['Tresor_45'] = '0';
							$data['Beneficaire_15'] = $taxe->taxeCode;

							$data_propre[] = $data;
							$instructions_recettes = $this->cashcloud_comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cso, $compte_cgu, "PROPRES");
							$instructions_rec[] = $instructions_recettes;
						}
					}

					$prefix++;
				}
				
				if (!empty($data_tresor)) {
					$return = $this->encaissement_model->save_payment_tresor_dgda($data_tresor, NULL);
				}
				
				if (!empty($data_propre)) {
					$return = $this->encaissement_model->save_payment_propres_dgda($data_propre, NULL);
				} 
				
				if ($return) {
					if (!empty($instructions_rec)) {
						# priority for integrating the counting in cbs
						$priority = 1;

						$end_execution = $this->cashcloud_comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instructions_rec, $logirefid, $priority);
						unset($instructions_rec);
					}

					if ($end_execution) {
						$bl_data['Status_2'] = '2';
						$this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
					}

					return $data['Sydonia_44'];
					
				} else {
					if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) {
						#Payment exist already
						return 'E500';
					} else {
						return 0;
					}
				}
		}
		else
		{
				return 'E500';
		}
    }

    public function validate_breakdown($id) {
		
        $code = '';

        if (isset($id) && $id != "") {
            $bulletin = $this->integration_model->get_paiement_sydonia($id);
            $agence_src = $bulletin->Agence_32;
            $data['Beneficaire_15'] = 'DGDA';
            $data['Sydonia_44'] = $id;
            $data['Account_3'] = $bulletin->Account_3;

            $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
            $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
            # Priority of transactions to send to the API set to 1.
            $data['Priority'] = 1;

            #Invocation of the api transfer
            @set_time_limit(300);

            $response = $this->curl_model->call_bank_virement($data);
            
            $return = json_decode($response, true);
       
            $id = $data['Sydonia_44'];
            $bl = 0;

            if (isset($return['response']) && $return['response'] == "200") {
                $code = 200;

                $paiement = $this->encaissement_model->get_paiement_tresor_bl($id);
                $result = json_decode($paiement->Notereference_30, true);

                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";

                $data_to_validate['Status_2'] = 2;
                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                $data_to_validate['Notereference_30'] = json_encode($result);

                # Update the paiement related to the bulletin
                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                if ($tid) {
                    $bl_data['Status_2'] = '3';
                    $bl = $this->integration_model->update_bulletin($bl_data, $id);
                }

                return $code;
            } elseif (isset($return['response']) && $return['response'] != "") {
                
                $data_to_validate['Status_2'] = 5;
                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                $data_to_validate['Notereference_30'] = json_encode($result);

                # Update the paiement related to the bulletin
                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                $code = $return['response'];

                return $code;
            } else {
                
                $data_to_validate['Status_2'] = 5;
                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                $data_to_validate['Notereference_30'] = json_encode($result);

                # Update the paiement related to the bulletin
                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                return 0;
            }
        }
    }

    public function get_proof_of_payment($id) {
        $user = $this->session->userdata('user_id');
        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
        $encrytions = json_decode($credentials->Password_18);
        #initialisation
        $apidata = array();
        $bl = $id;

        $bulletin = $this->integration_model->get_paiement_sydonia($bl);

        if (isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 != "") {
            $quittance = $bulletin->Pdfcontent_18;
            echo $quittance;
        } else {
            $declaration = json_decode($bulletin->Results_13);
            $apidata['ReceiptSerial'] = $declaration->receiptSerial;
            $apidata['ReceiptNumber'] = $declaration->receiptNumber;
            $apidata['ReceiptDate'] = $declaration->receiptDate;
            $apidata['Office'] = $bulletin->Office_6;
            $apidata['Account'] = $this->session->userdata('account_id');
            $apidata['Paiementid'] = $bl;
            $apidata['User'] = $this->session->userdata('user_id');
            $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
            $apidata['password'] = (isset($encrytions->encryption)) ? $encrytions->encryption : '';
            $apidata['code_bank'] = (isset($encrytions->codebank)) ? $encrytions->codebank : '';

            $response = $this->curl_model->call_dgda_quittance($apidata);

            if ($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000") {
                return $response;
            } else {
                $bulletin = $this->integration_model->get_paiement_sydonia($bl);

                if (isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 != "") {
                    $quittance = $bulletin->Pdfcontent_18;
                    return $quittance;
                } else {
                    return "E406";
                }
            }
        }
    }

    public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) {
        if ($obj == "number_letter") {
            $value = $this->number_letter->converter($data, $arg);

            return $value;
        } elseif ($obj == "paiement_sms") {
            if ($data == 'DGI') {
                $url = $arg;
                $phone = $param;
                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS POUR LA DGI. TELECHARGER LA PREUVE : " . $url;

                $data_to_send = array();
                $data_to_send['message'] = $sms;
                $data_to_send['phone'] = $phone;

                $return = $this->curl_model->call_bank_send_sms($data_to_send);
            } elseif ($data == 'DGRAD') {
                $url = $arg;
                $phone = $param;
                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS POUR LA DGRAD. TELECHARGER LA PREUVE : " . $url;

                $data_to_send = array();
                $data_to_send['message'] = $sms;
                $data_to_send['phone'] = $phone;

                $return = $this->curl_model->call_bank_send_sms($data_to_send);
            } else {
                $url = $arg;
                $phone = $param;
                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS. TELECHARGER LA PREUVE : " . $url;

                $data_to_send = array();
                $data_to_send['message'] = $sms;
                $data_to_send['phone'] = $phone;

                $return = $this->curl_model->call_bank_send_sms($data_to_send);
            }

            return $return;
        }
    }

    public function check_request($regie, $note) {
        $log_request = var_export($note, true);
        $this->save_log($log_request, "make_payment_" . $regie);

        if ($regie == "dgi") {
            if (isset($note->logiref_id) && isset($note->customer_email) && isset($note->customer_msisdn)) {
                return true;
            } else {
                $this->error_message("Failed to read the request, please check your request !");
            }
        } elseif ($regie == "dgda") {
            if (isset($note->logiref_id) && isset($note->customer_email) && isset($note->customer_msisdn)) {
                return true;
            } else {
                $this->error_message("Failed to read the request, please check your request !");
            }
        } elseif ($regie == "dgrad") {
            if (isset($note->logiref_id) && isset($note->customer_email) && isset($note->customer_msisdn)) {
                return true;
            } else {
                $this->error_message("Failed to read the request, please check your request !");
            }
        } elseif ($regie == "dgrk") {
            if (isset($note->logiref_id)) {
                return true;
            } else {
                $this->error_message("Failed to read the request, please check your request !");
            }
        }
    }
}
