<?php
ini_set('display_errors', 0);

/**
 * Description of Middleware
 *
 * @author alvin BM
 */
class Middleware extends REST_Controller{
    
        public $api_key;
        public $api_channel;
        public $token;
        public $key_invalid;
        public $headers;
        public $regies = ["dgi", "dgda", "dgrad", "dgrk"];
        public $params_logireflist = ["service", "taxe", "tax"];
        public $type_compte_by_channel= [
                                            "Telegram"=>"CST", 
                                            "Eazzybiz"=>"CSE"
                                        ];


        public function __construct() 
        {
                parent::__construct();
				
				$request=file_get_contents('php://input');
				$this->save_log($request,"login_plain_request");
				
                $this->allowed_cors();
                $this->load->library('Authorization_Token');
                $this->headers = apache_request_headers();
                $this->api_key =  isset($this->headers['Api-Key']) ? $this->headers['Api-Key'] : "";
                $this->api_channel =  isset($this->headers['Api-Channel']) ? $this->headers['Api-Channel'] : "";
                $this->token = isset($this->headers['token']) ? $this->headers['token'] : "";
                //$this->verify_apikey();
                
                //Charge requiered models
                $this->load->model('MY_Main');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('main/main_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model('api/fees_model');
                $this->load->model('api/users_model');
                $this->load->model('api/curl_model');
                $this->load->model('api/integration_model');
                $this->load->model('api/comptabilisation_model');
                $this->load->model('api/accounts_model');
                $this->load->model('api/branches_model');
                $this->load->model('api/encaissement_model');
                $this->load->model('api/data_model');
                $this->load->model('api/dgrk_model');
                
                $this->verify_token();
                
                $this->load->library('m_pdf');
                $this->load->library('ciqrcode');
        }
        
        public function verify_apikey() {
            
                if (!isset($this->api_channel) or !in_array($this->api_channel, REST_Controller::CHANNEL_AUTHORIZED)) {
                        
                        $data = [
                                "code" => REST_Controller::HTTP_NOT_ACCEPTABLE,
                                "status" => "failed",
                                "description" => "You do not have permission to access this resource",
                                "line" => 0,
                                "data" => null
                        ];
                        
                        header("HTTP/1.1 ".REST_Controller::HTTP_OK);
                        header('Content-Type: application/json');
                        echo json_encode($data);
                        die;
                }
                else
                {
                        $channels = REST_Controller::API_CHANNEL;
                        
                        if($channels[$this->api_channel] != $this->api_key)
                        {
                                $data = [
                                "code" => REST_Controller::HTTP_NOT_ACCEPTABLE,
                                "status" => "failed",
                                "description" => "The api-key value entered is not correct",
                                "line" => 0,
                                "data" => null
                        ];
                        
                        header("HTTP/1.1 ".REST_Controller::HTTP_OK);
                        header('Content-Type: application/json');
                        echo json_encode($data);
                        die;
                        }
                }
        }
        
        public function verify_token() 
        {
                if($_SERVER['PATH_INFO'] != "/api/v1/auth/login")
                {
                        $tokenData = $this->authorization_token->validateToken();
                        if($tokenData['status'] == false )
                        {
                                $data = [
                                        "code" => REST_Controller::HTTP_NOT_ACCEPTABLE,
                                        "status" => "error",
                                        "description" => "Token erreur : " . $tokenData["message"], //"Le token est invalide ou il a expiré, Veuillez vous reconnecter svp!",
                                        "line" => 0,
                                        "data" => null
                                ];
                                header("HTTP/1.1 ".REST_Controller::HTTP_OK);
                                header('Content-Type: application/json');
                                echo json_encode($data);
                                die;
                        }else{
                                $user = $this->main_model->get_profile_infos($tokenData['data']->user_id);
                                $this->main_model->init_sessions($user);
                        }
                        
                        
                }
        }
        
        public function set_token($token_data) {
            return $this->authorization_token->generateToken($token_data);
        }
        
        private function allowed_cors()
        {
                // Allow from any origin
                header("Access-Control-Allow-Origin: *");
                header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, HEAD, OPTIONS");
                header('Access-Control-Allow-Headers: append, delete, entries, foreach, get, has, keys, set, values, Content-Type, Authorization, X-Requested-With, api_key');
                header('Access-Control-Allow-Credentials: true');
                header('Access-Control-Max-Age: 86400');    // cache for 1 day
                header('Content-Type:Application/json,charset=UTF-8');

                // Access-Control headers are received during OPTIONS requests
                if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
                    //echo "cool";
                    // may also be using PUT, PATCH, HEAD etc
                    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
                        header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, HEAD, OPTIONS");

                    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADskyERS']))
                        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

                    exit(0);
                }
        }
        
        public function save_log($data, $name="default",$folder="eazzybiz")
        {
                $name = gmdate('Y-m-d')."_".$name;
                $path = "./drive/logs/".$folder;
                
                if (is_dir($path)==false)
                {
                        mkdir($path,0777,true);
                }
                
                $path = $path."/".$name;
                $handle = fopen($path.".logs", 'a+');
                $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                fwrite($handle, $data."\n\n");   
                fclose($handle);	
        }
}
