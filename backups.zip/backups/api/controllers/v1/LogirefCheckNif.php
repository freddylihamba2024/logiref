<?php
require  'Middleware.php';
/**
 * Description of LogirefCheckNif
 * This endpoint makes it possible to retrieve the customer's information from his tax number.
 * @author alvin Bauma
 */
class LogirefCheckNif extends Middleware {

    public function __construct() 
    {
            parent::__construct();
    }
    
    
    public function index_get() 
    {
            $nif = $this->input->get("nif");
            
            if (!empty($nif))
            {
                    $this->get_nif($nif);
            }
            else
            {
                    $this->error_message("Impossible de récuperer les informations. Le NIF n'est pas renseigné");
            }
        
    }


    
    private function get_nif($nif) 
    {
            $client =  $this->logiref_model->get_clients_by_nif($nif);
            if($client)
            {
                
                    $data_client = new stdClass();
                    $data_client->nif = $client->Nif_4;
                    $data_client->designation = $client->Designation_5;
                    $data_client->phone = $client->Phone_6;
                    $data_client->email = $client->Email_7;
                    $data_client->name = $client->Name_8;

                    //######## NIF retrieved Code 200 ###########
                    $data = [
                            "code" => REST_Controller::HTTP_OK,
                            "description" => "success",
                            "line" => 1,
                            "data" => [
                                "client" => $data_client,
                            ]
                    ];
                    $this->response($data, REST_Controller::HTTP_OK);
            }
            else
            {
                    $this->error_message("Impossible de récuperer les informations. le NIF renseigné n'est pas correct");
            }
    }
}
