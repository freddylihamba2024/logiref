<?php

require 'Middleware.php';

class LogirefMakePaymentPassport extends Middleware
{
        public function __construct()
        {
                parent::__construct();
        } 
        
        public function index_post()
        {
                $request = json_decode(file_get_contents('php://input'));
              
                if($request)
                {
                        //Cybercource payment modes
                        if(isset($request->payment_mode) && $request->payment_mode == 'Card')
                        {
                                        $return = $this->check_request_payment_card($request);
                        }
                        //Agency Banking (PWE) payment modes
                        elseif(isset($request->payment_mode) && in_array($request->payment_mode,['MOBILE','WEB','POS','USSD']))
                        {
                                        $return = $this->check_request_payment_agency_banking($request);
                        }
                        //Proxypay payment modes
                        else
                        {
                                        $return = $this->check_request($request);
                        }
                       
                        if($return)
                        {
                                        $this->post_note_passport($request->logiref_id,$request->note_number,$request->payment_number,$request->currency,$request->amount,$request->exchange_rate,$request->bank_code,$request->agency_code,$request->agency,$request->reference,$request->date_trans,$request->payment_mode,$request->proxypay_ref);
                        }
                        else
                        {
                                $this->error_message("Failed to read the request, please check your request !",400,"confirm_passport_error");
                        }
                }
                else 
                {
                        $this->error_message("No document related to this information was found, No parameter getted",400,"confirm_passport_error");
                }
        }
        
        public function post_note_passport($logiref_id,$note_number,$payment_number,$currency,$amount,$exchange_rate,$bank_code,$agency_code,$agency,$reference_trans,$dateTrans,$payment_mode,$proxypay_ref,$customer_email=NULL,$customer_number=NULL)
        {
                $date = new DateTime($dateTrans);
                $dateTrans = $date->format('d-m-Y');
				
                # Appel du paiement par son logirefid
                $paiement = $this->encaissement_model->get_paiement_by_logirefid($logiref_id);
				
				# Verification of the finacle transaction
				$request_data = array();
				
				
				$instructions_to_update=$this->comptabilisation_model->get_instructions_dgrad($logiref_id);
		
				if($payment_mode == 'Card')
				{
						$result = array();
						$result['Status'] = "SUCCESS";

                                                //payment mode channel or provider
						$data_to_update['Channel_58']="Cybersource";
						$data_to_update['Paymentmode_56']=9;
				}
				elseif($payment_mode == 'MobileMoney')
				{
						$request_data['Reference_32'] = $reference_trans;
						$request_data['transDate'] = $dateTrans;
						$request_data['Compte_33'] = $paiement->Compte_33;
						
						$return = $this->curl_model->call_bank_trans_details($request_data);
						$result = json_decode($return, true);

                                                //payment mode channel or provider
						$data_to_update['Channel_58']="Proxypay";
						$data_to_update['Paymentmode_56']=8;
				}
				elseif(in_array($payment_mode,['MOBILE','WEB','POS','USSD']))
				{
						$request_data['Reference_32'] = $proxypay_ref;
						$request_data['transDate'] = $dateTrans;
						$request_data['Compte_33'] = $paiement->Compte_33;
						
						$return = $this->curl_model->call_bank_trans_details_rrn($request_data);
						var_dump($return);die;
						
						$result = json_decode($return, true);
						
						//$result['Status'] = "SUCCESS";
                                                 
						//payment mode channel or provider
						$data_to_update['Channel_58']="AgencyBanking";
						
						if($payment_mode=="MOBILE")
						{
								$data_to_update['Paymentmode_56']=10;
						}
						elseif($payment_mode=="WEB")
						{
								$data_to_update['Paymentmode_56']=11;
						}
						elseif($payment_mode=="POS")
						{
								$data_to_update['Paymentmode_56']=12;
						}
						elseif($payment_mode=="USSD")
						{
								$data_to_update['Paymentmode_56']=13;
						}
				}
				
				$this->encaissement_model->update_payment_tresor_by_ref($data_to_update,$logiref_id);
				
				if(isset($result['Status']) && $result['Status'] == "SUCCESS")
				{
						$reference = isset($paiement->Noteid_26) ? $paiement->Noteid_26 : "";
                                                
						$commission=0;
						$vat=0;
						$commission_details=array();
						
						
					
						if(isset($paiement->Commission_details_60) && $paiement->Commission_details_60!=NULL)
						{
								$commissions= json_decode($paiement->Commission_details_60,true);
								$commission_details['BankCommission']= $commissions['ComAgencyBanking_CFP'];
								$commission_details['MerchantCommission']= $commissions['ComAgencyBanking_CMP'];
						}

						if ($paiement->Checkerid_10 != 0 && $paiement->Status_2 !=0 ) 
						{
								$taux = $paiement->Taux_41;
								$frais_bbc = 0;

								
								if($paiement->Devise_24 == 'CDF') 
								{
										$tva = $paiement->Commission_23 * 0.16;
										$vat=round($tva,2);
										$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc;
										$total = $total/$taux;
										$paiement->Commission_23 = $paiement->Commission_23/$taux;
								}
								else
								{
										$tva = $paiement->Commission_23 * 0.16;
										$vat=round($tva,2);
										$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $vat;
								}
								
								$commission_array = array();
								$commission_array['amount'] = $paiement->Commission_23;
								$commission_array['currency'] = $paiement->Devise_24;

									
								$note_exist = $this->integration_model->get_note_by_ref($reference);
								$note_details = json_decode($note_exist->Result_8);
																										
								$not_details = new stdClass();
								$not_details->tax_number = $note_details->logiradData->numeroNotePerception;
								$not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
								$not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
								$not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
								$not_details->designation = $note_details->logiradData->detailAssujetti->designation;
								
								######## Payment was made successfully ###########
								$return = new stdClass();
								$return->logiref_id = $logiref_id;
								$return->note_amount = $paiement->Montant_11;
								$return->currency=$paiement->Devise_12;
								$return->commission = floatval($paiement->Commission_23);
								$return->commision_details=$commission_details;
								$return->vat =$vat;
								//$return->bcc_fees = round($frais_bbc,2);
								$return->total_amount = round($total,0);
								$return->exchange_rate=$paiement->Taux_41;
								$return->compte_gl = $paiement->Compte_33;
								$return->dec_details= $not_details;
								/* $return->proof = ''; */
								
								$data = [
									"code" => '202',
									"status" => "paid",
									"message" => "Declaration is already paid.",
									"data" => $return
								];

								

								$this->response($data, REST_Controller::HTTP_OK);
								
								$log_response = var_export($data, true);
								$this->save_log($log_response,"confirm_passport");
						} 
						elseif (isset($paiement->Montant_11)) 
						{
								
								$confirmation_data['note_number']=$note_number;
								$confirmation_data['payement_number']=$payment_number;
								$confirmation_data['currency']=$currency;
								$confirmation_data['amount']=$amount;
								$confirmation_data['exchange_rate']=$exchange_rate;
								$confirmation_data['bank_code']=$bank_code;
								$confirmation_data['agency_code']=$agency_code;
								$confirmation_data['agency']=$agency;
								$confirmation_data['reference']=$reference;
								$confirmation_data['dateTrans']=$dateTrans;
								$confirmation_data['payment_mode']=$payment_mode;
								$confirmation_data['proxypay_ref']=$proxypay_ref;
								
								
								$result = $this->make_validation_dgrad($paiement,$confirmation_data, $customer_email, $customer_number, $instructions_to_update);
				   
								$result = json_decode($result, true);

								if (isset($result['code_transaction']) && $result['code_transaction'] == 200) 
								{
										
										if (isset($result['code_transaction']) && $result['code_transaction'] == 200 && isset($result['code_email']) && $result['code_email'] == 200) 
										{
											
												$taux = $paiement->Taux_41;
												$frais_bbc = 0;
												
												
												
												if($paiement->Devise_24 == 'CDF') 
												{
														$tva = $paiement->Commission_23 * 0.16;
														$vat=round($tva,2);
														$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc;
														$total = $total/$taux;
														$paiement->Commission_23 = $paiement->Commission_23/$taux;
												}
												else
												{
														$tva = $paiement->Commission_23 * 0.16;
														$vat=round($tva,2);
														$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $vat;
												}

												$commission_array = array();
												$commission_array['amount'] = $paiement->Commission_23;
												$commission_array['currency'] = $paiement->Devise_24;
												
												
												$note_exist = $this->integration_model->get_note_by_ref($reference);
												$note_details = json_decode($note_exist->Result_8);
																													
												$not_details = new stdClass();
												$not_details->tax_number = $note_details->logiradData->numeroNotePerception;
												$not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
												$not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
												$not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
												$not_details->designation = $note_details->logiradData->detailAssujetti->designation;
											
												######## Payment was made successfully ###########
												$return = new stdClass();
												
												$proof = new stdClass();
												$return->logiref_id = $logiref_id;
												$return->note_amount = $paiement->Montant_11;
												$return->currency = $currency;
												$return->commission = floatval($paiement->Commission_23);
												$return->commision_details=$commission_details;
												$return->vat =$vat;
												//$return->bcc_fees = round($frais_bbc,2);
												$return->total_amount =round($total,0);
												$return->exchange_rate=$paiement->Taux_41;
												$return->compte_gl = $paiement->Compte_33;
												$return->dec_details = $not_details;
												
												/* $proof->code = 200;
												$proof->message = 'The proof was sent successfully to the customer by email'; */

												$data = [
													"code" => REST_Controller::HTTP_OK,
													"status" => "paid",
													"message" => "Declaration was paid successfully.",
													"data" => $return
												];

												$this->response($data, REST_Controller::HTTP_OK);
												
												$log_response = var_export($data, true);
												$this->save_log($log_response,"confirm_passport");
										} 
										else 
										{
												$taux = $paiement->Taux_41;
												$frais_bbc = 0;
												
												if($paiement->Devise_24 == 'CDF') 
												{
														$tva = $paiement->Commission_23 * $vat;
														$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc;
														$total = $total/$taux;
														$paiement->Commission_23 = $paiement->Commission_23/$taux;
												}
												else
												{
														$tva = $paiement->Commission_23 * 0.16;
														$total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $vat;
												}

												$commission_array = array();
												$commission_array['amount'] = $paiement->Commission_23;
												$commission_array['currency'] = $paiement->Devise_24;
												
												
												$note_exist = $this->integration_model->get_note_by_ref($reference);
												$note_details = json_decode($note_exist->Result_8);
																													
												$not_details = new stdClass();
												$not_details->tax_number = $note_details->logiradData->numeroNotePerception;
												$not_details->recipe = $note_details->logiradData->detailTaxation->codeArticleBudgetaire;
												$not_details->recipe_description = $note_details->logiradData->detailTaxation->libelleArticleBudgetaire;
												$not_details->tax_payer = $note_details->logiradData->detailAssujetti->numeroImpot;
												$not_details->designation = $note_details->logiradData->detailAssujetti->designation;
											
												######## Payment was made successfully ###########
												$return = new stdClass();
												
												$proof = new stdClass();
												$return->logiref_id = $logiref_id;
												$return->note_amount = $paiement->Montant_11;
												$return->currency = $currency;
												$return->commission = $paiement->Commission_23;
												$return->commision_details=$commission_details;
												$return->vat =$vat;
												//$return->bcc_fees = round($frais_bbc,2);
												$return->total_amount =round($total,0);
												$return->exchange_rate=$paiement->Taux_41;
												$return->compte_gl = $paiement->Compte_33;
												$return->dec_details = $not_details;
												
											/*     $proof->code = 300;
												$proof->message = 'The proof was not sent to the customer'; */

												$data = [
													"code" => REST_Controller::HTTP_OK,
													"status" => "paid",
													"message" => "Declaration was paid successfully.",
													"data" => $return
												];

												$this->response($data, REST_Controller::HTTP_OK);
												
												$log_response = var_export($data, true);
												$this->save_log($log_response,"confirm_passport");
										}
								} 
								else 
								{
										######## Payment failed ###########
										$return = new stdClass();
										$return->logiref_id = $logiref_id;

										$data = [
											"code" => 300,
											"status" => "failed",
											"message" => "The note has not been validated, an error occured while the integration of transactions in Finacle.",
											"data" => null,
											"proof" => null
										];

										$this->response($data, 300);
										
										$log_response = var_export($data, true);
										$this->save_log($log_response,"confirm_passport");
								}
						} 
						else 
						{
								$this->error_message("No declaration found for logirefid " . $logiref_id . " ", 307,"confirm_passport_error");
						}	
				}					
				else 
				{
						$this->error_message("The transaction reference " . $reference_trans . " entered was not found in Finacle", 309,"confirm_passport_error");
				}
		}
        
        public function make_validation_dgrad($paiement,$confirmation_data, $customer_email, $customer_number, $instructions_to_update) 
        {
                $_SESSION['Logiref_groupe'] = 'banks';
                $data_to_update['Status_2'] = 5;
				
				$mail_type=null;

                $this->encaissement_model->update_payment_tresor($data_to_update, $paiement->Logirefid_4);

                $infos = json_decode($paiement->Notereference_30, true);

                $data['Beneficaire_15'] = 'DGRAD';
				
                $data['Logirefid_4'] = $paiement->Logirefid_4;
                $data['Account_3'] = $paiement->Account_3;
                $data['Id_0'] = $paiement->Id_0;

				
                $data['Trans']='firstTrans';
                $data['Priority_27']=0;
                
                $data_to_update_libelle = array();
                $payment_mode = 0;
				
				# Check the value of payment_mode in the request
				if($confirmation_data['payment_mode'] == 'Card')
				{
						$payment_mode = 9;
						$mail_type="online";
				}
				elseif(in_array($confirmation_data['payment_mode'],['MOBILE','WEB','POS','USSD']))
				{
												$mail_type="AgencyBanking";
                                                //payment mode channel or provider
                                                if($confirmation_data['payment_mode']=="MOBILE")
                                                {
                                                        $payment_mode = 10;
                                                }
                                                elseif($confirmation_data['payment_mode']=="WEB")
                                                {
                                                        $payment_mode=11;
                                                }
                                                elseif($confirmation_data['payment_mode']=="POS")
                                                {
                                                        $payment_mode=12;
                                                }
                                                elseif($confirmation_data['payment_mode']=="USSD")
                                                {
                                                        $payment_mode=13;
                                                }
				}
				else
				{
						$payment_mode = 8;
						$mail_type="online";
				}
				
			
				
				foreach($instructions_to_update as $line)
				{
						if($payment_mode == '8')
						{
								$id_update = $line->Id_0;
								$libelle_update = $line->Libelle_12."M_".$paiement->Noteid_26."_".$confirmation_data['proxypay_ref']."_".$paiement->Designation_14;
								
								$data_to_update_libelle['Libelle_12'] = $libelle_update;
								$data_to_update_libelle['Mode_15'] = $payment_mode;
								$this->comptabilisation_model->update_instructions_dgrad_by_id($id_update,$data_to_update_libelle);
						}
						elseif(in_array($payment_mode,['10','11','12','13']))
						{
								$id_update = $line->Id_0;
								$libelle_update = $line->Libelle_12."A_".$paiement->Noteid_26."_".$paiement->Designation_14;
								
								$data_to_update_libelle['Libelle_12'] = $libelle_update;
								$data_to_update_libelle['Mode_15'] = $payment_mode;
								$this->comptabilisation_model->update_instructions_dgrad_by_id($id_update,$data_to_update_libelle);
						}
						else
						{
								$id_update = $line->Id_0;
								$libelle_update = $line->Libelle_12."C_".$paiement->Noteid_26."_".$confirmation_data['proxypay_ref']."_".$paiement->Designation_14;
								
								$data_to_update_libelle['Libelle_12'] = $libelle_update;
								$data_to_update_libelle['Mode_15'] = $payment_mode;
								$this->comptabilisation_model->update_instructions_dgrad_by_id($id_update,$data_to_update_libelle);
						}
				}
				
				if(!in_array($payment_mode,['10','11','12','13']))
				{
						# Constructing new commission data to update
						$id_commission=$instructions_to_update[1]->Id_0;
						$data_to_update_commission['Compte_13']=$this->data('get_account_commission',$payment_mode);
						
						$data_to_update_commission['Mode_15']= $payment_mode;
						
						$this->comptabilisation_model->update_instructions_dgrad_by_id($id_commission,$data_to_update_commission);
				}
				
					
				$response = $this->curl_model->call_bank_virement_passport_online($data);
                $return = json_decode($response, true);
				//$return['response']='200';
				
                if (isset($return['response']) && $return['response'] == '200') 
                {
						$data['Trans']='secondTrans';
						$data['Priority_27']=1;
						
						$data_to_update['Id_0'] = $paiement->Id_0;
						$data_to_update['Logirefid_4'] =$paiement->Logirefid_4;
						$data_to_update['Status_2'] = 6;
						$data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
						$data_to_update['Validation_36 '] = gmdate('Y-m-d H:i:s');

						$this->encaissement_model->update_payment_tresor_by_ref($data_to_update, $paiement->Logirefid_4);
						
						$response_transact_2=$this->curl_model->call_bank_virement_passport_online($data);
                        
						$return_transact_2 = json_decode($response_transact_2, true);
						
						//$return_transact_2['response'] ='200';
						
						if(isset($return_transact_2['response']) && $return_transact_2['response']=='200')
						{
							
							
							$data['Status_2'] = 7;
							$data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
							$data_to_update['Validation_36 '] = gmdate('Y-m-d H:i:s');

							$this->encaissement_model->update_payment_tresor_by_ref($data_to_update, $paiement->Logirefid_4);
							
							$response_confirmation=$this->curl_model->call_dgrad_confirm_passport_online($confirmation_data);
							 /* var_dump($response);die; */
							//$return_confirmation = json_decode($response_confirmation, true);
							//$response_confirmation = "E200";
							
						if(isset($response_confirmation) && ($response_confirmation == "E200" || $response_confirmation == "CP200"))
						{
									
                                $result = json_decode($paiement->Notereference_30, true);

                                foreach ($return as $row) 
                                {
                                        $result['Num_evenement'] = isset($row['Num_evenement']) ? $row['Num_evenement'] : '';
                                        break;
                                }

                                $logirefid = $data['Logirefid_4'];

                                $data = array();

                                $data['Notereference_30'] = json_encode($result);
                                $data['Id_0'] = $paiement->Id_0;
                                $data['Logirefid_4'] = $paiement->Logirefid_4;
                                $data['Status_2'] = 2;
                                $data['Checkerid_10'] = $this->session->userdata("user_id");
                                $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

                                # now pass the data
                                $this->data['typeDoc'] = $this->logiref_model->documents;
                                $this->data['devises'] = $this->logiref_model->devises;
                                $this->data['modes'] = $this->logiref_model->modes;
                                $this->data['months'] = $this->comptabilisation_model->months;
                                $this->data['users'] = $this->main_model->get_dropdown('users');
								$this->data['logo'] = $this->imageToBase64();
								
                                $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

								//Generate unique number for the attestation
								$num = $encaissement->Id_0 + 1;
								$this->data['numero']="N".str_pad($num,8,"0",STR_PAD_LEFT);

                                # Suite numerique
                                if ($id != '') 
                                {
                                        $number = '';
                                        $nb = strlen($id);

                                        $iteration = 10 - $nb;

                                        for ($i = 1; $i <= $iteration; $i++) 
                                        {
                                                $number .= '0';
                                        }
                                        $number = $number . $id;

                                        $this->data['number'] = $number;
                                }

                                $guichets = $this->branches_model->get_dropdown("guichets");
                                $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
                                $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                                $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                                $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
                                $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';
                                $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                                $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);
                                $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");
                                # Display the amaount in letter
                                $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

                                # Treatment of information returned by the CBS
                                $cbs_return = $this->integration_model->get_cbs_returns($id);
                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") 
                                {
                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                        $this->data['cbs_return'] = $cbs_return;
                                }
                                $infos = json_decode($encaissement->Notereference_30, true);
                                $date = explode('/', $infos["standard"]);

                                if (count($date) == 3) 
                                {
                                        $periode_mois = $date[1];
                                        $periode_annee = $date[0];
                                } 
                                elseif (count($date) == 2) 
                                {
                                        $periode_mois = $date[0];
                                        $periode_annee = $date[1];
                                } 
                                else 
                                {
                                        $periode_mois = "";
                                        $periode_annee = "";
                                }

                                # creation de qrcode
                                $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
								
                                if (is_dir($dir) == false) 
                                {
                                        mkdir($dir, 0777, true);
                                }
                                $checkerid = $this->data['encaissement']->Checkerid_10;

                                $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
                                $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

                                $param ['banque'] = $this->session->userdata('account_id');
                                if (isset($cbs_return["Num_evenement"]))
                                {
                                        $param ['identifiant'] = $cbs_return["Num_evenement"];
                                } 
                                else 
                                {
                                        $param ['identifiant'] = NULL;
                                }

                                $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
                                $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['designation'] = $this->data['encaissement']->Designation_14;
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") 
                                {
                                        $param ['referencenote'] = NULL;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                                        $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                                        $param['articlebudgetaire'] = NULL;
                                }
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") 
                                {
                                        $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                                        $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                                        $param['motif_de_paiement'] = NULL;
                                }

                                $params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
								//$params['data'] = json_encode($param);
								$params['level'] = 'L';
								$params['size'] = '4';
								$this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

								$this->ciqrcode->generate($params);

                                $service_type = $this->logiref_model->get_dropdown("type_services");

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27421600") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_passport', $this->data, true);
                                }

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27022470") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_taxegardienage', $this->data, true);
                                }

                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');
                                $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

                                # actually, you can pass mPDF parameter on this load() function
                                $pdf = $this->m_pdf->load();
                                $pdf->WriteHTML('', 1);
                                $pdf->WriteHTML($html, 2);

                                $pdf->Output($pdfFilePath, "F");

                                $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

                                $customer = isset($designation) ? $designation : "Customer";

                                $mail_data['designation']=$paiement->Designation_14;
                                $mail_data['email']=(!isset($customer_email))?$paiement->Email_54:$customer_email;
								//$mail_data['email']="freddylihamba.dev@gmail.com";
                                $mail_data['telephone']=(!isset($customer_number))?$paiement->Msisdn_55:$customer_number;
								
								$tva=$paiement->Commission_23 * 0.16;
								$total_commission=$paiement->Commission_23 + $tva;
								
								$mail_data['commission']=$total_commission;
                                $mail_data['amount']=$paiement->Montant_11;
                                $mail_data['currency']=$paiement->Devise_12;
                                $mail_data['attachement']= $pdfFilePath;
								$mail_data['mode']= $mail_type;
								$mail_data['commission_in_letter']= $this->data('number_letter', round($total_commission,0), $paiement->Devise_12);


                                $return = $this->mail->mail_send_proof($mail_data['email'],$mail_data['designation'],'fr',$mail_data['attachement'],'DGRAD_PASSPORT',$mail_data['amount'],$mail_data['currency'], $paiement->Noteid_26,$mail_data);

                                if ($return == true) 
                                {
                                        $function_return['code_email'] = 200;
                                        $function_return['code_transaction'] = 200;
                                } 
                                else 
                                {
                                        $function_return['code_email'] = 300;
                                        $function_return['code_transaction'] = 200;
                                }
                        }
						else
						{
								$logirefid = $data['Logirefid_4'];

								$data = array();

								$data['Notereference_30'] = json_encode($result);
								$data['Id_0'] = $paiement->Id_0;
								$data['Logirefid_4'] = $logirefid;
								$data['Status_2'] = 7;
								$data['Checkerid_10'] = $this->session->userdata("user_id");
								$data['Validation_36'] = gmdate('Y-m-d H:i:s');

								$this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

								# now pass the data
                                $this->data['typeDoc'] = $this->logiref_model->documents;
                                $this->data['devises'] = $this->logiref_model->devises;
                                $this->data['modes'] = $this->logiref_model->modes;
                                $this->data['months'] = $this->comptabilisation_model->months;
                                $this->data['users'] = $this->main_model->get_dropdown('users');
								$this->data['logo'] = $this->imageToBase64();
								
                                $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

								//Generate unique number for the attestation
								$num = $encaissement->Id_0 + 1;
								$this->data['numero']="N".str_pad($num,8,"0",STR_PAD_LEFT);

                                # Suite numerique
                                if ($id != '') 
                                {
                                        $number = '';
                                        $nb = strlen($id);

                                        $iteration = 10 - $nb;

                                        for ($i = 1; $i <= $iteration; $i++) 
                                        {
                                                $number .= '0';
                                        }
                                        $number = $number . $id;

                                        $this->data['number'] = $number;
                                }

                                $guichets = $this->branches_model->get_dropdown("guichets");
                                $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
                                $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                                $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                                $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
                                $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';
                                $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                                $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);
                                $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");
                                # Display the amaount in letter
                                $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

                                # Treatment of information returned by the CBS
                                $cbs_return = $this->integration_model->get_cbs_returns($id);
                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") 
                                {
                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                        $this->data['cbs_return'] = $cbs_return;
                                }
                                $infos = json_decode($encaissement->Notereference_30, true);
                                $date = explode('/', $infos["standard"]);

                                if (count($date) == 3) 
                                {
                                        $periode_mois = $date[1];
                                        $periode_annee = $date[0];
                                } 
                                elseif (count($date) == 2) 
                                {
                                        $periode_mois = $date[0];
                                        $periode_annee = $date[1];
                                } 
                                else 
                                {
                                        $periode_mois = "";
                                        $periode_annee = "";
                                }

                                # creation de qrcode
                                $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
								
                                if (is_dir($dir) == false) 
                                {
                                        mkdir($dir, 0777, true);
                                }
                                $checkerid = $this->data['encaissement']->Checkerid_10;

                                $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
                                $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

                                $param ['banque'] = $this->session->userdata('account_id');
                                if (isset($cbs_return["Num_evenement"]))
                                {
                                        $param ['identifiant'] = $cbs_return["Num_evenement"];
                                } 
                                else 
                                {
                                        $param ['identifiant'] = NULL;
                                }

                                $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
                                $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['designation'] = $this->data['encaissement']->Designation_14;
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") 
                                {
                                        $param ['referencenote'] = NULL;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                                        $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                                        $param['articlebudgetaire'] = NULL;
                                }
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") 
                                {
                                        $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                                        $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                                        $param['motif_de_paiement'] = NULL;
                                }

                                $params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
								//$params['data'] = json_encode($param);
								$params['level'] = 'L';
								$params['size'] = '4';
								$this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

								$this->ciqrcode->generate($params);

                                $service_type = $this->logiref_model->get_dropdown("type_services");

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27421600") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_passport', $this->data, true);
                                }

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27022470") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_taxegardienage', $this->data, true);
                                }

                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');
                                $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

                                # actually, you can pass mPDF parameter on this load() function
                                $pdf = $this->m_pdf->load();
                                $pdf->WriteHTML('', 1);
                                $pdf->WriteHTML($html, 2);

                                $pdf->Output($pdfFilePath, "F");

                                $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

                                $customer = isset($designation) ? $designation : "Customer";

                                $mail_data['designation']=$paiement->Designation_14;
                                $mail_data['email']=(!isset($customer_email))?$paiement->Email_54:$customer_email;
								//$mail_data['email']="freddylihamba.dev@gmail.com";
                                $mail_data['telephone']=(!isset($customer_number))?$paiement->Msisdn_55:$customer_number;
								
								$tva=$paiement->Commission_23 * 0.16;
								$total_commission=$paiement->Commission_23 + $tva;
								
								$mail_data['commission']=$total_commission;
                                $mail_data['amount']=$paiement->Montant_11;
                                $mail_data['currency']=$paiement->Devise_12;
                                $mail_data['attachement']= $pdfFilePath;
								$mail_data['mode']= $mail_type;
								$mail_data['commission_in_letter']= $this->data('number_letter', round($total_commission,0), $paiement->Devise_12);

                                $return = $this->mail->mail_send_proof($mail_data['email'],$mail_data['designation'],'fr',$mail_data['attachement'],'DGRAD_PASSPORT',$mail_data['amount'],$mail_data['currency'], $paiement->Noteid_26,$mail_data);

                                if ($return == true) 
                                {
                                        $function_return['code_email'] = 200;
                                        $function_return['code_transaction'] = 200;
                                } 
                                else 
                                {
                                        $function_return['code_email'] = 300;
                                        $function_return['code_transaction'] = 200;
                                }
						}
                        
                        
     /*                    return json_encode($function_return); */
                        
							
					}
					else
					{
							// Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
							$this->integration_model->update_integration_dgrad_attempts($paiement->Id_0, 1);
					}
						
                       
                } 
                else 
                {
						
                        $logirefid = $data['Logirefid_4'];

                        $data = array();

                        $data['Notereference_30'] = json_encode($result);
                        $data['Id_0'] = $paiement->Id_0;
                        $data['Logirefid_4'] = $logirefid;
                        $data['Status_2'] = 5;
                       // $data['Checkerid_10'] = $this->session->userdata("user_id");
                       // $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                        $this->encaissement_model->update_payment_tresor_by_ref($data, $logirefid);

						// Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
						$this->integration_model->update_integration_dgrad_attempts($paiement->Id_0, 0);

                        # now pass the data
                                $this->data['typeDoc'] = $this->logiref_model->documents;
                                $this->data['devises'] = $this->logiref_model->devises;
                                $this->data['modes'] = $this->logiref_model->modes;
                                $this->data['months'] = $this->comptabilisation_model->months;
                                $this->data['users'] = $this->main_model->get_dropdown('users');
								$this->data['logo'] = $this->imageToBase64();
								
                                $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_by_logirefid($logirefid);

								//Generate unique number for the attestation
								$num = $encaissement->Id_0 + 1;
								$this->data['numero']="N".str_pad($num,8,"0",STR_PAD_LEFT);

                                # Suite numerique
                                if ($id != '') 
                                {
                                        $number = '';
                                        $nb = strlen($id);

                                        $iteration = 10 - $nb;

                                        for ($i = 1; $i <= $iteration; $i++) 
                                        {
                                                $number .= '0';
                                        }
                                        $number = $number . $id;

                                        $this->data['number'] = $number;
                                }

                                $guichets = $this->branches_model->get_dropdown("guichets");
                                $users = $this->data['users'] = $this->main_model->get_dropdown('users_array');
                                $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                                $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                                $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL) ? $guichet->Ville_7 : '...................';
                                $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL) ? $agence->Nom_4 : '...................';
                                $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                                $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province = NULL, true);
                                $bureau = $this->data['bureau'] = $this->logiref_model->get_dropdown("services");
                                # Display the amaount in letter
                                $this->data['number_letter'] = $this->data('number_letter', $encaissement->Montant_11, $encaissement->Devise_12);

                                # Treatment of information returned by the CBS
                                $cbs_return = $this->integration_model->get_cbs_returns($id);
                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") 
                                {
                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                        $this->data['cbs_return'] = $cbs_return;
                                }
                                $infos = json_decode($encaissement->Notereference_30, true);
                                $date = explode('/', $infos["standard"]);

                                if (count($date) == 3) 
                                {
                                        $periode_mois = $date[1];
                                        $periode_annee = $date[0];
                                } 
                                elseif (count($date) == 2) 
                                {
                                        $periode_mois = $date[0];
                                        $periode_annee = $date[1];
                                } 
                                else 
                                {
                                        $periode_mois = "";
                                        $periode_annee = "";
                                }

                                # creation de qrcode
                                $dir = "./drive/logiref/" . $this->session->userdata('account_id') . "/" . $this->session->userdata('user_id') . "/" . $beneficiaires['Regies'][$encaissement->Beneficaire_15];
								
                                if (is_dir($dir) == false) 
                                {
                                        mkdir($dir, 0777, true);
                                }
                                $checkerid = $this->data['encaissement']->Checkerid_10;

                                $montant_a_payer = $this->data['encaissement']->Notemontant_28 . ' ' . $this->data['encaissement']->Notedevise_29;
                                $montant_paye = $this->data['encaissement']->Montant_11 . ' ' . $this->data['encaissement']->Devise_12;

                                $param ['banque'] = $this->session->userdata('account_id');
                                if (isset($cbs_return["Num_evenement"]))
                                {
                                        $param ['identifiant'] = $cbs_return["Num_evenement"];
                                } 
                                else 
                                {
                                        $param ['identifiant'] = NULL;
                                }

                                $param['ville_agence'] = $guichet->Ville_7 . '/' . $guichets[$this->data['encaissement']->Guichet_21];
                                $param['montantapayer'] = number_format($this->data['encaissement']->Notemontant_28, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['montantpaye'] = number_format($this->data['encaissement']->Montant_11, 2, ",", " ") . ' ' . $this->data['encaissement']->Notedevise_29;

                                $param['designation'] = $this->data['encaissement']->Designation_14;
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGI") 
                                {
                                        $param ['referencenote'] = NULL;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $services[$this->data['encaissement']->Beneficaire_15][$this->data['encaissement']->Service_16];
                                        $param['motif_de_paiement'] = $this->data['encaissement']->Typerecette_17 . ' ' . $periode_mois . '/' . $periode_annee;
                                        $param['articlebudgetaire'] = NULL;
                                }
                                if (isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == "DGRAD") 
                                {
                                        $param ['referencenote'] = $this->data['encaissement']->Noteid_26;
                                        $param['service_de_recouvrement'] = $this->data['encaissement']->Beneficaire_15 . ' ' . $bureau[$this->data['encaissement']->Service_16];
                                        $param['articlebudgetaire'] = $this->data['encaissement']->Artbudgetaire_18;
                                        $param['motif_de_paiement'] = NULL;
                                }

                                $params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
								//$params['data'] = json_encode($param);
								$params['level'] = 'L';
								$params['size'] = '4';
								$this->data['qrcode'] = $params['savename'] = $dir . "/" . $this->session->userdata('account_id') . '.jpeg';

								$this->ciqrcode->generate($params);

                                $service_type = $this->logiref_model->get_dropdown("type_services");

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27421600") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_passport', $this->data, true);
                                }

                                if ($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 == "27022470") 
                                {
                                        $html = $this->load->view('ebcdc/banks/impression/_attestation_taxegardienage', $this->data, true);
                                }

                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');
                                $pdfFilePath = "./drive/logiref/" . $account_id . "/" . $id . "_" . $user_id . "_" . time() . ".pdf";

                                # actually, you can pass mPDF parameter on this load() function
                                $pdf = $this->m_pdf->load();
                                $pdf->WriteHTML('', 1);
                                $pdf->WriteHTML($html, 2);

                                $pdf->Output($pdfFilePath, "F");

                                $designation = isset($encaissement->Designation_14) ? $encaissement->Designation_14 : $encaissement->Nif_13;

                                $customer = isset($designation) ? $designation : "Customer";

                                $mail_data['designation']=$paiement->Designation_14;
                                $mail_data['email']=(!isset($customer_email))?$paiement->Email_54:$customer_email;
								//$mail_data['email']="freddylihamba.dev@gmail.com";
                                $mail_data['telephone']=(!isset($customer_number))?$paiement->Msisdn_55:$customer_number;
								
								$tva=$paiement->Commission_23 * 0.16;
								$total_commission=$paiement->Commission_23 + $tva;
								
								$mail_data['commission']=$total_commission;
                                $mail_data['amount']=$paiement->Montant_11;
                                $mail_data['currency']=$paiement->Devise_12;
                                $mail_data['attachement']= $pdfFilePath;
								$mail_data['mode']= $mail_type;
								$mail_data['commission_in_letter']= $this->data('number_letter', round($total_commission,0), $paiement->Devise_12);

                                $return = $this->mail->mail_send_proof($mail_data['email'],$mail_data['designation'],'fr',$mail_data['attachement'],'DGRAD_PASSPORT',$mail_data['amount'],$mail_data['currency'], $paiement->Noteid_26,$mail_data);

                                if ($return == true) 
                                {
                                        $function_return['code_email'] = 200;
                                        $function_return['code_transaction'] = 200;
                                } 
                                else 
                                {
                                        $function_return['code_email'] = 300;
                                        $function_return['code_transaction'] = 200;
                                }

                        
                }
				return json_encode($function_return);
        }
        
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) 
        {
                if ($obj == "number_letter") 
                {
                        $value = $this->number_letter->converter($data, $arg);

                        return $value;
                } 
                elseif($obj=="get_account_commission")
                {
                                #Retrieve the Eazzybiz account configured based on branch channel configured
                                $token_data = $this->authorization_token->validateToken();
                                $branch_channel = isset($token_data['data']->branch_channel) ? $token_data['data']->branch_channel : "";
                                //$instructions=$this->comptabilisation_model->get_instructions_dgrad($data['logirefid']);
                        
                                $list="'CFP'";
                                $comptes=$this->accounts_model->get_comptes_array($list,$branch_channel,$branch_channel, '', '', '',$data);
                                
                                if($data==9)
                                {
                                        $compte_commission=(isset($comptes['Ebcdc']['CFP']['CDF']))?$comptes['Ebcdc']['CFP']['CDF']:"00000000000000000000";
                                }
								elseif(in_array($payment_mode,['10','11','12','13']))
								{
										$compte_commission=(isset($comptes['Ebcdc']['CFP']['CDF']))?$comptes['Ebcdc']['CFP']['CDF']:"00000000000000000000";
								}
                                else
                                {
                                        $compte_commission=(isset($comptes['Ebcdc']['CFP']['USD']))?$comptes['Ebcdc']['CFP']['USD']:"00000000000000000000";
                                }

                                return $compte_commission;
                }
                elseif ($obj == "paiement_sms") 
                {
                        if ($data == 'DGI') 
                        {
                                $url = $arg;
                                $phone = $param;
                                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS POUR LA DGI. TELECHARGER LA PREUVE : " . $url;

                                $data_to_send = array();
                                $data_to_send['message'] = $sms;
                                $data_to_send['phone'] = $phone;

                                $return = $this->curl_model->call_bank_send_sms($data_to_send);
                        } 
                        elseif ($data == 'DGRAD') 
                        {
                                $url = $arg;
                                $phone = $param;
                                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS POUR LA DGRAD. TELECHARGER LA PREUVE : " . $url;

                                $data_to_send = array();
                                $data_to_send['message'] = $sms;
                                $data_to_send['phone'] = $phone;

                                $return = $this->curl_model->call_bank_send_sms($data_to_send);
                        } 
                        else 
                        {
                                $url = $arg;
                                $phone = $param;
                                $sms = "PAIEMENT EFFECTUE AVEC SUCCESS. TELECHARGER LA PREUVE : " . $url;

                                $data_to_send = array();
                                $data_to_send['message'] = $sms;
                                $data_to_send['phone'] = $phone;

                                $return = $this->curl_model->call_bank_send_sms($data_to_send);
                        }

                        return $return;
                }
        }
		
		public function imageToBase64() 
		{
			$path = FCPATH . 'ikwook_files/logos/46/equity-bank-logo.png';
			//$path = 'http://10.58.202.34/ikwook_files/logos/46/equity-bank-logo.png';
			
			if (!file_exists($path)) {
				return "Error: Image file not found.";
			}

			$imageData = file_get_contents($path);

			if ($imageData === false) {
				return "Error: Unable to retrieve image.";
			}

			$base64 = base64_encode($imageData);
            //var_dump($base64);die;
			$finfo = new finfo(FILEINFO_MIME_TYPE);
			$mimeType = $finfo->buffer($imageData);

			return "data:$mimeType;base64,$base64";
		}

		
        public function check_request($request)
        {
                $log_request = var_export($request, true);
                
                $this->save_log($log_request,"confirm_passport");

                if(isset($request->note_number) && $request->note_number!="" 
                        && isset($request->payment_number) && $request->payment_number!="" 
                        && isset($request->currency) && $request->currency!="" 
                        && isset($request->amount) && $request->amount!=""
                        && isset($request->exchange_rate) && $request->exchange_rate!=""
                        && isset($request->bank_code) && $request->bank_code!=""
                        && isset($request->agency_code) && $request->agency_code!=""
                        && isset($request->agency) && $request->agency!=""
                        && isset($request->logiref_id) && $request->logiref_id!=""
                        && isset($request->reference) && $request->reference!=""
                        && isset($request->date_trans) && $request->date_trans!=""
                        && isset($request->proxypay_ref) && $request->proxypay_ref!=""
					)
                {
                        return true;
                }
                else
                {
                        return false;
                }
        }
		
        public function check_request_payment_card($request)
        {
                $log_request = var_export($request, true);
                
                $this->save_log($log_request,"confirm_passport");

                if(isset($request->note_number) && $request->note_number!="" 
                        && isset($request->payment_number) && $request->payment_number!="" 
                        && isset($request->currency) && $request->currency!="" 
                        && isset($request->amount) && $request->amount!=""
                        && isset($request->exchange_rate) && $request->exchange_rate!=""
                        && isset($request->bank_code) && $request->bank_code!=""
                        && isset($request->agency_code) && $request->agency_code!=""
                        && isset($request->agency) && $request->agency!=""
                        && isset($request->logiref_id) && $request->logiref_id!=""
					)
                {
                        return true;
                }
                else
                {
                        return false;
                }
        }

        public function check_request_payment_agency_banking($request)
        {
                $log_request = var_export($request, true);
                
                $this->save_log($log_request,"confirm_passport");

                if(isset($request->note_number) && $request->note_number!="" 
                        && isset($request->payment_number) && $request->payment_number!="" 
                        && isset($request->currency) && $request->currency!="" 
                        && isset($request->amount) && $request->amount!=""
                        && isset($request->exchange_rate) && $request->exchange_rate!=""
                        && isset($request->bank_code) && $request->bank_code!=""
                        && isset($request->agency_code) && $request->agency_code!=""
                        && isset($request->agency) && $request->agency!=""
                        && isset($request->logiref_id) && $request->logiref_id!=""
                        && isset($request->proxypay_ref) && $request->proxypay_ref!=""
                        && isset($request->date_trans) && $request->date_trans!=""
					)
                {
                        return true;
                }
                else
                {
                        return false;
                }
        }
        
}
