<?php
require  'Middleware.php';
/**
 * Description of LogirefCheckDocument
 * This endpoint is used to verify the existence of a note.
 * @author alvin Bauma
 */
class LogirefCheckDocument extends Middleware {

    public function __construct() {
        parent::__construct();
	
	ini_set('display_errors', 1);
    }
    
    
    public function index_post() 
    {
		
            $request = json_decode(file_get_contents('php://input'));
            
            $regie = null;
            $note = null;
            if($request)
            {
                    $regie = strtolower($request->tax_authority);
                    $note = $request->note;
                    

                    if($regie != null && in_array($regie, $this->regies))
                    {
                            if($note)
                            {   
                                    $return = $this->check_request($regie, $note);
                                    
                                    if($return)
                                    {
                                            if($regie == "dgi")$this->get_note_dgi($note->declaration_id, $note->tax_id, $note->branch_code);
                                            if($regie == "dgda") $this->get_note_dgda($note->service, $note->year, $note->agent, $note->company, $note->assessment_serial, $note->assessment_number, $note->amount, $note->bank_code, $note->currency, $note->branch_code);
                                            if($regie == "dgrad") $this->get_note_dgrad($note->declaration_id, $note->branch_code);
                                            if($regie == "dgrk") $this->get_note_dgrk($note->declaration_id, $note->branche_code);
                                    }
                            }
                            else
                            {
                                    $this->error_message("No information from the note was found");
                            }
                    }
                    else
                    {
                            $this->error_message("The tax authority that you have entered does not exist");
                    }
            }
            else 
            {
                    $this->error_message("No document related to this information was found, No parameter getted");
            }
            
    }
    
    
    private function get_note_dgrk($note_id, $agence) 
    {
            //Fonction a activer apres integration avec la DGRK
            return NULL;
    }
    
    private function get_note_dgi($reference, $nif) 
    {     
            $encaissement = array();
            $declaration = $this->integration_model->get_declaration_by_ref($reference);
            

            if(isset($declaration->Id_0))
            {   
                    $response = $declaration->Id_0;
                    
                    if($declaration->Nif_14 != $nif)
                    {
                            # NIF dismatching
                            $response = 'E402';
                    }
                    else
                    {
                            $encaissement = $this->data_model->dgidec_migrate_declaration($response);
                    }
            }
            else
            {
                    $data['Reference_14'] = $reference;
                    $data['account'] = $this->session->userdata('account_id');
                    $data['user'] = $this->session->userdata('user_id');
                    $data['nif'] = $nif;
                    $data['agence'] = '';
                    
                    
                    # Invocation of the API DGIDEC
                    $response = $this->curl_model->call_dgi_declaration($data);
            }

            if($response == 'E404' || $response == false || $response == '')
            {
                    # Declaration not found
                    $this->error_message("DGI server not available", 404);
            }
            elseif($response == 'E500')
            {
                    $this->error_message("The declaration has not been saved in the database, please retry", 500);
            }
            elseif($response == 'E302')
            {
                    # Declaration not found
                    $this->error_message("Declaration number incorrect", 302);
            }
            elseif($response == 'E402')
            {
                    # NIF dismatching
                    $this->error_message("The tax_id is not correct", 402);
            }
            else
            {   
                    #Successful attempt
                    $encaissement = $this->data_model->dgidec_migrate_declaration($response);
                    
                    $code_service = isset($encaissement->Service_16) ? $encaissement->Service_16 : "";
                    
                    $guichet = $this->branches_model->get_branche_by_service();
                    $guichet = current($guichet);

                    # Retrieve the branch based on the service code
                    $branch_name = isset($guichet->Nom_4) ? $guichet->Nom_4 : "";    
                    $_SESSION['Logiref_guichet'] = isset($guichet->Id_0) ? $guichet->Id_0 : "";
                    $_SESSION['Logiref_agence'] = isset($guichet->Agence_5) ? $guichet->Agence_5 : "";

                    if(isset($guichet->Id_0) ? $guichet->Id_0 : "")
                    {
                            # Retrieve the exchange rate 
                            $this->rates_model->get_easybusy_exchange_rates();

                            $_POST['Montant'] = $amount = $encaissement->Montant_11;
                            $_POST['Devise'] = $currency = $encaissement->Devise_12;
                            $_POST['Noteid'] = $reference = $encaissement->Noteid_26;
                            $_POST['Nif'] = $nif = $encaissement->Nif_13;
                            $_POST['Designation'] = $designation = $encaissement->Designation_14;
                            $_POST['Service'] = $service = $encaissement->Service_16;
                            $_POST['Recette'] = $recette = $encaissement->Typerecette_17;
                            $_POST['Notereference'] = $encaissement->Notereference_30;
                            $_POST['Notedate'] = $encaissement->Notedate_27;

                            #Retrieve the Eazzybiz account configured based on branch channel configured
                            $token_data = $this->authorization_token->validateToken();
                            
                            $branch_channel = isset($token_data['data']->branch_channel) ? $token_data['data']->branch_channel : "";
                            
                            $agence_dst=NULL;
                            $agence_src = $branch_channel;
                            $list = "'CSI'";
                            
                            $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
				
                            $compte_eazzybiz = isset($comptes['Ebcdc']['CSI'][$currency]) ? $comptes['Ebcdc']['CSI'][$currency] : "";

                            if($compte_eazzybiz !="")
                            {
                                    # Compte GL to return to the to request
                                    $compte_gl = str_replace('-', "", $compte_eazzybiz);
                                    
                                    $paiement = $this->encaissement_model->check_paiement();
                                    $paiement = current($paiement);

                                    if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !="")
                                    {
                                            $taux = json_decode($_SESSION['Bank_rates'], true);
                                            $taux = $taux['Dollar_4'];

                                            if(isset($paiement->Checkerid_10) &&  $paiement->Checkerid_10 != 0)
                                            {
                                                    $taux = $paiement->Taux_41;

                                                    $frais_bbc = $paiement->Montant_11 * 0.005;
                                                    
                                                    $declaration = $this->integration_model->get_declaration_by_ref($reference);

                                                    if($paiement->Devise_12 == 'USD')
                                                    {
                                                            $total = 0;
                                                            
                                                            if($paiement->Devise_24 == 'CDF') 
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                                    $tva = $tva/$taux;
                                                                    $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $tva;
                                                                    $total = $total/$taux;
                                                                    $paiement->Commission_23 = $paiement->Commission_23/$taux;
                                                            }
                                                            else
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                                    $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $tva;
                                                            }
                                                            
                                                            $commission_array = array();
                                                            $commission_array['amount'] = $paiement->Commission_23;
                                                            $commission_array['currency'] = $paiement->Devise_24;
                                                            
                                                            $note_details = json_decode($declaration->Notereference_16);
                                                                    
                                                            $montant_onem = str_replace(' ', '', $note_details->MontantONEM);
                                                            $montant_onem = str_replace(',','.', $montant_onem);

                                                            $montant_cnss = str_replace(' ', '', $note_details->MontantINSS);
                                                            $montant_cnss = str_replace(',','.', $montant_cnss);
                                                            
                                                            if(isset($note_details->MontantINPP3))
                                                            {
                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP3);
                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                            }
                                                            elseif(isset($note_details->MontantINPP))
                                                            {
                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP);
                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                            }
                                                            else
                                                            {
                                                                    $montant_inpp = 0;
                                                            }
                                                            

                                                            if($total > 0)
                                                            {
                                                                    $total = $total + $montant_cnss + $montant_inpp + $montant_onem;
                                                            }
                                                            else
                                                            {
                                                                    $total = $paiement->Montant_11 + $frais_bbc + $montant_cnss + $montant_inpp + $montant_onem;
                                                            }
                                                            
                                                            $dec_details = new stdClass();
                                                            $dec_details->tax_number = $note_details->numDeclaration;
                                                            $dec_details->note_amount = $note_details->montantDeclare;
                                                            $dec_details->currency = 'CDF';
                                                            $dec_details->tax_payer = $note_details->NIF ;
                                                            $dec_details->designation = $note_details->raisonSociale ;
                                                            $dec_details->recipe = $note_details->TypeImpot;
                                                            $dec_details->recipe_description = $note_details->LibelleImpot;
                                                            
                                                            $return = new stdClass();
                                                            $return->logiref_id = $paiement->Logirefid_4;
                                                            $return->note_amount = $paiement->Montant_11;
                                                            $return->inpp_amount = $montant_inpp;
                                                            $return->cnss_amount = $montant_cnss;
                                                            $return->onem_amount = $montant_onem;
                                                            $return->currency = $currency;
                                                            $return->commission = $commission_array;
                                                            $return->vat = $tva;
                                                            $return->bcc_fees = $frais_bbc;
                                                            $return->total_amount = $total;
                                                            $return->exchange_rate = $taux;
                                                            $return->compte_gl = $compte_gl;
                                                            $return->dec_details = $dec_details;
                                                            

                                                            $data = [
                                                                    "code" => '202',
                                                                    "status"=>'success',
                                                                    "description" => "Declaration already paid.",
                                                                    "message" => "Declaration already paid.",
                                                                    "data" => $return
                                                            ];
                                                            $this->response($data, REST_Controller::HTTP_OK);
                                                    }
                                                    else
                                                    {
                                                            if($paiement->Devise_24 == 'USD') 
                                                            {
                                                                    $paiement->Commission_23 = $paiement->Commission_23 * $taux;
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                                    $tva = $tva * $taux;
                                                            }
                                                            else
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                            }
                                                            
                                                            $commission_array = array();
                                                            $commission_array['amount'] = $paiement->Commission_23;
                                                            $commission_array['currrency'] = $paiement->Devise_24;
                                                            
                                                            $note_details = json_decode($declaration->Notereference_16);
                                                                    
                                                            $montant_onem = str_replace(' ', '', $note_details->MontantONEM);
                                                            $montant_onem = str_replace(',','.', $montant_onem);

                                                            $montant_cnss = str_replace(' ', '', $note_details->MontantINSS);
                                                            $montant_cnss = str_replace(',','.', $montant_cnss);

                                                            if(isset($note_details->MontantINPP3))
                                                            {
                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP3);
                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                            }
                                                            elseif(isset($note_details->MontantINPP))
                                                            {
                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP);
                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                            }
                                                            else
                                                            {
                                                                    $montant_inpp = 0;
                                                            }

                                                            
                                                            $total = $paiement->Montant_11 + $tva + $paiement->Commission_23 + $frais_bbc + $montant_cnss + $montant_inpp + $montant_onem;
                                                            
                                                            $dec_details = new stdClass();
                                                            $dec_details->tax_number = $note_details->numDeclaration;
                                                            $dec_details->note_amount = $note_details->montantDeclare;
                                                            $dec_details->currency = 'CDF';
                                                            $dec_details->tax_payer = $note_details->NIF ;
                                                            $dec_details->designation = $note_details->raisonSociale ;
                                                            $dec_details->recipe = $note_details->TypeImpot;
                                                            $dec_details->recipe_description = $note_details->LibelleImpot;
                                                            
                                                            $return = new stdClass();
                                                            $return->logiref_id = $paiement->Logirefid_4;
                                                            $return->note_amount = $paiement->Montant_11;
                                                            $return->inpp_amount = $montant_inpp;
                                                            $return->cnss_amount = $montant_cnss;
                                                            $return->onem_amount = $montant_onem;
                                                            $return->currency = $currency;
                                                            $return->commission = $commission_array;
                                                            $return->vat = $tva;
                                                            $return->bcc_fees = $frais_bbc;
                                                            $return->total_amount = $total;
                                                            $return->exchange_rate = $taux;
                                                            $return->compte_gl = $compte_gl;
                                                            $return->dec_details = $dec_details;

                                                            $data = [
                                                                    "code" => '202',
                                                                    "status"=>'success',
                                                                    "description" => "Declaration already paid.",
                                                                    "message" => "Declaration already paid.",
                                                                    "data" => $return
                                                            ];
                                                            $this->response($data, REST_Controller::HTTP_OK);
                                                    }
                                            }
                                            else 
                                            {
                                                    // Calcul de la commission
                                                    $agence = $_SESSION['Logiref_guichet'];
                                                    $response = array();
                                                    $cdata['regie'] = "DGI";
                                                    $cdata['service']= $service;
                                                    $cdata['recette']= $recette;
                                                    $cdata['devise'] = $currency;
                                                    $cdata['guichet'] = $agence;
                                                    $cdata['montant'] = $amount;

                                                    $response = $this->data('get_commission', $cdata, $taux);

                                                    if($currency == 'CDF')
                                                    {
                                                            $frais_bbc = $amount * 0.005;
                                                    }
                                                    else
                                                    {
                                                            $frais_bbc = 0;
                                                    }

                                                    if($currency == "USD" || $currency == "CDF")
                                                    {
                                                            if($currency == "CDF")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] =  $response[0] * $taux;

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'CDF',

                                                                                        );
                                                                    }
                                                                    else 
                                                                    {
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> isset($response[1]) ? $response[1] : 'CDF',

                                                                                        );
                                                                    }

                                                                    $response[2] = $frais_bbc + $response[2];
                                                                    $response[2] = round($response[2]);
                                                            }
                                                            elseif($currency=="USD")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] = number_format($response[0],2,".","");
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> $response[1],

                                                                                        );
                                                                    }
                                                                    elseif(isset($response[1]) && $response[1] =="CDF")
                                                                    {
                                                                            $response[0] =  $response[0]/$taux;

                                                                            $response[0] = number_format($response[0],2,".","");

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'USD'

                                                                                        );
                                                                    }

                                                                    $response[2] = $response[2]/$taux;
                                                                    $response[2] = number_format($response[2],2,".","");
                                                            }

                                                            $paiement = $this->encaissement_model->check_paiement();
                                                            $paiement = current($paiement);
                                                            
                                                            $declaration = $this->integration_model->get_declaration_by_ref($reference);
                                                            
                                                            if(isset($paiement->Id_0) && $paiement->Id_0 !="")
                                                            {
                                                                    $note_details = json_decode($declaration->Notereference_16);
                                                                    
                                                                    $montant_onem = str_replace(' ', '', $note_details->MontantONEM);
                                                                    $montant_onem = str_replace(',','.', $montant_onem);
                                                                    
                                                                    $montant_cnss = str_replace(' ', '', $note_details->MontantINSS);
                                                                    $montant_cnss = str_replace(',','.', $montant_cnss);
                                                                    
                                                                    if(isset($note_details->MontantINPP3))
                                                                    {
                                                                            $montant_inpp = str_replace(' ', '', $note_details->MontantINPP3);
                                                                            $montant_inpp = str_replace(',','.', $montant_inpp);
                                                                    }
                                                                    elseif(isset($note_details->MontantINPP))
                                                                    {
                                                                            $montant_inpp = str_replace(' ', '', $note_details->MontantINPP);
                                                                            $montant_inpp = str_replace(',','.', $montant_inpp);
                                                                    }
                                                                    else
                                                                    {
                                                                            $montant_inpp = 0;
                                                                    }
                                                                    
                                                                    $total = 0;
                                                                    
                                                                    if(isset($response[2]))
                                                                    {
                                                                            $total = $response[2] + $montant_cnss + $montant_inpp + $montant_onem;
                                                                            $tva = $response[0] * 0.16;
                                                                    }
                                                                    else
                                                                    {
                                                                            $total = $paiement->Montant_11 + $frais_bbc + $montant_cnss + $montant_inpp + $montant_onem;
                                                                            $tva = 0;
                                                                    }
                                                                    
                                                                    $dec_details = new stdClass();

                                                                    $dec_details->tax_number = $note_details->numDeclaration;
                                                                    $dec_details->note_amount = $note_details->montantDeclare;
                                                                    $dec_details->currency = 'CDF';
                                                                    $dec_details->tax_payer = $note_details->NIF ;
                                                                    $dec_details->designation = $note_details->raisonSociale ;
                                                                    $dec_details->recipe = $note_details->TypeImpot;
                                                                    $dec_details->recipe_description = $note_details->LibelleImpot;
                                                                    
                                                                    $return = new stdClass();
                                                                    $return->logiref_id = $paiement->Logirefid_4;
                                                                    $return->note_amount = $paiement->Montant_11;
                                                                    $return->inpp_amount = $montant_inpp;
                                                                    $return->cnss_amount = $montant_cnss;
                                                                    $return->onem_amount = $montant_onem;
                                                                    $return->currency = $currency;
                                                                    $return->commission = $commission;
                                                                    $return->vat = $tva;
                                                                    $return->bcc_fees = $frais_bbc;
                                                                    $return->total_amount = $total;
                                                                    $return->exchange_rate = $taux;
                                                                    $return->compte_gl = $compte_gl;
                                                                    $return->dec_details = $dec_details;

                                                                    $data = [
                                                                            "code" => REST_Controller::HTTP_OK,
                                                                            "status"=>'success',
                                                                            "description" => "The request has been executed successfully.",
                                                                            "message" => "The request has been executed successfully.",
                                                                            "data" => $return
                                                                    ];
                                                                    $this->response($data, REST_Controller::HTTP_OK);
                                                            }
                                                            else
                                                            {
                                                                    //Initialisation du paiement dans la table tresor
                                                                    $_POST['Total_amount'] = isset($response[2]) ? $response[2] : 0;
                                                                    $_POST['Commission'] = $commission['amount'];
                                                                    $_POST['Devise_commission'] = $commission['currency'];
                                                                    $_POST['total_amount'] = isset($response[2]) ? $response[2] : 0;

                                                                    $note['Logirefid_4'] = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');

                                                                    $return = $this->init_note_dgi($note['Logirefid_4'], $compte_eazzybiz);

                                                                    if($return == 'E200')
                                                                    {
                                                                            $note_details = json_decode($declaration->Notereference_16);
                                                                    
                                                                            $montant_onem = str_replace(' ', '', $note_details->MontantONEM);
                                                                            $montant_onem = str_replace(',','.', $montant_onem);

                                                                            $montant_cnss = str_replace(' ', '', $note_details->MontantINSS);
                                                                            $montant_cnss = str_replace(',','.', $montant_cnss);

                                                                            if(isset($note_details->MontantINPP3))
                                                                            {
                                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP3);
                                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                                            }
                                                                            elseif(isset($note_details->MontantINPP))
                                                                            {
                                                                                    $montant_inpp = str_replace(' ', '', $note_details->MontantINPP);
                                                                                    $montant_inpp = str_replace(',','.', $montant_inpp);
                                                                            }
                                                                            else
                                                                            {
                                                                                    $montant_inpp = 0;
                                                                            }

                                                                            $total = 0;

                                                                            if(isset($response[2]))
                                                                            {
                                                                                    $total = $response[2] + $montant_cnss + $montant_inpp + $montant_onem;
                                                                                    $tva = $response[0] * 0.16;
                                                                            }
                                                                            else
                                                                            {
                                                                                    $total = $paiement->Montant_11 + $frais_bbc + $montant_cnss + $montant_inpp + $montant_onem;
                                                                                    $tva = 0;
                                                                            }
                                                                            
                                                                            $dec_details = new stdClass();

                                                                            $dec_details->tax_number = $note_details->numDeclaration;
                                                                            $dec_details->note_amount = $note_details->montantDeclare;
                                                                            $dec_details->currency = 'CDF';
                                                                            $dec_details->tax_payer = $note_details->NIF ;
                                                                            $dec_details->designation = $note_details->raisonSociale ;
                                                                            $dec_details->recipe = $note_details->TypeImpot;
                                                                            $dec_details->recipe_description = $note_details->LibelleImpot;
//                                                                            $dec_details->service = $note_details->serviceOperationnel;
//                                                                            $dec_details->release_date = $note_details->Dateordonance_13 ;
//                                                                            $dec_details->period = $note_details->exercice;
//                                                                            $dec_details->inpp_amount = $note_details->MontantINPP3;
//                                                                            $dec_details->cnss_amount = $note_details->MontantINSS;
//                                                                            $dec_details->onem_amount = $note_details->MontantONEM;
                                                                            
                                                                            ######## Bulletin retrieved Code 200 ###########
                                                                            $return = new stdClass();
                                                                            
                                                                            
                                                                            $return->logiref_id = $note['Logirefid_4'];
                                                                            $return->note_amount = $_POST['Montant'];
                                                                            $return->inpp_amount = $montant_inpp;
                                                                            $return->cnss_amount = $montant_cnss;
                                                                            $return->onem_amount = $montant_onem;
                                                                            $return->currency = $currency;
                                                                            $return->commission = $commission;
                                                                            $return->vat = $tva;
                                                                            $return->bcc_fees = $frais_bbc;
                                                                            $return->total_amount = $total;
                                                                            $return->exchange_rate = $taux;
                                                                            $return->compte_gl = $compte_gl;
                                                                            $return->dec_details = $dec_details;

                                                                            $data = [
                                                                                    "code" => REST_Controller::HTTP_OK,
                                                                                    "status"=>'success',
                                                                                    "description" => "The request has been executed successfully.",
                                                                                    "message" => "The request has been executed successfully.",
                                                                                    "data" => $return
                                                                            ];
                                                                            $this->response($data, REST_Controller::HTTP_OK);

                                                                    }
                                                                    elseif($return == 'E401')
                                                                    {
                                                                            $this->error_message("The payment verification failed, please try again.");
                                                                    }
                                                            }
                                                    }
                                                    else
                                                    {
                                                            $this->error_message("Failed to read the request, please check your request !");
                                                    }
                                            }


                                    }
                                    else
                                    {
                                            $this->error_message("The rate exchange has not been retrieved from finacle, an error occured, please retry.", 306);
                                    }
                            }
                            else
                            {
                                    $this->error_message("The Eazzybiz account is not configured in logiref, please kindly contact the administrator for this purpose.", 306);
                            }
                    }
                    else
                    {
                            $this->error_message("No branch found for the code service ".$code_service.", please kindly contact the administartor for further information.", 307);
                    }
            }
    }
    
    
    private function get_note_dgrad($reference, $nif=NULL) 
    {   
            $note_exist = $this->integration_model->get_note_by_ref($reference);
            
            if(isset($note_exist->Id_0))
            {   
                    $response = $note_exist->Id_0;
                    $encaissement = $this->data_model->logirad_migrate_note($response);
            }
            else
            {   
                    $note_data = array();
                    $note_data['Reference_8'] = $reference;
                    $note_data['Account'] = $this->session->userdata('account_id');
                    $note_data['User'] = $this->session->userdata('user_id');
                    
                    # Invocation of the API LOGIRAD
                    $response = $this->curl_model->call_dgrad_notes($note_data);
            }
            
            if($response == "E302")
            {
                    # Declaration not found
                    $this->error_message("Declaration not found", 302);
            }
            elseif($response == "E308")
            {
                    # Declaration not found
                    $this->error_message("An error occurred while executing the query from the DGRAD server", 308);
            }
            elseif($response=="E002")
            {
                    # The declaration has not been saved in the database
                    $this->error_message("The declaration has not been saved in the database, please retry", 500);
            }
            elseif($response == "E000" || $response == "" || $response == false)
            {
                    # Declaration not found
                    $this->error_message("DGRAD server not available", 404);
            }
            else
            {
                    $encaissement = $this->data_model->logirad_migrate_note($response);
                    
                    $code_service = isset($encaissement->Service_16) ? $encaissement->Service_16 : "";
                    
                    # Retrieve the branch based on the service code
                    $guichet = $this->branches_model->get_branche_by_service();
                    $guichet = current($guichet);
                    
                    $branch_name = isset($guichet->Nom_4) ? $guichet->Nom_4 : "";
                    $_SESSION['Logiref_guichet'] = isset($guichet->Id_0) ? $guichet->Id_0 : "";
                    $_SESSION['Logiref_agence'] = isset($guichet->Agence_5) ? $guichet->Agence_5 : "";

                    if(isset($guichet->Id_0) ? $guichet->Id_0 : "")
                    {
                            # Retrieve the exchange rate
                            $this->rates_model->get_easybusy_exchange_rates();

                            $_POST['Montant'] = $amount = $encaissement->Montant_11;
                            $_POST['Devise'] = $currency = $encaissement->Devise_12;
                            $_POST['Noteid'] = $reference = $encaissement->Noteid_26;
                            $_POST['Designation'] = $designation = $encaissement->Designation_14;
                            $_POST['Service'] = $service = $encaissement->Service_16;
                            $_POST['Recette'] = $recette = $encaissement->Typerecette_17;
                            $_POST['Notereference'] = $encaissement->Notereference_30;
                            $_POST['Notedate'] = $encaissement->Notedate_27;
                            
                            #Retrieve the Eazzybiz account configured based on branch channel configured
                            $token_data = $this->authorization_token->validateToken();
                            
                            $branch_channel = isset($token_data['data']->branch_channel) ? $token_data['data']->branch_channel : "";
                            
                            $agence_dst=NULL;
                            $agence_src = $branch_channel;
                            $list = "'CSI'";
                            
                            $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
                            $compte_eazzybiz = isset($comptes['Ebcdc']['CSI'][$currency]) ? $comptes['Ebcdc']['CSI'][$currency] : "";

                            if($compte_eazzybiz !="")
                            {
                                    # Compte GL to return to the to request
                                    $compte_gl = str_replace('-', "", $compte_eazzybiz);
                                    
                                    $paiement = $this->encaissement_model->check_paiement();
                                    $paiement = current($paiement);

                                    if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !="")
                                    {
                                            $taux = json_decode($_SESSION['Bank_rates'], true);
                                            $taux = $taux['Dollar_4'];

                                            if(isset($paiement->Checkerid_10) &&  $paiement->Checkerid_10 != 0)
                                            {
                                                    $note_exist = $this->integration_model->get_note_by_ref($reference);
                                                    
                                                    $taux = $paiement->Taux_41;
                                                    $frais_bbc = $paiement->Montant_11 * 0.005;

                                                    if($paiement->Devise_34 == 'USD')
                                                    {
                                                            if($paiement->Devise_24 == 'CDF') 
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                                    $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc;
                                                                    $total = $total/$taux;
                                                                    $paiement->Commission_23 = $paiement->Commission_23/$taux;
                                                            }
                                                            else
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                                    $total = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $tva;
                                                            }
                                                            
                                                            $commission_array = array();
                                                            $commission_array['amount'] = $paiement->Commission_23;
                                                            $commission_array['currency'] = $paiement->Devise_24;
                                                            
                                                            $not_details = json_decode($note_exist->Result_8);
                                                            
                                                            $not_details = new stdClass();
                                                            $not_details->tax_number = $note_details->numeroNote;
                                                            $not_details->recipe = $note_details->codeActe;
                                                            $not_details->recipe_description = $note_details->libelleActe;
                                                            $not_details->tax_payer = $note_details->numeroImpot;
                                                            $not_details->designation = $note_details->designation;

                                                            $return = new stdClass();
                                                            $return->logiref_id = $paiement->Logirefid_4;
                                                            $return->note_amount = $paiement->Montant_11;
                                                            $return->currency = $currency;
                                                            $return->commission = $commission_array;
                                                            $return->vat = $tva;
                                                            $return->bcc_fees = $frais_bbc;
                                                            $return->tota_amount = $total;
                                                            $return->exchange_rate = $taux;
                                                            $return->compte_gl = $compte_gl;
                                                            $return->dec_details = $note_details;

                                                            $data = [
                                                                    "code" => '202',
                                                                    "status"=>'success',
                                                                    "description" => "Declaration already paid.",
                                                                    "message" => "Declaration already paid.",
                                                                    "data" => $return
                                                            ];
                                                            $this->response($data, REST_Controller::HTTP_OK);
                                                    }
                                                    else
                                                    {
                                                            if($paiement->Devise_24 == 'USD') 
                                                            {
                                                                    $paiement->Commission_23 = $paiement->Commission_23 * $taux;
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                            }
                                                            else
                                                            {
                                                                    $tva = $paiement->Commission_23 * 0.16;
                                                            }
                                                            
                                                            $note_details = json_decode($note_exist->Result_8);
                                                            
                                                            $not_details = new stdClass();
                                                            $not_details->tax_number = $note_details->numeroNote;
                                                            $not_details->recipe = $note_details->codeActe;
                                                            $not_details->recipe_description = $note_details->libelleActe;
                                                            $not_details->tax_payer = $note_details->numeroImpot;
                                                            $not_details->designation = $note_details->designation;

                                                            $return = new stdClass();
                                                            $return->logiref_id = $paiement->Logirefid_4;
                                                            $return->note_amount = $paiement->Montant_11;
                                                            $return->currency = $currency;
                                                            $return->commission = $commission_array;
                                                            $return->vat = $tva;
                                                            $return->bcc_fees = $frais_bbc;
                                                            $return->total_amount = $paiement->Montant_11 + $paiement->Commission_23 + $frais_bbc + $tva;
                                                            $return->exchange_rate = $taux;
                                                            $return->compte_gl = $compte_gl;
                                                            $return->dec_details = $not_details;


                                                            $data = [
                                                                    "code" => '202',
                                                                    "status"=>'success',
                                                                    "description" => "Declaration already paid.",
                                                                    "message" => "Declaration already paid.",
                                                                    "data" => $return
                                                            ];
                                                            $this->response($data, REST_Controller::HTTP_OK);
                                                    }
                                            }
                                            else 
                                            {
                                                    // Calcul de la commission
                                                    $agence = $_SESSION['Logiref_guichet'];
                                                    $response = array();
                                                    $cdata['regie'] = "DGRAD";
                                                    $cdata['service']= $service;
                                                    $cdata['recette']= $recette;
                                                    $cdata['devise'] = $currency;
                                                    $cdata['guichet'] = $agence;
                                                    $cdata['montant'] = $amount;

                                                    $response = $this->data('get_commission', $cdata, $taux);

                                                    if($currency == 'CDF')
                                                    {
                                                            $frais_bbc = $amount * 0.005;
                                                    }
                                                    else
                                                    {
                                                            $frais_bbc = 0;
                                                    }

                                                    if($currency == "USD" || $currency == "CDF")
                                                    {
                                                            if($currency == "CDF")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] =  $response[0] * $taux;

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'CDF',

                                                                                        );
                                                                    }
                                                                    else 
                                                                    {
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> isset($response[1]) ? $response[1] : 'CDF',

                                                                                        );
                                                                    }

                                                                    $response[2] = $frais_bbc + $response[2];
                                                                    $response[2] = round($response[2]);

                                                                    $taux = 1;
                                                            }
                                                            elseif($currency=="USD")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] = number_format($response[0],2,".","");
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> $response[1],

                                                                                        );
                                                                    }
                                                                    elseif(isset($response[1]) && $response[1] =="CDF")
                                                                    {
                                                                            $response[0] =  $response[0]/$taux;

                                                                            $response[0] = number_format($response[0],2,".","");

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'USD'

                                                                                        );
                                                                    }

                                                                    $response[2] = $response[2]/$taux;
                                                                    $response[2] = number_format($response[2],2,".","");
                                                            }

                                                            $paiement = $this->encaissement_model->check_paiement();
                                                            $paiement = current($paiement);
                                                            
                                                            $note_exist = $this->integration_model->get_note_by_ref($reference);

                                                            if(isset($paiement->Id_0) && $paiement->Id_0 !="")
                                                            {
                                                                    $note_details = json_decode($note_exist->Result_8);
                                                                    
                                                                    if(isset($response[0]) && $response[0] > 0)
                                                                    {
                                                                            $tva = $response[0] * 0.16;
                                                                    }
                                                                    else 
                                                                    {
                                                                            $tva = 0;
                                                                    }
                                                                    
                                                                    $not_details = new stdClass();
                                                                    $not_details->tax_number = $note_details->numeroNote;
                                                                    $not_details->recipe = $note_details->codeActe;
                                                                    $not_details->recipe_description = $note_details->libelleActe;
                                                                    $not_details->tax_payer = $note_details->numeroImpot;
                                                                    $not_details->designation = $note_details->designation;

                                                                    $return = new stdClass();
                                                                    $return->logiref_id = $paiement->Logirefid_4;
                                                                    $return->note_amount = $paiement->Montant_11;
                                                                    $return->currency = $currency;
                                                                    $return->commission = $commission;
                                                                    $return->vat = $tva;
                                                                    $return->bcc_fees = $frais_bbc;
                                                                    $return->total_amount = isset($response[2]) ? $response[2] : 0;
                                                                    $return->exchange_rate = $taux;
                                                                    $return->compte_gl = $compte_gl;
                                                                    $return->dec_details = $not_details;

                                                                    $data = [
                                                                            "code" => REST_Controller::HTTP_OK,
                                                                            "status"=>'success',
                                                                            "description" => "The request has been executed successfully.",
                                                                            "message" => "The request has been executed successfully.",
                                                                            "data" => $return
                                                                    ];
                                                                    $this->response($data, REST_Controller::HTTP_OK);

                                                            }
                                                            else
                                                            {
                                                                    //Initialisation du paiement dans la table tresor
                                                                    $_POST['Total_amount'] = isset($response[2]) ? $response[2] : 0;
                                                                    $_POST['Commission'] = $commission['amount'];
                                                                    $_POST['Devise_commission'] = $commission['currency'];
                                                                    $_POST['total_amount'] = isset($response[2]) ? $response[2] : 0;

                                                                    $note_details = json_decode($note_exist->Result_8);

                                                                    $note['Logirefid_4'] = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');

                                                                    $return = $this->init_note_dgrad($note['Logirefid_4'], $compte_eazzybiz);

                                                                    if($return == 'E200')
                                                                    {
                                                                            ######## Declaration retrieved code 200 ###########
                                                                            $note_details = json_decode($note_exist->Result_8);
                                                                            
                                                                            if(isset($response[0]) && $response[0] > 0)
                                                                            {
                                                                                    $tva = $response[0] * 0.16;
                                                                            }
                                                                            else 
                                                                            {
                                                                                    $tva = 0;
                                                                            }
                                                                            
                                                                            $not_details = new stdClass();
                                                                            $not_details->tax_number = $note_details->numeroNote;
                                                                            $not_details->recipe = $note_details->codeActe;
                                                                            $not_details->recipe_description = $note_details->libelleActe;
                                                                            $not_details->tax_payer = $note_details->numeroImpot;
                                                                            $not_details->designation = $note_details->designation;
                                                                            
                                                                            $return = new stdClass();
                                                                            $return->logiref_id = $note['Logirefid_4'];
                                                                            $return->note_amount = $_POST['Montant'];
                                                                            $return->currency = $currency;
                                                                            $return->commission = $commission;
                                                                            $return->vat = $tva;
                                                                            $return->bcc_fees = $frais_bbc;
                                                                            $return->total_amount = isset($response[2]) ? $response[2] : 0;
                                                                            $return->exchange_rate = $taux;
                                                                            $return->compte_gl = $compte_gl;
                                                                            $return->dec_details = $not_details;
                                                                            

                                                                            $data = [
                                                                                    "code" => REST_Controller::HTTP_OK,
                                                                                    "status"=>'success',
                                                                                    "description" => "The request has been executed successfully.",
                                                                                    "message" => "The request has been executed successfully.",
                                                                                    "data" => $return
                                                                            ];
                                                                            $this->response($data, REST_Controller::HTTP_OK);

                                                                    }
                                                                    elseif($return == 'E401')
                                                                    {
                                                                            $this->error_message("The payment verification failed, please try again.");
                                                                    }
                                                            }
                                                    }
                                                    else
                                                    {
                                                            $this->error_message("Failed to read the request, please check your request !");
                                                    }
                                            }
                                    }
                                    else
                                    {
                                            $data = [
                                                    "code" => 304,
                                                    "status"=>'error',
                                                    "description" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                                    "message" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                                    "data" => $return
                                            ];
                                            $this->response($data, 304);
                                    }
                            }
                            else
                            {
                                    $this->error_message("The Eazzybiz account is not configured in logiref, please kindly contact the administrator for this purpose.", 306);
                            }
                    }
                    else
                    {
                            $this->error_message("No branch found for the code service ".$code_service.", please kindly contact the administartor for further information.", 307);
                    }
            }
    }
    
    public function get_note_dgda($service, $year, $agent, $company, $assessment_serial, $assessment_number, $amount, $bank_code, $currency) 
    {
            #Retrieve the branch based on the service code
            $guichet = $this->branches_model->get_branche_by_service();
            $guichet = current($guichet);

            $branch_name = isset($guichet->Nom_4) ? $guichet->Nom_4 : $bank_code;    
            $_SESSION['Logiref_guichet'] = isset($guichet->Id_0) ? $guichet->Id_0 : "";
            $_SESSION['Logiref_agence'] = isset($guichet->Agence_5) ? $guichet->Agence_5 : "";
            
            if(isset($guichet->Id_0) ? $guichet->Id_0 : "")
            {
                    #Retrieve the Eazzybiz account configured based on branch channel configured
                    $token_data = $this->authorization_token->validateToken();

                    $branch_channel = isset($token_data['data']->branch_channel) ? $token_data['data']->branch_channel : "";

                    $agence_dst=NULL;
                    $agence_src = $branch_channel;
                    $list = "'CSI'";

                    $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
                    $compte_eazzybiz = isset($comptes['Ebcdc']['CSI'][$currency]) ? $comptes['Ebcdc']['CSI'][$currency] : "";

                    if($compte_eazzybiz !="")
                    {
                            # Compte GL to return to the to request
                            $compte_gl = str_replace('-', "", $compte_eazzybiz);
                                    
                            $user = $this->session->userdata('user_id');
                            $_POST['Year'] = $year;
                            $_POST['Series'] = $assessment_serial;
                            $_POST['Number'] = $assessment_number;//95
                            $_POST['Agent'] = $agent;
                            $_POST['Office'] = $service;
                            $_POST['Nif'] = $company;//A0815158L
                            $_POST['Bank'] = $bank_code;
                            $_POST['Amount'] = $amount; //10863739

                            $bulletin = $this->integration_model->check_bulletin_sydonia();
                            $bulletin = current($bulletin);

                            $this->rates_model->get_easybusy_exchange_rates();

                            if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !="")
                            {
                                    $taux = json_decode($_SESSION['Bank_rates'], true);

                                    $taux = $taux['Dollar_4'];

                                    if(isset($bulletin->Status_2) &&  $bulletin->Status_2 == '2')
                                    {   
                                            $taux = $bulletin->Taux_31;

                                            $frais_bbc = $bulletin->Amount_12 * 0.001;

                                            
                                            $tva = $bulletin->Commission_26 * 0.16;
                                            $total = $bulletin->Commission_26 + $tva + $frais_bbc + $bulletin->Amount_12;


                                            $commission_array = array();
                                            $commission_array['amount'] = $bulletin->Commission_26;
                                            $commission_array['currency'] = $bulletin->Devise_27;

                                            $return = new stdClass();
                                            $return->logiref_id = $bulletin->Logirefid_36;
                                            $return->note_amount = $bulletin->Amount_12;
                                            $return->currency = 'CDF';
                                            $return->commission = $commission_array;
                                            $return->vat = $tva;
                                            $return->bcc_fees = $frais_bbc;
                                            $return->total_amount = $total;
                                            $return->exchange_rate = $taux;
                                            $return->compte_gl = $compte_gl;

                                            $data = [
                                                    "code" => '202',
                                                    "status"=>'success',
                                                    "description" => "Declaration already paid",
                                                    "message" => "Declaration already paid",
                                                    "data" => $return
                                            ];
                                            $this->response($data, REST_Controller::HTTP_OK);
                                    }
                                    else
                                    {
                                            $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                                            $response = $this->curl_model->call_dgda_checkbl($credentials);
                                            $response = trim($response);

                                            $result = json_decode($response, true);

                                            if($result['code']!='OK')
                                            {
                                                    $this->error_message($result['message'], $result['code']);
                                            }
                                            else
                                            {
                                                    // Calcul de la commission
                                                    $agence = $_SESSION['Logiref_guichet'];
                                                    $response = array();
                                                    $cdata['regie'] = "DGDA";
                                                    $cdata['service']= $service;
                                                    $cdata['recette']= NULL;
                                                    $cdata['devise'] = "CDF";
                                                    $cdata['guichet'] = $agence;
                                                    $cdata['montant'] = $amount;
                                                    $cdata['compte'] = "";
                                                    $cdata['compteDevise'] = "";

                                                    $response = $this->data('get_commission', $cdata, $taux);

                                                    $frais_bbc = $amount * 0.001;

                                                    if($currency == "USD" || $currency == "CDF")
                                                    {
                                                            if($currency == "CDF")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] =  $response[0] * $taux;

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'CDF',

                                                                                        );
                                                                    }
                                                                    else 
                                                                    {
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> isset($response[1]) ? $response[1] : 'CDF',

                                                                                        );
                                                                    }

                                                                    $response[2] = $frais_bbc + $response[2];
                                                                    $response[2] = round($response[2]);
                                                            }
                                                            elseif($currency=="USD")
                                                            {
                                                                    if(isset($response[1]) && $response[1] =="USD")
                                                                    {
                                                                            $response[0] = number_format($response[0],2,".","");
                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> $response[1],

                                                                                        );
                                                                    }
                                                                    elseif(isset($response[1]) && $response[1] =="CDF")
                                                                    {
                                                                            $response[0] =  $response[0]/$taux;

                                                                            $response[0] = number_format($response[0],2,".","");

                                                                            $commission = array(
                                                                                            "amount"=> isset($response[0]) ? $response[0] : 0,
                                                                                            "currency"=> 'USD'

                                                                                        );
                                                                    }

                                                                    $response[2] = $response[2]/$taux;
                                                                    $response[2] = number_format($response[2],2,".","");
                                                            }

                                                            $bulletin = $this->integration_model->check_bulletin_sydonia();
                                                            $bulletin = current($bulletin); 

                                                            if(isset($bulletin->Id_0) && $bulletin->Id_0 !="")
                                                            {
                                                                    ######## Bulletin retrieved Code 200 ###########
                                                                    $result = $bulletin->Results_13;
                                                                    
                                                                    if(isset($response[0]) && $response[0] > 0)
                                                                    {
                                                                            $tva = $response[0] * 0.16;
                                                                            $total = $response[0] + $tva + $frais_bbc + $bulletin->Amount_12;
                                                                    }
                                                                    else
                                                                    {
                                                                            $tva = 0;
                                                                            $total = $frais_bbc + $bulletin->Amount_12;
                                                                    }
                                                                    
                                                                    $return = new stdClass();
                                                                    $return->logiref_id = $bulletin->Logirefid_36;
                                                                    $return->note_amount = $bulletin->Amount_12;
                                                                    $return->currency = 'CDF';
                                                                    $return->commission = $commission;
                                                                    $return->vat = $tva;
                                                                    $return->fees_amount = $frais_bbc;
                                                                    $return->total_amount = $total;
                                                                    $return->exchange_rate = $taux;
                                                                    $return->compte_gl = $compte_gl;
                                                                    
                                                                    $data = [
                                                                            "code" => REST_Controller::HTTP_OK,
                                                                            "status"=>'success',
                                                                            "description" => "The request has been executed successfully",
                                                                            "message" => "The request has been executed successfully",
                                                                            "data" => $return
                                                                    ];
                                                                    $this->response($data, REST_Controller::HTTP_OK);

                                                            }
                                                            else
                                                            {
                                                                    //Initialisation du paiement dans la table Sydonia 
                                                                    $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                                                    $_POST['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :$_POST['Nif']; 
                                                                    $_POST['Total_amount'] = isset($response[2]) ? $response[2] : 0;
                                                                    $_POST['Commission'] = $commission['amount'];
                                                                    $_POST['Devise_commission'] = $commission['currency'];

                                                                    $note['Logirefid_4'] = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');

                                                                    $return = $this->init_note_dgda($note['Logirefid_4'], $compte_eazzybiz);

                                                                    if($return == 200)
                                                                    {
                                                                            ######## Bulletin retrieved Code 200 ###########
                                                                            
                                                                            if(isset($response[0]) && $response[0] > 0)
                                                                            {
                                                                                    $tva = $response[0] * 0.16;
                                                                                    $total = $response[0] + $tva + $frais_bbc + $_POST['Amount'];
                                                                            }
                                                                            else
                                                                            {
                                                                                    $tva = 0;
                                                                                    $total = $frais_bbc + $bulletin->Amount_12;
                                                                            }
                                                                            
                                                                            $return = new stdClass();
                                                                            $return->logiref_id = $note['Logirefid_4'];
                                                                            $return->note_amount = $_POST['Amount'];
                                                                            $return->currency = 'CDF';
                                                                            $return->commission = $commission;
                                                                            $return->vat = $tva;
                                                                            $return->fees_bcc = $frais_bbc;
                                                                            $return->total_amount = $total;
                                                                            $return->exchange_rate = $taux;
                                                                            $return->compte_gl = $compte_gl;

                                                                            $data = [
                                                                                    "code" => REST_Controller::HTTP_OK,
                                                                                    "status"=>'success',
                                                                                    "description" => "The request has been executed successfully",
                                                                                    "message" => "The request has been executed successfully",
                                                                                    "data" => $return
                                                                            ];
                                                                            $this->response($data, REST_Controller::HTTP_OK);

                                                                    }
                                                                    elseif($return == 'E401')
                                                                    {
                                                                            $this->error_message("There was a problem while checking the bulletin, please kindly retry the operation.");
                                                                    }
                                                                    else
                                                                    {
                                                                            // L'initialisation du bulletin n'a pas ï¿½tï¿½ effectuï¿½ : message erreur ï¿½ retourner
                                                                            $this->error_message("No branch found for this bank code");

                                                                    }
                                                            }
                                                    }
                                                    else
                                                    {
                                                            $this->error_message("Failed to read the request, please check your request !");
                                                    }
                                            }
                                    }
                            }
                            else
                            {
                                    $data = [
                                            "code" => 304,
                                            "status"=>'error',
                                            "description" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                            "message" => "The rate exchange has not been retrieved from finacle, an error occured, please retry.",
                                            "data" => $return
                                    ];
                                    $this->response($data, 304);
                            }
                    }
                    else
                    {
                            $this->error_message("The Eazzybiz account is not configured in logiref, please kindly contact the administrator for this purpose.", 306);
                    }
            }
            else
            {
                    $this->error_message("No branch found for the code service ".$service.", please kindly contact the administartor for further information.", 307);
            }
    }
    
    
    public function init_note_dgda($id, $compte_eazzybiz)
    {
            $logirefid = $id;
                        
            $data['Status_2'] = 0;
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Designation_23'] = $_POST['designation'];

            //Formatting amount
            $data['Amount_12'] = str_replace(' ','',$_POST['Amount']);
            $data['Amount_12'] = str_replace(',','.',$data['Amount_12']);

            $data['Devise_27'] ='CDF';//$_POST['devise'];
            $data['Type_4'] = 10;
            $data['Year_5'] = $_POST['Year'];
            $data['Serie_7'] = $_POST['Series'];
            $data['Number_8'] = $_POST['Number'];
            $data['Agent_10'] = $_POST['Agent'];
            $data['Office_6'] = $_POST['Office'];
            $data['Nif_9'] = $_POST['Nif'];
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Bank_11'] = $_POST['Bank'];
            $data['Account_28'] = $compte_eazzybiz;
            $data['Devise_29'] = 'CDF';
            
            $data['User_15'] = $this->session->userdata('user_id');

            $data['Mode_30'] = 7;
            $data['Agence_32'] =  $_SESSION['Logiref_guichet'];
            $data['Amount_25'] = $_POST['Nif'];

            $data['Amount_25'] = str_replace(' ','',$_POST['Total_amount']);
            $data['Amount_25'] = str_replace(',','.',$data['Amount_25']);

            $data['Commission_26'] = str_replace(' ','',$_POST['Commission']);
            $data['Commission_26'] = str_replace(',','.',$data['Commission_26']);

            $data['Devise_27'] = $_POST['Devise_commission'];
            $data['Logirefid_36'] = $logirefid;
            
            $agence_src= $_SESSION['Logiref_guichet'];
            $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
            # Compte guichet unique
            $compte_cgu = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
            $data['Account_24'] = $compte_cgu;
            
            $data['Account_28'] = $compte_eazzybiz;
            $data['Devise_29'] = 'CDF';
            
            $taux = json_decode($_SESSION['Bank_rates'], true);
            $taux = $taux['Dollar_4'];
            $data['Taux_31'] = $taux;


            $id = $this->integration_model->save_bulletin($data, NULL);


            if($id > 0)
            {
                    return 200;
            }
            else
            {
                    return 'E401';
            }
    }
    
    public function init_note_dgrad($logirefid, $compte_eazzybiz)
    {
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Status_2'] = 0;
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Logirefid_4'] = $logirefid;
            $data['Makerid_9'] = $this->session->userdata('user_id');
            $data['Montant_11'] = $_POST['Montant'];
            $data['Devise_12'] = $_POST['Devise'];
            $data['Designation_14'] = $_POST['Designation'];
            $data['Beneficaire_15'] = 'DGRAD';
            $data['Service_16'] = $_POST['Service'];
            $data['Typerecette_17'] = $_POST['Recette'];
            $data['Mode_19'] = 7;
            $data['Agence_20'] = $_SESSION['Logiref_agence'];
            $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
            $data['Contrevaleur_22'] = $_POST['Montant'];
            $data['Notetype_25'] = 1;
            $data['Noteid_26'] = $_POST['Noteid'];
            $data['Notedate_27'] = $_POST['Notedate'];
            $data['Notemontant_28'] = $_POST['Montant'];
            $data['Notedevise_29'] =  $_POST['Devise'];
            $data['Datevaleur_31'] = gmdate('Y-m-d');
            $data['Commission_23'] = $_POST['Commission'];
            $data['Devise_24'] = $_POST['Devise_commission'];
            $data['Devise_34'] = $_POST['Devise'];
            
            $data['Sydonia_44'] = '0';
            $data['Tresor_45'] = 1;
            $data['Type_53'] = 'mobile';
            
            #Comptes suspens Eazzybiz
            $data['Compte_33'] = $compte_eazzybiz;
            
            $infos = array();

            $infos['NumeroTitre'] = "";
            $infos['Motif'] = "";
            $infos['standard'] = $_POST['Recette'];
            $infos['totalMontant'] = $_POST['total_amount'];
            $infos['totalDevise'] = "CDF";

            $data["Notereference_30"] = json_encode($infos);

            $periode = $data['Notedate_27'];

            $agence_dst=NULL;
            $agence_src = $_SESSION['Logiref_guichet'];
            $list = NULL;
            $comptes_recettes = NULL;

            $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);

            $date_emission = isset($data['Notedate_27']) ? $data['Notedate_27'] : "";

            $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRAD", NULL, NULL, $date_emission);

            $nid = $this->encaissement_model->save_payment_tresor($data, NULL);

            if(!empty($instructions))
            {
                    $this->comptabilisation_model->save_instructions_dgrad($nid, $data, $instructions, $data['Logirefid_4']);
            }

            if($nid > 0)
            {
                    return 'E200';
            }
            else
            {
                    return 'E401';
            }
    }
    
    public function init_note_dgi($logirefid, $compte_eazzybiz)
    {
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Status_2'] = 0;
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Logirefid_4'] = $logirefid;
            $data['Makerid_9'] = $this->session->userdata('user_id');
            $data['Montant_11'] = $_POST['Montant'];
            $data['Devise_12'] = $_POST['Devise'];
            $data['Nif_13'] = $_POST['Nif'];
            $data['Designation_14'] = $_POST['Designation'];
            $data['Beneficaire_15'] = 'DGI';
            $data['Service_16'] = $_POST['Service'];
            $data['Typerecette_17'] = $_POST['Recette'];
            $data['Mode_19'] = 7;
            $data['Agence_20'] = $_SESSION['Logiref_agence'];
            $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
            $data['Contrevaleur_22'] = $_POST['Montant'];
            $data['Notetype_25'] = 5;
            $data['Noteid_26'] = $_POST['Noteid'];
            $data['Notedate_27'] = $_POST['Notedate'];
            $data['Notemontant_28'] = $_POST['Montant'];
            $data['Notedevise_29'] =  $_POST['Devise'];
            $data['Datevaleur_31'] = gmdate('Y-m-d');
            $data['Commission_23'] = $_POST['Commission'];
            $data['Devise_24'] = $_POST['Devise_commission'];
            $data['Devise_34'] = $_POST['Devise'];
            
            $data['Sydonia_44'] = '0';
            $data['Tresor_45'] = 1;
            $data['Type_53'] = 'mobile';
            
            #Comptes suspens Eazzybiz
            $data['Compte_33'] = $compte_eazzybiz;
            
            $infos = array();

            if(isset($_POST['Notereference']) && $_POST['Notereference'] !="")
            {
                    $infos = json_decode($_POST['Notereference'], true);
            }

            $infos['NumeroTitre'] = "";
            $infos['Motif'] = "";
            $infos['totalMontant'] = $_POST['total_amount'];
            $infos['totalDevise'] = "CDF";
            $infos['Branch_code'] = $branch_code;

            if(!isset($infos['standard']))
            {
                    $infos['standard'] = $_POST['Periode'];
            }
            
            # Verify the existence of INPP 
            if(isset($infos['MontantINPP3']))
            {
                    $inpp = $infos['MontantINPP3'];
            }
            elseif(isset($infos['MontantINPP']))
            {
                    $inpp = $infos['MontantINPP3'];
            }
            else
            {
                    $inpp = 0;
            }

            if(isset($infos['MontantONEM']) || isset($infos['MontantINSS']) || $inpp > 0)
            {
                    if(isset($infos['MontantINPP3']))
                    {
                            $inpp = $infos['MontantINPP3'];
                    }
                    elseif(isset($infos['MontantINPP']))
                    {
                            $inpp = $infos['MontantINPP3'];
                    }
                    else
                    {
                            $inpp = 0;
                    }
                    
                    $data['Montant_11'] = $_POST['Montant'] - $infos['MontantONEM'] - $infos['MontantINSS'] - $inpp;
                    $infos['QuotasDGI'] = $data['Montant_11'];
                    $infos['QuotasINPP'] = $inpp;
                    $infos['QuotasINSS'] = $infos['MontantINSS'];
                    $infos['QuotasONEM'] = $infos['MontantONEM'];
            }

            $data["Notereference_30"] = json_encode($infos);

            $periode = isset($infos['standard']) ? $infos['standard'] : "";

            $agence_dst=NULL;
            $agence_src = $_SESSION['Logiref_guichet'];
            $list = NULL;
            $comptes_recettes = NULL;
            $service_type =$this->logiref_model->get_dropdown("type_services");

            $service = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
            $recette = $data['Typerecette_17'];
            $case = $this->comptabilisation_model->get_use_case($data);
            $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst, $data['Beneficaire_15'], $service, $recette);

            if($data['Beneficaire_15'] == 'DGI' && ($data['Typerecette_17'] == 'TVF' || $data['Typerecette_17'] == 'TVN' || $data['Typerecette_17'] == 'TVO'))
            {
                    $agence_src= $_SESSION['Logiref_guichet'];
                    $comptes_recettes = $this->accounts_model->get_comptes_recettes_agence_array("'CPT'", $agence_src, "DGI");
            }

            $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGI", $comptes_recettes, $service, $periode);

            $nid = $this->encaissement_model->save_payment_tresor($data, NULL);

            if(!empty($instructions))
            {
                    $this->comptabilisation_model->save_instructions_dgi($nid, $data, $instructions, $data['Logirefid_4']);
            }

            if(isset($infos) && $infos !="")
            {
                    #Guichet Unique DGI - repartition
                    if($data['Typerecette_17'] == 'IPRIER' && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="")
                    {
                            $instructions = $this->comptabilisation_model->get_instructions_gu_dgi($data, $comptes,'DGI', $service, $periode);
                            $this->comptabilisation_model->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                    }
            }

            if($nid > 0)
            {
                    return 'E200';
            }
            else
            {
                    return 'E401';
            }
    }
    
    public function init_note_dgrk($note, $id)
    {
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Status_2'] = 0;
            $data['Account_3'] = $this->session->userdata('account_id');
            $data['Logirefid_4'] = $id;
            $data['Makerid_9'] = $this->session->userdata('user_id');
            $data['Montant_11'] = $note->Montant_11;
            $data['Devise_12'] = $note->Notedevise_29;
            $data['Nif_13'] = $note->Nif_13;
            $data['Designation_14'] = $note->Designation_14;
            $data['Beneficaire_15'] = 'DGRK';
            $data['Service_16'] = $note->Service_16;
            $data['Typerecette_17'] = $note->Typerecette_17;
            $data['Artbudgetaire_18'] = $note->Artbudgetaire_18;
            $data['Mode_19'] = 7;
            $data['Agence_20'] = $_POST['Agence_20'];
            $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
            $data['Contrevaleur_22'] = $note->Contrevaleur_22;
            $data['Notetype_25'] = 1;
            $data['Noteid_26'] = $note->Reference_8;
            $data['Notedate_27'] = $note->Notedate_27;
            $data['Notemontant_28'] = $note->Notedate_27;
            $data['Notedevise_29'] = $note->Notedevise_29;
            $data['Notereference_30'] = $note->Notereference_30;
            $data['Datevaleur_31'] = $note->Datevaleur_31;
            $data['Sydonia_44'] = '0';
            $data['Tresor_45'] = '0';
            
            $nid = $this->encaissement_model->save_payment_propres($data, NULL);
            
            if($nid > 0)
            {
                    return 200;
            }
            else
            {
                    return 'E200';
            }
    }
    
    public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
    {
            if($obj == "get_commission")
            {
                    $cdata = $data;
                    $taux = $arg;
                    $montant1 = str_replace(' ','',$cdata['montant']);
                    $montant2 = str_replace(',','.',$montant1);
                    $cdata['montant'] = $montant2;
                    $oDeivise = $cdata['devise'];
                    
                    $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte'], $cdata['compteDevise']);

                    if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                    {
                            $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                            $com['devise'] = $cdata['devise'];
                    }
                    elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                    {
                            $com['com'] = $rules['Valeur'];
                            $com['devise'] = $rules['Unite'];
                    }

                    if(!empty($com) && $com['com']!=0)
                    {
                            $cdata['commission'] = $com['com'];
                            $cdata['devise'] = $com['devise'];
                    }
                    else
                    {
                            $cdata['commission'] = $cdata['montant']*0;
                            $cdata['devise'] = $cdata['devise'];
                    }

                    //Montant total
                    if(isset($_SESSION['Bank_rates'])):
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                    else: 
                        $taux['Dollar_4']  = 1;
                    endif;
                        
                        
                    if($cdata['devise'] == $oDeivise && $oDeivise=='CDF')
                    {
                            $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                    }
                    else if($cdata['devise'] == $oDeivise && $oDeivise =='USD')
                    {
                            # Convert amount to cdf to get the total in cdf
                            $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];

                            # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                            $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                            $cdata['devise']='CDF';

                            $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                    }
                    else if($cdata['devise'] == 'USD' && $oDeivise =='CDF')
                    {
                            # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                            $cdata['commission'] = $cdata['commission']*$taux['Dollar_4'];
                            $cdata['devise']='CDF';

                            $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);

                    }
                    else if($cdata['devise'] == 'CDF' && $oDeivise =='USD')
                    {
                            # Convert amount to cdf to get the total in cdf
                            $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];

                            $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                    }
                    else 
                    {
                            $cdata['total'] = 0;
                    }
                    $cdata['commission'] = $cdata['commission'];
                    $cdata['total'] = $cdata['total'];

                    $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                    return $ar; exit;
            }
    }
    
    public function check_request($regie, $note)
    {   
            $log_request = var_export($note, true);
            $this->save_log($log_request,"check_document_".$regie);
            
            if($regie == "dgi")
            {
                    if(isset($note->declaration_id) && $note->tax_id !="" && isset($note->branch_code))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }

            }
            elseif($regie == "dgda")
            {
                    if(isset($note->service) && isset($note->year) && isset($note->company) && isset($note->assessment_serial) && isset($note->assessment_number) && isset($note->amount) && isset($note->bank_code) && isset($note->currency) && isset($note->branch_code))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrad")
            {
                    if(isset($note->declaration_id) && isset($note->branch_code))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
            elseif($regie == "dgrk")
            {
                    if(isset($note->declaration_id) && isset($note->branch_code))
                    {
                            return true;
                    }
                    else
                    {
                            $this->error_message("Failed to read the request, please check your request !");
                    }
            }
    }

}
