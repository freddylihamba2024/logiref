<?php
class Fees_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	public $priorites = array(
                            '1' => 'Priorit&eacute;1',
                            '2' => 'Priorit&eacute;2',
                            '3' => 'Priorit&eacute;3',
                            '4' => 'Priorit&eacute;4',
                            '5' => 'Priorit&eacute;5',
                            '6' => 'Priorit&eacute;6',
                            '7' => 'Priorit&eacute;7',
                            '8' => 'Priorit&eacute;8',
                            '9' => 'Priorit&eacute;9',
                            '10' => 'Priorit&eacute;10'
            
                        );
        
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_regle_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Priorite_4 = '';
                        $obj->Beneficiaire_5 = '';
                        $obj->Service_6 = '';
                        $obj->Recette_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Value_9 = '';
                        $obj->Unite_10 = '';
                        $obj->Min_11 = '0';
                        $obj->Max_12 = '0';
                        $obj->Devise_13 = 'CDF';
                        $obj->Makerid_14 = '';
                        $obj->Checkerid_15 = '';
                        $obj->Validation_16 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_regles p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_regles($type=NULL)
        {
                $this->_table_name = '';
                
                if($type== "rgle")
                {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "'"; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
                else
                {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND ( Beneficiaire_5='0' OR Beneficiaire_5='" .$_SESSION['Logiref_regies']. "') AND Checkerid_15 !='0'"; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                        
                }
        }
        
        public function get_bank_charges($regie, $service, $recette, $devise, $montant, $guichet) 
        {
                $valeur = 0;
                $unite = 0;
                $account = $this->session->userdata('account_id');
                $where = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "'";
                $this->db->where($where, NULL, FALSE);
                $this->db->order_by('Priorite_4 DESC');
                $query = $this->db->get('logiref_regles');
                $ddmenu = array();

                foreach ($query->result_array() as $row)
                {
                        #Priorit� 1
                        if($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']))
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;
                               
                        }
                        #Priorit� 2
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] == 0 && $montant == 0))
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                                
                        }
                        #Priorit� 3
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                             
                                break;
                        } 
                        #Priorit� 4
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                 
                                break;
                        }
                        #Priorit� 5
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet)
                        {     
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                break;    
                        }
                        #Priorit� 6
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                break;
                        }
                        #Priorit� 7
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                        }
                        #Priorit� 8
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;
                        }
                        #Priorit� 9
                        elseif($row['Beneficiaire_5'] == $regie && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet)
                        { 
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                              
                                break; 
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] =='' && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];

                                break; 
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break; 
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] =='' && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break; 
                        }
                        
                }
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite);
               
                return $ddmenu;
                
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='".$account_id."'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
	}
        
        public function get_agence_regles()
        {
                $guichet = $_SESSION['Logiref_guichet'];
                
                $this->_table_name = '';
                $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                $this->db->from('logiref_regles');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Guichet_8='".$guichet."'"; 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_agence_regles_filtered($data)
        {
                $guichet = $_SESSION['Logiref_guichet'];
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Guichet_8='".$guichet."'"; 
                
                if( isset($data['regie'] )  &&  $data['regie'] !="" ) $st .=  " AND Beneficiaire_5 ='".$data['regie']."'";
                
                $this->_table_name = '';
                $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                $this->db->from('logiref_regles');
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_regle($data, $id)
        {
                $this->set_table('logiref_regles', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        
        
        
}