<?php
class Rates_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_all_taux($from = NULL, $to = NULL) 
        {
                $to = date('Y-m-d', strtotime($to. ' +1 days'));
                
                $this->_table_name = '';
                
                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 DESC');
                $this->db->from('logiref_taux');
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_11 !=0 ";
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                $this->db->where($st, NULL, FALSE);
                if($from != NULL) $this->db->where('Date_1 >=', $from);
                if($to != NULL) $this->db->where('Date_1 <=', $to);
                $this->db->order_by('logiref_taux.Id_0 DESC');
                $this->db->limit('100');
                return $this->get_all();
        }
        
        public function get_taux($from = NULL, $to = NULL) 
        {
                $month = gmdate('Y-m');
                $this->_table_name = '';
                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 DESC');
                $this->db->from('logiref_taux');
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata('account_id') . "'";
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                
                if($from != NULL && $to != NULL)
                {
                        $st .= " AND (Day_9 BETWEEN '" . $from . " AND  '" . $to . "')";
                }
                $this->db->where($st, NULL, FALSE);
                $this->db->where("DATE_FORMAT(Day_9,'%Y-%m')", $month);
                $this->db->order_by('logiref_taux.Id_0 DESC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_exchange_rates() 
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                $day = gmdate('Y-m-d');
                $agence = '';
                if(isset($_SESSION['Logiref_agence'])) $agence = $_SESSION['Logiref_agence'];
                $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Day_9='" . $day. "' AND Agence_8='" . $agence. "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_taux');
                $results = $query->result_array();
                if(!empty($results))
                {
                        $_SESSION['Bcc_rates'] = 0;
                        $_SESSION['Bank_rates'] = 0;
                        $_SESSION['Bank_rates_not_validated'] = 0;
                        $_SESSION['Exchange_rates'] = 0;
                        foreach ($results as $row) 
                        {
                                //Donn�es BCC
                                if($row['Account_3']==0 && $row['Makerid_10']==0 && $row['Checkerid_11']==0)
                                {
                                        $_SESSION['Bcc_rates'] = json_encode($row);
                                }
                                elseif($row['Account_3']==$account_id)
                                {
                                        if($row['Checkerid_11']==0)
                                        {
                                                $_SESSION['Exchange_rates'] = 1;
                                                $_SESSION['Bank_rates_not_validated'] = json_encode($row);
                                        }
                                        else
                                        {
                                                $_SESSION['Bank_rates'] = json_encode($row);
                                                $_SESSION['Bank_rates_not_validated'] = 0;
                                                $_SESSION['Exchange_rates'] = 2;
                                        }
                                }
                        }
                }
                else
                {
                        $_SESSION['Exchange_rates'] = 0;
                }
                return true;
        }
        
        public function get_easybusy_exchange_rates() 
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                $agence = '';
                if(isset($_SESSION['Logiref_agence'])) $agence = $_SESSION['Logiref_agence'];
                $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                $this->db->limit(1);
                $query = $this->db->get('logiref_taux');
                $results = $query->result_array();
                
                if(!empty($results))
                {
                        $_SESSION['Bcc_rates'] = 0;
                        $_SESSION['Bank_rates'] = 0;
                        $_SESSION['Bank_rates_not_validated'] = 0;
                        $_SESSION['Exchange_rates'] = 0;
                        foreach ($results as $row) 
                        {
                                //Donn�es BCC
                                if($row['Account_3']==0 && $row['Makerid_10']==0 && $row['Checkerid_11']==0)
                                {
                                        $_SESSION['Bcc_rates'] = json_encode($row);
                                        $_SESSION['Makerid'] = 0;
                                }
                                elseif($row['Account_3']==$account_id)
                                {
                                        if($row['Checkerid_11']==0)
                                        {
                                                $_SESSION['Exchange_rates'] = 1;
                                                $_SESSION['Makerid'] = $row['Makerid_10'];
                                                $_SESSION['Bank_rates_not_validated'] = json_encode($row);
                                        }
                                        else
                                        {
                                                $_SESSION['Bank_rates'] = json_encode($row);
                                                $_SESSION['Bank_rates_not_validated'] = 0;
                                                $_SESSION['Exchange_rates'] = 2;
                                                $_SESSION['Makerid'] = $row['Makerid_10'];
                                        }
                                }
                        }
                }
                else
                {
                        $_SESSION['Exchange_rates'] = 0;
                        $_SESSION['Makerid'] = 0;
                }
                return true;
        }
        
        public function get_taux_by_filter($agence = NULL, $date_start = NULL, $date_end = NULL)
        {   
            
                if(!empty($agence) || !empty($date_start) || !empty($date_end))
                {
                        if(!empty($agence) && !empty($date_start) && !empty($date_end))
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata('account_id') . " AND Agence_8 ='".$agence."'";
                                $this->_table_name = '';
                                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 ASC');
                                $this->db->from('logiref_taux');
                                $this->db->where($st1, NULL, FALSE);
                                $this->db->where('Day_9 >=', $date_start);
                                $this->db->where('Day_9 <=', $date_end);
                                $this->db->order_by('Id_0 ASC');

                        }
                        elseif (!empty($agence)) 
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata('account_id') . " AND Agence_8 ='".$agence."'";
                                $this->_table_name = '';
                                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 ASC');
                                $this->db->from('logiref_taux');
                                $this->db->where($st1, NULL, FALSE);
                                $this->db->order_by('Id_0 ASC');
                        }
                        elseif (!empty($date_start) && !empty($date_end)) 
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata('account_id') . " ";
                                $this->_table_name = '';
                                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 ASC');
                                $this->db->from('logiref_taux');
                                $this->db->where($st1, NULL, FALSE);
                                $this->db->where('Day_9 >=', $date_start);
                                $this->db->where('Day_9 <=', $date_end);
                                $this->db->order_by('Id_0 ASC');
                        }
                        return $this->get_all();
                }
            
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_taux($data, $id) {
                $this->set_table('logiref_taux', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }	
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}