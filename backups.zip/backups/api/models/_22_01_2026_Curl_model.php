<?php
class Curl_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        //LOGS 
	public function call_set_log($data, $type=NULL)
	{
                $url = $_SERVER["SERVER_NAME"].$_SERVER["PHP_SELF"];
                $log['url']= $url;
                $log['message'] = $data;
                $log['bank_name'] = $this->session->userdata('account_business');

                if($type == NULL)
                {
                        $url = base_url('api/logs/logiref/encaissement/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);

                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                elseif($type == "sydonia")
                {
                        $url = base_url('api/logs/logiref/sydonia/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);
		
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                elseif($type=="isys")
                {
                        $url = base_url('api/logs/logiref/isys/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);

                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                elseif($type=="quittance")
                {
                        $url = base_url('api/logs/logiref/quittance/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);
	
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                $response = $this->curl->execute();
	}
        
        //DGI 
	public function call_dgi_declaration($data)
	{
                $url = base_url('api/endpoints/declaration/declaration.php');
                
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
		
                $response = $this->curl->execute();
                
                return $response;
	}
        
        public function call_logirad($data)
	{
                //Fonction a activer apres integration avec la DGI
                //Ou apres integration du Internet banking
                /* 
                $url = base_url('api/endpoints/declaration/declaration.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                */
                return NULL;
	}
        
        //DGRAD-Logirad
        public function call_dgrad_notes($data)
	{
                $data['User'] = $this->session->userdata('user_id');
                $data['Account'] = $this->session->userdata('account_id');
                $data['Agence'] = $_SESSION['Logiref_guichet'];
                
              	$url = base_url('api/endpoints/logirad/checknote.php');
                $this->load->library('curl');
                $this->curl->create($url);
                
		//$this->curl->option('SSL_VERIFYPEER',0);
		//$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($data);
                $response = $this->curl->execute();
                
                return $response; 
	}
        
	//DGRAD-Logirad Passport
	public function call_dgrad_notes_passport($data)
	{
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['Reference_8'] = $data['Reference_8'];
                
              	$url = base_url('api/endpoints/logirad/checknote.passport.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                if($response==false)
                {
                        return 'E404';
                }
                else
                {
                        return $response; 
                }
                
	}
	
	//DGRAD-Logirad Passport Test
	public function call_dgrad_notes_passport_test($data)
	{
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['Reference_8'] = $data['Reference_8'];
                
              	$url = base_url('api/endpoints/logirad/checknote.passport2.php');
                $this->load->library('curl');
                $this->curl->create($url);
//		$this->curl->option('SSL_VERIFYPEER',0);
//		$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                if($response==false)
                {
                        return 'E404';
                }
                else
                {
                        return $response; 
                }
                
	}
        
        public function call_dgrad_confirm_passport($data)
        {
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
                
//                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['numeroNotePerception'] = $data['note_number'];
                $apidata['numeroPaiement'] = $data['payment_number'];
                $apidata['datePaiement'] = date("Y-m-d h:i:s");
                $apidata['devise'] = $data['currency'];
                $apidata['montant'] = $data['amount'];
                $apidata['tauxChange'] = $data['exchange_rate'];
                $apidata['codeBanque'] = $data['bank_code'];
                $apidata['codeAgence'] = $data['agency_code'];
                $apidata['agence'] = $data['agency'];
                
              	$url = base_url('api/endpoints/logirad/confirmnote.passport.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                if($response==false)
                {
                        return 'E404';
                }
                else
                {
                        return $response; 
                }
        }
		
		public function call_dgrad_confirm_passport_online($data)
        {
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
//                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['numeroNotePerception'] = $data['note_number'];
                $apidata['numeroPaiement'] = $data['payement_number'];
                $apidata['datePaiement'] = date("Y-m-d h:i:s");
                $apidata['devise'] = $data['currency'];
                $apidata['montant'] = $data['amount'];
                $apidata['tauxChange'] = $data['exchange_rate'];
                $apidata['codeBanque'] = $data['bank_code'];
                $apidata['codeAgence'] = $data['agency_code'];
                $apidata['agence'] = $data['agency'];
                
              	$url = base_url('api/endpoints/logirad/confirmnote.passport.online.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                if($response==false)
                {
                        return 'E404';
                }
                else
                {
                        return $response; 
                }
        }
		
		public function call_dgrad_confirm_passport_online_test($data)
        {
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
//                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['numeroNotePerception'] = $data['note_number'];
                $apidata['numeroPaiement'] = $data['payement_number'];
                $apidata['datePaiement'] = date("Y-m-d h:i:s");
                $apidata['devise'] = $data['currency'];
                $apidata['montant'] = $data['amount'];
                $apidata['tauxChange'] = $data['exchange_rate'];
                $apidata['codeBanque'] = $data['bank_code'];
                $apidata['codeAgence'] = $data['agency_code'];
                $apidata['agence'] = $data['agency'];
                
              	$url = base_url('api/endpoints/logirad/confirmnote.passport.online.test.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                if($response==false)
                {
                        return 'E404';
                }
                else
                {
                        return $response; 
                }
        }
        
        public function call_dgrk_notes($data)
	{
                $data['user'] = $this->session->userdata('user_id');
                $data['account'] = $this->session->userdata('account_id');
                $data['agence'] = $_SESSION['Logiref_guichet'];
              	$url = base_url('api/endpoints/dgrk/get_declaration.php');
                
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($data);
                $response = $this->curl->execute();
                
		if($response == false)
		{
			echo 'E404';
		}
                else
                {
                        return $response; 
		}
	}
        
        public function call_dgrk_confirm_notes($data)
	{
                $data['user'] = $this->session->userdata('user_id');
                $data['account'] = $this->session->userdata('account_id');
                $data['agence'] = $_SESSION['Logiref_guichet'];
                
              	$url = base_url('api/endpoints/dgrk/confirm_payment.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($data);
                $response = $this->curl->execute();
                
		if($response == false)
		{
			echo 'E404';
		}
                else
                {
                        return $response; 
		}
	}
        
        public function call_dgrk_dropdown($type)
	{
                $data['user'] = $this->session->userdata('user_id');
                $data['account'] = $this->session->userdata('account_id');
                $data['agence'] = $_SESSION['Logiref_guichet'];
                $data[''] = $_SESSION['Logiref_guichet'];
              	$url = base_url('api/endpoints/dgrk/dropdown.php?obj='.$type);
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($data);
                $response = $this->curl->execute();
                
		if($response == false)
		{
			echo 'E404';
		}
                else
                {
                        return $response; 
		}
	}
        
        //DGDA
        public function call_dgda_declaration($data)
	{
                $response = $data;
                return $response;
	}
        
        //DGDA
        public function call_dgda_prepayments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                
                $apidata['bank'] = (isset($encryption->codebank))? $encryption->codebank :'';
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['Office'] = $_POST['Office'];
		$apidata['Agence'] = $_SESSION['Logiref_guichet'];
                
                $url = base_url('api/endpoints/sydonia/prepaymentsList.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        //DGDA
        public function call_dgda_send_ack_prepayments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                
                $apidata['messageKey'] = $_POST['messageKey'];
                $apidata['codeTr'] = $_POST['codeTr'];
                $apidata['Account'] = $this->session->userdata('account_id');
                
                $url = base_url('api/endpoints/sydonia/prepaymentsAck.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        //BANK
        public function call_bank_comptant($data)
	{
			set_time_limit(250);
			$url = base_url('api/endpoints/bank/ebcdc/comptant.php');
			$this->load->library('curl');
			$this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);

			$this->curl->post($data);
			$response = $this->curl->execute();
			return $response;
	}
	
	public function call_bank_payment_amount($credentials)
	{
			set_time_limit(250);
			$encryption = json_decode($credentials->Password_18);
            
			$notemontant = str_replace(' ','',$_POST['Amount']);
			$Amount = str_replace(',','.',$notemontant);
			$apidata = array();
			$apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
			$apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
			
			$apidata['Amount'] = intval($Amount);
			$apidata['Year'] = $_POST['Year'];
			$apidata['Series'] = $_POST['Series'];
			$apidata['Number'] = $_POST['Number'];
			$apidata['Agent'] = $_POST['Agent'];
			$apidata['Office'] = $_POST['Office'];
			$apidata['Nif'] = $_POST['Nif'];
			$apidata['Account'] = $this->session->userdata('account_id');
			$apidata['Bank'] = $_POST['Bank'];
			$apidata['User'] = $this->session->userdata('user_id');
		
			$url = base_url('api/endpoints/sydonia/get.payment.amount.php');
			$this->load->library('curl');
			$this->curl->create($url);
			$this->curl->option('SSL_VERIFYPEER',0);
			$this->curl->option('SSL_VERIFYHOST',0);
			$this->curl->post($apidata);
			$response = $this->curl->execute();
	
			return $response;
	}
        
        //BANK
        public function call_bank_virement($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/virement.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
	//BANK
	public function call_bank_virement_passport($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/virement.passport.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
	
	//BANK
	public function call_bank_virement_passport_online($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/virement.passport.online.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
	
  //BANK TEST
	public function call_bank_virement_passport_test($data)
	{
				
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/virement.passport.online.test.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
				
                return $response;
	}
        
        //BANK
        public function call_bank_batch_debit($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/batch_debit.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_checkbalance($data)
	{
                $response = '';
                $url = base_url('api/endpoints/bank/check.balance.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_account_info($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/account.info.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
				
                return $response;
	}
        
	public function call_bank_trans_details($data)
	{
		set_time_limit(250);
		$response = '';
		$url = base_url('api/endpoints/bank/ebcdc/trans.details.php');
		$this->load->library('curl');
		$this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
		$this->curl->post($data);
		$response = $this->curl->execute();
		//var_dump($response); die;
	   
		return $response;
	}
		
        public function call_bank_send_sms($data)
	{
                $url = base_url('api/endpoints/bank/ebcdc/send.sms.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                
                $this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                
                $response = $this->curl->execute();
                
                return $response;
	}

	public function call_bank_account_internal_info($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/account.internal.info.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        //BANK
        public function call_bank_tax_exempt($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/tax.exempt.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_exchange_rate($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/exchange.rate.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        //BANK
        public function call_bank_reservation($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/reservation.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_cancel_reservation($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/ebcdc/cancel.reservation.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
	//DGDA
        public function call_dgda_checkbl_credit($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['refcredit'] = $_POST['refcredit'];
                $apidata['Account'] = $this->session->userdata('account_id');
                
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $url = base_url('api/endpoints/sydonia/checkblcredit.php');
                $this->load->library('curl');
                $this->curl->create($url);
				
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);
		
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        //DGDA
        public function call_dgda_checkbl($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $url = base_url('api/endpoints/sydonia/checkbl.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
		
		//DGDA
        public function call_dgda_checkbl_mobile($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $url = base_url('api/endpoints/sydonia/checkbl.single.mobile.php');
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        //BANK
        public function call_bank_comptant_single($credentials)
	{
                $taux = "";// Donnees test
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'] ;
				
                $apidata['Commission'] = $_POST['Commission'];// Donnees test
                $apidata['Total_amount'] = $_POST['Total_amount'];// Donnees test
				
                $apidata['Devise_commission'] = $_POST['Devise_commission'];// Donnees test
                
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                
                $apidata['Agence'] = $_POST['Agence'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['Taux'] = $_POST['Taux'];
                $apidata['bank_account'] = $_POST['bank_account'];
                $apidata['Devise_account'] = $_POST['Devise_account'];
                $apidata['account_name'] = '';
                
                $url = base_url('api/endpoints/sydonia/comptant.single.php');
                
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                return $response;
	}
	
	   //BANK
        public function call_bank_comptant_single_mobile($credentials)
	{
                $taux = "";// Donnees test
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'] ;
				
                $apidata['Commission'] = $_POST['Commission'];// Donnees test
                $apidata['Total_amount'] = $_POST['Total_amount'];// Donnees test
				
                $apidata['Devise_commission'] = $_POST['Devise_commission'];// Donnees test
                
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                
                $apidata['Agence'] = $_POST['Agence'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['Taux'] = $_POST['Taux'];
                $apidata['bank_account'] = $_POST['bank_account'];
                $apidata['Devise_account'] = $_POST['Devise_account'];
                $apidata['account_name'] = '';
                
                $url = base_url('api/endpoints/sydonia/comptant.single.mobile.php');
                
                $this->load->library('curl');
                $this->curl->create($url);
				$this->curl->option('SSL_VERIFYPEER',0);
				$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                return $response;
	}
	
         public function call_bank_credit_single($credentials)
	{
                if($_POST['Taux'] == "")
                {
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];
                }
                
                $encryption = json_decode($credentials->Password_18);
                        
                $notemontant = str_replace(' ','',$_POST['Amount']);
                $Amount = str_replace(',','.',$notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'];
                
                $apidata['Commission'] = str_replace(' ', '', $_POST['Commission']);
                $apidata['Commission'] = str_replace(',', '.', $apidata['Commission']);
                $apidata['Total_amount'] = str_replace(' ', '', $_POST['Total_amount']);
                $apidata['Devise_commission'] = $_POST['Devise_commission'];
                
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['Taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux;
                $apidata['bank_account'] = isset($_POST['bank_account']) ? $_POST['bank_account'] : "";
                $apidata['Devise_account'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                $apidata['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                $apidata['refcredit'] = $_POST['refcredit'];
                $url = base_url('api/endpoints/sydonia/credit.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
				
                $this->curl->option('SSL_VERIFYPEER',0);
                $this->curl->option('SSL_VERIFYHOST',0);
				
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                
                return trim($response);
	}
         //BANK
        public function call_bank_comptant_batch($data)
	{
                $url = base_url('api/endpoints/sydonia/comptant.batch.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
	}
        
        public function call_dgda_payments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                $apidata['password'] = (isset($encryption->encryption))? $encryption->encryption:'';
                
                $taux = json_decode($_SESSION['Bank_rates'], true);
                $taux = $taux['Dollar_4'];
                
                $apidata['guichet'] = $_POST['guichet'];
                $apidata['User'] = $this->session->userdata('user_id');
                $apidata['Account'] = $this->session->userdata('account_id');
                $apidata['Office'] = $_POST['Office'];
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['cGuichet'] = $_POST['cGuichet'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['designation'] = $_POST['designation'];
                $apidata['taux'] = $taux;
                $apidata['Logirefid'] = $_POST['Logirefid'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $url = base_url('api/endpoints/sydonia/paymentsList.php');
               
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        public function call_dgda_quittance($data)
        {
                $url = base_url('api/endpoints/sydonia/quittance.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
        }
        
        
        
        public function call_bank_licence_bcc($data)
	{
                $response = '';        
                $url = base_url('api/endpoints/sydonia/declarationsList.php');
                $this->load->library('curl');
                $this->curl->create($url);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        public function call_bank_regularization($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/regularize.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        //BANK
        public function call_bank_reversepayment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/ebcdc/extourne.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
}
