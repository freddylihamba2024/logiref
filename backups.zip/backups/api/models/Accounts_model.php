<?php
class Accounts_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        public $type_service = array(
                            ''=>'',
                            'DGE' => 'Direction des grandes entreprises', 
                            'CDI' => 'Centre d\'imp&ocirc;t',
                            'CIS' => 'Centre d\'imp&ocirc;t synth&eacute;tique'
                        );
	
	public function __construct()
	{
		parent::__construct();
                $this->load->model('ebcdc/branches_model');
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Type_4 = '';
                        $obj->Beneficiaires_5 = '';
                        $obj->Compte_6 = '';
                        $obj->Clef_7 = '';
                        $obj->Devise_8 = '';
                        $obj->Makerid_9 = '';
                        $obj->Validation_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Recette_13 = '';
                        $obj->Ville_14 = '';
                        $obj->Agenceid_15= '';
                        $obj->Serviceid_16= '';
                        $obj->Nif_17	= '';
                        $obj->Comptesydonia_18	= '';
                        $obj->Code_agence_19 = '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_comptes p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_prepaid_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Nifimportateur_7 = '';
                        $obj->Accountnumber_8 = '';
                        $obj->Refsydonia_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Makerid_11 = '';
                        $obj->Checkerid_12 = '';
                        $obj->Validation_13 = '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_prepaid_accounts p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_clientexonere_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Beneficiaires_7 = '';
                        $obj->Compte_8 = '';
                        $obj->Agenceid_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Validation_13 = '';
                        $obj->Devise_14 = '';
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_client_exonere l', 'l.Id_0', 'l.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='".$account_id."'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
	}
        
        public function get_latest_validated_accounts()
	{
                $this->_table_name = '';
                $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 ASC');
                $this->db->from('logiref_comptes');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_11 !='0'"; 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 ASC');
                $this->db->limit(20);
                return $this->get_all();
	}
        
        public function get_agence_accounts()
	{
                $guichet = $_SESSION['Logiref_guichet'];
                
                $this->_table_name = '';
                $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 ASC');
                $this->db->from('logiref_comptes');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Agence_12 = '".$guichet."'"; 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 ASC');
                return $this->get_all();
	}
        
        public function get_account_tariff($guichet=NULL,$data=NULL,$regie=NULL)
        {
                $this->_table_name = '';
                
                $this->db->select('logiref_client_exonere.*', 'logiref_client_exonere.Date_1 DESC');
                $this->db->from('logiref_client_exonere');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Changer_6 !='0'"; 
                if($guichet!=NULL){$st.= " AND Agenceid_9='".$guichet."'";}
                if($data!=''){$st.= " AND Compte_8 ='".$data."'";}
                if($regie!=''){$st.= " AND Beneficiaires_7 ='".$regie."'";}
               
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
                
        }
        
        
        public function get_comptes($type=NULL) 
        {
                $this->_table_name = '';
                
                if($type=='cptes')
                {
                        $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 DESC');
                        $this->db->from('logiref_comptes');
                        $st = "Status_2 !='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_11 ='0'"; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
                else
                {
                        $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 DESC');
                        $this->db->from('logiref_comptes');
                        $st = "Status_2='1' AND Beneficiaires_5='" .$_SESSION['Logiref_regies']. "'"; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }

        }
        
        public function get_clientexoneres($type=NULL) 
        {
                $this->db->select('logiref_client_exonere.*', 'logiref_client_exonere.Date_1 DESC');
                $this->db->from('logiref_client_exonere');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Changer_6 ='0'"; 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_filtered_accounts($data)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "'"; 
                if(isset($data['type']) && $data['type'] !="") $st.= " AND Type_4 ='".$data['type']."'";
                if(isset($data['agence']) && $data['agence'] !="") $st.= " AND Agence_12 ='".$data['agence']."'";
                if(isset($data['taxe']) && $data['taxe'] !="") $st.= " AND Recette_13 ='".$data['taxe']."'";
                if(isset($data['bureau']) && $data['bureau']) $st.= " AND Serviceid_16 ='".$data['bureau']."'";
                if(isset($data['devise']) && $data['devise']) $st.= " AND Devise_8 ='".$data['devise']."'";
                
                $this->_table_name = '';
                $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 DESC');
                $this->db->from('logiref_comptes');
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function get_export_comptes()
        {
                $this->db->select('logiref_comptes.*', 'logiref_comptes.Date_1 DESC');
                $this->db->from('logiref_comptes');
                $st = "Status_2 !='0' AND Account_3='" . $this->session->userdata('account_id') . "'"; 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function get_filtered_tarifications($data)
        {
               
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "'"; 
                if(isset($data['agence']) && $data['agence'] !="") $st.= " AND Agence_12 ='".$data['agence']."'";
                if(isset($data['beneficiaires']) && $data['beneficiaires'] !="") $st.= " AND Beneficiaires_7 ='".$data['beneficiaires']."'";
                if(isset($data['devise']) && $data['devise']) $st.= " AND Devise_10 ='".$data['devise']."'";
                
                $this->_table_name = '';
                $this->db->select('logiref_client_exonere.*', 'logiref_client_exonere.Date_1 DESC');
                $this->db->from('logiref_client_exonere');
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        
        #Recuperer la devise par rapport ? un compte
        public function get_comptes_by_parameters($compte = NULL, $devise = NULL, $type = NULL, $beneficiaire = NULL, $agence = NULL, $recette = NULL, $service = NULL)
        {
                $account_id = $this->session->userdata('account_id');
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                $array = array('Account_3'=>$account_id,'Type_4'=>$type,'Compte_6'=>$compte, 'Beneficiaires_5'=>$beneficiaire, 'Devise_8'=>$devise, 'Agence_12'=>$agence);
                if(isset($recette))$array["Recette_13"] = $recette;
                if(isset($service))$array["Serviceid_16"] = $service;
                
                return $this->get_by($array, TRUE);
        }
        
        public function get_compte_by_number($data=NULL) 
        {
                $account_id = $this->session->userdata('account_id');
                
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Compte_6'=>$data,'Account_3' =>$account_id), TRUE);
        }
        
        public function get_comptes_array($liste='', $agence_src=NULL, $agence_dst=NULL, $regie =NULL, $service = NULL, $recette = NULL) 
        {
      
                
                $main_branches = $this->branches_model->get_dropdown('main_branch');
           
                $branch_id = $_SESSION['Logiref_guichet'];
                
                $branch_code = isset($main_branches[$branch_id]) ? $main_branches[$branch_id] : 0;
                
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0' ";
                
                if($liste!='') $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 = '".$agence_src."' "; 
                   
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                $res=$query->result_array();
				
				
                foreach ($query->result_array() as $row) 
                {
                        if($row['Type_4'] != "" && ($row['Type_4'] == 'CPT' || $row['Type_4'] == 'CTP'  || $row['Type_4'] == 'CFE' || $row['Type_4'] == 'CGU' || $row['Type_4'] == 'CPI') && $row['Code_agence_19'] == $branch_code)
                        {      
                                if($row['Recette_13']=="27022470" || $row['Recette_13']=="27421600")
                                {
                                        if($row['Agenceid_15'] !="")
                                        {
                                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                        }
                                        else
                                        {
                                                $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        }
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] == $service && $row['Recette_13'] =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        if($row['Type_4'] != "" && ($row['Type_4'] == 'FBC' || $row['Type_4'] == 'CSO' || $row['Type_4'] == 'CSI'))
                        {
                                if($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $recette =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =='')
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Agence_12'] != "" && $row['Agence_12'] == $agence_src && ($row['Type_4'] =='CFB' || $row['Type_4'] =='CFP' || $row['Type_4'] =='TVA' ))
                        {
                                if($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $recette =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Type_4']!="" && $row['Type_4']=="CSP" && $row['Devise_8'] =="USD" && $row['Agence_12'] == $agence_src)
                        {
                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        }
                        
                }
                
                return $comptes;
        }
		
		public function get_comptes_array_cashcloud($liste='', $agence_src=NULL, $agence_dst=NULL, $regie =NULL, $service = NULL, $recette = NULL) 
        {
      
                
                $main_branches = $this->branches_model->get_dropdown('main_branch');
           
                $branch_id = $_SESSION['Logiref_guichet'];
                
                $branch_code = isset($main_branches[$branch_id]) ? $main_branches[$branch_id] : 0;
                
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0' ";
                
                if($liste!='') $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 = '".$agence_src."' "; 
                   
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                $res=$query->result_array();
				
				
				
                foreach ($query->result_array() as $row) 
                {
                        if($row['Type_4'] != "" && ($row['Type_4'] == 'CPT' || $row['Type_4'] == 'CTP'  || $row['Type_4'] == 'CFE' || $row['Type_4'] == 'CGU' || $row['Type_4'] == 'CPI') && $row['Code_agence_19'] == $branch_code)
                        {      
                                if($row['Recette_13']=="27022470" || $row['Recette_13']=="27421600")
                                {
                                        if($row['Agenceid_15'] !="")
                                        {
                                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                        }
                                        else
                                        {
                                                $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        }
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] == $service && $row['Recette_13'] =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        if($row['Type_4'] != "" && ($row['Type_4'] == 'FBC' || $row['Type_4'] == 'CSO' || $row['Type_4'] == 'CSI'))
                        {
                                if($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $recette =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =='')
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Agence_12'] != "" && $row['Agence_12'] == $agence_src && ($row['Type_4'] =='CFB' || $row['Type_4'] =='CFP' || $row['Type_4'] =='TVA' ))
                        {
                                if($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="" && $recette =="TVA" && $row['Devise_8'] =="CDF")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="" && $service !="" && $row['Serviceid_16'] !="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Type_4']!="" && $row['Type_4']=="CSP" && $row['Devise_8'] =="USD" && $row['Agence_12'] == $agence_src)
                        {
                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        }
                        
                }
                
                return $comptes;
        }
        
        public function get_agence_comptes_array($liste='', $agence) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                foreach ($query->result_array() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_recettes_agence_array($liste='', $agence, $beneficiaire = NULL) 
        {
                $main_branches = $this->branches_model->get_dropdown('main_branch');
                $branch_id = $_SESSION['Logiref_guichet'];
                
                $branch_code = isset($main_branches[$branch_id]) ? $main_branches[$branch_id] : 0;
                
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Code_agence_19 = '".$branch_code."' ";
				
                $st .= " AND Type_4 IN (" . $liste . ")";
                if($beneficiaire != "") $st .= " AND Beneficiaires_5 ='".$beneficiaire."' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                foreach ($query->result_array() as $row) 
                {
                        if($row['Recette_13'] == 'TVA' && $row['Beneficiaires_5'] == 'DGDA')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Recette_13'] != 'TVA')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];
                                }
                        }
                }
                return $comptes;
        }
        
        public function get_comptescfb_recette_array($liste='', $recette, $instution) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 = '".$recette."'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                $results = $query->result_array();
                
                if(empty($results))
                {
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Regie_14='' AND  Recette_13 = '".$recette."'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13='' AND Regie_14 = '".$instution."'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13 ='' AND Regie_14 = '".$instution."'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 = '' AND Regie_14=''";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14='' ";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }

                foreach ($results as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
                
        }
        
        public function get_comptescfb_agence_array($liste='', $instution) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13='' AND Regie_14 = '".$instution."'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                $results = $query->result_array();
               
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13 ='' AND Regie_14 ='".$instution."'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 ='' AND Regie_14=''";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14=''";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                foreach ($results as $row) 
                {
                       
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
                
        }
        
        public function get_recette_comptes_array($liste='', $agence) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                foreach ($query->result_array() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_by_type_array($liste='', $regie=NULL) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND  Regie_14 = '".$regie."'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                $results = $query->result_array();
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 ='' AND Regie_14=''";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                if(empty($results))
                {
                        
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14=''";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        $results = $query->result_array();
                }
                
                foreach ($results as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function tcheck_prepaid_account($account=NULL, $devise=NULL)
        {
                $account_id = $this->session->userdata('account_id');
                $this->set_table('logiref_prepaid_accounts ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' =>$account_id, 'Devise_10'=>$devise, 'Accountnumber_8'=>$account), TRUE);
        }
        
        public function get_prepaid_comptes($type=NULL) 
        {
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "')"; 
                $query = $this->db->select('*')
                ->from('logiref_prepaid_accounts')
                ->where($st, NULL, FALSE)
                ->get();
                return $query->result();

        }
        
        public function get_prepaid_comptes_array($type=NULL, $agence) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $type . ") AND Agence_12 =".$agence."";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_comptes');
                foreach ($query->result_array() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_prepaid_compte_by_refsydonia($account)
        {
                $account_id = $this->session->userdata('account_id');
                $this->set_table('logiref_prepaid_accounts ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' =>$account_id, 'Comptesydonia_18'=>$account), TRUE);
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_prepaid_accounts($data, $id) {
                $this->set_table('logiref_prepaid_accounts', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_compte($data, $id)
        {
                $this->set_table('logiref_comptes', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_tarification_account($data, $id)
        {
                $this->set_table('logiref_client_exonere', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function delete_account($data, $id)
	{
		$this->set_table('logiref_comptes', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}