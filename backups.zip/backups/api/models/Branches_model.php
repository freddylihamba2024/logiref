<?php
class Branches_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_guichet_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Nom_4 = '';
                        $obj->Agence_5 = '';
                        $obj->Province_6 = '';
                        $obj->Ville_7 = '';
                        $obj->Adresse_8 = '';
                        $obj->Observation_9 = '';
                        $obj->Code_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Validation_12 = '';
                        $obj->Agence_principale_14 ='';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_guichets p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="guichets")
                {   
                        if($_SESSION['Logiref_groupe']=='banks')
                        {
                                $agence = $arg;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                                if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_guichets');
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                           
                                $st = "Status_2='1'";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_guichets');
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="agences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_agences');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                elseif($item=="codeagences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Code_10'];
                        }
                        return $ddmenu;
                }
               elseif($item=="agence_principale")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Code_10']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                elseif($item=="main_branch")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Agence_principale_14'];
                        }
                        return $ddmenu;
                }
        
        
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_agences($type=NULL)
        {
                $this->_table_name = '';
                $this->db->select('logiref_agences.*', 'logiref_agences.Id_0 ASC');
                $this->db->from('logiref_agences');
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata('account_id') . "')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }
        
        public function get_branches_by_account_id()
        {
                $aid = $_SESSION['Logiref_guichet'];
                $this->set_table('logiref_guichets', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Id_0' => $aid), TRUE);
        }
        
        public function get_branche_by_service($service = NULL)
        {
                $this->_table_name = '';
                $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                $this->db->from('logiref_guichets');
                //$st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Bureau_15 LIKE '%".$service."|%' ";
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND  Id_0 = '62'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
		
		public function get_branche_by_dgda_service($service = NULL)
        {
				
                $this->_table_name = '';
                $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                $this->db->from('logiref_guichets');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Bureau_15 LIKE '%".$service."|%' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
		
		public function get_branche_by_agence($service = NULL)
        {
                $this->_table_name = '';
                $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                $this->db->from('logiref_guichets');
                //$st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Bureau_15 LIKE '%".$service."|%' ";
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' AND Id_0 = '139' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_branches($type=NULL)
        {
            
                $this->_table_name = '';
                $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                $this->db->from('logiref_guichets');
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata('account_id') . "') AND Agence_5='" . $_SESSION['Logiref_agence'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
         public function get_guichets($type=NULL) 
        {
                $this->_table_name = '';
                
                if($type=='Guichet')
                {
                        $this->db->select('logiref_guichets.*', 'logiref_guichets.Date_1 DESC');
                        $this->db->from('logiref_guichets');
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata('account_id') . "' "; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
                else
                {
                        $this->db->select('logiref_guichets.*', 'logiref_guichets.Date_1 DESC');
                        $this->db->from('logiref_guichets');
                        $st = "Status_2='1' "; 
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
            
        }
        
        
        #Checks if an agency has already been created with the entered code
        public function get_code_exists($code = NULL)
        {
                $account_id = $this->session->userdata('account_id');
                $this->set_table('logiref_guichets ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Code_10 '=>$code), TRUE);
        }
        
        
        // 
        public function get_info_guichet_by_codebank($codebank)
        {
                $this->set_table('logiref_guichets g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Code_10' => $codebank), TRUE);
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_branche($data, $id) {
                $this->set_table('logiref_guichets', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        
        
}