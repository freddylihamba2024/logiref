<?php
class Reports_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
	
        public $regies = array(
            ''=>'',
            'DGI'=>'DGI',
            'DGRAD'=>'DGRAD'
        );
        
        
        
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_validated_paiements_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND (Status_2 = 1 OR Status_2 = 3) AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
                
                $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
	
	public function get_validated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_unvalidated_paiements_dgrk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_paiements_propres.*');
                $this->db->from('logiref_paiements_propres');
                $this->db->where("logiref_paiements_propres.Account_3 ='".$account_id."' AND Beneficaire_15 = 'DGRK' AND Checkerid_10='0' AND Status_2=1 ");
                $this->db->order_by('logiref_paiements_propres.Id_0');
                return $this->get_all();
	}
        
        public function get_validated_paiements_dgrk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_paiements_propres.*');
                $this->db->from('logiref_paiements_propres');
                $this->db->where("logiref_paiements_propres.Account_3 ='".$account_id."' AND Beneficaire_15 = 'DGRK' AND Checkerid_10 !='0' AND Status_2=1 ");
                $this->db->order_by('logiref_paiements_propres.Id_0');
                return $this->get_all();
	}
        
        public function get_paiements_tresor($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Sydonia_44 = 0 ";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_paiements_tresor_gu($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND (Sydonia_44 != 0 OR Sydonia_49 != 0) AND Status_2 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_paiements_propres_gu($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND (Sydonia_44 != 0 OR Sydonia_49 != 0) AND Status_2 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_paiements_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Sydonia_44 = '0' ";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_fond_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND 	Beneficaire_15 != 'DGDA' AND Sydonia_44 =0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_fond_tresor($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "'";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function get_report_paiements($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0";
                #Restriction
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_filter_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
					$user = $this->session->userdata('user_id');
					
			$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
					
					#Filtre d'affichage
					if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
					if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
					
	 
					#Restriction
					if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
					if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
					
					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
        
        public function get_paiements_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                 $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
	
		public function get_eazzybiz_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
					$user = $this->session->userdata('user_id');
					
					$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0   AND Type_53='mobile'";
					
					#Restriction
					if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
					if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
					
					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
		
		        
        public function get_eazzybiz_paiements_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
					$user = $this->session->userdata('user_id');
					
					$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = "Account_3='" . $this->session->userdata('account_id') . "' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Type_53='mobile'";
					
					#Restriction
					$st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
					
					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}