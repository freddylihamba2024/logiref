<?php
class Encaissement_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $documents = array(
                            '1' => 'NOTE DE PERCEPTION', 
                            '2' => 'QUITTANCE',
                            '3' => 'BULLETIN DE LIQUIDATION', 
                            '4' => 'NOTE DE VERSEMENT', 
                            '5' => 'DECLARATION'
                        );
	public $devises = array(
                            ''=>'', 
                            'CDF' => 'CDF', 
                            'USD' => 'USD', 
//                            'EUR' => 'EUR', 
//                            'ZAF' => 'ZAF'
                        );
        public $modes = array(
                            ''=>'', 
                            '5' => 'ESPECE', 
                            '7' => 'OP', 
                            '8' => 'OV'
                        );
        public $reversementStatus = array(
                                        '1' => 'Reverser', 
                                        '2' => 'Regler', 
                                        '3' => 'Niveller'
                                    );
        public $infos = array(
                            'type' => '', 
                            'agence' => '', 
                            'reference' => '', 
                            'moyen' => '', 
                            'standard' => '',
                            'QuotasINPP' => '', 
                            'QuotasINSS' => '', 
                            'QuotasONEM' => '', 
                            'RefINSS' => '', 
                            'RefINPP' => '', 
                            'RefONEM' => '', 
                        ); 
        public $moyens = array(
                            '' => '', 
                            '10' => 'Especes',
                            '20' => 'Cheque', 
                            '21' => 'Lettre bancaire',
                            '22' => 'Lettre bancaire certifiee', 
                            '23' => 'Cheque bancaire (issu par banque ou etablissement financier simil.)', 
                            '24' => 'Cheque particulier signe par la banque',
                            '50' => 'Ordre', 
                            '80' => 'Paiement partiel', 
                            '90' => 'Consentement mutuel',
                        );
	public $order_status = array(
            
                '1'=>"En cours",
                '2'=>"Valid&eacute; (pay&eacute;)",
                '3'=>"Finalis&eacute; (rejet&eacute;)",
                '4'=>"Expir&eacute;",
                ''=>""
        );
        public $color_orders = array(
                '1'=>'label-upcoming',
                '2'=>'label-ongoing',
                '3'=>'label-cancelled',
                '4'=>'label-ongoing',
        );
        
        public $codes = array(
                'E162'=>'Le compte est inexistant',
                'E463'=>'La transaction n est pas &eacute;quilibr&eacute;e',
                'E3238'=>'Les détails suppl&eacute;mentaires ne sont pas saisis et Diff&eacute;rence de devise',
                'E397'=>'Les d&eacute;tails suppl&eacute;mentaires ne sont pas saisis',
                'W0205'=> 'Le montant du retrait ne peut pas d&eacute;passer le solde du compte',
        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_paiement_tresor_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata('account_id');
                        $obj->Logirefid_4 = $this->generate_unique_reference().$this->session->userdata('user_id');
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];
                        
                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';                        

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_order_info($id = NULL)
        {
                if($id == NULL)
                {
                        $order = new stdClass();
                        $order->Id_0 = '';
                        $order->Date_1 ='';
                        $order->Status_2='';
                        $order->Account_3 ='';
                        $order->Creator_4 ='';
                        $order->Changes_5 ='';
                        $order->Changer_6 ='';
                        $order->Regie_7 ='';
                        $order->Service_8 ='';
                        $order->Bank_9 ='';
                        $order->Account_10 ='';
                        $order->Currency_11 ='';
                        $order->Amount_12 ='';
                        $order->Object_13 ='';
                        $order->Nif_14 ='';
                        return $order;
                }
                else
                {
                        $this->set_table('logiref_payment_orders o', 'o.Id_0', 'o.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_paiement_propre_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata('account_id');
                        $obj->Logirefid_4 = $this->generate_unique_reference().$this->session->userdata('user_id');
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];
                        
                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';   
                        $obj->Edgrk_50 = '0'; 

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_paiement_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata('account_id');
                        $obj->Logirefid_4 = $this->generate_unique_reference().$this->session->userdata('user_id');
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = isset($_SESSION['Logiref_agence'])?$_SESSION['Logiref_agence']:"";
                        
                        $obj->Guichet_21 = isset($_SESSION['Logiref_guichet'])?$_SESSION['Logiref_guichet']:"";
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';                        

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function  check_bulletin_tresor($pkey)
        {
                $this->_table_name = '';
                
                $account = $this->session->userdata('account_id');
                $this->db->select('logiref_paiements_tresor.Paiementkey_52');
                $this->db->from('logiref_paiements_tresor');
                $this->db->where("logiref_paiements_tresor.Account_3 ='".$account."'");
                $this->db->where("logiref_paiements_tresor.Paiementkey_52 IN ($pkey)");
                $this->db->order_by('logiref_paiements_tresor.Id_0', 'logiref_paiements_tresor.Id_0 DESC');
                return $this->get_all();
        }
        public function  check_bulletin_propres($pkey)
        {
                $account = $this->session->userdata('account_id');
                $this->db->select('logiref_paiements_propres.Paiementkey_52');
                $this->db->from('logiref_paiements_propres');
                $this->db->where("logiref_paiements_propres.Account_3 ='".$account."'");
                $this->db->where("logiref_paiements_propres.Paiementkey_52 IN ($pkey)");
                $this->db->order_by('logiref_paiements_propres.Id_0', 'logiref_paiements_propres.Id_0 DESC');
                return $this->get_all();
        }
        public function  check_prepayment_tresor($id, $code_taxe)
        {
                $this->set_table('logiref_paiements_tresor t', 't.Id_0', 't.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id, 'Typerecette_17' => $code_taxe), TRUE);
        }
        public function  check_prepayment_propres($id, $code_taxe)
        {
                $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id, 'Typerecette_17' => $code_taxe), TRUE);
        }
        
        public function get_paiement_by_logirefid($logirefid)
        {
                $this->set_table('logiref_paiements_tresor t', 't.Id_0', 't.Id_0 DESC');
                return $this->get_by(array('Logirefid_4' => $logirefid), TRUE);
        }
        
		public function get_paiement_tresor_by_sydoniaid($id)
        {
				$this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
		}
		
		public function get_paiement_propres_by_sydoniaid($id)
        {
				$this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
		}
		
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="regies")
                {
                        $ddmenu['Regies'] = array(''=>'', 'DGI'=>'DGI', 'DGRAD'=>'DGRAD', 'DGDA'=>'DGDA');
                        return $ddmenu;
                }
        }
        
        
        public function get_paiement_tresor_by_logirefid($logirefid)
        {
                $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Logirefid_4' => $logirefid), TRUE);
        }
        
        public function get_paiement_propre_by_logirefid($logirefid)
        {
                $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Logirefid_4' => $logirefid), TRUE);
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_stats($type=NULL)
        {
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_4'];
                        $eur = $bank['Euro_5'];
                        $rand = $bank['Rand_6'];
                        $pound = $bank['Pound_7'];
                }
                if($type=='commission')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "1" => '0', //'Commission de l'annee,
                                "2" => '0', //'Commission du mois,
                                "3" => '0', //'Commission de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $query = $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC')
                                            ->where('Account_3',$this->session->userdata('account_id'))
                                            ->where('Agence_20',$_SESSION['Logiref_agence'])
                                            ->get('logiref_paiements_tresor');


                        foreach ($query->result_array() as $row)
                        {
                                //$stats['1'] = $stats['1'] + $row['Commission_23'];

                                $dateTime = new DateTime($row['Datevaleur_31']); $date= $dateTime->format('U'); 
                                $year = date('Y', strtotime("+0 day",$date));
                                $month = date('m', strtotime("+0 day",$date));

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Commission_23'];
                                        } 
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Commission_23'];
                                        }
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Commission_23'];
                                        }
                                }


                        }
                        
                        return $stats;
                }
                elseif($type=='paiement')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "1" => '0', //'Paiement de l'annee,
                                "2" => '0', //'Paiement du mois,
                                "3" => '0', //'Paiement de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $query = $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC')
                                            ->where('Account_3',$this->session->userdata('account_id'))
                                            ->where('Agence_20',$_SESSION['Logiref_agence'])
                                            ->get('logiref_paiements_tresor');


                        foreach ($query->result_array() as $row)
                        {
                                $dateTime = new DateTime($row['Datevaleur_31']); $date= $dateTime->format('U'); 
                                $year = date('Y', strtotime("+0 day",$date));
                                $month = date('m', strtotime("+0 day",$date));

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Montant_11'];
                                        }   
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Montant_11'];
                                        } 
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Montant_11'];
                                        } 
                                }

                        }
                        return $stats;
                }
                elseif($type=='paiement_guichet')
                {
                        if(!empty($data))
                        {
                                if(isset($data['agence']) && !empty($data['agence']))
                                {
                                        $st0 .= " AND Guichet_21 ='".$data['agence']."'";
                                }

                                if((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end'])))
                                {
                                        $st0 .= " AND (Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."')";
                                }

                                $this->db->select('logiref_paiements_tresor.*'); 
                                $this->db->from('logiref_integration_isys');
                                $this->db->where($st0, NULL, FALSE);
                                $this->db->order_by('logiref_paiements_tresor.Id_0','logiref_paiements_tresor.Id_0 DESC');
                                
                                return $this->get_all();
                                
                                if($row['Devise_12']=='USD')
                                {
                                        $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $stats['1'] = $stats['1'] + $row['Montant_11'];
                                } 
                        }
                        
                }
                elseif($type=='paiement_situation_cdf')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );
                        
                        $query = $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC')
                                            ->where('Account_3',$this->session->userdata('account_id'))
                                            ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                            ->get('logiref_paiements_tresor');
                        
                        foreach ($query->result_array() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='CDF')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }
                        
                        return $stats;
                }
                elseif($type=='paiement_situation_usd')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );
                        
                        $query = $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC')
                                            ->where('Account_3',$this->session->userdata('account_id'))
                                            ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                            ->get('logiref_paiements_tresor');
                        
                        foreach ($query->result_array() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='USD')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='USD')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='USD')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }
                        
                        return $stats;
                }
                elseif($type=='paiement_situation_regie')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "dgi_unvalidated" => '0',
                                "dgi_unvalidated_number" => '0',
                                "dgi_validated" => '0',
                                "dgi_validated_number" => '0',
                                "dgda_unvalidated" => '0',
                                "dgda_unvalidated_number" => '0',
                                "dgda_validated" => '0',
                                "dgda_validated_number" => '0',
                                "dgrad_unvalidated" => '0',
                                "dgrad_unvalidated_number" => '0',
                                "dgrad_validated" => '0',
                                "dgrad_validated_number" => '0',
                        );
                        
                        $query = $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC')
                                            ->where('Account_3',$this->session->userdata('account_id'))
                                            ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                            ->get('logiref_paiements_tresor');
                        
                        foreach ($query->result_array() as $row)
                        {
                                if($row['Checkerid_10']==0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + $row['Montant_11'];
                                                }
                                                $stats['dgi_unvalidated_number'] = $stats['dgi_unvalidated_number'] +1;
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + $row['Montant_11'];
                                                } 
                                                $stats['dgda_unvalidated_number'] = $stats['dgda_unvalidated_number'] +1;
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + $row['Montant_11'];
                                                } 
                                                $stats['dgrad_unvalidated_number'] = $stats['dgrad_unvalidated_number'] +1;
                                        }
                                }
                                elseif($row['Checkerid_10']>0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgi_validated'] = $stats['dgi_validated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgi_validated'] = $stats['dgi_validated'] + $row['Montant_11'];
                                                }
                                                $stats['dgi_validated_number'] = $stats['dgi_validated_number'] +1;
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgda_validated'] = $stats['dgda_validated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgda_validated'] = $stats['dgda_validated'] + $row['Montant_11'];
                                                } 
                                                $stats['dgda_validated_number'] = $stats['dgda_validated_number'] +1;
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Devise_12']=='USD')
                                                {
                                                        $stats['dgrad_validated'] = $stats['dgrad_validated'] + ($row['Montant_11']*$usd);
                                                }
                                                elseif($row['Devise_12']=='CDF')
                                                {
                                                        $stats['dgrad_validated'] = $stats['dgrad_validated'] + $row['Montant_11'];
                                                } 
                                                $stats['dgrad_validated_number'] = $stats['dgrad_validated_number'] +1;
                                        }
                                }
                        }
                        
                        return $stats;
                }
        }
        
        public function get_paiements_stats($type=NULL, $id=NULL)
        {      
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_4'];
                        $eur = $bank['Euro_5'];
                        $rand = $bank['Rand_6'];
                        $pound = $bank['Pound_7'];
                }
                if($type=='guichet_filter')
                {
                        $this->_table_name = '';

                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        $paiement_total = 0;
                        $commission_total = 0;
                        $commission_contreval = 0;
                        $commission_cdf = 0;
                        $nombre=0;
                        $paiement_contreval = 0;
                        $paiement_cdf = 0;
                        
                        
                        $st0 = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata('account_id') . "'";
                        
                        if(isset($_POST['agence']) && !empty($_POST['agence']))
                        {
                                $st0 .= " AND g.Id_0 ='".$_POST['agence']."'";
                                
                                if(isset($_POST['start']) && !empty($_POST['start']))
                                {
                                        $st0 .= " AND (p.Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."')";
                                }
                        }
                        if((isset($_POST['start']) && !empty($_POST['start'])) && (isset($_POST['end']) && !empty($_POST['end'])))
                        {
                                $st0 .= " AND (p.Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."')";
                        }
                        
                        $query = $this->db->select('*', 'logiref_paiements_tresor.Id_0 DESC')
                                ->from('logiref_paiements_tresor as p')
                                ->join('logiref_guichets as g', 'p.Guichet_21 = g.Id_0')
                                ->where($st0,NULL, FALSE)
                                ->get();
                        
                        foreach ($query->result_array() as $row)
                        {
                                if($row['Devise_12']=='USD')
                                {
                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                                }
                                
                                $nombre++;
                        }
                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        $commission_total = $commission_contreval + $commission_cdf;
                        $data['paiement'] = $paiement_total;
                        $data['nombre'] = $nombre;
                        $data['commission'] = $commission_total;
                        
                        if(empty($query->result_array()))
                        {
                               $data = array(); 
                        }
                        
                        return $data;
                }
                elseif($type=='guichet')
                {
                        $this->_table_name = '';

                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        $paiement_total = 0;
                        $commission_total = 0;
                        $commission_contreval = 0;
                        $commission_cdf = 0;
                        $nombre=0;
                        $paiement_contreval = 0;
                        $paiement_cdf = 0;
                        $st0 = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata('account_id') . "' AND g.Id_0='".$id."' AND p.Agence_20='" . $_SESSION['Logiref_agence'] . "'";
                        $query = $this->db->select('*', 'logiref_paiements_tresor.Id_0 DESC')
                                ->from('logiref_paiements_tresor as p')
                                ->join('logiref_guichets as g', 'p.Guichet_21 = g.Id_0')
                                ->where($st0,NULL, FALSE)
                                ->get();

                        foreach ($query->result_array() as $row)
                        {
                                if($row['Devise_12']=='USD')
                                {
                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                                }
                                
                                $nombre++;
                        }
                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        $commission_total = $commission_contreval + $commission_cdf;
                        $data['paiement'] = $paiement_total;
                        $data['nombre'] = $nombre;
                        $data['commission'] = $commission_total;
                        
                        return $data;
                }
                elseif($type=='agence')
                {
                        $this->_table_name = '';

                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        $paiement_total = 0;
                        $commission_total = 0;
                        $commission_contreval = 0;
                        $commission_cdf = 0;
                        $nombre=0;
                        $paiement_contreval = 0;
                        $paiement_cdf = 0;
                        $st0 = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata('account_id') . "' AND g.Id_0='".$id."' ";
                        $query = $this->db->select('*', 'logiref_paiements_tresor.Id_0 DESC')
                                ->from('logiref_paiements_tresor as p')
                                ->join('logiref_agences as g', 'p.Agence_20 = g.Id_0')
                                ->where($st0,NULL, FALSE)
                                ->get();

                        foreach ($query->result_array() as $row)
                        {
                                if($row['Devise_12']=='USD')
                                {
                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                                }
                                
                                $nombre++;
                        }
                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        $commission_total = $commission_contreval + $commission_cdf;
                        $data['paiement'] = $paiement_total;
                        $data['nombre'] = $nombre;
                        $data['commission'] = $commission_total;
                        return $data;
                }
        }
        
        public function get_id_by_reference($ref) 
        {
                $st = " Logirefid_4='" . $ref . "'";
                $this->db->where($st, NULL, FALSE);
                $query = $this->db->get('logiref_paiements_tresor');
                $id = NULL;
                $ddmenu = array();
                foreach ($query->result_array() as $row) 
                {
                    $id = $row['Id_0'];
                }
                return $id;
        }
        
        public function get_regle_penalites()
        {
                $this->_table_name = '';
                $this->db->select('logiref_penalites.*', 'logiref_penalites.Id_0 ASC');
                $this->db->from('logiref_penalites');
                $st = " Status_2='1' AND Checkerid_15 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Priorite_4 DESC');
                return $this->get_all();
        }
        
        public function get_paiement_tresor_bl($id)
        {
                $this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
        }
        
        public function get_prepaiement_tresor_bl($id)
        {
                $this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id), TRUE);
        }
        
        
        
        public function get_paiement_propres_bl($id)
        {
                $this->set_table('logiref_paiements_propres I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
        }
        
        public function get_paiement_propres_dgrk($id)
        {
                $this->set_table('logiref_paiements_propres I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Edgrk_50' => $id), TRUE);
        }
        
        public function get_prepaiement_propres_bl($id)
        {
                $this->set_table('logiref_paiements_propres I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id), TRUE);
        }
        
        public function get_paiement_by_reference($ref=NULL)
        {
                if($ref != "")
                {
                        $this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Noteid_26' => $ref), TRUE);
                }
        }
        
        public function get_paiements($type=NULL) 
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                #Filtre d'affichage
                if($type=='attente') $st .= " AND Checkerid_10='0'";
                elseif($type=='urgents') $st .= " AND Checkerid_10='0' AND Datevaleur_31<'".gmdate('Y-m-d')."'";
                elseif($type=='validated') $st .= " AND Status_2 = '2'";
                elseif($type=='nvalidated') $st .= " AND Status_2 = '1' AND Checkerid_10 = 0";
                elseif($type=='transferred') $st .= " AND Status_2 = '3'";
                elseif($type=='virement') $st .= " AND Mode_19 = '7'";
                elseif($type=='penalities') $st .= " AND Status_2 = '1' AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1";
                else $st .= " AND (Checkerid_10='0' OR Datevaleur_31<='".gmdate('Y-m-d')."')";
                #Restriction
                if($_SESSION['Logiref_role']>2) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_nvalidated_to_export($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=2 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_nvalidated_to_integrate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=7 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        
        
        public function filter_nvalidated_paiements($regie)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND Beneficaire_15='$regie' AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_filterd_paiements($type=NULL, $data) 
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                #Filtre d'affichage
                if(isset($data['agence']) && $data['agence'] != '') $st .="AND Guichet_21 ='".$data['agence']."'";
                if(isset($data['start']) && isset($data['end']) && ($data['start'] != '' && $data['end'] != '')) $st .="AND (Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."')";
                if($type=='attente') $st .= " AND Checkerid_10='0'";
                elseif($type=='urgents') $st .= " AND Checkerid_10='0' AND Datevaleur_31<'".gmdate('Y-m-d')."'";
                elseif($type=='validated') $st .= " AND Status_2 = '2'";
                elseif($type=='nvalidated') $st .= " AND Status_2 = '1' AND Checkerid_10 = 0";
                elseif($type=='transferred') $st .= " AND Status_2 = '3'";
                elseif($type=='virement') $st .= " AND Mode_19 = '7'";
                elseif($type=='penalities') $st .= " AND Status_2 = '1' AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1";
                else $st .= " AND (Checkerid_10='0' OR Datevaleur_31<='".gmdate('Y-m-d')."')";
                #Restriction
                if($_SESSION['Logiref_role']>2) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        public function get_ordres($obj=NULL, $param=NULL, $data=NULL)
        {
            
                    if($obj=='regie')
                    {
                            $regie = $_SESSION['Logiref_regies'];
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Regie_7 = '" .$regie."'";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                        
                    }
                    elseif($obj=='bank')
                    {
                            $bank = $param;
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Bank_9 ='".$bank."'";
                            if($data =="new") $st= "Bank_9 ='".$bank."' AND Status_2 = 1 "; else $st = "Bank_9 ='".$bank."' AND Status_2 > 1";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                    }
                    else
                    {
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Account_3='" . $this->session->userdata('account_id') . "'";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                    }
        }
        
        public function get_montant_total($data=NULL) 
        {
                $total_montant = "";
                
                if(!empty($data))
                {
                        $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        $data['Montant_11'] = intval($data['Montant_11']);
                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','',$data['Commission_23']);
                        $data['Commission_23'] = intval($data['Commission_23']);
                        
                        $total_montant = $data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23']*0.16);
                }
                return  $total_montant;
        }
        
        public function check_paiement()
        {
                $this->_table_name = '';
                
                $st = " Account_3='" . $this->session->userdata('account_id') . "'";
                
                if(isset($_POST['Montant'])) $st .= " AND Montant_11 ='".$_POST['Montant']."'";
                if(isset($_POST['Devise']))   $st .= " AND Devise_12 ='".$_POST['Devise']."'";
                if(isset($_POST['Noteid']))    $st .= " AND Noteid_26 ='".$_POST['Noteid']."'";
                if(isset($_POST['Nif'])) $st .= " AND Nif_13 ='".$_POST['Nif']."'";
                if(isset($_POST['Service'])) $st .= " AND Service_16 ='".$_POST['Service']."'";
                if(isset($_POST['Recette'])) $st .= " AND Typerecette_17 ='".$_POST['Recette']."'";
                if(isset($_POST['Notedate'])) $st .= " AND Notedate_27 ='".$_POST['Notedate']."'";
                
                //var_dump($_POST); die;
                //var_dump($st); die;
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                
                return $this->get_all();
        }
        
        
        public function get_code_agence_client($data=NULL) 
        {
                $compte_client = $data['Compte_33'];
                $compte = explode("-", $compte_client);
                $code_agence = $compte[0];
                
                return $code_agence;
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_payment_propres($data, $id) {
                $this->set_table('logiref_paiements_propres', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_payment_tresor($data, $id) {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_payment_propres_dgda($data, $id) {
                $result = $this->db->insert_batch('logiref_paiements_propres', $data);
                if($result){
                    return TRUE;
                }else{
                    return FALSE;
                }
        }
        
        public function save_payment_tresor_dgda($data, $id) {
                $result = $this->db->insert_batch('logiref_paiements_tresor', $data);
                //var_dump($result);die;
                if($result){
                    return TRUE;
                }else{
                    return FALSE;
                }
        }
        
        public function update_payment_tresor($data, $id) {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Logirefid_4', $id);
                return $this->save($data, $id);
        }
        
        public function update_payment_tresor_by_ref($data, $ref) {
                $this->db->where("logiref_paiements_tresor.Logirefid_4 ='".$ref."'");
                return $this->db->update('logiref_paiements_tresor',$data);
        }
        
        public function update_payment_propres($data, $ref) {
                $this->db->where("logiref_paiements_propres.Logirefid_4 ='".$ref."'");
                return $this->db->update('logiref_paiements_propres',$data);
        }
        
        public function update_payment_tresor_dgda($data, $ref) {
                $this->db->where("logiref_paiements_tresor.Sydonia_44 ='".$ref."'");
                return $this->db->update('logiref_paiements_tresor',$data);
        }
        
        public function update_prepayment_tresor_dgda($data, $ref) {
                $this->db->where("logiref_paiements_tresor.Sydonia_49 ='".$ref."'");
                return $this->db->update('logiref_paiements_tresor',$data);
        }
        
        public function update_payment_propres_dgda($data, $ref) {
                $this->db->where("logiref_paiements_propres.Sydonia_44 ='".$ref."'");
                return $this->db->update('logiref_paiements_propres',$data);
        }
        
        public function update_prepayment_propres_dgda($data, $ref) {
                $this->db->where("logiref_paiements_propres.Sydonia_49 ='".$ref."'");
                return $this->db->update('logiref_paiements_propres',$data);
        }
        
        public function delete_paiement_tresor($id)
	{
		$this->db->where('Logirefid_4', $id);
		return $this->db->delete('logiref_paiements_tresor');
	}
        
        public function delete_paiement_propre($id)
	{
		$this->db->where('Logirefid_4', $id);
		return $this->db->delete('logiref_paiements_propres');
	}
        
	public function generate_unique_reference()
	{
			$datetimePart = date('ymdHis'); // 6 (ymd) + 6 (His) = 12 caractères
			$randomPart = substr(bin2hex(random_bytes(4)), 0, 8); // 8 caractères aléatoires

			return $datetimePart . $randomPart; // total : 12 + 8 = 20 caractères
	}
}