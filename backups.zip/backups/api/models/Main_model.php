<?php
class Main_model extends MY_Main{
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        
        public $languages = array(
                        '0' => 'en',
                        '1' => 'en',
                        '2' => 'fr',
                        '3' => 'en',
                        '4' => 'en'
        );
        
        public $user_status = array(
                'en' => array(
                        '0' => 'Deleted',
                        '1' => 'Active',
                        '2' => 'Inactive',
                        '3' => 'Suspended',
                        '4' => 'New'
                ),
                'fr' => array(
                        '0' => 'Supprim&eacute;',
                        '1' => 'Actif',
                        '2' => 'Inactif',
                        '3' => 'Suspendu',
                        '4' => 'Nouveau'
                )
        );
        
        public $user_dashboard = array(
                'en' => array(
                        'Relations' => 'iKwook Relations',
                        'Logistics' => 'iKwook Logistic',
                        'Finance' => 'iKwook Finance',
                        'Page' => 'iKwook Page',
                        'Pay' => 'iKwook Pay',
                        'Project' => 'iKwook Project',
                        'Education' => 'iKwook Education',
                        'Logiref' => 'iKwook Logiref',
                        'Enterprise' => 'iKwook Enterprise',
                ),
                'fr' => array(
                        'Relations' => 'iKwook Relations',
                        'Logistics' => 'iKwook Logistique',
                        'Finance' => 'iKwook Finance',
                        'Page' => 'iKwook Page',
                        'Pay' => 'iKwook Pay',
                        'Project' => 'iKwook Projet',
                        'Education' => 'iKwook Education',
                        'Logiref' => 'iKwook Logiref',
                        'Enterprise' => 'iKwook Entreprise',
                )
        );
        
        public $types_regie = array(
            'AIP'=>'AIP',
            'RGF'=>'RGF',
            'RFP'=>'RFP',
            'BKC'=>'BKC',
            ''=>''
        );
        
        public $user_role = array(
                'en' => array(
                        '200' => 'Administrator',
                        '300' => 'User (recommended)',
                        '400' => 'Visitor'
                ),
                'fr' => array(
                        '200' => 'Administrateur',
                        '300' => 'Utilisateur',
                        '400' => 'Visiteur'
                )
        );
        
        public $account_categories = array(
                'en' => array(
                        '101' => 'Corprate',
                        '202' => 'Business',
                        '303' => 'Family'
                ),
                'fr' => array(
                        '101' => 'Corprate',
                        '202' => 'Business',
                        '303' => 'Famille'
                )
        );
        
        public $rules = array(
                'identifiant' => array(
                        'field' => 'identifiant',
                        'label' => 'Username',
                        'rules' => 'trim|required|xss_clean'
                ),
                'passcode' => array(
                        'field' => 'passcode',
                        'label' => 'password',
                        'rules' => 'trim|required'
                )
        );

        public $signup_rules = array(
                'email' => array(
                        'field' => 'email',
                        'label' => 'Email',
                        'rules' => 'trim|required|xss_clean'
                ),
                'firstname' => array(
                        'field' => 'firstname',
                        'label' => 'First name',
                        'rules' => 'trim|required|xss_clean'
                ),
                'lastname' => array(
                        'field' => 'lastname',
                        'label' => 'Last name',
                        'rules' => 'trim|required|xss_clean'
                ),
                'password' => array(
                        'field' => 'password',
                        'label' => 'password',
                        'rules' => 'trim|required'
                )
        );
        
        public $dedicated_applications = array(
                                'fr'=>array(
                                    'Logiref' => array(
                                        'Bank'=>'Banques',
                                        'Regie'=>'R&eacute;gies',
                                        'Clients'=>'Contibuables'
                                    ),
                                    'Enterprise'=>array(
                                        'Education'=>'Education(ENA)',
                                        'Recruitment'=>'Recruitement',
                                        'Smartways'=>'Smartways',
                                        'Trafic'=>'Trafic'
                                    )
                                ),
                                'en'=>array(
                                    'Logiref' => array(
                                        'Bank'=>'Banks',
                                        'Regie'=>'R&eacute;gies',
                                        'Clients'=>'Contribuables'
                                    ),
                                    'Enterprise'=>array(
                                        'Education'=>'Education(ENA)',
                                        'Recruitment'=>'Recruitment',
                                        'Smartways'=>'Smartways',
                                        'Trafic'=>'Trafic'
                                    )
                                    
                                ),
        );
        //public $dedicated_applications = array();
        public $standard_applications = array(
                
                                'fr' => array(
                                        'Logistics' => array(
                                            
                                                'Orders' => 'Gestion de commandes',
                                                'Purchases' => 'Gestions des achats',
                                                'Assets' => 'Gestion de parcs',
                                                'Shipments' => 'Gestion des exp&eacute;ditions',
                                                'Stocks' => 'Gestion de stocks',

                                         ),
                                         'Relations' => array(
                                             
                                                'Contacts' => 'Contacts',
                                                'Campaigns' => 'Campagnes',
                                                'Reminders' => 'Reminders',
                                                'Sales' => 'Ventes',
                                                'Projet' => 'Projet',
                                                'Survey' => 'Sondages',
                                                'Share' => 'Partage',
                                         ),
                                         'Finance' => array(
                                             
                                                'Cashflow' =>'Cashflow',
                                                'Budget' => 'Budget',
                                         ),
                                        'Pay' => array(

                                                    'Ewallet' =>'eWallet',
                                                    'Epos' => 'ePOS',
                                                    'Ebills'=>'eBills'
                                        )
                                ),
                                'en' => array(
                                        'Logistics' => array(
                                            
                                                'orders' => 'Orders',
                                                'purchases' => 'Purchases',
                                                'assets' => 'Assets',
                                                'shipments' => 'Shipments',
                                                'stocks' => 'Stocks',

                                         ),
                                         'Relations' => array(
                                             
                                                'Contacts' => 'Contacts',
                                                'Campaigns' => 'Campaigns',
                                                'Reminders' => 'Reminders',
                                                'Sales' => 'Sales',
                                                'Projet' => 'Project',
                                                'Survey' => 'Survey',
                                                'Share' => 'Share',
                                         ),
                                         'Finance' => array(
                                             
                                                'Cashflow' =>'Cashflow',
                                                'Budget' => 'Budget',
                                        ),
                                        'Pay' => array(
                                             
                                                'Ewallet' =>'eWallet',
                                                'Epos' => 'ePOS',
                                                'Ebills'=>'Ebills'
                                        )
                                )
        );
        
        public  $ikwook_applications = array(
                                'Page' => array(
                                        'fr' => 'Pages',
                                        'en' => 'Pages',
                                        'url'  => 'page/',
                                        'icon' => 'fa fa-globe text-aqua'
                                 ),
                                 'Wallet' => array(
                                        'fr' => 'e-Wallet',
                                        'en' => 'e-Wallet',
                                        'url'  => 'wallet/',
                                        'icon' => 'fa fa-credit-card text-orange'
                                 ),
                                 'Pay' => array(
                                        'fr' => 'Pay',
                                        'en' => 'Payer',
                                        'url'  => 'pay',
                                        'icon' => 'fa fa-bank text-green'
                                 ),
                                 'Relations' => array(
                                        'en' => 'Relations',
                                        'fr' => 'Relations',
                                        'url'  => 'relations',
                                        'icon' => 'fa fa-user text-blue'
                                 ),
                                 'Project' => array(
                                        'en' => 'Projects',
                                        'fr' => 'Projets',
                                        'url'  => 'project',
                                        'icon' => 'fa fa-list text-blue'
                                 ),
                                 'Objective' => array(
                                        'en' => 'Objectives',
                                        'fr' => 'Objectifs',
                                        'url'  => 'objective',
                                        'icon' => 'fa fa-dot-circle-o text-aqua'
                                 ),
                                 'Finance' => array(
                                        'fr' => 'Finances',
                                        'en' => 'Finances',
                                        'url'  => 'finance',
                                        'icon' => 'fa fa-suitcase text-orange'
                                 ),
                                 'Logistics' => array(
                                        'fr' => 'Logistique',
                                        'en' => 'Logistics',
                                        'url'  => 'logistics',
                                        'icon' => 'fa fa-truck text-green'
                                 ),
                                 'Recruitment' => array(
                                        'fr' => 'Recruitment',
                                        'en' => 'Recrutement',
                                        'url'  => 'relations/recruitment',
                                        'icon' => 'fa fa-user text-yellow'
                                 ),
                                 'Share' => array(
                                        'fr' => 'Partage',
                                        'en' => 'Share',
                                        'url'  => 'relations/share',
                                        'icon' => 'fa fa-cloud text-orange'
                                 ),
                                 'Contact' => array(
                                        'fr' => 'Contacts',
                                        'en' => 'Contact',
                                        'url'  => 'relations/contact',
                                        'icon' => 'fa fa-cloud text-orange'
                                 ),
                                 'Communications' => array(
                                        'fr' => 'Communications',
                                        'en' => 'Communications',
                                        'url'  => 'relations/communications',
                                        'icon' => 'fa fa-cloud text-orange'
                                 ),
                        );


        public function __construct()
        {
                parent::__construct();
        }
        
        
        
        /**
         * Site  details - to be updated 
         * By Papin - Update 16 01 2015
        */
        public function get_site_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1='';
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Name_7='';
                        $obj->Description_8='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_branches', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       return $result[0]; 
                }
        }
        
        /**
         * Role  details - to be updated 
         * By Papin - Update 16 01 2015
        */
        public function get_relation_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1='';
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->User_7='';
                        $obj->Group_8='';
                        $obj->Branch_9='';
                        $obj->Type_10='300';
                        $obj->Module_11='';
                        $obj->Function_12='';
                        return $obj;
                }
                else
                {
                       $account_id = $this->session->userdata('account_id');
                       $this->set_table('main_relations', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('User_7' => $id, 'Account_3' => $account_id));
                       
                       return $result[0]; 
                }
        }
        
        /**
         * Group  details - to be updated 
         * By Papin - Update 16 01 2015
        */
        public function get_group_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1='';
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Name_7='';
                        $obj->Description_8='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_groups', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       return $result[0]; 
                }
        }
        
        /**
         * Profile  details - to be updated 
         * By Papin - Update 16 01 2015
        */
        public function get_profile_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1='';
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Identifier_7='';
                        $obj->Encryption_8='';
                        $obj->Firstname_9='';
                        $obj->Lastname_10='';
                        $obj->Middlename_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Language_14='';
                        $obj->Gender_15='';
                        $obj->Profile_16='';
                        $obj->Birthday_17='';
                        $obj->Position_18='';
                        $obj->Login_19='';
                        $obj->Logout_20='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       return $result[0]; 
                }
        }
        
        public function get_profile_by_account($id)
        {
                $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Account_3' => $id));
                if(!empty($result)) return $result[0]; else return false;
        }
        
        public function get_profile_by_email($email)
        {
                $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Identifier_7' => $email));
                if(!empty($result)) return $result[0]; else return false;
        }
        
        public function get_profile_by_id($id)
        {
                $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Id_0' => $id));
                if(!empty($result)) return $result[0]; else return false;
        }
        
        public function get_all_user_by_email($email)
        {
                $this->db->select('main_profiles.*', 'Identifier_7', 'Identifier_7 ASC');
                $this->db->from('main_profiles');
                $this->db->where("Identifier_7 ='".$email."' OR Email_13 ='".$email."'");
                $this->db->order_by("Identifier_7");
                $result = $this->get_all();
                if(!empty($result)) return $result; else return false;
        }
        
        public function get_user_by_key($key)
        {
                $this->db->select('main_profiles.*', 'Id_0', 'Identifier_7 ASC');
                $this->db->from('main_profiles');
                $this->db->where("Encryption_8 ='".$key."'");
                $this->db->order_by("Encryption_8");
                $result = $this->get_all();
                if(!empty($result)) return $result[0]; else return false;
        }
        
        /**
         * Profile  details - to be updated 
         * By Papin - Update 16 01 2015517
        */
        //'517997'
        public function get_account_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Business_7='';
                        $obj->Category_8='';
                        $obj->Description_9='';
                        $obj->Activation_10='';
                        $obj->Expire_11='';
                        $obj->Country_12='';
                        $obj->Currency_13='';
                        $obj->Dashboard_14='';
                        $obj->Telephone_15='';
                        $obj->Email_16='';
                        $obj->Logo_17='';
                        $obj->Website_18='';
                        $obj->State_19='';
                        $obj->City_20='';
                        $obj->Address_21='';
                        $obj->Address_22='';
                        $obj->Postal_23='';
                        $obj->Pageid_24='';
                        $obj->Restrictedto_25='';
                        $obj->Myapplication_26='';
                        $obj->Regies_27='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_accounts', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       return $result[0]; 
                }
        }
        
        /**
         * Login - required a username + a password
         * Should be using Email or Mobile phone as username
         * By Papin - Update 16 01 2015
        */
        public function login($userid=NULL)
        {
                $password = $this->input->post('passcode');
				
                $publickey = $this->input->post('publickey');
                
                if($userid==NULL)
                {
                        $this->set_table('main_profiles', 'Id_0', 'Id_0');
                        $user = $this->get_by(array('Identifier_7' => $this->input->post('login')), TRUE);
                       
                        if(isset($publickey) && isset($user->Encryption_8) && $publickey == $user->Encryption_8)
                        {
                                $this->init_sessions($user); 
                        }
                        else if(isset($user->Encryption_8) && $user->Encryption_8!="" && $password!='')
                        {
                                //Decrypting password encrypt from JS
                                $key = "1234567890123456";
                                $iv = "1234567890123456";
                                $decrypted = openssl_decrypt($password, 'aes-128-cbc', $key, 0, $iv);
                                //var_dump($decrypted); die;
                                
                                $matches = $this->verify($decrypted, $user->Encryption_8);
                                if($matches)
                                {
                                    $this->init_sessions($user);                                    
                                }
                        }
                }
                return true;
        }
        
        public function loggedin()
        {
                return (bool) $this->session->userdata('loggedin');
        }
        
        public function verify($password, $hashedPassword) 
        {
                return crypt($password, $hashedPassword) == $hashedPassword;
        }
		
        public function init_sessions($user)
        {
                if(isset($user->Id_0) && $user->Id_0 >0)
                {
                        //Retrieving account details
                        $this->set_table('main_accounts', 'Id_0', 'Id_0');
                        $account = $this->get_by(array('Id_0' => $user->Account_3), TRUE);
                        //Retrieving access details
                        $this->set_table('main_relations', 'Id_0', 'Id_0');
                        $relation = $this->get_by(array('User_7' => $user->Id_0, 'Account_3' => $user->Account_3), TRUE);

                        
                        //Seting Language
                        switch($user->Language_14)
                        {
                                case 2: $lang='fr'; break;
                                case 3: $lang='por'; break;
                                default: $lang='en';
                        }
                        //Setting sessions variables
                        $data = array(
                                //Profile details
                                'user_id'           => $user->Id_0,
                                'user_status'       => $user->Status_2,
                                'user_username'     => $user->Identifier_7,
                                'user_key'          => $user->Encryption_8,
                                'user_fname'        => $user->Firstname_9,
                                'user_sname'        => $user->Lastname_10,
                                'user_nname'        => $user->Middlename_11,
                                'user_cellphone'    => $user->Cellphone_12,
                                'user_email'        => $user->Email_13,
                                'user_lang'         => $lang,
                                'user_gender'       => $user->Gender_15,
                                'user_profile'      => $user->Profile_16,
                                'user_birthday'     => $user->Birthday_17,
                                'user_position'     => $user->Position_18,
                                'user_lastsession'  => $user->Lastsession_23,
                                //Account details
                                'account_status'    => $account->Status_2,
                                'account_id'        => $user->Account_3,
                                'account_business'  => $account->Business_7,
                                'account_category'  => $account->Category_8,
                                'account_description'  => $account->Description_9,
                                'account_active'    => $account->Activation_10,
                                'account_expire'    => $account->Expire_11,
                                'account_country'   => $account->Country_12,
                                'account_currency'  => $account->Currency_13,
                                'account_dashboard' => $account->Dashboard_14,
                                'account_tel'       => $account->Telephone_15,
                                'account_email'     => $account->Email_16,
                                'account_logo'      => $account->Logo_17,
                                'account_website'   => $account->Website_18,
                                'account_address'   => $account->Address_21,
                                'account_state'     => $account->State_19, //Or province
                                'account_city'      => $account->City_20,
                                'account_postal'    => $account->Postal_23,
                                'account_pageid'    => $account->Pageid_24,
                                'account_restrict'  => $account->Restrictedto_25,
                                'account_myapps'    => $account->Myapplication_26,
                               
                                
                                //Relation details
                                'user_type'         => $relation->Type_10, //200, 300, 400
                                'user_roles'         => $relation->Roles_13, //JSON
                                'user_group'        => $relation->Group_8,
                                'user_site'         => $relation->Branch_9,
                                'user_module'       => $relation->Module_11,
                                'user_function'     => $relation->Function_12,
                                'user_apps'         => $relation->Applications_14,	
                                'ikwook_bullet'     => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['SERVER_ADDR'].$_SERVER['HTTP_USER_AGENT'] : "",
                                'loggedin' => TRUE                              
                        );
                        
                       
                        //We check that the account an the user account is active
                        if(($account->Status_2!= 1) || ($account->Activation_10 <= gmdate('Y-m-d H:i:s') && $account->Expire_11 < date('Y-m-d', strtotime("+0 day"))))
                        {
                                $data['loggedin'] = FALSE;
                                $this->session->set_userdata($data);
                        }
                        elseif($user->Status_2!= 1)
                        {
                                $data['loggedin'] = FALSE;
                                $this->session->set_userdata($data);
                        }
                        else
                        {
                                $lastsessionID = $data['user_lastsession'];
                                
                                if($lastsessionID!=""){
                                    
                                        session_destroy();

                                        session_id($lastsessionID);
                                        session_start();

                                        session_destroy();
                                        
                                }
                                //Sessions
                                $this->session->set_userdata($data);		
                        }
                }
                
                return TRUE;
        }
        
        public function change_sessions($account_id = NULL)
        {
                if(isset($account_id) && $account_id >0)
                {
                        $user_id = $this->session->userdata('user_id');
                                
                        //Retrieving account details
                        $this->set_table('main_accounts', 'Id_0', 'Id_0');
                        $account = $this->get_by(array('Id_0' => $account_id), TRUE);
                        
                        //Retrieving access details
                        $this->set_table('main_relations', 'Id_0', 'Id_0');
                        $relation = $this->get_by(array('User_7' => $user_id, 'Account_3' => $account_id), TRUE);

                        //Setting sessions variables
                        $data = array(
                                //Account details
                                'account_id'        => $account_id,
                                'account_status'    => $account->Status_2,
                                'account_business'  => $account->Business_7,
                                'account_category'  => $account->Category_8,
                                'account_active'    => $account->Activation_10,
                                'account_expire'    => $account->Expire_11,
                                'account_country'   => $account->Country_12,
                                'account_currency'  => $account->Currency_13,
                                'account_dashboard' => $account->Dashboard_14,
                                'account_tel'       => $account->Telephone_15,
                                'account_email'     => $account->Email_16,
                                'account_logo'      => $account->Logo_17,
                                'account_website'   => $account->Website_18,
                                'account_address'   => $account->Address_21,
                                'account_state'     => $account->State_19, //Or province
                                'account_city'      => $account->City_20,
                                'account_postal'    => $account->Postal_23,
                                'account_pageid'    => $account->Pageid_24,
                                'account_restrict'  => $account->Restrictedto_25,
                                'account_myapps'    => $account->Myapplication_26,
                                //Relation details
                                'user_type'         => $relation->Type_10,
                                'user_group'        => $relation->Group_8,
                                'user_site'         => $relation->Branch_9,
                                'user_application'  => $relation->Applications_14,
                                'user_module'       => $relation->Module_11,
                                'user_function'     => $relation->Function_12,
                                'loggedin' => TRUE                              
                        );

                        //Sessions
                        $this->session->set_userdata($data);	
                }
                return TRUE;
        }
        
	       
        public function get_dashboard()
        {
                $account = $this->session->userdata('account_id');
                $page_id = $this->session->userdata('account_pageid');
                $application = $this->session->userdata('user_apps');
                $dashboard = $this->session->userdata('account_dashboard');
                #var_dump($user_module); die;
                $restrictions = $this->session->userdata('account_restrict');
                $category = $this->session->userdata('account_category');
                $lang = $this->data['lang'];
                #If account type is Family
                if($category == '303')
                {
                      $return['dashboard'] = 'pay/hotleads';  
                }
                #If account type is Business or Enterprise
                elseif($application != '0' && $application != '')
                {
                        $myapps = $this->standard_applications['fr'];
                        
                        $module = '';

                        foreach ($myapps as $row => $tab)
                        {
                                if(key_exists($application, $tab))
                                {
                                        $module = $row;
                                }
                        }
                        $application = strtolower($application);
                        $module = strtolower($application);
                       
                        $return['dashboard'] = "".$module."/".$application."";
                        
                }
                elseif($dashboard!='')
                {
                        
                        $dashboard = strtolower($dashboard);
                        $return['dashboard'] = $dashboard;
                }
                #Default for Business or Enterprise
                elseif($category == '202' || $category == '101')
                {
                      $return['dashboard'] = 'page/manage/set/dashboard';  
                }
                else
                {
                      $return['dashboard'] = 'main/account/set/profile';              
                }

                //Apply rules
                if($restrictions !='')
                {
                    $apps = explode(',', $restrictions);
                    if(isset($apps[0]))
                    {
                        $dashboard = strtolower($apps[0]);
                        $return['dashboard'] = $dashboard.'/';
                    }
                }
                elseif($this->session->userdata('account_country') == '0' || $this->session->userdata('account_country') == '')
                {
                        $return['dashboard'] = 'main/account/complete';
                }
                if($page_id == "@enardc") $return['dashboard'] = $return['dashboard'].'ena';
                return $return;
        }
                
        /**
         * Login - required a username + a password
         * Should be using Email or Mobile phone as username
         * By Papin - Update 16 01 2015
        */
        public function get_dropdown($item, $param=NULL)
        {
                $account = $this->session->userdata('account_id');
                
                if($item=="country")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                elseif($item=="groups")
                {
                        $this->db->where("main_groups.Status_2 ='1' AND main_groups.Account_3 ='" . $account . "'");
                        $this->db->order_by('Name_7');
                        $query = $this->db->get('main_groups');
                        $ddmenu = array();
                        $ddmenu['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="sites")
                {
                        $this->db->where("main_branches.Status_2 ='1' AND main_branches.Account_3 ='" . $account . "'");
                        $this->db->order_by('Name_7');
                        $query = $this->db->get('main_branches');
                        $ddmenu = array();
                        $ddmenu['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="profiles_array")
                {
                        if($param == NULL)$where="Account_3='".$this->session->userdata('account_id')."'"; else $where=" Status_2 = 1";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('Firstname_9');
                        $query = $this->db->get('main_profiles');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Firstname_9'].' '.$row['Lastname_10'];
                                $pprofiles[$row['Id_0']] = $row['Profile_16'];
                        }
                        
                        $returns['profiles'] = $pprofiles;
                        $returns['names'] = $ddmenu;
                        
                        return $returns;
                }
                elseif($item=="users_array")
                {
                        if($param == NULL)$where="Account_3='".$this->session->userdata('account_id')."'"; else $where=" Status_2 = 1";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('Firstname_9');
                        $query = $this->db->get('main_profiles');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Firstname_9'].' '.$row['Lastname_10'];
                                $pprofiles[$row['Id_0']] = $row['Profile_16'];
                        }
                        $returns = $ddmenu;
                        return $returns;
                }
                elseif($item=="users_html")
                {
                        $where="Status_2='5' AND Account_3='".$this->session->userdata('account_id')."'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('Firstname_9');
                        $query = $this->db->get('main_profiles');
                        $ddmenu = array();
                        $ddmenu= '<select name="user" class="form-control" required="required"><option value="" selecteed></option>';
                        foreach ($query->result_array() as $row) {
                                $ddmenu.= '<option value="'.$row['Id_0'].':'.$row['Firstname_9'].' '.$row['Lastname_10'].'" >'.$row['Firstname_9'].' '.$row['Lastname_10'].'</option>';
                        }
                        $ddmenu.= '</select>';
                        return $ddmenu;
                }
                elseif($item=="users")
                {
                        $where="Status_2!='0' AND Account_3='".$this->session->userdata('account_id')."'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('Firstname_9');
                        $query = $this->db->get('main_profiles');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Firstname_9'].' '.$row['Lastname_10'];
                        }
                        return $ddmenu;
                }
        }
        
        /**
         * Login - required a username + a password
         * Should be using Email or Mobile phone as username
         * By Papin - Update 16 01 2015
        */
        public function check_group_user($id)
        {
                $this->db->where('Status_2',1);
                $this->db->where('Account_3',$this->session->userdata('account_id'));
                $this->db->where('Group_8',$id);
                $this->db->order_by('Id_0');
                $query = $this->db->get('main_relations');
                if($query->row_data == NULL) return FALSE;
                else return TRUE;
        }
        
        public function check_site_user($id)
        {
                $this->db->where('Status_2',1);
                $this->db->where('Account_3',$this->session->userdata('account_id'));
                $this->db->where('Branch_9',$id);
                $this->db->order_by('Id_0');
                $query = $this->db->get('main_relations');
                if($query->row_data == NULL) return FALSE;
                else return TRUE;
        }
        
        public function check_user_opt($email, $otp)
        {
                $this->db->select('main_profiles.*', 'Id_0', 'Identifier_7 ASC');
                $this->db->from('main_profiles');
                $this->db->where("Identifier_7 ='".$email."' AND Lastotp_21 ='".$otp."'");
                $this->db->order_by("Identifier_7");
                $result = $this->get_all();
                if(!empty($result)) return $result[0]; else return false;
        }

        public function get_sites($in = NULL, $notIn=NULL)
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                
                $this->db->select('main_branches.*, main_branches.Name_7');
                $this->db->from('main_branches');
                $this->db->where("main_branches.Status_2 ='1' AND main_branches.Account_3 ='" . $account_id . "'");
                if($in != NULL) $this->db->where("main_branches.Id_0 IN (".$in.")"); 
                if($notIn !=NULL) $this->db->where("main_branches.Id_0 NOT IN (".$notIn.")"); 
                $this->db->order_by('main_branches.Date_1 ASC');
                $queryResults = $this->get_all();
                
                return $queryResults;
        }
        
        public function get_groups($in = NULL, $notIn=NULL)
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                
                $this->db->select('main_groups.*, main_groups.Name_7');
                $this->db->from('main_groups');
                $this->db->where("main_groups.Status_2 ='1' AND main_groups.Account_3 ='" . $account_id . "'");
                if($in != NULL)
                {
                    $this->db->where("main_groups.Id_0 IN (".$in.")"); 
                }
                if($notIn !=NULL)
                {
                    $this->db->where("main_groups.Id_0 NOT IN (".$notIn.")"); 
                }
                $this->db->order_by('main_groups.Date_1 ASC');
                $queryResults = $this->get_all();
                
                return $queryResults;
        }
        
        public function get_users($uid=NULL, $in = NULL, $notIn=NULL, $role=NULL)
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                
                $this->db->select('main_profiles.*, main_relations.*');
                $this->db->select('main_profiles.Id_0 as Id_0');
                $this->db->select('main_relations.Id_0 as r_id');
                $this->db->from('main_profiles');
                $this->db->join('main_relations', 'main_profiles.Id_0 = main_relations.User_7', 'left');
                $this->db->where("main_profiles.Status_2 !='0'");
                $this->db->where("main_relations.Status_2 !='0'");
                $this->db->where("main_relations.Account_3 ='".$account_id."'");
                if(isset($_POST['search']) && $_POST['search'] !="")
                {
                        $this->db->like("CONCAT(Firstname_9,' ',Lastname_10)", $_POST['search'], 'both');
                }
                if($uid != NULL)
                {
                        $this->db->where("main_profiles.Id_0 = '".$uid."'");
                }
                if($in != NULL)
                {
                        $this->db->where("main_profiles.Id_0 IN (".$in.")"); 
                }
                if($notIn !=NULL)
                {
                        $this->db->where("main_profiles.Id_0 NOT IN (".$notIn.")"); 
                }
                if($role !=NULL)
                {
                        $this->db->where("main_relations.Type_10 = '".$role."'"); 
                }
                else
                {
                        $this->db->where("main_relations.Type_10 IN (200,300) AND main_profiles.Account_3 ='" . $account_id . "'");    
                }
                $this->db->order_by('main_profiles.Date_1 ASC');
                $queryResults = $this->get_all();
                
                return $queryResults;
        }
		
        public function get_relations($userID=NULL, $groupID = NULL, $branchID=NULL, $roleID=NULL)
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata('account_id');
                $user_id = $this->session->userdata('user_id');
                
                $this->db->select('main_relations.User_7, main_groups.Name_7 AS Group, main_branches.Name_7 AS Branch');
                $this->db->from('main_relations');
                $this->db->join('main_groups', 'main_groups.Id_0 = main_relations.Group_8', 'left');
                $this->db->join('main_branches', 'main_branches.Id_0 = main_relations.Branch_9', 'left');
                $this->db->where("main_relations.Status_2 !='0'");
                $this->db->where("main_relations.Account_3 ='" . $account_id . "'");
                $this->db->where("main_relations.User_7 ='" . $user_id . "'");
                
                if($userID != NULL)
                {
                    $this->db->where("main_relations.User_7 IN (".$userID.")");
                }
                if($groupID != NULL)
                {
                    $this->db->where("main_relations.Group_8 IN (".$groupID.")"); 
                }
                if($branchID !=NULL)
                {
                    $this->db->where("main_relations.Branch_9 IN (".$branchID.")"); 
                }
                if($roleID !=NULL)
                {
                    $this->db->where("main_relations.Type_10 IN (".$roleID.")"); 
                }
                $this->db->order_by('main_relations.Date_1 ASC');
                $queryResults = $this->get_all();
                
                return $queryResults;
        }
        
        public function get_all_accounts()
        {
                $this->_table_name = '';
                $user_id = $this->session->userdata('user_id');
                
                $this->db->select('main_profiles.Firstname_9, main_relations.*, main_accounts.Business_7, main_accounts.Pageid_24');
                $this->db->from('main_profiles');
                $this->db->join('main_relations', 'main_relations.User_7 = main_profiles.Id_0', 'left');
                $this->db->join('main_accounts', 'main_relations.Account_3 = main_accounts.Id_0', 'left');
                $this->db->where("main_profiles.Id_0 ='".$user_id."'");               
                $this->db->select('main_profiles.Firstname_9, main_relations.*, main_accounts.Business_7, main_accounts.Pageid_24');

                $this->db->where("main_profiles.Status_2 !='0'");
                $this->db->where("main_relations.Status_2 !='0'");
                $this->db->where("main_accounts.Status_2 !='0'");
                $this->db->order_by('main_accounts.Business_7 ASC');
                
                $queryResults = $this->get_all();
                return $queryResults;
        }
        
        
        
        /**
         * Password - required a username + a password
         * Should be using Email or Mobile phone as username
         * By Papin - Update 16 01 2015
        */
        public function get_new_password()
        {
                  $alphab="qsdfreTDHjavghkoyfgQWERTYUmnbvcxzlkjhgfdsapoiuytrewqIOPASDFGHJKLMNBVCXZ*";
                  $letters=str_shuffle($alphab);
                  $letters=str_replace(" ", "",$letters);
                  $numb="1234567890";
                  $p1=substr(str_shuffle($letters), 0, 3);
                  $p2=substr(str_shuffle($numb), 0, 2);
                  $p3=substr(str_shuffle($letters), 0, 3);
                  $p4=substr(str_shuffle($numb), 0, 2);
                  $key=$p1."".$p2."".$p3."".$p4;
                  return $key;
        }
        
        public function generate_hash($password) 
        {
                if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) 
                {
                        $salt = '$2y$11$' . substr(md5(uniqid(rand(), true)), 0, 22);
                        return crypt($password, $salt);
                }
                else
                {
                        return false;
                }
        }

        public function hash($string)
        {
                return hash('sha512', $string . config_item('encryption_key'));
        }
        
        /**
         * Profile  get details
         * By Papin - Update 16 01 2015
        */
        public function get_otp_code($type='integer')
        {
                if($type=='integer')
                {
                        return rand('100000','999999');
                }
                else
                {
                        $alphab="QWERTYUmnbvcxzlkjhgfdsapoiuytrewqIOPASDFGHJKLMNBVCXZ";
                        $letters=str_shuffle(strtoupper(trim($alphab)));
                        $letters=str_replace(" ", "",$letters);
                        $numb="1234567890";
                        $p1=substr(str_shuffle($letters), 0, 2);
                        $p2=substr(str_shuffle($numb), 0, 2);
                        $p3=substr(str_shuffle($letters), 0, 2);
                        $key=$p1."".$p2."".$p3;
                        return $key;
                }
        }
        
        /**
         * Logout
         * By Papin - Update 16 01 2015
        */
        public function logout()
        {
                if(isset($_SESSION['page_details'])) $page_details = $_SESSION['page_details'];
                $this->session->sess_destroy();
                session_start();
                if(isset($page_details)) $_SESSION['page_details'] = $page_details;
        }
        
        
        
	/**
         * Save methods
         * By Papin - Update 16 01 2015
        */	
        public function save_account($data, $id)
        {
                $this->set_table('main_accounts', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_profile($data, $id)
        {
                $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id); 
        }

        public function save_site($data, $id)
        {
                $this->set_table('main_branches', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_group($data, $id)
        {
                $this->set_table('main_groups', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_relation($data, $id)
        {
                $this->set_table('main_relations', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        

        public function update_relation($data, $id) {
                $this->db->where('User_7', $id);
                return $this->db->update('main_relations',$data);
        } 
        
        public function save_application($data, $id)
        {
                $this->set_table('main_accounts', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
		
}

