<?php
    class Offline_model extends MY_Logiref_Ebcdc_Integration {
	
        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        
        
	public function __construct()
	{
		parent::__construct();
                
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        public function get_integration_offline_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();

                        $obj->Instructions_7 = '';
                        $obj->Pathexcel_8 = '';
                        $obj->Pathxml_9 = '';
                        $obj->Paiements_10 = '';
                        $obj->Instructions_11	 = '';
                        $obj->Montant_12 = '';
                        $obj->Regie_13 = '';
                        $obj->Agence_14	 = '';
                        $obj->Checker_15 = '';
                        $obj->Devise_16 = '';
                        $obj->Paiements_17 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_cbs_integration_offline', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_bulletins_instructions($ids) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Paiementid_4 IN($ids) AND Status_2 = '1' AND Priority_24 > 0";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                return $this->get_all();
        }
        
        public function get_prepayments_instructions($ids) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_prepayments_instructions.*', 'logiref_cbs_prepayments_instructions.Id_0 ASC');
                $this->db->from('logiref_cbs_prepayments_instructions');
                $st = " Paiementid_4 IN($ids) AND Status_2 = '1' AND Priority_24 > 0";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_prepayments_instructions.Id_0 ASC');
                return $this->get_all();
        }
        
        
        public function get_dgi_instructions($ids) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgi.*', 'logiref_cbs_instructions_dgi.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgi');
                $st = " Paiementid_4 IN($ids) AND Status_2 ='1'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgi.Id_0 ASC');
                return $this->get_all();
        }
        
        public function get_dgrad_instructions($ids) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgrad.*', 'logiref_cbs_instructions_dgrad.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgrad');
                $st = " Paiementid_4 IN($ids) AND Status_2 = '1'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgrad.Id_0 ASC');
                return $this->get_all();
        }
        
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_integrations($status = NULL)
        {
                $this->_table_name = '';
                #Query
                $user = $this->session->userdata('user_id');
                $account = $this->session->userdata('account_id');
                $this->db->select('logiref_cbs_integration_offline.*', 'logiref_cbs_integration_offline.Id_0 DESC');
                $this->db->from('logiref_cbs_integration_offline');
                $st = "Creator_4 ='".$user."' AND Account_3='" . $account . "'";
                if($status == "nvalidated" || $status == NULL) $st .= " AND Status_2 = 1";
                if($status == "validated") $st .= " AND Status_2 = 2";
               
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */
       
        public function save_integrations($data, $id)
        {
                $this->set_table('logiref_cbs_integration_offline', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function update_integrations($data, $ref) {
                $this->db->where("logiref_cbs_integration_offline.Id_0 ='".$ref."'");
                return $this->db->update('logiref_cbs_integration_offline',$data);
        }
                
      
}

