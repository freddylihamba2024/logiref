<?php
class Dgrk_model extends MY_Logiref_Ebcdc_Integration {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata('account_id');
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_new_payments($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_integration_dgrk.*');
                $this->db->from('logiref_integration_dgrk');
                $this->db->where("logiref_integration_dgrk.Account_3 ='".$account_id."' AND Status_2 = '1' ");
                $this->db->order_by('logiref_integration_dgrk.Id_0');
                return $this->get_all();
	}
        
        public function get_validated_payments($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_integration_dgrk.*');
                $this->db->from('logiref_integration_dgrk');
                $this->db->where("logiref_integration_dgrk.Account_3 ='".$account_id."' AND Status_2 = '2' ");
                $this->db->order_by('logiref_integration_dgrk.Id_0');
                return $this->get_all();
	}
        
        public function get_confirmed_payments($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_integration_dgrk.*');
                $this->db->from('logiref_integration_dgrk');
                $this->db->where("logiref_integration_dgrk.Account_3 ='".$account_id."' AND Status_2 = '3' ");
                $this->db->order_by('logiref_integration_dgrk.Id_0');
                return $this->get_all();
	}
        
        public function get_paiement_dgrk($id =NULL)
        {
                if($id !=NULL)
                {
                        $this->set_table('logiref_integration_dgrk I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function update_paiement_dgrk($data, $ids) 
        {
                $this->db->where("logiref_integration_dgrk.Id_0 IN (".$ids.")");
                return $this->db->update('logiref_integration_dgrk', $data);
        }
        
        
        
}