<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bulletin extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'bulletins';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/bulletins_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/fees_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'bulletin';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1', $this->data);
                }
                elseif($obj == "verification") 
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_checkbl($credentials);
                        $response = trim($response);
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000')
                        {
                                echo $response; die;
                        }
                        else
                        {
                            
                                $amount = str_replace(' ','',$_POST['Amount']);
                                $amount = str_replace(',','.',$amount);
                                $devise = $_POST['devise'];
                                $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                                $service = $_POST['Office'];
                                $agence = $_SESSION['Logiref_guichet'];
                                $mode = $_POST['Mode'];

                                $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                if($devise !='CDF')
                                {
                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        }
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                }
                                else
                                {
                                        $devise_taux = 1;
                                }

                                if(isset($_POST['Nif']))
                                {
                                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                        $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                                }


                                if(!isset($_POST['Commission']))
                                {
                                        $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                                $com['com'] = ($amount * $rules['Valeur'])/100;
                                                $com['devise'] = $devise;
                                        }
                                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }
                                        if(!empty($com) && $com['com']!=0)
                                        {
                                                if($com['devise'] !='CDF')
                                                {
                                                        $this->data['commission'] = $com['com'] * $devise_taux;
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                                else
                                                {
                                                        $this->data['commission'] = $com['com'];
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                        }
                                        else
                                        {
                                                $this->data['commission'] = $amount*0;
                                                $this->data['commission_devise'] = $devise;
                                                $this->data['total_amount'] = $amount + $this->data['commission'];
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                else 
                                {
                                        $commission = str_replace(' ','',$_POST['Commission']);
                                        $commission = str_replace(',','.',$commission);
                                        
                                        $this->data['commission'] = $commission;
                                        $this->data['commission_devise'] = $_POST['Devise_commission'];

                                        if($_POST['Devise_commission'] !="CDF")
                                        {
                                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                {
                                                        $devise_taux = $_POST['Taux'];
                                                }
                                                else
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        $devise_taux = $taux['Dollar_4'];
                                                }
                                                $commission = $this->data['commission'] * $devise_taux;
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        else
                                        {
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                # Balance verification
                                if($_POST['account_currency']=="" || $_POST['account_balance']=="")
                                {
                                        echo 'E411';
                                }
                                else 
                                {
                                        if($_POST['account_currency'] == 'CDF')
                                        {
                                                $tva =  $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;
                                                
                                                if($_POST['account_balance'] >= $amount_to_pay)
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                }
                                                else 
                                                {
                                                        $this->data['account_balance']= "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        }
                                        elseif($_POST['account_currency'] == 'USD')
                                        {
                                                $tva =  $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;
                                                
                                                $taux = $this->data['bank_rate_applied'];
                                                
                                                # convert amount in USD
                                                $amount_to_pay = $amount_to_pay/$taux;
                                                
                                                if($_POST['account_balance'] >= $amount_to_pay)
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                }
                                                else 
                                                {
                                                        $this->data['account_balance']= "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        }
                                }
                                
                                $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                                
                                $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                                                    
                                if($mode =='7')
                                {
                                        $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                        $this->data['disabled'] = "";
                                }
                                else 
                                {
                                        $this->data['referenceOP'] = "";
                                        $this->data['disabled'] = "disabled";
                                }

                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_details', $this->data);
                        }
                }
                elseif($obj == "confirmation") 
                {
                        $data['bank_account'] = $_POST['Paiementid'];
                        $data['Devise_account'] = $_POST['Devise_account'];
                        
                        $return = $this->curl_model->call_bank_reservation($data);
						
                        if($return == '200')
                        {
                                # Save the return of the first transactions in the database
                                $this->save('cbs_return', $id, $response);
                                
                                $user = $this->session->userdata('user_id');
                                $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                                $response = $this->curl_model->call_bank_comptant_single($credentials);
                                $response = trim($response);
                        }
                        else 
                        {       
                                $response = $return;
                        }
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000' || $response == 'E300' || $response == 'E411' || $response == 'E162' || $response == 'E463' || $response == 'E3238' || $response == 'E397' || $response == 'W0205' || $response == 'E405')
                        {
                                if($response == 'E404')
                                {
                                        $message = " Error 404 : Sydonia not available ";
                                        //$this->curl_model->call_set_log($message, "sydonia");
                                }
                                
                                echo $response; die;
                        }
                        else
                        {
                                $message = "Success : Connection to sydonia for payment confirmation was successful ";
                                //$this->curl_model->call_set_log($message, "sydonia");
                                echo $response; die;
                        }
                        
                }
                elseif($obj == "batch_start") 
                {
                    
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['step'] = 0;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_start', $this->data);
                
                }
                elseif($obj == "batch_step_2") 
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['nif'] = $_POST['Nif'];
                        $this->data['agent'] = $_POST['agent'];
                        $this->data['quota'] = $_POST['quota'];
                        $this->data['office'] = $_POST['office'];
                        $this->data['mode'] = $_POST['mode'];
                        $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                        $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                        $this->data['step'] = 1;
                        $this->load->view($this->module.'/'.$this->group. '/bulletins/_batch_step_2', $this->data);
                
                }
                elseif($obj == "batch_verification") 
                {
                        $amounts = $_POST['amounts'];
                        $account_devise = isset($_POST['cdevise']) ? $_POST['cdevise'] : "";
                        $service = $_POST['office'];
                        $agence = $_SESSION['Logiref_guichet'];
                        $mode = $_POST['mode'];
                        $commission = 0;
                        $total_amount = 0;
                        $response = array();
                        $account_client = isset($_POST['account']) ? $_POST['account'] : "";
                        $cdata['regie'] = "DGDA";
                        $cdata['service']= $_POST['office'];
                        $cdata['recette']= NULL;
                        $cdata['devise'] = "CDF";
                        $cdata['guichet'] = $agence;
                        $response['items'] = count($amounts);
                        foreach($amounts as $amount)
                        {
                                $cdata['montant'] = $amount;
                                $response['commissions'][] = $this->data('get_commission', $cdata);
                                $total_amount = $total_amount + $amount;
                        }
                        
                        
                        if($mode =='7')
                        {
                                $balance = $this->curl_model->call_bank_checkbalance($account_client);
                                $balance = trim($balance);
                                if($balance == "E005")
                                {
                                        $response['balance'] = "Non approvisionné";
                                }
                                else
                                {
                                        
                                        $response['balance'] = "Approvisionné";
                                }
                        }
                        else 
                        {
                                $response['balance'] = "";
                                
                        }
                        
                        $response['total'] = $total_amount;
                        echo $response = json_encode($response);
                        die;
                        
                }
                elseif($obj == "batch_confirmation")
                {
                        $nif = $this->data['nif'] = $_POST['nif'];
                        $this->data['agent'] = $_POST['agent'];
                        $this->data['office'] = $_POST['office'];
                        $mode = $this->data['mode'] = $_POST['mode'];
                       
                        $account = (isset($_POST['account']))? $_POST['account']:'';
                        $devise = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                        
                        $client = $this->logiref_model->get_clients_by_nif($nif);
                        if($client !=NULL) $_POST['designation'] = $client->Designation_5; else $_POST['designation'] ='';
                        
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                        
                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata('account_id');
                        $_POST['User'] =  $this->session->userdata('user_id');
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                       
                        set_time_limit(250);
                        $data = $_POST;
                        
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        
                        $data['bank'] = $encrytions->codebank;
                        $data['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                        $data['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                        $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                        $result = $this->curl_model->call_bank_comptant_batch($data);
//                        $result = array('36','37','38');
//                        $result = implode(",",$result);
                        if($result=='E003' || $result=='E22' || $result=='E21' || $result=='E11' || $result=='E34' || $result == 'E404' || $result == 'E501' || $result == 'E4' || $result == 'E000')
                        {
                            
                                echo $result; die;
                                
                        }
                        else
                        {
                                $this->data['bulletins'] = $this->bulletins_model->get_bulletins_by_lot($result);
                                $this->data['account'] = $account;
                                $this->data['cdevise'] = $devise;
                                $this->data['status'] = $this->integration_model->sydonia_error_code;
                                $this->data['color'] = $this->integration_model->bl_statuscolor;
                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['step'] = 1;
                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3', $this->data);
                            
                        }
                }
                elseif($obj == "edit")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        $agence_src= $_SESSION['Guichet_code'];
                        
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        $info = $encaissement->Notereference_30;
                        
                        $guichet = $this->session->userdata("Logiref_guichet");
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        $instructions2 = array();

                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                        $taxes = $info['taxesPaid'];

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        //var_dump($this->data['instructions']); die;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "preview")
                {
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="")?$_GET['view']:'';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "getquittance")
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        #initialisation
                        $apidata = array();
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);
                        
                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                        {
                                $quittance = $bulletin->Pdfcontent_18;
                                echo $quittance;
                        }
                        else
                        {
                                $declaration = json_decode($bulletin->Results_13);
                                $apidata['ReceiptSerial'] = $declaration->receiptSerial;
                                $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                                $apidata['ReceiptDate'] = $declaration->receiptDate;
                                $apidata['Office'] = $bulletin->Office_6;
                                $apidata['Account'] = $this->session->userdata('account_id');
                                $apidata['Paiementid'] = $bl;
                                $apidata['User'] = $this->session->userdata('user_id');
                                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                                $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                                
                                $response = $this->curl_model->call_dgda_quittance($apidata);
                                
                                if($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000")
                                {
                                        echo $response;
                                }
                                else
                                {
                                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);

                                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                                        {
                                                $quittance = $bulletin->Pdfcontent_18;
                                                echo $quittance;
                                        }
                                        else
                                        {
                                                echo "E406";
                                        }
                                }
                        }
                       
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error! To assign a member to a group, please select both a member and a group.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();
                                
                                $data = $_POST;
                                $data['Status_2'] = 0;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');

                                $infos = $data['Infos'];
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                                $data['Beneficaire_15'] = 'DGDA';

                                # SAVE PAYMENT
                                
                                $results = $infos;
                                $prefix = 1;
                                $logirefid = $data['Logirefid_4'];
                                $end_execution = NULL;

                                # Comptabilisation
                                # Prmiere partie - 
                                $Missmatch['Missmatch_32'] = 0;
                                
                                $agence_src= $_SESSION['Guichet_code'];
                                
                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                
                                switch ($case)
                                {
                                        case "case_1": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                        case "case_2": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                break;
                                        case "case_3": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                break;
                                        case "case_4": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                break;
                                        default: 
                                                //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                }
                                
                                if(!empty($instructions))
                                {
                                        $this->comptabilisation_model->save_instructions($id, $data, $instructions, NULL);
                                }
                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT
                                $guichet = $this->session->userdata("Logiref_guichet");
                                $agence_src= $_SESSION['Logiref_guichet'];
                                $compte_cpt = isset($comptes['CPT']['CPT'][$data['Devise_12']]) ? $comptes['CPT']['CPT'][$data['Devise_12']] : '00000000000000000000000'; 
                                $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                #Taxes comptes
                                unset($comptes);
                                $comptes = array();
                                $instructions = array();
                                
                                $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                                $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                                
                                $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                                $taxes = unserialize($results['taxesPaid']);

                                foreach($taxes as $taxe)
                                {
                                        
                                        $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;

                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $data['Tresor_45'] = '1';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];
                                                
                                                $type_rectte = $type_recettes[$taxe->taxeCode];
                                                
                                                $pid = $this->encaissement_model->save_payment_tresor($data, NULL);
                                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                $instructions[] = $instruction;
                                        }
                                        else if(isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                $instructions[] = $instruction;
                                        }
                                        else
                                        {
                                                $Missmatch['Missmatch_32'] = 1;
                                        }
                                        $data['Id_0'] = $pid;

                                        $prefix++;
                                }

                                if(!empty($instructions))
                                {
                                        $end_execution = $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instructions, $data['Logirefid_4'], $priority);
                                        unset($instructions);
                                }
                                
                                if($end_execution)
                                {
                                        $bl_data['Status_2'] = '2';
                                        $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
                                }
                                
                                echo $data['Sydonia_44'];
                                
                        }
                }
                elseif($obj == "validate")
                {
                        $data = $_POST;
                        $code = '';
                        
                        if(isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "")
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                {
                                        # Invoque the api cancel reservation
                                        $api_data = $_POST['Compte_33'];
                                        $api_data = $_POST['Devise_34'];
                                        
                                        $response = $this->curl_model->call_bank_cancel_reservation($data);
                                        
                                        if($response == '200')
                                        {
                                                #Invocation of the api transfer
                                                @set_time_limit(300);

                                                $response = $this->curl_model->call_bank_virement($data);
                                                $return = json_decode($response, true);

                                                if(isset($return['response']) && $return['response'] == "200")
                                                {
                                                        $code = 200;
                                                        $id = $_POST['Sydonia_44'];

                                                        # Data to save in the in logiref_cbs_return
                                                        $data_cbs['Date_1']= gmdate('Y-m-d H:i:s');
                                                        $data_cbs['Status_2'] = 1;
                                                        $data_cbs['Account_3'] = $this->session->userdata('account_id');
                                                        $data_cbs['Sydonia_5'] = $id;
                                                        $data_cbs['Result_6'] = $response;

                                                        # Save in logiref_cbs_return
                                                        $this->integration_model->update_cbs_return($data_cbs, $id);


                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');


                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                                                        $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                                                        if($tid)
                                                        {
                                                                $bl_data['Status_2'] = '3';
                                                                $bl = $this->integration_model->update_bulletin($bl_data, $id);
                                                        }
                                                        
                                                }
                                                elseif(isset($return['response']) && $return['response'] !="")
                                                {
                                                        # Invoque the api reservation
                                                        $api_data = $_POST['Compte_33'];
                                                        $api_data = $_POST['Devise_34'];

                                                        $response = $this->curl_model->call_bank_reservation($api_data);
                                                        
                                                        $code = $return['response'];
                                                }
                                        }
                                        else 
                                        {
                                                echo 0;
                                        }
										
                                        
                                }
                                if(isset($bl) && $bl > 0) 
                                {
                                        $retour = array('code'=>$code, 'id'=>$id);
                                        echo json_encode($retour);
                                }
                                else
                                {
                                        echo 0;
                                }
                                
                        }
                }
                elseif($obj == "bulletin")
                {
                        $data['Status_2'] = 0;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Designation_23'] = $_POST['designation'];
                        
                        //Formatting amount
                        $data['Amount_12'] = str_replace(' ','',$_POST['Amount']);
                        $data['Amount_12'] = str_replace(',','.',$data['Amount_12']);
                        
                        $data['Devise_27'] = $_POST['devise'];
                        $data['Year_5'] = $_POST['Year'];
                        $data['Serie_7'] = $_POST['Series'];
                        $data['Number_8'] = $_POST['Number'];
                        $data['Agent_10'] = $_POST['Agent'];
                        $data['Office_6'] = $_POST['Office'];
                        $data['Nif_9'] = $_POST['Nif'];
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Bank_11'] = $_POST['Bank'];
                        $data['User_15'] = $this->session->userdata('user_id');
                        $data['Reference_19'] = $_POST['reference'];
                        $data['Mode_30'] = $_POST['Mode'];
                        $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                        
                        $id = $this->integration_model->save_bulletin($data, NULL);
                        
                        if($id != "")
                        {
                                $data = array();

                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Agence_20']=$_SESSION['Logiref_agence'];
                                $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                $data['Mode_19'] = $_POST['Mode'];
                                $data['Typerecette_17'] = $_POST['Series'].$_POST['Number'];
                                $data['Devise_34'] = 'CDF';
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$_POST['Amount']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                
                                $data['Devise_12'] = $_POST['devise'];
                                $data['Compte_33'] = $_POST['bank_account'];
                                $data['Noteid_26'] = $_POST['Series'].$_POST['Number'];
                                
                                
                                //Formatting amount
                                $data['Commission_23'] = str_replace(' ','',$_POST['Commission']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                $data['Devise_24'] = $_POST['Devise_commission'];
                                $data['Nif_13'] = $_POST['Nif'];

                                $agence_src= $_SESSION['Guichet_code'];

                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                switch ($case)
                                {
                                        case "case_1": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                        case "case_2": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                break;
                                        case "case_3": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                break;
                                        case "case_4": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                break;
                                        default: 
                                                break;
                                }
                                
                                
                        }
                        
                        return $id;
                }
                elseif($obj == "cbs_return")
                {
                        if($id !="" && $arg != "")
                        {
                                # Data to save in the in logiref_cbs_return
                                $data['Date_1']= gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata('account_id');
                                $data['Sydonia_5'] = $id;
                                $data['Result_6'] = $arg;

                                # Save in logiref_cbs_return
                                $this->integration_model->save_cbs_return($data, NULL);
                        }
                }
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "get_commission")
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }
                        
//                      //Montant total
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;
                        
                        if($cdata['devise'] == $oDeivise)
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'];
                        }
                        else if($cdata['devise'] == 'USD')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']*$taux['Dollar_4']);
                        }
                        else if(result[1] == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']/$taux['Dollar_4']);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
                        
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar; exit;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */