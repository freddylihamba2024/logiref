<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Impression extends MY_Controller {
        /*
         * Presentation: gestion des impression(production des documents PDF)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'impression';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('MY_Main');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model('logiref/stakeholders_model');
				$this->load->model($this->module.'/reports_model');
				$this->load->model($this->module.'/fees_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model('main/main_model');
                
                $this->load->library('m_pdf');
                $this->load->library('ciqrcode');
                
                $this->folder = 'impression';
                
	} 
	
        
	public function index()
	{
               
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
	public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
		if($obj == "export_comptes") 
                {  
                        $comptes = $this->accounts_model->get_export_comptes();
                        $types = $this->logiref_model->get_dropdown("types","Compte");
                        $users = $this->main_model->get_dropdown('users_array');
                        $agences = $this->branches_model->get_dropdown("guichets");
                        $services =$this->logiref_model->get_dropdown("services");
                        $recettes = $this->logiref_model->get_dropdown("recettes");
                        $villes = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $guichets = $this->branches_model->get_dropdown("guichets");
                                               
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_comptes');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Agence","Type","Taxe","Libelle","Service/Bureau","Comptes","Devise","Beneficiaire");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($comptes);
                        $datas = $this->session->userdata('datas');
                        
                        if(isset($datas) && $datas !="")
                        {
                                $comptes = $datas;
                        }
                        
                        foreach($comptes as $row)
                        {
                                 $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                array(
                                                                    'code' =>'###'
                                                                )
                                );
                                
                                if(isset($guichets[$row->Agence_12]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $guichets[$row->Agence_12]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Type_4);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Recette_13);
								if($row->Type_4 ="CPS")$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Comptesydonia_18);
                                else if(isset($recettes[$row->Beneficiaires_5][$row->Recette_13]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $recettes[$row->Beneficiaires_5][$row->Recette_13]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Serviceid_16);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Agenceid_15.''.$row->Compte_6.''.$row->Clef_7);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Devise_8);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Beneficiaires_5);
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        if(isset($guichets[$row->Agence_12]) && $guichets[$row->Agence_12]!='')
                        {
                                $filename= $guichets[$row->Agence_12].'.xlsx';
                        }
                        else 
                        {
                            $filename= 'Les_comptes'.'.xlsx';
                        }
                        
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-comptes';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
				if($obj == "export_users")
                {
                        $statut = $this->users_model->status;
                        $members = $this->users_model->get_members();
                        $villes = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $groups = $this->logiref_model->get_groups();
                        $agences = $this->branches_model->get_dropdown("agences");
                        $roles = $this->users_model->role;
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $users_login = $this->main_model->get_dropdown('users_profil');

                        $users = $this->main_model->get_dropdown('users_array');
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_users');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Id Finacle","Nom complet","Role","Agence","Statut","Date creation","Derniere connexion");
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;

                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                       

                        $array_length = count($members);
                        #$datas = $this->session->userdata('datas');
                    
                        foreach($members as $row)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow,$row->Code_12);
                                if(isset($users[$row->Userid_13]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $users[$row->Userid_13]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $roles[$row->Role_4]);
                                if(isset($guichets[$row->Guichet_8]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $guichets[$row->Guichet_8]);
                                if(isset($statut[$row->Status_2]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $statut[$row->Status_2]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Date_1);
                                if(isset($users_login[$row->Userid_13]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $users_login[$row->Userid_13]);

                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= $guichets[$row->Guichet_8].'.xlsx';
                        #var_dump($statut);die;
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-utilisateurs';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                        
                }
				if($obj == "export_contribuable")
                {
                        $regies = $this->encaissement_model->get_dropdown("regies");
                        $beneficiaires = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $encaissements = $this->encaissement_model->get_paiements();
                        $guichets= $this->branches_model->get_dropdown("guichets");
                        $recettes = $this->logiref_model->get_dropdown('recettes');
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_contribuable');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date","Contribuable","Beneficiaire","Taxe","Service/Bureau","Montant", "Agence");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        $datas = $this->session->userdata('encaissements');
                        
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
                        
                        foreach($encaissements as $row)
                        {
                                 $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                array(
                                                                    'code' =>'###'
                                                                )
                                );
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                if(isset($beneficiaires[$row->Service_16]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $beneficiaires[$row->Service_16]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Montant_11.''. $row->Devise_12);
                                if(isset($guichets[$row->Guichet_21]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= $row->Designation_14.'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-contribuables';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
				elseif($obj == "report_dgidgrad")
                {

                        $beneficiaires= $this->reports_model->regies;
                        $encaissements = $this->reports_model->get_report_paiements();
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $recettes = $this->logiref_model->get_dropdown("recettes");
                        $alphas = range('A', 'Z');

                        $atoz = $alphas[7];

                        //load our new PHPExcel library

                        $this->load->library('Excel');

                        $objPHPExcel = new Excel();

                        //activate worksheet number 1

                        $objPHPExcel->setActiveSheetIndex(0);

                        //name the worksheet

                        $objPHPExcel->getActiveSheet()->setTitle('report_dgi_dgrad');

                        //set cell A1 content with some tex

                        $style4Array = array(

                            'font'  => array(

                                'bold'  => true,

                                'color' => array('rgb' => '000000'),

                                'size'  => 12,

                                'name'  => 'Book Antiqua'

                        ));        

                        $table_columns = array("Date","Régie","Service","Client","Montant", "Devise", "Agence");

                        $column = 0;
                        foreach($table_columns as $field)
                        {

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }

                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                         $datas = $this->session->userdata('encaissements');
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
						
                        foreach($encaissements as $row)
                        {

                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Service_16);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Montant_11);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Devise_12);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $guichets[$row->Guichet_21]);
                                if($i != $array_length)
                                {  
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {

                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }
                        $styleArray = array(

                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );

                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        $user_id = $this->session->userdata('user_id');
                        $filename=$user_id.'_report_dgidgrad'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

                        if($id == NULL)
                        {

                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgidgrad';

                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }

                                $path = $path."/".$filename;
                        }

                        //download the file in the browser
                        $objWriter->save('php://output');

                }
				elseif($obj == "report_dgrad")
                {
                        $beneficiaires= $this->reports_model->regies;
                        $encaissements = $this->reports_model->get_paiements_tresor_dgrad();
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $recettes = $this->logiref_model->get_dropdown("recettes");
						
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7];
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_dgrad');
                        //set cell A1 content with some tex
                        $style4Array = array(

                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));        

                        $table_columns = array("Date","Régie","Service","Client","Montant", "Devise", "Agence");
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($encaissements);
                         $datas = $this->session->userdata('encaissements');
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
                        foreach($encaissements as $row)
                        {

                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Service_16);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Montant_11);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Devise_12);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {  
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing

                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }
                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(

                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )

                        );

                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata('user_id');

                        $filename=$user_id.'_report_dgrad'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgrad';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');

                }
				   elseif($obj == "report_dgi_gu")
                {
                        $beneficiaires= $this->reports_model->regies;
                        $encaissements = $this->reports_model->get_report_paiements_dgi_gu();
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $recettes = $this->logiref_model->get_dropdown("recettes");
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7];
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_dgi_gu');
                        //set cell A1 content with some tex
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));        
                        $table_columns = array("Date","Régie","Service","Nature de paiement","Client","Montant", "Devise", "Agence");
                        $column = 0;
                        $array_length = count($encaissements);
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        $datas = $this->session->userdata('encaissements');
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
						
                        foreach($encaissements as $row)
                        {
                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Service_16);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Montant_11);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Devise_12);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $guichets[$row->Guichet_21]);
                                if($i != $array_length)
                                {  
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {

                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }
                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        $user_id = $this->session->userdata('user_id');
                        $filename=$user_id.'_report_dgi_gu'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgidgrad';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
				if($obj == "export_paydgda") 
                {  
                        $services = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $bulletins = (isset($_SESSION['bulletins'])) ? $this->session->userdata('bulletins') : $this->integration_model->get_reports_bls();

                        $guichets = $this->branches_model->get_dropdown("guichets");
						$users = $this->main_model->get_dropdown('users_array');
                                               
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_paydgda');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date Paiement","Service","Bulletin","Montant","Devise","Client","Agence","Date Saisie");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($bulletins);
                        $datas = $this->session->userdata('bulletins');
                        
                        if(isset($datas) && $datas !="")
                        {
                                $bulletins = $datas;
                        }
                        
                        $paiements = 0; 
                        
                        foreach($bulletins as $row)
                        {
                                $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                        array(
                                            'code' =>'###'
                                        )
                                );
                                
                                $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                $results = json_decode($row->Results_13);
                                $recieptDate = explode("/",$results->receiptDate);
                                $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "-");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $services['DGDA'][$row->Office_6]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Serie_7."".$row->Number_8);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, number_format($row->Amount_12,2,","," "));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, 'CDF');
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, ($row->Designation_23 =="") ? "Bulletin de liquidation / ".$row->Nif_9 : $row->Designation_23);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, isset($guichets[$row->Agence_32]) ? $guichets[$row->Agence_32] : "-");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                

                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $paiements  +=  $row->Amount_12;

                                $i++;
                                

                        }
                        
                        $objPHPExcel->getActiveSheet()->getStyle("A{$erow}:H{$erow}")->applyFromArray($style4Array);
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "Montant général");
                        $objPHPExcel->getActiveSheet()->mergeCells("A{$erow}:C{$erow}");
                        $objPHPExcel->getActiveSheet()->getStyle("A{$erow}")->getAlignment()->applyFromArray(
                            array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,)
                        );
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, 'CDF '.number_format($paiements,2,","," "));
                        
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'Les_paiements_dgda'.'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report_dgda';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
				if($obj == "export_paiement_tresor")

                {

                        $services = $this->logiref_model->get_dropdown("services", $service=NULL);

                       

                        if(isset($_SESSION['encaissements']))

                        {

                                $encaissements = $this->session->userdata('encaissements');

                               

                        }

                        else

                        {

                                $encaissements = $this->reports_model->get_paiements_tresor_gu();

                        }

                       

                        $guichets = $this->branches_model->get_dropdown("guichets");

                      

                        $alphas = range('A', 'Z');

                        $atoz = $alphas[9];

                        //load our new PHPExcel library

                        $this->load->library('Excel');

                        $objPHPExcel = new Excel();

                        //activate worksheet number 1

                        $objPHPExcel->setActiveSheetIndex(0);

                        //name the worksheet

                        $objPHPExcel->getActiveSheet()->setTitle('report_paiement_tresor');

                        //set cell A1 content with some tex

                       

                        $style4Array = array(

                            'font'  => array(

                            'bold'  => true,

                            'color' => array('rgb' => '000000'),

                            'size'  => 12,

                            'name'  => 'Book Antiqua'

                        ));        

                        $table_columns = array("Date","Régie","Client","Service","Compte prepaiement","Numero BL", "Montant BL", "Taxe",  "Montant Taxe", "Guichet");

                        $column = 0;

                       

                        foreach($table_columns as $field)

                        {

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);

                                $column++;

                        }

                        $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($style4Array);

                        $erow = 2;

                        $i = 0;

                       

                        $array_length = count($encaissements);

                        $datas = $this->session->userdata('encaissements');

                       

                        if(isset($datas) && $datas !="")

                        {

                                $instructions = $datas;

                        }

                        

                        foreach($encaissements as $row)

                        {

                                $objPHPExcel->getActiveSheet()->getStyle('G')->getNumberFormat()->applyFromArray(

                                    array(

                                        'code' =>'###'

                                    )

                                );

                               

                                if($row->Sydonia_44 != 0)

                                {

                                        $sydonia = $this->integration_model->get_paiement_sydonia_by_ref($row->Sydonia_44);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Designation_14);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $services[$row->Service_16]);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Noteid_26);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Noteid_26);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, number_format($sydonia->Amount_12,2,","," "));

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Typerecette_17);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, number_format($row->Montant_11,2,","," "));

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-");

                                }

                                elseif ($row->Sydonia_49 !=0)

                                {

                                        $prepaiements = $this->integration_model->get_prepaiement_sydonia($row->Sydonia_49);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Designation_14);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $services[$row->Service_16]);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $prepaiements ->Accountholder_29);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Noteid_26);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, number_format($prepaiements ->Amount_18,2,","," "));

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Typerecette_17);

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, number_format($row->Montant_11,2,","," "));

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-");

                                }

 

 

                                if($i != $array_length)

                                {  

                                        $erow++;

                                }

                                $i++;

 

                        }

                        //Sizing

                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {

                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);

                        }

 

                        $styleArray = array(

                              'borders' => array(

                                    'allborders' => array(

                                        'style' => PHPExcel_Style_Border::BORDER_THIN

                                    )

                              )

                        );

                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);

                        unset($styleArray);

                       

                        $user_id = $this->session->userdata('user_id');

                        $filename= 'paiement_tresor'.'.xlsx';

                       

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

                        header('Content-Disposition: attachment;filename="'.$filename.'"');

                        header('Cache-Control: max-age=0');

                        

                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

 

                        if($id == NULL)

                        {

                                $account_id = $this->session->userdata('account_id');

                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/synthese_dgi';

                                if (is_dir($path)==false)

                                {

                                        mkdir($path,0777,true);

                                }

                                $path = $path."/".$filename;

                        }

                        //download the file in the browser

                        $objWriter->save('php://output');

                }
                if($obj == "export_paiement_propre")
                {
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $services = $this->logiref_model->get_dropdown("services", $service=NULL);
                        if(isset($_SESSION['encaissements']))
                        {
                                $encaissements = $this->session->userdata('encaissements');
                        }
                        else
                        {
                                $encaissements = $this->reports_model->get_paiements_propres_gu();
                        }
                        $alphas = range('A', 'Z');
                        $atoz = !isset($_SESSION['encaissements']) ? $alphas[8] : $alphas[10];
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_paiement_propre');
                        //set cell A1 content with some tex
                        $style4Array = array(
                            'font'  => array(
                            'bold'  => true,
                            'color' => array('rgb' => '000000'),
                            'size'  => 12,
                            'name'  => 'Book Antiqua'
                        ));

                        if(!isset($_SESSION['encaissements']))
                        {
                                $table_columns = array("Date","Bulletin","Declaration", "Quitt", "OpÃ©rateur Economique", "Agence en Douane", "Mode de paiement", "Motif de paiement", "Montant");
                        }
                        else
                        {
                                $table_columns = array("Date","Bulletin","RÃ©gie", "Service", "Recette", "Importateur", "Bordereau", "Quitt.", "Devise", "Montant du bulletin", "Quota recette");
                        }
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:K1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        $array_length = count($encaissements);
                        $datas = $this->session->userdata('encaissements');
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
                        $total_general_bls = 0;
                        $total_general_paiements = 0;
                        foreach($encaissements as $row)
                        {
                                $objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->applyFromArray(
                                    array(
                                        'code' =>'###'
                                    )
                                );
                                if(!isset($_SESSION['encaissements']))
                                {
                                        $notereference = (isset($row->Notereference_30) && $row->Notereference_30 !="") ? json_decode($row->Notereference_30) : '';
                                        if($row->Sydonia_44 != 0)
                                        {
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, (isset($notereference->quittanceid) && $notereference->quittanceid!="") ? $notereference->quittanceid : '');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, (isset($notereference->quittanceid) && $notereference->quittanceid!="")? $notereference->quittanceid : '');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Designation_14);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, "");
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Reference_32);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Typerecette_17);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, number_format($row->Montant_11,2,","," "));

                                        }
                                        elseif ($row->Sydonia_49 != 0)
                                        {
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Beneficaire_15);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Designation_14);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $services[$row->Service_16]);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Devise_12.' '.number_format($row->Montant_11,2,","," "));
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, 'CDF '.number_format($row->Contrevaleur_22,2,","," "));
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Devise_24.' '.number_format($row->Commission_23,2,","," "));
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-");
                                        }
                                }
                                else
                                {
                                        $Infos = (isset($row->Notereference_30) && $row->Notereference_30 != "" ) ? json_decode($row->Notereference_30, true) : '';
                                        if($row->Sydonia_44 != 0)
                                        {

                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $services[$row->Service_16]);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Typerecette_17);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Designation_14);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, isset($row->Reference_32) ? $row->Reference_32 : '-');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, (isset($Infos['quittanceid']))? $Infos['quittanceid'] :'');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $row->Devise_12);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, number_format($row->Notemontant_28,2,","," "));
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, number_format($row->Montant_11,2,","," "));
                                        }
                                        elseif ($row->Sydonia_49 != 0)
                                        {

                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $services[$row->Service_16]);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Typerecette_17);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Designation_14);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, isset($row->Reference_32) ? $row->Reference_32 : '-');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, (isset($Infos['quittanceid']))? $Infos['quittanceid'] :'');
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $row->Devise_12);
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, number_format($row->Notemontant_28,2,","," "));
                                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, number_format($row->Montant_11,2,","," "));
                                        }
                                }
                                if($i != $array_length)
                                {  
                                        $erow++;
                                }
                                $total_general_bls = $total_general_bls + $row->Notemontant_28;
                                $total_general_paiements = $total_general_paiements + $row->Montant_11;
                                $i++;
                        }

                        if(isset($_SESSION['encaissements']))
                        {
                                $objPHPExcel->getActiveSheet()->getStyle("A{$erow}:K{$erow}")->applyFromArray($style4Array);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "Total gÃ©nÃ©ral");
                                $objPHPExcel->getActiveSheet()->mergeCells("A{$erow}:I{$erow}");
                                $objPHPExcel->getActiveSheet()->getStyle("A{$erow}")->getAlignment()->applyFromArray(
                                    array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,)
                                );
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, number_format($total_general_bls,2,","," "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, number_format($total_general_paiements,2,","," "));
                        }
                        else
                        {
                                $objPHPExcel->getActiveSheet()->getStyle("A{$erow}:I{$erow}")->applyFromArray($style4Array);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "Total GÃ©nÃ©ral");
                                $objPHPExcel->getActiveSheet()->mergeCells("A{$erow}:H{$erow}");
                                $objPHPExcel->getActiveSheet()->getStyle("A{$erow}")->getAlignment()->applyFromArray(
                                    array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,)
                                );
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, number_format($total_general_paiements,2,","," "). " CDF");
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++)
                        {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }
                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'paiement_propre'.'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/paiement_propre';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');

                }
				elseif($obj == "export_ci_comptes") 
                {  
                        $types = $this->logiref_model->get_dropdown("types","Compte");
                        $tusers = $this->main_model->get_dropdown('users_array');
                        $agences = $this->branches_model->get_dropdown("guichets");
                        $services =$this->logiref_model->get_dropdown("services");
                        $recettes = $this->logiref_model->get_dropdown("recettes");
                        $villes = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $regies = $this->stakeholders_model->get_dropdown("beneficiaries");
                        
                        if (isset($_SESSION['ci_comptes']))
                        {
                                $comptes = $_SESSION['ci_comptes'];
                        }
                        else
                        {
                                $comptes = $this->accounts_model->get_comptes("cptes");
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_comptes');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Agence","Type de compte","Taxe","Libelle","Service/Bureau","Comptes", "Régie", "Maker","Checker");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($comptes);
                        $datas = $this->session->userdata('datas');
                        
                        if(isset($datas) && $datas !="")
                        {
                                $comptes = $datas;
                        }
                        
                        foreach($comptes as $row)
                        {
                                 $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                array(
                                                                    'code' =>'###'
                                                                )
                                );
                                
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, isset($guichets[$row->Agence_12]) ? $guichets[$row->Agence_12]: '-');
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, isset($types[$row->Type_4]) ? $types[$row->Type_4] : '-');
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Recette_13);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, (isset($recettes[$row->Beneficiaires_5][$row->Recette_13])) ? $recettes[$row->Beneficiaires_5][$row->Recette_13]: "");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Serviceid_16);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Agenceid_15.''.$row->Compte_6.''.$row->Clef_7. ' '.$row->Devise_8);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Beneficiaires_5);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ');
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, (isset($users[$row->Checkerid_11]))?$users[$row->Checkerid_11]:' - ');

                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'report_comptes.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-comptes';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                        unset($_SESSION['ci_comptes']);
                }
				elseif($obj == "export_ci_users")
                {
                        $statut = $this->users_model->status;
                        $villes = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $groups = $this->logiref_model->get_groups();
                        $agences = $this->branches_model->get_dropdown("agences");
                        $roles = $this->users_model->role;
                        $guichets = $this->branches_model->get_dropdown("guichets");
                        $users = $this->main_model->get_dropdown('users_array');
                        
                        if(isset($_SESSION['membres']))
                        {
                                $members = $_SESSION['membres'];
                        }
                        else
                        {
                                //$members = array();
                                $members = $this->users_model->get_members();
                        }
                        

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_users');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Nom complet","Role","Ville","Nom de l'agence","Statut");
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;

                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        #var_dump($users);die;

                        $array_length = count($members);
                        $datas = $this->session->userdata('datas');
                        if(isset($datas) && $datas !="")
                        {
                                $members = $datas;
                        }
                    
                        foreach($members as $row)
                        {
                                if(isset($users[$row->Userid_13]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $users[$row->Userid_13]);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $roles[$row->Role_4]);
                                if(isset($agences[$row->Agence_7]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $agences[$row->Agence_7]);
                                if(isset($guichets[$row->Guichet_8]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $guichets[$row->Guichet_8]);

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, isset($statut[$row->Status_2])? $statut[$row->Status_2]:'-');

                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'users.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-utilisateurs';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                        
                        unset($_SESSION['membres']);
                        
                }
				 elseif($obj == "export_commissions")
                {
                        $beneficiaires = $this->encaissement_model->get_dropdown("regies");
                        $guichets = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $regles = $this->fees_model->get_regles("rgle");;
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_commissions');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Beneficiaire","Montant","Service","Recette", "Min", "Max", "Agences");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($regles);
                        $datas = $this->session->userdata('commissions');
                        
                        if(isset($datas) && $datas !="")
                        {
                                $commissions= $datas;
                        }
                        
                        foreach($commissions as $row)
                        {
                                $objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->applyFromArray(
                                                                array(
                                                                    'code' =>'###'
                                                                )
                                );
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Beneficiaire_5);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Value_9.' '.$row->Unite_10);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Service_6); 
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Recette_7); 
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Devise_13.' '.number_format($row->Min_11,2,","," "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Devise_13.' '.number_format($row->Max_12,2,","," "));
                                if(isset($guichets[$row->Guichet_8]))$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow( 6, $erow,$row->Guichet_8);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'report_commission'.'.xlsx';
                        //var_dump("tres");die;
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report_commission';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
                elseif($obj == "export_payment_agence")
                {
                        $beneficiaires = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $guichets = $this->branches_model->get_dropdown("guichets");
			$users = $this->main_model->get_dropdown('users_array');
                        
                        if (isset($_SESSION['payment_agence']) && $_SESSION['payment_agence'] != '')
                        {
                            $encaissements = $_SESSION['payment_agence'];
                        }
                        else
                        {
                            $encaissements = [];
                        }
                        
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_payment_agence');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date","Désignation","Bénéficiaire","Recette","Montant", "Commissions", "Opérateur", "Agence");
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;

                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        #var_dump($users);die;

                        $array_length = count($encaissements);
                        $datas = $this->session->userdata('datas');
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }
                    
                        foreach($encaissements as $row)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow,$row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Devise_12.' '.number_format($row->Montant_11,2,","," "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Devise_24.' '.number_format($row->Commission_23,2,","," "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ');
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ');
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= 'report_paiement_agence.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/paiement_agence';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter->save('php://output');
                        
                        unset($_SESSION['payment_agence']);
                        
                }
                elseif($obj=="print_paydgda")
                {
                        $this->data['bulletins'] = $this->session->userdata('bulletins');
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/impression/_print_paydgda', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
				
				if($obj == "schema")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logiref_model->documents;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        
                        //get instuctions
                        if($encaissement->Beneficaire_15 == "DGI"):
                            
                            $instrcutions = $this->comptabilisation_model->get_instructions_dgi($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGRAD"):
                            
                            $instrcutions = $this->comptabilisation_model->get_instructions_dgrad($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGDA"):
                            
                            $instrcutions = $this->comptabilisation_model->get_instructions_dgda($encaissement->Sydonia_44);
                        
                        endif;
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integration_model->get_cbs_returns($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        $this->data['lines'] = $instrcutions;
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_schema', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->WriteHTML('',1);
                        $pdf->WriteHTML($html,2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $pdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }
                        
                        $pdf->Output($pdfFilePath, "I");
                        
                        exit;  
                }
                if($obj == "schemabl")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logiref_model->documents;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                        
                        // 
                        if($arg !='' && $arg ='prepayment')
                        {
                                $encaissement = $this->encaissement_model->get_prepaiement_tresor_bl($id);
                        }
                        else
                        {
                                $encaissement = $this->encaissement_model->get_paiement_tresor_bl($id);
                        }
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        if(empty($encaissement))
                        {
                               if($arg !='' && $arg ='prepayment')
                               {
                                   $encaissement = $this->encaissement_model->get_prepaiement_propres_bl($id);
                               }
                               else
                               {
                                   $encaissement = $this->encaissement_model->get_paiement_propres_bl($id);
                               }
                                  
                        }
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integration_model->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        if($arg !='' && $arg ='prepayment')
                        {
                            $instrcutions = $this->comptabilisation_model->get_instructions_dgda_prepayment($id);
                        }
                        else
                        {
                            $instrcutions = $this->comptabilisation_model->get_instructions_dgda($id);
                        }
                        
                        $this->data['lines'] = $instrcutions;
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_schema_dgda', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->WriteHTML('',1);
                        $pdf->WriteHTML($html,2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $pdf->Output($pdfFilePath, "I");
                        
                        exit;  
                }
                elseif($obj == "attestation")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logiref_model->documents;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['months'] = $this->comptabilisation_model->months;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
						
                        # Suite numerique
                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                                $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;
                        }
						$agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                        
                        $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)? $agence->Nom_4:'...................';
                        $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                        # Display the amaount in letter
                        
						$montant = number_format($encaissement->Montant_11,2,",","");
						$contre_valeur = number_format($encaissement->Contrevaleur_22,2,",","");
                        $this->data['number_letter'] = $this->data('number_letter',$montant, $encaissement->Devise_12);
						$this->data['number_letters'] = $this->data('number_letter', $contre_valeur, "CDF");
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integration_model->get_cbs_returns($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata('account_id')."/". $this->session->userdata('user_id')."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".$this->data['encaissement']->Logirefid_4.'.png';
                        //$this->ciqrcode->generate($params);
                        
                        $service_type =$this->logiref_model->get_dropdown("type_services");
                        if($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27022470")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_taxegardienage', $this->data, true);
                        }
                        
						elseif($encaissement->Beneficaire_15 == "DGRAD")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dgrad', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI"  && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 =="AMRA")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge_amra', $this->data, true);
                                
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="DGE" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 =="TVA")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="DGE" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="TVA")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge_htva', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CDI" && $encaissement->Typerecette_17 !="IPRIER")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cdi', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] =="DGE" || $service_type[$encaissement->Service_16] =="CDI")&& $encaissement->Typerecette_17 =="IPRIER")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_iprier', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGDA")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dgda', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CIS" && $encaissement->Typerecette_17 =="IPRIER")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cis', $this->data, true);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CIS" && $encaissement->Typerecette_17 !="IPRIER")
                        {
                                $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cis', $this->data, true);
                        }
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->WriteHTML('',1);
                        $pdf->WriteHTML($html,2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $pdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }
                        
                        $pdf->Output($pdfFilePath, "I");
                        
                        exit;
                }
                elseif($obj=="attestationbl")
                {       
                        $this->data['typeDoc'] = $this->logiref_model->documents;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['villes'] = $this->logiref_model->get_dropdown('parameter', 'VILLE');
                        $this->data['users'] = $this->logiref_model->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                        
                        $encaissement = $this->encaissement_model->get_paiement_tresor_bl($id);
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissement_model->get_paiement_propres_bl($id);  
                        }
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = ($guichet->Ville_7!="")? $guichet->Ville_7 :'.................';
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integration_model->get_cbs_returns($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata('account_id')."/". $this->session->userdata('user_id')."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".$this->data['encaissement']->Logirefid_4.'.png';
                        //$this->ciqrcode->generate($params);
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_quittance', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	

                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->WriteHTML('',1);
                        $pdf->WriteHTML($html,2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "I");
                        exit;
                }
                elseif($obj=="print_users")
                {
                        $this->data['statut'] = $this->users_model->status;
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->users_model->state_Color;
                        $this->data['groups'] = $this->logiref_model->get_groups();
                        
                        if(isset($_POST['members']) && $_POST['members'] !="")
                        {
                                $this->data['members'] = json_decode($_POST['members']);
                        }
                        else
                        {
                                $this->data['members'] = array();
                        }

                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);

                        $this->data['roles'] = $this->users_model->role;

                        $this->load->model('MY_Main');
                        $this->load->model('main/main_model');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/impression/_print_users', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }

                elseif($obj=="print_client")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        
                        if(isset($_POST['encaissements']) && $_POST['encaissements'] !="")
                        {
                                $this->data['encaissements'] = json_decode($_POST['encaissements']);
                                
                        }
                        else 
                        {
                                $this->data['encaissements'] = array();
                        }
                        $this->data['agences'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->model('MY_Main');
                        $this->load->model('main/main_model');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/impression/_print_client', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
				
				elseif($obj=="print_contribuable")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        
                        if(isset($_POST['encaissements']) && $_POST['encaissements'] !="")
                        {
                                $this->data['encaissements'] = json_decode($_POST['encaissements']);
                                
                        }
                        else 
                        {
                                $this->data['encaissements'] = array();
                        }
                        $this->data['agences'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->model('MY_Main');
                        $this->load->model('main/main_model');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/impression/_print_contribuable', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        //$pdf->setFooter('<div>{PAGENO}/{nb}</div>');
                        //$pdf->SetFooter(' | Page {PAGENO}/{nbpg} |');
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
				elseif($obj=="print_gu_paiements_propres")
                {
                        $this->data['encaissements'] = $this->reports_model->get_paiements_propres_gu();
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/impression/_print_gu_paiements_propres', $this->data, true);
                       
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
				elseif($obj=="print_gu_paiements_tresor")
                {
						$this->data['encaissements'] = $this->reports_model->get_paiements_tresor_gu();
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
						$this->data['office'] = $_POST['Office'];
						$html = $this->load->view($this->module.'/banks/impression/_print_gu_paiements_propres', $this->data, true);
                       
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;

                        

                }
                elseif($obj=="print_paiements_taxegardiennage")
                {
                        if(isset($_POST['encaissements']) && $_POST['encaissements'] != "")
                        {
                                $this->data['encaissements'] = $encaissements = json_decode($_POST['encaissements']);	
                        }
                        else 
                        {
                                $this->data['encaissements'] = array();
								
                        }
                        
                        $montant_total = 0;
                        foreach ($encaissements as $row):
                            $montant_total += $row->Montant_11;
                        endforeach;

                        $this->data['number_letter'] = $this->data('number_letter', $montant_total, "CDF");
                        $this->data['date_paiement'] = $_POST['start'];
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/banks/impression/_print_paiements_taxegardiennage', $this->data, true);
                       
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_paiements_gu")
                {
                        $this->data['office'] = $_POST['Office'];
                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                        {
                                $bls = implode(',', $_POST['paiements']);
                                $this->data['bulletins'] = $this->integration_model->get_bulletins_by_lot($bls);
                         
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/impression/_print_paiements_gu', $this->data, true);
                        
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_bl")
                {
                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                        {
                                $this->data['bulletins'] = json_decode($_POST['bulletins']);
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        $this->data['agences'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/impression/_print_bl', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }

                elseif($obj=="print_commissions")
                {
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");

                        if(isset($_POST['commissions']) && $_POST['commissions'] !="")
                        {
                                $p = $this->data['paiements'] = json_decode($_POST['commissions']);
                        }
                        else
                        {
                                $this->data['paiements'] = array();
                        }

                        $html = $this->load->view($this->module.'/banks/impression/_print_commissions', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);

                        $pdf->WriteHTML($html);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
              
                elseif($obj == "print_regles")
                {
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        if(isset($_POST['regles']) && $_POST['regles'] !="")
                        {
                                $this->data['regles'] = json_decode($_POST['regles']);
                        }
                        else
                        {
                                $this->data['regles'] = array();
                        }
                        
                        $html = $this->load->view($this->module.'/banks/impression/_print_regles', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_comptes")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                       
                      
                        if(isset($_POST['comptes']) && $_POST['comptes'] !="")
                        {
                            
                                $this->data['comptes'] = json_decode($_POST['comptes']);
                                
                        }
                        else
                        {
                                $this->data['comptes'] = array();
                        }
                        $html = $this->load->view($this->module.'/banks/impression/_print_comptes', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_penalites")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissement_model->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integration_model->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                       
                        $this->data['encaissements'] = (isset($_POST['encaissements']) && $_POST['encaissements'] !="")? json_decode($_POST['encaissements']) : array();
                        $this->data['bulletins'] = (isset($_POST['bulletins']) && $_POST['bulletins'] !="")?json_decode($_POST['bulletins']) : array();
                        
                        $html = $this->load->view($this->module.'/banks/impression/_print_penalites', $this->data, true);
                        $account_id = $this->session->userdata('account_id');
                        $user_id = $this->session->userdata('user_id');
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$user_id."_".time().".pdf";	
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "number_letter")
                {
                    $value = $this->number_letter->converter($data, $arg);

                    return $value;
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */