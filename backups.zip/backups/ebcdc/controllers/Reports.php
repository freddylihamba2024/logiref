<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('taux','encaissements','list','reversements','reports','commissions','penalties','reporting','declarations','gudouane','ordres','nvalidated','validated','transferred','penalities', 'rapport', 'report_agence','report_clients', 'report_users','report_taxe', 'report_bl', 'pending', 'report_paydgda', 'report_dgrad_dgi', 'report_dgrad', 'prepaids', 'report_dgrk', 'batchs','alltaxe', 'all_taxes', 'report_payments', 'comptes', 'report_prepayments', 'report_comptes_cso', 'comptes_mad','passport','paiements_passports','online-taxes', 'nvalidatedpassport','validatedpassport','passports','nvalidatedpassports');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'ebcdc';
        public $folder = 'reports';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                
                $this->load->model($this->module.'/reports_model');
                $this->load->model($this->module.'/fees_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/prepayments_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/encaissement_model');
                
                $this->load->model($this->module.'/rates_model');
                $this->load->model('logiref/stakeholders_model');
                
                $this->load->model('main/main_model');
                
                $this->folder = 'reports';
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                ini_set('memory_limit','8192M');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "validated") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_validated_paiements();
                        $this->data['bulletins'] = $this->integration_model->get_validated_bls();
                        $this->data['prepayments'] = $this->prepayments_model->get_validated_bls();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "validatedpassport") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_validated_paiements_passports();
                        //$this->data['bulletins'] = $this->integration_model->get_validated_bls();
                        //$this->data['prepayments'] = $this->prepayments_model->get_validated_bls();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "pending") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_validated_paiements_by_user();
                        $this->data['bulletins'] = $this->integration_model->get_validated_bls_by_user();
                        $this->data['prepayments'] = $this->prepayments_model->get_validated_bls_by_user();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "pendingpassport") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_validated_paiements_passports_by_user();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "transferred") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
						$this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['encaissements'] = $this->integration_model->get_integrations_isys();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
			  elseif($obj == "filter_isys")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['isys'] = $this->integration_model->get_isys_filter($_POST);
                        $this->data['encaissements'] = $this->integration_model->get_integrations_isys();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "nvalidated") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_nvalidated_paiements();
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls();
                        $this->data['bulletins_batch'] = $this->integration_model->get_unvalidated_batch_bl();
                        $this->data['paiements_dgrk'] = []; 
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "nvalidatedpassports") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_nvalidated_paiements_passports();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "filterbacth") 
                {
                        $nif = $_POST['filter'];
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['batchs'] = $this->integration_model->get_unvalidated_batch_by_nif($nif);
                        
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/filterbacth', $this->data);
                }
                elseif($obj == "batchs") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['batchs'] = [];
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/batchs', $this->data);
                }
                elseif($obj == "prepaids") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls();
                        $this->data['compte_sydonia'] = $compte_sydonia = isset($this->data['prepayments'][0]) ? $this->data['prepayments'][0]->AccountRef_14 : "";
                        
                        $prepayment = $this->prepayments_model->get_prepayments_by_reference($compte_sydonia, "all");
                        
                        $amount = 0;
                        $frais_bcc = 0;
                        $i = 0;
                        
                        if(isset($prepayment) && $prepayment !="")
                        {
                                foreach($prepayment as $row)
                                {
                                        $amount = $row->Amount_18 + $amount;

                                        if($row->Fees_32 > 0)
                                        {
                                                $frais_bcc = $row->Fees_32 + $frais_bcc;
                                        }

                                        $i++;
                                }
                        }
                        $lot = isset($this->data['prepayments'][0]) ? $this->data['prepayments'][0]->Lot_19 : "";
                        $this->data['total_amount'] = $amount;
                        $this->data['total_fees'] = $frais_bcc;
                        $this->data['total_prepayment'] = $i;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['gu_instructions'] = $this->comptabilisation_model->get_prepayment_gu_instructions($lot);
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/prepaids', $this->data);
                }
               
                elseif($obj == "paiement_tresor") 
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reports_model->get_paiements_tresor_gu();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "paiement_propre") 
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reports_model->get_paiements_propres_gu();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
						
                }
                elseif($obj == "fond_propre") 
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reports_model->get_fond_propres();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "alltaxe") 
                {
						
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $encaissements = $this->data['encaissements'] = $this->reports_model->get_paiements_gu_alltaxe();
						//var_dump($encaissements);die;
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "all_taxes") 
                {
						
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $encaissements = $this->reports_model->get_paiements_gu_all_taxes();
                        
                        $i=1;
                        foreach($encaissements as $eKey => $eVal)
                        {
                                $all_tax['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]['datepayment'][]= $eVal->datepayment_tresor;
                                $all_tax['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]['amount'][]= $eVal->montant_tresor;
                                $all_tax['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]['devise'][]= $eVal->devise_tresor;
                                $all_tax['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]['guichet'][]= $eVal->guichet_tresor;
                                $all_tax['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]['designation'][]= $eVal->designation_tresor;
                                
                                $all_tax['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres]['datepayment'][]= $eVal->datepayment_propres;
                                $all_tax['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres]['amount'][]= $eVal->montant_propres;
                                $all_tax['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres]['devise'][]= $eVal->devise_propres;
                                $all_tax['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres]['guichet'][]= $eVal->guichet_propres;
                                $all_tax['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres]['designation'][]= $eVal->designation_propres;
                        
                                $i++;
                        }

                        $this->data['encaissements'] = $all_tax;
                        $this->data['allrecettes'] = $this->logiref_model->get_dropdown("recettes_all_dgda");
                        

                        $this->data['regies'] = $this->logiref_model->parternaire_regie;

                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        #$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
               
                elseif($obj == "filterpayment_taxe") 
                {
                        $this->data['encaissements'] = $_SESSION['type_recettes'] = $this->reports_model->get_paiements_filter_taxe_gu_reports($_POST);
                        
                        $type_recettes = array();
                        
                        foreach($this->data['encaissements'] as $eKey => $eVal)
                        {
                                $type_recettes['TRESOR'][$eVal->beneficaire_tresor][$eVal->typerecette_tresor]= $eVal->montant_tresor;
                                $type_recettes['PROPRE'][$eVal->beneficaire_propres][$eVal->typerecette_propres] = $eVal->montant_propres;
                                
                        }
                        $this->data['type_recettes'] = !empty($type_recettes) ? $type_recettes : [];
                        $this->data['regies'] = $this->logiref_model->parternaire_regie;
                        $this->data['allrecettes'] = $this->logiref_model->get_dropdown("recettes_all_dgda");
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "filter_gu")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reports_model->regies;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        if($status == 'tresor')
                        {
                                $this->data['encaissements'] = $this->session->encaissements = $this->reports_model->get_paiements_tresor_gu();
                        }
                        elseif($status == 'propre')
                        {
                                $this->data['encaissements'] = $encaissements=$this->reports_model->get_paiements_propres_gu();
                                $_SESSION['encaissements'] = $encaissements;
                        }
                        else 
                        {
                                $this->data['encaissements'] = $this->reports_model->get_fond_tresor();
                        }
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/filterresult', $this->data);
                }
                elseif($obj == "filterresult")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reports_model->regies;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
						$this->data['display'] = $obj;
                        
                        if($status == 'tresor')
                        {
                                $this->data['encaissements'] = $encaissements=  $this->reports_model->get_paiements_tresor($_POST);
                                $_SESSION['encaissements'] = $encaissements;
                        }
						elseif($status == 'tresor_dgi_gu')
                        {
                                $this->data['encaissements'] = $encaissements=  $this->reports_model->get_paiements_tresor_dgi_gu($_POST);
                                $_SESSION['encaissements'] = $encaissements;
								
                        }
                        elseif($status == 'tresor_dgrad')
                        {
                                $this->data['encaissements'] = $encaissements=  $this->reports_model->get_paiements_tresor_dgrad($_POST);
                                $_SESSION['encaissements'] = $encaissements;
								
                        }
                        elseif($status == 'propre')
                        {
                                $this->data['encaissements'] = $encaissements=$this->reports_model->get_paiements_propres();
                                 $_SESSION['encaissements'] = $encaissements;
                        }
                        else 
                        {
                                $this->data['encaissements'] = $this->reports_model->get_fond_tresor();
                        }
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/'.$obj, $this->data);
                }	
				
                elseif($obj == "filterresult_dgda")
                {
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['bulletins'] = $_SESSION['bulletins'] = $this->integration_model->get_reports_filter();
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->model('MY_Main');
						$this->load->model('main/main_model');
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/'.$obj, $this->data);
                }
                elseif($obj == "filter_nvalidated")
                {
                        $this->data['encaissements'] = $this->reports_model->get_filter_nvalidated_paiements();
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls();
                        $this->data['beneficiaires'] = $this->reports_model->regies;
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/'.$obj, $this->data);
                }
                elseif($obj == "ordres")
                {
                        $bank = $this->session->userdata('account_id');
                        if($id !="") $this->data['title'] = "Nouveaux odres des paiements";
                        else $this->data['title'] = "Tous les odres des paiements";
                        $this->data['ordres'] = $this->encaissement_model->get_ordres('bank',$bank, $id);
                        $this->data['from'] = $id;
                        $this->data['status'] = $this->encaissement_model->order_status;
                        $this->data['OrderColor'] = $this->encaissement_model->color_orders;
                        $this->load->view($this->module.'/'.$this->group. '/ordres/'.$obj, $this->data);
                }
                elseif($obj == "prepayments")
                {
                        $this->data['messages'] = $this->prepayments_model->ackmessages;
                        $this->load->view($this->module.'/'.$this->group. '/prepayments/prepayments', $this->data);
                }
                elseif($obj == "report_dgrk")
                {
                        $this->data['view'] = isset($id) ? $id : "";
                        $this->load->view($this->module.'/'.$this->group. '/reports/report_dgrk', $this->data);
                }
                elseif($obj == "declarationslist")
                {
                        $this->data['messages'] = $this->integration_model->declaration_ackmessages;;
                        $this->data['status'] = $this->integration_model->prepayments_status;
                        $this->data['color'] = $this->integration_model->prepayments_status_color;
                        $this->data['declarations'] = $this->integration_model->get_douane_declarations();
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/declarations', $this->data);
                }
                elseif($obj == "reports") 
                {
				       $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "report_payments") 
                {
                    $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_paydgda")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['bulletins'] = $_SESSION['bulletins'] = $this->integration_model->get_reports_bls();
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->model('MY_Main');
						$this->load->model('main/main_model');
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['display'] = $obj;
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "report_dgrad_dgi")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reports_model->regies;
                        $this->data['encaissements'] = $this->reports_model->get_report_paiements();
						$_SESSION['encaissements'] = $this->data['encaissements'];
						$data = array();
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['display'] = $obj;
                        $this->load->model('MY_Main');
						$this->load->model('main/main_model');
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);

                }
				 elseif($obj == "report_dgi_gu")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reports_model->regies;
                        $this->data['encaissements'] = $this->reports_model->get_report_paiements_dgi_gu();
                        $_SESSION['encaissements'] = $this->data['encaissements'];
                        $data = array();
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['display'] = $obj;
                        $this->load->model('MY_Main');
                        $this->load->model('main/main_model');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "report_dgrad")
                {

                        $status = $id;

                        $this->data['devises'] = $this->logiref_model->devises;

                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);

                        $this->data['beneficiaires'] = $this->reports_model->regies;

                        $this->data['encaissements'] = $this->reports_model->get_report_paiements_dgrad();

                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");

                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");

                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");

                        $this->data['display'] = $obj;

                       $this->load->model('MY_Main');

					   $this->load->model('main/main_model');

					   $this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);

                }
                elseif($obj == "report_nvalidated")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_paiements_to_regulate();
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate();
                        $this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "gu_bulletin")
                {
                        $this->data['typeDoc'] = $this->logiref_model->documents;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                       
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integration_model->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                         $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['bulletin'] = $this->integration_model->get_paiement_sydonia($id);
                        $this->data['encaissementBl'] = $this->data_model->sydonia_migrate_bl($id);
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "situation_dgda")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integration_model->get_all_instructions_dgda($day);
                        $this->data['events'] = $this->integration_model->get_cbs_returns_dgda_array($encaissements);
                        $this->data['comptes'] = $this->accounts_model->get_agence_comptes_array("'CGU','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "situation_dgi")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integration_model->get_all_instructions_dgi($day);
                        $this->data['events'] = $this->integration_model->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accounts_model->get_agence_comptes_array("'CPT','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "situation_dgrad")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integration_model->get_all_instructions_dgrad($day);
                        $this->data['events'] = $this->integration_model->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accounts_model->get_agence_comptes_array("'CPT','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "taxe_gardeinnage")
                {
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $this->reports_model->get_paiements_taxegardiennage_dgrad();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "filter_taxegardiennage")
                {
                        $this->data['encaissements'] = $this->reports_model->get_paiements_filter_taxegardiennage_dgrad($_POST);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
				elseif($obj == "passport")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements_agence'] = $this->reports_model->get_paiements_passport_dgrad();
                        $this->data['encaissements_online'] = $this->reports_model->get_paiements_passport_dgrad('mobile');
                        
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        
                        $this->data['display'] = $obj;
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                        
                }
                elseif($obj == "paiements_passports")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements_agence'] = $this->reports_model->get_paiements_passport_dgrad();
                        $this->data['encaissements_online'] = $this->reports_model->get_paiements_passport_dgrad('mobile');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        
                        $this->data['display'] = $obj;
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_paiements_passports', $this->data);
                }
                elseif($obj == "filterresult_passports")
                {
						
                        $this->data['modes'] = $this->logiref_model->modes;
                        
                        $this->data['encaissements'] = $this->reports_model->get_paiements_filter_passport_dgrad($id);
                        
						$_SESSION['encaissements'] = $this->data['encaissements'];
                        $data = array();
                        #var_dump($this->data['encaissements']);die;
                        $this->data['display'] = $obj;
                        
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        #var_dump($this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_filter_passport', $this->data));die;
                        #$this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_filter_passport', $this->data);

                }
				
				elseif($obj == "passports")
                {
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "passport_agence")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $this->reports_model->get_paiements_passport_dgrad();
                        $this->data['status'] = $this->reports_model->status;
                        $this->data['colors'] = $this->reports_model->status_color;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        
                        $this->data['display'] = "passports";
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_passport_agence', $this->data);
                }
                elseif($obj == "filter_passport_agence")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $this->reports_model->get_paiements_passport_dgrad();
                        $this->data['status'] = $this->reports_model->status;
                        $this->data['colors'] = $this->reports_model->status_color;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['display'] = "passports";
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_filter_passport_agence', $this->data);
                }
                elseif($obj == "passport_online")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $this->reports_model->get_paiements_passport_dgrad('mobile');
                        $this->data['status'] = $this->reports_model->status;
                        $this->data['colors'] = $this->reports_model->status_color;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['types'] = "online";
                        $this->data['display'] = "passports";
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_passport_online', $this->data);
                }
                elseif($obj == "filter_passport_online")
                {
                        $this->data['modes'] = $this->logiref_model->modes;
                        $this->data['users'] = $this->main_model->get_dropdown('users');
                        $this->data['encaissements'] = $this->reports_model->get_paiements_passport_dgrad('mobile');
                        $this->data['status'] = $this->reports_model->status;
                        $this->data['colors'] = $this->reports_model->status_color;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['display'] = "passports";
                        $this->data['types'] = "online";
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_filter_passport_online', $this->data);
                }
				elseif($obj=="online-taxes")
                {
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integration_model->get_reports_online_taxes_paiements();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
//                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/online_taxes', $this->data);
                }
                elseif($obj=="online_taxes")
                {
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integration_model->get_reports_online_taxes_paiements();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/online_taxes', $this->data);
                }
                elseif($obj=="filter_online_taxes")
                {
                        $data=$_POST;
                        
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integration_model->get_reports_online_taxes_paiements($data);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/filterresult_online_taxes', $this->data);
                }
                elseif($obj == "dropdowns")
                {
                        $recettes = $this->logiref_model->get_dropdown('recettes',$id);
                        
                        echo form_dropdown('Typerecette_17', $recettes[$id], "", 'class="form-control"   id="recette" ');
                }
                elseif($obj == "commissions") 
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['regles'] = $this->fees_model->get_regles("rgle");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/commissions', $this->data);
                }
                elseif($obj == "commissions_filter")
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $commissions = $this->data['commissions'] = $this->reports_model->get_commission_filter($_POST);
                        $_SESSION['commissions'] = $this->data['commissions'];
                        $data = array();
                        $this->data['regles'] = $this->fees_model->get_regles("rgle");
                        
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                    
                }
                elseif($obj == "rapport")
                {
                        if($_SESSION['Logiref_role'] == 3):
                            
                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_validateur_rapport', $this->data);
                        
                        else:
                            
                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                        
                        endif;
                }
                elseif($obj == "report_agence")
                {
                        $this->data['agence'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['agences'] = $this->branches_model->get_branches();
                        
                        $_SESSION['agences'] = $this->data['agences'];
                        
                        $data = array();
                        
                        foreach ($this->data['agences'] as $row)
                        {
                                $data[$row->Id_0]= $this->encaissement_model->get_paiements_stats("guichet", $row->Id_0);
                        }
                        $this->data['data'] = $data;
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_comptes")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['agences'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accounts_model->get_agence_accounts();
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
				elseif($obj == "comptes")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['agences'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";

                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                                $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                                $this->data['comptes'] = $this->accounts_model->get_comptes("cptes");
                                
                                $this->data['lastestComptes'] = $this->accounts_model->get_latest_validated_accounts();
                        }
                        else
                        {
                                $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                                $this->data['comptes'] = $this->accounts_model->get_comptes();
                        }
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "filter_comptes")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['comptes'] = $_SESSION['ci_comptes'] = $this->accounts_model->get_filtered_accounts($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_regles")
                {
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->fees_model->get_agence_regles();
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_commissions")
                {
                        ini_set('max_input_vars','3000' );
                        $this->data['paiement'] = $this->encaissement_model->get_paiements();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_penalites")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissement_model->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integration_model->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "agence_filter")
                {
                        $this->data['agence'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['agences'] = $this->branches_model->get_branches();
                        $_SESSION['agences'] = $this->data['agences'];
                        $data = array();
                        
                        if(isset($_POST['agence']) && $_POST['agence'] !="")
                        {
                                $this->data['agences'] = $this->branches_model->get_branches($_POST['agence']);
                                $_SESSION['agences'] = $this->data['agences'];
                                $return= $this->encaissement_model->get_paiements_stats("guichet_filter", $_POST['agence']);
                                if(empty($return))
                                {
                                        $data = $return;
                                        $_SESSION['return_id'] = $_POST['agence'];
                                        $this->data['agences'] = [];
                                }
                                else
                                {
                                        $return['id_agence'] = $_POST['agence'];
                                
                                        $_SESSION['return'] = $return;
                                        
                                        $data[$_POST['agence']]= $return;
                                }
                        }
                        else 
                        {
                                foreach ($this->data['agences'] as $row)
                                {   
                                        $return = $this->encaissement_model->get_paiements_stats("guichet_filter", $row->Id_0);
                                        
                                        if(empty($return))
                                        {
                                                $data = $return;
                                        }
                                        else
                                        {
                                                $data[$row->Id_0]= $return;
                                        }
                                }
                        }
                        $this->data['data'] = $data;
                        if(empty($data))
                        {
                                $this->data['agences'] = array();
                        }
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                        
                }
                elseif($obj == "regles_filter")
                {
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->fees_model->get_agence_regles_filtered($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "report_clients")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissement_model->get_paiements("virement");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			            $this->data['users'] = $users= $this->main_model->get_dropdown('users_array');
                        $this->data['operators'] = $this->users_model->get_dropdown('operators', $users);
                        $this->data['bulletins'] = $this->integration_model->get_reports_bls();
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "client_filter")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissement_model->get_filterd_paiements("virement", $_POST);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "report_contribuable")
                {
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        #$this->data['encaissements'] = $this->encaissement_model->get_paiements();
                        $this->data['encaissements'] = $this->reports_model->get_report_paiements();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['designation'] = $this->reports_model->get_dropdown('designation');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
               
                elseif($obj == "filter_contribuable")
                {
                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $encaissements= $this->reports_model->get_filter_contribuable_paiements();
                        $_SESSION['encaissements'] = $encaissements;
                        $guichet = $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_synthese") 
                {
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->integration_model->get_instructions_dgis();
                        $this->data['instructions'] = $this->integration_model->get_instructions_dgrad();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_taxe")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['propres'] = $this->reports_model->get_paiements_taxe_propres();
                        #var_dump($this->data['propre']);die;
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                 elseif($obj == "filter_report_taxe")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['propres'] = $this->reports_model->get_paiements_filtertaxe_propres($_POST);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_filter_report_taxe', $this->data);
                }
                elseif($obj == "report_users")
                {
                        $this->data['statut'] = $this->users_model->status;
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->users_model->state_Color;
                        $this->data['groups'] = $this->logiref_model->get_groups();
                        $this->data['members'] = $this->data("get_users");
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['roles'] = $this->users_model->role;
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "penalities")
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissement_model->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integration_model->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
               elseif($obj == "user_filter")
                {
                        $this->data['statut'] = $this->users_model->status;
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->users_model->state_Color;
                        $this->data['groups'] = $this->logiref_model->get_groups();
                        
                        if(isset($_POST['agence']) && $_POST['agence'] !="")
                        {
                                $this->data['members'] = $this->data("get_users", $_POST['agence']);
                        }
                        else
                        {
                                $this->data['members'] = $this->data("get_users");
                        }
                        
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        
                        $this->data['roles'] = $this->users_model->role;
                        
                      
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "account_filter")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['comptes'] = $this->accounts_model->get_filtered_accounts($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "report_bl")
                {
                        $this->data['bulletins'] = $this->integration_model->get_bulletins();
                        $this->data['agences'] = $this->branches_model->get_dropdown('guichets');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "bl_filter")
                {
                        $this->data['bulletins'] = $this->integration_model->get_bulletins($_POST);
                        $this->data['agences'] = $this->branches_model->get_dropdown('guichets');
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "paiements_gu")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integration_model->get_reports_gu_paiements();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "filter_paiements_gu")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                        $this->data['offices'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissement_model->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integration_model->get_filter_gu_paiements($_POST);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
						$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_paiements_gu', $this->data);
                }
				elseif($obj == "report_comptes_cso")
                {

                        $comptes = $this->accounts_model->get_comptes_array(NULL);
                        $compte_cpt = implode(' ', isset($comptes['Ebcdc']['CSO']) ? $comptes['Ebcdc']['CSO']:[]) ;
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['instructions'] = $this->integration_model->get_instructions_dgda_cso($compte_cpt);
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_prepayments")
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['instructions'] = $this->integration_model->get_instructions_prepayments();

                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "comptes_mad")
                {
                        $regies = $id;
                        
                        $comptes = $this->accounts_model->get_comptes_array(NULL);
                        $compte_cpt = implode(' ', isset($comptes['Ebcdc']['MAD']) ? $comptes['Ebcdc']['MAD']:[]) ; 
                        $compte_mad = str_replace('-', '', $compte_cpt);
                        
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['regie'] = $regies;
                        
                        if ($regies == 'DGI')
                        {
                                $this->data['instructions'] = $this->integration_model->get_instructions_dgi_compte_mad($compte_mad);
                        }
                        elseif ($regies == 'DGRAD')
                        {
                                $this->data['instructions'] = $this->integration_model->get_instructions_dgrad_compte_mad($compte_mad);
                        }
                        elseif ($regies == 'DGDA')
                        {
                                $this->data['instructions'] = $this->integration_model->get_instructions_dgda_compte_mad($compte_mad);
                        }
                        
                        $libelles = [];
                        foreach ($this->data['instructions'] as $line)
                        {
                                $libelles[$line->Paiementid_4] = substr($line->Libelle_12, 10);
                        }
                       
                        $this->data['designations'] = $libelles;
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "report_unequalize") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_paiements_to_regulates_ci();
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate_ci();
                        $this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls_to_regulate_ci();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "filter_prepayments")
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['instructions'] = $_SESSION['ci_prepayments'] = $this->integration_model->get_instructions_prepayments($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "filter_comptes_cso")
                {
                        $comptes = $this->accounts_model->get_comptes_array(NULL);
                        $compte_cpt = implode(' ', isset($comptes['Ebcdc']['CSO']) ? $comptes['Ebcdc']['CSO']:[]) ;
                        $compte_mad = substr($compte_cpt, 6);
                        
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] =  $this->branches_model->get_dropdown("guichets");
                        $this->data['instructions'] = $_SESSION['CSO'] = $this->integration_model->get_instructions_dgda_cso($compte_cpt, $_POST);
                        //var_dump( $this->data['instructions']);die;
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "filter_comptes_mad")
                {
                        $regie = $id;
                        
                        $comptes = $this->accounts_model->get_comptes_array(NULL);
                        $compte_cpt = implode(' ', isset($comptes['Ebcdc']['MAD']) ? $comptes['Ebcdc']['MAD']:[]) ; 
                        $compte_mad = str_replace('-', '', $compte_cpt);
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] =  $this->branches_model->get_dropdown("guichets");
                        
                        if ($regie == 'DGI')
                        {
                                $this->data['instructions'] = $_SESSION['instruction_dgis'] = $this->integration_model->get_instructions_dgi_compte_mad($compte_mad, $_POST);
                        }
                        elseif ($regie == 'DGRAD')
                        {
                                $this->data['instructions'] = $_SESSION['instruction_dgrad'] = $this->integration_model->get_instructions_dgrad_compte_mad($compte_mad, $_POST);
                        }
                        elseif ($regie == 'DGDA')
                        {
                                $this->data['instructions'] =  $_SESSION['instruction_dgda'] = $this->integration_model->get_instructions_dgda_compte_mad($compte_mad, $_POST);
                        }
                        
                        foreach ($this->data['instructions'] as $line)
                        {
                                $libelles[$line->Paiementid_4] = substr($line->Libelle_12, 10);
                        }
                       
                        $this->data['designations'] = $libelles;
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_filter_comptes_mad', $this->data);
                }
                elseif($obj == "filter_unequalize")
                {
                        $this->data['encaissements'] = $this->reports_model->get_paiements_to_regulates_ci($_POST);
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate_ci($_POST);
                        $this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls_to_regulate_ci($_POST);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['regies'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->folder . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        if($data !="" && $data != NULL)
                        {
                                $members = $this->users_model->get_members($data);
                        }
                        else
                        {
                                $members = $this->users_model->get_members();
                        }
                        
                        $members = $this->users_model->get_members();
                        
                        return $members;
                }
               
                
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */