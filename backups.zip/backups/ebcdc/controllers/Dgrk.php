<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dgrk extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'dgrk';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/dgrk_model');
                $this->load->model('main/main_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'notes';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissement_model->documents;
                $this->data['devises'] = $this->encaissement_model->devises;
                $this->data['modes'] = $this->encaissement_model->modes;
                $this->data['moyens'] = $this->encaissement_model->moyens;
                $this->data['infos'] = $this->encaissement_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                $f = $this->data_model->dgrk_payment_affectation();
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 1;
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_step_1', $this->data);
                }
                elseif($obj == "verification")
                {
                        $data = $_POST;
                        $response = $this->curl_model->call_dgrk_notes($data);
                        
                        if($response == "E500" || $response == "E400" || $response=="E404"):
                            
                                echo $response;
                        
                        else: 
                                $services = $this->curl_model->call_dgrk_dropdown("centre");
                                
                                $recettes = $this->logiref_model->get_dropdown('recettes',"DGRK");
                        
                                $this->rates_model->get_exchange_rates();
                                $this->data['services'] = json_decode($services);
                                $this->data['recettes'] = $recettes['DGRK'];
                                
                                
                                $this->data['encaissement'] =  $this->data_model->dgrk_migrate_note($response);
                                
                                $note = $this->dgrk_model->get_paiement_dgrk($response);
                                $data = json_decode($note->Noterefrence_16);
                                $this->data['note'] = $data;
                                $this->data['noteid'] = $response;
                                $this->data['reference'] = $note->Declarationid_19;
                                $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_step_2', $this->data);
                                
                        endif;
                }
                elseif($obj == "create")
                {
                        $this->rates_model->get_exchange_rates();
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['client'] = $this->logiref_model->get_clients_by_nif($_POST['Nif_17']);
                        $services = $this->curl_model->call_dgrk_dropdown("centre");
                        $center =  $this->curl_model->call_dgrk_dropdown("impot");
                        
                        
                        
                        $this->data['services'] = json_decode($services);
                        $this->data['recettes'] = json_decode($center);
                        
                        $this->data['note_reference'] = $this->encaissement_model->get_paiement_by_reference($_POST['id_declaration']);
                        
                        
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "edit")
                {
                        $this->rates_model->get_exchange_rates();
                        
                        $services = $this->curl_model->call_dgrk_dropdown("centre");
                        $this->data['services'] = json_decode($services);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRK");
                        $this->data['recettes'] = $recettes['DGRK'];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "edit_note")
                {
                        $this->rates_model->get_exchange_rates();
                        $services = $this->curl_model->call_dgrk_dropdown("centre");
                        $center =  $this->curl_model->call_dgrk_dropdown("impot");
                        $this->data['services'] = json_decode($services);
                        $this->data['recettes'] = json_decode($center);
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['encaissement'] =  $this->encaissement_model->get_paiement_propres_dgrk($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->rates_model->get_exchange_rates();
                        $services = $this->curl_model->call_dgrk_dropdown("centre");
                        $this->data['services'] = json_decode($services);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRK");
                        $this->data['recettes'] = $recettes['DGRK'];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "new")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['paiements'] = $this->dgrk_model->get_new_payments();
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_new_payments', $this->data);
                }
                elseif($obj == "pending")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['paiements'] = $this->dgrk_model->get_validated_payments();
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_validated_payments', $this->data);
                }
                elseif($obj == "confirmed")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['paiements'] = $this->dgrk_model->get_confirmed_payments();
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_confirmed_payments', $this->data);
                }
                elseif($obj == "affectation")
                {
                        $this->data['paiements'] = $this->dgrk_model->get_confirmed_payments();
                        $this->data['payment_affectation'] = $this->data_model->dgrk_payment_affectation();
                        $this->data['affectation'] = $this->integration_model->get_dgrk_affectations();
                        
                        $this->data['status'] = $this->integration_model->status;
                        $this->data['statusColor'] = $this->integration_model->di_statuscolor;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        $this->data['comptes'] = $comptes;
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_affectation', $this->data);
                }
                elseif($obj == "affectation_confirmed")
                {
                        $this->data['affectations'] = $this->integration_model->get_dgrk_affectations_confirmed();
                        $this->data['status'] = $this->integration_model->status;
                        $this->data['statusColor'] = $this->integration_model->di_statuscolor;
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_confirmed_affectation', $this->data);
                }
                elseif($obj == "details")
                {
                        $type = $id;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $this->data['payment_affectation'] = $data = $this->data_model->dgrk_payment_affectation();
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        $this->data['comptes'] = $comptes;
                        $this->data['type'] = $id;
                        if($type=='RFS')$this->data['lines'] = $this->comptabilisation_model->get_instructions_dgrk_affectation_rfs($data, $comptes);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_details', $this->data);
                }
                elseif($obj == "confirm_affectation")
                {
                        if($id == "")
                        {
                                $reference = $this->save('affectation');
                                $agence_src= $_SESSION['Logiref_guichet'];
                                $this->data['payment_affectation'] = $data = $this->data_model->dgrk_payment_affectation();
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                                $this->data['reference'] = $reference;
                                $this->data['lines'] = $this->comptabilisation_model->get_instructions_dgrk_repartition($reference);
                        }
                        else
                        {
                                $this->data['affectation'] = $affectation = $this->integration_model->get_affectation_info($id);
                                $reference = $affectation->Reference_10;
                                
                                $paiments = json_decode($affectation->Paiementids_9);
                                $this->data['payment_affectation'] = $data = $this->data_model->dgrk_payment_affectation($paiments);
                                $this->data['reference'] = $reference;
                                $this->data['lines'] = $this->comptabilisation_model->get_instructions_dgrk_repartition($reference);
                        }
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_details', $this->data);
                }
                elseif($obj == "confirm_payment")
                {
                        $note = $this->dgrk_model->get_paiement_dgrk($id);
                        
                        $encaissement = $this->encaissement_model->get_paiement_propres_dgrk($id);
                        
                        $data = array();
                        
                        $data['id_declaration'] = $note->Declarationid_19;
                        $data['reference_transaction'] = $note->Transactionid_18;
                        $data['montant_transaction'] = $note->Montant_7;
                        $data['currency'] = $note->Devise_8;
                        $data['date_transaction'] = gmdate('d-m-Y');
                        $data['numero_compte'] = $encaissement->Compte_33;
                        
                        $response = $this->curl_model->call_dgrk_confirm_notes($data);
                        
                        
                        if($response == "E500" || $response == "E400" || $response=="E404"):
                            
                                echo $response;
                        
                        else: 
                                echo "E200";
                        endif;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();

                                if(isset($_POST['Ndeclaration']))
                                {
                                        $declaration = $_POST['Ndeclaration'];
                                        unset($_POST['Ndeclaration']);
                                }

                                $data = $_POST;
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata('account_id');
                                if($_SESSION['Logiref_role'] ==4) $data['Makerid_9'] = $this->session->userdata('user_id');
                                $benificiaire = $data['Beneficaire_15'] = 'DGRK';
                                $infos = $data['Infos'];
                                
                                // Test if the total_amount has been calculated
                                if($infos['totalMontant'] == "")
                                {
                                        $infos['totalMontant'] = $this->encaissement_model->get_montant_total($data);
                                }
                                
                                #Invoque the API account.info to retrieve the client informations
                                
                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);
                                
                                $type_recette = $this->logiref_model->get_dropdown("type_recette");
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                
                                # Affectation des fonds 
                                # PRM : Prime de mobilisation
                                # DGF : DGRK fonctionnement
                                # TUB : Taxe urbaine
                                # RSA : Retro services d'assiette
                                
                                if($type_recette[$data['Typerecette_17']] == 'RFS')
                                {
                                        $infos['RFS']['PRM'] = $data['Montant_11'] * 0.28;
                                        $infos['RFS']['DGF'] = $data['Montant_11'] * 0.07;
                                        $infos['RFS']['TUB'] = $data['Montant_11'] * 0.65;
                                }
                                elseif($type_recette[$data['Typerecette_17']] == 'RNF')
                                {
                                        $infos['RNF']['PRM'] = $data['Montant_11'] * 0.3;
                                        $infos['RNF']['DGF'] = $data['Montant_11'] * 0.07;
                                        $infos['RNF']['RSA'] = $data['Montant_11'] * 0.05;
                                        $infos['RNF']['TUB'] = $data['Montant_11'] * 0.58;
                                }
                                elseif($type_recette[$data['Typerecette_17']] == 'TCS')
                                {
                                        $infos['TCS']['PRM'] = $data['Montant_11'] * 0.1;
                                        $infos['TCS']['RSA'] = $data['Montant_11'] * 0.05;
                                        $infos['TCS']['TUB'] = $data['Montant_11'] * 0.85;
                                }
                                
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }
                                //Formatting amount
                                
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                    
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                                # SAVE PAYMENT
                                # Check if it's a new payment
                                if($data['Id_0']=="" || $data['Id_0']==0)
                                {
                                        unset($data['Id_0']);
                                        $ref = $this->encaissement_model->get_id_by_reference($data['Logirefid_4']);
                                        $data['Id_0'] = $ref;
                                }

                                # Encaissement existant
                                if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                        {
                                                #Invocation of the api transfer
                                                $response = $this->curl_model->call_bank_virement($data);
                                                
                                                $return = json_decode($response, true);
												 
                                                if(isset($return['response']) && $return['response'] =='200')
                                                {
                                                        $result = json_decode($data['Notereference_30'], true);
                                                        
                                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                        
                                                        $logirefid = $data['Logirefid_4'];
                                                        
                                                        // Pour eviter la modification du paiment par le validateur 
                                                        $dgrk_data = array();
                                                        $paiementid = $data['Edgrk_50'];
                                                                
                                                        $data = array();
                                                        
                                                        $data['Notereference_30'] = json_encode($result);
                                                        $data['Id_0'] = $id;
                                                        $data['Logirefid_4'] = $logirefid;
                                                        $data['Status_2'] = 1;
                                                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                                                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                                        
                                                        $dgrk_data['Status_2'] = '2';
                                                        $dgrk_data['Transactionid_18'] = $result['Num_evenement'];
                                                        $this->dgrk_model->update_paiement_dgrk($dgrk_data, $paiementid);
                                                }
                                                elseif(isset($return['response']) && $return['response'] != "")
                                                {
                                                        echo $return['response'];
                                                        die;
                                                }
                                                else
                                                {
                                                        echo 'E411';
                                                        die;
                                                }
                                                
                                        }
                                        else 
                                        {
                                                $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                                $this->comptabilisation_model->delete_instructions_dgrK($data['Logirefid_4']);
                                        }
                                        # Save changes
                                        $this->encaissement_model->update_payment_propres($data, $data['Logirefid_4']);
                                        
                                }
                                # Nouvel encaissement
                                else
                                {
                                        #Enregistrement
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $instructions = array();
                                        $logiref_id = $data['Logirefid_4'];
                                        if($data['Id_0'] == 0) $data['Id_0'] = NULL;

                                        
                                        $pid = $this->encaissement_model->save_payment_propres($data, $data['Id_0']);
                                        
                                        $data['Id_0'] = $pid;
                                } 
                                
                                if($_SESSION['Logiref_role'] ==4)
                                {
                                        #Comptabilisation
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $agence_dst=NULL;
                                        $list = NULL;

                                        $case = $this->comptabilisation_model->get_use_case($data);
                                        $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
										
                                        switch ($case)
                                        {
                                                case "case_1": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGRK");
                                                        break;
                                                case "case_2": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRK", NULL, NULL, NULL, $type_recette[$data['Typerecette_17']]);
                                                        break;
                                                case "case_3": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGRK");
                                                        break;
                                                case "case_4": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGRK");
                                                        break;
                                                case "case_5": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_5($data, $comptes,"DGRK");
                                                        break;
                                                default: 
                                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGI");
                                                        break;
                                        }

                                        if(!empty($instructions))
                                        {
                                                $end_execution = $this->comptabilisation_model->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                        }
                                }
                                
                                
                                #Return
                                echo $data['Id_0'];
                                die;
                        }
                }
                elseif($obj == "affectation")
                {
                        $type = $id;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $data_affectation = $this->data_model->dgrk_payment_affectation();
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        $paiements = $this->encaissement_model->get_paiements_propres_dgrk();
                        
                        $instruction = $this->comptabilisation_model->get_instructions_dgrk_affectation($data_affectation, $comptes);

                        if(!empty($instruction))
                        {
                                $reference = date('H').date('i').date('s').date('j').date('m').date('y');
                                $id = $this->comptabilisation_model->save_instructions_affectation_dgrk($reference, $instruction);

                                if($id > 0)
                                {
                                        $data = array();
                                        
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']= 1;
                                        $data['Account_3']= $this->session->userdata('account_id');;
                                        $data['Creator_4']= $this->session->userdata('user_id');
                                        $data['Montant_7']= $data_affectation['Total_amount'];
                                        $data['Nombrepaiement_8']= $data_affectation['Total_payment'];
                                        $data['Paiementids_9']= json_encode($paiements);
                                        $data['Reference_10']= $reference;
                                        $data['Datevaleur_11']= gmdate('Y-m-d');
                                        
                                        $this->integration_model->save_affectation_dgrk($data, NULL);
                                        
                                        return $reference;
                                }
                        }
                        
                }
                elseif($obj == "validate")
                {
                        $reference = $id;
                        
                        $data = $this->data_model->dgrk_payment_affectation();
                        
                        $data['reference'] = $reference;
                        $data['Beneficaire_15'] = 'DGRK';
                        $data['Account_3'] = $this->session->userdata('account_id');
                        
                        $response = $this->curl_model->call_bank_virement_affectation($data);
                        
                        $return = json_decode($response, true);
                        
                        if(isset($return['response']) && $return['response'] == "200")
                        {
                                $data = array();
                                
                                $data['Status_2'] = '2';
                                $data['Cbscode_12'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "0";
                                
                                $this->integration_model->update_dgrk_affectation($data, $reference);
                                
                                echo $return['response'];
                        }
                        elseif(isset($return['response']) && $return['response'] !="")
                        {
                                echo  $return['response'];
                        }
                        else
                        {
                                echo 'E411';
                                die;
                        }
                }
                elseif($obj == "delete")
                {
                        $RecetteTYPES = $this->logiref_model->get_dropdown("type_recette");
                        $code_recette = $this->input->get('recette');
                        
                        $rType = $RecetteTYPES[$code_recette];
                        $pid = 0;
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_propre($id);
                        }
                        if($pid > 0)
                        {
                                $this->comptabilisation_model->delete_instructions_dgrad($id);
                        }
                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "OBj")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */


