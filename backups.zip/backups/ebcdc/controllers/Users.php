<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends MY_Controller {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('privileges','settings','accountsydonia');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'users';
        private $method = "aes-256-cbc";
        private $pass = '0123456789*';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
              
                $this->load->model('MY_Main');
                $this->load->model('main/main_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/branches_model');
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'users';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "privileges")
                {
                     
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['statut'] = $this->users_model->status;
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->users_model->state_Color;
                        $this->data['groups'] = $this->logiref_model->get_groups();
                        $this->data['isys'] = $this->integration_model->get_isys_account_info();
                        $this->data['sydonia'] = $this->integration_model->get_sydonia_account_info();
                        $this->data['members'] = $this->data("get_users");
                        $users['0'] = 'Member';
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                                $this->data['roles'] = $this->users_model->role;
                        }
                        else
                        {
                                $this->data['fonctions'] = $this->users_model->fonction;

                        }
                        $this->load->model('MY_Main');
			$this->load->model('main/main_model');
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/users', $this->data);
                }
                elseif($obj == "user") 
                {
                       
                        $this->data['statut'] = $this->users_model->status;
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['provinces'] = $this->logiref_model->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['from'] = $arg;
                        $members = $this->users_model->get_dropdown("users");
                        
			$this->load->model('MY_Main');
			$this->load->model('main/main_model');
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];
                        foreach($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['user'] = $this->users_model->get_user_info($id);
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['roles'] = $this->users_model->role;
                        }
                        else
                        {
                            $this->data['fonctions'] = $this->users_model->fonction;
                            $this->data['fonctions'][1] ="";

                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_user', $this->data);  
                }
                elseif($obj == "accountsydonia")
                {   
                        $user = $this->session->userdata('user_id');
                        $this->data['identifiants'] = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_sydonia', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "user")
                {
                        if($_POST['userid']=='0' || $_POST['role']=='' || $_POST['ville']==''):
                                echo '<div class="alert alert-danger text-white">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        else:
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                    
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']= '2';
                                        $data['Statusvalidate_19']= '1';
                                        $data['Account_3']=$this->session->userdata('account_id');
                                        $data['Maker_14']= $this->session->userdata('user_id');
                                
                                endif;
                                
                                if($_SESSION['Logiref_role']==1)
                                {
                                        
                                        $data['Role_4']=$_POST['role'];
                                        $data['Province_5']=$_POST['province'];
                                        $data['Ville_6']= $_POST['ville'];
                                        $data['Agence_7']= $_POST['agence'];
                                        if($_SESSION['Logiref_groupe']== 'banks')
                                        {
                                            $data['Guichet_8']=$_POST['guichet'];
                                            $data['Regies_11']='';
                                        }
                                        else
                                        {
                                            $data['Service_10']=$_POST['service'];
                                            $data['Regies_11']=$_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9']=$_SESSION['Logiref_groupe'];
                                        $data['Code_12']=$_POST['code'];
                                        $data['Userid_13']=$_POST['userid'];
                                        
                                        


                                        if($_POST['role'] == '1')
                                        {
                                                $this->load->model('MY_Main');
                                                $this->load->model('main/main_model');
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata('user_id');
                                                $rdata['Type_10'] = '200';
                                                $userid = $_POST['userid'];
                                                $relationid = $this->main_model->update_relation($rdata, $userid);
                                        }

                                        if($id != "" && $id !='0')
                                        {
                                            if($_POST['role'] != '1'):
                                                    $this->load->model('MY_Main');
                                                    $this->load->model('main/main_model');
                                                    
                                                    $data['Statusvalidate_19'] = $_POST['status'];
                                                    $data['Maker_14']= $this->session->userdata('user_id');
                                                    
                                                    $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                    $rdata['Changer_6'] = $this->session->userdata('user_id');
                                                    $rdata['Type_10'] = '300';
                                                    $userid = $_POST['userid'];
                                                    $relationid = $this->main_model->update_relation($rdata, $userid);
                                            endif;
                                        }
                                       
                                        $data['Checker_15']=0;
                                        $data['Validation_16']='0000-00-00';
                                       
                                    
                                }
                                else
                                {
                                        $data['Checker_15']= $this->session->userdata('user_id');
                                        $data['Validation_16']= gmdate('Y-m-d H:i:s');
                                        if($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] !='0')
                                        {
                                                $data['Status_2'] = $_POST['statusvalidate'];
                                        }
                                }
                                
                                #Database
                                $cid = $this->users_model->save_users($data, $id);
			endif;
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif; 
                }
                elseif($obj == "account_sydonia")
                {
                        $encryption = array('codebank'=>$_POST['code'], 'encryption'=>$_POST['password']);
                        $user = $this->session->userdata('user_id');
                        $data['Login_17'] = $_POST['login'];
                        $data['Password_18'] = json_encode($encryption);
                        $cid = $this->users_model->update_users($data, $user);
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif; 
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        $members = $this->users_model->get_members();
                        $type = $this->session->userdata('user_type');
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata('user_id');
                                $cid = $this->users_model->save_users($data, NULL);
                                if($cid) $members = $this->users_model->get_members();
                        }
                        return $members;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */