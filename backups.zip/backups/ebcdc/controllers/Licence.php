<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Licence extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('declarations');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'ebcdc';
        public $folder = 'licences';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/licence_model');
                $this->load->model($this->module.'/data_model');
                
                $this->folder = 'licences';
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'licence';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "start")
                {
                        $this->data['step'] = 0;
                        
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_declaration', $this->data);
                }
                elseif($obj == "extraction") 
                {
                        $datedebut = explode("-", $_POST['dateDebut']);
                        $datefin  = explode("-", $_POST['dateFin']);
                        $_POST['dateDebut'] = $datedebut[2].'/'.$datedebut[1].'/'.$datedebut[0];
                        $_POST['dateFin'] = $datefin[2].'/'.$datefin[1].'/'.$datefin[0];
                        $data = $_POST;
                        $response = $this->curl_model->call_bank_licence_bcc($data);
                        $response = trim($response);
                        
                        if($response == 'E404' || $response == 'E13' || $response == 'E14' || $response == 'E15' || $response == 'E16' || $response == 'E20')
                        {
                                echo $response; die;
                        }
                        else
                        {    
                                $response = json_decode($response,true);
                                
                                $this->data['declarations'] = $this->licence_model->get_declarations($response);
                                
                                if(!empty($this->data['declarations']))
                                {
                                        $this->data['step'] = 1;
                                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_declarations', $this->data);
                                }
                                else
                                {
                                        echo 'E404';
                                }
                        }
                }
                elseif($obj == "declaration_detail") 
                {
                        $articles = array();
                        $this->data['declaration'] = $this->integration_model->get_declaration_detail($id);
                        $articles = json_decode($this->data['declaration']->Articles_15);
                        $this->data['articles'] = $articles;
                        
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/declaration', $this->data);
                }
                elseif($obj == "declarationsAck") 
                {
                        $messagekeys = $_POST['messageskeys']; 
                        $message = $_POST['message'];
                        $message = ($message == "OK")? 'OK' : 'KO';

                        $keys = array();
                        $ids = array();
                        
                        foreach($messagekeys as $key => $value)
                        {
                            $keys[] = $value;
                            $ids[] = $key;
                        }

                        $ids = implode(',', $ids);

                        // 
                        unset($_POST['messageskeys']);
                        unset($_POST['message']);

                        $_POST['messageKey'] = $keys;
                        $_POST['codeTr'] = $message;

                        set_time_limit(250);
                        $url = base_url('api/endpoints/sydonia/declarationsAck.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($_POST);
                        $SydoniaResponse = $this->curl->execute();
                        $SydoniaResponse = trim($SydoniaResponse);
                        
                        if($SydoniaResponse == "E404" || $SydoniaResponse == "E401" || $SydoniaResponse == "E37" || $SydoniaResponse == "E38" || $SydoniaResponse == "E39" || $SydoniaResponse == "E43")
                        {
                                echo $SydoniaResponse; die;
                        }
                        elseif($SydoniaResponse == "OK")
                        {    
                                $status = ($message == 'OK')? 3: 4;
                                
                                $update = $this->save("updatedeclaration",$ids, $status);
                                
                                if($update)
                                {
                                        echo '42';
                                }
                                else
                                {
                                        echo '401';
                                }
                        }
                }
                elseif($obj == "apurement")
                {
                        $_POST['num_licence'] = "";
                        set_time_limit(250);
                        $url = base_url('api/endpoints/sydonia/apurement.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($_POST);
                        $SydoniaResponse = $this->curl->execute();
                        
                        $SydoniaResponse = trim($SydoniaResponse);
                        
                        if($SydoniaResponse == 'E404' || $SydoniaResponse == 'E13' || $SydoniaResponse == 'E14' || $SydoniaResponse == 'E15' || $SydoniaResponse == 'E16' || $SydoniaResponse == 'E22')
                        {
                                echo $SydoniaResponse; die;
                        }
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
        }
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */