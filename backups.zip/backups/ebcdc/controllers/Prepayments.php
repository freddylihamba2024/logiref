<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Prepayments extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('prepaids','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'prepayments';
        public $exonered = array();
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/prepayments_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/fees_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/users_model');
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'prepaids';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "extractList")
                {
                        set_time_limit(250);
                        
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_prepayments($credentials);
                        
                        //$response = '1,2,3,4,5,6,7,8,9,10,11,12';
                        if($response ==  "E514" || $response == "E404" || $response == "E36" || $response == "E37" || $response == "E38" || $response == "E39" || $response == "E43" || $response == "E501" || $response == "E000" || $response == "E502"):
                        
                                echo $response; die;
								
                        elseif($response == "" || $response == NULL) :
                                echo "E411"; die;
                        else :
                                $this->data['lot'] = $response;
                                $this->data['prepayments'] = $this->prepayments_model->get_prepayments_by_lot($response);
                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['step'] = 0;
                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_prepayments', $this->data);
                                
                        endif;
                }
                elseif($obj == "traitement")
                {           
                        $agence = $_SESSION['Logiref_guichet'];
                        
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        
                        $account_reference = isset($_GET['reference']) ? $_GET['reference'] : "";
                        
                        $this->data['prepayments'] = $prepayments = $this->prepayments_model->get_prepayments_by_reference($account_reference);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        
                        $frais_bcc = 0;
                        $amount = 0;
                        
                        foreach($this->data['prepayments'] as $row)
                        {
                                $encaissement = $this->data_model->sydonia_migrate_prepayment($row->Id_0);
                                
                                $info = $encaissement->Notereference_30;
                                
                                $amount = $encaissement->Montant_11 + $amount; 
                                
                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);
                                
                                $taxes = $info['taxesPaid'];
                                
                                foreach($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $taxe_amount = $taxe->taxeAmount * 0.0005;
                                                
                                                $frais_bcc = $taxe_amount + $frais_bcc;
                                        }
                                }
                        }
                        
                        #Get and set prepaid account
                        $comptes =  $this->accounts_model->get_prepaid_comptes_array("'CPS'", $agence);
                        
                        $compte_client = (isset($comptes[$account_reference]['CPS']['CDF']))?$comptes[$account_reference]['CPS']['CDF'] : '';
                        $this->data['account'] = $compte_client;
                        
                        $this->data['bulletin'] =  isset($prepayments[0]) ? $prepayments[0] : "";
                        
                        $this->data['fees_amount'] =  $frais_bcc;
                        $this->data['total_amount'] =  $amount;
                        
                        $this->data['account_reference'] =  $account_reference;
						
                        $this->data['lot'] =  $this->input->get('lot');
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1', $this->data);
                    
                }
                elseif($obj == "verification")
                {
                        //var_dump($_POST); die;
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        
                        if(isset($_POST['fb']) && $_POST['fb'] !="")
                        {
                                $prepayments = $this->prepayments_model->get_prepayments_by_reference($_POST['account_reference']);
                                $total_commission = 0;
                                $total_amount = 0;
                                foreach ($prepayments as $row)
                                {
                                        $amount = isset($row->Amount_18) ? $row->Amount_18 : 0;
                                        
                                        $devise = "CDF";
                                        $service = isset($row->Office_8) ? $row->Office_8 : "";
                                        $agence = $_SESSION['Logiref_guichet'];
                                        
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        
                                        if($devise !='CDF')
                                        {
                                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                {
                                                        $devise_taux = $_POST['Taux'];
                                                }
                                                else
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);

                                                        $devise_taux = $taux['Dollar_4'];
                                                }
                                        }
                                        else
                                        {
                                                $devise_taux = 1;
                                        }
                                        
                                        $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                                $com['com'] = ($amount * $rules['Valeur'])/100;
                                                $com['devise'] = $devise;
                                        }
                                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }

                                        if(!empty($com) && $com['com']!=0)
                                        {
                                                if($com['devise'] !='CDF')
                                                {
                                                        $this->data['commission'] = $com['com'] * $devise_taux;
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                                else
                                                {
                                                        $this->data['commission'] = $com['com'];
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                        }
                                        
                                        
                                        $total_commission = $com['com'] + $total_commission;
                                        $total_amount = $amount + $total_amount;
                                        
                                }
                                
                                $this->data['total_amount'] = $total_commission + $total_amount;
                                $this->data['commission'] = $total_commission;
                                $this->data['commission_devise'] = $com['devise'] = $devise;
                                
                        }
                        else
                        {
                                $this->data['commission'] = 0;
                                $this->data['commission_devise'] = $devise = "CDF";
                                
                                if(isset($_POST['frais_bcc']) && $_POST['frais_bcc'] != "")
                                {
                                        $prepaid_amount = isset($_POST['prepaid_amount']) ? $_POST['prepaid_amount'] : 0;
                                        $fees_amount = isset($_POST['fees_amount']) ? $_POST['fees_amount'] : 0;
                                        $this->data['total_amount'] = $prepaid_amount + $fees_amount;
                                        
                                        $this->data['frais_bcc'] = $_POST['frais_bcc'];
                                }
                                else
                                {
                                        $this->data['total_amount'] = isset($_POST['prepaid_amount']) ? $_POST['prepaid_amount'] : "";
                                }
                        }
                        
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $mode = $_POST['Mode'];
                        $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";

                        $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                        
                        if(isset($_POST['Nif']) && (isset($_POST['designation']) && $_POST['designation'] ==""))
                        {
                                $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                        }
                        else
                        {
                                $this->data['designation'] = (isset($_POST['designation']) && $_POST['designation'] !='') ? $_POST['designation']: '';
                        }
                        
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);

                        $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];

                        if($mode =='7')
                        {
                                $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                $this->data['disabled'] = "";
                        }
                        else 
                        {
                                $this->data['referenceOP'] = "";
                                $this->data['disabled'] = "disabled";
                        }
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_details', $this->data);
                }
                elseif($obj == "edit")
                {
                        $account_reference = isset($_POST['account_reference']) ? $_POST['account_reference'] : "";
						
						
                        $amount = 0;
                        $amount_frais_bcc = 0;
                        $i = 0;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                        $compte_cpt = isset($comptes['Ebcdc']['CSO']['CDF']) ? $comptes['Ebcdc']['CSO']['CDF'] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        $instructions2 = array();
                        
                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments_by_reference($account_reference);
                        
                        $this->data['object_info'] = $object_info = isset($this->data['prepayments'][0]) ? $this->data['prepayments'][0] : "";
                        $this->data['prepayment_account'] = $_POST['bank_account'];
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        
                        $frais_bcc = 0;
						
                        
                        foreach($this->data['prepayments'] as $row)
                        {
                                $encaissement = $this->data_model->sydonia_migrate_prepayment($row->Id_0);
                                
                                $info = $encaissement->Notereference_30;
                                
                                $amount = $encaissement->Montant_11 + $amount; 
                                
                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);
                                
                                $taxes = $info['taxesPaid'];
                                
                                foreach($taxes as $taxe)
                                {
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda_prepayments($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                        $instructions2[] = $instruction;
                                        
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $amount_frais_bcc = $taxe->taxeAmount * 0.0005;

                                                $frais_bcc = $amount_frais_bcc + $frais_bcc;
                                        }
                                }
                                
                                $i++;
                        }
                        
                        $encaissement->Montant_11 = $amount;
                        
                        $commission = str_replace(' ','',$_POST['Commission']);
                        $com = str_replace(',','.',$commission);

                        $tva = $com * 0.16;

                        $encaissement->Designation_14 = isset($_POST['designation']) ? $_POST['designation'] : "";
                        $encaissement->CGU =  $_POST['Compte_guichet'];
                        $encaissement->Taux_41 =  $_POST['Taux'];
                        $encaissement->Commission_23 =  $_POST['Commission'];
                        $encaissement->Devise_24 =  $_POST['Devise_commission'];
                        $encaissement->Compte_33 = $_POST['bank_account'];
                        $encaissement->Devise_34 = 'CDF';
                        $encaissement->Notereference_30['accountname'] = $_POST['account_name'];
                        $encaissement->Tva = $tva;
                        $encaissement->Comptec = $_POST['bank_accountc'];
                        $encaissement->Devisec = $_POST['Devise_account_c'];
                        
                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        
                        # Total de frais bcc des taxes tresor
                        $data['frais_bcc'] = $frais_bcc;
                        
                        # Account to debit the BCC fees.
                        if(isset($_POST['bank_accountc']))
                        {
                                $compte_debit = $_POST['bank_accountc'];
                        }
                        else
                        {
                                $compte_debit = '000000000000000000000000';
                        }
                        
                        $devise_compte = $_POST['Devise_account_c'];
                                    
                        $i = 0;
                        
                        $bl = $id;
                        $agence = $_SESSION['Logiref_guichet'];
                        $devise = 'CDF';
                        
                        $comptes = array();
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                      
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_prepayment_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        if(isset($_POST['frais_bcc']) && $_POST['frais_bcc']== 1)
                        {
                                $instructions3 = $this->comptabilisation_model->get_instructions_frais_bcc_prepayments($data, $comptes, $compte_debit, $devise_compte);

                                $instructions1 = array_merge($instructions1, $instructions3);
                                
                                $this->data['frais_bcc'] = $frais_bcc;
                        }
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        
                        $this->data['account_reference'] =  $account_reference;
                        
                        $this->data['prepayment_account'] =  $_POST['bank_account'];
                        $this->data['currency'] =  $_POST['Devise_account'];
                        $this->data['fbank'] =  (isset($_POST['fb']) && $_POST['fb'] == 'fb') ? $_POST['fb'] : "";
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        
                        $this->data['Comptec'] = $compte_debit;
                        $this->data['Devisec'] = $devise_compte;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "preview")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_prepaiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_prepayment($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "_prepayments")
                {
                        $response = $id;
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments_by_lot($response);
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['step'] = 0;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_prepayments', $this->data);
                }
                elseif($obj == "allprepayments")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['status'] = $this->prepayments_model->prepayments_status;
                        $this->data['color'] = $this->prepayments_model->prepayments_status_color;
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments();
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_allprepayments', $this->data);
                }
                elseif($obj == "new")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['status'] = $this->prepayments_model->prepayments_status;
                        $this->data['color'] = $this->prepayments_model->prepayments_status_color;
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments("new");
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_allprepayments', $this->data);
                }
                elseif($obj == "nvalidated")
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['status'] = $this->prepayments_model->prepayments_status;
                        $this->data['color'] = $this->prepayments_model->prepayments_status_color;
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments('nvalidated');
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_nvalidated', $this->data);
                }
                elseif($obj == "validated")
                {
                        $this->data['messages'] = $this->prepayments_model->ackmessages;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['status'] = $this->prepayments_model->prepayments_status;
                        $this->data['color'] = $this->prepayments_model->prepayments_status_color;
                        $this->data['prepayments'] = $this->prepayments_model->get_prepayments('validated');
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_validated', $this->data);
                }
                elseif($obj == "prepaymentsAck")
                {
                        $id = $_POST['id'];
                        $messagekeys = $_POST['messageskeys']; 
                        $message = $_POST['message'];
                        $message = ($message == "OK")? 'OK' : 'KO';


                        unset($_POST['messageskeys']);
                        unset($_POST['message']);

                        $_POST['messageKey'] = $messagekeys;
                        $_POST['codeTr'] = $message;

                        // Sydonia credantials
                        
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_send_ack_prepayments($credentials);
                        if($response == "E404" || $response == "E401" || $response == "E37" || $response == "E38" || $response == "E39" || $response == "E43"  || $response == "E42")
                        {
                                echo $response; die;
                        }
                        elseif($response == "OK")
                        {    
                                $status = ($message == 'OK')? 6: 0;
                                $update = $this->save("updateprepayment", $id, $status);
                                if($update > 0)
                                {
                                        echo '41';
                                }
                                else
                                {
                                        echo '401';
                                }
                        }
                    
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        $prepyment_unvalidated = $this->prepayments_model->get_prepayments_unvalidated();

                        #If form could not be validate
                        if(!empty($prepyment_unvalidated))
                        {
                                echo 'E002'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();
                                
                                
                                $data = $_POST;
                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');

                                $infos = $data['Infos'];
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                unset($data['account_reference']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $amount = $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                                $data['Beneficaire_15'] = 'DGDA';

                                # SAVE PAYMENT
                                
                                $results = $infos;
                                $prefix = 1;
                                $logirefid = $data['Logirefid_4'];
                                $end_execution = NULL;
                               
                                
                                # Comptabilisation
                                # Prmiere partie - 
                                $Missmatch['Missmatch_32'] = 0;
                                
                                
                                $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                                
                                $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");
                                
                                $prepayments = $this->prepayments_model->get_prepayments_by_reference($_POST['account_reference']);
                                
                                $random = rand(1, 9999);
                                $reference_lot = date('H').date('i').date('s').date('j').date('m').date('y').$random;
                                
                                $return = "";
                        
                                foreach($prepayments as $row)
                                {
                                        $encaissement = $this->data_model->sydonia_migrate_prepayment($row->Id_0);
                                        
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                
                                        $case = $this->comptabilisation_model->get_use_case($data);
                                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, "DGDA");
                                        
                                        $object = json_encode($encaissement);
                                        $data = json_decode($object, true);
                                        
                                        $data['Compte_33'] = $_POST['Compte_33'];
                                        $data['Comptec'] = $_POST['Comptec'];
                                        $data['Notereference_30'] = json_encode($data['Notereference_30']);
                                        
                                        if($_POST['fbank'] && $_POST['fbank'] == 'fb')
                                        {
                                                $amount = isset($row->Amount_18) ? $row->Amount_18 : "";
                                                $devise = "CDF";
                                                $service = isset($row->Office_8) ? $row->Office_8 : "";
                                                $agence = $_SESSION['Logiref_guichet'];

                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                if($devise !='CDF')
                                                {
                                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                        {
                                                                $devise_taux = $_POST['Taux'];
                                                        }
                                                        else
                                                        {
                                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                                $devise_taux = $taux['Dollar_4'];
                                                        }
                                                }
                                                else
                                                {
                                                        $devise_taux = 1;
                                                }

                                                $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                                if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                                {
                                                        $com['com'] = ($amount * $rules['Valeur'])/100;
                                                        $com['devise'] = $devise;
                                                }
                                                elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                                {
                                                        $com['com'] = $rules['Valeur'];
                                                        $com['devise'] = $rules['Unite'];
                                                }

                                                if(!empty($com) && $com['com']!=0)
                                                {
                                                        if($com['devise'] !='CDF')
                                                        {
                                                                $commission = $com['com'] * $devise_taux;
                                                                $commission_devise = $com['devise'];
                                                        }
                                                        else
                                                        {
                                                                $commission = $com['com'];
                                                                $commission_devise = $com['devise'];
                                                        }
                                                }

                                                $data['Commission_23'] = $commission;
                                                $data['Devise_24'] = $commission_devise;
                                        }
                                        else
                                        {
                                                $data['Commission_23'] = 0;
                                                $data['Devise_24'] = "CDF";
                                                $commission = 0;
                                                $commission_devise = "CDF";
                                        }                                        
                                        switch ($case)
                                        {
                                                case "case_1": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                        break;
                                                case "case_2": 
                                                        $instructions = $this->comptabilisation_model->get_prepayment_instructions_case_2($data, $comptes,"DGDA");
                                                        break;
                                                case "case_3": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                        break;
                                                case "case_4": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                        break;
                                                default: 
                                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                        break;
                                        }

                                        if(!empty($instructions))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                $end_execution = $this->comptabilisation_model->save_prepayments_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);
                                                unset($instructions);

                                        }
                                        #SAVE PAYMENT DE CHAQUE TAXE
                                        #Comptes CGU & CPT
                                        $guichet = $this->session->userdata("Logiref_guichet");
                                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                                        
                                        #Taxes comptes
                                        unset($comptes);
                                        unset($data['Comptec']);
                                        unset($data['fbank']);
                                        
                                        
                                        $comptes = array();
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $instructions = array();

                                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                                        $info = $encaissement->Notereference_30;

                                        $taxes = $info['taxesPaid'];
                                        
                                        unset($data['CGU']);
                                        unset($data['Total']);
                                        
                                        $frais_bcc = 0;
                                        $montant_total = $data['Montant_11'];
                                        
                                        foreach($taxes as $taxe)
                                        {
                                                $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                                $data['Montant_11'] = $taxe->taxeAmount;
                                                $data['Typerecette_17'] = $taxe->taxeCode;
                                                $data['Commission_23'] = $commission;
                                                $data['Devise_24'] = $commission_devise;
                                                
                                                $prefix++;
                                                
                                                if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                                {
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];
                                                        
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                        
                                                        $frais_bcc = $amount + $frais_bcc;

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $pid = $this->encaissement_model->save_payment_tresor($data, NULL);
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda_prepayments($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                        $instructions[] = $instruction;
                                                }
                                                else if(isset($beneficiaires[$taxe->taxeCode]))
                                                {
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];
                                                        
                                                        
                                                        $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda_prepayments($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                                else
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $pid = $this->encaissement_model->save_payment_propres($data, NULL);

                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda_prepayments($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        
                                        if(isset($_POST['frais_bcc']) && $_POST['frais_bcc'] > 0)
                                        {
                                                # Transaction of the BCC fees for each payment of the batch.
                                                $comptes = array();

                                                $data['frais_bcc'] = $frais_bcc;

                                                # Account to debit the BCC fess

                                                $compte_debit = $_POST['Comptec'];
                                                $devise_compte = $_POST['Devisec'];

                                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, "DGDA");

                                                $instructions_frais_bcc = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes, $compte_debit, $devise_compte);

                                                $priority = 2;
                                                $this->comptabilisation_model->save_prepayments_instructions_frais_bcc($row->Id_0, $data, $instructions_frais_bcc, $data['Logirefid_4'], $priority);
                                        }
                                        
                                        if(!empty($instructions))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                $end_execution = $this->comptabilisation_model->save_prepayments_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);
                                                unset($instructions);
                                        }

                                        if($end_execution)
                                        {
                                                $bl_data['Status_2'] = '2';
                                                $bl_data['Designation_21'] = $data['Designation_14'];
                                                $bl_data['Account_22'] = $compte_cgu;
                                                $bl_data['Taux_23'] = $data['Taux_41'];
                                                $bl_data['Commission_24'] = $data['Commission_23'];
                                                $bl_data['Devise_25'] = $data['Devise_24'];
                                                $bl_data['Amount_26'] = $montant_total + $frais_bcc;
                                                $bl_data['Account_27'] = $_POST['Compte_33'];
                                                $bl_data['Devise_28'] = $data['Devise_34'];
                                                $bl_data['Accountholder_29'] = $infos['accountname'];
                                                $bl_data['Lot_19'] = $reference_lot;
                                                $bl_data['Agence_30'] = $_SESSION['Logiref_guichet'];
                                                $bl_data['Account_31'] = $_POST['Comptec'];
                                                
                                                if(isset($_POST['frais_bcc']) && $_POST['frais_bcc'] > 0)
                                                {   
                                                        $bl_data['Fees_32'] = $frais_bcc;
                                                }
                                                $return = $this->prepayments_model->update_prepayement($bl_data, $row->Id_0);
                                        }
                                }
                                
                                echo $return;
                        }
                        
                }
                elseif($obj == "validate_extract")
                {
                        $compte_sydonia = isset($_POST['compte_sydonia']) ? $_POST['compte_sydonia'] : "";
                        $prepayment = $this->prepayments_model->get_prepayments_by_reference($compte_sydonia, "all");
                        
                        $amount = 0;
                        $frais_bcc = 0;
                        $response = "";
                        
                        if(isset($prepayment) && $prepayment !="")
                        {
                                foreach($prepayment as $row)
                                {
                                        $amount = $row->Amount_18 + $amount;
                                        
                                        if($row->Fees_32 > 0)
                                        {
                                                $frais_bcc = $row->Fees_32 + $frais_bcc;
                                        }
                                }
                        }
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                        $data['fees_account'] = isset($comptes['Ebcdc']['FBC']['CDF']) ? $comptes['Ebcdc']['FBC']['CDF'] : '';
                        $data['prepaid_account'] = isset($prepayment[0]) ? $prepayment[0]->Account_27 : "";
                        $data['client_account'] = isset($prepayment[0]) ? $prepayment[0]->Account_31 : "";
                        $data['lot'] = isset($prepayment[0]) ? $prepayment[0]->Lot_19 : "";
                        $data['amount'] = $amount;
                        $data['fees_amount'] = $frais_bcc;
                        $data['compte_sydonia'] = $compte_sydonia;
                        $data['designation'] = isset($prepayment[0]) ? $prepayment[0]->Designation_21 : "";
                        $data['nif'] = isset($prepayment[0]) ? $prepayment[0]->Nif_15 : "";
                        $data['office'] = isset($prepayment[0]) ? $prepayment[0]->Office_8 : "";
                        $data['makerid'] = isset($prepayment[0]) ? $prepayment[0]->Creator_4 : "";
                        
                        $gu_instructions = $this->comptabilisation_model->get_prepayment_gu_instructions($data['lot']);
                        
                        if(empty($gu_instructions))
                        {
                                $instruction = $this->comptabilisation_model->get_instructions_gu_prepayment($data, $prepayment);
                                
                                
                                if(!empty($instruction))
                                {
                                        # priority for integrating the counting in cbs
                                        $end_execution = $this->comptabilisation_model->save_prepayments_gu_instructions($instruction, $data);
                                }
                        }
                        else
                        {
                                $end_execution = true;
                        }
                        
                        if($end_execution)
                        {
                                $response = $this->curl_model->call_bank_batch_debit($data);
                        }
                        
                        $code = '';
                        $return = json_decode($response, true);

                        if(isset($return['response']) && $return['response'] == "200")
                        {
                                $code = 200;
                        }
                        elseif(isset($return['response']) && $return['response'] !="")
                        {
                                $code = $return['response'];
                        }
                        else
                        {
                                $code = "E411";
                        }
                                
                        $retour = array('code'=>$code);
                        echo json_encode($retour);
                        
                        
                }
                elseif($obj == "validate_batch")
                {
                        $prepayments = $_POST['paimentid'];
                        
                        $validation = array();
                        //var_dump($prepayments);die;
                        foreach($prepayments as $row)
                        {
                                $data['Priority'] = 1;
                                $data['Type'] = 'prepayment';
                                $data['Sydonia_49'] = $row;
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Account_3'] = $this->session->userdata('account_id');
                                
                                $agence_src= $_SESSION['Logiref_guichet'];
                        
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                                #Invocation of the api transfer
                                @set_time_limit(300);
								
								$id = $row;
                                
                                $bl_data['Status_2'] = '5';
                                $bl = $this->integration_model->update_prepayement($bl_data, $id);
                                    
                                $response = $this->curl_model->call_bank_virement($data);
                                
                                $return = json_decode($response, true);
                                
                                $validation[$row]['response'] = $return['response']; 
                                
                                
                                
                                if(isset($return['response']) && $return['response'] == "200")
                                {
                                        $code = 200;
                                                
                                        $paiement = $this->encaissement_model->get_prepaiement_tresor_bl($row);
                                        
                                        if(isset($paiement->Notereference_30) && $paiement->Notereference_30 != "")
                                        {
                                                $result = json_decode($paiement->Notereference_30, true);
                                        
                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                $data_to_validate['Notereference_30'] = json_encode($result);
                                        }
                                        
                                        $data_to_validate['Status_2'] = 1;
                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                        

                                        # Update the paiement related to the bulletin
                                        $tid = $this->encaissement_model->update_prepayment_tresor_dgda($data_to_validate, $id);
                                        $pid = $this->encaissement_model->update_prepayment_propres_dgda($data_to_validate, $id);

                                        
                                        $bl_data['Status_2'] = '3';
                                        $bl = $this->integration_model->update_prepayement($bl_data, $id);
                                }
                               
                        }
                        
                        $result = json_encode($validation);

                        echo $result;
                }
                elseif($obj == "updateprepayment")
                {
                        $status = $arg;
                        $ordData['Status_2'] = $status;
                        $ordData['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $ordData['Changer_6'] = $this->session->userdata('user_id');
                        $ref = $this->prepayments_model->update_prepayement($ordData, $id);
                        return $ref;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */