<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notes extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'notes';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/rates_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'notes';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissement_model->documents;
                $this->data['devises'] = $this->encaissement_model->devises;
                $this->data['modes'] = $this->encaissement_model->modes;
                $this->data['moyens'] = $this->encaissement_model->moyens;
                $this->data['infos'] = $this->encaissement_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 1;
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
						unset($recettes["DGRAD"]['27421600']);
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
				elseif($obj == "passport")
                {
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");

                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['step'] = 1;

                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "verification")
                {
                        $checked = false;

                        $data = $_POST;

                        $data['Reference_8'] = strtoupper($data['Reference_8']);

                        $note_exist = $this->integration_model->get_note_by_ref($data['Reference_8']);
                        $encaissement = $this->encaissement_model->get_paiement_by_reference($_POST['Reference_8']);

                        if(!empty($note_exist) && !empty($encaissement))
                        {
								if($encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == '0' && $encaissement->Type_57 == 'mobile')
                                {
                                        $response = $note_exist->Id_0;
                                        $checked = true;
                                }		
                                elseif($encaissement->Status_2 == '1' && $encaissement->Checkerid_10 != '0' )
                                {
                                        $response = "E505";
                                }
                                elseif($encaissement->Status_2 == '3')
                                {
                                        $response = "E506";
                                }							
                                elseif($encaissement->Status_2 != '0')
                                {
                                        $response = "E503";
                                }
                        }
                        elseif((isset($note_exist->Id_0) && $note_exist->Status_2 == 1))
                        {
                                $response = $note_exist->Id_0;
                        }
                        elseif(isset($note_exist->Id_0) && $note_exist->Status_2 == 2)
                        {
                                $response = "E504";
						}
                        else
                        {
                                if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600"):

                                        $response = $this->curl_model->call_dgrad_notes_passport($data);
                                else:
                                        $response = $this->curl_model->call_dgrad_notes($data);
                                        //$response = "E000";
                                endif;
                        }

						if($response == "E604" || $response == "E000" || $response=="E002" || $response == "E22" || $response == "E404" || $response == "E405" || $response == "E503" || $response == "E504" || $response == "E505" || $response == "E506"  || $response=="401" || $response=="402" || $response=="500")
                        {
								if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600" && $response == "E404")
                                {
                                        $_SESSION['login_info']['ip']['attempts']++;
										
                                        $return = $this->logiref_model->get_ipaddress_info($_SERVER['REMOTE_ADDR']);

                                        if($_SESSION['login_info']['ip']['attempts'] <= 2)
                                        {
                                                $_SESSION['login_info']['username']['attempts']=0;
                                                $_SESSION['login_info']['ip']['attempts'] = 0;																				
                                        }
                                        elseif($_SESSION['login_info']['ip']['attempts'] >=3)
                                        {
                                                $this->save_ipaddress();
                                                echo '<span  style="color:#F00">Vous avez dépassé le nombre maximum de consultation après 3 tentatives avec une mauvaise ref&eacute;f&eacute;rence.</span>';
                                                die;	
                                        }
                                }
								else 
                                {
									$_SESSION['login_info']['ip']['attempts']=0;
                                } 
								
								echo $response;
                        }
                        else
                        {
                                $note = $this->integration_model->get_paiement_logirad($response);

                                if(isset($note->Id_0))
                                {
                                        $this->rates_model->get_exchange_rates();

                                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);

                                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");

                                        $this->data['recettes'] = $recettes["DGRAD"];

                                        if ($checked)
                                        {
                                                $pid = $encaissement->Id_0;
                                                $this->data['encaissement'] =  $this->encaissement_model->get_paiement_info($pid);
                                        }
                                        else
                                        {
                                                $this->data['encaissement'] =  $this->data_model->logirad_migrate_note($response);
                                        }
                                       
                                        //$this->data['encaissement'] =  $this->data_model->logirad_migrate_note($response);
                                        $this->data['note_id'] = $response;

                                        $this->data['note'] = $note;

                                        $this->load->view($this->module.'/'.$this->group. '/notes/_step_2', $this->data);
                                }
                                else
                                {
                                        echo 'E406';
                                }
                        }
                }
                elseif ($obj == "verify_passport") 
                {
                        $checked = false;
                        $data = $_POST;
                        $data['Reference_8'] = strtoupper($data['Reference_8']);

                        $note_exist = $this->integration_model->get_note_by_ref($data['Reference_8']);
                        $encaissement = $this->encaissement_model->get_paiement_by_reference($data['Reference_8']);

                        $code = null;
                        $responseMessage = null;
                        $html = null;

                        if (!empty($note_exist) && !empty($encaissement)) 
                        {
                                if (($encaissement->Status_2 == 1 || $encaissement->Status_2 == 0) && $encaissement->Checkerid_10 == '0' && $encaissement->Type_57 == 'mobile') 
                                {
                                        $code = $note_exist->Id_0;
                                        $checked = true;
                                } 
                                elseif (($encaissement->Status_2 == '1' || $encaissement->Status_2 == '2') && $encaissement->Checkerid_10 != '0') 
                                {
                                        $date_paiement = strftime('%d/%m/%Y', strtotime($encaissement->Validation_36));
                                        $code = "E505";
                                        $html = '<div class="alert alert-warning text-white">D&eacute;sol&eacute;!... Paiement d&eacute;j&agrave; valid&eacute; dans <strong>FINACLE</strong>, le <strong>' . $date_paiement . '</strong> !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif ($encaissement->Status_2 == '3') 
                                {
                                        $date_paiement = strftime('%d/%m/%Y', strtotime('+1 day', strtotime($encaissement->Validation_36)));
                                        $code = "E506";
                                        $html = '<div class="alert alert-warning text-white">D&eacute;sol&eacute;!... Paiement d&eacute;j&agrave; revers&eacute; , le <strong>' . $date_paiement . '</strong> !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif ($encaissement->Status_2 != '0') 
                                {
                                        $date_paiement = strftime('%d/%m/%Y', strtotime($encaissement->Date_1));
                                        $code = "E503";
                                        $html = '<div class="alert alert-warning text-white">D&eacute;sol&eacute;!... Paiement d&eacute;j&agrave; enregistr&eacute; , le <strong>' . $date_paiement . '</strong> !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }

                        } 
                        elseif ((isset($note_exist->Id_0) && $note_exist->Status_2 == 1)) 
                        {
                                $code = $note_exist->Id_0;
                        } 
                        elseif (isset($note_exist->Id_0) && $note_exist->Status_2 == 2) 
                        {
                                $code = "E504";
                        } 
                        else 
                        {
                                if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600") 
                                {
                                        $code = $this->curl_model->call_dgrad_notes_passport($data);
                                } 
                                else 
                                {
                                        $code = "E000";
                                }
                        }

                        // Gestion des tentatives et limites
                        if (in_array($code, ["E604", "E000", "E002", "E22", "E404", "E405", "E503", "E504", "E505", "E506", "401", "402", "500"])) 
                        {
                                if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600" && $code == "E404") 
                                {
                                        $_SESSION['login_info']['ip']['attempts']++;

                                        $return = $this->logiref_model->get_ipaddress_info($_SERVER['REMOTE_ADDR']);

                                        if ($_SESSION['login_info']['ip']['attempts'] <= 2) 
                                        {
                                                $_SESSION['login_info']['username']['attempts'] = 0;
                                                $_SESSION['login_info']['ip']['attempts'] = 0;
                                        } 
                                        elseif ($_SESSION['login_info']['ip']['attempts'] >= 3) 
                                        {
                                                $this->save_ipaddress();
                                                echo json_encode([
                                                        'code' => 'LOCKOUT',
                                                        'message' => 'Vous avez dépassé le nombre maximum de consultation après 3 tentatives avec une mauvaise référence.'
                                                ]);
                                                die;
                                        }
                                } 
                                else 
                                {
                                        $_SESSION['login_info']['ip']['attempts'] = 0;
                                }

                                // Retour simple avec code d'erreur et message html si défini
                                echo json_encode([
                                        'code' => $code,
                                        'message' => $html ?? null
                                ]);
                                die;
                        } 
                        else 
                        {
                                $note = $this->integration_model->get_paiement_logirad($code);

                                if (isset($note->Id_0)) 
                                {
                                        $this->rates_model->get_exchange_rates();

                                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", NULL, true);

                                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");

                                        $this->data['recettes'] = $recettes["DGRAD"];

                                        if ($checked) 
                                        {
                                                $pid = $encaissement->Id_0;
                                                $this->data['encaissement'] =  $this->encaissement_model->get_paiement_info($pid);
                                        } 
                                        else 
                                        {
                                                $this->data['encaissement'] =  $this->data_model->logirad_migrate_note($code);
                                        }

                                        $this->data['note_id'] = $code;
                                        $this->data['note'] = $note;

                                        // Capture la vue en variable
                                        $htmlView = $this->load->view($this->module.'/'.$this->group. '/notes/_step_2', $this->data, true);

                                        echo json_encode([
                                                'code' => 'SUCCESS',
                                                'html' => $htmlView
                                        ]);
                                } 
                                else 
                                {
                                        echo json_encode([
                                                'code' => 'E406',
                                                'message' => 'Un problème est survenu. Merci de réessayer plus tard.'
                                        ]);
                                }
                                die;
                        }
                }
                elseif($obj == "create")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['client'] = $this->logiref_model->get_clients_by_nif($_POST['Nifclient_7']);
                        $this->data['recettes'] = $recettes["DGRAD"];
						unset($recettes["DGRAD"]['27421600']);
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        
                        $this->data['note_reference'] = $this->encaissement_model->get_paiement_by_reference($_POST['Reference_8']);
                       
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "edit")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error! To assign a member to a group, please select both a member and a group.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();

                                if(isset($_POST['Ndeclaration']))
                                {
                                        $declaration = $_POST['Ndeclaration'];
                                        unset($_POST['Ndeclaration']);
                                }

                                // Controle sur la vérification des informations soumises dans la view et celles retournées par l'API
								if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']=="27421600")
                                {
                                        if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                        {	
                                                $note_exist = $this->integration_model->get_note_by_ref($_POST['Noteid_26']);
                                                if(!empty($note_exist))
                                                {
                                                        $_POST['Logiradid'] = $note_exist->Id_0;
                                                }
                                                else
                                                {
                                                        $_POST['Logiradid'] = "";
                                                }
                                        }
                                        
                                        if ((isset($_POST['Montant_11']) && $_POST['Montant_11'] < 0) || (isset($_POST['Commission_23']) && $_POST['Commission_23'] < 0) || (isset($_POST['Notemontant_28']) && $_POST['Notemontant_28'] < 0) || (isset($_POST['Infos']['totalMontant']) && $_POST['Infos']['totalMontant'] < 0))
                                        {
                                                echo $return['response'] = 'PP405';
                                                die;
                                        }
									
                                        if (isset($_POST['Logiradid']) && $_POST['Logiradid']!="")
                                        {
                                                $logirad_id = $_POST['Logiradid'];

                                                $note = $this->integration_model->get_paiement_logirad($logirad_id);
												
                                                if (!empty($note))
                                                {
                                                        $infos = $_POST['Infos'];

                                                        if (isset($note->Notereference_23) && $note->Notereference_23!=""):
                                                                $quote_parts = json_decode($note->Notereference_23, true);
                                                        else:
                                                                $quote_parts = array();
                                                        endif;
															
                                                        $_POST['Notemontant_28'] = str_replace(' ','',$_POST['Notemontant_28']);
                                                        $_POST['Notemontant_28'] = str_replace(',','.',$_POST['Notemontant_28']);
                                                                
                                                        if(isset($_POST['Noteid_26']) && isset($_POST['Typerecette_17']) && isset($_POST['Notemontant_28']) && isset($_POST['Nif_13'])&& isset($_POST['Designation_14'])&& isset($infos['QuotasComite'])&& isset($infos['QuotasPrestataire']) && isset($infos['QuotasService']) && isset($infos['QuotasTresor']))
                                                        {
                                                                $conditions = array(
                                                
                                                                        strtoupper($_POST['Noteid_26']) == strtoupper($note->Reference_21),
                                                                        $_POST['Typerecette_17'] == $note->Recette_20,
                                                                        $_POST['Notemontant_28'] == $note->Montantdu_15,
                                                                        strtoupper($_POST['Nif_13']) == strtoupper($note->Nif_22),
                                                                        $_POST['Designation_14'] == $note->Requerant_11,
                                                                        ($infos['QuotasComite']) == $quote_parts['comite'],
                                                                        ($infos['QuotasPrestataire']) == $quote_parts['prestataire'],
                                                                        ($infos['QuotasService']) == $quote_parts['service'],
                                                                        ($infos['QuotasTresor']) == $quote_parts['tresorPublic']
                                                                );
                                                        }
                                                        else
                                                        {
                                                                $conditions = array();
                                                        }
											
                                                        if (in_array(false, $conditions, true)) 
                                                        {
                                                                //echo $return['response'] = 'PP401';
                                                                //die;
                                                        }
                                                }
                                                else
                                                {
                                                        //echo $return['response'] = 'PP400';
                                                        //die;
                                                }
                                        }
                                        else
                                        {
                                                echo $return['response'] = 'PP403';
                                                die;
                                        }
                                }

                                // Controle sur les taux d'echange a appliquer
                                if($_POST['Devise_34'] == 'CDF' && $_POST['Devise_12'] == 'USD')
                                {
                                        $data = $_POST;
                                }
                                else 
                                {
                                        $_POST['Infos']['rate_code'] = 'TTB';
                                        $data = $_POST;
                                }
                                
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata('account_id');
                                if($_SESSION['Logiref_role'] ==4 || $_SESSION['Logiref_role'] ==9) $data['Makerid_9'] = $this->session->userdata('user_id');
                                $benificiaire = $data['Beneficaire_15'] = 'DGRAD';
                                $infos = $data['Infos'];
                                
                                // Test if the total_amount has been calculated
                                if($infos['totalMontant'] == "")
                                {
                                        $infos['totalMontant'] = $this->encaissement_model->get_montant_total($data);
                                }
                                
				// formatage des valeurs des quotas de chaque beneficiaire pour un paiement IPRIER  
                                if($data['Typerecette_17'] == "27421600" && $infos['QuotasComite'] != "" && $infos['QuotasPrestataire'] !="" && $infos['QuotasService'] !="" && $infos['QuotasTresor'] !="")
                                {
                                        $infos['QuotasComite'] = str_replace(' ','',$infos['QuotasComite']);
                                        $infos['QuotasComite'] = str_replace(',','.',$infos['QuotasComite']);
                                        
                                        $infos['QuotasPrestataire'] = str_replace(' ','',$infos['QuotasPrestataire']);
                                        $infos['QuotasPrestataire'] = str_replace(',','.',$infos['QuotasPrestataire']);
                                        
                                        $infos['QuotasService'] = str_replace(' ','',$infos['QuotasService']);
                                        $infos['QuotasService'] = str_replace(',','.',$infos['QuotasService']);
										
                                        $infos['QuotasTresor'] = str_replace(' ','',$infos['QuotasTresor']);
                                        $infos['QuotasTresor'] = str_replace(',','.',$infos['QuotasTresor']);

                                        $infos['Email'] = isset($infos['Email']) ? $infos['Email']:"";
                                        $infos['Phone'] = isset($infos['Phone']) ? $infos['Phone'] : "";
                                }
								
                                #Invoque the API account.info to retrieve the client informations
                                
                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);
                                
                                $data['Artbudgetaire_18'] = $infos['standard'];
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                    
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                                # SAVE PAYMENT
                                # Check if it's a new payment
                                if($data['Id_0']=="" || $data['Id_0']==0)
                                {
                                        unset($data['Id_0']);
                                        $ref = $this->encaissement_model->get_id_by_reference($data['Logirefid_4']);
                                        $data['Id_0'] = $ref;
                                }

                                # Encaissement existant
                                if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                        {
                                                #Invocation of the api transfer
                                                $id = $data['Id_0'];

                                                if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']=="27421600")
                                                {
														$data_to_update['Status_2'] = 5;
														$data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
														$this->encaissement_model->update_payment_tresor($data_to_update, $id);
														
                                                        $data['Trans'] = 'firstTrans';
														$data['Priority_27'] = 0;
                                                        
                                                        $response1 = $this->curl_model->call_bank_virement_passport($data);

                                                        $return1 = json_decode($response1, true);

                                                        if (isset($return1['response']) && $return1['response'] == '200') 
                                                        {
                                                                $logirefid = $data['Logirefid_4'];
                                                                
                                                                $data_to_update1 = array();
                                                                
                                                                $data_to_update1['Status_2'] = 6;
                                                                $data_to_update1['Checkerid_10'] = $this->session->userdata("user_id");
                                                                $data_to_update1['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                                # Save changes
                                                                $this->encaissement_model->update_payment_tresor_by_ref($data_to_update1, $_POST['Logirefid_4']);

                                                                $data['Trans'] = 'secondTrans';
																$data['Priority_27'] = 1;

                                                                $response = $this->curl_model->call_bank_virement_passport($data);
                                                        }
                                                        else
                                                        {
                                                                $response = $response1;
                                                        }

                                                        if(isset($data['Trans'])) unset($data['Trans']);
                                                        if(isset($data['Priority_27'])) unset($data['Priority_27']);
                                                }
                                                else
                                                {
														$data_to_update['Status_2'] = 5;
														$data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
														$this->encaissement_model->update_payment_tresor($data_to_update, $id);
														
                                                        $response = $this->curl_model->call_bank_virement($data);
                                                }

                                                $return = json_decode($response, true);
                                                //$return['response'] ='200';
                                                //$return['Num_evenement'] ="87E8898";
												 
                                                if(isset($return['response']) && $return['response'] =='200')
                                                {
                                                        $data_to_update2 = array();

                                                        $result = json_decode($data['Notereference_30'], true);
                                                                
                                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                                
                                                        $logirefid = $data['Logirefid_4'];

														#Call  the api to confirm a note passport
                                                        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] == "27421600")
                                                        {
                                                                $data_to_update2['Status_2'] = 7;
                                                                $data_to_update2['Checkerid_10'] = $this->session->userdata("user_id");
                                                                $data_to_update2['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                                # Save changes
                                                                $this->encaissement_model->update_payment_tresor_by_ref($data_to_update2, $_POST['Logirefid_4']);

                                                                $apidata = array();

                                                                $guichets = $this->branches_model->get_dropdown("guichets");
                                                                $code_agences = $this->branches_model->get_dropdown("codeagences");

                                                                $apidata['codeAgence'] = isset($code_agences[$_SESSION['Logiref_guichet']]) ? $code_agences[$_SESSION['Logiref_guichet']]: "";
                                                                $apidata['agence'] = isset($guichets[$_SESSION['Logiref_guichet']]) ? $guichets[$_SESSION['Logiref_guichet']] : "";
                                                                $apidata['Noteid_26'] = isset($_POST['Noteid_26']) ? $_POST['Noteid_26'] : "";
                                                                $apidata['Reference_32'] = isset($_POST['Reference_32'])?$_POST['Reference_32']:"";

                                                                $apidata['Montant_11'] = isset($_POST['Montant_11'])?$_POST['Montant_11']:"0";
                                                                $apidata['Montant_11'] = str_replace(' ','',$apidata['Montant_11']);
                                                                $apidata['Montant_11'] = str_replace(',','.',$apidata['Montant_11']);

                                                                $apidata['Devise_12'] = isset($_POST['Devise_12'])? $_POST['Devise_12']:"";
                                                                $apidata['Taux_41'] = isset($_POST['Taux_41'])? $_POST['Taux_41']:"";

                                                                $return_logirad = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);
                                                                
                                                                if($return_logirad == "CP604" || $return_logirad == "CP000" || $return_logirad=="CP001" || $return_logirad=="CP002" || $return_logirad == "CP22"  || $return_logirad == "CP404" || $return_logirad == "CP200")
                                                                {
                                                                        if ($return_logirad != "CP200")
                                                                        {
                                                                                $cdata = array();
                                                                                $cdata['Status_2'] = 7;

                                                                                # Save changes
                                                                                $this->encaissement_model->update_payment_tresor_by_ref($cdata, $_POST['Logirefid_4']);
                                                                        }

                                                                        echo $return_logirad;
                                                                        die;
                                                                }
                                                                else
                                                                {
                                                                        //$data['Notereference_30'] = json_encode($result);
                                                                        //$data['Id_0'] = $id;
                                                                        $data['Logirefid_4'] = $logirefid;
                                                                        $data['Status_2'] = 2;
                                                                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                                                                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                                                        $data['Logirad_53'] = $return_logirad;
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $data_to_update2['Notereference_30'] = json_encode($result);
                                                                $data_to_update2['Id_0'] = $id;
                                                                $data_to_update2['Logirefid_4'] = $logirefid;
                                                                $data_to_update2['Status_2'] = 1;
                                                                $data_to_update2['Checkerid_10'] = $this->session->userdata("user_id");
                                                                $data_to_update2['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                                # Save changes
                                                                $this->encaissement_model->update_payment_tresor_by_ref($data_to_update2, $_POST['Logirefid_4']);
                                                        }
                                                }
                                                elseif(isset($return['response']) && $return['response'] != "")
                                                {
                                                        echo $return['response'];
                                                        die;
                                                }
                                                else
                                                {
                                                        echo 'E411';
                                                        die;
                                                }
                                        }
                                        else 
                                        {
                                                $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                                $this->comptabilisation_model->delete_instructions_dgrad($data['Logirefid_4']);
                                        }

                                        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']=="27421600")
                                        {
                                                $noteid = isset($data['Noteid_26']) ? $data['Noteid_26'] : "";
                                                $encaissement = $this->encaissement_model->get_paiement_by_reference($noteid);

                                                if (!empty($encaissement))
                                                {
                                                        if (($encaissement->Status_2 == '0' || $encaissement->Status_2 == '1') && $encaissement->Checkerid_10 == '0' &&  $encaissement->Type_57 == 'mobile')
                                                        {
                                                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $data['Status_2'] = '1';
                                                                $data['Datevaleur_31'] = gmdate('Y-m-d');
                                                                $data['Checkerid_10'] = '0';
                                                                $data['Paymentmode_56'] = '';
																$data['Type_57'] = '';
                                                        }
                                                }
                                   
                                                if (isset($data['Logiradid']))
                                                {
                                                        $data['Logirad_53'] = $data['Logiradid'];
                                                        unset($data['Logiradid']);
                                                }
                                        }

                                        # Save changes
                                        $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                        
                                }
                                # Nouvel encaissement
                                else
                                {
                                        #Enregistrement
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $instructions = array();
                                        $logiref_id = $data['Logirefid_4'];
										
                                        if($data['Id_0'] == 0) $data['Id_0'] = NULL;
		
                                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                                        $rType = $type_recettes[$data['Typerecette_17']];
										
                                        if (isset($data['Logiradid']))
                                        {
                                                $data['Logirad_53'] = $data['Logiradid'];
                                                unset($data['Logiradid']);
                                        }
										
                                        if($rType=='TRESOR' || $rType=='RFTRESD')
                                        {
                                                $pid = $this->encaissement_model->save_payment_tresor($data, $data['Id_0']);
                                        }
                                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                                        {
                                                $pid = $this->encaissement_model->save_payment_propres($data, $data['Id_0']);
                                        }

                                        $data['Id_0'] = $pid;
                                } 
                                
                                if($_SESSION['Logiref_role'] ==4 || $_SESSION['Logiref_role'] ==9)
                                {
                                        #Comptabilisation
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $agence_dst=NULL;
                                        $list = NULL;

                                        $case = $this->comptabilisation_model->get_use_case($data);
                                        $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst);
										
                                        $date_emission = isset($data['Notedate_27']) ? $data['Notedate_27'] : "";

                                        if($data['Typerecette_17'] == '27022470' || $data['Typerecette_17'] == '27022450' || $data['Typerecette_17'] == '27421600')
                                        {
                                                $taxe_cpi = $data['Typerecette_17'];
                                        }
                                        else
                                        {
                                                $taxe_cpi = NULL;
                                        }
										
                                        switch ($case)
                                        {
                                                case "case_1": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGRAD", NULL, NULL, $date_emission);
                                                        break;
                                                case "case_2": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRAD", NULL, NULL, $date_emission, $taxe_cpi);
                                                        break;
                                                case "case_3": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGRAD", NULL, NULL, $date_emission);
                                                        break;
                                                case "case_4": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGRAD", NULL, NULL, $date_emission);
                                                        break;
                                                case "case_5": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_5($data, $comptes,"DGRAD", NULL, NULL, $date_emission);
                                                        break;
                                                default: 
                                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGI");
                                                        break;
                                        }

                                        if(!empty($instructions))
                                        {
                                                $end_execution = $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $instructions, $data['Logirefid_4'],0);
                                        }
										
					#Guichet Unique (compte sequestre) DGRAD - passport
                                        if($data['Typerecette_17'] == '27421600' && $infos['QuotasComite'] != "" && $infos['QuotasPrestataire'] !="" && $infos['QuotasService'] !="" && $infos['QuotasTresor'] !="")
                                        {
                                                $instructions = $this->comptabilisation_model->get_instructions_dgrad_passport($data, $comptes,'DGRAD', $date_emission);

                                                $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $instructions, $data['Logirefid_4'], 1);
                                        }
                                }
                                
                                #Return
                                echo $data['Id_0'];
                                die;
                        }
                }
		elseif($obj == "confirm_note")
                {
                        $data = array();
                        $data = $_POST;
                        
                        # Encaissement existant
                        if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if($_SESSION['Logiref_role'] ==3)
                                {
                                        #Invocation of the api transfer
                                        if (isset($data['Typerecette_17']) && $data['Typerecette_17'] == "27421600")
                                        {
                                                $guichets = $this->branches_model->get_dropdown("guichets");
                                                $code_agences = $this->branches_model->get_dropdown("codeagences");

                                                $apidata = array();

                                                $apidata['codeAgence'] = isset($code_agences[$_SESSION['Logiref_guichet']]) ? $code_agences[$_SESSION['Logiref_guichet']]: "";
                                                $apidata['agence'] = isset($guichets[$_SESSION['Logiref_guichet']]) ? $guichets[$_SESSION['Logiref_guichet']] : "";
                                                $apidata['Noteid_26'] = isset($_POST['Noteid_26']) ? $_POST['Noteid_26'] : "";
                                                $apidata['Reference_32'] = isset($_POST['Reference_32'])?$_POST['Reference_32']:"";

                                                $apidata['Montant_11'] = isset($_POST['Montant_11'])?$_POST['Montant_11']:"0";
                                                $apidata['Montant_11'] = str_replace(' ','',$apidata['Montant_11']);
                                                $apidata['Montant_11'] = str_replace(',','.',$apidata['Montant_11']);

                                                $apidata['Devise_12'] = isset($_POST['Devise_12'])? $_POST['Devise_12']:"";
                                                $apidata['Taux_41'] = isset($_POST['Taux_41'])? $_POST['Taux_41']:"";

                                                $response = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);
                                               
                                                if($response == "CP604" || $response == "CP000" || $response=="CP001" || $response=="CP002" || $response == "CP22"  || $response == "CP404" || $response == "CP200"):
                                                        echo $response;
                                                        die;
                                                else: 
                                                        $cdata = array();
                                                        $cdata['Status_2'] = 2;

                                                        # Save changes
                                                        $this->encaissement_model->update_payment_tresor_by_ref($cdata, $_POST['Logirefid_4']);

                                                        echo $response;
                                                        die;
                                                endif;
                                        }
                                }

                        }
                }
                elseif($obj == "delete")
                {
                        $RecetteTYPES = $this->logiref_model->get_dropdown("type_recette");
                        $code_recette = $this->input->get('recette');
                        
                        $rType = $RecetteTYPES[$code_recette];
                        $pid = 0;
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_propre($id);
                        }
                        if($pid > 0)
                        {
                                $this->comptabilisation_model->delete_instructions_dgrad($id);
                        }
                        #Return
                        echo $pid;
                        die;
                }
			
                elseif($obj == "OBj")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "get_paiment_transid")
                {
                        $transid = isset($_POST['transID']) ? $_POST['transID'] : "";
                        
                        $paiement = $this->encaissement_model->get_paiement_by_transactionid($transid);

                        if (!empty($paiement))
                        {
                                echo '405';
                        }
                        else
                        {
                                echo '200';
                        } 
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
		public function save_ipaddress()
		{
                        $description = array('Detail'=> '3 tentatives de consultation de passport echouées');
                        
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = '46';
                        $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];
                        $data['Sessionid_8'] = $this->session->session_id;
                        $data['Observation_9'] = json_encode($description);

                        $this->logiref_model->save_ipaddress($data, NULL);
		}
}
/* End of file welcome.php  */
/* Location: /project/activities  */
