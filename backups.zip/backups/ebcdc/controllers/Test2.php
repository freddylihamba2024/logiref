<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test2 extends MY_Controller {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
               
	} 
	
        
	public function index()
	{
//                $data = array();
//                
//                $url = 'https://logiref.tax/api/endpoints/logirad/check.note.php';
//                $this->load->library('curl');
//                $this->curl->create($url);
//                $this->curl->option('SSL_VERIFYPEER',0);
//                $this->curl->option('SSL_VERIFYHOST',0);
//                $this->curl->post($data);
//                $response = $this->curl->execute();
//                var_dump($response); die;
                $url = 'https://logiref.tax/api/endpoints/logirad/checknote.php';
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => ''
                        ),
                        'ssl'=>array(
                            'cafile'=>'/home/LOGIREFSSL/TESTlogiref.pem',
                            'verify_peer'=>true,
                            'verify_peer_name'=>true,
                        )

                );
                
                $context  = stream_context_create( $options );
                $return = file_get_contents( $url, false, $context );
                
                var_dump($return); die;
                //return trim($response);
		
	}
    
}

/* End of file welcome.php  */
/* Location: /project/activities  */

