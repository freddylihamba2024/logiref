<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Branches extends MY_Controller {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('guichets','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'branches';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('main/main_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model('logiref/logiref_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'branches';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "guichets")
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['agenceprincipale'] = $this->branches_model->get_dropdown('agence_principale');
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['guichets'] = $this->branches_model->get_guichets("Guichet");
                            
                        }
                        else
                        {
                            $this->data['guichets'] = $this->branches_model->get_guichets();

                        }
                        
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/guichets', $this->data);
                }
                elseif($obj == "guichet") 
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['provinces'] = $this->logiref_model->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['guichet'] = $this->branches_model->get_guichet_info($id);
                        $this->data['from'] = $arg;
						$this->data['agenceprincipale'] = $this->branches_model->get_dropdown('agence_principale');
                        
                        #var_dump($this->data['guichet']);die;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_guichet', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
				if($obj == "guichet")
                {
                        $data=$_POST;
                        if($data['Nom_4']=='0' || $data['Nom_4']==''  || $data['Code_10']==''  || $data['Province_6']=='' || $data['Adresse_8']==''  || $data['Agence_5']=='' || $data['Agence_principale_14']==''):
                                echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;

                        
                        if($_POST['Id_0']=='0' || $_POST['Id_0']=='')
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Makerid_13']=$this->session->userdata('user_id');
                                
                                // checks if the code entered has already been used 
                                $guichet = $this->branches_model->get_code_exists($data['Code_10']);
                                if(!empty($guichet))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une agence bancaire cr&eacute;&eacute;&eacute; avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $branche = $this->branches_model->get_guichet_info($data['Id_0']);
                                if($branche->Code_10 !== $data['Code_10'])
                                {
                                        //checks if the code entered has already been used 
                                        $guichet = $this->branches_model->get_code_exists($data['Code_10']);
                                        if(!empty($guichet))
                                        {
                                                echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une agence bancaire cr&eacute;&eacute;&eacute; avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                }
                        }
                        
                        if($_SESSION['Logiref_role']==1):
                                $data['Validation_12']='0000-00-00';
                                $data['Checkerid_11']=0;
                        else:
                                $data['Validation_12']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11']=$this->session->userdata('user_id');
                        endif;    
                       
                        #Database
                        $cid = $this->branches_model->save_branche($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */