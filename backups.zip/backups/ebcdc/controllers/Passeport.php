<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Passeport extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $role = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'passeports';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/passeport_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'notes';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissement_model->documents;
                $this->data['devises'] = $this->encaissement_model->devises;
                $this->data['modes'] = $this->encaissement_model->modes;
                $this->data['moyens'] = $this->encaissement_model->moyens;
                $this->data['infos'] = $this->encaissement_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                $this->role = $_SESSION['Logiref_role'];
                $this->branch = $_SESSION['Logiref_guichet'];
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "passport")
                {
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");

                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['step'] = 1;

                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif ($obj == "verification") 
                {
                        $data = $_POST;
                        $data['Reference_8'] = strtoupper($data['Reference_8']);

                        # Récupération des données locales
                        $integrations = $this->integration_model->get_note_by_ref($data['Reference_8']);

                        $result = $this->passeport_model->check_existing_payments($integrations, $data);

                        $code         = $result['code'];
                        $html         = $result['html'];
                        $checked      = $result['checked'];
                        $encaissement = $result['encaissement'] ?? null;

                        # Si aucun résultat local → appel CURL externe
                        if (isset($code) && $code =="E200") 
                        {
                                $code = $this->curl_model->call_dgrad_notes_passport($data);
							
                        }

                        # Gestion des codes d'erreur
                        if ($this->data('handle_error_codes', $code, $data))
                        {
                                echo json_encode(['code' => $code, 'message' => $html ?? null]);
                                die;
                        }

                        # Succès : récupération de la note via integration_logirad
                        $note = $this->integration_model->get_paiement_logirad($code);

                        if (!isset($note->Id_0)) 
                        {
                                echo json_encode(['code' => 'E406', 'message' => 'Un problème est survenu. Merci de réessayer plus tard.']);
                                return;
                        }

                        # Préparation des données
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGRAD", NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes', "DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
						
                        if ($checked) 
                        {
								# Ici il s'agit des cas des paiements initiE en ligne
								# Que les operateurs poursuivent en agence
                                $pid = $encaissement->Id_0;
                                $this->data['encaissement'] = $this->encaissement_model->get_paiement_info($pid);
								$this->data['encaissement']->Makerid_9 = $this->session->userdata("user_id");
								$this->data['encaissement']->Notedate_27 = $note->Dateordonance_13;
								$this->data['encaissement']->Type_57 = '';
								$this->data['encaissement']->Commission_23 = '';
								
								
								$noteref_logirad = json_decode($note->Notereference_23, true);
								
								
								$note_result = json_decode($note->Result_8);
								$email = isset($note_result->logiradData->detailAssujetti->email) ? $note_result->logiradData->detailAssujetti->email : "";
								$phone = isset($note_result->logiradData->detailAssujetti->telephone) ? $note_result->logiradData->detailAssujetti->telephone : "";
								
								
								$notereference = array(
									'standard' => $note->Article_12,
									'totalDevise' => $note->Devise_18,
									'accountname' => '',
									'QuotasTresor' => isset($noteref_logirad['tresorPublic']) ? $noteref_logirad['tresorPublic'] : '',
									'QuotasComite' => isset($noteref_logirad['comite']) ? $noteref_logirad['comite']:'',
									'QuotasPrestataire' => isset($noteref_logirad['prestataire']) ? $noteref_logirad['prestataire']:'',
									'QuotasService' => isset($noteref_logirad['service']) ? $noteref_logirad['service']:'',
									'Email' => $email,
									'Phone' => $phone
								);
								
								$this->data['encaissement']->Notereference_30 = json_encode($notereference); 
								
								$this->data['note_id'] = $code;
								$this->data['note']    = $note;
								$this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
								$this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
								$this->data['view'] = '';

								$htmlView = $this->load->view($this->module.'/'.$this->group.'/passeports/_passport_3', $this->data, true);
								echo json_encode(['code' => 'SUCCESS', 'html' => $htmlView]);
                        } 
                        else 
                        {
                                $this->data['encaissement'] = $this->data_model->logirad_migrate_note($code);
								
								$this->data['note_id'] = $code;
								$this->data['note']    = $note;

								$htmlView = $this->load->view($this->module.'/'.$this->group.'/passeports/_passport_2', $this->data, true);
								echo json_encode(['code' => 'SUCCESS', 'html' => $htmlView]);
                        }
                }
                elseif($obj == "edit")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->passeport_model->get_paiement_info($id);
                       
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_passport_3', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->passeport_model->get_paiement_info($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_passport_3', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                //Nouvel enregistrement
                //Tables concernées: tresor, integration
                if($obj == 'initiation')
                {
                        if( !empty($_POST) && ($_POST['Id_0'] == NULL || $_POST['Id_0'] == "") && ($this->role == 4 || $this->role == 9))//Conditions maker nouveau
                        {   
                                //Récupération des données
                                $error_code = 0;
								
								$return_check_paiement=$this->passeport_model->check_paiement_by_reference($_POST['Noteid_26']);
								
								if(isset($return_check_paiement['code']) && $return_check_paiement['code']!="E200")
								{
										$data=array();
										$data['Id_0']=$return_check_paiement['id'];
								}
								else
								{
										$return = $this->passeport_model->get_data_passeport(); 

										if(isset($return['code']) && $return['code'] == 200)
										{
												//Formattage des données
												$data  = $return['data'];
												$return = $this->passeport_model->get_formatage_data_passeport($data);

												if(isset($return['code']) && $return['code'] == 200)
												{
														//Traitements spécifiques
														//Comptabilisation
														$data  = $return['data'];
														$agence = $this->branch;
														$agence_dst=NULL;
														$list = NULL;

														$case = $this->comptabilisation_model->get_use_case($data);
														$comptes = $this->accounts_model->get_comptes_array($list, $agence, $agence_dst);

														$date_emission = isset($data['Notedate_27']) ? $data['Notedate_27'] : "";
														$taxe_cpi = $data['Typerecette_17'];

														$debit_mad_instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRAD", NULL, NULL, $date_emission, $taxe_cpi);
														$debit_sequestre_instructions = $this->comptabilisation_model->get_instructions_dgrad_passport($data, $comptes,'DGRAD', $date_emission);


														//Enregistrement base de données
														$data['Id_0'] = $this->passeport_model->save_paiement_tresor($data);

														if($data['Id_0'] > 0)
														{
																$first_instruction= $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'],0);

																if($first_instruction)
																{
																		$second_instructions = $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

																		if($second_instructions == false)
																		{
																				// breakdown instructions not saved
																				$error_code = '403';
																				$error_description = 'Paiement enregistr&eacute; partiellement';
																		}
																}
																else
																{
																		// first instruction not saved
																		$error_code = '402';
																		$error_description = 'Paiement enregistr&eacute; partiellement';
																}
														}
														else 
														{
																// paiement not saved in the database
																$error_code = '401';
																$error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
														}
												}
												else
												{
														$error_code = $return['code'];
														$error_description = $return['message'];
												}
										}
										else
										{
												$error_code = $return['code'];
												$error_description = $return['message'];
										}
								}
								
                                

                                //Return utilisateurs
                                if($error_code != 0)
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $data['Id_0'];
                                        $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                }

                                echo json_encode($data_return);
                        }
                        else
                        {
                                $data_return['code'] = 403;
                                $data_return['id'] = '';
                                $data_return['message'] = 'Vous n\'avez pas les droits d\'initier un paiement, veuillez contacter l\'op&eacute;rateur qui encaisse le paiement.';
                                echo json_encode($data_return);
                        }
                }
                //Modification enregistrement
                //Tables concernées: propres, integration
                if($obj == "update")
                {
                        if( !empty($_POST) && $_POST['Id_0'] > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                        {   
                                //Récupération des données
                                $error_code = 0;
                                $return = $this->passeport_model->get_data_passeport(); 

                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        //Formattage des données
                                        $data  = $return['data'];
                                        $return = $this->passeport_model->get_formatage_data_passeport($data);

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Traitements spécifiques
                                                //Comptabilisation
                                                $data  = $return['data'];
                                                $agence = $this->branch;
                                                $agence_dst=NULL;
                                                $list = NULL;

                                                $case = $this->comptabilisation_model->get_use_case($data);
                                                $comptes = $this->accounts_model->get_comptes_array($list, $agence, $agence_dst);

                                                $date_emission = isset($data['Notedate_27']) ? $data['Notedate_27'] : "";
                                                $taxe_cpi = $data['Typerecette_17'];

                                                $debit_mad_instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGRAD", NULL, NULL, $date_emission, $taxe_cpi);
                                                $debit_sequestre_instructions = $this->comptabilisation_model->get_instructions_dgrad_passport($data, $comptes,'DGRAD', $date_emission);


                                                //Enregistrement base de données
                                                $data['Id_0'] = $this->passeport_model->update_payment_tresor($data, $data['Id_0']);

                                                if($data['Id_0'] > 0)
                                                {
                                                        //Delete former instructions
                                                        $this->comptabilisation_model->delete_instructions_dgrad_passeport($data['Id_0']);
                                                        
                                                        $first_instruction= $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'],0);

                                                        if($first_instruction)
                                                        {
                                                                $second_instructions = $this->comptabilisation_model->save_instructions_dgrad($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                if($second_instructions == false)
                                                                {
                                                                        // breakdown instructions not saved
                                                                        $error_code = '403';
                                                                        $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                }
                                                        }
                                                        else
                                                        {
                                                                // first instruction not saved
                                                                $error_code = '402';
                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                        }
                                                }
                                                else 
                                                {
                                                        // paiement not saved in the database
                                                        $error_code = '401';
                                                        $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }
                                }
                                else
                                {
                                        $error_code = $return['code'];
                                        $error_description = $return['message'];
                                }

                                //Return utilisateurs
                                if($error_code != 0)
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $data['Id_0'];
                                        $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                }

                                echo json_encode($data_return);
                        }
                        else
                        {
                                $data_return['code'] = 403;
                                $data_return['id'] = '';
                                $data_return['message'] = 'Vous n\'avez pas les droits de modifier ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                echo json_encode($data_return);
                        }
                }
                //Validation
                //Tables concernées: propres, integration
                elseif($obj == "validation")//Conditions maker pour modification
                {
                        if($id > 0 && ($this->role == 2 || $this->role == 3))//Conditions maker pour modification
                        { 
                                $error_code = 0;
                                //Formattage des données
                                $return = $this->passeport_model->get_data_validation_passport($id);

                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        //Traitements spécifiques
                                        
                                        // Mise à jour du statut de paiement en statut regularisation
                                        // Pour la premiere sequence
                                        
                                        $this->passeport_model->update_payment_validation($id, 5);
                                        
                                        $data = $return['data']['firstTrans'];
                                        
                                        $response = $this->curl_model->call_bank_virement_passport($data);
                                        
                                        $result = json_decode($response, true);
                                        
                                        if(isset($result['response']) && $result['response'] == 200)
                                        {
                                                // Mise à jour du statut de paiement en statut en cours
                                                // Pour la deuxieme sequence
                                                $this->passeport_model->update_payment_validation($id, 6);
                                                
                                                $data = $return['data']['secondTrans'];
                                                
                                                $response = $this->curl_model->call_bank_virement_passport($data);
                                                
                                                $result = json_decode($response, true);
                                                
                                                if(isset($result['response']) && $result['response'] == 200)
                                                {
                                                        // Mise à jour du statut de paiement en statut en cours
                                                        // Pour la confirmation dans Logirad
                                                        $this->passeport_model->update_payment_validation($id, 7);
                                                        //Formattage des données pour la confirmation dans Logirad
                                                        $return = $this->passeport_model->get_data_confirmation_passport();
                                                        
                                                        if(isset($return['code']) && $return['code'] == 200)
                                                        {   
                                                                $apidata = $return['data'];
                                                                $response = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);
															
                                                                if($response == "E200" || $response == "CP200")
                                                                {
                                                                        // Mise à jour du statut de paiement en statut validE et confirmE
                                                                        $this->passeport_model->update_payment_validation($id, 2);
																		$error_description = "Paiement valid&eacute; dans Finacle et confirm&eacute; avec succès dans Logirad.";
                                                                }
                                                                else
                                                                {
                                                                        $error_code = $response;
                                                                        $error_description = "Paiement valid&eacute; dans Finacle, Mais la confirmation n'a pas abouti dans Logirad.";
                                                                }
                                                        }
                                                        else 
                                                        {
                                                                $error_code = $return['code'];
                                                                $error_description = $return['message'];
                                                        }
                                                }
                                                else
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->integration_model->update_integration_dgrad_attempts($id, 1);
                                                        
                                                        $error_code = $result['response'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integration_model->update_integration_dgrad_attempts($id, 0);
                                                
                                                
                                                $error_code = $result['response'];
                                                $error_description = 'Paiement non valid&eacute;, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }
                                }
                                else
                                {
                                        $error_code = $return['code'];
                                        $error_description = 'Paiement non valid&eacute;, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                }

                                //Return utilisateurs 
                                if($error_code != 0 || $error_code != "0")
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $data['Id_0'];
                                        $data_return['message'] = $error_description;
                                }

                                echo json_encode($data_return);
                        } 
                        else
                        {
                                $data_return['code'] = 403;
                                $data_return['id'] = '';
                                $data_return['message'] = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                                echo json_encode($data_return);
                        }
                }
                
                //Suppression
                //Tables concernées: propres, integration
                elseif($obj == "deletion")//Conditions maker pour modification
                {
                        if($id > 0 && ($this->role == 3 || $this->role == 4 || $this->role == 9))//Conditions maker pour modification
                        {
                                $error_code = 0;
                                //Récupération des données
                                $return = $this->passeport_model->get_data_deletion_passport();

                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        $data = $return['data'];
                                        // Mise à jour du statut de paiement en statut en supprimé
                                        $pid = $this->encaissement_model->update_payment_tresor($data, $id);
                                        
                                        //Traitements spécifiques
                                        if($pid == 0)
                                        {
                                                $error_code = 404;
                                                $error_description = 'Paiement non supprim&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                        }
                                }
                                else
                                {
                                        $error_code = $return['code'];
                                        $error_description = $return['message'];
                                }

                                //Return utilisateurs
                                if($error_code != 0)
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $id;
                                        $data_return['message'] = 'Bravo ! paiement suppri&eacute; avec succ&egrave;s.';
                                }

                                echo json_encode($data_return);
                        }
                        else
                        {
                                $data_return['code'] = 403;
                                $data_return['id'] = '';
                                $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                echo json_encode($data_return);
                        }

                }
                
                //Arret du script
                //Tables concernées: propres, integration
                else
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "get_paiment_transid")
                {
                        $transid = isset($_POST['transID']) ? $_POST['transID'] : "";
                        
                        $paiement = $this->encaissement_model->get_paiement_by_transactionid($transid);

                        if (!empty($paiement))
                        {
                                echo '405';
                        }
                        else
                        {
                                echo '200';
                        } 
                }
                elseif($obj == "handle_error_codes")
                {
                        $error_codes = ["E604", "E000", "E002", "E22", "E404", "E405", "E503", "E504", "E505", "E506","E507", "E508", "E509","E999", "401", "402", "500"];

                        $code = $data;
                        if (!in_array($code, $error_codes)) 
                        {
                                return false;
                        }

                        if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600" && $code == "E404") 
                        {
                                $_SESSION['login_info']['ip']['attempts']++;
                                if ($_SESSION['login_info']['ip']['attempts'] >= 3) 
                                {
                                        $this->save_ipaddress();
                                        echo json_encode(['code' => 'LOCKOUT', 'message' => 'Nombre maximum de tentatives dépassé.']);
                                        die;
                                }
                        } 
                        else 
                        {
                                $_SESSION['login_info']['ip']['attempts'] = 0;
                        }
                        return true;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        public function save_ipaddress()
        {
                $description = array('Detail'=> '3 tentatives de consultation de passport echouées');

                $data['Status_2'] = 1;
                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                $data['Account_3'] = '46';
                $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];
                $data['Sessionid_8'] = $this->session->session_id;
                $data['Observation_9'] = json_encode($description);

                $this->logiref_model->save_ipaddress($data, NULL);
        }
}
/* End of file welcome.php  */
/* Location: /project/activities  */
