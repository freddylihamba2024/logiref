﻿<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Equalize extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Dimitri on the 11.03.2021
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('unequalized','unequalizedpassports');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'ebcdc';
        public $folder = 'equalize';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                
                $this->load->model($this->module.'/reports_model');
                $this->load->model($this->module.'/fees_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/prepayments_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/passeport_model');
                $this->load->model('logiref/stakeholders_model');
                
                
                
                $this->load->model('main/main_model');
                
                $this->folder = 'equalize';
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'equalize';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->role = $_SESSION['Logiref_role'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "unequalized") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_paiements_to_regulate();
                        $this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate();
                        $this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls_to_regulate();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
		elseif($obj == "unequalizedpassports") 
                {
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reports_model->get_paiements_passports_to_regulate();
                        //$this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate();
                        //$this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls_to_regulate();
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
			$this->data['users'] = $this->main_model->get_dropdown('users_array');

                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "declaration")
                {
                    
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        
                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";
                        
                        $succes = array();
                        
                        $instructions  = $this->comptabilisation_model->get_instructions_dgi($logirefid);
                        foreach($instructions as $value):
                           $succes[] = $value->Status_2; 
                        endforeach;

                        if(!in_array('3', $succes) && !in_array('1', $succes))  
                        {
                                $this->data['validate'] = '';
                        }
                        else 
                        {
                                $this->data['validate'] = 'disabled';
                        }
                        
                        if(!in_array('2', $succes))  
                        {
                                $this->data['delete'] = '';
                        }
                        else 
                        {
                                $this->data['delete'] = 'disabled';
                        }
                        
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "note")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        
                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";
                        
                        $succes = array();
                        
                        $instructions  = $this->comptabilisation_model->get_instructions_dgrad($logirefid);
                        foreach($instructions as $value):
                           $succes[] = $value->Status_2; 
                        endforeach;

                        if(!in_array('3', $succes) && !in_array('1', $succes))  
                        {
                                $this->data['validate'] = '';
                        }
                        else 
                        {
                                $this->data['validate'] = 'disabled';
                        }
                        
                        if(!in_array('2', $succes))  
                        {
                                $this->data['delete'] = '';
                        }
                        else 
                        {
                                $this->data['delete'] = 'disabled';
                        }
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "passeport")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        
                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";
                        
                        $succes = array();
                        
                        $instructions  = $this->comptabilisation_model->get_instructions_dgrad($logirefid);
                        foreach($instructions as $value):
                           $succes[] = $value->Status_2; 
                        endforeach;

                        if(!in_array('3', $succes) && !in_array('1', $succes))  
                        {
                                $this->data['validate'] = '';
                        }
                        else 
                        {
                                $this->data['validate'] = 'disabled';
                        }
                        
                        if(!in_array('2', $succes))  
                        {
                                $this->data['delete'] = '';
                        }
                        else 
                        {
                                $this->data['delete'] = 'disabled';
                        }
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "bulletin")
                {
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "prepayment")
                {
                        $bl = $id;
                        $bulletin = $this->integration_model->get_prepaiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_prepayment($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                }
                if($obj == "get_details")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisation_model->get_instructions($ref);
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_details_dgda', $this->data);
                }
                elseif($obj == "get_details_dgi") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisation_model->get_instructions_dgi($ref);
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_details_dgi', $this->data);
                }
                elseif($obj == "get_details_dgrad") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisation_model->get_instructions_dgrad($ref);
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_details_dgrad', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->folder . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "verify_declaration")
                {
                        $data['Id_0'] = $_POST['Id_0'];
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Beneficaire_15'] = $_POST['Beneficaire_15'];
                        
                        //$this->save('regularisation', $id, $_POST['action']);
                        $response =  $this->curl_model->call_bank_virement($data);

                        $result = json_decode($response, true);

                        $reverse = array();
                        $reverse['validate'] = false;

                        if($result['response'] == '200')
                        {
                                $data = array();
                                $data['Status_2'] = 2;
                                $data['Checkerid_17'] = $this->session->userdata("user_id");
                                $pid = $this->comptabilisation_model->update_instructions_cbs_dgda($id, $data);
                                
                                $reverse['response'] = "E200";
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $reverse['response'] = "E".$result['response'];
                        }

                        echo json_encode($reverse);
                        die;
                }
                elseif($obj == "verify_note")
                {
                        $data['Id_0'] = $_POST['Id_0'];
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Beneficaire_15'] = $_POST['Beneficaire_15'];
                        
                        //$this->save('regularisation', $id, $_POST['action']);
                        $response =  $this->curl_model->call_bank_virement($data);

                        $result = json_decode($response, true);

                        $reverse = array();
                        $reverse['validate'] = false;

                        if($result['response'] == '200')
                        {
                                $data = array();
                                $data['Status_2'] = 2;
                                $data['Checkerid_17'] = $this->session->userdata("user_id");
                                $pid = $this->comptabilisation_model->update_instructions_cbs_dgda($id, $data);
                                
                                $reverse['response'] = "E200";
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $reverse['response'] = "E".$result['response'];
                        }

                        echo json_encode($reverse);
                        die;
                }
                elseif($obj == "verify_bulletin")
                {
                        $data['Priority'] = 1;
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Beneficaire_15'] = $_POST['Beneficaire_15'];
                        $data['Sydonia_44'] = $paiementid = $_POST['Sydonia_44'];
                        
                        $response =  $this->curl_model->call_bank_regularization($data);
                        
                        $result = json_decode($response, true);

                        $reverse = array();

                        if($result['response'] == '200')
                        {
                                $reverse['response'] = "E200";
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $reverse['response'] = $result['response'];
                        }
                                
                        echo json_encode($reverse);
                        die;
                }
                elseif($obj == "prepayment")
                {
                        $data['Priority'] = 1;
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['Sydonia_44'] = $paiementid = $_POST['paiementid'];
                        
                        //$this->save('regularisation', $id, $_POST['action']);
                        $response =  $this->curl_model->call_bank_virement($data);

                        $result = json_decode($response, true);

                        $reverse = array();
                        $reverse['validate'] = false;

                        if($result['response'] == '200')
                        {
                                $data = array();
                                $data['Status_2'] = 2;
                                $data['Checkerid_17'] = $this->session->userdata("user_id");
                                $pid = $this->comptabilisation_model->update_instructions_cbs_dgda($id, $data);
                                
                                $reverse['response'] = "E200";
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $reverse['response'] = "E".$result['response'];
                        }

                        echo json_encode($reverse);
                        die;
                }
                elseif($obj == "save_declaration")
                {
                        $data = array();
                        $data['Status_2'] = 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                        $pid =  $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        if($pid) echo $id;
                        else echo "E002";
                }
                elseif($obj == "validate_declaration")
                {
                        #Invocation of the api transfer
                        $data = $_POST;
                        $infos = $data['Infos'];
                        
                        $data['Notereference_30'] = json_encode($infos);
                        
                        $response = $this->curl_model->call_bank_virement($data);
                        
                        $return = json_decode($response, true);

                        if(isset($return['response']) && $return['response'] =='200')
                        {
                                $result = json_decode($data['Notereference_30'], true);

                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";

                                $logirefid = $data['Logirefid_4'];

                                // Pour eviter la modification du paiment par le validateur 
                                $data = array();
                                $data['Notereference_30'] = json_encode($result);
                                $data['Id_0'] = $id;
                                $data['Logirefid_4'] = $logirefid;
                                $data['Status_2'] = 1;
                                $data['Checkerid_10'] = $this->session->userdata("user_id");
                                $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                        }
                        elseif(isset($return['response']) && $return['response'] != "")
                        {
                                echo $return['response'];
                                die;
                        }
                        else
                        {
                                echo 'E411';
                                die;
                        }
                        
                        # Save changes
                        $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        
                        echo $data['Id_0'];
                        die;
                }
                elseif($obj == "save_note")
                {
                        $data = array();
                        $data['Status_2'] = (isset($data['Typerecette_17']) && $data['Typerecette_17']=="27421600") ? 2: 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                        $pid =  $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        if($pid) echo $id;
                        else echo "E002";
                }
 		elseif($obj == "save_passport")
                {
                        $data = array();
                        $data['Status_2'] =  2;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                        $pid =  $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        if($pid) echo $id;
                        else echo "E002";
                }
		elseif($obj == "validate_note")
                {
                        $data_to_update = array();

                        #Invocation of the api transfer
                        $data = $_POST;
                        $infos = $data['Infos'];

                        $data['Notereference_30'] = json_encode($infos);

                        if (isset($data['Typerecette_17']) && $data['Typerecette_17']=="27421600")
                        {
                                if (isset($data['Trans']) && $data['Trans'] == 'firstTrans')
                                {
                                        $data['Priority_27'] = 0;

                                        $response1 = $this->curl_model->call_bank_virement_passport($data);
                                        $return1 = json_decode($response1, true);

                                        if (isset($return1['response']) && $return1['response'] == '200') 
                                        {
                                                $logirefid = $data['Logirefid_4'];
                                                
                                                $data_to_update1 = array();
                                                
                                                $data_to_update1['Status_2'] = 6;
                                                $data_to_update1['Checkerid_10'] = $this->session->userdata("user_id");
                                                $data_to_update1['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                                
                                                # Save changes
                                                $this->encaissement_model->update_payment_tresor_by_ref($data_to_update1, $_POST['Logirefid_4']);

                                                $data['Trans'] = 'secondTrans';
                                                $data['Priority_27'] = 1;

                                                $response = $this->curl_model->call_bank_virement_passport($data);

                                                unset($data['Trans']);
                                        }
                                        else
                                        {
                                                $response = $response1;
                                        }
                                }

                                if (isset($data['Trans']) && $data['Trans'] == 'secondTrans')
                                {
                                        $data['Trans'] = 'secondTrans';
                                        $data['Priority_27'] = 1;

                                        $response = $this->curl_model->call_bank_virement_passport($data);
                                }

                                if(isset($data['Trans'])) unset($data['Trans']);
                                if(isset($data['Priority_27'])) unset($data['Priority_27']);
                        }
                        else
                        {
                                $response = $this->curl_model->call_bank_virement($data);
                        }
                        
                        $return = json_decode($response, true);
                        
                        if(isset($return['response']) && $return['response'] =='200')
                        {
                                $result = json_decode($data['Notereference_30'], true);
                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";

                                $logirefid = $data['Logirefid_4'];
                                $data_to_update['Logirefid_4'] = $logirefid;
                                                                                        
                                #Call  the api to confirm a note passport
                                if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] == "27421600")
                                {
                                        $data_to_update2 = array();

                                        $data_to_update2['Status_2'] = 7;
                                        $data_to_update2['Checkerid_10'] = $this->session->userdata("user_id");
                                        $data_to_update2['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                        # Save changes
                                        $this->encaissement_model->update_payment_tresor_by_ref($data_to_update2, $_POST['Logirefid_4']);

                                        $apidata = array();

                                        $guichets = $this->branches_model->get_dropdown("guichets");
                                        $code_agences = $this->branches_model->get_dropdown("codeagences");

                                        $apidata['codeAgence'] = isset($code_agences[$_SESSION['Logiref_guichet']]) ? $code_agences[$_SESSION['Logiref_guichet']]: "";
                                        $apidata['agence'] = isset($guichets[$_SESSION['Logiref_guichet']]) ? $guichets[$_SESSION['Logiref_guichet']] : "";
                                        $apidata['Noteid_26'] = isset($_POST['Noteid_26']) ? $_POST['Noteid_26'] : "";
                                        $apidata['Reference_32'] = isset($_POST['Reference_32'])?$_POST['Reference_32']:"";

                                        $apidata['Montant_11'] = isset($_POST['Montant_11'])?$_POST['Montant_11']:"0";
                                        $apidata['Montant_11'] = str_replace(' ','',$apidata['Montant_11']);
                                        $apidata['Montant_11'] = str_replace(',','.',$apidata['Montant_11']);

                                        $apidata['Devise_12'] = isset($_POST['Devise_12'])? $_POST['Devise_12']:"";
                                        $apidata['Taux_41'] = isset($_POST['Taux_41'])? $_POST['Taux_41']:"";

                                        $return_logirad = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);

                                        if($return_logirad == "CP604" || $return_logirad == "CP000" || $return_logirad=="CP001" || $return_logirad=="CP002" || $return_logirad == "CP22"  || $return_logirad == "CP404" || $return_logirad == "CP200")
                                        {
                                                echo $return_logirad;
                                                die;
                                        }
                                        else
                                        {
                                                $data_to_update['Status_2'] = 2;
                                                $data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
                                                $data_to_update['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                                $data_to_update['Logirad_53'] = $return_logirad;
                                        }
                                }
                                else
                                {
                                        $data_to_update['Status_2'] = 1;
                                        $data_to_update['Checkerid_10'] = $this->session->userdata("user_id");
                                        $data_to_update['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                }
                                
                        }
                        elseif(isset($return['response']) && $return['response'] != "")
                        {
                                echo $return['response'];
                                die;
                        }
                        else
                        {
                                echo 'E411';
                                die;
                        }
                        
                        # Save changes
                        $this->encaissement_model->update_payment_tresor_by_ref($data_to_update, $data['Logirefid_4']);
                        
                        echo $data['Id_0'];
                        die;
                }
                elseif ($obj == "validate_passeport") 
                {
                        if ($id > 0 && ($this->role == 2 || $this->role == 3)) 
                        {
                                $return = $this->passeport_model->get_data_validation_passport($id);

                                if (isset($return['code']) && $return['code'] == 200) 
                                {
                                        $transaction = array_keys($return['data']);

                                        if (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[0]) 
                                        {
                                                # Cas 1 : première transaction
                                                $data = $return['data'];
                                                $data_return = $this->data('get_first_transaction', $data, $id);
                                        }
                                        elseif (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[1]) 
                                        {
                                                # Cas 2 : deuxième transaction
                                                $data = $return['data']['secondTrans'];
                                                $data_return = $this->data('get_second_transaction', $data, $id, $return['data']);
                                        }
                                        else 
                                        {
                                                $data_return = [
                                                        'code' => 400,
                                                        'id' => '',
                                                        'message' => 'Transaction invalide ou manquante.'
                                                ];
                                        }
                                } 
                                else 
                                {
                                        $data_return = [
                                                'code' => $return['code'],
                                                'id' => '',
                                                'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        } 
                        else 
                        {
                                $data_return = [
                                        'code' => 403,
                                        'id' => '',
                                        'message' => 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.'
                                ];
                        }

                        echo json_encode($data_return);
                }
                elseif($obj == "confirm_note")
                {
                        if ($id > 0) 
                        {
                                # On appelle directement la confirmation via la méthode data()
                                $return = $this->data('get_confirmation', null, $id);
                                echo json_encode($return);
                        } 
                        else 
                        {
                                echo json_encode([
                                        'code' => 400,
                                        'id' => '',
                                        'message' => 'Identifiant de paiement manquant ou invalide.'
                                ]);
                        }
                }

                elseif($obj == "save_bulletin")
                {
                        $bl_data['Status_2'] = '3';
                        $bl = $this->integration_model->update_bulletin($bl_data, $id);
                        
                        if($bl) echo $bl;
                        else echo "E002";
                }
                elseif($obj == "validate_bulletin")
                {
                        $data['Priority'] = 1;
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Beneficaire_15'] = $_POST['Beneficaire_15'];
                        $data['Sydonia_44'] = $paiementid = $_POST['Sydonia_44'];
                        
                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                        
                        $response =  $this->curl_model->call_bank_virement($data);
                        
                        $result = json_decode($response, true);

                        $return = array();

                        if($result['response'] == '200')
                        {
                                $bl_data['Status_2'] = '3';
                                $bl =  $this->integration_model->update_bulletin($bl_data, $paiementid);
                                $return['response'] = "200";
                                $return['id'] = $paiementid;
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $return['response'] = $result['response'];
                        }
                                
                        echo json_encode($return);
                        die;
                }
                elseif($obj == "validate_prepayment")
                {
                        $data['Priority'] = 1;
                        $data['Type'] = 'prepayment';
                        $data['Sydonia_49'] = $paiementid = $_POST['Sydonia_49'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Account_3'] = $this->session->userdata('account_id');

                        $agence_src= $_SESSION['Logiref_guichet'];
                        
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                        
                        $response = $this->curl_model->call_bank_virement($data);
                                
                        $return = json_decode($response, true);
                        
                        if(isset($return['response']) && $return['response'] == "200")
                        {
                                $code = 200;

                                $paiement = $this->encaissement_model->get_prepaiement_tresor_bl($id);

                                if(isset($paiement->Notereference_30) && $paiement->Notereference_30 != "")
                                {
                                        $result = json_decode($paiement->Notereference_30, true);

                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                        $data_to_validate['Notereference_30'] = json_encode($result);
                                }

                                $data_to_validate['Status_2'] = 1;
                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');


                                # Update the paiement related to the bulletin
                                $tid = $this->encaissement_model->update_prepayment_tresor_dgda($data_to_validate, $id);
                                $pid = $this->encaissement_model->update_prepayment_propres_dgda($data_to_validate, $id);


                                $bl_data['Status_2'] = '3';
                                $bl = $this->integration_model->update_prepayement($bl_data, $paiementid);
                                
                                $return['response'] = "200";
                                $return['id'] = $paiementid;
                        }
                        elseif(isset($result['response']) && $result['response'] != "")
                        {
                                $return['response'] = $result['response'];
                        }
                        
                        echo json_encode($return);
                        die;
                }
                elseif($obj == "save_prepayment")
                {
                        $bl_data['Status_2'] = '3';
                        $bl =  $this->prepayments_model->update_prepayement($bl_data, $id);
                        
                        if($bl) echo $bl;
                        else echo "E002";
                }
                else if($obj == "delete")
                {
                        $RecetteTYPES = $this->logiref_model->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_propre($id);
                        }
                        if($pid > 0)
                        {
                                $this->comptabilisation_model->delete_instructions_dgi($id);
                        }
                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "regularisation")
                {
                        $lines = $this->integration_model->get_instructions_dgda_by_id($id);
                        $action = $arg;
                        
                        if(!empty($lines))
                        {
                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');
                                
                                $data['Paiementid_4']=$lines->Paiementid_4;
                                $data['Agence_6']=$lines->Agence_6;
                                $data['Guichet_7']=$lines->Guichet_7;
                                $data['Operation_8']=$lines->Operation_8;
                                $data['Compte_9']=$lines->Compte_9;
                                $data['Montant_10']=$lines->Montant_10;
                                $data['Devise_11']=$lines->Devise_11;
                                $data['Libelle_12']=$lines->Libelle_12;
                                $data['Compte_13']=$lines->Compte_13;
                                $data['Reference_14']=$lines->Reference_14;
                                $data['Mode_15']=$lines->Mode_15;
                                $data['Makerid_16']=$lines->Makerid_16;
                                $data['Checkerid_17']=$lines->Checkerid_17;
                                $data['Validation_18']=$lines->Validation_18;
                                $data['Integration_20']= gmdate('Y-m-d H:i:s');
                                if($arg == 'reverse') $data['Action_21']= 'Extourne'; else $data['Action_21'] = 'Regularisation';
                                
                                $this->integration_model->save_regularisations($data, NULL);
                        }
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        if($data !="" && $data != NULL)
                        {
                                $members = $this->users_model->get_members($data);
                        }
                        else
                        {
                                $members = $this->users_model->get_members();
                        }
                        
                        $members = $this->users_model->get_members();
                        
                        return $members;
                }
                elseif ($obj == "get_first_transaction") 
                {
                        $first_data  = $data['firstTrans'];
                        $second_data = $data['secondTrans'];
                        $id = $arg;

                        # Statut régularisation (1ère séquence)
                        $this->passeport_model->update_payment_validation($id, 5);

                        # First transaction
                        $response = $this->curl_model->call_bank_virement_passport($first_data);
                        $first_result = json_decode($response, true);
                        

                        if (isset($first_result['response']) && $first_result['response'] == 200) 
                        {
                                # Statut en cours (2ème séquence)
                                $this->passeport_model->update_payment_validation($id, 6);

                                # Second transaction
                                $response = $this->curl_model->call_bank_virement_passport($second_data);
                                $second_result = json_decode($response, true);

                                if (isset($second_result['response']) && $second_result['response'] == 200) 
                                {
                                        # Confirmation
                                        return $this->data('get_confirmation', null, $id, $data);
                                } 
                                else 
                                {
                                        $this->integration_model->update_integration_dgrad_attempts($id, 1);

                                        return [
                                                'code' => $second_result['response'] ?? 500,
                                                'id' => '',
                                                'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        } 
                        else 
                        {
                                $this->integration_model->update_integration_dgrad_attempts($id, 0);

                                return [
                                        'code' => $first_result['response'] ?? 500,
                                        'id' => '',
                                        'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                ];
                        }
                }
                elseif ($obj == "get_second_transaction") 
                {
                        $second_data = $data;
                        $id = $arg;

                        # Statut en cours (2ème séquence)
                        $this->passeport_model->update_payment_validation($id, 6);

                        # Second transaction
                        $response = $this->curl_model->call_bank_virement_passport($second_data);
                        $result = json_decode($response, true);

                        if (isset($result['response']) && $result['response'] == 200) 
                        {
                                # Confirmation
                                return $this->data('get_confirmation', null, $id);
                        } 
                        else 
                        {
                                $this->integration_model->update_integration_dgrad_attempts($id, 1);

                                return [
                                        'code' => $result['response'] ?? 500,
                                        'id' => '',
                                        'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                ];
                        }
                }
                elseif ($obj == "get_confirmation") 
                {
                        $id = $arg;
                       
                        $this->passeport_model->update_payment_validation($id, 7);

                        $return = $this->passeport_model->get_data_confirmation_passport();

                        if (isset($return['code']) && $return['code'] == 200) 
                        {
                                $apidata = $return['data'];

                                #Call api confirmation
                                $response = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);

                                if ($response == "E200" || $response == "CP200") 
                                {
                                        $this->passeport_model->update_payment_validation($id, 2);

                                        return [
                                                'code' => 200,
                                                'id' => $id ?? '',
                                                'message' => 'Paiement validé dans Finacle et confirmé avec succès dans Logirad'
                                        ];
                                } 
                                else 
                                {
                                        return [
                                                'code' => $response,
                                                'id' => $id ?? '',
                                                'message' => 'Paiement validé dans Finacle, mais la confirmation n\'a pas abouti dans Logirad.'
                                        ];
                                }
                        } 
                        else 
                        {
                                return [
                                        'code' => $return['code'],
                                        'id' => $id ?? '',
                                        'message' => $return['message']
                                ];
                        }
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */

