<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Declaration extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'declarations';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model($this->module.'/rates_model');
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'declaration';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissement_model->documents;
                $this->data['devises'] = $this->encaissement_model->devises;
                $this->data['modes'] = $this->encaissement_model->modes;
                $this->data['moyens'] = $this->encaissement_model->moyens;
                $this->data['infos'] = $this->encaissement_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 1;
                        $this->load->view($this->module.'/'.$this->group.'/declarations/_'.$obj, $this->data);
                }
                elseif($obj == "verification")
                {
                        //En attendant l'integration avec GESIMPOT et L'internet banking de la banque
                        //Cett fonction va toujours retourner NULL
                        $data = $_POST;
                        $declaration = $this->curl_model->call_dgi_declaration($data);
                        
                        if($declaration == NULL || $response==false):
                                echo 401;
                        elseif($response==true):
                        
                        else: 
                                #declaration non paye
                                if($declaration->Status_2 == "1") 
                                {
                                        $this->data['encaissement'] =  $this->integration_model->get_declaration_by_ref($declaration->Id_0);;
                                        $this->load->view($this->module.'/'.$this->group. '/declarations/_step_2', $this->data);
                                }
                                #declaration en cours de paiement / ordre de paiement en cours
                                elseif($declaration->Status_2 == "2") 
                                {
                                        echo 402;
                                }
                                #declaration deja paye
                                elseif($declaration->Status_2 == "3") 
                                {
                                        echo 403;
                                }
                        endif;
                }
                elseif($obj == "create")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['client'] = $this->logiref_model->get_clients_by_nif($_POST['Nif_17']);
                        $this->data['note_reference'] = $this->encaissement_model->get_paiement_by_reference($_POST['Reference_14']);
                        $this->data['encaissement'] = $this->encaissement_model->get_paiement_tresor_info();
                        $this->data['type_services'] =$this->logiref_model->get_dropdown("type_services");
                        $this->load->view($this->module.'/'.$this->group. '/declarations/_step_2', $this->data);
                }
                elseif($obj == "edit")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['type_services'] =$this->logiref_model->get_dropdown("type_services");
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $this->load->view($this->module.'/'.$this->group. '/declarations/_step_3', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->rates_model->get_exchange_rates();
                        $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logiref_model->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                        }
                        $this->load->view($this->module.'/'.$this->group. '/declarations/_step_3', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error! To assign a member to a group, please select both a member and a group.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {   
                                $data = array();
                                $data_id_paiement = array();

                                if(isset($_POST['Ndeclaration']))
                                {
                                        $declaration = $_POST['Ndeclaration'];
                                        unset($_POST['Ndeclaration']);
                                }

                                // Controle sur les taux d'echange a appliquer
                                if($_POST['Devise_34'] == 'CDF' && $_POST['Devise_12'] == 'USD')
                                {
                                        $data = $_POST;
                                }
                                else 
                                {
                                        $_POST['Infos']['rate_code'] = 'TTB';
                                        $data = $_POST;
                                }
                                
                                
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata('account_id');
                                if($_SESSION['Logiref_role'] ==4) $data['Makerid_9'] = $this->session->userdata('user_id');
                                $benificiaire = $data['Beneficaire_15'] = 'DGI';
                                $infos = $data['Infos'];
                                
                                // Test if the total_amount has been calculated
                                if($infos['totalMontant'] == "")
                                {
                                        $infos['totalMontant'] = $this->encaissement_model->get_montant_total($data);
                                }
                                
                                // formatage des valeurs des quotas de chaque beneficiaire pour un paiement IPRIER  
                                if($data['Typerecette_17'] == "IPRIER" && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="" && $infos['QuotasDGI'] !="")
                                {
                                        $infos['QuotasINPP'] = str_replace(' ','',$infos['QuotasINPP']);
                                        $infos['QuotasINPP'] = str_replace(',','.',$infos['QuotasINPP']);
                                        
                                        $infos['QuotasINSS'] = str_replace(' ','',$infos['QuotasINSS']);
                                        $infos['QuotasINSS'] = str_replace(',','.',$infos['QuotasINSS']);
                                        
                                        $infos['QuotasONEM'] = str_replace(' ','',$infos['QuotasONEM']);
                                        $infos['QuotasONEM'] = str_replace(',','.',$infos['QuotasONEM']);
										
                                        $infos['QuotasDGI'] = str_replace(' ','',$infos['QuotasDGI']);
                                        $infos['QuotasDGI'] = str_replace(',','.',$infos['QuotasDGI']);
                                }
                                elseif($data['Typerecette_17'] == "IPRIER" && $infos['QuotasDGI'] != "")
                                {
                                        $infos['QuotasDGI'] = str_replace(' ','',$infos['QuotasDGI']);
                                        $infos['QuotasDGI'] = str_replace(',','.',$infos['QuotasDGI']);
                                }

                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }
                                    
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                

                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                                # SAVE PAYMENT
                                # Check if it's a new payment
                                if($data['Id_0']=="" || $data['Id_0']==0)
                                {
                                        unset($data['Id_0']);
                                        $ref = $this->encaissement_model->get_id_by_reference($data['Logirefid_4']);
                                        $data['Id_0'] = $ref;
                                }

                                # Encaissement existant
                                if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                        {
                                                #Invocation of the api transfer
                                            
                                                $id = $data['Id_0'];
                                            
                                                $data_to_update['Status_2'] = 5;
                                                $this->encaissement_model->update_payment_tresor($data_to_update, $id);

                                                $response = $this->curl_model->call_bank_virement($data);
												
                                                
                                                $return = json_decode($response, true);
												
                                                if(isset($return['response']) && $return['response'] =='200')
                                                {
                                                        $result = json_decode($data['Notereference_30'], true);
                                                        
                                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                        
                                                        $logirefid = $data['Logirefid_4'];
                                                        
                                                        // Pour eviter la modification du paiment par le validateur 
                                                        $data = array();
                                                        $data['Notereference_30'] = json_encode($result);
                                                        $data['Id_0'] = $id;
                                                        $data['Logirefid_4'] = $logirefid;
                                                        $data['Status_2'] = 1;
                                                        $data['Checkerid_10'] = $this->session->userdata("user_id");
                                                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                                        
                                                }
                                                elseif(isset($return['response']) && $return['response'] != "")
                                                {
                                                        echo $return['response'];
                                                        die;
                                                }
                                                else
                                                {
                                                        echo 'E411';
                                                        die;
                                                }
                                                
                                        }
                                        else 
                                        {
                                                $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                                $this->comptabilisation_model->delete_instructions_dgi($data['Logirefid_4']);
                                        }
                                        
                                        # Save changes
                                        $this->encaissement_model->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                      
                                }
                                # Nouvel encaissement
                                else
                                {
                                        #Enregistrement
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $instructions = array();
                                        $logiref_id = $data['Logirefid_4'];
                                        if($data['Id_0'] == 0) $data['Id_0'] = NULL;

                                        $RecetteTYPES = $this->logiref_model->get_dropdown("type_recette");
                                        $rType = $RecetteTYPES[$data['Typerecette_17']];

                                        if($rType=='TRESOR' || $rType=='RFTRESD')
                                        {
                                                $pid = $this->encaissement_model->save_payment_tresor($data, $data['Id_0']);
                                        }
                                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                                        {
                                                $pid = $this->encaissement_model->save_payment_propres($data, $data['Id_0']);
                                        }
                                        $data['Id_0'] = $pid;
                                } 
                                
                                if($_SESSION['Logiref_role'] ==4)
                                {
                                        #
                                        if($data['Typerecette_17'] == "IPRIER")
                                        {
                                                $data['Montant_11'] = $infos['QuotasDGI'] ;
                                        }
                                        #Comptabilisation
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $guichet = $this->session->userdata("Logiref_guichet");
                                        
                                        $periode = isset($infos['standard']) ? $infos['standard'] : "";
                                        
                                        $agence_dst=NULL;
                                        $list = NULL;
                                        $comptes_recettes = NULL;
                                        $service_type =$this->logiref_model->get_dropdown("type_services");
                                        
                                        $service = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
                                        $recette = $data['Typerecette_17'];
                                        $case = $this->comptabilisation_model->get_use_case($data);
                                        $comptes = $this->accounts_model->get_comptes_array($list, $agence_src, $agence_dst, $data['Beneficaire_15'], $service, $recette);
                                        
                                        if($data['Beneficaire_15'] == 'DGI' && ($data['Typerecette_17'] == 'TVF' || $data['Typerecette_17'] == 'TVN' || $data['Typerecette_17'] == 'TVO'))
                                        {
                                                $agence_src= $_SESSION['Logiref_guichet'];
                                                $comptes_recettes = $this->accounts_model->get_comptes_recettes_agence_array("'CPT'", $agence_src, "DGI");
                                        }
										
                                        switch ($case)
                                        {
                                                case "case_1": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGI", $comptes_recettes, $service, $periode);
                                                        break;
                                                case "case_2": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGI", $comptes_recettes, $service, $periode);
                                                        break;
                                                case "case_3": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGI", $comptes_recettes, $service, $periode);
                                                        break;
                                                case "case_4": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGI", $comptes_recettes, $service, $periode);
                                                        break;
                                                case "case_5": 
                                                        $instructions = $this->comptabilisation_model->get_instructions_case_5($data, $comptes,"DGI", $comptes_recettes, $service, $periode);
                                                        break;
                                                default: 
                                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGI");
                                                        break;
                                        }
                                       
                                        if(!empty($instructions))
                                        {
                                                $this->comptabilisation_model->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                        }

                                        #Guichet Unique DGI - repartition
                                        if($data['Typerecette_17'] == 'IPRIER' && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="")
                                        {
                                                $instructions = $this->comptabilisation_model->get_instructions_gu_dgi($data, $comptes,'DGI', $service, $periode);
                                                $this->comptabilisation_model->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                        }
                                }
                                
                                #Return
                                echo $data['Id_0'];
                                die;
                        }
                }
                elseif($obj == "delete")
                {
                        $RecetteTYPES = $this->logiref_model->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissement_model->delete_paiement_propre($id);
                        }
                        if($pid > 0)
                        {
                                $this->comptabilisation_model->delete_instructions_dgi($id);
                        }
                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */