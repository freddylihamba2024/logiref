<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Others extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Dimitri on the 17.03.2021
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'others';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/bulletins_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/fees_model');
                $this->load->model($this->module.'/others_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'others';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->encaissement_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 0;
                        $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                       
                        $this->data['encaissement'] = $this->encaissement_model->get_paiement_tresor_info();
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1', $this->data);
                }
                elseif($obj == "verification") 
                {
                    
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_checkbl_credit($credentials);
                        $response = trim($response);
                        if($response == NULL || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000')
                        {
                            
                                if($response == 'E404')
                                {
                                        $message = " Error 404 : Sydonia not available ";
                                        //$this->curl_model->call_set_log($message, "sydonia");
                                }
                                
                                echo $response; die;
                        }
                        elseif($response == NULL )
                        {
                            
                        }
                        else
                        {
                            
                                $amount = str_replace(' ','',$_POST['Amount']);
                                $amount = str_replace(',','.',$amount);
                                $devise = $_POST['devise'];
                                $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                                $service = $_POST['Office'];
                                $agence = $_SESSION['Logiref_guichet'];
                                $mode = $_POST['Mode'];

                                $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                if($devise !='CDF')
                                {
                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        }
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                }
                                else
                                {
                                        $devise_taux = 1;
                                }

                                if(isset($_POST['Nif']))
                                {
                                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                        $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                                }


                                if(!isset($_POST['Commission']))
                                {
                                        $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                                $com['com'] = ($amount * $rules['Valeur'])/100;
                                                $com['devise'] = $devise;
                                        }
                                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }
                                        if(!empty($com) && $com['com']!=0)
                                        {
                                                if($com['devise'] !='CDF')
                                                {
                                                        $this->data['commission'] = $com['com'] * $devise_taux;
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                                else
                                                {
                                                        $this->data['commission'] = $com['com'];
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                        }
                                        else
                                        {
                                                $this->data['commission'] = $amount*0;
                                                $this->data['commission_devise'] = $devise;
                                                $this->data['total_amount'] = $amount + $this->data['commission'];
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                else 
                                {
                                        $commission = str_replace(' ','',$_POST['Commission']);
                                        $commission = str_replace(',','.',$commission);
                                        
                                        $this->data['commission'] = $commission;
                                        $this->data['commission_devise'] = $_POST['Devise_commission'];

                                        if($_POST['Devise_commission'] !="CDF")
                                        {
                                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                {
                                                        $devise_taux = $_POST['Taux'];
                                                }
                                                else
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        $devise_taux = $taux['Dollar_4'];
                                                }
                                                $commission = $this->data['commission'] * $devise_taux;
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        else
                                        {
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                
                                $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);

                                $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";

                                if($mode =='7')
                                {
                                        $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                        $this->data['disabled'] = "";
                                }
                                else 
                                {
                                        $this->data['referenceOP'] = "";
                                        $this->data['disabled'] = "disabled";
                                }

                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_details', $this->data);
                        }
                }
                elseif($obj == "confirmation") 
                {
                       
                        $taxes = array();
                        $Taxes = $_POST['taxes'];
                        $Amount = $_POST['amounts'];

                        for($i = 0; $i < count($Taxes); $i++)
                        {
                                $taxe = new stdClass();
                                $amount = str_replace(' ','',$Amount[$i]);
                                $taxe->taxeAmount = str_replace(',','.',$amount);
                                $taxe->taxeCode = $Taxes[$i];
                                $taxes[] = $taxe;
                        }
                        // All taxes
                        $_POST['Infos']['taxesPaid'] = json_encode($taxes);
                       
                        
                        $_POST['Paiementid'] = $id  = $this->save('bulletin');
                                        
                        $data['Sydonia_44'] = $id;
                        # reference of the transaction.
                        $data['Logirefid_4'] = $this->integration_model->generate_unique_reference().$this->session->userdata('user_id');
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Designation_14'] = $_POST['designation'];  
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Priority'] = 0;
                        $response = $this->curl_model->call_bank_virement($data);
                                    
                        $return = json_decode($response, true);
                       
                        if($return['response']=='200')
                        {
                                if(isset($_POST['Mode']) && $_POST['Mode'] =="5")
                                {
                                        foreach ($return as $row)
                                        {
                                                $_POST['reference'] = $row['Num_evenement'];
                                                break;
                                        }
                                }
                                
                                $user = $this->session->userdata('user_id');
                                $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                                $response = $this->curl_model->call_bank_comptant_single($credentials);
                                $response = trim($response);
                        }
                        elseif($return['response']=='300') 
                        {
                                $response = 'E300';
                        }
                        elseif($return['response']=='404') 
                        {
                                $response = 'E406';
                        }
                        elseif($return==false || $return==NULL)
                        {
                                $response = 'E412';
                        }
                        else 
                        {       
                                $response = 'E411';
                        }
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000' || $response == 'E406' || $response == 'E300' || $response == 'E411' || $response == 'E412')
                        {
                                if($response == 'E404')
                                {
                                        $message = " Error 404 : Sydonia not available ";
                                        //$this->curl_model->call_set_log($message, "sydonia");
                                }
                                echo $response; die;
                        }
                        else
                        {
                                $message = "Success : Connection to sydonia for payment confirmation was successful ";
                                //$this->curl_model->call_set_log($message, "sydonia");
                                echo $response; die;
                        }
                        
                }
                elseif($obj == "edit")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        $agence_src= $_SESSION['Logiref_guichet'];
                                
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        $info = $encaissement->Notereference_30;
                        
                        $guichet = $this->session->userdata("Logiref_guichet");
                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $instructions2 = array();

                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                        $taxes = $info['taxesPaid'];

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "preview")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "getquittance")
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        #initialisation
                        $apidata = array();
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);
                        
                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                        {
                                $quittance = $bulletin->Pdfcontent_18;
                                echo $quittance;
                        }
                        else
                        {
                                $declaration = json_decode($bulletin->Results_13);
                                $apidata['ReceiptSerial'] = $declaration->receiptSerial;
                                $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                                $apidata['ReceiptDate'] = $declaration->receiptDate;
                                $apidata['Office'] = $bulletin->Office_6;
                                $apidata['Account'] = $this->session->userdata('account_id');
                                $apidata['Paiementid'] = $bl;
                                $apidata['User'] = $this->session->userdata('user_id');
                                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                                $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                                
                                $response = $this->curl_model->call_dgda_quittance($apidata);
                                
                                if($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000")
                                {
                                        echo $response;
                                }
                                else
                                {
                                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);

                                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                                        {
                                                $quittance = $bulletin->Pdfcontent_18;
                                                echo $quittance;
                                        }
                                        else
                                        {
                                                echo "E406";
                                        }
                                }
                        }
                       
                }
                elseif($obj == "selectTaxes")
                {
                        $recettes = $this->logiref_model->get_dropdown('recettes');
                        echo form_dropdown('taxes[]', $recettes, '', 'class="form-control itemgrid iwtd" required="required" id="service"'); 
                }
                elseif($obj == "encaissement")
                {
                        $taxeCodes =  $_POST['taxes'];
                        $amounts = $_POST['amounts'];
                        $taxes = array();
                        $amount = 0;
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                        
                       
                        
                        for($i = 0; $i < count($taxeCodes); $i++):
                            
                            $taxe = new stdClass();
                            
                            $taxe->taxeCode = $taxeCodes[$i];
                            
                            $Amount = str_replace(' ','',$amounts[$i]);
                            $taxe->taxeAmount = str_replace(',','.',$Amount);
                            $taxes[] = $taxe;
                            
                            $amount = $amount + $taxe->taxeAmount;
                            
                        endfor;
                        
                        $_POST['Notemontant_28'] = $amount;
                        $_POST['Infos']['taxesPaid'] = $taxes; 
                        
                        $_POST['Infos']['quittanceid'] = $_POST['Infos']['Qserie'].$_POST['Infos']['Qnumber'];
                        $_POST['Noteid_26'] = $_POST['Infos']['serie'].$_POST['Infos']['number'];
                        
                        $_POST['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                        
                        unset($_POST['taxes']);
                        unset($_POST['amounts']);
                        
                        // save bulletin
                        $_POST['Sydonia_44'] = $id =  $this->save('bulletin');
                        
                        $_POST['Infos']['Paiementid'] = $_POST['Sydonia_44']; 
                        
                        if(isset($_POST['tva'])) $_POST['Infos']['tva'] = $_POST['tva']; 
                        if(isset($_POST['pourcompte'])) $_POST['Infos']['pourcompte'] = $_POST['pourcompte']; 
                       
                        
                        if($id > 0)
                        {
                            
                                $taxes = json_encode($taxes);
                                $_POST['Infos']['taxesPaid'] = $taxes; 
                               

                                unset($_POST['taxes']);
                                unset($_POST['amounts']);
                                unset($_POST['commission']);
                                unset($_POST['devise']);
                                unset($_POST['Paiementid']);
                                unset($_POST['account_name']);
                                unset($_POST['account_cgu']);
                                if(isset($_POST['tva'])) unset($_POST['tva']);
                                if(isset($_POST['pourcompte'])) unset($_POST['pourcompte']);

                                // save taxes payments
                                $result = $this->save('comptant');

                                if($result == 'E406')
                                {
                                        echo 'E406';
                                }
                                else
                                {
                                        echo  $result;
                                }
                        }
                        else
                        {
                            
                        }
                        
                      
                       
                }
                elseif($obj == "ComptantTaxesDetails")
                {
                        $ref = $id;
                        $paiment = $this->bank_model->get_paiement_tresor_bl($ref);
                        
                        if(empty($paiment))
                        {
                               $paiment = $this->bank_model->get_paiement_propres_bl($ref); 
                        }
                        
                        if($paiment != NULL):
                            $bulletin = json_decode($paiment->Notereference_30);
                            $taxes = json_decode($bulletin->taxesPaid);
                        else:
                            $taxes = array();
                        endif;
                        $this->data['recettes'] = $this->bank_model->get_dropdown("recettes");
                        $this->data['beneficiaires'] = $this->bank_model->get_dropdown("beneficiaires");
                        $this->data['taxesPaid'] = $taxes;
                        $this->load->view($this->module.'/'.$this->group.'/bulletins/_taxesDetails', $this->data);
                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error! To assign a member to a group, please select both a member and a group.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();
                                
                                $data = $_POST;
                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');

                                $infos = $data['Infos'];
                                $infos['quittanceid'] = $infos['Qserie'].$infos['Qnumber'];
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                        $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }
                                
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                               
                                
                                
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                                $data['Beneficaire_15'] = 'DGDA';
                                
                                # SAVE PAYMENT
                                $results = $infos;
                                $prefix = 1;
                                $logirefid = $data['Logirefid_4'];
                                $end_execution = NULL;

                                # Comptabilisation
                                # Prmiere partie - 
                                
                                $agence_src= $_SESSION['Logiref_guichet'];
                                
                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL, 'DGDA');

                                
                                switch ($case)
                                {
                                        case "case_1": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                        case "case_2": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                break;
                                        case "case_3": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                break;
                                        case "case_4": 
                                                $instructions = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                break;
                                        default: 
                                                //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                }

                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT
                                $guichet = $this->session->userdata("Logiref_guichet");
                                $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                                $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                #Taxes comptes
                                unset($comptes);
                                $comptes = array();
                                $agence_src= $_SESSION['Logiref_guichet'];
                                $instructions = array();
                                
                                $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                                $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                                
                                $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                                $taxes = json_decode($results['taxesPaid']);

                                foreach($taxes as $taxe)
                                {
                                        
                                        $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Paiementkey_52'] = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');

                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $data['Tresor_45'] = '1';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];
                                                
                                                $type_rectte = $type_recettes[$taxe->taxeCode];
                                                
                                                $pid = $this->encaissement_model->save_payment_tresor($data, NULL);
                                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                $instructions[] = $instruction;
                                        }
                                        else if(isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                $instructions[] = $instruction;
                                        }
                                        else
                                        {
                                                $data['Missmatch_46'] = 1;
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $taxe->taxeCode;

                                                $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                                
                                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                $instructions[] = $instruction;
                                        }
                                        $data['Id_0'] = $pid;

                                        $prefix++;
                                }
                                if(!empty($instructions))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        
                                        $end_execution = $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instructions, $data['Logirefid_4'], $priority);
                                        unset($instructions);
                                }
                                
                                if($end_execution)
                                {
                                        $bl_data['Status_2'] = '2';
                                        $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
                                }
                                
                                echo $data['Sydonia_44'];
                                
                        }
                }
                elseif($obj == "validate")
                {
                        $data = $_POST;
                        $code = '';
                        
                        if(isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "")
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;

                                        #Invocation of the api transfer
                                        @set_time_limit(300);

                                        $response = $this->curl_model->call_bank_virement($data);
                                        $return = json_decode($response, true);
										
                                        $id = $_POST['Sydonia_44'];

                                        if(isset($return['response']) && $return['response'] == "200")
                                        {
                                                $code = 200;
                                                
                                                $paiement = $this->encaissement_model->get_paiement_tresor_bl($_POST['Sydonia_44']);
                                                $result = json_decode($paiement->Notereference_30, true);

                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
												
                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Notereference_30'] = json_encode($result);


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                                                if($tid)
                                                {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->integration_model->update_bulletin($bl_data, $id);
                                                }
                                        }
                                        elseif(isset($return['response']) && $return['response'] !="")
                                        {
                                                $code = $return['response'];
                                        }
                                        
                                        
                                }
                                if(isset($id) && $id > 0) 
                                {
                                        $retour = array('code'=>$code, 'id'=>$id);
                                        echo json_encode($retour);
                                }
                                else
                                {
                                        echo 0;
                                }
                                
                        }
                }
                elseif($obj == "bulletin")
                {
                        # reference of the payment.
                        $logirefid = isset($_POST['Logirefid_4']) ? $_POST['Logirefid_4'] : "";
                        
                        $infos = $_POST['Infos'];
                        
                        $data['Status_2'] = 2;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata('account_id');
                       
                        //Formatting amount
                        $data['Amount_12'] = str_replace(' ','',$_POST['Notemontant_28']);
                        $data['Amount_12'] = str_replace(',','.',$data['Amount_12']);
                        
                        //Formatting amount
                        $data['Commission_26'] = str_replace(' ','',$_POST['Commission_23']);
                        $data['Commission_26'] = str_replace(',','.',$data['Commission_26']);
                        
                        $data['Taux_31'] = str_replace(' ','',$_POST['Taux_41']);
                        $data['Taux_31'] = str_replace(',','.',$data['Taux_31']);
                        
                        $data['Year_5'] = $infos['year'];
                        $data['Serie_7'] = $infos['serie'];
                        $data['Number_8'] = $infos['number'];
                        $data['Office_6'] = $_POST['Service_16'];
                        $data['Nif_9'] = $_POST['Nif_13'];
                        $data['Agent_10'] = $infos['Agent'];
                        $data['Bank_11'] = $infos['bank'];
                        
                        // result constuction 
                        $result = new stdClass();
                        $result->receiptDate = str_replace('-', '/', $infos['receiptdate']);
                        $result->receiptSerial = $infos['Qserie'];
                        $result->receiptNumber = $infos['Qnumber'];
                        $result->declarationsPaid = new stdClass();
                       
                        $result->declarationsPaid->registrationYear = $infos['year'];
                        $result->declarationsPaid->assessmentSerial = $infos['serie'];
                        $result->declarationsPaid->assessmentNumber =  $infos['number'];
                        $result->declarationsPaid->amountToBePaid = $data['Amount_12'];
                        $result->declarationsPaid->taxesPaid = $_POST['Infos']['taxesPaid'];
                        
                        $data['Results_13'] = json_encode($result);
                        $data['Error_14'] = '0';
                        $data['User_15'] = $this->session->userdata('user_id');
                        $data['Integration_16'] = gmdate('Y-m-d H:i:s');
                        $data['Printing_17'] = gmdate('Y-m-d H:i:s');
                        $data['Reference_19'] = $_POST['Reference_32'];
                        $data['Designation_23'] = $_POST['Designation_14'];
                        $data['Account_24'] = $_POST['account_cgu'];  // compte GU
                        $data['Amount_25'] = $data['Amount_12'] + $data['Commission_26'];  // Total amount
                        $data['Devise_27'] = $_POST['Devise_24'];
                        $data['Account_28'] = $_POST['Compte_33'];
                        $data['Devise_29'] = $_POST['Devise_34'];
                        $data['Mode_30'] = $_POST['Mode_19'];
                        $data['Taux_31'] = $_POST['Taux_41'];
                        $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                        //Formatting frais bcc
                        
                        if(isset($_POST['pourcompte'])) $paiementinfo['pourcompte'] = $_POST['pourcompte'];
                        
                        if(isset($_POST['tva'])) $paiementinfo['tva'] = $_POST['tva'];
                        
                        if(isset($paiementinfo))
                        {
                                $data['Paiementinfo_35'] = json_encode($paiementinfo);	
                        }

                        $data['Accountholder_33'] = (isset($_POST['Infos']['accountname']) && $_POST['Infos']['accountname'] != "")? $_POST['Infos']['accountname'] : '';
                        $data['Lot_22'] = 'saisi';
                        $id = $this->integration_model->save_bulletin($data, NULL);
                        
                        if($id > 0)
                        {
                                $data = array();

                                $data['Designation_14'] = $_POST['Designation_14'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Agence_20']=$_SESSION['Logiref_agence'];
                                $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                $data['Mode_19'] = $_POST['Mode_19'];

                                $data['Service_16'] = $_POST['Service_16'];

                                $data['Typerecette_17'] = $infos['serie'].$infos['number'];
                                $data['Devise_34'] = $_POST['Devise_34'];
                                $data['Notedate_27'] = $_POST['Notedate_27'];
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = str_replace(' ','',$_POST['Taux_41']);
                                        $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$_POST['Notemontant_28']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                
                                $data['Devise_12'] = $_POST['Devise_12'];
                                $data['Compte_33'] = $_POST['Compte_33'];
                                $data['Noteid_26'] = $infos['serie'].$infos['number'];
                                
                                
                                //Formatting amount
                                $data['Commission_23'] = str_replace(' ','',$_POST['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                if(isset($paiementinfo['tva']))
                                {
                                        $data['tva'] = $paiementinfo['tva'];
                                }
                                else
                                {
                                        $data['tva'] = "";
                                }
                                
                                $data['Devise_24'] = $_POST['Devise_24'];
                                $data['Nif_13'] = $_POST['Nif_13'];
                                
                                

                                $agence_src= $_SESSION['Logiref_guichet'];

                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src);

                                switch ($case)
                                {
                                        case "case_1": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                        case "case_2": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                break;
                                        case "case_3": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                break;
                                        case "case_4": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                break;
                                        default: 
                                                break;
                                }
                                
                                if(!empty($instructions1))
                                {
                                        # priority for integrating the counting in cbs
                                        
                                        $priority = 0; 
                                        $this->comptabilisation_model->save_first_instructions_dgda($id, $data, $instructions1, $logirefid, $priority);
                                }
                        }
                        
                        return $id;
                }
                elseif($obj == "delete")
                {
                        
                        $pid = 0;
                        // supression du bulletin 
                        $idBL = $this->others_model->delete_bulletin($id);
                        
                        // supression de l'eclatement 
                        if($idBL > 0)
                        {
                            $pid = $this->encaissement_model->delete_paiement_tresor_dgda($id);
                            $pid = $this->encaissement_model->delete_paiement_propre_dgda($id);
                        }
                      
                        // supression des écritutes du bulletin 
                        if($pid > 0)
                        {
                            
                            $sup = $this->comptabilisation_model->delete_instructions_dgda($id);
                            
                        }
                        
                        #Return
                        echo $idBL;
                        die;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "get_commission")
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }
                        
//                      //Montant total
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;
                        
                        if($cdata['devise'] == $oDeivise)
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'];
                        }
                        else if($cdata['devise'] == 'USD')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']*$taux['Dollar_4']);
                        }
                        else if(result[1] == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']/$taux['Dollar_4']);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
                        
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar; exit;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
