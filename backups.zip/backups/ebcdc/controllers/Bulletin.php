<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bulletin extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'bulletins';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/bulletins_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/comptabilisation_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/fees_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'bulletin';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
	public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1', $this->data);
                }
                elseif($obj == "verification") 
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_checkbl($credentials);
                        
                        $message_en = $this->integration_model->sydonia_error_message['en'];
                        $message_fr = $this->integration_model->sydonia_error_message['fr'];
                        
                        $result = json_decode($response, true);
                        
                        if(isset($result['code']))
                        {
                                if($result['code']=='E11' || $result['code']=='E15' || $result['code']=='E34' ||  $result['code']=='E22' || $result['code'] == 'E404' || $result['code'] == 'E405' || $result['code'] == 'E406' || $result['code'] == 'E000' || $result['code'] == 'E18' || $result['code'] == 'E21')
                                {
                                        echo $response; die;
                                }
                                elseif($result['code']=='E13' || $result['code']=='E003')
                                {
                                        
                                        foreach($message_en as $key=>$row)
                                        {
                                                $message_sydonia = strtolower($result['message']);
                                                
                                                if (strstr($message_sydonia, $row)) 
                                                {
                                                        $result['message'] = $message_fr[$key];
                                                        break;
                                                }
                                        }
                                        
                                        $result['message'] = '<div class="alert alert-warning text-white">'.$result['message'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                        $response = json_encode($result);
                                        
                                        echo $response; die;
                                }
                                elseif($result['code'] == 'OK')
                                {
                                        $response = array();
                                        
                                        $response['code'] = $result['code'];
                                        $response['data'] = $_POST;
                                        
                                        echo json_encode($response); die;
                                }
                        }
                        else
                        {
                                # no return
                                $response = array();
                                $response['code'] = 'E406';
                                
                                echo json_encode($response); die;
                        }
                }
                elseif($obj == "step_1_details")
                {
                        $amount = str_replace(' ','',$_POST['Amount']);
                        $amount = str_replace(',','.',$amount);
                        $devise = $_POST['devise'];
                        $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                        $service = $_POST['Office'];
                        $agence = $_SESSION['Logiref_guichet'];
                        $mode = $_POST['Mode'];
                        
                        if(isset($_POST['tarif']) && $_POST['tarif'] !="")
                        {
                                $_POST['Commission'] = $_POST['tarif'];
                                $_POST['Devise_commission'] = 'CDF';
                        }

                        $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";
                                
                        if(isset($_POST['exchange_rate']) && $_POST['exchange_rate'] != "")
                        {
                                $taux['Dollar_4'] = $_POST['exchange_rate'];
                        }
                        else
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                        }

                        if($devise !='CDF')
                        {
                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                {
                                        $devise_taux = $_POST['Taux'];
                                }
                                else
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);

                                        $devise_taux = $taux['Dollar_4'];
                                }
                        }
                        else
                        {
                                $devise_taux = 1;
                        }

                        if(isset($_POST['Nif']))
                        {
                                $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                                if(isset($_POST['designation'])) $this->data['designation'] = $_POST['designation'];
                        }


                        if(!isset($_POST['Commission']))
                        {
                                $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                {
                                        $com['com'] = ($amount * $rules['Valeur'])/100;
                                        $com['devise'] = $devise;
                                }
                                elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                {
                                        $com['com'] = $rules['Valeur'];
                                        $com['devise'] = $rules['Unite'];
                                }
                                if(!empty($com) && $com['com']!=0)
                                {
                                        if($com['devise'] !='CDF')
                                        {
                                                $this->data['commission'] = $com['com'] * $devise_taux;
                                                $this->data['$commission_devise'] = $com['devise'];

                                                $this->data['total_amount'] = $amount + $this->data['commission'] + ($this->data['commission']*0.16);
                                        }
                                        else
                                        {
                                                $this->data['commission'] = $com['com'];
                                                $this->data['$commission_devise'] = $com['devise'];

                                                $this->data['total_amount'] = $amount + $this->data['commission'] + ($this->data['commission']*0.16);
                                        }
                                }
                                else
                                {
                                        $this->data['commission'] = $amount*0;
                                        $this->data['commission_devise'] = $devise;
                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                }
                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        }
                        else 
                        {
                                $commission = str_replace(' ','',$_POST['Commission']);
                                $commission = str_replace(',','.',$commission);

                                $this->data['commission'] = $commission;
                                $this->data['commission_devise'] = $_POST['Devise_commission'];

                                if($_POST['Devise_commission'] !="CDF")
                                {
                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        }
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                        $commission = $this->data['commission'] * $devise_taux;
                                        $this->data['total_amount'] = $amount + $commission + ($commission * 0.16);
                                }
                                else
                                {
                                        $this->data['total_amount'] = $amount + $commission + ($commission * 0.16);
                                }
                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        }
                        # Balance verification
                                
                        if(isset($_POST['internal_account']) && $_POST['internal_account'] !='')
                        {
                                $this->data['account_balance'] = "Approvisionné";
                                $this->data['balance'] = 'ok';
                        }
                        else
                        {
                                if($_POST['account_currency']=="" || $_POST['account_balance']=="")
                                {
                                        echo 'E411'; die;
                                }
                                else 
                                {
                                        if($_POST['account_currency'] == 'CDF')
                                        {
                                                $tva =  $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                if($_POST['account_balance'] >= $amount_to_pay)
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                }
                                                else 
                                                {
                                                        $this->data['account_balance']= "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        }
                                        elseif($_POST['account_currency'] == 'USD')
                                        {
                                                $tva =  $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                $taux = $this->data['bank_rate_applied'];

                                                # convert amount in USD
                                                $amount_to_pay = $amount_to_pay/$taux;

                                                if($_POST['account_balance'] >= $amount_to_pay)
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                }
                                                else 
                                                {
                                                        $this->data['account_balance']= "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        }
                                }
                        }
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);

                        $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";

                        if($mode =='7')
                        {
                                $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                $this->data['disabled'] = "";
                        }
                        else 
                        {
                                $this->data['referenceOP'] = "";
                                $this->data['disabled'] = "disabled";
                        }

                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_details', $this->data);
                }
                elseif($obj == "confirmation") 
                {
                        $_POST['Paiementid'] = $_POST['bulletin_id'];
                        
                        $message_en = $this->integration_model->sydonia_error_message['en'];
                        $message_fr = $this->integration_model->sydonia_error_message['fr'];
						
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_bank_comptant_single($credentials);
                        $result = json_decode($response, true);
                        
                        if(isset($result['code']))
                        {
                                if($result['code']=='E11' || $result['code']=='E34' ||  $result['code']=='E22' || $result['code'] == 'E404' || $result['code'] == 'E405' || $result['code'] == 'E406' || $result['code'] == 'E000' || $result['code'] == 'E002' || $result['code'] == 'E18' || $result['code'] == 'E21' || $result['code'] == 'E15')
                                {
                                        echo $response; die;
                                }
                                elseif($result['code']=='E13' || $result['code']=='E003')
                                {
                                        foreach($message_en as $key=>$row)
                                        {
                                                $message_sydonia = strtolower($result['message']);
                                                
                                                if (strstr($message_sydonia, $row)) 
                                                {
                                                        $result['message'] = $message_fr[$key];
                                                        break;
                                                }
                                        }
                                        
                                        $result['message'] = '<div class="alert alert-warning text-white">'.$result['message'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                        $response = json_encode($result);
                                        
                                        echo $response; die;
                                }
                                elseif($result['code'] == 'OK')
                                {
                                        $response = array();
                                        
                                        $response['code'] = $result['code'];
                                        $response['id'] = $result['id'];
                                        
                                        echo json_encode($response); die;
                                }
                        }
                        else
                        {
                                # no return
                                $response = array();
                                $response['code'] = 'E406';
                                
                                echo json_encode($response); die;
                        }
                }
                elseif($obj == "create_bulletin") 
                {
                        # reference of the payment.
                        $data['Logirefid_4'] = $this->integration_model->generate_unique_reference().$this->session->userdata('user_id');

                        $id = $this->save('bulletin', $data['Logirefid_4'], $id);

                        if($id > 0)
                        {
                                echo $id;
                        }
                        else
                        {
                                echo 0;
                        }
                }
                 
                elseif($obj == "credit_start") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_credit_step_1', $this->data);
                }
                elseif($obj == "credit_verification") 
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_checkbl_credit($credentials);
                        $response = trim($response);
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000')
                        {
                                echo $response; die;
                        }
                        else
                        {
                                $amount = str_replace(' ','',$_POST['Amount']);
                                $amount = str_replace(',','.',$amount);
                                $devise = $_POST['devise'];
                                $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                                $service = $_POST['Office'];
                                $agence = $_SESSION['Logiref_guichet'];
                                $mode = $_POST['Mode'];
                                
                                if(isset($_POST['tarif']) && $_POST['tarif'] !="")
                                {
                                        $_POST['Commission'] = $_POST['tarif'];
                                        $_POST['Devise_commission'] = 'CDF';
                                }

                                $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                if($devise !='CDF')
                                {
                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        }
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                }
                                else
                                {
                                        $devise_taux = 1;
                                }

                                if(isset($_POST['Nif']))
                                {
                                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                        $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                                }


                                if(!isset($_POST['Commission']))
                                {
                                        $rules = $this->fees_model->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                                $com['com'] = ($amount * $rules['Valeur'])/100;
                                                $com['devise'] = $devise;
                                        }
                                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }
                                        if(!empty($com) && $com['com']!=0)
                                        {
                                                if($com['devise'] !='CDF')
                                                {
                                                        $this->data['commission'] = $com['com'] * $devise_taux;
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'] + ($this->data['commission']*0.16);
                                                }
                                                else
                                                {
                                                        $this->data['commission'] = $com['com'];
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'] + ($this->data['commission']*0.16);
                                                }
                                        }
                                        else
                                        {
                                                $this->data['commission'] = $amount*0;
                                                $this->data['commission_devise'] = $devise;
                                                $this->data['total_amount'] = $amount + $this->data['commission'];
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                else 
                                {
                                        $commission = str_replace(' ','',$_POST['Commission']);
                                        $commission = str_replace(',','.',$commission);
                                        
                                        $this->data['commission'] = $commission;
                                        $this->data['commission_devise'] = $_POST['Devise_commission'];

                                        if($_POST['Devise_commission'] !="CDF")
                                        {
                                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                {
                                                        $devise_taux = $_POST['Taux'];
                                                }
                                                else
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        $devise_taux = $taux['Dollar_4'];
                                                }
                                                $commission = $this->data['commission'] * $devise_taux;
                                                $this->data['total_amount'] = $amount + $commission + ($commission * 0.16);
                                        }
                                        else
                                        {
                                                $this->data['total_amount'] = $amount + $commission + ($commission * 0.16);
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                # Balance verification
                                if(isset($_POST['internal_account']) && $_POST['internal_account'] !='')
                                {
                                        $this->data['account_balance'] = "Approvisionné";
                                        $this->data['balance'] = 'ok';
                                }
                                else
                                {
                                        if($_POST['account_currency']=="" || $_POST['account_balance']=="")
                                        {
                                                echo 'E411'; die;
                                        }
                                        else 
                                        {
                                                if($_POST['account_currency'] == 'CDF')
                                                {
                                                        $tva =  $this->data['commission'] * 0.16;
                                                        $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                        if($_POST['account_balance'] >= $amount_to_pay)
                                                        {
                                                                $this->data['account_balance'] = "Approvisionné";
                                                                $this->data['balance'] = 'ok';
                                                        }
                                                        else 
                                                        {
                                                                $this->data['account_balance']= "Solde insuffisant";
                                                                $this->data['balance'] = 'ko';
                                                        }
                                                }
                                                elseif($_POST['account_currency'] == 'USD')
                                                {
                                                        $tva =  $this->data['commission'] * 0.16;
                                                        $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                        $taux = $this->data['bank_rate_applied'];

                                                        # convert amount in USD
                                                        $amount_to_pay = $amount_to_pay/$taux;

                                                        if($_POST['account_balance'] >= $amount_to_pay)
                                                        {
                                                                $this->data['account_balance'] = "Approvisionné";
                                                                $this->data['balance'] = 'ok';
                                                        }
                                                        else 
                                                        {
                                                                $this->data['account_balance']= "Solde insuffisant";
                                                                $this->data['balance'] = 'ko';
                                                        }
                                                }
                                        }
                                }
                                $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                                
                                $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                                                      
                                if($mode =='7')
                                {
                                        $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                        $this->data['disabled'] = "";
                                }
                                else 
                                {
                                        $this->data['referenceOP'] = "";
                                        $this->data['disabled'] = "disabled";
                                }

                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_details', $this->data);
                        }
                }
                
                elseif($obj == "credit_confirmation") 
                {
                        if($_POST['bulletin_id'] == "")
                        {
                                $_POST['lien_id'] = $_SESSION['lien_id'];
                                $_POST['date_lien'] = $_SESSION['date_lien'];
                                $_POST['Paiementid'] = $id = $this->save('bulletin');
                        }
                        else 
                        {
                                $_POST['Paiementid'] = $_POST['bulletin_id'];
                        }
						
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $response = $this->curl_model->call_bank_credit_single($credentials);
                        $response = trim($response);
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000')
                        {
                                $result['response'] = $response;
                                $result['id'] = $id;

                                echo json_encode($result); die;
                        }
                        else
                        {
                                $result['response'] = $response;
                                echo json_encode($result); die;
                        }
                }
                elseif($obj == "batch_start") 
                {
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['step'] = 0;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_start', $this->data);
                }
                elseif($obj == "batch_step_2") 
                {
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        $file = $_FILES['attachement']['tmp_name'];
                        $file_extension = strtolower(substr(strrchr($_FILES['attachement']['name'], '.'), 1));
                        $valid_extensions = array('xlsx','xls');
                        $bulletins = array();
                        $tables = array();
                        $amounts = 0;
                        if(empty($file))
                        {
                                echo 'E200';
                                die;
                        }
                        
                        if (!in_array($file_extension, $valid_extensions)) 
                        {
                                echo 'E202';
                                die;
                        }
                        
                        $handle = fopen($file, "r");
                        if($handle == false)
                        {
                                echo 'E200';
                        }
                        else
                        {
                                $sheet = PHPExcel_IOFactory::createReaderForFile($file);
                                $sheet->setReadDataOnly(true);
                                $objPHPExcel = $sheet->load($file);
                                $objWorksheet = $objPHPExcel->getActiveSheet();
                                $lot = $objWorksheet->toArray(null, true, true, true);
                                                        
                                if(!empty($lot))
                                {
                                        $t = 1;
                                        foreach ($lot as $worksheet)
                                        {
                                                if($t > 1)
                                                {
                                                    $bulletins[] = $worksheet;
                                                }
                                                
                                                $t++;
                                        }
                                        
                                        foreach($bulletins as $sheet) 
                                        {
                                                
                                                $bl_exists = false;
                                                foreach($tables as $bl)
                                                {
                                                        if($sheet['A'] == $bl->year && $sheet['B']== $bl->number && $sheet['C']== $bl->amount)
                                                        {
                                                                $bl_exists = true;   
                                                        }

                                                }
                                                
                                                if($bl_exists == false)
                                                {
                                                    if($sheet['A'] != "" && $sheet['B'] != "" && $sheet['C'] != "")
                                                    {
                                                            $bulletin = new stdClass();
                                                            $bulletin->year = $sheet['A'];
                                                            $bulletin->number = $sheet['B'];
                                                            $montant1 =  str_replace(' ','',intval($sheet['C']));
                                                            $bulletin->amount = $amount = str_replace(',','.',$montant1);
                                                            $amounts += $amount;
                                                            $tables[] = $bulletin;
                                                            
                                                            
                                                    }
                                                }
                                        }
                                        
                                        // Calcul de la commission du lot
                                        $agence = $_SESSION['Logiref_guichet'];
                                        $response = array();
                                        $cdata['regie'] = "DGDA";
                                        $cdata['service']= $_POST['office'];
                                        $cdata['recette']= NULL;
                                        $cdata['devise'] = "CDF";
                                        $cdata['guichet'] = $agence;
                                        $cdata['montant'] = $amounts;
                                        
                                        $commission = $this->data('get_commission', $cdata);
                                       
                                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                        $this->data['nif'] = $_POST['Nif'];

                                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                                        $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 

                                        $this->data['agent'] = $_POST['agent'];
                                        $this->data['total'] = $amounts;
                                        $this->data['bulletins'] = $tables;
                                        $this->data['account_name'] = $_POST['account_name'];
                                        $this->data['commission'] = $commission[0];
                                        $this->data['total_to_paid']  = $amounts + $commission[0];
                                        $this->data['office'] = $_POST['office'];
                                        $this->data['bank'] = $_POST['bank'];
                                        $this->data['refOp'] = $_POST['ref'];
                                        $this->data['mode'] = $_POST['mode'];
                                        $this->data['taux'] = isset($_POST['Taux'])? $_POST['Taux'] :'00,00';
                                        $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                                        $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
										$this->data['tva'] = isset($_POST['tva']) ? $_POST['tva']: 0;
                                        
                                        $this->data['account_type'] = $_POST['account_type'];
                                        $this->data['account_balance'] = $_POST['account_balance'];
                                        $this->data['step'] = 1;
                                        $this->load->view($this->module.'/'.$this->group. '/bulletins/_batch_step_2', $this->data);
                                }
                                else
                                {
                                    echo 'E200';
                                }
                                
                        }
                
                }
                elseif($obj == "check_batch") 
                {
                        $reference_op = $id;
                        
                        $batch_line = $this->integration_model->check_batch_bulletin_sydonia($reference_op);
                        
                        if(!empty($batch_line))
                        {
                                echo "E000";  
                        }
                        else
                        {
                                echo "E200";
                        }
                }
                elseif($obj == "batch_verification") 
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $agence = $_SESSION['Logiref_guichet'];
                        $bulletins = array();
                        $serials  = $_POST['years'];
                        $years = $_POST['serials'];
                        $amounts = $_POST['amounts'];
                        $total_amount = 0;
                        
                        // Variable retour
                        $verification = array();
                        $verification['error'] = false;
                        $verification['response'] = 'OK';
                        
                        //Verification de chaque bulletin dans SYDONIA
                        for($i = 1; $i<= count($serials); $i++)
                        {
                                $_POST['Year'] = $years = $_POST['years'][$i];
                                $montant1 =  str_replace(' ','',$_POST['amounts'][$i]);
                                $_POST['Amount']= $amount = str_replace(',','.',$montant1);
                                $total_amount = $total_amount + $amount;
                                $verification['total_amount'] = $total_amount;
                                
                                $bulletin = $_POST['serials'][$i];
                                $service = $_POST['Office'];
                                $_POST['Series'] = $serial = substr($bulletin,0,1);
                                $_POST['Number'] = $number = substr($bulletin,1);
                                $agent = $_POST['Agent'];
                                $bank = $_POST['Bank'];
                                
                                $response = $this->curl_model->call_dgda_checkbl_batch($credentials);
                                $response = trim($response);
                                
                                if($response=='E003' || $response == 'E404' || $response == 'E18'  ||  $response == 'E21' ||  $response == 'E000')
                                {
                                        $verification['response'] = $response; 
                                        
                                        echo json_encode($verification);
                                        
                                        die;
                                }
                                
                                if($response != "OK")
                                {
                                        $verification['error'] = true;
                                }

                                $bulletins[] = $response;
                                
                                $verification['bulletins'] = $bulletins;
                        }
                        
                        if($verification['error'] == false)
                        {
                                //Calcul de la commission 
                                if(isset($_POST['Commission']) && $_POST['Commission'] =="")
                                {
                                        $agence = $_SESSION['Logiref_guichet'];
                                        $response = array();
                                        $cdata['regie'] = "DGDA";
                                        $cdata['service']= $_POST['Office'];
                                        $cdata['recette']= NULL;
                                        $cdata['devise'] = "CDF";
                                        $cdata['guichet'] = $agence;
                                        $cdata['montant'] = $amount;

                                        $commission = $this->data('get_commission', $cdata)[0];
                                        $tva = $commission[0] * 0.16;
                                        $total_to_paid = $commission + $total_amount + $tva;
                                        
                                        $verification['tva'] = $tva;
                                        $verification['commission'] = $commission;
                                        $verification['total'] = $total_to_paid;
                                }
                                else
                                {
                                        $commission = str_replace(' ','',$_POST['Commission']);
                                        $commission = str_replace(',','.',$commission);
                                        $tva = $commission * 0.16;
                                        $total_to_paid = $commission + $total_amount + $tva;
                                        
                                        $verification['tva'] = $tva;
                                        $verification['commission'] = $commission;
                                        $verification['total'] = $total_to_paid;
                                }


                                //V�rification de la balance du client
                                if($_SESSION['Logiref_role']==4)
                                {
                                        $data['bank_account'] = $_POST['account'];
                                        $data['devise_account'] = $_POST['cdevise'];
                                        $data['amount'] = $total_to_paid;


                                        if($_POST['account_type'] == 'current_account')
                                        {
                                                $balance = isset($_POST['account_balance']) ? $_POST['account_balance'] : 0;

                                                if($balance > $total_to_paid)
                                                {
                                                        $verification['balance'] = 'OK';
                                                }
                                                else
                                                {
                                                        $verification['balance'] = 'KO';
                                                }
                                        }
                                        elseif($_POST['account_type'] == 'internal_account')
                                        {
                                                $verification['balance'] = 'OK';
                                        }
                                        else
                                        {
                                                $verification['balance'] = 'E411';
                                        }
                                }
                                else
                                {
                                        $verification['balance'] = 'OK';
                                }
                        }
                        
                        echo json_encode($verification);
                        
                }
                elseif($obj == "batch_create_bulletin")
                {
                        # If the account is not internal
                        # Reservation
                        
                        $data['Logirefid_4'] = $this->integration_model->generate_unique_reference().$this->session->userdata('user_id');
                        
                        $id = $this->save('batch_bulletin', $data['Logirefid_4'], $id);
                    
                        if($id > 0)
                        {
                                echo $id;
                        }
                        else
                        {
                                echo 0;
                        }
                        
                }
                elseif($obj == 'step_1_batch')
                {
                        $batch_lines = $this->integration_model->get_bulletin_batch_info($id);
                        
                        $bulletins= $this->bulletins_model->get_bulletins_by_logiredid($batch_lines->Lot_14);
                        
                        # If notes related to the batch is already confirmed.
                        if(!empty($bulletins))
                        {
                                $this->data['bulletins'] = $bulletins;
                                
                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                                
                                $this->data['cGuichet'] =  isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                                    
                                $this->data['batch_reference'] = $batch_lines->Lot_14;
                                $this->data['batch_lines'] = $batch_lines;
                                $this->data['account'] = (isset($batch_lines->Account_16))? $batch_lines->Account_16:'';
                                $this->data['cdevise'] = (isset($batch_lines->Devise_17))? $batch_lines->Devise_17:''; 
                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['designation'] = $batch_lines->Designation_15;
                                $this->data['nif'] = $batch_lines->Nif_8;
                                $this->data['accountnane'] = $batch_lines->Accountholder_18;
                                $this->data['total_amount'] = $batch_lines->Total_23;
                                $this->data['commission'] = $batch_lines->Commission_20 ;
                                $this->data['totalpaid'] = $batch_lines->Total_23;
                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                
                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3', $this->data);
                        }
                        else
                        {
				$bulletins = json_decode($batch_lines->Bulletins_22, true);
                                $i = 1;
                                $amounts = 0;

                                for($i=1; $i<=count($bulletins['years']); $i++) 
                                {
                                        $bulletin = new stdClass();

                                        $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $bulletin->year = $bulletins['years'][$i];
                                        $bulletin->number = $bulletins['serials'][$i];
                                        $bulletin->amount = $amount;
                                        $amounts += $amount;

                                        $tables[] = $bulletin;
                                }

                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['nif'] = $batch_lines->Nif_8;

                                $this->data['designation'] = $batch_lines->Designation_15;

                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['total'] = $batch_lines->Amount_11;
                                $this->data['bulletins'] = $tables;
                                $this->data['batch'] = $batch_lines;
                                $this->data['account_name'] = $batch_lines->Accountholder_18; 
                                $this->data['account_type'] = $batch_lines->Typeaccount_28; 
                                $this->data['commission'] = $batch_lines->Commission_20;
                                $this->data['total_to_paid']  = $batch_lines->Total_23; 
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['bank'] = $batch_lines->Bank_10;
                                $this->data['refOp'] = $batch_lines->Refop_25;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['taux'] = $batch_lines->Taux_26;
                                $this->data['account'] = $batch_lines->Account_16; 
                                $this->data['cdevise'] = $batch_lines->Devise_17 ;
                                $this->data['integrations'] = $this->comptabilisation_model->get_first_instructions_dgda($batch_lines->Lot_14);
                                $this->data['step'] = 1;
                                $this->load->view($this->module.'/'.$this->group. '/bulletins/_batch_step_2_process', $this->data);
                        }
                }
                elseif($obj == "batch_confirmation")
                {
                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                        if($client !=NULL) $_POST['designation'] = $client->Designation_5; else $_POST['designation'] ='';
                        
                        $batch_id = isset($_POST['batch_id']) ? $_POST['batch_id'] : "";
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                        
                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata('account_id');
                        $_POST['User'] =  $this->session->userdata('user_id');
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                        $_POST['batch_reference'] = $batch_reference = isset($_POST['batch_reference']) ?  $_POST['batch_reference'] : "";
                        
                        $batch_lines = $this->integration_model->get_bulletin_batch_info($batch_id);
                       
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        
                        $data = $_POST;
                        $data['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                        $data['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                        
                        set_time_limit(250);
                       
                        $result = $this->curl_model->call_bank_comptant_batch($data);
						
                        
                        if($result=='E003' || $result=='E22' || $result=='E21' || $result=='E11' || $result=='E34' || $result == 'E404' || $result == 'E501' || $result == 'E4' || $result == 'E000' || $result == 'E13')
                        {
                                echo $result; die;
                        }
                        else
                        {
                                $this->data['bulletins'] = $bulletins = $this->bulletins_model->get_bulletins_by_lot($result);
                                    
                                $this->data['batch_reference'] = (isset($_POST['batch_reference']))? $_POST['batch_reference']:'';
                                $this->data['batch_lines'] = $batch_lines;
                                $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                                $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                                $this->data['agent'] = $_POST['Agent'];
                                $this->data['office'] = $_POST['Office'];
                                $this->data['mode'] = $_POST['mode'];
                                $this->data['designation'] = $_POST['designation'];
                                $this->data['nif'] = $_POST['Nif'];
                                $this->data['accountnane'] = $account_name;
                                
                                $this->data['total_amount'] = str_replace(' ', '', $_POST['total_amount']);
                                $this->data['total_amount'] = str_replace(',','.', $this->data['total_amount']);
                                
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['tva'] = $_POST['tva'];
                                $this->data['fraisbcc'] = $_POST['fraisbcc'];
                                $this->data['totalpaid'] = $_POST['total_topaid'];
                                $this->data['cGuichet'] =  $_POST['cGuichet'];
                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                //$this->data['step'] = 1;
                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3', $this->data);
                        }
                }
                elseif($obj == "batch_validation")
                {
                        $batch_reference = $id;
                        $this->data['bulletins'] = $this->bulletins_model->get_bulletins_by_logiredid($batch_reference, "unvalidated");
                        $this->data['step'] = 0;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_validation', $this->data);
                }
                elseif($obj == "preview_batch")
                {
                        $this->data['step'] = 0;
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);

                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="") ? $_GET['view'] : '';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3_view', $this->data);
                }
                elseif($obj == "edit")
                {
                        $bl = $id;
                        $instructions2 = array();
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        
                        $info = $encaissement->Notereference_30;
                        
                        $taxesPaid = $info['taxesPaid'];
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        
                        $frais_bcc = 0;
                        
                        if(is_array($taxesPaid) && count($taxesPaid) > 0)
                        {
                                $taxes = $taxesPaid;
                        }
                        elseif(is_object($taxesPaid) && $taxesPaid !="")
                        {
                                $taxes[] = $taxesPaid;
                        }
                        
                        foreach($taxes as $taxe)
                        {
                                if(isset($taxe->taxeCode))
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $amount = $taxe->taxeAmount * 0.0005;

                                                $frais_bcc = $amount + $frais_bcc;
                                        }
                                }
                        }
                        
                        $encaissement->Total = $encaissement->Total + $frais_bcc;

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        
                        $data['frais_bcc'] = $frais_bcc;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        
                        $infos = $data["Notereference_30"];
                        
                        if(isset($infos['tva']) && $infos['tva'] == "1")
                        {
                                $data['tva'] = $infos['tva'];
                        }
                        else 
                        {
                                $data['tva'] = "";
                        }
						
                        # The value to know whether the customer account is exempted from bcc fees or not
                        $frais_bcc_exempt = isset($infos['fraisbcc']) ? $infos['fraisbcc'] : "";
						
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        
                        $data ['paiement_key'] = "";
                        
                        //$instructions2 = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes);
						$instructions2 = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes, $frais_bcc_exempt);
                        
                        $guichet = $this->session->userdata("Logiref_guichet");
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        
                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->data['step'] = 0;
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);

                        $encaissement = $this->data_model->sydonia_migrate_bl($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="")?$_GET['view']:'';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_3', $this->data);
                }
                elseif($obj == "step_1_process")
                {
                        $this->data['step'] = 0;
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="")?$_GET['view']:'';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_first_instructions_dgda($id);
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_process', $this->data);
                }
		elseif($obj == "step_1_process_credit")
                {
                        $this->data['step'] = 0;
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="")?$_GET['view']:'';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_first_instructions_dgda($id);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_1_process_credit', $this->data);
                }
                elseif($obj == "first_transaction_batch")
                {
                        $id = $_POST['batch_id'];
                        
                        $batch = $this->integration_model->get_bulletin_batch_info($id);

                        $data['Sydonia_44'] = $batch->Lot_14;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $batch->Designation_15;
                        $data['Account_3'] = $this->session->userdata('account_id');
                        
                        $data['Type'] = "first_transaction_batch";

                        $data['Priority'] = 0;
                        
                        $response = $this->curl_model->call_bank_virement($data);
			
                        $return = json_decode($response, true);
                        
                        if(isset($return['response']) && $return['response'] == "200")
                        {
                                $data = array();
                                $data['Status_2'] = 2;
                                $data['Priority_24'] = 0;
                                
                                $this->comptabilisation_model->update_instructions_dgda_by_id($id, $data);
                                
                                echo $return['response'];
                        }
                        elseif(isset($return['response']) && ($return['response'] == "E162" || $return['response'] == "E463" || $return['response'] == "W0205" || $return['response'] == "E3238" || $return['response'] == "E397" || $return['response'] == "AD3" || $return['response'] == "ERR002" || $return['response'] == "ERR003" || $return['response'] == "P83"))
                        {
                                echo $return['response'];
                        }
                        else
                        {
                                $data = array();
                                $data['Status_2'] = 5;
                                $data['Priority_24'] = 0;
                                
                                $this->comptabilisation_model->update_instructions_dgda_by_id($batch->Lot_14, $data);
                                echo $return['response'];
                        }
                }
                elseif($obj == "first_transaction")
                {
                        $id = $_POST['bulletin_id'];
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);

                        $data['Sydonia_44'] = $id;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $bulletin->Designation_23;
                        $data['Account_3'] = $this->session->userdata('account_id');
                        
                        $data['Type'] = "first_transaction";

                        $data['Priority'] = 0;
                        
                        $response = $this->curl_model->call_bank_virement($data);
                        $return = json_decode($response, true);

                        

                        if(isset($return['response']) && $return['response'] == "200")
                        {
                                $data = array();
                                $data['Status_2'] = 2;
                                $data['Priority_24'] = 0;
                                
                                $this->comptabilisation_model->update_instructions_dgda_by_id($id, $data);
                                
                                echo $return['response'];
                        }
                        elseif(isset($return['response']) && ($return['response'] == "E162" || $return['response'] == "E463" || $return['response'] == "W0205" || $return['response'] == "E3238" || $return['response'] == "E397" || $return['response'] == "AD3" || $return['response'] == "ERR002" || $return['response'] == "ERR003" || $return['response'] == "P83"))
                        {
                                echo $return['response'];
                        }
                        else
                        {
                                $data = array();
                                $data['Status_2'] = 5;
                                $data['Priority_24'] = 0;
                                
                                $this->comptabilisation_model->update_instructions_dgda_by_id($id, $data);
                                echo $return['response'];
                        }
                }
                elseif($obj == "edit_credit")
                {
                        $bl = $id;
                        $instructions2 = array();
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_credit_bl($id);
                        
                        $info = $encaissement->Notereference_30;
                        
                        $taxes = $info['taxesPaid'];
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        
                        $frais_bcc = 0;
                        
                        foreach($taxes as $taxe)
                        {
                                if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                {
                                        $amount = $taxe->taxeAmount * 0.0005;
                                        
                                        $frais_bcc = $amount + $frais_bcc;
                                }
                        }
                        
                        $encaissement->Total = $encaissement->Total + $frais_bcc;

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        
                        $data['frais_bcc'] = $frais_bcc;
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                        
                        $infos = $data["Notereference_30"];
                        
                        if(isset($infos['tva']) && $infos['tva'] == "1")
                        {
                                $data['tva'] = $infos['tva'];
                        }
                        else 
                        {
                                $data['tva'] = "";
                        }
                        
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        $instructions2 = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes);
                        
                        
                        $guichet = $this->session->userdata("Logiref_guichet");
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        
                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                        $taxes = $info['taxesPaid'];

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_credit_step_2', $this->data);
                }
                elseif($obj == "preview_credit")
                {
                        $bl = $id;
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_credit_bl($id);
                        $this->rates_model->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] !="")?$_GET['view']:'';
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisation_model->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_credit_step_3', $this->data);
                }
                elseif($obj == "batch_recover")
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $agence = $_SESSION['Logiref_guichet'];
                        $bulletins = array();
                        
                        $batch_lines = $this->integration_model->get_bulletins_batch_by_reference($_POST['batch_reference']);
                        
                        $serials  = $_POST['years'];
                        $years = $_POST['serials'];
                        $amounts = $_POST['amounts'];
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);

                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata('account_id');
                        $_POST['User'] =  $this->session->userdata('user_id');
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                        
                        if(isset($_POST['batch_reference']) && $_POST['batch_reference'] != "")
                        {
                                $_POST['logirefid'] = $_POST['batch_reference'];
                        }
                        
                        $account_name = $data['account_name'] = $_POST['account_name'];
                                
                        $total_amount = 0;
                        
                        //Variable retour
                        $verification = array();
                        
                        //Verification de chaque bulletin dans SYDONIA
                        for($i = 1; $i<= count($serials); $i++)
                        {
                                $_POST['Year'] = $years = $_POST['years'][$i];
                                $montant1 =  str_replace(' ','',$_POST['amounts'][$i]);
                                $_POST['Amount']= $amount = str_replace(',','.',$montant1);
                                $total_amount = $total_amount + $amount;
                               
                                $bulletin = $_POST['serials'][$i];
                                $service = $_POST['Office'];
                                $_POST['Series'] = $serial = substr($bulletin,0,1);
                                $_POST['Number'] = $number = substr($bulletin,1);
                                $agent = $_POST['Agent'];
                                $bank = $_POST['Bank'];
                                
                                set_time_limit(250);
                                $response = $this->curl_model->call_batch_recover($credentials);
                                
                                
                                
                                $response = trim($response);
                                if($response == 'E404' ||  $response == 'E000' || $response == 'E002')
                                {
                                        echo $response;
                                        die;
                                }
                                else
                                {
                                        if(is_numeric($response))
                                        {
                                                $bulletins[] = $response;
                                        }
                                }                
                        }
                        
                        $result = implode(",",$bulletins);
                        
                        
                        
                        if(count($bulletins) > 0) 
                        {
                                $lot = $this->bulletins_model->get_bulletins_by_lot($result);
                                $this->save("update_batch", $batch_lines->Id_0);
                        }
                        else 
                        {
                                $lot = array();
                        }
                        
                        $this->data['bulletins'] = $lot;
                        $this->data['batch_reference'] = (isset($_POST['batch_reference']))? $_POST['batch_reference']:'';
                        $this->data['batch_lines'] = $batch_lines;
                        $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                        $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                        $this->data['agent'] = $_POST['Agent'];
                        $this->data['office'] = $_POST['Office'];
                        $this->data['mode'] = $_POST['mode'];
                        $this->data['designation'] = $_POST['designation'];
                        $this->data['nif'] = $_POST['Nif'];
                        $this->data['accountnane'] = $account_name;
                        $this->data['total_amount'] = $_POST['total_amount'];
                        
                        $_POST['total_amount'] = str_replace(' ', '', $_POST['total_amount']);
                        $this->data['total_amount'] = str_replace(',','.', $_POST['total_amount']);
                        
                        $this->data['commission'] = $_POST['Commission'];
                        $this->data['devise_commission'] = isset($_POST['devise_commision']) ? $_POST['devise_commision'] : 'CDF';
                        $this->data['tva'] = $_POST['tva'];
                        $this->data['totalpaid'] = $_POST['total_topaid'];
                        $this->data['cGuichet'] =  $_POST['cGuichet'];
                        
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3', $this->data);
                        
                }
                elseif($obj == "batch_recover_start")
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_'.$obj, $this->data);
                }
                elseif($obj == "extractbls")
                {
                        set_time_limit(250);
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_agence_comptes_array("'CGU'", $agence);
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";
                        
                        $_POST['Logirefid'] = $this->integration_model->generate_unique_reference().$this->session->userdata('user_id');
                        
                        $client = $this->logiref_model->get_clients_by_nif($_POST['Nif']);
                        $_POST['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                        
                        
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_payments($credentials);
                        
                        if($response ==  "E514" || $response == "E404" ||  $response == "E44" || $response == "E501" || $response == "E000"):
                                
                                echo $response; die;
                        else :
                                $this->data['lot'] = $response;
                                $this->data['office'] = $_POST['Office'];
                                $this->data['cGuichet'] = $_POST['cGuichet'];
                                $Logirefid = $this->data['Logirefid'] = $_POST['Logirefid'];
                                $this->data['bulletins'] = $this->bulletins_model->get_bulletins_retrieved_by_logiredid($Logirefid);
                                #var_dump($this->data['bulletins']);die;
                                $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['step'] = 0;
                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_recover_step_1', $this->data);
                                
                        endif;
                }
                elseif($obj == "getquittance")
                {
                        $user = $this->session->userdata('user_id');
                        $credentials = $this->users_model->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        #initialisation
                        $apidata = array();
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);
                        
                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                        {
                                $quittance = $bulletin->Pdfcontent_18;
                                echo $quittance;
                        }
                        else
                        {
                                $declaration = json_decode($bulletin->Results_13);
                                $apidata['ReceiptSerial'] = $declaration->receiptSerial;
                                $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                                $apidata['ReceiptDate'] = $declaration->receiptDate;
                                $apidata['Office'] = $bulletin->Office_6;
                                $apidata['Account'] = $this->session->userdata('account_id');
                                $apidata['Paiementid'] = $bl;
                                $apidata['User'] = $this->session->userdata('user_id');
                                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                                $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
								$apidata['code_bank'] = (isset($encrytions->codebank))? $encrytions->codebank:'';
                                
                                $response = $this->curl_model->call_dgda_quittance($apidata);
                                
                                if($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000")
                                {
                                        echo $response;
                                }
                                else
                                {
                                        $bulletin = $this->integration_model->get_paiement_sydonia($bl);

                                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                                        {
                                                $quittance = $bulletin->Pdfcontent_18;
                                                echo $quittance;
                                        }
                                        else
                                        {
                                                echo "E406";
                                        }
                                }
                        }
                       
                }
                elseif($obj == "_batch_2")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integration_model->get_paiement_sydonia($id);
                        $encaissement = $this->data_model->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        
                        $agence_src= $_SESSION['Logiref_guichet'];
                                
                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        $info = $encaissement->Notereference_30;
                        
                        $guichet = $this->session->userdata("Logiref_guichet");
                        $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $instructions2 = array();

                        $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");

                        
                        $taxes = array();
                        $taxesPaid = $info['taxesPaid'];
                        if(is_array($taxesPaid) && count($taxesPaid) > 0)
                        {
                                $taxes = $taxesPaid;
                        }
                        elseif(is_object($taxesPaid) && $taxesPaid !="")
                        {
                                $taxes[] = $taxesPaid;
                        }

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logiref_model->get_dropdown("type_recette");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_2', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert alert-danger text-white">Error!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();
                                
                                $data = $_POST;
                                if(isset($_POST['bl_credit']))
                                {
                                        $lot = 'credit';
                                        unset($data['bl_credit']);
                                }
                                $data['Status_2'] = 0;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');

                                $infos = $data['Infos'];
                                
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                                $data['Beneficaire_15'] = 'DGDA';

                                # SAVE PAYMENT
                                
                                $results = $infos;
                                $prefix = 1;
                                $logirefid = $data['Logirefid_4'];
                                $end_execution = NULL;
                        
                                $taxesPaid = unserialize($results['taxesPaid']);
                                
                                if(is_array($taxesPaid) && count($taxesPaid) > 0)
                                {
                                        $taxes = $taxesPaid;
                                }
                                elseif(is_object($taxesPaid) && $taxesPaid !="")
                                {
                                        $taxes[] = $taxesPaid;
                                }
                                
                                #Serie et numero du bulletin
                                $noteid = isset($data['Noteid_26']) ? $data['Noteid_26'] : "";
                                
                                $bulletin = $this->integration_model->get_paiement_sydonia($data['Sydonia_44']);
                                
                                $pkeys_tresor = array();
                                $pkeys_propre = array();

                                $type_recettes = $this->logiref_model->get_dropdown("type_recette");

                                $frais_bcc = 0;

                                foreach($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $amount = $taxe->taxeAmount * 0.0005;

                                                $frais_bcc = $amount + $frais_bcc;
                                        }

                                }
                                $data['frais_bcc'] = $frais_bcc;
                                
                                if(isset($_POST['total_amount']) && $_POST['total_amount'] != "")
                                {
                                        $total_amount = $_POST['total_amount'];
                                }
                                
                                unset($data['total_amount']);
                                # Comptabilisation
                                # Prmiere partie - 
                                $Missmatch['Missmatch_32'] = 0;
                                
                                $agence_src= $_SESSION['Logiref_guichet'];
                                
                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                                
                                $data['paiement_key'] = $data['Logirefid_4']."".$data['Noteid_26']."".$data['Sydonia_44'];
								
								# The value to know whether the customer account is exempted from bcc fees or not
								$frais_bcc_exempt = isset($infos['fraisbcc']) ? $infos['fraisbcc'] : "";

                                $instruction = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes, $frais_bcc_exempt);
                                
                                # Frais BCC
                                if(!empty($instruction))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        
                                        $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instruction, $data['Logirefid_4'], $priority);
                                        
                                }
                                unset($data['frais_bcc']);
                                unset($data['paiement_key']);
                                
                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT
                                $guichet = $this->session->userdata("Logiref_guichet");
                                $agence_src= $_SESSION['Logiref_guichet'];
                                
                                $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                                $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                #Taxes comptes
                                unset($comptes);
                                $comptes = array();
                                $instructions = array();
                                
                                $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                                
                                $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");
                                
                                foreach ($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $pkeys_tresor[] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$bulletin->Year_5;
                                        }   
                                        else
                                        {
                                                $pkeys_propre[] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$bulletin->Year_5;
                                        }
                                }
                                
                                if(!empty($pkeys_tresor))
                                {
                                        $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                        $pkeys_tresor_exist = $this->encaissement_model->check_bulletin_tresor($pkeys_tresor);
                                        
                                        if(!empty($pkeys_tresor_exist))
                                        {
                                                foreach ($pkeys_tresor_exist as $row)
                                                {
                                                        $pkeys_tresor_exist[]= $row->Paiementkey_52;
                                                } 
                                        }
                                }
                                if(!empty($pkeys_propre))
                                {
                                        $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                        $pkeys_propre_exist = $this->encaissement_model->check_bulletin_propres($pkeys_propre);
                                        
                                        if(!empty($pkeys_propre_exist))
                                        {
                                                foreach ($pkeys_propre_exist as $row)
                                                {
                                                        $pkeys_propre_exist[]= $row->Paiementkey_52;
                                                } 
                                        }
                                }
                                
                                $data_tresor = array();
                                $data_propre = array();
                                
                                foreach($taxes as $taxe)
                                {
                                        $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Paiementkey_52'] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$bulletin->Year_5;
                                        
                                        $pid = "";

                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_tresor_exist))
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $data_tresor[] = $data;
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else if(isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }

                                        $prefix++;
                                }
                                
                                $return = false;
                                
                                if(!empty($data_tresor))
                                {
                                        $return = $this->encaissement_model->save_payment_tresor_dgda($data_tresor, NULL);
                                }
                                if(!empty($data_propre))
                                {
                                        $return = $this->encaissement_model->save_payment_propres_dgda($data_propre, NULL);
                                }       
                                 
                                if($return)
                                {
                                        if(!empty($instructions))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;

                                                $end_execution = $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                                                unset($instructions);
                                        }

                                        if($end_execution)
                                        {
                                                $bl_data['Status_2'] = '2';
                                                $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
                                        }

                                        echo $data['Sydonia_44'];
                                }
                                else
                                {
                                        if(!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist))
                                        {
                                                #Payment exist already
                                                echo 'E500';
                                        }
                                        else
                                        {
                                                echo 0;
                                        }
                                }
                        }
                }
                elseif($obj == "validate")
                {
                        $data = $_POST;
                        $code = '';
                        
                        if(isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "")
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                {
                                        $agence_src= $_SESSION['Logiref_guichet'];
                        
                                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                                        
                                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                                        
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        
                                        

                                        #Invocation of the api transfer
                                        @set_time_limit(300);

                                        $response = $this->curl_model->call_bank_virement($data);
                                        
                                        $return = json_decode($response, true);
										
                                        $id = $_POST['Sydonia_44'];

                                        if(isset($return['response']) && $return['response'] == "200")
                                        {
                                                $code = 200;
                                                
                                                $paiement = $this->encaissement_model->get_paiement_tresor_bl($_POST['Sydonia_44']);
                                                $result = json_decode($paiement->Notereference_30, true);

                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
												
                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Notereference_30'] = json_encode($result);


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                                                if($tid)
                                                {
                                                        $info['lien_id'] = "";
                                                        $info['date_lien'] = "";
                                                        $bl_data['Reservation_34'] = json_encode($info);
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->integration_model->update_bulletin($bl_data, $id);
                                                }
                                        }
                                        elseif(isset($return['response']) && $return['response'] !="")
                                        {
                                                $info['lien_id'] = "";
                                                $info['date_lien'] = "";
                                                $bl_data['Reservation_34'] = json_encode($info);
                                                $bl = $this->integration_model->update_bulletin($bl_data, $id);
                                                $code = $return['response'];
                                        }
                                        
                                        
                                }
                                if(isset($id) && $id > 0) 
                                {
                                        $retour = array('code'=>$code, 'id'=>$id);
                                        echo json_encode($retour);
                                }
                                else
                                {
                                        echo 0;
                                }
                                
                        }
                }
                elseif($obj == "validate_batch")
                {
                        $bulletins = $_POST['bulletin_id'];
                        
                        $validation = array();
                        
                        foreach($bulletins as $row)
                        {
                                $bulletin = $this->integration_model->get_bulletin_info($row);
                                
                                if($bulletin->Status_2 != 5 && $bulletin->Status_2 != 3)
                                {
                                        $data['Priority'] = 1;
                                        $data['Sydonia_44'] = $row;
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Account_3'] = $this->session->userdata('account_id');

                                        $agence_src= $_SESSION['Logiref_guichet'];

                                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                                        #Invocation of the api transfer
                                        @set_time_limit(300);

                                        $response = $this->curl_model->call_bank_virement($data);

                                        $return = json_decode($response, true);

                                        $validation[$row]['response'] = $return['response']; 


                                        $id = $row;

                                        if(isset($return['response']) && $return['response'] == "200")
                                        {
                                                $code = 200;

                                                $paiement = $this->encaissement_model->get_paiement_tresor_bl($id);
                                                $result = json_decode($paiement->Notereference_30, true);

                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Notereference_30'] = json_encode($result);


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissement_model->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissement_model->update_payment_propres_dgda($data_to_validate, $id);

                                                if($tid)
                                                {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->integration_model->update_bulletin($bl_data, $id);
                                                }
                                        }
                                }
                        }
                        
                        $result = json_encode($validation);

                        echo $result;
                }
                elseif($obj == "bulletin")
                {
                        $logirefid = $id;
                        $type = $arg;
                        
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata('account_id');
                                
                        $data['Designation_23'] = $_POST['designation'];
						
                        $data['Amount_12'] = str_replace(' ', '', $_POST['Amount']);
                        $data['Amount_12'] = str_replace(',','.', $data['Amount_12']);
                        
                        $data['Amount_25'] = str_replace(' ', '', $_POST['Total_amount']);
                        $data['Amount_25'] = str_replace(',','.', $data['Amount_25']);
                        
                        $data['Commission_26'] = str_replace(' ', '', $_POST['Commission']);
                        $data['Commission_26'] = str_replace(',','.', $data['Commission_26']);
                        
						
                        $data['Devise_27'] = $_POST['devise'];
                        $data['Year_5'] = $_POST['Year'];
                        $data['Serie_7'] = $_POST['Series'];
                        $data['Number_8'] = $_POST['Number'];
                        $data['Agent_10'] = $_POST['Agent'];
                        $data['Office_6'] = $_POST['Office'];
                        $data['Nif_9'] = $_POST['Nif'];
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Bank_11'] = $_POST['Bank'];
                        $data['User_15'] = $this->session->userdata('user_id');
                        $data['Mode_30'] = $_POST['Mode'];
                        
                        $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                        $data['Account_28'] = $_POST['bank_account'];
                        $data['Account_24'] = $_POST['Compte_guichet'];
                        $data['Devise_29'] = $_POST['Devise_account'];
                        
                        $data['Devise_27'] = $_POST['Devise_amount'];
                        $data['Reference_19'] = isset($_POST['reference']) ? $_POST['reference'] : "";;
                        $data['Taux_31'] = $_POST['Taux'];
                        $data['Accountholder_33'] =$_POST['account_name'];
                        
                        
                        if(isset($_POST['pourcompte'])) $paiementinfo['pourcompte'] = $_POST['pourcompte'];
                        
                        if(isset($_POST['tva'])) $paiementinfo['tva'] = $_POST['tva'];
						if(isset($_POST['fraisbcc'])) $paiementinfo['fraisbcc'] = $_POST['fraisbcc'];
                        if(isset($_POST['DateL'])) $paiementinfo['DateL'] = $_POST['DateL'];
                        if(isset($_POST['refcredit'])) $paiementinfo['refcredit'] = $_POST['refcredit'];
                        
                        if(isset($paiementinfo))
                        {
                                $data['Paiementinfo_35'] = json_encode($paiementinfo);	
                        }
                        
                        if(isset($_POST['bl_credit']) && $_POST['bl_credit'] !="")
                        {
                                $data['Lot_22'] = 'credit';
                        }
                        
                        if($type =='reservation')
                        {
                                $info['lien_id'] = $_SESSION['lien_id'];
                                $info['date_lien'] = $_SESSION['date_lien'];
                        }
                        else
                        {
                                $info['lien_id'] = "";
                                $info['date_lien'] = "";
                        }
                        
                        $data['Reservation_34'] = json_encode($info);
                        
                        $id = $this->integration_model->save_bulletin($data, NULL);
                        
                        if($id != "")
                        {
                                $data = array();

                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Agence_20']=$_SESSION['Logiref_agence'];
                                $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                $data['Mode_19'] = $_POST['Mode'];
                                $data['Typerecette_17'] = $_POST['Year'].$_POST['Series'].$_POST['Number'];
                                $data['Service_16'] = $_POST['Office'];
                                $data['Devise_34'] = $_POST['Devise_account'];
                                
                                if(isset($paiementinfo['tva']))
                                {
                                        $data['tva'] = $paiementinfo['tva'];
                                }
                                else
                                {
                                        $data['tva'] = "";
                                }
                                if(isset($paiementinfo['fraisbcc']))
                                {
                                        $data['fraisbcc'] = $paiementinfo['fraisbcc'];
                                }
                                else
                                {
                                        $data['fraisbcc'] = "";
                                }
                                $data['Montant_11'] = str_replace(' ', '', $_POST['Amount']);
                                $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);
								
                                $data['Devise_12'] = $_POST['devise'];
                                $data['Compte_33'] = $_POST['bank_account'];
                                $data['Noteid_26'] = $_POST['Year'].$_POST['Series'].$_POST['Number'];
                                $data['Notedate_27'] = '';
								
                                $data['Commission_23'] = $_POST['Commission'];
								
                                $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                                $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);
								
                                $data['Devise_24'] = $_POST['Devise_commission'];
                                $data['Nif_13'] = $_POST['Nif'];

                                $agence_src= $_SESSION['Logiref_guichet'];

                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                switch ($case)
                                {
                                        case "case_1": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                break;
                                        case "case_2": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                break;
                                        case "case_3": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                break;
                                        case "case_4": 
                                                $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                break;
                                        default: 
                                                break;
                                }
                                
                                if(!empty($instructions1))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 0; 
                                        $this->comptabilisation_model->save_first_instructions_dgda($id, $data, $instructions1, $logirefid, $priority);
                                }
                        }
                        
                        return $id;
                }
                elseif($obj == "cbs_return")
                {
                        if($id !="" && $arg != "")
                        {
                                # Data to save in the in logiref_cbs_return
                                $data['Date_1']= gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata('account_id');
                                $data['Sydonia_5'] = $id;
                                $data['Result_6'] = $arg;

                                # Save in logiref_cbs_return
                                $this->integration_model->save_cbs_return($data, NULL);
                        }
                }
                elseif($obj == "batch_bulletin")
                {
                        $reference_op = isset($_POST['refOp']) ? $_POST['refOp'] : "";
                        
                        $batch_line = $this->integration_model->check_batch_bulletin_sydonia($reference_op);
                        
                        if(empty($batch_line))
                        {
                                $logirefid = $id;
                                $type = $arg;

                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata('account_id');

                                $data['Office_7'] = $_POST['Office'];
                                $data['Nif_8'] = $_POST['Nif'];
                                $data['Agent_9'] = $_POST['Agent'];
                                $data['Bank_10'] = $_POST['Bank'];

                                $data['Amount_11'] = str_replace(' ', '', $_POST['total_amount']);
                                $data['Amount_11'] = str_replace(',','.', $data['Amount_11']);

                                $data['Devise_12'] = 'CDF';

                                $data['User_13'] = $this->session->userdata('user_id');
                                $data['Lot_14'] = $logirefid;
                                $data['Designation_15'] = $_POST['designation'];

                                $data['Account_16'] = $_POST['account'];
                                $data['Devise_17'] = $_POST['cdevise'];
                                $data['Accountholder_18 '] = $_POST['account_name'];
                                $data['Mode_19'] = $_POST['mode'];

                                $data['Commission_20'] = str_replace(' ', '', $_POST['Commission']);
                                $data['Commission_20'] = str_replace(',','.', $data['Commission_20']);

                                $data['Devise_21'] = $_POST['devise_commision'];

                                $data['Total_23'] = str_replace(' ', '', $_POST['total_topaid']);
                                $data['Total_23'] = str_replace(',','.', $data['Total_23']);

                                $bulletins['years']= $_POST['years'];
                                $bulletins['serials']= $_POST['serials'];
                                $bulletins['amounts']= $_POST['amounts'];

                                $data['Bulletins_22'] = json_encode($bulletins);

                                $data['Agence_24'] = $_SESSION['Logiref_guichet'];

                                $data['Refop_25'] = $_POST['refOp'];

                                $data['Typeaccount_28'] = $_POST['account_type'];

                                # The variable type permits to distinguish if the bulletin is paid with 
                                # an current account or an internal account
                                if($type =='reservation')
                                {
                                        $info['lien_id'] = $_SESSION['lien_id'];
                                        $info['date_lien'] = $_SESSION['date_lien'];
                                }
                                else
                                {
                                        $info['lien_id'] = "";
                                        $info['date_lien'] = "";
                                }

                                $data['Taux_26'] = str_replace(' ', '', $_POST['taux']);
                                $data['Taux_26'] = str_replace(',','.', $data['Taux_26']);

                                $data['Reservation_27'] = json_encode($info);

                                $id = $this->integration_model->save_batch_bulletin($data, NULL);

                                if($id != "")
                                {
                                        $data = array();

                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Agence_20']=$_SESSION['Logiref_agence'];
                                        $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                        $data['Mode_19'] = $_POST['mode'];
                                        $data['Typerecette_17'] = $_POST['refOp'];
                                        $data['Service_16'] = $_POST['Office'];
                                        $data['Devise_34'] = $_POST['cdevise'];

                                        if(isset($_POST['tva']) && $_POST['tva'] > 0)
                                        {
                                                $data['tva'] = $_POST['tva'];
                                        }
                                        else
                                        {
                                                $data['tva'] = "";
                                        }

                                        $data['Montant_11'] = str_replace(' ', '', $_POST['total_amount']);
                                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                                        $data['Devise_12'] = 'CDF';
                                        $data['Compte_33'] = $_POST['account'];
                                        $data['Noteid_26'] = $_POST['refOp'];
                                        $data['Notedate_27'] = '';

                                        $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                                        $data['Devise_24'] = $_POST['devise_commision'];
                                        $data['Nif_13'] = $_POST['Nif'];

                                        $agence_src= $_SESSION['Logiref_guichet'];

                                        $case = $this->comptabilisation_model->get_use_case($data);
                                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                                        switch ($case)
                                        {
                                                case "case_1": 
                                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                                        break;
                                                case "case_2": 
                                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                                        break;
                                                case "case_3": 
                                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                                        break;
                                                case "case_4": 
                                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                                        break;
                                                default: 
                                                        break;
                                        }

                                        if(!empty($instructions1))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 0; 
                                                $this->comptabilisation_model->save_first_instructions_dgda($logirefid, $data, $instructions1, $logirefid, $priority);
                                        }
                                }

                                return $id;
                        }
                        else
                        {
                                return 1;
                        }
                }
                elseif($obj == "update_batch")
                {
                        $batch_data['Status_2'] = '2';
                        $id = $this->integration_model->update_batch_bulletin($batch_data, $id);
                        
                        return $id; 
                }
                elseif($obj == "batch_reservation")
                {
                        $data = array();
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Agence_20']=$_SESSION['Logiref_agence'];
                        $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                        $data['Mode_19'] = $_POST['mode'];
                        $data['Typerecette_17'] = 'OP'.$id;
                        $data['Devise_34'] = 'CDF';

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ','',$_POST['total_topaid']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);

                        $data['Devise_12'] = $_POST['cdevise'];
                        $data['Compte_33'] = $_POST['account'];
                        $logirefid = $data['Noteid_26'] = $id;


                        //Formatting amount
                        $data['Commission_23'] = str_replace(' ','',$_POST['Commission']);
                        $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);

                        $data['Devise_24'] = $_POST['devise_commision'];
                        $data['Nif_13'] = $_POST['Nif'];

                        $agence_src= $_SESSION['Logiref_guichet'];

                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        break;
                        }

                        if(!empty($instructions1))
                        {
                                # priority for integrating the counting in cbs
                                $priority = 0; 
                                $this->comptabilisation_model->save_instructions($id, $data, $instructions1, $logirefid, $priority);
                        }

                        return $id;
                }
                elseif($obj == "save_batch")
                {
                        # Save payment
                        # Validate payment form 
                    
                        $data = array();
                        $data_id_paiement = array();
                        $prefix = 1;

                        $end_execution = NULL;

                        $Missmatch['Missmatch_32'] = 0;

                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");

                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");
                        
                        $payments = $this->bulletins_model->get_bulletins_by_logiredid($_POST['batch_reference']);
                        
                        $commission = isset($_POST['commission']) ? $_POST['commission'] : 0;
                        $devise_commission = isset($_POST['devise_commission']) ? $_POST['devise_commission'] : 'CDF';
                        
                        $return = 0;
                        
                        foreach($payments as $row)
                        {
                                $encaissement = $this->data_model->sydonia_migrate_bl($row->Id_0);

                                $agence_src= $_SESSION['Logiref_guichet'];

                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);

                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, "DGDA");

                                $data['Compte_33'] = isset($row->Account_28) ? $row->Account_28 : "";
                                $amount = $data['Montant_11'];

                                $client = $this->logiref_model->get_clients_by_nif($encaissement->Nif_13);
                                $data['Designation_14'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 : ''; 

                                $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                $data['Commission_23'] = $commission;
                                $data['Devise_24'] = $devise_commission;

                                if(isset($data['frais_bcc'])) unset($data['frais_bcc']);
                                if(isset($data['CGU'])) unset($data['CGU']);
                                if(isset($data['Total'])) unset($data['Total']);
                                if(isset($data['Reservation_34'])) unset($data['Reservation_34']);

                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT
                                $guichet = $this->session->userdata("Logiref_guichet");
                                $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                                $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                $info = $encaissement->Notereference_30;

                                $taxesPaid = $info['taxesPaid'];
                                
                                if(is_array($taxesPaid) && count($taxesPaid) > 0)
                                {
                                        $taxes = $taxesPaid;
                                }
                                elseif(is_object($taxesPaid) && $taxesPaid !="")
                                {
                                        $taxes = array();
                                        
                                        $taxes[] = $taxesPaid;
                                }
                                
                                $logirefid = $_POST['batch_reference'];
                                
                                #Serie et numero du bulletin
                                $noteid = $data['Typerecette_17'];

                                unset($data['CGU']);
                                unset($data['Total']);
                                
                                $pkeys_tresor = array();
                                $pkeys_propre = array();
                                
                                foreach ($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $pkeys_tresor[] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$row->Year_5;
                                        }   
                                        else
                                        {
                                                $pkeys_propre[] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$row->Year_5;
                                        }
                                }

                                if(!empty($pkeys_tresor))
                                {
                                        $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                        $pkeys_tresor_exist = $this->encaissement_model->check_bulletin_tresor($pkeys_tresor);

                                        if(!empty($pkeys_tresor_exist))
                                        {
                                                foreach ($pkeys_tresor_exist as $ligne)
                                                {
                                                        $pkeys_tresor_exist[]= $ligne->Paiementkey_52;
                                                } 
                                        }
                                }
                                if(!empty($pkeys_propre))
                                {
                                        $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                        $pkeys_propre_exist = $this->encaissement_model->check_bulletin_propres($pkeys_propre);

                                        if(!empty($pkeys_propre_exist))
                                        {
                                                foreach ($pkeys_propre_exist as $ligne)
                                                {
                                                        $pkeys_propre_exist[]= $ligne->Paiementkey_52;
                                                } 
                                        }
                                }

                                $data_tresor = array();
                                $data_propre = array();
                                
                                $frais_bcc = 0;

                                foreach($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $amount = $taxe->taxeAmount * 0.0005;

                                                $frais_bcc = $amount + $frais_bcc;
                                        }
                                }
                                
                                $data['frais_bcc'] = $frais_bcc;
                                
								# The value to know whether the customer account is exempted from bcc fees or not
                                $frais_bcc_exempt = isset($_POST['fraisbcc']) ? $_POST['fraisbcc'] : "";
								
								
                                # Comptabilisation
                                # Prmiere partie - 
                                $Missmatch['Missmatch_32'] = 0;
                                
                                $data['paiement_key'] = $logirefid."".$data['Noteid_26']."".$data['Sydonia_44'];

                                # Instructions for the BCC fees
                                $instruction = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes, $frais_bcc_exempt);
                                
                                # Frais BCC
                                if(!empty($instruction))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        
                                        $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instruction, $logirefid, $priority);
                                        
                                }
                                unset($data['frais_bcc']);
                                unset($data['paiement_key']);
                                
                                $comptes = array();
                                $agence_src= $_SESSION['Logiref_guichet'];
                                $instructions = array();

                                $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                                foreach($taxes as $taxe)
                                {
                                        $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Commission_23'] = $commission;
                                        $data['Devise_24'] = 'CDF';
                                        $data['Paiementkey_52'] = $data['Noteid_26']."".$taxe->taxeCode."".$data['Sydonia_44']."".$data['Service_16']."".$data['Notedate_27'].$row->Year_5;
                                        $data['Status_2'] = '1';

                                        $prefix++;

                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_tresor_exist))
                                                {   
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $data_tresor[] = $data;
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else if(isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else
                                        {
                                                if(!in_array($data['Paiementkey_52'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $data_propre[] = $data;

                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                }
                                
                                $return = false;
                                        
                                if(!empty($data_tresor))
                                {
                                        $return = $this->encaissement_model->save_payment_tresor_dgda($data_tresor, NULL);
                                }
                                if(!empty($data_propre))
                                {
                                        $return = $this->encaissement_model->save_payment_propres_dgda($data_propre, NULL);
                                }

                                if($return)
                                {
                                        if(!empty($instructions))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                $end_execution = $this->comptabilisation_model->save_instructions($row->Id_0, $data, $instructions, $logirefid, $priority);
                                                unset($instructions);
                                        }

                                        if($end_execution)
                                        {
                                                $commission = str_replace(' ','',$commission);
                                                $commission = str_replace(',','.',$commission);

                                                $frais_bcc = str_replace(' ','',$frais_bcc);
                                                $frais_bcc = str_replace(',','.',$frais_bcc);

                                                $amount_bl = str_replace(' ','',$row->Amount_12);
                                                $amount_bl = str_replace(',','.',$amount_bl);


                                                $bl_data['Status_2'] = '2';
                                                $bl_data['Commission_26'] = $commission;
                                                $tva = $commission * 0.16;
                                                $bl_data['Devise_27'] = $devise_commission;
                                                $bl_data['Amount_25'] = $commission + $tva + $frais_bcc + $amount_bl;

                                                $return = $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);

                                                if($return)
                                                {
                                                        $batch_lines = $this->integration_model->get_bulletins_batch_by_reference($_POST['batch_reference']);
                                                        $this->save("update_batch", $batch_lines->Id_0);
                                                }
                                        }
                                }
                        }

                        if($return)
                        {
                                echo $row->Id_0;
                        }
                        else
                        {
                                if(!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist))
                                {
                                        #Payment exist already
                                        echo 'E500';
                                }
                                else
                                {
                                        echo 0;
                                }
                        }
                }
                elseif($obj == "save_batch_bl_retrieved")
                {
                        # Save payment
                        # Validate payment form 
                    
                        $data = array();
                        $data_id_paiement = array();
                        $prefix = 1;

                        $end_execution = NULL;

                        $Missmatch['Missmatch_32'] = 0;

                        $type_recettes = $this->logiref_model->get_dropdown("type_recette");

                        $beneficiaires = $this->stakeholders_model->get_dropdown("beneficiaires");
                        
                        $payments = $this->bulletins_model->get_bulletins_retrieved_by_logiredid($_POST['batch_reference']);
                        
                        $commission = isset($_POST['commission']) ? $_POST['commission'] : 0;
                        $devise_commission = isset($_POST['devise_commission']) ? $_POST['devise_commission'] : 'CDF';
                        
                        $return = 0;
                        
                        foreach($payments as $row)
                        {
                                $encaissement = $this->data_model->sydonia_migrate_bl($row->Id_0);

                                $agence_src= $_SESSION['Logiref_guichet'];

                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);

                                $case = $this->comptabilisation_model->get_use_case($data);
                                $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, "DGDA");

                                $data['Compte_33'] = isset($row->Account_28) ? $row->Account_28 : "";
                                $amount = $data['Montant_11'];

                                $client = $this->logiref_model->get_clients_by_nif($encaissement->Nif_13);
                                $data['Designation_14'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 : ''; 

                                $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                $data['Commission_23'] = $commission;
                                $data['Devise_24'] = $devise_commission;

                                if(isset($data['frais_bcc'])) unset($data['frais_bcc']);
                                if(isset($data['CGU'])) unset($data['CGU']);
                                if(isset($data['Total'])) unset($data['Total']);
                                if(isset($data['Reservation_34'])) unset($data['Reservation_34']);

                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT
                                $guichet = $this->session->userdata("Logiref_guichet");
                                $compte_cpt = isset($comptes['Ebcdc']['CSO'][$data['Devise_12']]) ? $comptes['Ebcdc']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                                $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                $info = $encaissement->Notereference_30;

                                $taxesPaid = $info['taxesPaid'];
                                
                                if(is_array($taxesPaid) && count($taxesPaid) > 0)
                                {
                                        $taxes = $taxesPaid;
                                }
                                elseif(is_object($taxesPaid) && $taxesPaid !="")
                                {
                                        $taxes = array();
                                        
                                        $taxes[] = $taxesPaid;
                                }
                                
                                $logirefid = $_POST['batch_reference'];
                                
                                #Serie et numero du bulletin
                                $noteid = $data['Typerecette_17'];

                                unset($data['CGU']);
                                unset($data['Total']);
                                
                                $frais_bcc = 0;

                                foreach($taxes as $taxe)
                                {
                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD"))
                                        {
                                                $amount = $taxe->taxeAmount * 0.0005;

                                                $frais_bcc = $amount + $frais_bcc;
                                        }
                                }
                                
                                $data['frais_bcc'] = $frais_bcc;
                                
                                # Comptabilisation
                                # Prmiere partie - 
                                $Missmatch['Missmatch_32'] = 0;

                                # Instructions for the BCC fees
                                $instruction = $this->comptabilisation_model->get_instructions_frais_bcc_dgda($data, $comptes);
                                
                                # Frais BCC
                                if(!empty($instruction))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        
                                        $this->comptabilisation_model->save_instructions($data['Sydonia_44'], $data, $instruction, $data['Logirefid_4'], $priority);
                                        
                                }
                                unset($data['frais_bcc']);
                                
                                $comptes = array();
                                $agence_src= $_SESSION['Logiref_guichet'];
                                $instructions = array();

                                $comptes = $this->accounts_model->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                                foreach($taxes as $taxe)
                                {
                                        $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Commission_23'] = $commission;
                                        $data['Devise_24'] = $devise_commission;
                                        $data['Status_2'] = '1';
                                        $pid = "";

                                        $prefix++;

                                        if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $check_payement_tresor = $this->encaissement_model->check_bulletin_tresor($data['Sydonia_44'], $taxe->taxeCode, $noteid);
                                                
                                                if(empty($check_payement_tresor))
                                                {
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $pid = $this->encaissement_model->save_payment_tresor($data, NULL);
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else if(isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                $check_payement_propres = $this->encaissement_model->check_bulletin_propres($data['Sydonia_44'], $taxe->taxeCode, $noteid);
                                                
                                                if(empty($check_payement_propres))
                                                {
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $pid = $this->encaissement_model->save_payment_propres($data, NULL);
                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                        else
                                        {
                                                $check_payement_propres = $this->encaissement_model->check_bulletin_propres($data['Sydonia_44'], $taxe->taxeCode, $noteid);
                                                
                                                if($check_payement_propres)
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $pid = $this->encaissement_model->save_payment_propres($data, NULL);

                                                        $instruction = $this->comptabilisation_model->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                }

                                if(!empty($instructions))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        $end_execution = $this->comptabilisation_model->save_instructions($row->Id_0, $data, $instructions, $_POST['batch_reference'], $priority);
                                        unset($instructions);
                                }

                                if($end_execution)
                                {
                                        $commission = str_replace(' ','',$commission);
                                        $commission = str_replace(',','.',$commission);
                                        
                                        $frais_bcc = str_replace(' ','',$frais_bcc);
                                        $frais_bcc = str_replace(',','.',$frais_bcc);
                                        
                                        $amount_bl = str_replace(' ','',$row->Amount_12);
                                        $amount_bl = str_replace(',','.',$amount_bl);
                                        
                                        
                                        $bl_data['Status_2'] = '2';
                                        $bl_data['Commission_26'] = $commission;
                                        $tva = $commission * 0.16;
                                        $bl_data['Devise_27'] = $devise_commission;
                                        $bl_data['Amount_25'] = $commission + $tva + $frais_bcc + $amount_bl;
                                        
                                        $return = $this->integration_model->update_bulletin($bl_data, $data['Sydonia_44']);
                                        
                                }
                        }

                        echo $return;
                }
                elseif($obj == "delete")
                {
                        
                        $pid = 0;
                        $data['Status_2'] = 0;
                        // supression du bulletin 
                        $idBL = $this->integration_model->delete_bulletin($data, $id);
                        
                        // supression de l'eclatement 
                        if($idBL > 0)
                        {
                            $pid = $this->encaissement_model->delete_paiement_tresors_dgda($data, $id);
                            $pid = $this->encaissement_model->delete_paiement_propres_dgda($data, $id);
                        }
                      
                        // supression des écritutes du bulletin 
                        if($pid > 0)
                        {
                            
                            $sup = $this->comptabilisation_model->delete_instruction_dgda($data, $id);
                            
                        }
                        
                        #Return
                        echo $idBL;
                        die;
                }
                elseif($obj == "delete_regul")
                {
                        
                        $pid = 0;
                        $data['Status_2'] = 6;
                        // supression du bulletin 
                        $idBL = $this->integration_model->delete_bulletin($data, $id);
                        
                        // supression de l'eclatement 
                        if($idBL > 0)
                        {
                            $pid = $this->encaissement_model->delete_paiement_tresors_dgda($data, $id);
                            $pid = $this->encaissement_model->delete_paiement_propres_dgda($data, $id);
                        }
                      
                        // supression des écritutes du bulletin 
                        if($pid > 0)
                        {
                            
                            $sup = $this->comptabilisation_model->delete_instruction_dgda($data, $id);
                            
                        }
                        
                        #Return
                        echo $idBL;
                        die;
                }
                elseif($obj == "delete_batch")
                {
                        $pid = 0;
                        $batch_ref = $arg;
                        $data['Status_2'] = 0;

                        // supression du bulletin 
                        $idBL = $this->integration_model->delete_batch_bulletin($data, $id);
                        
                        // supression de l'eclatement 
//                        if($idBL > 0)
//                        {
//                            $pid = $this->encaissement_model->delete_paiement_tresors_dgda($data, $id);
//                            $pid = $this->encaissement_model->delete_paiement_propres_dgda($data, $id);
//                        }
                      
                        // supression des écritutes du bulletin 
                        if($pid > 0)
                        {
                            
                            $sup = $this->comptabilisation_model->delete_batch_instruction_dgda($data, $batch_ref);
                            
                        }
                        
                        #Return
                        echo $idBL;
                        die;
                }
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                 elseif($obj == "validate_batchpaiments")
                {
                        $error = '';
                        if($_POST['Logirefid']=='0' || $_POST['Logirefid']=='') $error = '<div class="alert alert-danger text-white">Le lot ne peut pas &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        return $error;
                }
                elseif($obj == "get_commission")
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }
                        
//                      //Montant total
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;
                        
                        if($cdata['devise'] == $oDeivise)
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'];
                        }
                        else if($cdata['devise'] == 'USD')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']*$taux['Dollar_4']);
                        }
                        else if(result[1] == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']/$taux['Dollar_4']);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
                        
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar; exit;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */