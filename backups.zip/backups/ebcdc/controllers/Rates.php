<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rates extends MY_Controller {
        /*
         * Presentation: gestion des taux de change
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('list','taux','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'rates';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('main/main_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model('logiref/logiref_model');
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'rates';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "taux")
                {
                        $this->data("default_values_new_taux");
                        $this->data("set_exchange_rates");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_taux', $this->data); 
                }
                elseif($obj == "list") 
                {
                        $this->load->model($this->module.'/data_model');
                        $this->data['agences'] = $this->branches_model->get_dropdown('agences');
                        $this->data['taux'] = $this->rates_model->get_taux();
                        $cumules = $this->data_model->get_rates_by_day();
                        $cumulous = $this->data_model->get_month_of_rates();
                        $this->data['chart'] = $this->data_model->get_rates_of_last_days($cumules, $cumulous);
                        $this->data("set_exchange_rates");
                       
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/taux', $this->data);
                }
                elseif($obj == "taux_filter") 
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown('agences');
                        $start = $this->input->post('start');
                        $end = $this->input->post('end');
                        $agence = $this->input->post('agence');
                        $this->data['taux'] = $this->rates_model->get_taux_by_filter($agence, $start, $end);
                        $this->load->model('MY_Main');
			$this->load->model('main/main_model');
			$this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == 'taux')
                {
                        if($_POST['usd']=='0' || $_POST['usd']=='')
                        {
                                $data_return['msg'] = '<div class="alert alert-danger text-white">ERROR! Valeurs incorrectes...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $return = json_encode($data_return);
                                echo $return; 
                                die;
                        }
                        elseif($_SESSION['Logiref_role']!=4 && $_POST['action']!='Confirmer')
                        {
                                $data_return['msg'] = '<div class="alert alert-warning text-white">Vous ne pouvez pas publier un taux. Veuillez contacter la personne habilet&eacute;e &agrave; le faire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $return = json_encode($data_return);
                                echo $return;  
                                die;
                        }
                        else
                        {
                                $dollar = str_replace(' ','',$_POST['usd']);
                                $dollar = str_replace(',','.',$dollar);

                                $euro = str_replace(' ','',$_POST['eur']);
                                $euro = str_replace(',','.',$euro);



                                $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                                $data['Status_2']   =   1;
                                $data['Account_3']  =   $this->session->userdata('account_id');
                                $data['Dollar_4']   =   $dollar;
                                $data['Euro_5']     =   $euro;
                                $data['Rand_6']     =   1;
                                $data['Pound_7']    =   1;
                                $data['Agence_8']   =   $_SESSION['Logiref_agence'];
                                $data['Day_9']      =   gmdate('Y-m-d');
                                if($_POST['is_checker']==1 && $id != NULL)
                                {
                                        $data['Checkerid_11']=$this->session->userdata('user_id');

                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                }
                                else 
                                {
                                        $data['Makerid_10']=$this->session->userdata('user_id');
                                }
                                if(isset($_POST['id_taux']) && $_POST['id_taux'] != "")
                                {
                                        $id = $_POST['id_taux'];
                                }
                                #var_dump($data); die;

                                $cid = $this->rates_model->save_taux($data, $id);  

                                if($cid)
                                {
                                        $data_return = array();

                                        if($id != "")
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success text-white">Bravo! Modification enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                                $data_return['id'] = $id;
                                        }
                                        else
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $data_return['id'] = $id;
                                        }
                                        $return = json_encode($data_return);

                                        echo $return;

                                        $this->data("set_exchange_rates","noredirect");
                                        die;
                                }
                        }
                        
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                 # Exchange rates
                #
                ################################################################################
                elseif($obj == "default_values_new_taux")
                {
                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                if($bank['Checkerid_11']==0): 
                                        $this->data['id'] = $bank['Id_0']; 
                                else :
                                        $this->data['id'] = ''; 
                                        $this->data['reset'] = 1; 
                                endif;   
                                
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }
                        
                        $this->data['action'] = '...';
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }
                        
                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')
                                    
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif($obj == "set_exchange_rates")
                {
                        $this->rates_model->get_exchange_rates();
                }
                elseif($obj == "get_taux")
                {
                        $data['from_currency'] = 'USD';
                        $data['to_currency'] = 'CDF';
                        $data['type'] = 'TTS';
                        $data['note_number'] = isset($_POST['note_number']) ? $_POST['note_number'] : "";

                        $return = $this->curl_model->call_bank_exchange_rate($data);
			
                        $return = json_decode($return, true);
                        

                        if(isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                        {
                                $rate = $return['exchange_rate'];
                                $code = 200;
                                
                                $result['rate'] = $rate;
                                $result['code'] = $code;
                                
                                echo json_encode($result);
                        }
                        else 
                        {
                                $result['code'] = '0003';
                                
                                echo json_encode($result);
                        }
                        
                }
                elseif($obj == "get_rate_to_buy")
                {
                        # Retrieve the rate to buy 
                    
                        $data['from_currency'] = 'USD';
                        $data['to_currency'] = 'CDF';
                        $data['type'] = 'TTB';
                        $data['note_number'] = isset($_POST['note_number']) ? $_POST['note_number'] : "";

                        $return = $this->curl_model->call_bank_exchange_rate($data);
			
                        $return = json_decode($return, true);
                        

                        if(isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                        {
                                $rate = $return['exchange_rate'];
                                $code = 200;
                                
                                $result['rate'] = $rate;
                                $result['code'] = $code;
                                
                                echo json_encode($result);
                        }
                        else 
                        {
                                $result['code'] = '0003';
                                
                                echo json_encode($result);
                        }
                        
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */