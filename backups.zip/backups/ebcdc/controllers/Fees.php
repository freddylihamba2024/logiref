<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fees extends MY_Controller {
        /*
         * Presentation: gestion des commissions et autres frais bancaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('regles','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'fees';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model($this->module.'/fees_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/rates_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'fees';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "default")
                {
                        $data = array();
                        $data = $_POST;
                        $ar = $this->data('get_commission', $data);
                        
                        echo json_encode($ar);
                }
                elseif($obj == "regles") 
                {
                        $this->data['agences'] = $this->branches_model->get_dropdown("agences");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        if($_SESSION['Logiref_groupe']=='banks')
                        {
                            $this->data['regles'] = $this->fees_model->get_regles("rgle");
                        }
                        else
                        {
                            #var_dump('tres'); die;
                            $this->data['regles'] = $this->fees_model->get_regles();

                        }
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/regles', $this->data);
                }
                elseif($obj == "regle") 
                {
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries", "RGF");
                        $this->data['services'] = $this->logiref_model->get_dropdown("services",NULL,NULL,true);
                        $this->data['from'] = $arg;
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Regle");
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['priorite'] = $this->fees_model->priorites;
                        $this->data['regle'] = $this->fees_model->get_regle_info($id);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_regle', $this->data);
                }
                elseif($obj == "OBJ ") 
                {
                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "regle")
                {
                        $fields = array(
                                'Priorite_4' => 'priorite',
                                'Value_9' =>'value',
                                'Unite_10' => 'unite',
                                'Min_11' => 'min',
                                'Max_12' => 'max',
                                'Devise_13' => 'devise',
                        );
                        foreach ($fields as $field => $value) 
                        {
                                $data[$field] = $this->input->post($value); //On assigne les valeurs de input aux champs de la DB
                        }
                        
                        
                        $data['Value_9'] = str_replace(' ','',$data['Value_9']);
                        $data['Min_11'] = str_replace(' ','',$data['Min_11']);
                        $data['Max_12'] = str_replace(' ','',$data['Max_12']);
                        
                        $data['Value_9'] = str_replace(',','.',$data['Value_9']);
                        $data['Min_11'] = str_replace(',','.',$data['Min_11']);
                        $data['Max_12'] = str_replace(',','.',$data['Max_12']);
                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] ='1';
                        $data['Account_3'] = $this->session->userdata('account_id');
                        if(isset($_POST['service']) && $_POST['service'] !="") $data['Service_6'] = $this->input->post('service');
                        if(isset($_POST['guichet']) && $_POST['guichet'] !="") $data['Guichet_8'] = $this->input->post('guichet');
                        if(isset($_POST['recette']) && $_POST['recette'] !="") $data['Recette_7'] = $this->input->post('recette');
                        if(isset($_POST['beneficiaire']) && $_POST['beneficiaire'] !="") $data['Beneficiaire_5'] = $this->input->post('beneficiaire');
                        $data['Makerid_14']=$this->session->userdata('user_id');
                        if($_SESSION['Logiref_role']==1):
                                $data['Validation_16']='0000-00-00';
                                $data['Checkerid_15']=0;
                        else:
                                $data['Validation_16']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_15']=$this->session->userdata('user_id');
                        endif;      
                            
                        $rid = $this->fees_model->save_regle($data, $id); // Enregistre les donnees dans la bd
                    if ($rid): 
                        echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    else: 
                            echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_commission")
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
						
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->fees_model->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
						if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }
                        
//                      //Montant total
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;
                        
                        if($cdata['devise'] == $oDeivise && $oDeivise=='CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                        }
						else if($cdata['devise'] == $oDeivise && $oDeivise =='USD')
                        {
                                
                                if($cdata['recette'] == "27421600")
                                {
                                        $cdata['commission'] = $cdata['commission'];
                                        $cdata['devise']='USD';

                                        $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);        

                                }
                                else
                                {
                                         # Convert amount to cdf to get the total in cdf
                                        $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];
                                        
                                        # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                        $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                        $cdata['devise']='CDF';
                                        
                                        $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);        
                                }
                               
                        }
                        else if($cdata['devise'] == $oDeivise && $oDeivise =='USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];
                                
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                $cdata['devise']='CDF';
                                
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                        }
                        else if($cdata['devise'] == 'USD' && $oDeivise =='CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission']*$taux['Dollar_4'];
                                $cdata['devise']='CDF';
                                
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                                
                        }
                        else if($cdata['devise'] == 'CDF' && $oDeivise =='USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant']*$taux['Dollar_4'];
                                
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission']*0.16);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
						$cdata['commission'] = number_format($cdata['commission'],2,","," ");
                        $cdata['total'] = number_format($cdata['total'],2,","," ");
						
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
						
                        return $ar; exit;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */