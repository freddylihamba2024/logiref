<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('privileges', 'taxes','services','provinces','agences','villes','comptes','beneficiaries','guichets','regles','privileges', 'penalites', 'souscriptions', 'prospects','taux','recettes','integrations','sydonia','isys','rtgs','cbs','settings','prepayments','settings_regies','settings_bcc', 'ipaddress');
        
        public $group = ''; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $roles = '5';
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'settings';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('main/main_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/fees_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model('logiref/stakeholders_model');
                
                
		$this->lang = 'fr';
                $user_roles = $this->session->userdata('user_roles');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'settings';
                $this->data['function'] = '';
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') != "200")
                {
                        #$this->display('deny');
                }
                
                //Exchange rate
                if(!isset($_SESSION['Exchange_rates']))
                {
                        $this->data("set_exchange_rates");
                }
                
                //Group
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect('logiref','refresh');
                }
	} 
	
        
	public function index()
	{
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * List: 
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                $fullscreen_items = array('taxes','provinces','agences', 'penalites', 'souscriptions');
                
                if(in_array($needle, $this->menus) && in_array($needle,$fullscreen_items))
                {
                        $this->data['sidebar'] = '';
                        $this->index();
                }
                elseif(in_array($needle, $this->menus))
                {
                        $this->index(); 
                }
	}

        
        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
	public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
            
                if($obj == "recettes") 
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Recette");
                        $this->data['recettes'] = $this->logiref_model->get_taxes_codes("");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->load->view($this->module.'/'.$this->group. '/settings/recettes', $this->data);
                }
                elseif($obj == "recette")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Recette");
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("beneficiaries");
                        $this->data['recette'] = $this->logiref_model->get_recette_info($id);
                        $this->data['from'] = $arg;
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_recette', $this->data);
                }
                elseif($obj == "services") 
                {
                        $this->data['provinces'] = $this->logiref_model->get_dropdown("parameter",'PROVINCE');
                        $this->data['services'] = $this->logiref_model->get_services(NULL);
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->load->view($this->module.'/'.$this->group. '/settings/services', $this->data);
                }
                elseif($obj == "service") 
                {
                        $this->data['provinces'] = $this->logiref_model->get_dropdown("parameter",'PROVINCE');
                        $this->data['service'] = $this->logiref_model->get_service_info($id);
						$this->data['beneficiaires'] = $this->logiref_model->get_dropdown("regies");
                        $this->data['from'] = $arg;
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_service', $this->data);
                }
                elseif($obj == "beneficiarie") 
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Beneficiaire");
                        $this->data['beneficiairie'] = $this->logiref_model->get_beneficiarie_info($id);
                        $this->data['beneficiaries'] = $this->logiref_model->get_beneficiaries();
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("beneficiaries");
                        $this->data['from'] = $arg;
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_beneficiarie', $this->data);
                }
                elseif($obj == "beneficiaries") 
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Beneficiaire");
                        $this->data['beneficiaries'] = $this->logiref_model->get_beneficiaries();
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/beneficiaries', $this->data);
                }
				elseif($obj == "provinces") 
                {
                        $this->data['provinces'] = $this->logiref_model->get_referentiel("PROVINCE");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/provinces', $this->data);
                }
                elseif($obj == "villes") 
                {
                        $this->data['villes'] = $this->logiref_model->get_referentiel("VILLE");
                        $this->data['provinces'] = $this->logiref_model->get_referentiel("PROVINCE");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/villes', $this->data);
                }
                elseif($obj == 'referentiel')
                {
                        $this->data['referentiels'] = $this->logiref_model->referentiel;
                        $this->data['referentiel'] = $this->logiref_model->get_parameter_info($id);
                        $this->data['from'] = $arg;
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_referentiel', $this->data);
                }
                elseif($obj == "integrations")
                {
                        $this->load->view($this->module.'/'.$this->group. '/settings/integrations', $this->data);
                }
                elseif($obj == "ipaddress")
                {
                        $this->data['list'] = $this->logiref_model->get_ipaddress();
                        $this->load->view($this->module.'/'.$this->group. '/settings/ipaddress', $this->data);
                }
                elseif($obj == "settings")
                {
                        $this->data['view'] = $id;
                        $this->data['controller'] = $arg;
                        $this->load->view($this->module.'/'.$this->group. '/settings/settings', $this->data);
                }
                elseif($obj == "filter_sydonia")
                {
                        $this->data['status'] = $this->integration_model->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integration_model->filter_logs_sydonia($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/settings/logs_sydonia', $this->data);
                }
                elseif($obj == "filter_isys")
                {
                        $this->data['status'] = $this->integration_model->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integration_model->filter_logs_isys($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/settings/logs_isys', $this->data);
                }
                elseif($obj == "filter_rtgs")
                {
                        $this->data['status'] = $this->integration_model->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integration_model->filter_logs_rtgs($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/settings/logs_rtgs', $this->data);
                }
                elseif($obj == "filter_cbs")
                {
                        $this->data['status'] = $this->integration_model->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integration_model->filter_logs_cbs($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/settings/logs_cbs', $this->data);
                }
                
                elseif($obj == "rtgs") 
                {
                        $this->data['logs'] = $this->integration_model->get_rtgs_logs();
                        $this->load->view($this->module.'/'.$this->group. '/settings/rtgs', $this->data);
                }
                elseif($obj == "cbs") 
                {
                        $this->data['logs'] = $this->integration_model->get_cbs_logs();
                        $this->load->view($this->module.'/'.$this->group. '/settings/cbs', $this->data);
                }
                elseif($obj == "souscriptions")
                {
                        $this->data['souscriptions'] = $this->taxes_model->get_souscriptions();
                        #var_dump($this->data['souscriptions']);die;
                        $this->data['prospects'] = $this->taxes_model->get_prospects();
                        $this->data['categorie'] = $this->taxes_model->get_dropdown("categories", "prospect");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/souscriptions', $this->data);
                }
                elseif($obj == "souscription")
                {
                        $this->data['souscriptions'] = $this->taxes_model->get_souscriptions();
                        $this->data['prospects'] = $this->taxes_model->get_prospects();
                        $this->data['categorie'] = $this->taxes_model->get_dropdown("categories", "prospect");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/_souscription', $this->data);   
                }
                #Recuperation de l'id de la declaration
                elseif($obj == "declaration")
                {
                        $declare = $id;
                        $this->data['categorie'] = $this->taxes_model->get_dropdown("categories");
                        $this->data['lines'] = $this->taxes_model->get_declarations($declare);
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/_declarations', $this->data);
                } 
                elseif($obj == "prospects")
                {
                        $this->data['prospects'] = $this->taxes_model->get_prospects();
                        $this->data['categorie'] = $this->taxes_model->get_dropdown("categories");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/prospects', $this->data);
                }
                elseif($obj == "prospect")
                {
                        $this->data['prospects'] = $this->taxes_model->get_prospects();
                        $this->data['categorie'] = $this->taxes_model->get_dropdown("categories");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/_prospect', $this->data);
                }
                elseif($obj == "agences") 
                {
                        $this->data['agences'] = $this->logiref_model->get_agences("");
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/agences', $this->data);
                }
                
                elseif($obj == "integrations")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Beneficiaire");
                        
                        $this->data['beneficiairie'] = $this->settings_model->get_beneficiarie_info($id);
                        $this->data['beneficiaries'] = $this->settings_model->get_beneficiaries();
                        $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("beneficiaries");
                        
                        $this->load->view($this->module.'/'.$this->group. '/settings/integrations', $this->data);
                }
                elseif($obj == "taux") 
                {
                        $this->data("default_values_new_taux");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/_taux', $this->data);
                }
                elseif($obj == "charges")
                {
                        $data = array();
                        $data = $_POST;
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $valeurs = $this->fees_model->get_bank_charges($data['regie'], $data['service'], NULL, $data['devise'], $data['montant'], $data['guichet']);
                        if($valeurs['Valeur'] !=0 && $valeurs['Unite'] =='%')
                        {
                                $com['com'] = ($data['Montant_11']*$valeurs['Valeur'])/100;
                                $com['devise'] = $data['Devise_12'];
                        }
                        elseif($valeurs['Valeur'] !='' && $valeurs['Unite'] !='')
                        {
                                $com['com'] = $valeurs['Valeur'];
                                $com['devise'] = $valeurs['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $data['commission'] = $com['com'];
                                $data['devise'] = $com['devise'];
                        }
                        else
                        {
                                $data['commission'] = $data['montant']*0;
                                $data['devise'] = $data['devise'];
                        }
                    
                        if($data['devise']=='CDF') $data['devise'] = 1; else if($data['devise']=='USD')
                        {
                                $data['devise'] = 2; 
                        }
                        else if($data['devise']=='EUR')
                        {
                                $data['devise'] = 3; 
                        }
                        else if($data['devise']=='ZAF')
                        {
                                $data['devise'] = 4; 
                        }
                        else
                        {
                                $data['devise'] = 1;
                        }
                        $ar = array($data['commission'], $data['devise']);
                        echo json_encode($ar);
                }
                elseif($obj == "transactions")
                {
                        $titre = trim($_POST['titre']);
                        $regie = trim($_POST['regie']);
                        $service = trim($_POST['service']);
                        $titreJSON = $this->logiref_model->get_titre_info($titre, $regie, $service);
                        if(!empty($titreJSON))
                        {
                                echo '<div class="alert alert-danger text-white">Avertissement: numero BL incorrect</div>'; 
                        }
                }
                elseif($obj == "dropdowns")
                {
                        $what = $arg;
                        $var1 = $param;
                        $error = '';
                        if($what== "services")
                        {
                                $services_dropdown = $this->logiref_model->get_dropdown("services", $id, $province=NULL, true);
                                $Service_6 = $var1;
                                echo form_dropdown('service', $services_dropdown, $Service_6, 'class="form-control" id="service" required="required" '); 
                        }
                        elseif($what== "guichets")
                        {
                                $guichets_dropdown = $this->settings_model->get_dropdown("guichets", $id);
                                $Guichet_8 = $var1;
                                echo form_dropdown('guichet', $guichets_dropdown, $Guichet_8, 'class="form-control" id="guichet"'); 
                        }
                        elseif($what== "recettes")
                        {
                                $recettes_dropdown = $this->logiref_model->get_dropdown('recettes',$id);
                                $Recette_7 = $var1;
                                echo form_dropdown('recette', $recettes_dropdown, $Recette_7, 'class="form-control" id="recette" required="required" '); 
                        }
                        elseif($what== "services-o")
                        {
                                $beneficiaires = $this->logiref_model->getBeneficiaresDropdown();
                                $Service_16 = $var1;
                                echo form_dropdown('Service_14', $beneficiaires[$id], $Service_16, 'class="form-control"  id="service" '); 
                        }
                        elseif($what== "recettes-o")
                        {
                                $recettes = $this->logiref_model->getRecettesDropdown();
                                $Typerecette_17 = $var1;
                                echo form_dropdown('Typerecette_15', $recettes[$id], $Typerecette_17, 'class="form-control" id="recette" ');
                        }
                        return $error;
                }
                elseif($obj == "sydonia") 
                {
                        $this->data['status'] = $this->integration_model->sydonia_error_code;
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['logs'] = $this->integration_model->get_sydonia_logs();
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder. '/sydonia', $this->data);
                }
                elseif($obj == "isys") 
                {
                        $this->data['logs'] = $this->integration_model->get_isys_logs();
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/isys', $this->data);
                }
                #Dashboard
                elseif($obj == "dashboard") 
                {      
                        if($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1)
                        {
                                $this->data("default_values_new_taux");
                                $this->load->view('logiref/'.$this->group. '/' . $this->lang.'/_taux', $this->data);
                        }
                        else
                        {
                                $this->data("default_values_new_taux");
                                $this->load->view($this->module.'/'.$this->group. '/' . $this->lang.'/dashboard', $this->data);
                        }
                }
                elseif($obj == "settings_regies") 
                {
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/'.$obj, $this->data);  
                }
                elseif($obj == "settings_bcc") 
                {
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/'.$obj, $this->data);  
                }
                elseif($obj == "isys_account")
                {
                        $this->data['identifiants'] = $this->integration_model->get_isys_account_info();
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_isys', $this->data);
                }
                elseif($obj == "sydonia_account")
                {
                        $this->data['identifiants'] = $this->integration_model->get_sydonia_account_info();
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_sydonia', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
     
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                # New payment
                # When type paiement is Comptant
                if($obj == "taxe")
                {
                        $data=$_POST;
                        if($data['Type_4']=='0' || $data['Type_4']==''|| $data['Beneficiare_5']=='' || $data['Recette_6']=='' || $data['Code_7']==''):
                                echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                       
                        if($_SESSION['Logiref_role']==1):
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                    $data['Date_1']=gmdate('Y-m-d H:i:s');
                                    $data['Status_2']=1;
                                    $data['Account_3']='0';
                                    $data['Makerid_8']=$this->session->userdata('user_id');
                                else:
                                    $data['Makerid_8']=$this->session->userdata('user_id');
                                endif; 
                                $data['Validation_9']='0000-00-00';
                                $data['Checkerid_10']=0;
                        else:
                                $data['Validation_9']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_10']=$this->session->userdata('user_id');
                        endif;    
                    
                        $tid = $this->logiref_model->save_taxe($data, $id); // Enregistre les donnees dans la 
                        if ($tid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
				
                elseif($obj == "service")
                {
                        $data=$_POST;
                        if($data['Direction_4']=='0' || $data['Direction_4']=='' || $data['Service_5']=='' || $data['Description_6']=='' || $data['Code_7']=='' || $data['Province_8']==''|| $data['Province_8']=='Type_9'):
                                echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                       
                        if($_SESSION['Logiref_role']==1):
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']='0';
                                        $data['Makerid_10']=$this->session->userdata('user_id');
                                else:
                                        $data['Makerid_10']=$this->session->userdata('user_id');
                                endif;
                                $data['Validation_11']='0000-00-00';
                                $data['Checkerid_12']=0;
                        else:
                                $data['Validation_11']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_12']=$this->session->userdata('user_id');
                        endif;    
                    
                        $sid = $this->logiref_model->save_service($data, $id); // Enregistre les donnees dans la bd
                        if ($sid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "parametre")
                {
                        $data=$_POST;
                        //var_dump($_POST);die;
                        if($data['Category_3']=='0' || $data['Category_3']=='' || $data['Option_4']==''):
                                echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($_SESSION['Logiref_role']==1):
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']='0';
										
                                        $data['Code_5'] ='00000';
                                        $data['Makerid_6']=$this->session->userdata('user_id');
                                else:
                                        $data['Makerid_6']=$this->session->userdata('user_id');
                                endif;
                                $data['Validation_7']='0000-00-00';
                                $data['Checkerid_8']=0;
                        else:
                                $data['Validation_7']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_8']=$this->session->userdata('user_id');
                        endif;    
                    
                        $sid = $this->logiref_model->save_parametre($data, $id); // Enregistre les donnees dans la bdv
						//var_dump($sid);die;
                        if ($sid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "beneficiaries")
                {
                        $data=$_POST;
                        if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']='0';
                                $data['Makerid_8']=$this->session->userdata('user_id');
                        else:
                                $data['Makerid_8']=$this->session->userdata('user_id');                                   
                        endif;
                        
                        if($_SESSION['Logiref_role']==1):
                                
                                $data['Validation_10']='0000-00-00';
                                $data['Checkerid_9']=0;
                        else:
                                $data['Validation_10']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_9']=$this->session->userdata('user_id');
                        endif;    
                    
                        $bid = $this->logiref_model->save_beneficiaries($data, $id); // Enregistre les donnees dans la bd
                        if ($sid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "penalite")
                {
                    $fields = array(
                        'Priorite_4' => 'priorite',
                        'Service_6' => 'service',
                        'Recette_7' => 'recette',
                        'Value_9' =>'value',
                        'Unite_10' => 'unite',
                        'Min_11' => 'min',
                        'Max_12' => 'max',
                        'Devise_13' => 'devise',
                    );
                    foreach ($fields as $field => $value) 
                        {
                                $data[$field] = $this->input->post($value); //On assigne les valeurs de input aux champs de la DB
                        }

                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] ='1';
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['Makerid_14']=$this->session->userdata('user_id');
                        $data['Beneficiaire_5'] = $_SESSION['Logiref_regies'];

                    if($_SESSION['Logiref_role']==1):
                            $data['Validation_16']='0000-00-00';
                            $data['Checkerid_15']=0;
                    else:
                            $data['Validation_16']=gmdate('Y-m-d H:i:s');
                            $data['Checkerid_15']=$this->session->userdata('user_id');
                    endif;      

                    $rid = $this->settings_model->save_penalite($data, $id); // Enregistre les donnees dans la bd
                    if ($rid): 
                        echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    else: 
                            echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    endif;
                }
                elseif($obj == "account_isys")
                {
                    if(isset($_POST['identifiant']) && $_POST['password'] )
                    {
                            $fields = array(

                                    'Login_7'=>'identifiant',
                                    'Password_8'=>'password',
                            );
                            foreach($fields as $field => $value)
                            {
                                    $data[$field] = $this->input->post($value);
                            }

                            if(isset($id) && $id !=""):
                                $data['Changes_5'] = date('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata('user_id'); 
                            else:
                                $data['Date_1'] = date('Y-m-d H:i:s');
                                $data['Status_2'] = '1'; 
                                $data['Account_3'] = $this->session->userdata('account_id');
                            endif;
                            $cid = $this->integration_model->save_isys_account($data, $id);    
                    }

                    if($cid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    else: 
                            echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    endif;
                }
                elseif($obj == "account_sydonia")
                {
                       
                        if(isset($_POST['code']))
                        {
                                $fields = array(

                                        'Bank_7'=>'code',
                                        'Login_8'=>'login',
                                        'Password_9'=>'password',
                                        
                                );
                                foreach($fields as $field => $value)
                                {
                                        $data[$field] = $this->input->post($value);
                                }
                            
                                if(isset($id) && $id !=""):
                                    $data['Changes_5'] = date('Y-m-d H:i:s');
                                    $data['Changer_6'] = $this->session->userdata('user_id'); 
                                else:
                                    $data['Date_1'] = date('Y-m-d H:i:s');
                                    $data['Status_2'] = '1'; 
                                    $data['Account_3'] = $this->session->userdata('account_id');
                                    $data['Creator_4'] = $this->session->userdata('user_id'); 
                                endif;
                                $cid = $this->integration_model->save_sydonia_account($data, $id);    
                        }
                        
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                
                #Enregistrement automatique  des donnees de la table prospect dans la table client et souscription
                elseif($obj == "prospect")
                {
                        $info = $this->taxes_model->get_prospect_info($id);
                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] ='2';
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $datas['Creator_4'] = $this->session->userdata('user_id');
                        $data['Denomination_7']= $info->Denomination_7;
                        $data['Email_10']= $info->Email_10;
                        $data['Siege_social_11']= $info->Siege_social_11;
                        $data['Site_exploitation_12']= $info->Site_exploitation_12;
                        $data['Idnat_13']= $info->Idnat_13;
                        $data['Rccm_14']= $info->Rccm_14;
                        $data['Idfiscal_15']= $info->Idfiscal_15;
                        #var_dump($info);die;
                        $lid = $this->taxes_model->save_client($data, NULL); // Enregistre les donnees dans la bd
                        if ($lid > 0)
                        { 
                                $this->load->model('MY_Main');
                                $this->load->model('main/main_model');
                                $password = '123456';
                                $datas['Date_1'] = date('Y-m-d H:i:s');
                                $datas['Status_2'] ='2';
                                $datas['Account_3'] = $this->session->userdata('account_id');
                                $datas['Creator_4'] = $this->session->userdata('user_id');
                                $datas['Code_8'] =  $this->main_model->generate_hash($password);
                                $datas['Clientid_9'] = $lid;
                                $datas['Starting_10'] = gmdate('Y-m-d');
                                $datas['Authorities_17'] = $this->session->userdata('account_id');
                                
                                #Tableau de l'encodage json
                                $validations = array(
                                        'DGI'=>'0',
                                        'DGDA'=>'0',
                                        'DGRAD'=>'0',
                                        'Date'=>'0'
                                    );
                                $datas['Validation_18'] = json_encode($validations);
                                $datas['Status_2'] ='1';

                                $sid = $this->taxes_model->save_souscription($datas, NULL);
                                
                                $datas = array();
                                $datas['Status_2'] ='2';
                                $datas['Validation_21'] =date('Y-m-d H:i:s');
                                $this->taxes_model->save_prospects($datas, $id);

                                if ($sid): 
                                    echo '<div class="alert alert-success text-white">Bravo! prospect valid&eacute;; avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                else: 
                                        echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                endif;
                        }
                        else
                        {
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        }
                }
                elseif($obj == "souscription")
                {
                        $line = $this->taxes_model->get_souscription_info($id);
                        $date = date('Y-m-d H:i:s');
                        
                        $content = json_decode($line->Validation_18, true);
                        
                        $content[$_SESSION['Logiref_regies']]=1;
                        $content['Date']=$date;
                        $validations = $content;
                        
                        $datas['Validation_18']= json_encode($validations);

                        $vid = $this->taxes_model->save_souscription($datas, $id);
                        if ($vid): 
                            echo '<div class="alert alert-success text-white">Bravo! souscription valid&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $object=$this->input->get('object');
                        
                        if($object=='ipadress')
                        {
                                $data['Date_1'] = date('Y-m-d H:i:s');
                                $data['Status_2'] = '0'; 
                                $data['Account_3'] = $this->session->userdata('account_id');
                                $return = $this->logiref_model->get_ipaddress_by_id($id);
                                
                                $id = $this->logiref_model->save_ipaddress($data, $id);
                                
                                if(isset($return->Sessionid_8) && $return->Sessionid_8 !="")
                                {
                                        unset($return->Sessionid_8);
                                }
                        }
                }
        }
        
        
          
        
                
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * List:
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if($obj == "get_users")
                {
                        $members = $this->users_model->get_members();
                        $type = $this->session->userdata('user_type');
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata('user_id');
                                $cid = $this->users_model->save_users($data, NULL);
                                if($cid) $members = $this->users_model->get_members();
                        }
                        return $members;
                }
                
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif($obj == "set_exchange_rates")
                {
                        $this->rates_model->get_exchange_rates();
                }
                elseif($obj == "default_values_new_taux")
                {
                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                if($bank['Checkerid_11']==0): 
                                        $this->data['id'] = $bank['Id_0']; 
                                else :
                                        $this->data['id'] = ''; 
                                        $this->data['reset'] = 1; 
                                endif;   
                                
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }
                        
                        $this->data['action'] = '...';
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }
                        
                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')
                                    
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }
                
                
                # Purpose
                # Description
                ################################################################################
                elseif($obj == "priority")
                {
                        
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */