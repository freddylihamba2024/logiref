<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reversement extends MY_Controller {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('beneficiaries','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'reversement';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/prepayments_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/reversement_model');
                
                $this->folder = 'reversement';
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'reversement';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
				
				ini_set('memory_limit', '8192M');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['regies'] = $this->logiref_model->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reversement_model->get_paiements_to_reverse();
						
						
                        # Retrieve the data_submitted from the form in order to put them in the session variable for export.
                        $_SESSION['data_submitted'] = $_POST;
                                
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_reverse', $this->data);
                }
				elseif($obj == "start_passport")
                {
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['regies'] = $this->logiref_model->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reversement_model->get_paiements_passport_to_reverse();
						
                        # Retrieve the data_submitted from the form in order to put them in the session variable for export.
                        $_SESSION['data_submitted'] = $_POST;
                                
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_reverse', $this->data);
                }
                elseif($obj == "export") 
                {   
                        @set_time_limit(300);
                        if($id != NULL)
                        {
                                $reversements = $this->integration_model->get_reversement_info($id);
                                
                                $paiements = json_decode($reversements->Paiementids_23, true);
                                
                                if(isset($paiements['autres']) && $paiements['autres'] !="")
                                {
                                        $_POST['paiements'] = $paiements['autres'];
                                }
                                elseif($paiements['dgda'] && $paiements['dgda'] !="")
                                {
                                        $_POST['bulletins'] = $paiements['dgda'];
                                }
                                elseif($paiements['dgda_prepayments'] && $paiements['dgda_prepayments'] !="")
                                {
                                        $_POST['prepayments'] = $paiements['dgda_prepayments'];
                                }
                                
                                $reversements = $this->reversement_model->get_paiements_to_reverse();
                        }
                        else 
                        {   
                                $_POST = $_SESSION['data_submitted'];
                                # New paiement to reverse into ISYS-REGIES
                                $reversements = $this->reversement_model->get_paiements_to_reverse();
                        }
						
                        $regie = "";
						
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[15]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('V_REG_NOTE_PERCEPTION');
                        //set cell A1 content with some text
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Numero Relevé Paiement", "Numero Titre de Perception","Numero Impot","Désignation","Période","Montant Note","Date Note", "Numero Quittance", "Numero Paiement", "Montant", "Devise", "Date de Paiement", "Regie", "Code Service Recouvrement", "Code Type Recette Etat", "Message Retour");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($style4Array);
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($reversements);
                        
                        foreach($reversements as $row)
                        {
                                if(($row->Typerecette_17 =='27022470' || $row->Typerecette_17 =='27421600' || $row->Typerecette_17 =='27022450') && $row->Devise_12 =='USD')
                                {
                                        $numero_releve = $i.round(1,9999).$row->Id_0;
                                        $regie = $row->Beneficaire_15;
                                        $devise = $row->Notedevise_29;
                                        $periode_Paiement = "";
                                        $numquittance = "";

                                        $numero_releve = "RLV".$regie."".gmdate('d')."".gmdate('m')."".gmdate('Y')."".$devise."";

                                        $Infos = json_decode($row->Notereference_30, true);

                                        if(isset($Infos['standard']) && $Infos['standard'] !="")
                                        {
                                                $data_1 = explode("/", $Infos['standard']);
												

                                                if(isset($data_1[1]) && $data_1[1] !="")
                                                {
                                                        $periode_Paiement = $data_1[0]."".$data_1[1];
                                                }
                                                else
                                                {
                                                        $periode_Paiement = "";
                                                }

                                        }

                                        if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                        {
                                                $date_num = gmdate('d-m-Y');
                                                $date_num = str_replace('-', '', $date_num);

                                                if($row->Sydonia_44 !="0" || $row->Sydonia_49 !="0")
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement']."/".$row->Id_0."-".$date_num;
                                                }
                                                else
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement'].'-'.$date_num;
                                                }
                                        }
                                        else
                                        {
                                                $numero_paiement = $row->Id_0;
                                        }

                                        if(isset($Infos['accountname']) && $Infos['accountname'] !="")
                                        {
                                                if(isset($Infos['pourcompte']) == "1")
                                                {
                                                        $designation = $Infos['accountname']." P/C ".$row->Designation_14;

                                                }
                                                else
                                                {
                                                        $designation = $row->Designation_14;	
                                                }
                                        }
                                        else 
                                        {
                                                if($row->Designation_14 !="") $designation = $row->Designation_14;
                                                else $designation = $row->Nif_13;
                                        }

                                        if($row->Sydonia_44 !="" || $row->Sydonia_49 !="") 
                                        {
                                                if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                {
                                                        $numquittance = $Infos['quittanceid'];
                                                }
                                                else 
                                                {
                                                        $numquittance = "";
                                                }
                                        }

                                        if($regie =='DGI' && $row->Sydonia_44 != '0')
                                        {
                                                $date = explode("-", $row->Notedate_27);

                                                if(isset($date[1]) && $date[1] != '')
                                                {
                                                        $periode_Paiement = $date[1]."".$date[0];
                                                }

                                                $row->Service_16 = 'GU-DGI';
                                        }
                                        if($regie =='DGRAD' && $row->Sydonia_44 != '0')
                                        {
                                                $row->Service_16 = 'GU-DGRAD';
                                        }

                                        # Montant paye
                                        $montant = $row->Montant_11;

                                        if($row->Typerecette_17 =='IPRIER')
                                        {
                                                if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                {
                                                        $montant = $Infos['QuotasDGI'];
                                                }
                                        }
										
										if($row->Typerecette_17 =='27421600')
                                        {
                                                if(isset($Infos['QuotasTresor']) && $Infos['QuotasTresor'] != "")
                                                {
                                                        $montant = $Infos['QuotasTresor'];
                                                }
												else
												{	
														$montant = 21;
												}
                                        }

                                        $note_montant = $row->Notemontant_28;

                                        if(isset($row->Sydonia_44) && $row->Sydonia_44 != '0')
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }
                                        else
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }


                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('N'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('E'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);


                                        $objPHPExcel->getActiveSheet()->getStyle('J')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );
                                        $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $numero_releve);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Nif_13);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $designation);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $periode_Paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Notemontant_28);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $date_note);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $numquittance);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $numero_paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, $montant);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, $row->Devise_12);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $erow, $date_paiement);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $erow, $row->Beneficaire_15);
                                        if($row->Beneficaire_15 == 'DGRAD')$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16.' ');
                                        else $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $erow, $row->Typerecette_17);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $erow, "");
                                        $i++;

                                        if($i != $array_length)
                                        {   
                                            $erow++;
                                        }
                                }
                                elseif($row->Typerecette_17 !='27022470' || $row->Typerecette_17 !='27022450') 
                                {
                                        $numero_releve = $i.round(1,9999).$row->Id_0;
                                        $regie = $row->Beneficaire_15;
                                        $devise = $row->Notedevise_29;
                                        $periode_Paiement = "";
                                        $numquittance = "";

                                        $numero_releve = "RLV".$regie."".gmdate('d')."".gmdate('m')."".gmdate('Y')."".$devise."";

                                        $Infos = json_decode($row->Notereference_30, true);

                                        if(isset($Infos['standard']) && $Infos['standard'] !="")
                                        {
                                                $data_1 = explode("/", $Infos['standard']);

                                                if(isset($data_1[1]) && $data_1[1] !="")
                                                {
                                                        $periode_Paiement = $data_1[0]."".$data_1[1];
                                                }
                                                else
                                                {
                                                        $periode_Paiement = "";
                                                }

                                        }

                                        if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                        {
                                                $date_num = gmdate('d-m-Y');
                                                $date_num = str_replace('-', '', $date_num);

                                                if($row->Sydonia_44 !="0" || $row->Sydonia_49 !="0")
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement']."/".$row->Id_0."-".$date_num;
                                                }
                                                else
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement'].'-'.$date_num;
                                                }
                                        }
                                        else
                                        {
                                                $numero_paiement = $row->Id_0;
                                        }

                                        if(isset($Infos['accountname']) && $Infos['accountname'] !="")
                                        {
                                                if(isset($Infos['pourcompte']) == "1")
                                                {
                                                        $designation = $Infos['accountname']." P/C ".$row->Designation_14;

                                                }
                                                else
                                                {
                                                        $designation = $row->Designation_14;	
                                                }
                                        }
                                        else 
                                        {
                                                if($row->Designation_14 !="") $designation = $row->Designation_14;
                                                else $designation = $row->Nif_13;
                                        }

                                        if($row->Sydonia_44 !="" || $row->Sydonia_49 !="") 
                                        {
                                                if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                {
                                                        $numquittance = $Infos['quittanceid'];
                                                }
                                                else 
                                                {
                                                        $numquittance = "";
                                                }
                                        }

                                        if($regie =='DGI' && $row->Sydonia_44 != '0')
                                        {
                                                $date = explode("-", $row->Notedate_27);

                                                if(isset($date[1]) && $date[1] != '')
                                                {
                                                        $periode_Paiement = $date[1]."".$date[0];
                                                }

                                                $row->Service_16 = 'GU-DGI';
                                        }
                                        if($regie =='DGRAD' && $row->Sydonia_44 != '0')
                                        {
                                                $row->Service_16 = 'GU-DGRAD';
                                        }

                                        # Montant paye
                                        $montant = $row->Montant_11;

                                        if($row->Typerecette_17 =='IPRIER')
                                        {
                                                if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                {
                                                        $montant = $Infos['QuotasDGI'];
                                                }
                                        }

                                        $note_montant = $row->Notemontant_28;

                                        if(isset($row->Sydonia_44) && $row->Sydonia_44 != '0')
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }
                                        else
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }


                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('N'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('E'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);


                                        $objPHPExcel->getActiveSheet()->getStyle('J')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );
                                        $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );


                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $numero_releve);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Nif_13);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $designation);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $periode_Paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Notemontant_28);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $date_note);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $numquittance);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $numero_paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, $montant);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, $row->Devise_12);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $erow, $date_paiement);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $erow, $row->Beneficaire_15);
                                        if($row->Beneficaire_15 == 'DGRAD')$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16.' ');
                                        else $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $erow, $row->Typerecette_17);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $erow, "");
                                        $i++;

                                        if($i != $array_length)
                                        {   
                                                $erow++;
                                        }
                                }
                        }
						
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) 
                        {
                                $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= $user_id.'_'.$regie.'_fichier_isys_'.time().'.xlsx';
						
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
						
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');
                                $path = "./drive/logiref/".$account_id."/".date('m-Y').'/isys-regies';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                
                                $path = $path."/".$filename;
								
                                //save the file on the server's HD
                                $objWriter->save($path);
								
                                $_POST['Filepath_24'] = $path;
                                $_POST['paiements_list'] = $reversements;
                                
                                $this->save("reversement");
                               
                        }
                        
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
				elseif($obj == "export_passport") 
                {   
                        @set_time_limit(300);
                        if($id != NULL)
                        {
                                $reversements = $this->integration_model->get_reversement_info($id);
                                
                                $paiements = json_decode($reversements->Paiementids_23, true);
                                
                                if(isset($paiements['autres']) && $paiements['autres'] !="")
                                {
                                        $_POST['paiements'] = $paiements['autres'];
                                }
                                elseif($paiements['dgda'] && $paiements['dgda'] !="")
                                {
                                        $_POST['bulletins'] = $paiements['dgda'];
                                }
                                elseif($paiements['dgda_prepayments'] && $paiements['dgda_prepayments'] !="")
                                {
                                        $_POST['prepayments'] = $paiements['dgda_prepayments'];
                                }
                                
                                $reversements = $this->reversement_model->get_paiements_passport_to_reverse();
                        }
                        else 
                        {   
                                $_POST = $_SESSION['data_submitted'];
                                # New paiement to reverse into ISYS-REGIES
                                $reversements = $this->reversement_model->get_paiements_passport_to_reverse();
                        }
						
                        $regie = "";
						
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[15]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('V_REG_NOTE_PERCEPTION');
                        //set cell A1 content with some text
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Numero Relevé Paiement", "Numero Titre de Perception","Numero Impot","Désignation","Période","Montant Note","Date Note", "Numero Quittance", "Numero Paiement", "Montant", "Devise", "Date de Paiement", "Regie", "Code Service Recouvrement", "Code Type Recette Etat", "Message Retour");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($style4Array);
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($reversements);
                        
                        foreach($reversements as $row)
                        {
                                if(($row->Typerecette_17 =='27022470' || $row->Typerecette_17 =='27421600' || $row->Typerecette_17 =='27022450') && $row->Devise_12 =='USD')
                                {
                                        $numero_releve = $i.round(1,9999).$row->Id_0;
                                        $regie = $row->Beneficaire_15;
                                        $devise = $row->Notedevise_29;
                                        $periode_Paiement = "";
                                        $numquittance = "";

                                        $numero_releve = "RLV".$regie."".gmdate('d')."".gmdate('m')."".gmdate('Y')."".$devise."";

                                        $Infos = json_decode($row->Notereference_30, true);

                                        if(isset($Infos['standard']) && $Infos['standard'] !="")
                                        {
                                                $data_1 = explode("/", $Infos['standard']);

                                                if(isset($data_1[1]) && $data_1[1] !="")
                                                {
                                                        $periode_Paiement = $data_1[0]."".$data_1[1];
                                                }
                                                else
                                                {
                                                        $periode_Paiement = "";
                                                }

                                        }

                                        if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                        {
                                                $date_num = gmdate('d-m-Y');
                                                $date_num = str_replace('-', '', $date_num);

                                                if($row->Sydonia_44 !="0" || $row->Sydonia_49 !="0")
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement']."/".$row->Id_0."-".$date_num;
                                                }
                                                else
                                                {
                                                        $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                        $numero_paiement = $Infos['Num_evenement'].'-'.$date_num;
                                                }
                                        }
                                        else
                                        {
                                                $numero_paiement = $row->Id_0;
                                        }

                                        if(isset($Infos['accountname']) && $Infos['accountname'] !="")
                                        {
                                                if(isset($Infos['pourcompte']) == "1")
                                                {
                                                        $designation = $Infos['accountname']." P/C ".$row->Designation_14;

                                                }
                                                else
                                                {
                                                        $designation = $row->Designation_14;	
                                                }
                                        }
                                        else 
                                        {
                                                if($row->Designation_14 !="") $designation = $row->Designation_14;
                                                else $designation = $row->Nif_13;
                                        }

                                        if($row->Sydonia_44 !="" || $row->Sydonia_49 !="") 
                                        {
                                                if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                {
                                                        $numquittance = $Infos['quittanceid'];
                                                }
                                                else 
                                                {
                                                        $numquittance = "";
                                                }
                                        }

                                        if($regie =='DGI' && $row->Sydonia_44 != '0')
                                        {
                                                $date = explode("-", $row->Notedate_27);

                                                if(isset($date[1]) && $date[1] != '')
                                                {
                                                        $periode_Paiement = $date[1]."".$date[0];
                                                }

                                                $row->Service_16 = 'GU-DGI';
                                        }
                                        if($regie =='DGRAD' && $row->Sydonia_44 != '0')
                                        {
                                                $row->Service_16 = 'GU-DGRAD';
                                        }

                                        # Montant paye
                                        $montant = $row->Montant_11;

                                        if($row->Typerecette_17 =='IPRIER')
                                        {
                                                if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                {
                                                        $montant = $Infos['QuotasDGI'];
                                                }
                                        }
										
										if($row->Typerecette_17 =='27421600')
                                        {
                                                if(isset($Infos['QuotasTresor']) && $Infos['QuotasTresor'] != "")
                                                {
                                                        $montant = $Infos['QuotasTresor'];
                                                }
												else
												{	
													$montant = 21;
												}
                                        }

                                        $note_montant = $row->Notemontant_28;

                                        if(isset($row->Sydonia_44) && $row->Sydonia_44 != '0')
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }
                                        else
                                        {
                                                $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                        }


                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('N'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
                                        $objPHPExcel->getActiveSheet()->getDefaultStyle('E'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);


                                        $objPHPExcel->getActiveSheet()->getStyle('J')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );
                                        $objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->applyFromArray(
                                                                        array(
                                                                            'code' =>'#,##0.00'
                                                                        )
                                        );

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $numero_releve);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Noteid_26);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Nif_13);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $designation);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $periode_Paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, $row->Notemontant_28);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $date_note);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $numquittance);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $numero_paiement.' ');
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, $montant);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, $row->Devise_12);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $erow, $date_paiement);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $erow, $row->Beneficaire_15);
                                        if($row->Beneficaire_15 == 'DGRAD')$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16.' ');
                                        else $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $erow, $row->Service_16);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $erow, $row->Typerecette_17);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $erow, "");
                                        $i++;

                                        if($i != $array_length)
                                        {   
                                            $erow++;
                                        }
                                }
                                 
                        }
						
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) 
                        {
                                $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata('user_id');
                        $filename= $user_id.'_'.$regie.'_fichier_isys_'.time().'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
						
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');
                                $path = "./drive/logiref/".$account_id."/".date('m-Y').'/isys-regies';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                
                                $path = $path."/".$filename;
								
                                //save the file on the server's HD
                                $objWriter->save($path);
								
                                $_POST['Filepath_24'] = $path;
                                $_POST['paiements_list'] = $reversements;
                                
                                $this->save("reversement");
                               
                        }
                        
                        //download the file in the browser
                        $objWriter->save('php://output');
                }
                
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "reversement")
                {
                        if(isset($_POST) && $_POST != "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Makerid_7']=$this->session->userdata('user_id');
                                
                                if($_POST['regie'] = 'all')
                                {
                                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                                        {
                                                $bulletins = $_POST['bulletins'];
                                                $total_dgda = array_sum($_POST['total_dgda']);
                                                $total_dgda = str_replace(' ','',$total_dgda);
                                                $total_dgda = str_replace(',','.',$total_dgda);
                                                $paiement_ids['dgda'] = $_POST['bulletins'];
                                        }
                                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                        {
                                                $paiements = $_POST['paiements'];
                                                $total = array_sum($_POST['total']);
                                                $total = str_replace(' ','',$total);
                                                $total = str_replace(',','.',$total);
                                                $paiement_ids['autres'] = $_POST['paiements'];
                                        }
                                        if(isset($_POST['prepayments']) && $_POST['prepayments'] !="")
                                        {
                                                $prepayments = $_POST['prepayments'];
                                                $total_prepayment = array_sum($_POST['total_prepayments']);
                                                $total_prepayment = str_replace(' ','',$total_prepayment);
                                                $total_prepayment = str_replace(',','.',$total_prepayment);
                                                $paiement_ids['dgda_prepayments'] = $_POST['prepayments'];
                                        }
                                        
                                       
                                        $paiement_ids['paiements'] = $_POST['paiements_list'];
                                        $data['Journee_13'] = gmdate('Y-m-d');
                                        $data['Beneficiaire_10'] = 'Tout';
                                        $data['Paiementids_23'] = json_encode($paiement_ids);
                                        $data['Filepath_24'] = $_POST['Filepath_24'];
                                        
                                        $data['Contrevaleur_16'] = 0;
                                        $data['Nombrepaiement_22'] = 0;
                                        
                                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                        {
                                                $data['Contrevaleur_16'] += $total;
                                                $data['Nombrepaiement_22'] += count($_POST['paiements']);
                                        }
                                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="") 
                                        {
                                                $data['Contrevaleur_16'] += $total_dgda;
                                                $data['Nombrepaiement_22'] += count($_POST['bulletins']);
                                        }
                                        if(isset($_POST['prepayments']) && $_POST['prepayments'] !="") 
                                        {
                                                $data['Contrevaleur_16'] += $total_prepayment;
                                                $data['Nombrepaiement_22'] += count($_POST['prepayments']);
                                        }
                                
                                }
                                else 
                                {
                                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                                        {
                                                $bulletins = $_POST['bulletins'];
                                                $data['Nombrepaiement_22']= count($_POST['bulletins']);
                                                $data['Contrevaleur_16'] = array_sum($_POST['total_dgda']);
                                                $data['Devise_9'] = 'CDF';
                                                $paiement_ids['dgda'] = $_POST['bulletins'];
                                        }
                                        if(isset($_POST['prepayments']) && $_POST['prepayments'] !="")
                                        {
                                                $prepayments = $_POST['prepayments'];
                                                $data['Nombrepaiement_22']= count($_POST['prepayments']);
                                                $data['Contrevaleur_16'] = array_sum($_POST['total_prepayments']);
                                                $data['Devise_9'] = 'CDF';
                                                $paiement_ids['dgda_prepayment'] = $_POST['prepayments'];
                                        }
                                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                        {
                                                $paiements = $_POST['paiements'];
                                                $data['Nombrepaiement_22']= count($_POST['paiements']);
                                                $data['Contrevaleur_16'] = array_sum($_POST['total']);
                                                $data['Devise_9'] = $_POST['devise_paiement'];
                                                $paiement_ids['autres'] = $_POST['paiements'];
                                        }
                                        
                                        $paiement_ids['paiements'] = $_POST['paiements_list'];
                                        $data['Journee_13'] = gmdate('Y-m-d');
                                        $data['Beneficiaire_10'] = $_POST['regie'];
                                        $data['Paiementids_23'] = json_encode($paiement_ids);
                                        $data['Filepath_24'] = $_POST['Filepath_24'];
                                }
                                
                                $rid = $this->integration_model->save_integrations_isys($data, NULL); 
                             
                                if($rid > 0)
                                {
                                        if(isset($bulletins) && $bulletins !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $ids = implode(",", $bulletins);
                                                
                                                $this->integration_model->update_bulletin($data, $ids);
                                        }
                                        if(isset($paiements) && $paiements !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $ids = implode(",", $paiements);
                                                
                                                $this->reversement_model->update_payment_tresor($data, $ids);
                                        }
                                        
                                        if(isset($prepayments) && $prepayments !="")
                                        {
                                                
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $ids = implode(",", $prepayments);
                                                $this->prepayments_model->update_prepayement($data, $ids);
                                               
                                        }
                                }
                                
                                return $rid;
                                
                        }
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */