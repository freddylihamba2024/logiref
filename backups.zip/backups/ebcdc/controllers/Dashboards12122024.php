﻿<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboards extends MY_Controller {
        /*
         * Presentation: Gestion des tableaux de bord
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('overview','menus','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'dashboards';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model($this->module.'/dashboards_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/encaissement_model');
                $this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/integration_model');
				$this->load->model($this->module.'/rates_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model($this->module.'/data_model');
                $this->load->model($this->module.'/rates_model');
				$this->load->model($this->module.'/curl_model');
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Exchange_rates']))
                {
                        $this->data("set_exchange_rates");
                        
                        $message = " ".$this->session->userdata('account_business')." Login to logiref successful";
                        $this->data("set_log", $message);
                }
                
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                ############################ Menu Operateur ################
                if($obj == "overview")
                {
                        if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3)
                        {
                                if(!isset($_SESSION['token_isys']))
                                {
                                        $this->integration_model->get_token_isys();
                                        $this->display('get_token_isys');
                                }
                                else
                                {
                                        $this->display('get_token_isys');
                                }
                        }
                        if($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['sidebar'] = '';
                                $this->data("default_values_new_taux");
                                $this->data("set_exchange_rates");
                                
                                $this->load->view($this->module.'/'.$this->group. '/rates/_taux', $this->data);
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                $this->data['paiement_cdf'] = $paiement_cdf = array();
                                $this->data['paiement_usd'] = $paiement_usd = array();
                                $this->data['paiement_regie'] = array();
                                $this->data['paiement'] = array();
                                $this->data['pie_situation_cdf'] = array();
                                $this->data['pie_situation_usd'] = array();
                                $this->data['right_side']= $id;
                                $this->data['beneficiaires'] =array();
                                $this->data['encaissements'] = array();
                                $this->data['guichets'] = array();
                                $this->load->model('MY_Main');
                                $this->load->model('main/main_model');
                                $this->data['users'] = $this->main_model->get_dropdown('users_array');
                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/overview_operator', $this->data);
                        }
                        elseif($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==5)
                        {
                                # Dashboard for the super user
                                $this->data['commission'] = $this->encaissement_model->get_stats("commission");
                                $this->data['penalties'] = $this->data_model->get_penalites();
                                $this->data['paiement'] = $this->encaissement_model->get_stats("paiement");
                                $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                                $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                                $this->data['guichets'] = $this->branches_model->get_branches();

                                $data = array();
                                
                                foreach ($this->data['guichets'] as $row)
                                {
                                        $data[$row->Id_0]= $this->encaissement_model->get_paiements_stats("guichet", $row->Id_0);
                                }
                                $this->data['data'] = $data;

                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/'.$obj, $this->data);
                        }
                        elseif($_SESSION['Logiref_role']==2)
                        {
                                # Dashboard for the operations manager
                    
                                $this->load->model($this->module.'/data_model');
                                
                                $this->data['commission'] = $this->encaissement_model->get_stats("commission");
                                $this->data['paiement'] = $this->encaissement_model->get_stats("paiement");
                                $this->data['penalties'] = $this->data_model->get_penalites();
                                $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                                $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                                $this->data['agences'] = $this->branches_model->get_agences();
                                foreach ($this->data['agences'] as $row)
                                {
                                        $data[$row->Id_0]= $this->encaissement_model->get_paiements_stats("agence", $row->Id_0);
                                }
                                $this->data['data'] = $data;
                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/summary', $this->data);
                        }
                        elseif($_SESSION['Logiref_role']==1)
                        {
                                $this->display("list");
                        }
                }
                ############################ Menu Operateur ################
                elseif($obj == "summary")
                {
                        # Dashboard for the operations manager
                    
                        $this->data['commission'] = $this->encaissement_model->get_stats("commission");
                        $this->data['paiement'] = $this->encaissement_model->get_stats("paiement");
                        $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                        $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                        $this->data['agences'] = $this->encaissement_model->get_agences();
                        
                        foreach ($this->data['agences'] as $row)
                        {
                                $data[$row->Id_0]= $this->encaissement_model->get_paiements_stats("agence", $row->Id_0);
                        }
                        $this->data['data'] = $data;
                        
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->lang. '/'.$obj, $this->data);
                }
                ############################ Menu Operateur ################
                elseif($obj == "menus") 
                {
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder. '/_'.$obj, $this->data);
                }
                ########################### Token ISYS-Regies ###############
                elseif($obj == "get_token_isys")
                {
                        set_time_limit(250);
                        
                        $data= array();
                        
                        if(isset($_SESSION['token_isys']) && $_SESSION['token_isys'] !="")
                        {
                                $token_time = $_SESSION['token_time'];
                                $current_time = gmdate('H:i:s');
                                
                                $token_time_1=strtotime($token_time);
                                $token_time_2=strtotime($current_time);
                                
                                $diff = $token_time_2 - $token_time_1;
 
                                $hour = floor(date('H:i:s', $diff));
                                
                                if($hour <= 3)
                                {
                                        $message = "The token exist";
                                }
                                else 
                                {
                                        $informations = $this->integration_model->get_isys_account_info();
                                        
                                        $data['login'] = $informations->Login_7;
                                        $data['password'] = $informations->Password_8;
                                        
                                        $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");
                                        
                                        //$url = base_url('api/endpoints/logiref/login.php');
                                        //$this->load->library('curl');
                                        //$this->curl->create($url);
                                        //$this->curl->post($data);
                                        
                                        //$response = $this->curl->execute();
                                        
                                       //if($response!=NULL)
                                        //{
                                                //$message = " Login to isys_regie successful";
                                                //$this->data("set_log", $message, "isys");
                                                
                                                //$_SESSION['token_isys'] = $response;
                                                //$_SESSION['token_time'] = gmdate('H:i:s');
                                                
                                                
                                        //}
                                }
                        }
                        else
                        {
                                $informations = $this->integration_model->get_isys_account_info();
                                        
                                $data['login'] = $informations->Login_7;
                                $data['password'] = $informations->Password_8;
                                
                                $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");
                                        
                                //$url = base_url('api/endpoints/logiref/login.php');
                                //$this->load->library('curl');
                                //$this->curl->create($url);
                                //$this->curl->post($data);
                                
                                //$response = $this->curl->execute();
                                
                                //if($response!=NULL)
                                //{
                                        //$_SESSION['token_isys'] = $response;
                                        //$_SESSION['token_time'] = gmdate('H:i:s');
                                        
                                        //$this->save('token_isys', $response);
                                //}
                        }
                }
                ############################ Menu Operateur ################
                elseif($obj == "OBJ ") 
                {
                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == 'taux')
				{
						$dollar = str_replace(' ','',$_POST['usd']);
						$dollar = str_replace(',','.',$dollar);

						if($_POST['eur'] !="")
						{
								$euro = str_replace(' ','',$_POST['eur']);
								$euro = str_replace(',','.',$euro);
								$data['Euro_5']     =   $euro;
						}
						
						$data['Date_1']     =   gmdate('Y-m-d H:i:s');
						$data['Status_2']   =   1;
						$data['Account_3']  =   $this->session->userdata('account_id');
						$data['Dollar_4']   =   $dollar;
						$data['Agence_8']   =   $_SESSION['Logiref_agence'];
						$data['Day_9']      =   gmdate('Y-m-d');
						$data['Checkerid_11']='0001';
						$data['Makerid_10']='0002';
						
						$_SESSION['Date_new_taux'] = gmdate('Y-m-d');
						
						$cid = $this->rates_model->save_taux($data, NULL);  

						if($cid)
						{
								echo $cid;
						}
						
				}
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if($obj == "set_privilegies")
                {
                        $this->users_model->get_privilegies();
                }
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif($obj == "set_exchange_rates")
                {
						$this->rates_model->get_exchange_rates();
						
                        if(!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates']=='0')
                        {
                                $data['from_currency'] = 'USD';
                                $data['to_currency'] = 'CDF';
								$data['type'] = 'TTB';

                                $return = $this->curl_model->call_bank_exchange_rate($data);

                                $return = json_decode($return, true);
								
                                if(isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                {
                                        $usd = $return['exchange_rate'];

                                        $data['from_currency'] = 'EUR';
                                        $data['to_currency'] = 'CDF';

                                        $return = $this->curl_model->call_bank_exchange_rate($data);
										
										$return = json_decode($return, true);

                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                        $_POST['usd'] = $usd;
                                        $_POST['eur'] = $eur;
                                        $_POST['rand'] = "";
                                        $_POST['pound'] = "";

                                        $this->save('taux');
										

                                        $this->rates_model->get_exchange_rates();
                                }
                                
                        }
						
                }
                
                # Exchange rates
                #
                ################################################################################
                elseif($obj == "default_values_new_taux")
                {
                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                if($bank['Checkerid_11']==0): 
                                        $this->data['id'] = $bank['Id_0']; 
                                else :
                                        $this->data['id'] = ''; 
                                        $this->data['reset'] = 1; 
                                endif;   
                                
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Le taux de la banque n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute; automatiquement d&ucirc; &agrave; un probl&egrave;me de connexion avec finacle.!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }
                        
                        $this->data['action'] = '...';
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }
                        
                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')
                                    
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }
                ################################################################################
                # Dashboard Pie chart
                ################################################################################
                if($obj == "pie-chart")
                {
                        if($arg=='commission')
                        {
                                    $stats = $data;
                            
                                    $datas = '
                                                {value:'.$stats[2].',label:"CDF",color:"#00C6F3",highlight:"green"},
                                                {value:'.$stats[3].',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                                {value:'.$stats[1].',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                                {value:'.$stats[4].',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                        elseif($arg=='paiement')
                        {
                                    $stats = $data;
                                    
                                    $datas = '
                                                {value:'.$stats[2].',label:"CDF",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats[3].',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats[1].',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats[4].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                }
                elseif($obj == "pie-chart_operator")
                {
                        if($arg=='paiement_situation_cdf')
                        {
                                    $stats = $data;
                                    //var_dump($stats); die;
                                    $datas = '
                                                {value:'.$stats['unvalidated'].',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats['validated'].',label:" CDF",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats['reversed'].',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats['none'].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                        elseif($arg=='paiement_situation_usd')
                        {
                                    $stats = $data;
                                    
                                    $datas = '
                                                {value:'.$stats['unvalidated'].',label:" USD",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats['validated'].',label:" USD",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats['reversed'].',label:" USD",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats['none'].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                }
                
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */