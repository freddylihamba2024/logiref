<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends MY_Controller {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
               
	} 
	
        
	public function index()
	{
                $data = array();
                
                $url = 'https://104.197.67.14/api/endpoints/logirad/checknote.php';
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->option('SSL_VERIFYPEER',0);
                $this->curl->option('SSL_VERIFYHOST',0);
                $this->curl->post($data);
                $response = $this->curl->execute();
                
                var_dump($response); die;
		if($response == false)
		{
			echo $this->curl->error_code;
		}else{
                        var_dump($response); die;
		}
	}
    
}

/* End of file welcome.php  */
/* Location: /project/activities  */