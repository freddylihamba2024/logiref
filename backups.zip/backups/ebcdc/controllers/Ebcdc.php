<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ebcdc extends MY_Controller {
        public $months = array('',"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov", "Dec");
        public $roles_banks = array('1'=>'admin', '2'=>'director', '3'=>'manager', '4'=> 'operator');
        
        public $group = ''; //Banks, Regies, Clients
        public $category = '202'; //Family, SMB, Enterprise
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $roles = '';
        public $lang = 'fr';
        public $country = '0';
        
        
        public function __construct()
	{
		parent::__construct();
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('logiref/logiref_model');
                $this->load->model('ebcdc/integration_model');
                $this->load->model('ebcdc/encaissement_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model('ebcdc/users_model');
                
                $this->lang = $this->session->userdata('user_lang');
                $this->country = $this->session->userdata('account_country');
                $this->data['Toggle'] = true;
                
                $this->data['module'] = 'ebcdc';
                $this->data['application'] = '';
                $this->data['function'] = $this->uri->segment(3);
                $this->data['sidebar'] = ''; //
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                
                $accounts = array('101'=>'enterprise', '202'=>'business', '303'=>'family'); 
                $account_category = $this->session->userdata('account_category');
                $this->category = $accounts[$account_category]; 
                $account_id = $this->session->userdata('account_id');
                $banks_account_id = array('REN45',); //A completer ...
                $isys_account = $this->integration_model->get_isys_account_info();
                $sydonia_account = $this->integration_model->get_sydonia_account_info();
                
                //Isys account initialisation
                if($isys_account == NULL)
                {
                        $this->save('isys');
                }

                //Sydonia account initialisation
                if($sydonia_account == NULL)
                {
                        $this->save('sydonia');
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                */
                if(isset($_SESSION['Logiref_userid']) && $_SESSION['Logiref_userid'] != $_SESSION['user_id'])
				{
						unset($_SESSION['Logiref_privileges']);
				}
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->users_model->get_privilegies();
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                /* Known group */
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_groupe']!='')
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                /* Unregistered bank */
                elseif(in_array($account_id, $banks_account_id))
                {
                        $this->save("beneficiaire");
                        $this->users_model->get_privilegies();
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                /* Log out */
                elseif(!isset($_SESSION['account_id']))
                {
                        redirect('/page/logiref', 'refresh');
                }
                /* else*/
                else
                {
                        //Nothing
                }
                
                
                
                
	}
        
	
	public function index()
	{      
                /* Registered businesses: banks & revenues authorities */
                if(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 0 && $this->group != '' && $this->country=='60')
                {
                        if($_SESSION['Logiref_role']==1)
                        {
                                $this->data['users_stats'] = $this->users_model->get_users_stats();
                        }
                        
                        if($this->group == 'banks')
                        {
                                redirect('ebcdc/dashboards/set/overview', 'refresh');
                        }
                }
                /** Unknown */                
                else 
                {
                        $this->data['country'] = $this->country;
                        $this->data['subview'] = 'ebcdc/' . $this->lang.'_denial';
                }
                $this->data['lang'] = $this->session->userdata('user_lang');
		$this->load->view("_layout_ebcdc", $this->data);
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj=="OBJ")
                {
                
                }
        }
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj=="beneficiaire")
                {
                        /* A completer pour creer metadonn?es des banques... */
                        $beneficiaires = $this->stakeholders_model->get_beneficiaries("Banks");
                
                        if(empty($beneficiaires))
                        {
                                $data['Date_1']= gmdate('Y-m-d H:i:s');
                                $data['Status_2']= 1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Type_4']= 'BKC';
                                $data['Description_5']= $this->session->userdata('account_business');
                                $this->stakeholders_model->save_beneficiairie($data, NULL);
                        }
                }
                elseif($obj=="isys")
                {
                        
                        $data['Date_1']= gmdate('Y-m-d H:i:s');
                        $data['Status_2']= 1;
                        $data['Account_3']= $this->session->userdata('account_id');
                        $data['Login_7']= 'BKC';
                        $data['Password_8']= 'BKC';
                        $this->integration_model->save_isys_account($data, NULL);
                }
                elseif($obj=="sydonia")
                {
                        $data['Date_1']= gmdate('Y-m-d H:i:s');
                        $data['Status_2']= 1;
                        $data['Account_3']= $this->session->userdata('account_id');
                        $data['Creator_4'] = $this->session->userdata('user_id'); 
                        $data['Bank_7']= '0000';
                        $this->integration_model->save_sydonia_account($data, NULL);
                }
                
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * List:
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                        
                }
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */