<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Accounts extends MY_Controller {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('comptes','prepayments','tarification_accounts');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'ebcdc';
        public $folder = 'accounts';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->load->model('MY_Logiref_Ebcdc');
                $this->load->model('MY_Logiref_Main');
                $this->load->model('MY_Logiref_Ebcdc_Integration');
                $this->load->model('MY_Main');
                $this->load->model('main/main_model');
                $this->load->model($this->module.'/integration_model');
                $this->load->model($this->module.'/accounts_model');
                $this->load->model('logiref/logiref_model');
                $this->load->model($this->module.'/branches_model');
                $this->load->model($this->module.'/users_model');
                $this->load->model('logiref/stakeholders_model');
                $this->load->model($this->module.'/curl_model');
                $this->load->model($this->module.'/comptabilisation_model');
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'accounts';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logiref_model->documents;
                $this->data['devises'] = $this->logiref_model->devises;
                $this->data['modes'] = $this->logiref_model->modes;
                $this->data['moyens'] = $this->logiref_model->moyens;
                $this->data['infos'] = $this->logiref_model->infos;
                $this->data['currency'] = $this->session->userdata('account_currency');
                $this->data['fullname'] = $this->session->userdata('user_fname');
                $this->data['userid'] = $this->session->userdata("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata('user_roles');
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata('user_type') == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
                                
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = 'container';
		$this->load->view("_layout_".$this->module, $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "comptes")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['agences'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                                $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                                $this->data['comptes'] = $this->accounts_model->get_comptes("cptes");
                                
                                $this->data['lastestComptes'] = $this->accounts_model->get_latest_validated_accounts();
                        }
                        else
                        {
                                $this->data['guichets'] = $this->branches_model->get_dropdown("guichets", NULL, "ALL");
                                $this->data['comptes'] = $this->accounts_model->get_comptes();
                        }
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/comptes', $this->data);
                }
                elseif($obj == "compte") 
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['service_types'] =$this->accounts_model->type_service;
                        $this->data['services'] =$this->logiref_model->get_dropdown("services");
                        $this->data['banque'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logiref_model->get_dropdown("recettes");
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['compte'] = $this->accounts_model->get_compte_info($id);
                        
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_compte', $this->data);
                }
                elseif($obj == "filter")
                {
                        $this->data['types'] = $this->logiref_model->get_dropdown("types","Compte");
                        $this->data['villes'] = $this->logiref_model->get_dropdown("parameter",'VILLE');
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accounts_model->get_filtered_accounts($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_comptes', $this->data);
                }
                
                elseif($obj == "prepayments") 
                {
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['comptes'] = $this->accounts_model->get_prepaid_comptes();
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/prepayments', $this->data);
                }
                elseif($obj == "prepayment") 
                {
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['compte'] = $this->accounts_model->get_prepaid_compte_info($id);
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_prepayment', $this->data);
                }
                elseif($obj == "tarification_accounts")
                {
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['agences'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['tarifications'] = $this->accounts_model->get_client_exoneres();
                        $this->data['lastestComptes'] = $this->accounts_model->get_latest_validated_accounts();
                        
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/tarification_accounts', $this->data);
                }
                elseif($obj == "tarification_account") 
                {
                        #$this->data['from'] = $arg;
                        $this->data['tarification'] = $this->accounts_model->get_clientexonere_info($id);
                        $this->data['devises'] = $this->logiref_model->devises;
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_tarification_account', $this->data);
                }
                elseif($obj == "filterTarif")
                {
                        $this->data['beneficiaires'] = $this->stakeholders_model->get_dropdown("beneficiaries");
                        $this->data['users'] = $this->main_model->get_dropdown('users_array');
                        $this->data['agences'] = $this->branches_model->get_dropdown("guichets");
                        $this->data['tarifications'] = $this->accounts_model->get_filtered_tarifications($_POST);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_tarification_accounts', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "compte")
                {
                        #Save compte
                        # Validate compte form 
                    
                        if($_POST['Compte_6']=='0' || $_POST['Compte_6']==''  || $_POST['Devise_8']==''  || ($_POST['Beneficiaires1']=='' && $_POST['Beneficiaires2']=='' && $_POST['Beneficiaires3']=='')  || $_POST['Type_4']==''):
                                echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Makerid_9']=$this->session->userdata('user_id');
                               
                        endif;
                        
                        if($_SESSION['Logiref_role']==1):
                                $data['Type_4']=$_POST['Type_4'];
                                if($data['Type_4'] ==="CAC" || $data['Type_4'] ==="CPI" || $data['Type_4'] ==="CFE"): 
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires1'];
                                elseif($data['Type_4'] ==="CPT" || $data['Type_4'] ==="CGU"|| $data['Type_4'] ==="CTP"):
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires3'];
                                else:
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires2'];
                                endif;
                                
                                if($_POST['Beneficiaires3'] == "DGI"):
                                        if(isset($_POST['service1'])) $service = $this->input->post("service1"); else $service = "";
                                else:    
                                        $service = $this->input->post("service");
                                endif;
                                
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                    
                                        $devise = $this->input->post("Devise_8");
                                        $type= $this->input->post("Type_4");
                                        $beneficiaire = $data['Beneficiaires_5'];
                                        $agence = $this->input->post("agence");
                                        $compte = $this->input->post("Compte_6");
                                        $recette = $service  = NULL;
                                        if($agence == "" || $agence == '0'):
                                            
                                                echo '<div class="alert alert-warning">Vous devez s&eacute;l&eacute;ctionner une agance !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                                
                                        endif;

                                        if(isset($_POST['service']))$service = $this->input->post("service");
                                        if(isset($_POST['recette']))$recette = $this->input->post("recette");
                                       
                                        $comptes = $this->accounts_model->get_comptes_by_parameters($compte, $devise, $type, $beneficiaire, $agence, $recette, $service);

                                        if(!empty($comptes))
                                        {
                                                echo '<div class="alert alert-danger">D&eacute;sol&eacute; il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                endif;
                                #var_dump($_POST['Beneficiaires2']);die;
                                
                                $aCmpt = explode("-", trim($_POST['Compte_6']));
                                #Optional keys
                                if(isset($aCmpt[0])) $data['Agenceid_15'] = trim($aCmpt[0]);
                                if(isset($aCmpt[1])) $data['Compte_6'] = trim($aCmpt[1]);
                                if(isset($aCmpt[2])) $data['Clef_7'] = trim($aCmpt[2]);
								
								if(isset($aCmpt[0])) $data['Agenceid_15'] = str_replace(' ', '',$aCmpt[0]);
                                if(isset($aCmpt[1])) $data['Compte_6'] = str_replace(' ', '',$aCmpt[1]);
                                if(isset($aCmpt[2])) $data['Clef_7'] = str_replace(' ', '',$aCmpt[2]);
								
                                #Devise par defaut
                                if($data['Type_4']=='CPU') $data['Devise_8']= 'USD';
                                elseif($data['Type_4']=='TVA') $data['Devise_8']= 'CDF';
                                #elseif($data['Type_4']=='CFB') $data['Devise_8']= 'CDF';
                                elseif($data['Type_4']=='CCV') $data['Devise_8']= 'CDF';
                                else $data['Devise_8']=$_POST['Devise_8'];
                                #Validation section
                                
                                if(isset($_POST['agence']))
                                {
                                        $data['Agence_12'] = $_POST['agence'];
                                }
                                if(isset($_POST['ville']))
                                {
                                        $data['Ville_14'] = $_POST['ville'];
                                }
                                if(isset($_POST['recette']))
                                {
                                       $data['Recette_13'] = $_POST['recette']; 
                                }
                                if(isset($_POST['service'])|| $_POST['service1'])
                                {
                                        if($_POST['Beneficiaires3'] == "DGI")
                                        {
                                                if(isset($_POST['service1'])) $data['Serviceid_16'] = $_POST['service1'];
                                        }
                                        else
                                        {
                                                $data['Serviceid_16'] = $_POST['service']; 
                                        }
                                }
                                if(isset($_POST['nif']))
                                {
                                       $data['Nif_17'] = $_POST['nif']; 
                                }
                                if(isset($_POST['comptesydonia']))
                                {
                                       $data['Comptesydonia_18'] = $_POST['comptesydonia']; 
                                }
                                
                                $code_agence= $this->branches_model->get_dropdown("codeagences");
                                if(isset($code_agence[$_POST['agence']]) && $code_agence[$_POST['agence']] !="")
                                {
                                       $data['Code_agence_19'] = $code_agence[$_POST['agence']]; 
                                }
                                
                                $data['Validation_10']='0000-00-00';
                                $data['Checkerid_11']=0;
                        else:
                                $data['Validation_10']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11']=$this->session->userdata('user_id');
                        endif;    
                        #Database
                        $cid = $this->accounts_model->save_compte($data, $id);
                        
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == 'prepayment')
                {
                    # Save compte
                    # Validate compte form 
                    #var_dump($_POST); die;
                    if($_POST['Accountnumber']=='0' || $_POST['Accountnumber']==''  || $_POST['Devise']==''  || ($_POST['Refsydonia']=='0' && $_POST['Refsydonia']=='')):
                            echo '<div class="alert alert-danger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                            die;
                    endif;
                    if($id=='0' || $id==''):
                            $data['Date_1']=gmdate('Y-m-d H:i:s');
                            $data['Status_2']=1;
                            $data['Creator_4']=$this->session->userdata('user_id');
                            $data['Account_3']=$this->session->userdata('account_id');
                            $data['Makerid_11']=$this->session->userdata('user_id');
                    endif;
                    if($_SESSION['Logiref_role']==1):
                            
                            $data['Devise_10'] = $devise = $this->input->post("Devise");
                            $data['Nifimportateur_7'] = $this->input->post("Nifimportateur");
                            $data['Refsydonia_9'] = $accountSydonia = $this->input->post("Refsydonia");
                            $accountcbs = $data['Accountnumber_8'] = $this->input->post("Accountnumber");

                            $count_number = $this->accounts_model->tcheck_prepaid_account($accountcbs, $devise);

                            if(!empty($count_number))
                            {
                                    echo '<div class="alert alert-danger">D&eacute;sol&eacute; il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                    die;
                            }
                        
                            $data['Validation_13']='0000-00-00';
                            $data['Checkerid_12']=0;
                    else:
                           
                            $data['Changes_5']=gmdate('Y-m-d H:i:s');
                            $data['Changer_6']=$this->session->userdata('user_id');
                            $data['Validation_13']=gmdate('Y-m-d H:i:s');
                            $data['Checkerid_12']=$this->session->userdata('user_id');
                    endif;    
                    #Database
                    $cid = $this->accounts_model->save_prepaid_accounts($data, $id);    
                    if($cid): 
                            echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    endif;
                    
                }
                else if($obj == "tarification_account")
                {
                        if($_POST['Id_0']=='0' || $_POST['Id_0']=='')
                        {
                                $data['Date_1'] = date('Y-m-d H:i:s');
                                $data['Status_2'] ='1';
                                $data['Account_3'] = $this->session->userdata('account_id');
                                $infos = isset($_POST['Infos'])? $_POST['Infos'] : NULL;
                                $data['Infos_14'] = json_encode($infos);
                        }
                       
                        if(isset($_POST['Beneficiaires3']) && $_POST['Beneficiaires3'] !="") $data['Beneficiaires_7'] = $this->input->post('Beneficiaires3');
                        
                        if (empty($_POST['amount']))
                        {
                            $data['Montant_11'] = NULL;
                        }
                        elseif (isset($_POST['amount']))
                        {
                            $data['Montant_11'] = str_replace(' ','',$_POST['amount']);
                            $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        }

                        if($_SESSION['Logiref_role']==1):
                                $data['Beneficiaires_7']= $_POST['Beneficiaires3'];
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):

                                        $data['Devise_10']=$this->input->post("Devise_10");
                                        $data['Agence_12']= $this->input->post("agence");
                                        $data['Compte_8']= $this->input->post("Compte_8");
                                        if (isset($_POST['amount']))
                                        {
                                            $data['Montant_11'] = str_replace(' ','',$_POST['amount']);
                                            $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                        }

                                endif;

                                $aCmpt = explode("-", trim($_POST['Compte_8']));
                                
                                #Optional keys
                                if(count($aCmpt) > 2)
                                {
                                    if(isset($aCmpt[0])) $data['Agenceid_9'] = trim($aCmpt[0]);
                                    if(isset($aCmpt[1])) $data['Compte_8'] = str_replace('-','',$_POST['Compte_8']);
                                    if(isset($aCmpt[2])) $data['Clef_15'] = trim($aCmpt[2]);
                                }
                                else
                                {
                                    if(isset($aCmpt[0])) $data['Agenceid_9'] = trim($aCmpt[0]);
                                    if(isset($aCmpt[1])) $data['Compte_8'] = str_replace('-','',$_POST['Compte_8']);
                                }
                                

                                $data['Validation_13']='0000-00-00';
                                $data['Changer_6']=0;
                                $data['Creator_4']=$this->session->userdata('user_id');
                        else:
                                $data['Validation_13']=gmdate('Y-m-d H:i:s');
                                $data['Changer_6']=$this->session->userdata('user_id');
                        endif;
                        
                        #Database
                        $cid = $this->accounts_model->save_tarification_account($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $object=$this->input->get('object');
                        $checkerid=$this->input->get('checkerid');
                        #var_dump($checkerid);die;
                     
                        if($object=='remove_account')
                        {
                                if($_SESSION['Logiref_role']==1):
                                        $data['Status_2'] = '2';
                                        $data['Validation_10']='0000-00-00';
                                        $data['Checkerid_11']=0;
                                else:
                                    $data['Status_2'] = '0';
                                    $data['Validation_10']=gmdate('Y-m-d H:i:s');
                                    $data['Checkerid_11']=$this->session->userdata('user_id');
                                endif;
                                $did = $this->accounts_model->delete_account($data, $id);
                                
                                if($did): 
                                        echo '<div class="alert alert-success text-white">Bravo! Informations supprime&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                endif;
                        }
                        elseif($object=='cancel_delete')
                        {
                                if($_SESSION['Logiref_role']==1):
                                    $data['Status_2'] = '1';
                                    $data['Validation_10']='0000-00-00';
                                    $data['Checkerid_11']=0;
                                else:
                                    $data['Validation_10']=gmdate('Y-m-d H:i:s');
                                    $data['Checkerid_11']=$this->session->userdata('user_id');
                                endif;
                                $did = $this->accounts_model->delete_account($data, $id);
                                
                                if($did): 
                                        echo '<div class="alert alert-success text-white">Bravo! Informations supprime&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                endif;
                        }
                }
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        $members = $this->users_model->get_members();
                        $type = $this->session->userdata('user_type');
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata('account_id');
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata('user_id');
                                $cid = $this->users_model->save_users($data, NULL);
                                if($cid) $members = $this->users_model->get_members();
                        }
                        return $members;
                }
                elseif($obj == "get_accountname")
                {
                    #var_dump("ici");die;
                        $data = array();
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Devise_34'] = $_POST['devise'];
                        $data['agence'] = $_SESSION['Guichet_code'];
						
                        $return = $this->curl_model->call_bank_account_info($data);
						
                        if($return == '404' || $return == '406' || $return == '405')
                        {
                                echo $return;
                        }
                        else
                        {
                                if(isset($return) && $return != "")
                                {
                                        //reponse_tax = $this->curl_model->call_bank_tax_exempt($data);
                                        $reponse_tax = 300;
                                        $result = json_decode($return, true);
                                        
                                        $response['account'] = $result['account'];
                                        $response['devise'] = $result['devise'];
                                        $response['balance'] = $result['balance'];
                                        $response['tax_info'] = $reponse_tax;
                                        
                                        $return = json_encode($response);
                                        
                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo '406';
                                }
                        }
                       
                       
                }
                elseif($obj == "get_accountname_internal")
                {
                    #var_dump("tres");die;
                        $data = array();
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Devise_34'] = $_POST['devise'];
                        $data['agence'] = $_SESSION['Guichet_code'];
						
                        $return = $this->curl_model->call_bank_account_internal_info($data);
                        if($return == '404' || $return == '406' || $return == '405')
                        {
                                echo $return;
                        }
                        else
                        {
                                if(isset($return) && $return != "")
                                {
                                        $reponse_tax = $this->curl_model->call_bank_tax_exempt($data);
                                        $result = json_decode($return, true);
                                        
                                        $response['account'] = $result['account'];
                                        $response['devise'] = $result['devise'];
                                        $response['tax_info'] = $reponse_tax;
                                        
                                        $return = json_encode($response);
                                        
                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo '406';
                                }
                        }
                }
                elseif($obj == "get_account_balance")
                {
                        if(isset($_POST['montant']) && isset($_POST['commission']) && isset($_POST['devise_compte']) && isset($_POST['balance']))
                        {
                                $amount = str_replace(' ','',$_POST['montant']);
                                $amount = str_replace(',','.',$amount);

                                $commission = str_replace(' ','',$_POST['commission']);
                                $commission = str_replace(',','.',$commission);

                                $tva = $commission * 0.16;
                                
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                $taux = $taux['Dollar_4'];

                                if($_POST['devise_compte'] == 'CDF')
                                {
                                        if($_POST['devise']=='USD')
                                        {
                                                $amount = $amount * $taux;
                                        }
                                        
                                        $amount_to_pay = $amount + $commission + $tva;

                                        if($_POST['balance'] >= $amount_to_pay)
                                        {
                                                echo 200;
                                        }
                                        else 
                                        {
                                                echo 300;
                                        }
                                }
                                elseif($_POST['devise_compte'] == 'USD')
                                {
                                        if($_POST['devise']=='CDF')
                                        {
                                                $amount = $amount/$taux;
                                        }
                                        
                                        $commission_tva = $commission + $tva;
                                        
                                        $commission_tva = $commission_tva/$taux;
                                        
                                        $amount_to_pay = $amount + $commission_tva;


                                        if($_POST['balance'] >= $amount_to_pay)
                                        {
                                                echo 200;
                                        }
                                        else 
                                        {
                                                echo 300;
                                        }
                                }
                        }
                        else
                        {
                                echo 'E405'; die;
                        }
                }
		elseif($obj == "get_trans_details")
                {
                        $data = array();
                        
                        $data['Reference_32'] = $_POST['transID'];
                        $data['transDate'] = $_POST['transDate'];
                        $data['Compte_33'] = $_POST['compte'];
                                            
                        $return = $this->curl_model->call_bank_trans_details($data);
                        
                        if($return == '404' || $return == '406' || $return == '405' || $return == '501')
                        {
                                echo $return;
                                die;
                        }
                        else
                        {
                                $result = json_decode($return, true);
                                $result['code'] = '200';

                                echo json_encode($result);
                                die;
                        }      
                }
                elseif($obj == "get_reservation")
                {
                        $bulletin = $this->integration_model->check_bulletin_sydonia();
                        $result= array();
                        $infos = array();
                        
                        if(isset($bulletin[0]->Id_0) && $bulletin[0]->Id_0 !="") $infos = json_decode($bulletin[0]->Reservation_34, true);
                        
                        if(isset($infos['lien_id']) && $infos['lien_id'] !="")
                        {
                                $id = $bulletin[0]->Id_0;
                                
                                $_SESSION['lien_id'] = isset($infos['lien_id']) ? $infos['lien_id'] : "";
                                $_SESSION['date_lien'] = isset($infos['date_lien']) ? $infos['date_lien'] : "";
                                
                                
                                $result['code'] = 'E500';
                                $result['id'] = $id;
                                echo json_encode($result);
                                
                        }
                        else
                        {
                                $api_data['compte'] = $_POST['compte'];
                                $api_data['devise'] = $_POST['devise'];
                                $api_data['montant'] = $_POST['montant'];

                                $api_data['montant'] = str_replace(' ','',$api_data['montant']);
                                $api_data['montant'] = str_replace(',','.',$api_data['montant']);

                                $response = $this->curl_model->call_bank_reservation($api_data);

                                $return = json_decode($response, true);

                                if($return['response']=='200')
                                {
                                        if(isset($_POST['bulletin_id']) && $_POST['bulletin_id'] !="")
                                        {
                                                $infos['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                $infos['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                $bl_data['Reservation_34'] = json_encode($infos);
                                                $bl = $this->integration_model->update_bulletin($bl_data, $_POST['bulletin_id']);
                                                
                                                $result['code'] = '200';
                                                
                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $_SESSION['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                $_SESSION['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                $result['code'] = '200';
                                                
                                                echo json_encode($result);
                                        }
                                }
                                elseif($return['response'] && $return['response'] != "") 
                                {
                                        $result['code'] = $return['response'];
                                                
                                        echo json_encode($result);
                                }
                                else 
                                {       
                                        $result['code'] = 'E411';
                                                
                                        echo json_encode($result);
                                }
                        }
                }
				elseif($obj == "get_batch_reservation")

                {

                        $reference_op = isset($_POST['refOp']) ? $_POST['refOp'] : "";

                        

                        $batch_line = $this->integration_model->check_batch_bulletin_sydonia($reference_op);

                       

                        $result= array();

                       

                        if(isset($batch_line[0]->Id_0) && $batch_line[0]->Id_0 !="")

                        {

                                $id = $batch_line[0]->Id_0;

                               

                                $infos = json_decode($batch_line[0]->Reservation_27, true);

                               

                                $_SESSION['lien_id'] = isset($infos['lien_id']) ? $infos['lien_id'] : "";

                                $_SESSION['date_lien'] = isset($infos['date_lien']) ? $infos['date_lien'] : "";

                               

                                $result['code'] = 'E500';

                                $result['id'] = $id;

                                echo json_encode($result);

                        }

                        else

                        {

                               

                                $api_data['compte'] = $_POST['compte'];

                                $api_data['devise'] = $_POST['devise'];

                                $api_data['montant'] = $_POST['montant'];

 

                                $api_data['montant'] = str_replace(' ','',$api_data['montant']);

                                $api_data['montant'] = str_replace(',','.',$api_data['montant']);

 

                                $response = $this->curl_model->call_bank_reservation($api_data);

 

                                $return = json_decode($response, true);

 

                                if($return['response']=='200')

                                {

                                        if(isset($_POST['bulletin_id']) && $_POST['bulletin_id'] !="")

                                        {

                                                $infos['lien_id'] = isset($return['lien']) ? $return['lien'] : "";

                                                $infos['date_lien'] = isset($return['date']) ? $return['date'] : "";

 

                                                $bl_data['Reservation_27'] = json_encode($infos);

                                                $bl = $this->integration_model->update_batch_bulletin($bl_data, $_POST['bulletin_id']);

                                               

                                                $result['code'] = '200';

                                                

                                                echo json_encode($result);

                                        }

                                        else

                                        {

                                                $_SESSION['lien_id'] = isset($return['lien']) ? $return['lien'] : "";

                                                $_SESSION['date_lien'] = isset($return['date']) ? $return['date'] : "";

 

                                                $result['code'] = '200';

                                               

                                                echo json_encode($result);

                                        }

                                }

                                elseif($return['response'] && $return['response'] != "")

                                {

                                        $result['code'] = $return['response'];

                                                

                                        echo json_encode($result);

                                }

                                else

                                {      

                                        $result['code'] = 'E411';

                                               

                                        echo json_encode($result);

                                }

                        }

                }
                elseif($obj == "get_reservation_credit")
                {
                        $bulletin = $this->integration_model->check_credit_bulletin_sydonia();
                        $result= array();;
                        
                        if(isset($bulletin[0]->Id_0) && $bulletin[0]->Id_0 !="")
                        {
                                $id = $bulletin[0]->Id_0;
                                $infos = json_decode($bulletin[0]->Reservation_34, true);
                                
                                $_SESSION['lien_id'] = isset($infos['lien_id']) ? $infos['lien_id'] : "";
                                $_SESSION['date_lien'] = isset($infos['date_lien']) ? $infos['date_lien'] : "";
                                
                                $result['code'] = 'E500';
                                $result['id'] = $id;
                                echo json_encode($result);
                        }
                        else
                        {
                                $api_data['compte'] = $_POST['compte'];
                                $api_data['devise'] = $_POST['devise'];
                                $api_data['montant'] = $_POST['montant'];

                                $api_data['montant'] = str_replace(' ','',$api_data['montant']);
                                $api_data['montant'] = str_replace(',','.',$api_data['montant']);

                                $response = $this->curl_model->call_bank_reservation($api_data);

                                $return = json_decode($response, true);

                                if($return['response']=='200')
                                {
                                        if(isset($_POST['bulletin_id']) && $_POST['bulletin_id'] !="")
                                        {
                                                $infos['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                $infos['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                $bl_data['Reservation_34'] = json_encode($infos);
                                                $bl = $this->integration_model->update_bulletin($bl_data, $_POST['bulletin_id']);
                                                
                                                $result['code'] = '200';
                                                
                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $_SESSION['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                $_SESSION['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                $result['code'] = '200';
                                                
                                                echo json_encode($result);
                                        }
                                }
                                elseif($return['response'] && $return['response'] != "") 
                                {
                                        $result['code'] = $return['response'];
                                                
                                        echo json_encode($result);
                                }
                                else 
                                {       
                                        $result['code'] = 'E411';
                                                
                                        echo json_encode($result);
                                }
                        }
                }
                elseif($obj == "batch_reservation")
                {
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        $ref = preg_replace('`[^0-9]`', '', $_POST['refOp']);
                        $transaction = $this->comptabilisation_model->get_instructions_dgda($ref);
                        //var_dump($transaction); die;
                        if(count($transaction) > 0)
                        {
                                
                                $lines = array();
                                $i = 1;
                                foreach($transaction as $row)
                                {
                                        $lines[$i]['status'] = $row->Status_2;
                                        $lines[$i]['id'] = $row->Id_0;
                                        $lines[$i]['reference'] = $ref;
                                        
                                        $i++;
                                }
                                
                                if($lines[1]['status'] =="1" && $lines[2]['status'] =="1" && $lines[3]['status'] =="1")
                                {
                                        
                                        # reference of the payment.
                                        $id = $data['Logirefid_4'] = $ref;
                                        
                                        $data['Sydonia_44'] = $id;
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Account_3'] = $this->session->userdata('account_id');
                                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                                        $data['Priority'] = 0;

                                        $response = $this->curl_model->call_bank_batch_reservation($data);
                                        $return = json_decode($response, true);
                                        
                                        if($return['response']=='200')
                                        {
                                                $batch_info["Status_2"] = 2;
                                                $batch_info["Integrateur_19"] = $this->session->userdata('user_id');
                                                $batch_info["Validation_18"] = gmdate('Y-m-d H:i:s');

                                                $this->comptabilisation_model->update_batch_instructions($ref, $batch_info);

                                                $result['code'] = '200';
                                                $result['reference'] = $ref;
                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $code = $return['response'];
                                                $result['reference'] = $ref;
                                                echo json_encode($result);
                                        }
                                }
                                elseif($lines[1]['status'] =="2" && $lines[2]['status'] =="2" && $lines[3]['status'] =="2")
                                {
                                        $result['code'] = '201';
                                        $result['reference'] = $ref;
                                        echo json_encode($result);
                                }
                               
                        }
                        else
                        {
                                # reference of the payment.
                                $data['Logirefid_4'] = $ref; 

                                $id = $this->data('batch_first_instructions',NULL, $data['Logirefid_4']);

                                $data['Sydonia_44'] = $id;
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Account_3'] = $this->session->userdata('account_id');
                                $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                                $data['Priority'] = 0;

                                $response = $this->curl_model->call_bank_batch_reservation($data);
                                $return = json_decode($response, true);
                                if($return['response']=='200')
                                {
                                        $batch_info["Status_2"] = 2;
                                        $batch_info["Integrateur_19"] = $this->session->userdata('user_id');
                                        $batch_info["Validation_18"] = gmdate('Y-m-d H:i:s');
                                        
                                        $this->comptabilisation_model->update_batch_instructions($ref, $batch_info);
                                        
                                        $result['code'] = '200';
                                        $result['reference'] = $ref;
                                        echo json_encode($result);
                                }
                                else
                                {
                                        $code = $return['response'];
                                        $retour = array('code'=> $code, 'reference'=> $ref);
                                        echo json_encode($retour);
                                }
                               
                        }
                        
                }
				elseif($obj == "cancel_batch_reservation")

                {

                        $api_data['compte'] = $_POST['compte'];

                        $api_data['devise'] = $_POST['devise'];

 

                        $batch = $this->integration_model->get_bulletin_batch_info($_POST['batch_id']);

 

                        $infos = json_decode($batch->Reservation_27, true);

 

                        $api_data['lien_id'] = $infos['lien_id'];

                        $api_data['date_lien'] = $infos['date_lien'];

 

                        $response = $this->curl_model->call_bank_cancel_reservation($api_data);

                                                                                             

                        $return = json_decode($response, true);

                                                                                             

                        if($return['response']=='200')

                        {

                                $info['lien_id'] = "";

                                $info['date_lien'] = "";

                                $batch_data['Reservation_27'] = json_encode($info);

                               

                                $this->integration_model->update_batch_bulletin($batch_data, $_POST['batch_id']);

                               

                                echo 200;

                        }

                        elseif($return['response'] && $return['response'] != "")

                        {

                                $response = $return['response'];

 

                                echo $response;

                        }

                        else

                        {      

                                echo 'E411';

                        }

                }
				elseif($obj == "get_account_tarification") 
                {
                        $data = array();
                        
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['agence'] = $_SESSION['Guichet_code'];
                        
                        $compte= explode('-',$data['Compte_33']);
                        
                        if(count($compte) == 2)
                        {
                                $agence = $compte[0];
                                $digit = $compte[1];
                                $clef = NULL;

                        }
                        elseif(count($compte) == 3)
                        {
                                $agence = $compte[0];
                                $digit = $compte[1];
                                $clef = $compte[2];
                        }
                        elseif(count($compte) == 1)
                        {
                                $agence =NULL;
                                $digit = $compte[0];
                                $clef = NULL;

                        }
                        else
                        {
                                $agence = "";
                                $digit = "";
                                $clef = NULL;

                        }
					
                        $return = $this->accounts_model->get_account_tariff($agence = NULL, $data['Compte_33'], $data['Beneficaire_15']);

                        
                        if(!empty($return))
                        {
							    $return = current($return);

								$tarif = isset($return->Infos_14) ? json_decode($return->Infos_14, true):"";
								
                                $response['commission'] = isset($return->Montant_11)? $return->Montant_11: '';
                                $response['tva'] = isset($tarif['tva']) ? $tarif['tva'] : '';
                                $response['fraisbcc'] = isset($tarif['fraisbcc']) ? $tarif['fraisbcc'] : '';
                                $response['devise'] = 'CDF';
                                        
                                $return = json_encode($response);
                                
                                # return data in json format : amount, devise, agence.
                                echo $return;
                        }
                        else
                        {
                                $response['commission'] = -1;
                                $response['fraisbcc'] = 1;
                                $return = json_encode($response);
                                
                                echo $return;
                        }
                }
                elseif($obj == "cancel_reservation")
                {
                        $api_data['compte'] = $_POST['compte'];
                        $api_data['devise'] = $_POST['devise'];

                        $bulletin = $this->integration_model->get_paiement_sydonia($_POST['bulletin_id']);

                        $infos = json_decode($bulletin->Reservation_34, true);

                        $api_data['lien_id'] = $infos['lien_id'];
                        $api_data['date_lien'] = $infos['date_lien'];

                        $response = $this->curl_model->call_bank_cancel_reservation($api_data);
						
                        $return = json_decode($response, true);
						
                        if($return['response']=='200')
                        {
                                $info['lien_id'] = "";
                                $info['date_lien'] = "";
                                $bl_data['Reservation_34'] = json_encode($info);
                                
                                $this->integration_model->update_bulletin($bl_data, $_POST['bulletin_id']);
                                
                                echo 200;
                        }
                        elseif($return['response'] && $return['response'] != "") 
                        {
                                $response = $return['response'];

                                echo $response;
                        }
                        else 
                        {       
                                echo 'E411';
                        }
                }
                elseif($obj == "cancel_batch_reservation")
                {
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);
                        $ref = preg_replace('`[^0-9]`', '', $_POST['refOp']);
                        
                        # reference of the payment.
                        $id = $data['Logirefid_4'] = $ref;

                        $data['Sydonia_44'] = $id;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata('account_id');
                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '';
                        $data['Priority'] = 0;

                        $response = $this->curl_model->call_bank_cancel_batch_reservation($data);
                        $return = json_decode($response, true);
                       
                        if($return['response']=='200')
                        {
                                $batch_info["Status_2"] = 2;
                                $batch_info["Integrateur_19"] = $this->session->userdata('user_id');
                                $batch_info["Validation_18"] = gmdate('Y-m-d H:i:s');

                                $this->comptabilisation_model->update_batch_instructions($ref, $batch_info);

                                $result['code'] = '200';
                                $result['reference'] = $ref;
                                echo json_encode($result);
                        }
                        else
                        {
                                $code = $return['code'];
                                $retour = array('code'=> $code, 'reference'=> $ref);
                                echo json_encode($retour);
                        }
                }
                elseif($obj == "get_account_tarification") 
                {
                        $data = array();
                        
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['agence'] = $_SESSION['Guichet_code'];
                        
                        $compte= explode('-',$data['Compte_33']);
                        
                        if(count($compte) == 2)
                        {
                                $agence = $compte[0];
                                $digit = $compte[1];
                        }
                        elseif(count($compte) == 1)
                        {
                                $agence =NULL;
                                $digit = $compte[0];
                        }
                        else
                        {
                                $agence = "";
                                $digit = "";
                        }
						
                        $return = $this->accounts_model->get_account_tariff($agence = NULL, $digit, $_POST['regie']);

                        if(!empty($return))
                        {
                                $response['commission'] = $return['0']->Montant_11;
                                $response['devise'] = 'CDF';
                                        
                                $return = json_encode($response);

                                # return data in json format : amount, devise, agence.
                                echo $return;
                        }
                        else
                        {
                                $response['commission'] = -1;
                                
                                $return = json_encode($response);
                                
                                echo $return;
                        }
                }
                elseif($obj == "batch_first_instructions")
                {
                        $data = array();
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Agence_20']=$_SESSION['Logiref_agence'];
                        $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                        $data['Mode_19'] = $_POST['mode'];
                        $data['Typerecette_17'] = 'OP'.$arg;
                        $data['Devise_34'] = 'CDF';

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ','',$_POST['total_topaid']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);

                        $data['Devise_12'] = $_POST['cdevise'];
                        $data['Compte_33'] = $_POST['account'];
                        $logirefid = $data['Noteid_26'] = $arg;


                        //Formatting amount
                        $data['Commission_23'] = str_replace(' ','',$_POST['Commission']);
                        $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);

                        $data['Devise_24'] = $_POST['devise_commision'];
                        $data['Nif_13'] = $_POST['Nif'];
                        
                        $data['Notereference_30'] = json_encode(array("tva"=>"tva"));
                        $data['Notedate_27'] = "-";
                        $data['Artbudgetaire_18'] = "-";
                        $agence_src= $_SESSION['Logiref_guichet'];

                        $case = $this->comptabilisation_model->get_use_case($data);
                        $comptes = $this->accounts_model->get_comptes_array(NULL, $agence_src, NULL);

                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisation_model->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        break;
                        }

                        if(!empty($instructions1))
                        {
                                # priority for integrating the counting in cbs
                                $priority = 0; 
                                $ins =  $this->comptabilisation_model->save_instructions($arg, $data, $instructions1, $logirefid, $priority);
                        }
                        return $arg;
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */