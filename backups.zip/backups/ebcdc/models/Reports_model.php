<?php
class Reports_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
	
        public $regies = array(
            ''=>'',
            'DGI'=>'DGI',
            'DGRAD'=>'DGRAD'
        );
        
		public $status = [ 
                ''=>'',
                '1' => 'Initialis&eacute;', 
                '2' => 'Valid&eacute & confirm&eacute;', 
                '3' => 'Revers&eacute', 
                '4' => 'Non reconnue',
                '5' => 'Regularisation',
                '6' => 'Non r&eacute;parti',
                '7' => 'Non confirm&eacute;'
        ];

        public $status_color = array(
                ''  => '',
                '1' => 'label-primary',    
                '2' => 'label-success',
                '3' => 'label-warning',
                '4' => 'label-upcoming',
                '5' => 'label-danger', 
                '6' => 'label-dark', 
                '7' => 'label-info',
        );
        

	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
               $account_id = $this->session->userdata('account_id');
                
                if($item=="designation")
                {
                        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_paiements_tresor');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Designation_14']] = $row['Designation_14'];
                        }
                        return $ddmenu;    
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_validated_paiements_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND (Status_2 = 1 OR Status_2 = 3) AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Typerecette_17 != '27421600' AND Sydonia_44=0 AND Sydonia_49=0";
                
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(2000);
                return $this->get_all();
	}
	
	public function get_validated_paiements_passports_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND (Status_2 = 2 OR Status_2 = 3) AND (Beneficaire_15='DGRAD') AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0";
                
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(2000);
                return $this->get_all();
	}
	
	public function get_validated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');

                # Get the name of the current day
                $today = date('Y-m-d');
                $dayOfWeek = date('l', strtotime($today));
                
				$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Typerecette_17 != '27421600' AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
				if ($dayOfWeek === 'Monday') {
                    $this->db->where('Date_1 >=', date('Y-m-d', strtotime('-3 days')));
                } else {
                    $this->db->where('Date_1 >=', date('Y-m-d', strtotime('-1 days')));
                } 
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(1000);
                return $this->get_all();
	}
	
	public function get_validated_paiements_passports($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                $agence = $_SESSION['Logiref_agence'];
                $guichet = $_SESSION['Logiref_guichet'];

                # Get the name of the current day
                $today = date('Y-m-d');
                $dayOfWeek = date('l', strtotime($today));
                

                if ($agence == '1' && $guichet == '62')
                {
                        $this->_table_name = '';
                        #Query
                        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                        $this->db->from('logiref_paiements_tresor');
                        $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10>'0' AND Status_2=2 AND Beneficaire_15='DGRAD' AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0";
                        
                        #Restriction
                        // if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                        // if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                       
                        #Run
                        $this->db->where($st, NULL, FALSE);

                        if ($dayOfWeek === 'Monday') 
                        {
                                $this->db->where('Date_1 >=', date('Y-m-d', strtotime('-3 days')));
                        } else 
                        {
                                $this->db->where('Date_1 >=', date('Y-m-d', strtotime('-1 days')));
                        }
                        $this->db->order_by('Date_1 DESC');
                        $this->db->limit(1000);
                        return $this->get_all();
                }
	}
        
        public function get_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
		$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Typerecette_17 != '27421600' AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
	
	    public function get_nvalidated_paiements_passports($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata('user_id');
                
				$this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                $this->db->from('logiref_paiements_tresor');
				
				$st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGRAD') AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0 AND (Type_57 IS NULL OR Type_57='') AND Suppression_40 = '0000-00-00 00:00:00' AND Validation_36 = '0000-00-00 00:00:00' ";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
	}
        
        public function get_unvalidated_paiements_dgrk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('logiref_paiements_propres.*');
                $this->db->from('logiref_paiements_propres');
                $this->db->where("logiref_paiements_propres.Account_3 ='".$account_id."' AND Beneficaire_15 = 'DGRK' AND Checkerid_10='0' AND Status_2=1 ");
                $this->db->order_by('logiref_paiements_propres.Id_0');
                return $this->get_all();
	}
        
        public function get_validated_paiements_dgrk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
				$account_id=$this->session->userdata('account_id');
				$this->db->select('logiref_paiements_propres.*');
                $this->db->from('logiref_paiements_propres');
                $this->db->where("logiref_paiements_propres.Account_3 ='".$account_id."' AND Beneficaire_15 = 'DGRK' AND Checkerid_10 !='0' AND Status_2=1 ");
                $this->db->order_by('logiref_paiements_propres.Id_0');
                return $this->get_all();
	}
        
        public function get_paiements_tresor($type=NULL, $data=NULL)
        {
                                                             
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query

                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Beneficaire_15 = 'DGI' AND Sydonia_44 = 0 AND Sydonia_49 = 0  AND Checkerid_10 != 0";

                #Filtre d'affichage

                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                if(isset($_POST['user']) && $_POST['user']!='') $st .= " AND Makerid_9='".$_POST['user']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                #Restriction
                //if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role'] == 4 ) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();                                                  

        }

 		public function get_report_paiements_dgi_gu($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND Beneficaire_15='DGI' AND Typerecette_17 ='IPRIER' AND Sydonia_44 =0 AND Sydonia_49 =0";
                #Restriction
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        public function get_paiements_tresor_dgrad($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Beneficaire_15 = 'DGRAD' AND Sydonia_44 = 0 AND Checkerid_10 != 0 ";
                
                #Filtre d'affichage
                
                  if(isset($_POST['user']) && $_POST['user']!='') $st .= " AND Makerid_9='".$_POST['user']."'";
				if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                
                #Restriction
                //if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
				if($_SESSION['Logiref_role'] == 4 ) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
		
        public function get_paiements_taxegardiennage_dgrad() 
        {
                $this->_table_name = '';
                $agence = $_SESSION['Logiref_agence'];
                $this->_table_name = '';
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 ASC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Agence_20='" . $agence . "'  AND (Typerecette_17 = 27022470 || Typerecette_17 = 27022450)  AND Devise_12 = 'CDF' AND Checkerid_10 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_paiements_tresor.Id_0 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        public function get_paiements_filter_taxegardiennage_dgrad($type=NULL, $data=NULL)
        {
                $this->_table_name = '';
                $agence = $_SESSION['Logiref_agence'];
                $this->_table_name = '';
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 ASC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Agence_20='" . $agence . "' AND  (Typerecette_17 = 27022470 || Typerecette_17 = 27022450) AND Devise_12 = 'CDF' AND  Checkerid_10 <> 0";
                #Filtre d'affichage
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 = '".$_POST['start']."'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function get_paiements_passport_dgrad($type=null) 
        {
				$agence = $_SESSION['Logiref_agence'];
                $guichet = $_SESSION['Logiref_guichet'];
				
                $this->_table_name = '';
                $agence = $_SESSION['Logiref_agence'];
                $this->_table_name = '';
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 ASC');
                $this->db->from('logiref_paiements_tresor');
                				
				$st = '';

                if (isset($_POST['Status_2']) && $_POST['Status_2'] !='')
                {
                        if ($_POST['Status_2'] =='1') $st .= " Status_2='1' AND Checkerid_10 = 0";
                        if ($_POST['Status_2'] =='2') $st .= " Status_2='2'  AND Checkerid_10 <>  0";
                        if ($_POST['Status_2'] =='3') $st .= " (Status_2='3' AND Checkerid_10 <>  0)";
                        if ($_POST['Status_2'] =='4') $st .= " Status_2='4'";
                        if ($_POST['Status_2'] =='5') $st .= " Status_2='5'";
                        if ($_POST['Status_2'] =='6') $st .= " Status_2='6'";
                        if ($_POST['Status_2'] =='7') $st .= " Status_2='7'";
                }
                else
                {
                        $st .= " Status_2 !='0'";
                }

                $st .= " AND Typerecette_17 = '27421600'";
				
                #Restriction
				if ($agence == '1' && $guichet == '62')
				{
                        if($_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                }
				else
                {
						if($_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
						if($_SESSION['Logiref_role'] == 3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                }

                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
				elseif(isset($_POST['start']) && $_POST['start']=='')
                {}
                else
                {
                        $st .= " AND Datevaleur_31 ='".gmdate('Y-m-d')."'";
                }

                if(isset($_POST['Noteid_26']) && $_POST['Noteid_26']!='') $st .= " AND Noteid_26 LIKE '%" . $_POST['Noteid_26'] . "%'";

                if($type=='mobile') $st.=" AND Type_57='mobile'";
                else $st.=" AND (Type_57 IS NULL OR Type_57='')";

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_paiements_tresor.Id_0 DESC');
                $this->db->limit(1000);
                return $this->get_all();
        }
       
        public function get_paiements_filter_passport_dgrad($type=NULL, $data=NULL)
        {
                $this->_table_name = '';
                $agence = $_SESSION['Logiref_agence'];
                $this->_table_name = '';
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 ASC');
                $this->db->from('logiref_paiements_tresor');
                
                $st = " Typerecette_17 = 27421600  AND  Checkerid_10 <> 0";
               
                if($type=='online')
                {
                    $st.=" AND Type_57='mobile'";
                }
                else
                {
					
                    $st.=" AND Type_57 IS NULL";
                }
                
				#Restriction
				if($_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role'] == 3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
				
                #Filtre d'affichage
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                #var_dump($st);die;
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function get_paiements_tresor_gu($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND (Sydonia_44 != 0 OR Sydonia_49 != 0) AND Status_2 = 1 AND Checkerid_10 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
if(isset($_POST['user']) && $_POST['user']!='') $st .= " AND Makerid_9='".$_POST['user']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        
		public function get_paiements_gu_all_taxes($type=NULL, $date=NULL)
        {
                $st = " t.Account_3='" . $this->session->userdata('account_id') . "'AND t.Date_1 == '".gmdate('Y-m-d')."'  AND t.Status_2 = 1 AND t.Checkerid_10 !=0 AND t.Sydonia_44 !=0 AND p.Account_3='" . $this->session->userdata('account_id') . "' AND p.Date_1 == '".gmdate('Y-m-d')."' AND p.Status_2 = 1 AND p.Checkerid_10 !=0 AND p.Sydonia_44 !=0 ";
                
                $this->db->select(''
                        . 't.Id_0 as tresor_id, '
                        . 'p.Id_0 as propre_id, '
                        . 't.Date_1 as datepayment_tresor, '
                        . 'p.Date_1 as datepayment_propres, '
                        . 't.Montant_11 as montant_tresor, '
                        . 'p.Montant_11 as montant_propres, '
                        . 't.Devise_12 as devise_tresor, '
                        . 'p.Devise_12 as devise_propres, '
                        . 't.Designation_14 as designation_tresor, '
                        . 'p.Designation_14 as designation_propres, '

                        . 't.Beneficaire_15 as beneficaire_tresor, '
                        . 'p.Beneficaire_15 as beneficaire_propres, '
                        . 't.Service_16 as service_tresor, '
                        . 'p.Service_16 as service_propres, '
                        . 't.Typerecette_17 as typerecette_tresor, '
                        . 'p.Typerecette_17 as typerecette_propres, '
                        . 't.Guichet_21 as guichet_tresor, '
                        . 'p.Guichet_21 as guichet_propres, '
                        . 't.datevaleur_31 as datevaleur_tresor, '
                        . 'p.datevaleur_31 as datevaleur_propres, '
                        . 't.Sydonia_44 as sydonia_tresor, '
                        . 'p.Sydonia_44 as sydonia_propres, '
                        . 't.Sydonia_49 as prepaid_tresor, '
                        . 'p.Sydonia_49 as prepaid_propres, '
                        );
                #$this->db->select('*');

                $this->db->from('logiref_paiements_tresor as t');
                $this->db->join('logiref_paiements_propres as p', 't.Sydonia_44 = p.Sydonia_44', 'left');
                $this->db->where($st, NULL, FALSE);
                
                $query = $this->db->get();
                $this->db->limit(1);
                return $query->result();
        }
        
        
        public function get_paiements_gu_alltaxe($type=NULL, $date=NULL)
        {
                $st = " t.Account_3='" . $this->session->userdata('account_id') . "' AND t.Date_1 == '".gmdate('Y-m-d')."' AND t.Status_2 = 1 AND t.Checkerid_10 !=0 AND t.Sydonia_44 !=0 AND p.Account_3='" . $this->session->userdata('account_id') ."' AND p.Date_1 == '".gmdate('Y-m-d')."' AND p.Status_2 = 1 AND p.Checkerid_10 !=0 AND p.Sydonia_44 !=0 ";
                $this->db->select('t.Id_0 as tresor_id, p.Id_0 as propre_id, t.Montant_11 as montant_tresor, p.Montant_11 as montant_propres, t.Devise_12 as devise_tresor, p.Devise_12 as devise_propres, t.Nif_13 as nif_tresor, p.Nif_13 as nif_propres, t.Designation_14 as designation_tresor, p.Designation_14 as designation_propres, t.Beneficaire_15 as beneficaire_tresor, p.Beneficaire_15 as beneficaire_propres, t.Service_16 as service_tresor, p.Service_16 as service_propres, t.Typerecette_17 as typerecette_tresor, p.Typerecette_17 as typerecette_propres, t.Guichet_21 as guichet_tresor, p.Guichet_21 as guichet_propres, t.Noteid_26 as noteid_tresor, p.Noteid_26 as noteid_propres,t.Notereference_30 as note_tresor, p.Notereference_30 as note_propres, t.datevaleur_31 as datevaleur_tresor, p.datevaleur_31 as datevaleur_propres, t.Reference_32 as reference_tresor, p.Reference_32 as reference_propres, t.Sydonia_44 as sydonia_tresor, p.Sydonia_44 as sydonia_propres, t.Sydonia_49 as prepaid_tresor, p.Sydonia_49 as prepaid_propres, t.Tresor_45 as tresor_tresor, p.Tresor_45 as tresor_propres ')
				
                ->from('logiref_paiements_tresor as t')
                ->join('logiref_paiements_propres as p', 't.Sydonia_44 = p.Sydonia_44')
                ->where($st, NULL, FALSE);
				$this->db->limit(1);
                $query = $this->db->get();
				//$this->db->limit(1);
                return $query->result();
        }
		
        public function get_paiements_propres_gu($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND (Sydonia_44 != 0 OR Sydonia_49 != 0) AND Status_2 = 1 AND Checkerid_10 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(100);
                return $this->get_all();
        }
        
        public function get_paiements_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Sydonia_44 = '0' AND Checkerid_10 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        
        public function get_fond_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
                $this->db->from('logiref_paiements_propres');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND 	Beneficaire_15 != 'DGDA' AND Sydonia_44 =0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        
        public function get_fond_tresor($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata('user_id');
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "'";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
		public function get_paiements_tresor_dgi_gu($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = " Account_3='" . $this->session->userdata('account_id') . "' AND Typerecette_17 ='IPRIER' AND Sydonia_44 =0 AND Sydonia_49 =0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
if(isset($_POST['user']) && $_POST['user']!='') $st .= " AND Makerid_9='".$_POST['user']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
		public function get_paiements_tresor_dgi($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                $user = $this->session->userdata('user_id');
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                //$st = " Account_3='" . $this->session->userdata('account_id') . "' AND Beneficaire_15 = 'DGI' AND Sydonia_44 = 0 ";
		$st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' AND Typerecette_17 !='IPRIER') AND (Sydonia_44 =0 || Sydonia_49 = 0) AND Checkerid_10 !=0";

                
                #Filtre d'affichage
                //if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
		if(isset($_POST['user']) && $_POST['user']!='') $st .= " AND Makerid_9='".$_POST['user']."'";
			if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                
                #Restriction
                //if($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role'] == 4 ) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
		public function get_report_paiements($type=NULL, $data=NULL) 
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                $this->db->from('logiref_paiements_tresor');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGI' AND Typerecette_17 !='IPRIER') AND (Sydonia_44 =0 AND  Sydonia_49 = 0) AND Checkerid_10 !=0";
                #Restriction
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
				$this->db->limit(200);
                return $this->get_all();
        }
        public function get_report_paiements_dgrad($type=NULL, $data=NULL)
        {

                $this->_table_name = '';

                #Query

                $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');

                $this->db->from('logiref_paiements_tresor');

                $st = "Status_2 = 1 AND Account_3='" . $this->session->userdata('account_id') . "' AND (Beneficaire_15='DGRAD') AND (Sydonia_44 =0 || Sydonia_49 = 0) AND Checkerid_10 !=0";
				#Restriction
                if($_SESSION['Logiref_role']==4) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                #Run

                $this->db->where($st, NULL, FALSE);

                $this->db->order_by('Date_1 DESC');

                return $this->get_all();

        }
        public function get_filter_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
					$user = $this->session->userdata('user_id');
					
			$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = "Account_3='" . $this->session->userdata('account_id') . "' AND Checkerid_10='0' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
					
					#Filtre d'affichage
					if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
					if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
					

					#Restriction
					if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
					if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";
					
					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
        
		 public function get_paiements_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
				$user = $this->session->userdata('user_id');
				
				$this->_table_name = '';
				#Query
				$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
				$this->db->from('logiref_paiements_tresor');
				$st = "Account_3='" . $this->session->userdata('account_id') . "' AND (Status_2=5 OR Status_2=6) AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Typerecette_17 != '27421600'";
				
				#Restriction
				if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
				
				#Run
				$this->db->where($st, NULL, FALSE);
				$this->db->order_by('Date_1 DESC');
				return $this->get_all();
		}

		public function get_paiements_passports_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
                        $user = $this->session->userdata('user_id');
                        
                        $this->_table_name = '';
                        #Query
                        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
                        $this->db->from('logiref_paiements_tresor');
                        $st = "Account_3='" . $this->session->userdata('account_id') . "' AND (Status_2=4 OR Status_2=5 OR Status_2=6 OR Status_2=7) AND Beneficaire_15='DGRAD'";
                        
                        #Restriction
                        if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                        if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                        
                        #Run
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
		}
		public function get_filter_contribuable_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
		{
					$user = $this->session->userdata('user_id');
					
					$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = "Account_3='".$this->session->userdata('account_id')."'";
					#Filtre d'affichage
					if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
					if(isset($_POST['Guichet_21']) && $_POST['Guichet_21']!='') $st .= " AND Guichet_21='".$_POST['Guichet_21']."'";
					if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
					if(isset($_POST['Designation_14']) && $_POST['Designation_14']!='') $st .= " AND Designation_14='".$_POST['Designation_14']."'";
					if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
					#Restriction
					if($_SESSION['Logiref_role'] == 3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
		public function get_paiements_to_regulates_ci($data=NULL)
		{
					
			$this->_table_name = '';
					#Query
					$this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
					$this->db->from('logiref_paiements_tresor');
					$st = " Status_2=5";
					
					#Filtre d'affichage
					if(isset($data['regies']) && $data['regies']!=''):
						$st .= " AND Beneficaire_15='".$data['regies']."'";
					else:
						$st .= " AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
					endif;
					if(isset($data['guichet']) && $data['guichet']!='') $st .= " AND Guichet_21='".$data['guichet']."'";
					if(isset($data['start']) && $data['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$data['start']."' AND '".$data['end']."' ";

					#Run
					$this->db->where($st, NULL, FALSE);
					$this->db->order_by('Date_1 DESC');
					return $this->get_all();
		}
		public function get_commission_filter($data=NULL)
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                $this->db->from('logiref_regles');
                $st = " Status_2 != 0";

                #Filtre d'affichage
                if(isset($data['agence']) && $data['agence']!='') $st .= " AND Guichet_8='".$data['agence']."'";
                if(isset($data['regies']) && $data['regies']!='') $st .= " AND 	Beneficiaire_5='".$data['regies']."'";

                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}