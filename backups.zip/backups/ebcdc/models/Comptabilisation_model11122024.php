<?php
class Comptabilisation_model extends MY_Logiref_Ebcdc_Integration {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
		public $months = array
                        (
                            '00' => '',
                            '01' => 'Janvier',
                            '02' => 'Fevrier',
                            '03' => 'Mars',
                            '04' => 'Avril',
                            '05' => 'Mai',
                            '06' => 'Juin',
                            '07' => 'Juillet',
                            '08' => 'Aout',
                            '09' => 'Septembre',
                            '10' => 'Octobre',
                            '11' => 'Novembre',
                            '12' => 'Decembre'
                        );
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_dgda($bl) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Paiementid_4 ='" . $bl . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_first_instructions_dgda($bl) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Paiementid_4 ='" . $bl . "' AND Status_2 <> 0 AND Priority_24 = 0";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                return $this->get_all();
        }
        
        public function get_gu_instructions_dgi($pid) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_gu_instructions_dgi.*', 'logiref_cbs_gu_instructions_dgi.Id_0 ASC');
                $this->db->from('logiref_cbs_gu_instructions_dgi');
                $st = " Paiementid_4 ='" . $pid . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_gu_instructions_dgi.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_instructions_dgi_propre($pid, $plate=NULL) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgi_propre.*', 'logiref_cbs_instructions_dgi_propre.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgi_propre');
                $st = " Reference_14 ='" . $pid . "' AND Status_2 <> 0 ";
                
                #if(isset($id) && $id != "") $st .= " AND Paiementid_4=" .$id. "";
                if(isset($plate) && $plate != "") $st .= " AND Plaque_25=" .$plate. "";

                
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgi_propre.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_instructions_dgi_tresor($pid, $plate=NULL) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgi.*', 'logiref_cbs_instructions_dgi.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgi');
                $st = " Reference_14 ='" . $pid . "' AND Status_2 <> 0 ";
                
                #if(isset($id) && $id != "") $st .= " AND Paiementid_4=" .$id. "";
                if(isset($plate) && $plate != "") $st .= " AND Plaque_25=" .$plate. "";
                
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgi.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_prepayment_instructions($bl) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_prepayments_instructions.*', 'logiref_cbs_prepayments_instructions.Id_0 ASC');
                $this->db->from('logiref_cbs_prepayments_instructions');
                $st = " Paiementid_4 ='" . $bl . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_prepayments_instructions.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        public function get_prepayment_gu_instructions($lot) 
        {
                $this->set_table('logiref_cbs_prepayments_gu_instructions g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Paiementid_4' => $lot), TRUE);
        }
        
        public function get_instructions_dgi($ref) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgi.*', 'logiref_cbs_instructions_dgi.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgi');
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgi.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_instructions_plate_batchs($ref=NULL) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_integration_plaque_batchs.*', 'logiref_integration_plaque_batchs.Id_0 ASC');
                $this->db->from('logiref_integration_plaque_batchs');
                if (isset($ref)) $st= " Lot_14='" . $ref . "' AND ";
                $st = " Status_2='1' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_integration_plaque_batchs.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_instructions_dgrad($ref) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgrad.*', 'logiref_cbs_instructions_dgrad.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgrad');
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgrad.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        public function get_instructions_dgrk($ref) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgrk.*', 'logiref_cbs_instructions_dgrk.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgrk');
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgrk.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        public function get_use_case($data)
        {
                ##################### Cas 2 ############################################
                //Ordre de paiement: devise compte client === devise recette en CDF === devise commission
                if($data['Devise_34']==$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }

                ##################### Cas 3 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise compte client === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }
                
                ##################### Cas 4 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise recette === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_12']==$data['Devise_24'])
                {
                        return "case_2";
                }
                elseif($data['Devise_34']==$data['Devise_12'] && $data['Devise_12']!=$data['Devise_24'])
                {
                       return "case_2";
                }
                else 
                {
                     return "case_0";
                }
        }
        
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Instruction de comptabilisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_case_1($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'];
                }
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'C', 
                                                'Compte_9'=>$compte_dst, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12']
                                            );
                        $instructions[] = $instruction;
                }
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_cfb, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_tva, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        ##################### Cas 2 ############################################
        //Ordre de paiement: compte client et recette a payer en CDF/ou en USD
        public function get_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL, $taxe_cpi=NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
               
                
                
                if($data["Beneficaire_15"] != 'DGDA')
                {
                        $infos = json_decode($data["Notereference_30"], true);
                }
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                $periode = str_replace("/", "", $periode);
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                        }
                        elseif($data['Typerecette_17']=='AMRA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                        }
                }
                else
                {
                        $date_emission = strftime('%d/%m/%Y',strtotime($data['Notedate_27']));
                        $date_emission = str_replace("/", "", $date_emission);
                        
                        
                        if($regie=="DGRAD")
                        {
                                if($taxe_cpi=='27022470' || $taxe_cpi == '27022450')
                                {
                                        $compte_dst = isset($comptes[$regie]['CPI'][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie]['CPI'][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                        #$libelle = $data['Beneficaire_15'].'_'.$data['Service_16'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                                        $libelle = $date_emission.'-'.$data['Noteid_26'].'-'.$data['Artbudgetaire_18'].'-'.$data['Designation_14'];
                                }
                                else
                                {
                                        $libelle = $date_emission.'-'.$data['Noteid_26'].'-'.$data['Artbudgetaire_18'].'-'.$data['Designation_14'];

                                }
                        }
                        else
                        {
                               $libelle = $date_emission.'-'.$data['Noteid_26'].'-'.$data['Designation_14']; 
                        }
                }
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode);
                        $instructions[] = $instruction;
                }
                else
                {
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                $instruction = array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$data['Compte_33'], 
                                                        'Libelle_12'=>$libelle, 
                                                        'Montant_10'=>$data['Montant_11'], 
                                                        'Devise_11'=>$data['Devise_12'],
                                                        'Devise_25'=>$data['Devise_34'],
                                                        'Compte_13'=>$compte_dst
                                                    );
                                $instructions[] = $instruction;
                        }
                        else
                        {
                                $instruction = array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$data['Compte_33'], 
                                                        'Libelle_12'=>$libelle, 
                                                        'Montant_10'=>$data['Montant_11'], 
                                                        'Devise_11'=>$data['Devise_12'],
                                                        'Devise_24'=>$data['Devise_34'],
                                                        'Compte_13'=>$compte_dst
                                                    );
                                $instructions[] = $instruction;
                        }
                }
                
                # Montant frais bancaire
                if($data['Devise_12'] != $data['Devise_24'] && $data['Devise_24'] =='USD')
                {
                        $montant_frais = $data['Commission_23'] / $data['Taux_41'];
                }
                elseif($data['Devise_12'] == $data['Devise_24'] && $data['Devise_24'] =='USD')
                {
                        $montant_frais = $data['Commission_23'] / $data['Taux_41'];
                }
                else 
                {
                        $montant_frais = $data['Commission_23'];
                }
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                
                if(isset($data['Typerecette_17']))
                {
                        $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                }
                else
                {
                        $libelle = 'Frais bancaire '.$periode.' '.$data['Designation_14'];
                }
                
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_frais, 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Devise_25'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Commission_23'], 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Devise_24'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                
                
                # Montant tva
                
		if($data['Devise_12'] != $data['Devise_24'] && $data['Devise_12'] =='USD')
                {
                        $montant = $data['Commission_23']*0.16;
                        
                        $montant_tva = $montant;
                        
                }
                else 
                {
                        $montant = $data['Commission_23']*0.16;
                        $montant_tva  = $montant;
                }
                
                if($data['Beneficaire_15'] != 'DGDA')
                {
                        
                        if(!isset($infos["tva"]))
                        {
                                $montant_tva = 0;
                        }
                }
                else
                {
                        if(isset($data['tva']) && $data['tva'] == "")
                        {
                                $montant_tva  = 0;
                        }
                }
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                
                if(isset($data['Typerecette_17']))
                {
                        $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                }
                else
                {
                        $libelle = 'TVA '.$periode.' '.$data['Designation_14'];
                }
                
                
                        
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_tva, 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Devise_25'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_tva
                                            );
                        $instructions[] = $instruction;
                }
                else 
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_tva, 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Devise_24'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_tva
                                            );
                        $instructions[] = $instruction;
                }
                
                
                #return $instructions;
                # Montant frais bcc
                
				
				if($data['Devise_12'] == 'CDF' && $taxe_cpi!='27022470' && $taxe_cpi != '27022450')
                {
                        $montant = $data['Montant_11']*0.0005;
                }
                else 
                {
                        $montant = 0;
                }
                
                if(isset($infos["fraisbcc"]) && $infos["fraisbcc"] == 0 )
                {
                        $montant = 0;
                }
                
                # Operation 4: crediter le compte frais bcc
                $compte_cfb = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                if($data['Beneficaire_15'] != 'DGDA' && $data['Beneficaire_15'] != 'DGRK')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant, 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Devise_24'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                
                return $instructions;
        }

        
        public function get_prepayment_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                $compte_commision = (isset($data['Comptec']) && $data['Comptec'] > 0)? $data['Comptec'] : $data['Compte_33'];
                $devise_compte = (isset($data['Devisec']) && $data['Devisec'] !="")? $data['Devisec'] : $data['Devise_34'];
                $date_emission = strftime('%d/%m/%Y',strtotime($data['Notedate_27']));
                $date_emission = str_replace("/", "", $date_emission);

                $libelle = $date_emission.'-'.$data['Noteid_26'].'-'.$data['Designation_14'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Devise_26'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_commision, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Devise_26'=>$devise_compte,
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_commision, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Devise_26'=>$devise_compte,
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        

        
  

        ##################### Cas 3 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_3($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_cdt = 'CPU' : $compte_cdt = 'CCV';
                $compte_dst = isset($comptes[$bank_code][$compte_cdt][$data['Devise_34']]) ? $comptes[$bank_code][$compte_cdt][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = $data['Montant_11'] / $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                        }
                        else 
                        {
                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                        }
                }
                else
                {
                        $libelle = $data['Notedate_27'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'];
                }
                
                
				$instruction = array(
										'Operation_8'=>'V', 
										'Compte_9'=>$data['Compte_33'], 
										'Libelle_12'=>$libelle, 
										'Montant_10'=>$montant_cdt, 
										'Devise_11'=>'CDF',
										'Compte_13'=>$compte_dst
									);
				$instructions[] = $instruction;
                
                
                
                # Operation 2: debiter soit le compte position en USD ou soit le compte contr-valeur en CDF
                # pour crediter soit le compte passage en USD ou soit le compte guichet unique
                
                //Compter a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compter a crediter
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;;
                }
				
				# Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
						if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_dbt, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
				
				
                # Operation 3: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 4: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                
                $instructions[] = $instruction;
                
                
                
                
                
                return $instructions;
        }
        
        ##################### Cas 4 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_4($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
				
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_cdt = 'CPU' : $compte_cdt = 'CCV';
                $compte_dst = isset($comptes[$bank_code][$compte_cdt][$data['Devise_34']]) ? $comptes[$bank_code][$compte_cdt][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = ($data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23'] * 0.16))/ $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
						if($regie=="DGDA")
						{
								$libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'];
						}
						else
						{
								$libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
						}
                }
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_cdt, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 2: debiter soit le compte position en USD ou soit le compte contr-valeur en CDF
                # pour crediter soit le compte passage en USD ou soit le compte guichet unique
                
                //Compte a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compte a crediter
                ($regie=="DGDA") ? $compte_cdt= 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        if($regie=="DGDA")
						{
								$libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'];
						}
						else
						{
								$libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
						}
                }
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_dbt, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
                
                # Operation 3: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                
                if($regie=="DGDA")
				{
						$libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
				}
				else
				{
						$libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
				}
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;

                # Operation 5: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
				
                if($regie=="DGDA")
				{
						$libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
				}
				else
				{
						$libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
				}
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_tva
                                    );
				
                $instructions[] = $instruction;
				
				return $instructions;
        }
        
        
        ##################### Cas 5 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_5($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
				
				
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
                }
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
                
                
                //Compte position a crediter pour la position de change des frais bancaires et la TVA.
                $compte_cpu = 'CPU';
                $compte_dst = isset($comptes[$bank_code][$compte_cpu]['USD']) ? $comptes[$bank_code][$compte_cpu]['USD'] : '00000000000000000000000'; 
                
                $compte_ccv = 'CCV';
                $compte_src = isset($comptes[$bank_code][$compte_ccv]['CDF']) ? $comptes[$bank_code][$compte_ccv]['CDF'] : '00000000000000000000000'; 
                
                //Montant de la commission a crediter, l'equivalence en dollars.
                $montant_commission = $data['Commission_23'] / $data['Taux_41'];
                
                # Operation 2: crediter le compte CPU de la banque pour la position de change des frais bancaires
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_commission, 
                                        'Devise_11'=>'USD',
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 3 : Debiter le compte contre-valeur pour crediter le compte frais bancaires 
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_src, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                //Montant de la tva a crediter, l'equivalence en dollars.
                $montant_tva = $data['Commission_23']*0.16;
                
                $montant_tva = $montant_tva / $data['Taux_41'];
                
                # Operation 4: crediter le compte CPU de la banque pour la position de change de la TVA
                
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_tva, 
                                        'Devise_11'=>'USD',
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 5: Debiter le compte contre-valeur pour crediter le compte TVA
                
                $compte_tva = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_src, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Cles de repartition
         * *************************************************************************************************************************SCETION 2
        */
        
        //DGI Cotisation - IPR 
        public function get_instructions_gu_dgi($data, $comptes,$regie, $service_types = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                $infos = json_decode($data['Notereference_30'], true);
                
                $compte_ONEM = isset($comptes['ONEM']['CPI'][$data['Devise_12']]) ? $comptes['ONEM']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_CNSS = isset($comptes['CNSS']['CPI'][$data['Devise_12']]) ? $comptes['CNSS']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_INPP = isset($comptes['INPP']['CPI'][$data['Devise_12']]) ? $comptes['INPP']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                
				
                $libelle = 'ONEM '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasONEM'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_ONEM
                                    );
                $instructions[] = $instruction;
                
                
                
                $libelle = 'INPP '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasINPP'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_INPP 
                                    );
                $instructions[] = $instruction;

                $libelle = 'CNSS '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasINSS'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_CNSS
                                    );
                $instructions[] = $instruction;

                return $instructions;
        }
        
		//DGI Vente des plaques - REIMATTRIC
        public function get_instructions_vente_gu_dgi($data, $comptes,$regie, $service_types = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                $infos = json_decode($data['Notereference_30'], true);
                
                $compte_DGI = isset($comptes['DGI']['CPI'][$data['Devise_12']]) ? $comptes['DGI']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_SYNTELL = isset($comptes['SYNTELL']['CPI'][$data['Devise_12']]) ? $comptes['SYNTELL']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_UTSCH = isset($comptes['UTSCH']['CPI'][$data['Devise_12']]) ? $comptes['UTSCH']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_RTNC = isset($comptes['RTNC']['CPI'][$data['Devise_12']]) ? $comptes['RTNC']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_SONAS = isset($comptes['SONAS']['CPI'][$data['Devise_12']]) ? $comptes['SONAS']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_HOLOGRAMME = isset($comptes['HOLOGRAMME']['CPI'][$data['Devise_12']]) ? $comptes['HOLOGRAMME']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
				
                
                $libelle = 'UTSCH '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantUTSCH'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_UTSCH
                                    );
                $instructions[] = $instruction;
				
				$libelle = 'SYNTELL '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantSYNTELL'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_SYNTELL
                                    );
                $instructions[] = $instruction;
                
				$libelle = 'DGI '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantDGI'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_DGI
                                    );
                $instructions[] = $instruction;
                
                $libelle = 'SONAS '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantSONAS'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_SONAS
                                    );
                $instructions[] = $instruction;
                
                $libelle = 'HOLOGRAME '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantHOLOGRAMME'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_HOLOGRAMME
                                    );
                $instructions[] = $instruction;
                
                 
                $libelle = 'RTNC '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantRTNC'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_RTNC
                                    );
                $instructions[] = $instruction;
                

                return $instructions;
                
               
        }
        
        public function get_instructions_batch_plaques_dgi($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                $compte_cdt = isset($comptes['DGI']['CPT']['CDF']) ? $comptes['DGI']['CPT']['CDF'] : '00000000000000000000000'; 
				
                $libelle = $data['Partenaires'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cdt
                                    );
                $instructions[] = $instruction;
                

                return $instructions;
        }
        //Guichet Unique en douane
        public function get_instructions_gu_dgda($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]['']))
                        {
                                $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][''];
                        }
                        else
                        {
                                $compte_dst = '00000000000000000000000';
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_cgu,
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst,
                                        'Paiementkey_26'=> $data['Paiementkey_52']
                                    );
                
                return $instruction;
        }
        public function get_instructions_gu_dgda_prepayments($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]['']))
                        {
                                $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][''];
                        }
                        else
                        {
                                $compte_dst = '00000000000000000000000';
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_cgu,
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                    );
                
                return $instruction;
        }
        
        public function get_instructions_frais_bcc_dgda($data, $comptes, $frais_bcc_exempt = NULL)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        
                        if($frais_bcc_exempt =="1")
                        {
                                $montant = $data['frais_bcc'];
                        }
                        else
                        {
                                $montant = 0;

                        }
                        
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34'] || $data['Devise_12'] == 'USD' && $data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant = 0;
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant = $data['Montant_11']*0.0005;
                        
                        if($frais_bcc_exempt =="1")
                        {
                                $montant = $data['frais_bcc'];
                        }
                        else
                        {
                               $montant = 0;

                        }
                }
				
                
                # Operation 1: crediter le compte frais bcc
                $compte_cfb = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant, 
                                                'Devise_11'=>'CDF',
                                                'Compte_13'=>$compte_cfb,
                                                'Paiementkey_26'=>$data['paiement_key']
                                            );
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant, 
                                                'Devise_11'=>'CDF',
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                return $instructions;
        }
        
        public function get_instructions_frais_bcc_plaques($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                # Operation 1: crediter le compte frais bcc
                $compte_fbc = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Service_16'].' '.$data['Typerecette_17'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['frais_bcc'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_fbc
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_first_instructions_plates($data, $comptes)
        {
                #$instructions = array();
                $bank_code = 'Ebcdc';
                
                # Operation 1: crediter le compte frais bcc
                $compte_fbc = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Designation_14'].' '.$data['Nif_13'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['frais_bcc'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_fbc,
                                        'Paiementid_4'=>$data['Paiementid_4']

                                    );
                $instructions[] = $instruction;
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes['Ebcdc']['CFB']['CDF']) ? $comptes['Ebcdc']['CFB']['CDF'] : '000000000000000000000000'; 
                
                $libelle = 'Frais bancaire '.$data['Designation_14'].' '.$data['Nif_13'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_cfb,
                                        'Paiementid_4'=>$data['Paiementid_4']
                                    );
                $instructions[] = $instruction;
                
                
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes['Ebcdc']['TVA']['CDF']) ? $comptes['Ebcdc']['TVA']['CDF'] : '000000000000000000000000'; 
                
                $libelle = 'TVA '.$data['Designation_14'].' '.$data['Nif_13'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23']*0.16, 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_tva,
                                        'Paiementid_4'=>$data['Paiementid_4']
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_first_instructions_plaques($data, $comptes)
        {
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes['Ebcdc']['CFB']['CDF']) ? $comptes['Ebcdc']['CFB']['CDF'] : '000000000000000000000000'; 
                
                $libelle = 'Frais bancaire '.$data['Service_16'].' '.$data['Typerecette_17'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes['Ebcdc']['TVA']['CDF']) ? $comptes['Ebcdc']['TVA']['CDF'] : '000000000000000000000000'; 
                
                $libelle = 'TVA '.$data['Service_16'].' '.$data['Typerecette_17'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23']*0.16, 
                                        'Devise_11'=>'CDF',
                                        'Devise_24'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_instructions_frais_bcc_prepayments($data, $comptes, $compte_debit, $devise_compte)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                
                if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                {
                        $data['Taux_41'] = $taux = $data['Taux_41'];
                }
                else 
                {
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $data['Taux_41'] = $taux['Dollar_4'];
                }
                
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $devise_compte)
                {
                        if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                        {
                                $montant_credit = $data['frais_bcc'];
                                $montant_debit = $data['frais_bcc']/$data['Taux_41'];
                        }
                        else
                        {
                                $montant_credit = $montant_debit = 0;
                        }
                        
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34'] || $data['Devise_12'] == 'USD' && $data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_credit = $montant_debit = 0;
                }
                elseif($data['Devise_12'] == $devise_compte) 
                {
                        if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                        {
                                $montant_credit = $montant_debit = $data['frais_bcc'];
                        }
                        else
                        {
                                $montant_credit = $montant_debit = 0;
                        }
                }
				
                
                # Operation 4: crediter le compte frais bcc
                $compte_cfb = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_debit, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$devise_compte,
                                        'Montant_27'=>$montant_credit, 
                                        'Devise_26'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        public function get_instructions_gu_prepayment($data, $prepayments)
        {
                $instructions = array();
                $bank_code = 'Ebcdc';
                
                if(isset($data['fees_account']) && $data['fees_account'] != "")
                {
                        $fees_account = $data['fees_account'];
                }
                else
                {
                        $fees_account = '00000000000000000';
                        $data['fees_amount'] = 0;
                }
                
                # Operation 1 : Crediter le compte guichet unique
                $libelle = $data['designation'].' '.$data['nif'].' '.$data['compte_sydonia'].' '.$data['office'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['prepaid_account'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['amount'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_26'=>'CDF',        
                                        'Compte_13'=>$data['account_cgu'],
                                        'Paiementid_4'=>$data['lot']
                                    );
                $instructions[] = $instruction;
                
                # Operation 2 : Crediter le compte frais bcc
                $libelle = 'Frais bcc '.$data['nif'].' '.$data['compte_sydonia'].' '.$data['office'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['client_account'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['fees_amount'], 
                                        'Devise_11'=>'CDF',
                                        'Devise_26'=>'CDF',        
                                        'Compte_13'=>$fees_account,
                                        'Paiementid_4'=>$data['lot']
                                    );
                $instructions[] = $instruction;
               
                return $instructions;
        }
        //Operation de virement du compte CPT Transitoire vers le compte TVA, TVF, TVN, TVO de la dounane
        public function get_instructions_dgi_tva($data, $comptes, $services = NULL, $periode = NULL, $compte_debit = NULL)
        {
                
                $compte_dst = isset($comptes[$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$data['Typerecette_17']][$data['Devise_12']] : '00000000000000000000000'; 
                
                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                
                if($compte_debit != NULL)
                {
                        $instruction = array(
                                'Operation_8'=>'V', 
                                'Compte_9'=>$compte_debit, 
                                'Libelle_12'=>$libelle, 
                                'Montant_10'=>$data['Montant_11'], 
                                'Devise_11'=>$data['Devise_12'],
                                'Devise_24'=>$data['Devise_34'],
                                'Compte_13'=>$compte_dst
                        );
                }
                else
                {
                        $instruction = array(
                                'Operation_8'=>'V', 
                                'Compte_9'=>$data['Compte_33'], 
                                'Libelle_12'=>$libelle, 
                                'Montant_10'=>$data['Montant_11'], 
                                'Devise_11'=>$data['Devise_12'],
                                'Devise_24'=>$data['Devise_34'],
                                'Compte_13'=>$compte_dst
                        );
                }
                
                return $instruction;
        }
        
        public function get_last_gu_instruction()
        {
                $this->_table_name = '';
                $this->db->select('Id_0', 'logiref_cbs_prepayments_gu_instructions.Id_0 DESC');
                $this->db->from('logiref_cbs_prepayments_gu_instructions');
                $this->db->order_by('Id_0 DESC');
                $this->db->limit(1);
                return $this->db->get()->result();
        }
        
        public function get_last_dgda_instruction()
        {
                $this->_table_name = '';
                $this->db->select('Id_0', 'logiref_cbs_instructions_dgda.Id_0 DESC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $this->db->order_by('Id_0 DESC');
                $this->db->limit(1);
                return $this->db->get()->result();
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function update_instructions($data, $id) 
        {
                $this->db->where("logiref_cbs_instructions.Reference_14 ='".$ids."')");
                return $this->db->update('logiref_cbs_instructions', $data);
        }
        
        public function save_first_instructions_dgda($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $last_instruction = $this->get_last_dgda_instruction();
                                
                                if(!empty($last_instruction)) $last_id = (int)$last_instruction[0]->Id_0 + 1; else $last_id = 1;
                                
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                $data['Reference_14']= $logirefid;
                                $data['Priority_24']=$priority;
                                $data['Paiementkey_26']= $logirefid."".$last_id;
                                
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                $data['Reference_14']= $logirefid;
                                $data['Priority_24']=$priority;
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgi($pid, $paiement, $instructions, $logirefid, $plate=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$_SESSION['Logiref_agence'];
                                $data['Guichet_7']=$_SESSION['Logiref_guichet'];
                                $data['Reference_14']=isset($logirefid)? $logirefid: ""; //TBD
                                $data['Mode_15']=isset($paiement['Mode_19'])? $paiement['Mode_19'] : "";
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                
                                if (isset($plate)) $data['Plaque_25']=$plate;
                                
                                $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        public function save_gu_instructions_dgi($paiement, $instructions, $logirefid)
        {
            
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $key => $values)
                        {
                            foreach ($values as $instruction)
                            {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                #$data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$_SESSION['Logiref_agence'];
                                $data['Guichet_7']=$_SESSION['Logiref_guichet'];
                                $data['Reference_14']=isset($logirefid)? $logirefid: ""; //TBD
                                $data['Mode_15']=isset($paiement['Mode_19'])? $paiement['Mode_19'] : "";
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                
                                $this->set_table('logiref_cbs_gu_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                            }
                        }
                }
                return TRUE;
        }
        public function save_instructions_plaque_batchs($pid, $paiement)
        {
                //Save instructions
                $data = array();
                
                //Variable d'integration
                $data['Id_0'] = '';
                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                $data['Status_2']=1;
                $data['Account_3']= $this->session->userdata('account_id');
                $data['Office_7']= $paiement['Service_16'];
                $data['Typerecette_8']= $paiement['Typerecette_17'];
                $data['Bank_10']= $this->session->userdata('account_id'); //TBD 

                $data['Amount_11'] = str_replace(' ','', $paiement['total_amount']);
                $data['Amount_11'] = str_replace(',','.', $data['Amount_11']); 
                
                $data['Devise_12']= "CDF";
                $data['Lot_14']= $pid;
                $data['Account_15']= $paiement['Compte_33'];
                $data['Devise_16']= $paiement['Devise_16'];
                $data['Accountholder_17']= $paiement['account_name'];
                $data['Mode_18']=   $paiement['Mode_19'];
                        
                $data['Commission_19'] = $paiement['Commission_23'];
                $data['Devise_20']= "CDF";
                $data['Total_21'] = $paiement['total_topaid'];
                $data['Agence_22']=$_SESSION['Logiref_agence'];
                $data['Taux_23'] = $paiement['taux'];
                
                $data['Refop_24']= $paiement['Refop_24'];

                $this->set_table('logiref_integration_plaque_batchs', 'Id_0', 'Id_0 DESC');
                $this->save($data, NULL);

                return TRUE;
        }
        public function save_instructions_dgi_propre($pid, $paiement, $instructions, $logirefid, $plate=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$_SESSION['Logiref_agence'];
                                $data['Guichet_7']=$_SESSION['Logiref_guichet'];
                                $data['Reference_14']=isset($logirefid)? $logirefid: ""; //TBD
                                $data['Mode_15']=isset($paiement['Mode_19'])? $paiement['Mode_19'] : "";
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                isset($plate) ? $data['Plaque_25']=$plate : "";
                                
                                $this->set_table('logiref_cbs_instructions_dgi_propre', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgrad($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                
                                $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgrk($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata('user_id');
                                
                                $this->set_table('logiref_cbs_instructions_dgrk', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_prepayments_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']= $paiement['Agence_20'];
                                $data['Guichet_7']= $paiement['Guichet_21'];
                                $data['Mode_15']= $paiement['Mode_19'];
                                $data['Makerid_16']= $this->session->userdata('user_id');
                                $data['Priority_24']= $priority;
                                $data['Reference_14']= $logirefid; 
                                
                                $this->set_table('logiref_cbs_prepayments_instructions', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_prepayments_instructions_frais_bcc($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata('account_id'); //TBD 
                                $data['Agence_6']= $paiement['Agence_20'];
                                $data['Guichet_7']= $paiement['Guichet_21'];
                                $data['Mode_15']= $paiement['Mode_19'];
                                $data['Makerid_16']= $this->session->userdata('user_id');
                                $data['Priority_24']= $priority;
                                $data['Reference_14']= $logirefid; 
                                
                                $this->set_table('logiref_cbs_prepayments_instructions', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_prepayments_gu_instructions($instructions, $prepayment)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data=array();
                                $data = isset($instruction) ? $instruction : "";

                                $last_instruction = $this->get_last_gu_instruction();
                                
                                if(!empty($last_instruction)) $id = (int)$last_instruction[0]->Id_0 + 1; else $id = 1;

                                $data['Reference_14']= $prepayment['lot']."".$id;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata('account_id');
                                $data['Agence_6']= $_SESSION['Logiref_agence'];
                                $data['Guichet_7']= $_SESSION['Logiref_guichet'];
                                $data['Mode_15'] = 'OP';
                                $data['Makerid_16'] = $prepayment['makerid'];
                                $data['Checkerid_17'] = $this->session->userdata('user_id');
                                $data['Validation_18'] = gmdate('Y-m-d H:i:s');
                                $data['Integrateur_19'] = $this->session->userdata('user_id');
                                $data['Integration_20'] = gmdate('Y-m-d H:i:s');


                                $this->set_table('logiref_cbs_prepayments_gu_instructions', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                        
                }
                return TRUE;
        }
        
        public function delete_instructions_dgda($id)
	{
		$this->db->where('Paiementid_4', $id);
		return $this->db->delete('logiref_cbs_instructions_dgda');
	}
        public function delete_instructions_dgi($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_instructions_dgi');
	}
        
        public function delete_instructions_dgrad($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_instructions_dgrad');
	}
        
        public function delete_instructions_dgrk($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_instructions_dgrk');
	}
        
        public function update_prepayments_instructions_cbs($ids, $data)
        {
                $this->db->where("logiref_cbs_prepayments_instructions.Id_0 IN (".$ids.")");
                return $this->db->update('logiref_cbs_prepayments_instructions', $data);
        }
        
        public function update_instructions_dgda_by_id($id, $data)
        {
                $this->db->where("logiref_cbs_instructions_dgda.Paiementid_4 = ".$id." AND logiref_cbs_instructions_dgda.Priority_24 = 0 ");
                return $this->db->update('logiref_cbs_instructions_dgda', $data);
        }
        
        public function update_batch_instructions($ids, $data)
        {
                $this->db->where("logiref_cbs_instructions_dgda.Paiementid_4 IN (".$ids.")");
                return $this->db->update('logiref_cbs_instructions_dgda', $data);
        }
        
        public function update_batch_plates($data, $ref) 
        {
                $this->db->where("logiref_integration_plaque_batchs.Lot_14 ='".$ref."'");
                return $this->db->update('logiref_integration_plaque_batchs',$data);
        }
        
        public function delete_instructions_tresor_plates($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_instructions_dgi');
	}
        
        public function delete_instructions_propre_plates($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_instructions_dgi_propre');
	}
        
        public function delete_gu_instructions_plates($id)
	{
		$this->db->where('Reference_14', $id);
		return $this->db->delete('logiref_cbs_gu_instructions_dgi');
	}
        
        public function delete_instructions_batch_plates($id)
	{
		$this->db->where('Lot_14', $id);
		return $this->db->delete('logiref_integration_plaque_batchs');
	}
        
        public function delete_instruction_dgda($data, $id)
	{
                $this->db->where("logiref_cbs_instructions_dgda.Paiementid_4 ='".$id."'");
                return $this->db->update('logiref_cbs_instructions_dgda', $data);
	}
	   public function delete_batch_instruction_dgda($data, $ref)
	{
                $this->db->where("logiref_cbs_instructions_dgda.Paiementid_4 ='".$ref."'");
                return $this->db->update('logiref_cbs_instructions_dgda', $data);
	}
       
        
        /*********************************************************************************/
        
        public function deletes_instructions_batch_plates($data, $ref) 
        {
                $this->db->where("logiref_integration_plaque_batchs.Lot_14 ='".$ref."'");
                return $this->db->update('logiref_integration_plaque_batchs',$data);
        }
        
        public function deletes_gu_instructions_plates($data, $ref)
	{
                $this->db->where("logiref_cbs_gu_instructions_dgi.Reference_14 ='".$ref."'");
                return $this->db->update('logiref_cbs_gu_instructions_dgi',$data);
	}
        
        public function deletes_instructions_propre_plates($data, $ref)
	{
                $this->db->where("logiref_cbs_instructions_dgi_propre.Reference_14 ='".$ref."'");
                return $this->db->update('logiref_cbs_instructions_dgi_propre',$data);
	}
        
        public function deletes_instructions_tresor_plates($data, $ref)
	{
                $this->db->where("logiref_cbs_instructions_dgi.Reference_14 ='".$ref."'");
                return $this->db->update('logiref_cbs_instructions_dgi',$data);
	}

}