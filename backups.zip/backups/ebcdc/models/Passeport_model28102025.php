<?php
class Passeport_model extends MY_Logiref_Ebcdc {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        private $role=null;
	
	
	public function __construct()
	{
		parent::__construct();
                $this->role=$_SESSION['Logiref_role'];
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata('account_id');

                if($item=="guichets")
                {
                        if($_SESSION['Logiref_groupe']=='banks')
                        {
                                $agence = $arg;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                                if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_guichets');
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        else
                        {

                                $st = "Status_2='1'";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_guichets');
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="agences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_agences');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                elseif($item=="codeagences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Code_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="agence_principale")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Code_10']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                elseif($item=="main_branch")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata('account_id') . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_guichets');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Agence_principale_14'];
                        }
                        return $ddmenu;
                }

        }

        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata('account_id');
		$this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='".$account_id."'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
	}
        
        public function get_paiement_info($id=NULL)
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata('account_id');
                        $obj->Logirefid_4 = rand(1, 999).date('H').date('i').date('s').date('j').date('m').date('y').rand(1, 999);
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];
                        
                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';
                        $obj->Edgrk_50 = '0'; 
                        $obj->Plaques_51 = '';                         

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_paiement_tresor_by_logiref_id($logiref_id=NULL)
        {
                if ($logiref_id != NULL)
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Logirefid_4' => $logiref_id), TRUE);
                }
        }

        public function get_paiement_tresor_by_reference($reference=NULL)
        {
                if($reference != "")
                {
						$this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');

                        return $this->get_by(array('Noteid_26' => $reference,'Status_2 !='=>0), TRUE);
                }
        }
        public function delete_paiement_tresor($id)
        {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                return $this->save(array('Status_2' => '0'), $id);
        }

        public function get_montant_total($data=NULL)
        {
                $total_montant = 0;
                
                if(!empty($data))
                {
                        $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        $data['Montant_11'] = intval($data['Montant_11']);
                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','',$data['Commission_23']);
                        $data['Commission_23'] = intval($data['Commission_23']);
                        $total_montant = $data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23']*0.16);
                }
                return  $total_montant;
        }
        
        public function get_data_validation_passport($id=null)
        {
                
                $return = array();
                $formdata = $_POST;
                
                $paiement_info = $this->get_paiement_info($id);

                if (empty($formdata) || !is_array($formdata)) 
                {
                        $errors[]='Les données sont manquantes ou invalides.';
                }
                // Validate user session data
//                if (is_null($_SESSION['userdata']['user_id'])) 
//                {
//                        $errors[] = 'Session invalide ou expirée. Veuillez vous reconnecter.';
//                }
                
                if (isset($this->role) && !in_array($this->role,[2,3]) ) 
                {
                        $errors[] = 'Vous n\'avez pas les droits nécessaires pour effectuer cette action.';
                }
                
                // Check if required fields are present
                if(!isset($formdata['Id_0']) || empty($formdata['Id_0']))
                {
                        $errors[] = 'L\'ID du paiement de passeport est manquant.';
                }

                if(!isset($formdata['Logirefid_4']) || empty($formdata['Logirefid_4']))
                {
                        $errors[] = 'La référence Logiref est manquante.';
                }

                $data_multi = [
                        'firstTrans' => [
                                'Id_0' => isset($formdata['Id_0']) ? $formdata['Id_0'] : '',
                                'Logirefid_4' => isset($formdata['Logirefid_4']) ? $formdata['Logirefid_4'] : '',
                                'Trans' => 'firstTrans',
                                'Priority_27' => 0,
                                'Account_3' =>  isset($formdata['Account_3']) ? $formdata['Account_3'] : '',
                                'Beneficaire_15' =>  isset($formdata['Beneficaire_15']) ? $formdata['Beneficaire_15'] : '',
                                'Statut_2'=> $paiement_info->Status_2
                        ],
                        'secondTrans' => [
                                'Id_0' => isset($formdata['Id_0']) ? $formdata['Id_0'] : '',
                                'Logirefid_4' => isset($formdata['Logirefid_4']) ? $formdata['Logirefid_4'] : '',
                                'Trans' => 'secondTrans',
                                'Priority_27' => 1,
                                'Account_3' => isset($formdata['Account_3']) ? $formdata['Account_3'] : '',
                                'Beneficaire_15' => isset($formdata['Beneficaire_15']) ? $formdata['Beneficaire_15'] : '',
                                'Statut_2'=> $paiement_info->Status_2
                                ]
                        ];

                if (!empty($errors)) 
                {
                        $return=['code' => 404, 'message' => implode(', ', $errors), 'data' => []];
                } 
                else 
                {
                        $return= ['code' => 200, 'message' => 'valid', 'data' => $data_multi];
                }

                return $return;
        }

        public function get_data_confirmation_passport()
        {
                $guichets = $this->get_dropdown("guichets");
                $code_agences = $this->get_dropdown("codeagences");
           

                $apidata = array();

                $apidata['codeAgence']   = isset($code_agences[$_SESSION['Logiref_guichet']]) ? $code_agences[$_SESSION['Logiref_guichet']] : "";
                $apidata['agence']       = isset($guichets[$_SESSION['Logiref_guichet']]) ? $guichets[$_SESSION['Logiref_guichet']] : "";
                $apidata['Noteid_26']    = $_POST['Noteid_26'] ?? "";
                $apidata['Reference_32'] = $_POST['Reference_32'] ?? "";
                $apidata['Montant_11']   = $this->formatage_amount($_POST['Montant_11'] ?? "0");
                $apidata['Devise_12']    = $_POST['Devise_12'] ?? "";
                $apidata['Taux_41']      = $_POST['Taux_41'] ?? "";

                $required = ['codeAgence', 'agence', 'Noteid_26', 'Reference_32', 'Montant_11', 'Devise_12', 'Taux_41'];

                foreach ($required as $field) {
                        if (empty($apidata[$field])) {
                                return [
                                        'code' => 404,
                                        'message' => "Le champ {$field} est manquant ou vide"
                                ];
                        }
                }

                return [
                        'code' => 200,
                        'data' => $apidata
                ];
        }
        
        public function get_data_passeport()
        {
                $formdata = $_POST;
                $errors = [];
                $clean = [];
                $notereferences=null;

                $return = array();

                if (empty($formdata) || !is_array($formdata)) 
                {
                        $errors[] ='Les données du formulaire sont manquantes ou invalides.';
                }

                // Fields to skip validation/formatting
                $exceptions = [
                        'Id_0','Logiradid', 'Sydonia_44', 'Tresor_45'
                ];

                // Required fields (add/remove as needed)
                $required = [
                        'Beneficaire_15',
                        'Service_16', 'Noteid_26', 'Notetype_25', 'Notedate_27',
                        'Typerecette_17', 'Notemontant_28', 'Notedevise_29',
                        'Nif_13', 'Designation_14', 'Mode_19', 'Taux_41',
                        'Datevaleur_31', 'Reference_32', 'Compte_33',
                        'Montant_11', 'Commission_23', 'Devise_34', 'Devise_12', 'Devise_24', 'Email_54'
                ];

                // Required fields for Infos
                $required_infos = [
                        'standard',
                        'QuotasComite', 'QuotasPrestataire',
                        'QuotasService', 'QuotasTresor', 'Email', 'Phone'
                ];

               

                //validate user session data
//                if(is_null($_SESSION['userdata']['user_id']))
//                {
//                        $errors[] = 'Session invalide ou expirée. Veuillez vous reconnecter.';
//                }

                if (isset($_SESSION['Logiref_role']) && !in_array($_SESSION['Logiref_role'], [4, 9])) 
                {
                        $errors[] = 'Vous n\'avez pas les droits nécessaires pour effectuer cette action.';
                }

                foreach ($formdata as $key => $value) 
                {
                        if (in_array($key, $exceptions)) 
                        {
                                $clean[$key] = $value;
                                continue;
                        }

                        // Required field check
                        if (in_array($key, $required) && ($value === '' || $value === null)) 
                        {
                                $errors[] = $key . ' est requis';
                                continue;
                        }

                        // Numeric formatting
                        if (in_array($key, ['Montant_11', 'Commission_23', 'Notemontant_28', 'Taux_41'])) 
                        {
                                $clean[$key] = floatval(str_replace([',', ''], ['.', ''], $value));
                                if ($clean[$key] < 0) 
                                {
                                        $errors[] = "$key doit être un nombre positif";
                                        continue;
                                }
                                continue;
                        }

                        // Email validation
                        if ($key === 'Email_54' && !filter_var($value, FILTER_VALIDATE_EMAIL)) 
                        {
                                $errors[] = 'L\'adresse mail est invalide';
                                continue;
                        }

                        // Default: trim text
                        $clean[$key] = is_string($value) ? trim($value) : $value;
                }


                // Validate Infos sub-array if present
                if (isset($formdata['Infos']) && is_array($formdata['Infos'])) 
                {
                        foreach ($required_infos as $infoKey) 
                        {
                                if (!isset($formdata['Infos'][$infoKey]) || $formdata['Infos'][$infoKey] === '' || $formdata['Infos'][$infoKey] === null) 
                                {
                                        $errors[] = "$infoKey est requis";
                                }
                        }
                        // Email validation
                        if (isset($formdata['Infos']['Email']) && !filter_var($formdata['Infos']['Email'], FILTER_VALIDATE_EMAIL)) 
                        {
                                $errors[] = 'L\'adresse mail est invalide';
                        }
                        // Phone validation
                        if (isset($formdata['Infos']['Phone']) && !preg_match('/^\d{9,15}$/', $formdata['Infos']['Phone'])) 
                        {
                                $errors[] = 'Le numéro de téléphone est invalide';
                        }
                        $notereferences = json_encode($formdata['Infos']);
                }

                if (!empty($errors)) 
                {
                        $return= ['code'=>404,'message' => implode(', ', $errors),'data' => []];
                }
                else
                {
                        
                        $formdata['Montant_11'] = $this->formatage_amount($formdata['Montant_11']);
                        $contrevaleur = ($formdata['Devise_12'] !='CDF') ? $formdata['Montant_11'] * $formdata['Taux_41'] : $formdata['Montant_11'];
                        
                        $data=[ 'Id_0' => $formdata['Id_0'],
                                'Date_1' => gmdate('Y-m-d H:i:s'),
                                'Status_2' => 1,
                                'Account_3' => $this->session->userdata('account_id'),
                                'Logirefid_4' => $this->generate_unique_reference().$this->session->userdata('user_id'),
                                'Makerid_9' => $this->session->userdata('user_id'),
                                'Montant_11' => $formdata['Montant_11'],
                                'Devise_12' => $formdata['Devise_12'],
                                'Nif_13' => $formdata['Nif_13'],
                                'Designation_14' => $formdata['Designation_14'],
                                'Beneficaire_15' => 'DGRAD',
                                'Service_16' => $formdata['Service_16'],
                                'Typerecette_17' => $formdata['Typerecette_17'],
                                'Mode_19' => $formdata['Mode_19'],
                                'Artbudgetaire_18' => $formdata['Infos']['standard'],
                                'Agence_20' =>$_SESSION['Logiref_agence'],
                                'Guichet_21' =>$_SESSION['Logiref_guichet'],
                                'Contrevaleur_22' => $contrevaleur,
                                'Commission_23' => $formdata['Commission_23'],
                                'Devise_24' => $formdata['Devise_24'],
                                'Notetype_25' =>'5',
                                'Noteid_26' => $formdata['Noteid_26'],
                                'Notedate_27' =>$formdata['Notedate_27'],
                                'Notemontant_28' => $formdata['Notemontant_28'],
                                'Notedevise_29' => $formdata['Notedevise_29'],
                                'Notereference_30' => $notereferences,
                                'Datevaleur_31' =>  gmdate('Y-m-d'),
                                'Reference_32' => $formdata['Reference_32'],
                                'Compte_33' => $formdata['Compte_33'],
                                'Devise_34' => $formdata['Devise_34'],
                                'Taux_41' => $formdata['Taux_41'],
                                'Devise_42' => $formdata['Devise_12'],
                                'Logirad_53' => $formdata['Logirad_53'],
                                'Email_54' => $formdata['Infos']['Email'],
                                'Msisdn_55'=> $formdata['Infos']['Phone']
                                
                        ];
                        $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                }
                return $return;
                
        }
        
        
        
        public function get_formatage_data_passeport($data = NULL)
        {
                if (!is_array($data))
                {
                        return [];
                }

                $amountFields = [
                        'Montant_11', 'Contrevaleur_22', 'Commission_23', 'Notemontant_28', 'Taux_41',
                        'QuotasComite', 'QuotasPrestataire', 'QuotasService', 'QuotasTresor'
                ];

                foreach ($amountFields as $field)
                {
                        if (isset($data[$field]))
                        {
                                $data[$field] = $this->formatage_amount($data[$field]);
                        }
                }

                if (!empty($data['Notereference_30']))
                {
                        $infos = json_decode($data['Notereference_30'], true);

                        if (is_array($infos))
                        {
                                foreach ($amountFields as $field)
                                {
                                        if (isset($infos[$field]))
                                        {
                                                $infos[$field] = $this->formatage_amount($infos[$field]);
                                        }
                                }
                                $data['Notereference_30'] = json_encode($infos, JSON_UNESCAPED_UNICODE);
                        }
                }

                return $data = array('code'=>200, 'data'=> $data);
        }
        
        public function get_data_deletion_passport()
        {
                $data['Status_2'] = 0;
                $data['Suppression_40'] = gmdate('Y-m-d H:i:s');

                return [
                        'code' => 200,
                        'data' => [
                                'Status_2' => 0,
                                'Suppression_40' => gmdate('Y-m-d H:i:s'),
                        ]
                ];
        }
        public function check_existing_payments($integrations, $data) 
        {
                $result = [
                        'code'        => null,
                        'html'        => null,
                        'checked'     => false,
                        'encaissement'=> null
                ];

                $encaissement = $this->get_paiement_tresor_by_reference($data['Reference_8']);
                $result['encaissement'] = $encaissement;

                if (!empty($integrations) && !empty($encaissement)) 
                {
                        if (($encaissement->Status_2 == 1) && $encaissement->Checkerid_10 == '0' && $encaissement->Type_57 == 'mobile') 
                        {
								
                                $result['code'] = $integrations->Id_0;
                                $result['checked'] = true;
                        } 
                        elseif ($encaissement->Status_2 == '1' && $encaissement->Checkerid_10 == '0') 
                        {
                                $result['code'] = "E503";
                                $result['html'] = $this->format_warning_message("Cette note de perception a déjà été initialisée et enregistrée", $encaissement->Date_1);
                        }
                        elseif ($encaissement->Status_2 == '2' && $encaissement->Checkerid_10 != '0') 
                        {
                                $result['code'] = "E505";
                                $result['html'] = $this->format_warning_message("Cette note de perception a déjà été validée dans <strong>Finacle</strong>", $encaissement->Validation_36);
                        } 
                        elseif ($encaissement->Status_2 == '3') 
                        {
                                $result['code'] = "E506";
                                $result['html'] = $this->format_warning_message("Cette note de perception a déjà été reversée", $encaissement->Validation_36, "+1 day");
                        } 
                        elseif ($encaissement->Status_2 == '5' || $encaissement->Status_2 == '6') 
                        {
                                $result['code'] = "E507";
                                $result['html'] = $this->format_warning_message("Cette note de perception est en régulation mais déjà enregistrée ", $encaissement->Date_1);
                        }
                        elseif ($encaissement->Status_2 == '7') 
                        {
                                $result['code'] = "E508";
                                $result['html'] = $this->format_warning_message("Cette note de perception est en régulation, en attente de confirmation dans Logirad, mais déjà enregistrée ", $encaissement->Date_1);
                        }
                        else
                        {
                                $result['code'] = "E999";
                                $result['html'] = $this->format_warning_message("Un problème est survenu ou la note est introuvable — aucun traitement applicable disponible");
                        }
                } 
                elseif (isset($integrations->Id_0) && $integrations->Status_2 == 1) 
                {
                        $result['code'] = $integrations->Id_0;
                } 
                elseif (isset($integrations->Id_0) && $integrations->Status_2 == 2) 
                {
                        $result['html'] = $this->format_warning_message("Cette note de perception a déjà été payée et confirmée avec succès dans Logirad");
                        $result['code'] = "E504";
                } 
                else
                {
                        $result['code'] = "E200";
                }

                return $result;
        }

        public function format_warning_message($text, $date = null, $modif = null) 
        {
                if ($date !== null) 
                {
                        if (!is_int($date))  $date = strtotime($date);
                        if ($modif) $date = strtotime($modif, $date);

                        $date_formatted = strftime('%d/%m/%Y', $date);
                }

                return '<div class="alert alert-warning text-white">Désolé!... ' 
                        . $text 
                        . ((isset($date_formatted)) ? ', le <strong>' . $date_formatted . '</strong>' : ' !')
                        . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        }


        public function formatage_amount($amount)
        {
                return str_replace([',', ' '], ['.', ''], $amount);
        }
        
        public function generate_unique_reference()
        {
                $datetimePart = date('ymdHis'); // 6 (ymd) + 6 (His) = 12 caractères
                $randomPart = substr(bin2hex(random_bytes(4)), 0, 8); // 8 caractères aléatoires

                return $datetimePart . $randomPart; // total : 12 + 8 = 20 caractères
        }
        
        public function formatage_text($data=NULL)
        {
                return $data;
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	
        public function save_paiement_tresor($data) 
        {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                $return = $this->save($data);
                $affected_rows=$this->db->affected_rows() ;
                
                if($affected_rows > 1)
                {
                        $data="Reference : ".$data['Noteid_26']."----- > Number of lines : ".$affected_rows;
                        $this->save_log($data,"duplicate_entries");
                }
                return $return;
        }

        public function update_payment_tresor($data, $id) {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                return $this->save($data, $id);
        }

        public function update_payment_validation($id,$validation_status)
        {
                $validation_data['Status_2'] = $validation_status;
                $validation_data['Checkerid_10'] = $this->session->userdata('user_id');
                $validation_data['Validation_36'] =date('Y-m-d H:i:s');
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                return $this->save($validation_data, $id);
        }
        
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
	//Save Log
	public function save_log($data, $prefix = NULL)
	{
			$name = gmdate('Y-m-d');
			$handle = fopen(".drive/logs/passport/".$name."_".$prefix, 'a+');
			$data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
			fwrite($handle, $data."\n\n");   
			fclose($handle);	
	}
        
        
}