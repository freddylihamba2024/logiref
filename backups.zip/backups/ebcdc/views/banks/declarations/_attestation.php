<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <table style="width: 100%">
        <tr>
            <td>
                <div style="padding: 10px 10px">
                    <?php $page = $_SESSION['account_logo']; ?>
                    <?php if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $logo; ?>" width="150" height="150" />
                    <h3 style="font-family: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></h3>
                </div>
            </td>
            <td align ="right" style="">
                <div>
                    <p><?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]; ?> / <?php echo  $encaissement->Id_0;?> / <?php echo gmdate("Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    <h3 align="center" style="color:black; padding-top: 100px; font: bold caption 1.3em  sans-serif;">&nbsp;&nbsp;&nbsp;&nbsp; ATTESTATION DE PAIEMENT <span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</h3>
<hr>
<span style="padding-top: 300px;">
    <p style="text-align:justify; ">
        Nous soussign&eacute;s <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></span>RDC attestons par la pr&eacute;sente que notre client <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo $encaissement->Designation_14; ?></span> a effectu&eacute;(e) un paiement de <span style="font-weight: bold;"><?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></span> en faveur de la 
        <span style="font-weight: bold;"><?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]; ?> </span> au titre de <?php echo $recettes[$beneficiaires['Regies'][$encaissement->Beneficaire_15]][$encaissement->Typerecette_17]; ?>.
    </p>
    <p>
        <table>
            <tr>
                <td>Suivant la note : N&ordm; <b style="font-weight: bold;"><?php echo $encaissement->Noteid_26; ?></b> <span style="font-weight: bold;"><?php echo $typeDoc[$encaissement->Notetype_25]; ?></span>  du <span style="font-weight: bold;"><?php echo strftime('%d-%m-%Y',strtotime($encaissement->Notedate_27)); ?></span></td>
            </tr>
            <tr>
                <td>Mode de paiement &nbsp;: <span style="font-weight: bold;"><?php echo $modes[$encaissement->Mode_19];?></span> </td>
            </tr>
        </table>
    </p>
    <?php if($beneficiaires['Regies'][$encaissement->Beneficaire_15] == 'DGI'):?>
        <p>
            <?php $infos = json_decode($encaissement->Notereference_30, true);?>
            <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
                <table>
                    <tr><td> - CNSS &nbsp;&nbsp;:</td><td><?php echo $infos['QuotasINSS']; ?></td></tr>
                    <tr><td> - INPP &nbsp;&nbsp;:</td><td><?php echo $infos['QuotasINPP']; ?></td></tr>
                    <tr><td> - ONEM &nbsp;&nbsp;:</td><td><?php echo $infos['QuotasONEM']; ?></td></tr>
                </table>
            <?php endif;?>
        </p>
    <?php endif;?>
    
    <div style="padding-top:  100px;">
    <p align="right">
        Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d-%m-%Y',strtotime(gmdate('d-m-Y'))); ?>.
    </p>
    <hr>
    <p align="center" >
        <?php echo '<img src="'.base_url($qrcode).'" width="120" heigth="120" />'; ?>
        <br> <br>
        Code s&eacute;curit&eacute; : <?php echo  $encaissement->Logirefid_4;?> |<?php echo ' '.$this->session->userdata('account_business').' '; ?>| Logiref | RDC
    </p>
    </div>
</span>
</body>
</html>

