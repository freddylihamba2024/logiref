<?php $userid = $this->session->userdata("user_id"); $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>


<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>
 

<?php if(isset($_POST['Reference_14']) && $_POST['Reference_14'] !='') {$reference = $_POST['Reference_14'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nif_17']) && $_POST['Nif_17'] !='') {$nif = $_POST['Nif_17'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else{ $designation = "";}?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        $infos['totalDevise'] = $encaissement->Devise_12;

        $valeur01 = $devise01 = $mode = $devise_montant = '';
        $infos['RefINSS'] = $infos['RefINPP'] = $infos['RefONEM'] = $infos['QuotasINSS'] = $infos['QuotasINPP'] = $infos['QuotasONEM'] = '';
        $infos['standard'] = '';
}
?>


<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $this->chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Ndeclaration" value="<?= isset($declaration->Id_0) ? $declaration->Id_0 : 1; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Beneficaire_15" value="DGI"  id="regies" />

    <div class="box-body">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader"><?php if(!empty($note_reference)) echo '<div class="alert alert-danger text-white"> La d&eacute;claration avec la r&eacute;f&eacute;rence '.$note_reference->Noteid_26.' a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; ?></div>
            </div> 
            <!------------------------- Beneficiare  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                    </span>
                    <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" id="regie" required="required"  '); ?>
                    <?php if($encaissement->Id_0 !=NULL): ?>
                        <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                    <?php endif; ?>
                </div>
            </div> 
            <div class="col-md-7">
                <div class="input-group"  id="regie0">
                    <span class="input-group-addon">
                        <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                    </span>
                    <span id="slist"><?php echo form_dropdown('Service_16', $services, isset($content['Service']) ? $content['Service'] : "" , 'class="form-control chosen-select" id="service"  required="required" '); ?></span>

                </div>
            </div> 
        
        
            <!-------------------------  Titre de perception  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $reference), ' class="form-control" id="reftitre" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-7">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', $documents[5]), 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="5">
                </div>
            </div>
            <div id="bl" class="col-md-12"></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7">
                <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label> 
                    </span>
                    <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?></span>
                </div>
            </div>
            
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">P&eacute;riode</label> 
                    </span>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", ''), ' class="form-control" id="datepicker3" required="required" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label> 
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('total', isset($paiement['Notemontant']) ? $paiement['Notemontant'] : ""), ' id="montantNote" class="form-control" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                   <?php echo form_dropdown('Notedevise_29',$devises, '', 'class="form-control" id="deviseNote"  required="required"'); ?>
                </div>
            </div>
        
        
        
        
            <!------------------------- Payement  ------------------------------>
            <div class="col-md-12 no-padding">
                <div class="col-md-5 border"><br/><label>Partie 3 : Assujetti ou Contribuable. </div>
                <div class="col-md-3 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"></span></label></div>
<!--                <div class="col-md-2 border"></br><label>Paie pour compte&nbsp;<input type="checkbox" name="Infos[pourcompte]" value="<?= 1 ?>"></label></div>-->
                <div class="col-md-2 border"></div>
                
                
                <input type="hidden" name="Infos[fraisbcc]"  value="1" id="infosFbcc">
                <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
            </div>
            <div class="col-md-12 hidden" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux d'echange : </b> <span id="exchange_message"></span></div>
            
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', $nif), 'class="form-control" required="required" maxlength="86"'); ?>
                </div>
            </div> 
            <div class="col-md-7">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14">D&eacute;signation</label> 
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', $designation), 'class="form-control" required="required" maxlength="86"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode_19">Mode de paiement</label> 
                    </span>
                    <?php echo form_dropdown('Mode_19', $modes, $mode, 'class="form-control" required="required" id="modeId"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Taux_41">Taux de change</label> 
                    </span>
                    <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    <input type="hidden" value="TTB" name="Infos[rate_code]" id="rate_code" >
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                       <label for="Datevaleur_31">Date paiement</label>
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  disabled="disabled" required="required" '); ?>
                    <input type="hidden" name="Datevaleur_31" value="<?= gmdate('Y-m-d')?>" id="">
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                    </span>
                    <?php echo form_input('Reference_32', set_value('Reference_32', $reference), 'class="form-control"'); ?>
                </div>
            </div> 
            <div class="col-md-5">
                <div class="input-group"> 
                    <span class="input-group-addon">
                        <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                    <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                    <input type="hidden" name="Infos[accounttax]" value="" id="tax_info">
                    <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                    <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant &agrave; payer</label> 
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', isset($paiement['Notemontant']) ? $paiement['Notemontant'] : ""), 'class="form-control" id="recetteMontant" required="required"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23"><div id="commiision">Commission</div></label>
                    </span>
                    <?php echo form_input('Commission_23', set_value('Commission_23', ""), 'class="form-control" required="required" id="commission"'); ?>
                    
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Total">Montant total</label> 
                    </span>
                    <?php echo form_input("Infos[totalMontant]", set_value('Infos[totalMontant]', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required" id="compteDevise" '); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_12', $devises, '', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="commissionDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF'), 'CDF', 'class="form-control bg-gray" id="totalDevise"'); ?>
                </div>
            </div>




            <!-------------------------  DGI Cotisation  ------------------------------>
            <div id="DGICotisation" style="display: none;">
                <div class="col-md-12"><br/><label>Partie 4 : Informations additionnelle</label><br/></div>
                
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefDGI">R&eacute;f&eacute;rence DGI</label> 
                        <?php echo form_input("Infos[RefDGI]", set_value("Infos[RefDGI]", ''), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefONEM">R&eacute;f&eacute;rence ONEM</label> 
                        <?php echo form_input("Infos[RefONEM]", set_value("Infos[RefONEM]", ''), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefINPP">R&eacute;f&eacute;rence INPP</label> 
                        <?php echo form_input("Infos[RefINPP]", set_value("Infos[RefINPP]", ''), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefINSS">R&eacute;f&eacute;rence CNSS</label> 
                        <?php echo form_input("Infos[RefINSS]", set_value("Infos[RefINSS]", ''), 'class="form-control"'); ?>
                    </div>
                </div> 
               
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasDGI">Quota DGI</label> 
                        <?php echo form_input("Infos[QuotasDGI]", set_value("Infos[QuotasDGI]", ''), 'class="form-control" id="quota_dgi" '); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasONEM">Quota ONEM</label> 
                        <?php echo form_input("Infos[QuotasONEM]", set_value("Infos[QuotasONEM]", ''), 'class="form-control" id="quota_onem"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasINPP">Quota INPP</label> 
                        <?php echo form_input("Infos[QuotasINPP]", set_value("Infos[QuotasINPP]", ''), 'class="form-control" id="quota_inpp"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasINSS">Quota CNSS</label> 
                        <?php echo form_input("Infos[QuotasINSS]", set_value("Infos[QuotasINSS]", ''), 'class="form-control" id="quota_inss"'); ?>
                    </div>
                </div> 
            </div>
            <!-------------------------  END  ------------------------------>
			
			<!-------------------------  DGI Vente des plaques  ------------------------------>
            <div id="DGIVenteplaque" style="display: none;">
                <div class="col-md-12"><br/><label>Partie 4 : Informations additionnelle</label><br/></div>
                
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="MontantTresor">Montant Tresor</label> 
                        <?php echo form_input("Infos[MontantTresor]", set_value("Infos[MontantTresor]", ''), 'class="form-control" id="montant_tresor" '); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="MontantSYNTELL">Montant SYNTELL</label> 
                        <?php echo form_input("Infos[MontantSYNTELL]", set_value("Infos[MontantSYNTELL]", ''), 'class="form-control" id="montant_syntell"'); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="MontantUTSCH">Montant UTSCH</label> 
                        <?php echo form_input("Infos[MontantUTSCH]", set_value("Infos[MontantUTSCH]", ''), 'class="form-control" id="montant_utsch"'); ?>
                    </div>
                </div>
               
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="MontantDGI">Montant DGI</label> 
                        <?php echo form_input("Infos[MontantDGI]", set_value("Infos[MontantDGI]", ''), 'class="form-control" id="montant_dgi" '); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="MontantSONAS">Montant SONAS</label> 
                        <?php echo form_input("Infos[MontantSONAS]", set_value("Infos[MontantSONAS]", ''), 'class="form-control" id="montant_sonas"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="MontantHOLOGRAMME">Montant HOLOGRAMME</label> 
                        <?php echo form_input("Infos[MontantHOLOGRAMME]", set_value("Infos[MontantHOLOGRAMME]", ''), 'class="form-control" id="montant_hologramme"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="MontantRTNC">Montant RTNC</label> 
                        <?php echo form_input("Infos[MontantRTNC]", set_value("Infos[MontantRTNC]", ''), 'class="form-control" id="montant_rtnc"'); ?>
                    </div>
                </div> 
            </div>
            <!-------------------------  END  ------------------------------>
			
    </div>
    <div  class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12">
                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="print" disabled="disabled" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    </div>
<?php $this->chtml->box_body_closing(); ?> 	  

<?php echo form_close(); ?>
    
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>  
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>'; 
var html_cotisation =  $("#DGICotisation").html();
var html_venteplaque =  $("#DGIVenteplaque").html();
var montant_total = '';
$("#DGICotisation").html('');
$("#DGIVenteplaque").html('');
$('.chosen-select').chosen({width: "100%"});

var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});
$('#datepicker3').datepicker({
        todayHighlight: true,
	format: 'mm/yyyy'
});

$("#pager").on("change", "#quota_dgi", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#quota_onem", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#quota_inpp", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#quota_inss", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#montant_tresor", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

 
$("#pager").on("change", "#montant_hologramme", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

 
$("#pager").on("change", "#montant_sonas", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});


$('#montantNote').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#montant_dgi", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#montant_syntell", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#montant_utsch", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#montant_rtnc", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});


$('#recetteMontant').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#commission').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});


$('#montantNote').change(function(){
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        
        $('#montantNote').val(note);
        $('#recetteMontant').val(note);
        
        if(note !="")
        {
            
            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');
            commission();
            get_account_tariff();
        }
});

$('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(devise == 'USD')
            {
                note = note * taux;
                if(note) $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                if(note) $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');

            commission();
            get_account_tariff();
        }
        
        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();

        if(devise_recette == 'USD' && devise_compte == 'CDF')
        {
            get_exchange_rate();
        }
        else
        {   
            $('#exchange_bloc').addClass('hidden');
            taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
            $('#Taux').val(taux);
        }
});

$('#recetteMontant').change(function(){
    
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);
        
        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                    $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else
            {
                    var commissions = $("#commission").val();

                    if(commissions !='0' && commissions !='')
                    {
                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                            if(deviseNote=='USD')
                            {
                                montant = montant * taux;

                                montant = commissions + montant + (commissions *0.16);

                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }
                    else
                    {
                            if(recetteDevise == 'USD')
                            {
                                montant = montant * taux;
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }

                    $('#info').html('');
                    commission();
                    get_account_tariff();
            } 
        }
});

$('#recetteDevise').change(function(){
        commission();
});

$('#service').change(function(){
        commission();
        get_account_tariff();
});

$('#commission').change(function(){
        var commissions = $("#commission").val();
        var devise = $('#recetteDevise').val();
        var montant = $('#recetteMontant').val();
        
        if(commissions !='0' && commissions !='')
        {
                commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    montant = montant * taux;
                    montant = montant + commissions + (commissions *0.16);

                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    montant = montant + (montant *0.0005) + commissions + (commissions *0.16);
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
        else if(commissions=='0' || commissions=='')
        {
                if(devise == 'USD')
                {
                    montant = montant * taux;
                    
                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
});


$("#pager").on("change", "#recette", function(){
        commission();
        get_account_tariff();
        var recette = $('#recette option:selected').val();
        if(recette === 'IPRIER'){
            $("#DGICotisation").css('display', '');
            $("#DGICotisation").html(html_cotisation);
        }
        else
        {
            $("#DGICotisation").css('display', 'none');
            $("#DGICotisation").html('');
        }
		
		if(recette ==='REIMATTRIC' || recette ==='IMMATRIC' || recette ==='MUTATION')
        {
            $("#DGIVenteplaque").css('display', '');
            $("#DGIVenteplaque").html(html_venteplaque);
        }
        else
        {
            $("#DGIVenteplaque").css('display', 'none');
            $("#DGIVenteplaque").html('');
        }
});



$('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        //$("#enregistrer").prop('disabled', true);
        scrollUP();
        
        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var test_balance = false;
        
        var compte = $("#compteId").val();

        if(compte.length == 14)
        {
            test_balance = false;
        }
        else
        {
            test_balance = true;
        }
        
        
        '<?php if(isset($encaissement->Id_0) && $encaissement->Id_0 !=""){ ?>'
        
            var recette = '<?= $encaissement->Typerecette_17; ?>'
            
            
        '<?php }else{ ?>'
        
            var recette = $('#recette option:selected').val();
            
        '<?php } ?>'
        
        var service_type = $('#service option:selected').val();
        
        if(recette == 'IPRIER')
        {
                var verif_iprier = verify_iprier_amount();

                if(verif_iprier)
                {
                        if(test_balance)
                        {
                            get_account_balance(data);
                        }
                        else
                        {
                            submiter(data);
                        }
                }
                else
                {
                        $('#loader').html('<div class="alert alert-danger text-white"> Le montant &agrave; payer n\'est pas &eacute;gal &agrave; la somme de quotas des diff&eacute;rentes instutitions !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        }
        else if(recette == 'REIMATTRIC' || recette == 'IMMATRIC' || recette == 'MUTATION' )
        {
                var verif_plaque = verify_plaque_amount();

                if(verif_plaque)
                {
                        if(test_balance)
                        {
                            get_account_balance(data);
                        }
                        else
                        {
                            submiter(data);
                        }
                }
                else
                {
                        $('#loader').html('<div class="alert alert-danger text-white"> Le montant &agrave; payer n\'est pas &eacute;gal &agrave; la somme de quotas des diff&eacute;rentes instutitions !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        }
        else
        {
                
                
                if(test_balance)
                {
                    get_account_balance(data);
                }
                else
                {
                    submiter(data);
                }
                
        }
});
$("#compteId").change(function(){
    
    var compte = $("#compteId").val();
    get_account_tariff();
    
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname(); 
           
    }
});


$("#compteDevise").change(function(){
    var compte = $("#compteId").val();
        
    if(compte.length == 14)
    {
            get_accountname_internal();
            
    }
    else
    {
            get_accountname(); 
           
    }
    
    get_account_tariff();
    commission();
    
    var devise_recette = $('#deviseNote option:selected').val();
    var devise_compte = $('#compteDevise option:selected').val();
    
    if(devise_recette == 'USD' && devise_compte == 'CDF')
    {
        get_exchange_rate();
    }
    else
    {   
        $('#exchange_bloc').addClass('hidden');
        taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
        $('#Taux').val(taux);
    }
});

$("#cancel").click(function(){
        location.reload(true);
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGRAD';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var commission = $("#commission").val();
        var  total_amount = '';
        var customer_code = $("#compteId").val();
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, customer_code:customer_code }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '' || commission == 0)
                        {
                            if(result[0] !="")
                            {
                                    $("#commission").val(result[0]);
                                    $("#commissionDevise").val(result[1]);
                                    $("#montantTotal").val(result[2]);
                            }
                        }
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}

function get_exchange_rate()
{
        var devise = $('#compteDevise').val();
        var devise_recette = $('#recetteDevise').val();
        var note_number = $('#reftitre').val();
        
        $('#exchange_bloc').removeClass('hidden');
        
        $("#exchange_message").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                
        var url = '<?php echo base_url($module.'/rates/data/get_taux'); ?>';
        
        $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { devise_compte : devise, devise_recette : devise_recette, note_number :note_number }, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse.code == '200')
                                {
                                        $("#Taux").val(reponse.rate);
                                        $("#exchange_message").css('color', 'green');
                                        $("#exchange_message").html('Taux de vente r&eacute;cup&eacute;r&eacute; avec succ&egrave;s.');
                                        $('#rate_code').val('TTS');
                                        taux = reponse.rate;
                                        exchange_changes();
                                }
                                else if(reponse.code == '0003')
                                {
                                        $("#exchange_message").css('color', 'red');
                                        $("#exchange_message").html('Probl&egrave;me de connexion &agrave; Finacle, le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                }); 
}

function exchange_changes()
{
    //alert(taux);
    var note = $('#montantNote').val();
    //alert(note);
    var deviseNote = $('#deviseNote option:selected').val();

    $('#montantNote').val(note);
    $('#recetteMontant').val(note);

    if(note !="")
    {
        
        note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

        if(deviseNote == 'USD')
        {
            note = note * taux;
            $('#montantTotal').val(note.toLocaleString());
        }
        else
        {
            $('#montantTotal').val(note.toLocaleString());
        }

        $('#commission').val('');
        commission();
    }
}

function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#compteDevise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + (montant *0.0005) + commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

function get_accountname_internal()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#compteDevise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + (montant *0.0005) + commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        //$("#account_balance").val(reponse.balance);
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

function get_account_tariff()
{
        var compte = $('#compteId').val();
        var regie = 'DGI';
        var url = '<?php echo base_url($module.'/accounts/data/get_account_tarification'); ?>';
        
        if(compte !== '')
        {  
                $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, regie : regie}, 
                        dataType    : 'json', 
                        encode      : true,
                        success: function(reponse)
                        {
                            
                                if(reponse.commission >= 0)
                                {
                                        if (reponse.commission > 0)
                                        {
                                            $("#commission").val(reponse.commission);
                                            $("#commissionDevise").val(reponse.devise);
                                            
                                            var commissions = reponse.commission;
                                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                                        }
                                        
                                        
                                        $("#infosFbcc").val(reponse.fraisbcc);
                                        $("#infosTva").val(reponse.tva);

                                        
                                        var tva = reponse.tva;
                                        var fbcc = reponse.fraisbcc;
                                        
                                        //$('#commission').val(commissions.toLocaleString());

                                        
                                        var montant = $('#recetteMontant').val();

                                        var recetteDevise = $('#recetteDevise option:selected').val();
                                        
                                        
                                        if(montant != "")
                                        {
                                            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
                                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                                            
                                            if(recetteDevise=='USD')
                                            {
                                                montant = montant * taux;

                                                montant = commissions + montant + (commissions *0.16);

                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (tva == '0' && fbcc == '0')
                                            {
                                                montant = commissions  + montant;
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (tva == '1')
                                            {
                                                montant = commissions  + montant + (commissions *0.16);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (fbcc == '1')
                                            {
                                                montant = commissions  + montant + (montant *0.0005);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else
                                            {
                                                montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                        }
                                }
                        },
                        error:function(error)
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }   
                });  
        }
        else
        {
                
        }
}
function get_account_balance(data)
{
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
		
        
        var url = '<?php echo base_url($module.'/accounts/data/get_account_balance'); ?>';
        
        $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_compte : devise_compte, balance : balance}, 
                        dataType    : 'html',  
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '200')
                                {
                                        submiter(data);
                                }
                                else if(reponse == '300')
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant pour le paiement de cette d&eacute;claration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(reponse == '405')
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                $("#enregistrer").prop('disabled', false);
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
        });
}


function submiter(data)
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/declaration/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        scrollUP();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E162")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E463")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E3238")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "W0205")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E397")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "AD3")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "E9999")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "ERR002")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "ERR003")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "P83")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#step2').remove;
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                
                                var url = '<?php echo base_url($module.'/declaration/display/preview'); ?>/' + result;
                                $.get(url, function(data, status){
                                    $('#loader').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function verify_iprier_amount(){
    
    var montant_paye = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
    
    var dgi = parseFloat($("#quota_dgi").val().split(' ').join('').split(',').join('.'));
    var onem = parseFloat($("#quota_onem").val().split(' ').join('').split(',').join('.'));
    var inss = parseFloat($("#quota_inss").val().split(' ').join('').split(',').join('.'));
    var inpp = parseFloat($("#quota_inpp").val().split(' ').join('').split(',').join('.'));
    var montant = "";
    
    montant = dgi + onem + inss + inpp;
    
    montant = Math.round(montant*100)/100; 
    
    if(montant_paye > montant || montant_paye != montant)
    {
        return false;
    }
    else
    {
        return true;
    }
}

function verify_plaque_amount(){
    
    var montant_paye = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
    
    var tresor = parseFloat($("#montant_tresor").val().split(' ').join('').split(',').join('.'));
    var dgi = parseFloat($("#montant_dgi").val().split(' ').join('').split(',').join('.'));
    var syntell = parseFloat($("#montant_syntell").val().split(' ').join('').split(',').join('.'));
    var utsch = parseFloat($("#montant_utsch").val().split(' ').join('').split(',').join('.'));
    var sonas = parseFloat($("#montant_sonas").val().split(' ').join('').split(',').join('.'));
    var hologramme = parseFloat($("#montant_hologramme").val().split(' ').join('').split(',').join('.'));
    var rtnc = parseFloat($("#montant_rtnc").val().split(' ').join('').split(',').join('.'));
    var montant = "";
    
    montant = tresor + dgi + syntell + utsch + sonas + hologramme + rtnc;
    
    montant = Math.round(montant*100)/100; 
    
    if(montant_paye > montant || montant_paye != montant)
    {
        return false;
    }
    else
    {
        return true;
    }
}
function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>

