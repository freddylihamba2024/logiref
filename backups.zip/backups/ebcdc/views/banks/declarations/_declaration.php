<?php $userid = $this->session->userdata("user_id"); $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); ?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php $Standard01='';?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
$title = 'Effectuer le paiement';
?>
<?php $this->chtml->box_body_opening('', true);?>
<div class="">
    <div id="loader"></div>
    <style>label {min-width: 150px !important;}</style>
    <?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Ndeclaration" value="<?php echo $declaration; ?>" />
    <div class="box-body">
        <!------------------------- B�n�ficiare  ------------------------------>
        <div class="col-md-12"><br/><label>B&eacute;n&eacute;ficiare</label><br/></div>
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_15', $beneficiaires['Regies'], $encaissement->Beneficaire_15, ' id="regies" class="form-control" '.$disabled.' required="required"  '); ?>
                <?php if($encaissement->Beneficaire_15 !=NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-6">
            <div class="input-group"  id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                </span>
                <span id="slist"><?php echo form_dropdown('Service_16', array(), $encaissement->Service_16, 'class="form-control" id="service" '.$disabled.' required="required" '); ?></span>
                <?php if($encaissement->Service_16 != NULL): ?>
                    <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <!------------------------- Payement  ------------------------------>
        <div class="col-md-12 border"><br/><label>Client (assujetti ou contribuable) </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
                </div>
            </div> 
            <div class="col-md-7">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14">D&eacute;signation</label> 
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                       <label for="Datevaleur_31">Date paiement</label>
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode_19">Mode de paiement</label> 
                    </span>
                    <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                </div>
            </div> 
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant pay&eacute;</label> 
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                </div>
                <div class="input-group"> 
                    <span class="input-group-addon">
                        <label for="Compte_33"><div id="compteLabel"><?php echo $label01; ?></div></label> 
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" disabled="" id="compteId"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" disabled="" id="compteDevise"'); ?>
                </div>
            </div>
            <div class="col-md-12">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_32">R&eacute;f&eacute;rence du client</label>
                    </span>
                    <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                </div>
            </div> 
        <!-------------------------  Titre de perception  ------------------------------>
        <div class="col-md-12"><br/><label>Titre de perception</label><br/></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26"><div id="TitreId">R&eacute;f&eacute;rence titre</div></label> 
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-7">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17">Nature paiement</label> 
                </span>
                <span id="rlist"><?php echo form_dropdown('Typerecette_17', array(), $encaissement->Typerecette_17, 'class="form-control" id="recette" disabled="disabled" required="required" '); ?></span>
            </div>
        </div>
        <div id="bl" class="col-md-12"></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-7">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25">Type note</label> 
                </span>
                <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" id="doc" required="required" '); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard"><div id="StandardLabel01">Ech&eacute;ance</div></label> 
                </span>
                <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $infos['standard']), ' class="form-control" id="Standard01" disabled="" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28">Montant de la note</label> 
                </span>
                <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="Notemontant_28" class="form-control"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="Notedevise_29"  required="required"'); ?>
            </div>
        </div>
        <div>
            <div class="col-md-12"><br/><label>Repartition</label><br/></div>
            <div  id="Comptabilisation" class="col-md-12">

            </div>
        </div>
    </div>
    <div  class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12">
            <?php if($feuille==''): ?>
                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; Attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php endif; ?>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>
<?php $this->chtml->box_body_closing(); ?>
<div class="col-md-1"></div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
var status_print ='<?php  echo($encaissement->Checkerid_10!=0 && $encaissement->Checkerid_10!="")? true: false ;?>'; 
var Dtaux=[];
Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>'; 
$("#Standard01").datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
})

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var data = $(this).serialize();
        submiter(data); 
});  
$("#recetteMontant").change(function(){
  
        montantValidation();
        commission();
});
$("#recetteDevise").change(function(){

        montantValidation();
        commission();
    
});
var mode = $('#modeId').val();
changeMode(mode);

shower()   
function shower()
{
        var regie = $('#regies option:selected').val();
        var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/services/<?php echo $encaissement->Service_16; ?>';
        $.get(url, function(data, status){
            $("#slist").html(data);
        });
        
        var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/recettes/<?php echo $encaissement->Typerecette_17; ?>';
        $.get(url, function(data, status){
            $("#rlist").html(data);
        });
        $(".Standard01").datepicker({
                todayHighlight: true,
                format: 'dd-mm-yyyy'
            });
            $("#Standard01").prop('disabled','');
            $("#Standard01").prop('maxlength','12');
            $("#Standard01").val('<?php echo $Infos['standard'];?>');
}

function comptabilisation(ref){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

function submiter(data){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E404" || result === "E22")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E405")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34x")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#loader').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                comptabilisation(result.logiref_4);
                                ref = result.ref;
                                $('#print').prop("disabled",false);
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

$("#print").click(function(){

        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$('#modeId').change(function(){
        var mode = $('#modeId').val();
       if(mode === '7' || mode == '8')
        {
                $("#compteId").prop('disabled',''); 
                $("#compteDevise").prop('disabled',''); 
                $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
                $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
                $("#compteId").val('');
        }
        else
        {
            $("#compteId").prop('disabled','disabled'); 
            $("#compteDevise").prop('disabled','disabled');
            $("#compteLabel").html('Commission');
            commission();
        }
});

function changeMode(mode)
{
        if(mode === '7' || mode == '8')
        {
                $("#compteId").prop('disabled',''); 
                $("#compteDevise").prop('disabled',''); 
                $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
                $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
                $("#compteId").val('');
        }
        else
        {
            $("#compteId").prop('disabled','disabled'); 
            $("#compteDevise").prop('disabled','disabled');
            $("#compteLabel").html('Commission');
            commission();
        }
}


function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#compteId").val('');
        $("#compteDevise").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = $('#regies option:selected').val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        
        if(mode === '5' && montant !== '' && regie !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/bank/display/charges'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        $("#compteId").val(result[0]);
                        $("#compteDevise").prop("selectedIndex", result[1]);
                        //$('#loader').html(reponse);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                    }  
            });    
        }
}

$("#Notemontant_28").change(function()
{
        montantValidation();

});

$("#Notedevise_29").change(function(){
    
        montantValidation();
});


function montantValidation()
{
        var notemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
        var recettemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
        var rdevise = $("#recetteDevise option:selected").val();
        var ndevise = $("#Notedevise_29 option:selected").val();
        var note = 0;
        var recette=0;
       
        
        if(isNaN(recettemontant))
        {
                recettemontant = 0;
        }
        
        if(isNaN(notemontant))
        {
                notemontant = 0;
        }
        
        $("#recetteMontant").closest('div').removeClass("has-error");
        $('#info').text("");
        if((rdevise!='' && ndevise!='') && (recettemontant && notemontant))
        {
                if((rdevise != null && rdevise !="CDF") && (ndevise != null && ndevise !="CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant * Dtaux[rdevise];
                }
                else if((ndevise!= null && ndevise != "CDF") && (rdevise != null && rdevise == "CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant;
                }
                else if((rdevise != null && rdevise != "CDF") && (ndevise != null && ndevise == "CDF"))
                {
                        recette = recettemontant * Dtaux[rdevise];
                        note = notemontant;
                }
                else
                {
                    note = notemontant * 1;
                    recette = recettemontant * 1;
                }
                
                if( note >= recette)
                {
                        valid = false;
                        $("#recetteMontant").closest('div').removeClass("has-error");
                        $('#info').text("");
                }
                else
                {
                        valid = true;
                }

                if(valid)
                {
                        $("#recetteMontant").closest('div').addClass('has-error');
                        $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
                        //$("#recetteMontant").val("");
                }
                 
        }
       
        
       
}
</script>
