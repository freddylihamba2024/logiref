<?php $user = $this->session->userdata('user_id');?>
<?php $type = $this->session->userdata('user_type');?>
    <div  class="col-md-10">
         <div id="loader"></div>
        <h2 class="text-blue">Les d&eacute;clarations</h2>
        <h5 class="page-header"><span class="text-gray">Trouvez ici toutes les d&eacute;clarations</span></h5>
    </div>
    <div class="col-md-2">
        <a id="new" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>   
    </div>
    <div class="col-md-10">
        <?php if(!empty($declarations)): ?>
        <?php $this->chtml->box_body_opening('', true); ?>
            <table id="tableREN1" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-gray">
                        <th width="4%">#</th>
                        <th width="12%">Date</th>
                        <th width="10%">Statut</th>
                        <th>D&eacute;signation</th>
                        <th>Service</th>
                        <th width="15%">Montant</th>
                        <th width="5%"><span class="fa fa-fw fa-tasks f14"></span></th>
                        <th width="5%"><span class="fa fa-fw fa-file-pdf-o f14"></span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach($declarations as $obj): ?>
                        <?php $content = json_decode($obj->Content_16, true); if(isset($content['paiement'])) $paiement = json_decode($content['paiement'], true); ?>
                        <tr>
                            <td width="4%"><?php echo $i;?></td>
                            <td width="12%"><?php echo strftime('%d-%m-%Y',strtotime($obj->Date_1));?></td>
                            <td width="10%"><span class="badge <?php echo $color[$obj->Status_2];?>"><?php echo $status[$obj->Status_2]; ?></span></td>
                            <td><?php if(isset($content['Nif']) && isset($content['Denomination'])) echo $content['Nif'].' - '.$content['Denomination'];?></td>
                            <td><?php if(isset($content['Service'])) echo $services[$content['Service']];?></td>
                            <td width="15%"><?php if(isset($paiement['Notemontant'])) echo "CDF ".$paiement['Notemontant'];?></td>
                            <td width="5%">
                                    <a style="cursor:pointer" onclick="view('<?php echo $obj->Id_0; ?>', '<?php echo $obj->Status_2; ?>', '<?php echo $obj->Paiementid_19; ?>')" ><span class="fa fa-fw text-yellow fa-folder-open f14"> </span></a>
                            </td>
                            <td width="5%">
                                <?php if($obj->Status_2 == 3 || $obj->Status_2 == 4):?>
                                        <a style="cursor:pointer" onclick="printpdf('<?php echo $obj->Paiementid_19; ?>')" ><span class="fa fa-fw text-yellow fa-file-pdf-o f14"> </span></a>
                                <?php else : ?>
                                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"></span>
                                <?php endif;?>
                            </td>
                        </tr>
                    <?php $i++; endforeach;?>
                </tbody>
            </table>
        <?php $this->chtml->box_body_closing(); ?>
        <?php else: ?>
            <section>
                <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                    <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute;e!</b></h4>
                    <br/>
                </div>
            </section>
        <?php endif;?>
    </div>  
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#tableREN1').DataTable({
      
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "bLengthChange": false,
      "bFilter": false
});

$("#new").click(function () {
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
    $.get("<?php echo base_url($module.'/bank/display/confirmdi'); ?>", function (data, status) {
       $("#loader").html('');
       $("#container").html(data);
    });
});

function view(id, status, paiementid)
{
    $("#loader").html('<img align="middle" height="30px" src="<?php  echo base_url('ikwook_bootstraps/v0/img/loadbar.gif'); ?>" />');
    
    if(status=='1' || status=='2')
    {
        var url = '<?php echo base_url($module.'/bank/display/declaration_step2'); ?>/' + id;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    if(status=='3' || status=='4')
    {
        var url = '<?php echo base_url($module.'/bank/display/declaration_step3'); ?>/' + id +'/'+paiementid;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
}

$("#print").click(function(){

        printpdf(ref);
});

function printpdf (id)
{
    
    var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/'+id;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);
}

</script>

