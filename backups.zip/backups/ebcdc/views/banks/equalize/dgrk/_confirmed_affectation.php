<?php $this->chtml->box_body_opening('', false);?>
    <div class="col-md-12 no-padding">
        <?php if(!empty($affectations)): ?>
        <div class="box-body box-solid no-padding">
            <div class="col-md-12 no-padding">
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table no-margin table-striped table-bordered">
                            <thead class='bg-aqua-active'>
                                <tr>
                                    <th width="">#</th>
                                    <th width="">Date</th>
                                    <th width="">B&eacute;n&eacute;ficiaire</th>
                                    <th width="" class="center">Nombre de paiements</th>
                                    <th width="">Montant</th>
                                    <th width="" class="center">Initiateur</th>
                                    <th width="" class="center">Statut</th>
                                    <th width="" style="text-align:center;"><i class="fa fa-fw fa-list f15"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i =1; 
                                    foreach($affectations as $row): 
                                    $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                                ?>
                                    <tr  id="line<?php echo $row->Id_0;?>">
                                        <td width=""><?php echo $i;?></td>
                                        <td width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                                        <td width=""><?php echo "DGRK" ?></td>
                                        <td width="" class="center"><?php echo $row->Nombrepaiement_8;?></td>
                                        <td width=""><?php echo "CDF ".$row->Montant_7; ?></td>
                                        <td width="" class="center"><?php echo $operateur; ?></td>
                                        <td class="center">
                                            <span class="badge <?php echo $statusColor[$row->Status_2]?>">
                                            <?php echo $status[$row->Status_2]; ?>
                                            </span>
                                        </td>
                                        <td class="center">
                                            <a style="cursor: pointer" onclick="view('<?php echo $row->Id_0; ?>')"> 
                                                <i class="fa fa-fw fa-list text-green f15"></i> 
                                            </a>
                                        </td>
                                    </tr>
                                <?php $i++; endforeach; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
            <section>
                <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                    <h4 align="center"><b>Aucune affectation trouv&eacute; !</b></h4>
                    <br/>
                </div>
            </section>
        <?php endif;?>
    </div>
<?php $this->chtml->box_body_closing(); ?>


<script type="text/javascript">

function view(id)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/confirm_affectation'); ?>/'+id;
        
        $.get(url ,function(data, status){
            $("#loader").html('');
            $('#container').html(data); 
        });
}



</script>