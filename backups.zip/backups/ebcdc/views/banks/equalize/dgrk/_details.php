
<div class=""></div>
<div  class="col-md-12">
    <div id="loader"></div>
    <?php $this->chtml->box_body_opening('', true);?>
        
            <div class="box-body">
                <div class="col-md-12 no-padding">
                    <div class="col-md-12">
                        <br/><br/>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Recette fiscale</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo number_format($payment_affectation['Total_RFS'],2,","," ").' CDF';?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Recette non fiscale</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($payment_affectation['Total_RNF'],2,","," ").' CDF';?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taxe de consommation</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($payment_affectation['Total_TCS'],2,","," ").' CDF';?>
                            </div>
                        </div>
                                              
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Nombre de paiements</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $payment_affectation['Total_payment'];?>
                            </div>
                        </div> 
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($payment_affectation['Total_amount'],2,","," ").' CDF';?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total frais bancaire</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($payment_affectation['Total_TCS'],2,","," ").' CDF';?>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-12 bTop">
                    <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                </div>
                <div class="col-md-12"><br></div>
                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead >
                            <tr class="bg-blue">
                                <th width="250px">Libell&eacute;</th>
                                <th width="100px">Op&eacute;ration</th>
                                <th width="200px">Source</th>
                                <th width="200px">D&eacute;stination</th>
                                <th class="right" width="">Montant</th>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php foreach($lines as $row) :?>
                                <?php if($row->Montant_10 > 0):?>
                                    <tr>
                                        <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                        <td  width="100px"><?php echo $row->Operation_8;?></td>
                                        <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                        <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                        <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                    </tr>
                                <?php endif;?>
                            <?php endforeach;?>
                        </tbody>    
                    </table>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div class="col-md-12">
                    <button type="submit" id='validate_affectation' <?php if(isset($affectation->Status_2) && $affectation->Status_2 == 2) echo "disabled" ?> class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script type="text/javascript">

$("#cancel").click(function(){
        location.reload(true);
});

$("#validate_affectation").click(function(){
    
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#validate_affectation").prop("disabled", true);
        var reference = '<?= $reference ?>';
        
        scrollUP();
        
        var url = '<?php echo base_url($module.'/dgrk/save/validate'); ?>/'+ reference;
        
        $.get(url ,function(result, status){
            $("#loader").html('');
            if(result === "E162")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E463")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E411")
            {
                    $("#message").html('');
                    $('#enregistrer').prop("disabled",false);
                    $('#loader').html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E3238")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "W0205")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E397")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "AD3")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
                    else if(result === "E9999")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
                    else if(result === "ERR002")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
                    else if(result === "ERR003")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
                    else if(result === "P83")
            {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else
            {
                    $('#loader').html('<div class="alert alert-success text-white">Bravo! affectation des fonds valid&eacute;e avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } 
        });
});


function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>