<div class="content">
    
    <div class="col-md-12">
        <div id="loader"></div>
        <h2 class="text-blue" ><?php echo " D&eacute;claration ou Note de perception (DGRK)"; ?></h2>
        <p class="page-header"></p>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification de la note<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Impression de la preuve<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/></div>
        <div id="pager" class="col-md-12 no-padding">
            <?php 
            if($step==2)
            { 
                    echo $this->load->view('_step_2'); 
            }
            elseif($step==3)
            { 
                    echo $this->load->view('_step_3');
            }
            else
            { 
            ?>
            <?php $this->chtml->box_body_opening("", true);?>
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="col-md-4">
                        <div id="approvalWarning" style="color:#F00"></div><br/>
                        <p>
                            Renseignez le num&eacute;ro de la d&eacute;claration ou de la note de perception en suite cliquez sur suivant pour payer cette note.
                        </p>
                        <br/><br/>
                    </div>
                    <div class="col-md-8 bLeft">
                        <div class="box-body">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Reference_14">Num&eacute;ro de la note</label>
                                    <?php echo form_input('id_declaration','', 'class="form-control"  id="Reference_14" required = "required" '); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Nif_17">Num&eacute;ro d'imp&ocirc;t du client</label> 
                                    <?php echo form_input('Nif_17','', 'class="form-control" id="Nif_17" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class=" clearfix">
                            <div class="col-md-12">
                                <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary "><i class="fa fa-search"></i> Suivant -> </button>
                                <a id="" href="" type="button" style="margin-left:5px;" name="button" class="btn btn btn-warning " ><i style="color:#fff" class="fa fa-times"></i> Quitter </a>&nbsp;
                            </div>
                        </div>
                    </div>
                <?php echo form_close(); ?>  
            <?php $this->chtml->box_body_closing(); ?>
            
            <?php }?>
        </div>
    </div>
    
</div>
<script type="text/javascript">
$('#mainform').submit(function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
        
});

function next_step(data)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/verification'); ?>';
         $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E404")
                        {
                                $("#loader").html('<div class="alert alert-warning"> D&eacute;sol&eacute;... EDGRK n\'est pas disponible, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#saisie").removeClass('btn-default');
                                $("#saisie").addClass('btn-success');
                                $("#saisie").prop("disabled", '');
                        }
                        else if(result === "E500")
                        {
                                $("#loader").html('<div class="alert alert-warning"> Un probl&egrave;me est survenu lors de l\'enregistrement des informations de cette note, veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E400")
                        {
                                $("#loader").html('<div class="alert alert-danger">Les informations renseign&eacute;es sont incorrectes, veuillez v&eacute;rifier s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                               $("#pager").html(result);
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        }); 
}

$("#saisie").click(function(){
    
    var data = $("#mainform").serialize();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.''); ?>/dgrk/display/create';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result){

            $("#loader").html('');
            $("#pager").html(result);
            $("#step-1").removeClass('bg-green-active');
            $("#step-1").addClass('bg-gray');
            $("#step-2").removeClass('bg-gray');
            $("#step-2").addClass('bg-green-active');
                
        },
        error:function(error){
                alert(error);
        }
    });
});

$("#cancel").click(function(){
   location.reload(true);
});
</script>
