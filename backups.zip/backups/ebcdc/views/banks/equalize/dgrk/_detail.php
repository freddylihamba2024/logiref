<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', true);?>
    <div class="col-md-12">
        <h2 class=" f20 w-300 page-header">D&eacute;tails de l'aff&eacute;ctation de la recette fiscale.</h2>
    </div>
    <div class="col-md-12">
        <div class="box-body">
            <table class="table no-margin table-bordered">
                <thead class='bg-blue'>
                    <tr>
                        <th width="3%">#</th>
                        <th width="5%">Date</th>
                        <th width="100px">B&eacute;n&eacute;ficiaire</th>
                        <th width="150px">Montant</th>
                        <th width="150px">N&ordm; de compte</th>
                    </tr>
                </thead>
                <tbody>
                        <tr class="bg-gray">
                            <td width="" colspan="6"><b>Recette fiscale</b></td>
                        </tr>
                        <tr>
                            <td width="" rowspan="3" style="vertical-align: middle;">1</td>
                            <td width="" rowspan="3" style="vertical-align: middle;">20-11-2021</td>
                            <td width="">Prime de mobilisation (28%)</td>
                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["PRM"],2,","," "); ?></td>
                            <td width=""><?= isset($comptes['DGRK2']['RFS']['CDF']) ? $comptes['DGRK2']['RFS']['CDF'] : '00000000000000000000000'; ?></td>
                        </tr>
                        <tr>
                            <td width="">Dgrk fonctionnement (7%)</td>
                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["DGF"],2,","," "); ?></td>
                            <td width=""><?= $compte_pm = isset($comptes['DGRK6']['RFS']['CDF']) ? $comptes['DGRK6']['RFS']['CDF'] : '00000000000000000000000';  ?></td>
                        </tr>
                        <tr>
                            <td width="">Tresor urbain (65%)</td>
                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["TUB"],2,","," "); ?></td>
                            <td width=""><?= isset($comptes['DGRK2']['RFS']['CDF']) ? $comptes['DGRK2']['RFS']['CDF'] : '00000000000000000000000';  ?></td>
                        </tr>
                </tbody>
            </table>
            <div class="col-md-12"><br/></div>
            <table id="table" class="table table-hover table-striped">
                <thead>
                  <tr class="bg-gray">
                      <th width="6%">Id</th>
                      <th width="3%">Sens</th>
                      <th>D&eacute;bit</th>
                      <th>Cr&eacute;dit</th>
                      <th>Montant</th>
                      <th>Designation</th>
                      <th width="8%">Date</th>
                  </tr>
                </thead>
                <tbody>
                    <?php foreach($lines as $row) :?>
                        <?php if($row['Operation_8'] == 'C'):?>
                        <tr class="<?php if($row['Compte_9']=='00000000000000000000000') echo 'text-red'; ?>">
                            <td><?= ++$i; ?></td>
                            <td  width="100px"><?php echo $row['Operation_8'];?></td>
                            <td  class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'-'; ?></td>
                            <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'-'; ?></td>
                            <td ><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                            <td  width="250px"><?php echo $row['Libelle_12'];?></td>
                            <td  width="250px"><?= gmdate('d-m-Y'); ?></td>
                        </tr>
                        <?php else:?>
                        <tr class="<?php if($row['Compte_9']=='00000000000000000000000') echo 'text-red'; ?>">
                            <td><?= ++$i; ?></td>
                            <td  width="100px"><?php echo $row['Operation_8'];?></td>
                            <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'00000000000000000000000'; ?></td>
                            <td  class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'00000000000000000000000'; ?></td>
                            <td ><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                            <td  width="250px"><?php echo $row['Libelle_12'];?></td>
                            <td  width="250px"><?= gmdate('d-m-Y'); ?></td>
                        </tr>
                        <?php endif;?>
                    <?php endforeach;?>
                </tbody>    
            </table>
        </div>
    </div>
    <div  class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12">
                <button type="submit" id='affectation' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    </div>
    <?php $this->chtml->box_body_closing(); ?>
    
    
</div>

<script type="text/javascript">

$("#cancel").click(function(){
        location.reload(true);
});

$("#affectation").click(function(){
       
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var type = '<?= isset($type) ? $type : "" ?>';
        var url = '<?php echo base_url($module.'/dgrk/save/affectation'); ?>/'+ type;
        
        $.get(url ,function(data, status){
            
            if(data > 0)
            {
                
            }
        });
});

function validate()
{
        var url = '<?php echo base_url($module.'/dgrk/save/validate'); ?>/';
        
        $.get(url ,function(data, status){
            $("#loader").html('');
            $('#container').html(data); 
        });
}



</script>