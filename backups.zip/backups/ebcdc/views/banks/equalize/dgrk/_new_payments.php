<?php  



?>

<div class="col-md-12">
  
</div>

<div class="col-md-12 no-padding">
    <?php $this->chtml->box_body_opening('', false);?>
        <div class="col-md-12 no-padding">
            <?php if(!empty($paiements)): ?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin table-striped table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th width="10px">#</th>
                                        <th width="80px">Date</th>
                                        <th width="200px">D&eacute;signation</th>
                                        <th width="100px">Num&eacute;ro imp&ocirc;t</th>
                                        <th width="150px">R&eacute;f&eacute;rence</th>
                                        <th width="100px" class="center">Montant</th>
                                        <th width="100px" class="center">Op&eacute;rateur</th>
                                        <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i =1; 
                                        foreach($paiements as $payment): 
                                        
                                        $operateur = (isset($users[$payment->Creator_4]))? $users[$payment->Creator_4] :' - ';
                                    ?>
                                        <tr  id="line<?php echo $payment->Id_0;?>">
                                            <td width=""><?php echo $i;?></td>
                                            <td width=""><?php echo strftime('%d-%m-%Y',strtotime($payment->Date_1)); ?></td>
                                            <td width=""><?php echo $payment->Designation_15; ?></td>
                                            <td width=""><?php echo $payment->Nif_13;?></td>
                                            <td width=""><?php echo $payment->Reference_14; ?></td>
                                            <td width="" class="center"><?php echo $payment->Devise_8." ".$payment->Montant_7; ?></td>
                                            <td width="" class="center"><?php echo $operateur; ?></td>
                                            <td>
                                                <a style="cursor: pointer" onclick="edit('<?php echo $payment->Id_0; ?>')"> 
                                                    <i class="fa fa-fw fa-list text-green f20"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                    <?php $i++; endforeach; ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Aucun paiement trouv&eacute; !</b></h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="modal fade" id="modal">
    <div class="modal-dialog">
        <div class="modal-content tScroll">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">D&eacute;tails du paiement</h4>
            </div>
            <div id="modal-pager" class="modal-body">
              <p>One fine body&hellip;</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
        <!-- /.modal-dialog -->
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">


function edit(id)
{
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/edit_note'); ?>/' +id;
        
        <?php if($_SESSION['Logiref_role'] == 3): ?>
        $.get(url, {from:"new", controller:"Reports"}, function(data, status){
            $("#loader1").html('');
            $('#container').html(data); 
            $("#step-1").removeClass('bg-green-active');
            $("#step-1").addClass('bg-gray');
            $("#step-2").removeClass('bg-gray');
            $("#step-2").addClass('bg-green-active');
        });
        <?php else: ?>
        $.get(url,{from:"new", controller:"Dgrk"},function(data, status){
            $("#loader1").html('');
            $('#pager').html(data); 
            $("#step-1").removeClass('bg-green-active');
            $("#step-1").addClass('bg-gray');
            $("#step-2").removeClass('bg-gray');
            $("#step-2").addClass('bg-green-active');
        });
        <?php endif;  ?>
}



</script>



