<?php  

    $montant_rfs = isset($payment_affectation["Total_RFS"]) ? $payment_affectation["Total_RFS"] : 0;
    $montant_rnf = isset($payment_affectation["Total_RNF"]) ? $payment_affectation["Total_RNF"] : 0;
    $montant_tcs = isset($payment_affectation["Total_TCS"]) ? $payment_affectation["Total_TCS"] : 0;
?>

<div class="col-md-12">
  
</div>

<div class="col-md-12 no-padding">
    <di id='loader'></di>
    <?php if(empty($affectation)): ?>
    <?php $this->chtml->box_body_opening("", true); ?>
        <div class="statistic-box no-border">
            <div class="col-sm-4 col-xs-4">
                <div class="description-block" >
                    <div class="col-md-12"><span class="f14"><b>Recectte Fiscale</b></span></div><br/><br/>
                    <span class="f12"><?php echo 'CDF '.number_format($montant_rfs,2,","," "); ?></span>
                </div>
            </div>
            <div class="col-sm-4 col-xs-4 border-left">
                <div class="description-block" >
                    <div class="col-md-12"><span class="f14"><b>Recette non fiscale</b></span></div><br/><br/>
                    <span class="f12"><?php echo 'CDF '.number_format($montant_rnf,2,","," "); ?></span>
                    
                </div>
            </div>
            <div class="col-sm-4 col-xs-4 border-left">
                <div class="description-block" >
                    <div class="col-md-12"><span class="f14"><b>Taxe de consommation</b></span></div><br/><br/>
                    <span class="f12"><?php echo 'CDF '.number_format($montant_tcs,2,","," "); ?></span>
                </div>
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?>
    <?php $this->chtml->box_body_opening('', false);?>
        <div class="col-md-12 no-padding">
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th width="3%">#</th>
                                        <th width="10%">Date</th>
                                        <th width="100px">B&eacute;n&eacute;ficiaire</th>
                                        <th width="150px">Montant</th>
                                        <th width="150px">N&ordm; de compte</th>
                                    </tr>
                                </thead>
                                <tbody>
                                        <tr class="bg-gray">
                                            <td width="" colspan="6"><b>Recette fiscale</b></td>
                                        </tr>
                                        <tr>
                                            <td width="" rowspan="3" style="vertical-align: middle;">1</td>
                                            <td width="" rowspan="3" style="vertical-align: middle;"><?= gmdate('d-m-Y'); ?></td>
                                            <td width="">Prime de mobilisation (28%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["PRM"],2,","," "); ?></td>
                                            <td width=""><?= isset($comptes['DGRK2']['RFS']['CDF']) ? $comptes['DGRK2']['RFS']['CDF'] : '00000000000000000000000'; ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Dgrk fonctionnement (7%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["DGF"],2,","," "); ?></td>
                                            <td width=""><?= isset($comptes['DGRK1']['RFS']['CDF']) ? $comptes['DGRK1']['RFS']['CDF'] : '00000000000000000000000'; ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Tresor urbain (65%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RFS"]["TUB"],2,","," "); ?></td>
                                            <td width=""><?= isset($comptes['DGRK6']['RFS']['CDF']) ? $comptes['DGRK6']['RFS']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr class="bg-gray">
                                            <td width="" colspan="6"><b>Recette non fiscale</b></td>
                                        </tr>
                                        <tr>
                                            <td width="" rowspan="4" style="vertical-align: middle;">2</td>
                                            <td width="" rowspan="4" style="vertical-align: middle;"><?= gmdate('d-m-Y'); ?></td>
                                            <td width="">Prime de mobilisation (30%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RNF"]["PRM"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK2']['RNF']['CDF']) ? $comptes['DGRK2']['RNF']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Dgrk fonctionnement (7%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RNF"]["DGF"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK1']['RNF']['CDF']) ? $comptes['DGRK1']['RNF']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Retro services d'assiette (5%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RNF"]["RSA"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK3']['RNF']['CDF']) ? $comptes['DGRK3']['RNF']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Tresor urbain (58%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["RNF"]["TUB"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK6']['RNF']['CDF']) ? $comptes['DGRK6']['RNF']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr class="bg-gray">
                                            <td width="" colspan="6"><b>Recette taxe de consommation</b></td>
                                        </tr>
                                        <tr>
                                            <td width="" rowspan="3" style="vertical-align: middle;">3</td>
                                            <td width="" rowspan="3" style="vertical-align: middle;"><?= gmdate('d-m-Y'); ?></td>
                                            <td width="">Prime de mobilisation (10%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["TCS"]["PRM"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK2']['TCS']['CDF']) ? $comptes['DGRK2']['TCS']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Retro services d'assiette (5%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["TCS"]["RSA"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK3']['TCS']['CDF']) ? $comptes['DGRK3']['TCS']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                        <tr>
                                            <td width="">Tresor urbain (85%)</td>
                                            <td width=""><?= "CDF ". number_format($payment_affectation["TCS"]["TUB"],2,","," "); ?></td>
                                            <td width=""><?= $compte_pm = isset($comptes['DGRK6']['TCS']['CDF']) ? $comptes['DGRK6']['TCS']['CDF'] : '00000000000000000000000';  ?></td>
                                        </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div  class="box-footer clearfix col-md-12">
                <?php if(empty($affectation)){ ?>
                <div id="createPaiement" class="col-md-12 no-padding">
                    <button type="submit" id="confirm"  name="submit" class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer l'affectation<span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
                <?php }else{ ?>
                <div id="createPaiement" class="col-md-12 no-padding">
                    <button type="submit" id="confirm"  name="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Proc&eacute;der à la validation<span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
                <?php } ?>
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
    <?php else: ?>
        <?php $this->chtml->box_body_opening('', false);?>
        <div class="col-md-12 no-padding">
            <?php if(!empty($affectation)): ?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin table-striped table-bordered">
                                <thead class='bg-aqua-active'>
                                    <tr>
                                        <th width="">#</th>
                                        <th width="">Date</th>
                                        <th width="">B&eacute;n&eacute;ficiaire</th>
                                        <th width="" class="center">Nombre de paiements</th>
                                        <th width="">Montant</th>
                                        <th width="" class="center">Initiateur</th>
                                        <th width="" class="center">Statut</th>
                                        <th width="" style="text-align:center;"><i class="fa fa-fw fa-list f15"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i =1; 
                                        foreach($affectation as $row): 
                                        $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                                    ?>
                                        <tr  id="line<?php echo $row->Id_0;?>">
                                            <td width=""><?php echo $i;?></td>
                                            <td width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                                            <td width=""><?php echo "DGRK" ?></td>
                                            <td width="" class="center"><?php echo $row->Nombrepaiement_8;?></td>
                                            <td width=""><?php echo "CDF ".$row->Montant_7; ?></td>
                                            <td width="" class="center"><?php echo $operateur; ?></td>
                                            <td class="center">
                                                <span class="badge <?php echo $statusColor[$row->Status_2]?>">
                                                <?php echo $status[$row->Status_2]; ?>
                                                </span>
                                            </td>
                                            <td class="center">
                                                <a style="cursor: pointer" onclick="view('<?php echo $row->Id_0; ?>')"> 
                                                    <i class="fa fa-fw fa-list text-green f15"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                    <?php $i++; endforeach; ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Aucun paiement trouv&eacute; !</b></h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
        <?php $this->chtml->box_body_closing(); ?>
    <?php endif; ?>
</div>

<script type="text/javascript">

$("#confirm").click(function(){
       
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/confirm_affectation'); ?>/';
        
        $.get(url ,function(data, status){
            $("#loader").html('');
            $('#container').html(data);
        });
});

function edit(type)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/details'); ?>/'+ type;
        
        $.get(url ,function(data, status){
            $("#loader").html('');
            $('#container').html(data); 
        });
}

function view(id)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/dgrk/display/confirm_affectation'); ?>/'+id;
        
        $.get(url ,function(data, status){
            $("#loader").html('');
            $('#container').html(data); 
        });
}



</script>



