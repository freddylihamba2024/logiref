<?php 
$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");

$lien_details = json_decode($encaissement->Reservation_34, true);

?>

<?php $userid = $this->session->userdata("user_id");  $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid'];?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="message"></div>
    <?php $this->chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                
                <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />
                
                <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />
                
                <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
                <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
                
                <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                
                <div class="col-md-12 no-padding">
                    <div class="col-md-12">
                        <br/><br/>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Bureau</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;clarant</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Agent_10; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;signation</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Designation_14.' / '.$encaissement->Nif_13; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Mode de paiement</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php  echo $modes[$encaissement->Mode_19]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Intitul&eacute; du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Num&eacute;ro du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Serie_7.' '.$bulletin->Number_8; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Ann&eacute;e du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Year_5; ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total(BL)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Montant_11.' CDF '; ?>
                            </div>
                        </div> 
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Commission</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Commission_23,2,","," ").' '.$encaissement->Devise_24;?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Total,2,","," ").' CDF'; ?>
                               <input name="total" value="<?=isset($encaissement->Total ) ? $encaissement->Total : ""; ?>" type="hidden" disabled="disabled" id="total">
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte client(&agrave; d&eacute;biter)</label>
                                <input name="bank_account" value="<?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>" type="hidden" disabled="disabled" id="bank_account">
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Devise du compte</label>
                                <input name="account_currency" value="<?=isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>" type="hidden" disabled="disabled" id="account_devise">
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?= isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b> <?= isset($encaissement->Taux_41 ) ? $encaissement->Taux_41 : ""; ?> CDF
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte Guichet Unique</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b>  <span class="<?php if($encaissement->CGU=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $encaissement->CGU; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 bTop">
                    <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                </div>
                <div class="col-md-12"><br></div>
                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead >
                            <tr class="bg-blue">
                                <th width="250px">Libell&eacute;</th>
                                <th width="100px">Op&eacute;ration</th>
                                <th width="200px">Source</th>
                                <th width="200px">D&eacute;stination</th>
                                <th class="right" width="">Montant</th>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php foreach($integrations as $row) :?>
                                <?php if($row->Operation_8 == 'C'):?>
                                <tr id="line<?php echo$row->Id_0;?>">
                                    <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                    <td  width="100px"><?php echo $row->Operation_8;?></td>
                                    <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                    <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                    <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                </tr>
                                <?php else:?>
                                <tr id="line<?php echo$row->Id_0;?>">
                                    <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                    <td  width="100px"><?php echo $row->Operation_8;?></td>
                                    <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                    <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                    <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                </tr>
                                <?php endif;?>
                            <?php endforeach;?>
                        </tbody>    
                    </table>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div id="createPaiement" class="col-md-6">
                    <button id="validate"  type="submit" disabled="disabled" id="validate" class="btn btn-primary  pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp; Valider &nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button id="save"  type="submit" class="btn  btn-success" disabled="disabled" id="save"><i class="fa fa-save"></i>&nbsp;&nbsp; Enregistrer &nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;

                    <a id="closePanel" type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                    <input type="hidden" name="action" value="" id="action">
                </div>
                <div class="col-md-6">
                    <div class="col-md-6">
                        <label class="pull-left">
                            <input type="checkbox" id="approbation_validate"  name="approbation" value="<?= 0 ?>"> Valider le paiement de nouveau
                        </label>
                    </div>
                    <div class="col-md-6">
                        <label class="pull-left">
                            <input type="checkbox" id="approbation_save"  name="approbation" value="<?= 0 ?>"> Enregistrer le paiement
                        </label>
                    </div>
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>

<script type="text/javascript"  charset="utf-8">


$("#validate").click(function(){
        $("#action").val('validate');
});

$("#save").click(function(){
        $("#action").val('save');
});

$("#approbation_validate").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#validate").prop("disabled", false);
                $("#approbation_save").prop("checked", false);
                $("#save").prop("disabled", true);
        }
        else
        {
                $("#validate").prop("disabled", true);
        }  
});

$("#approbation_save").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#save").prop("disabled", false);
                $("#approbation_validate").prop("checked", false);
                $("#validate").prop("disabled", true);
        }
        else
        {
                $("#save").prop("disabled", true);
        } 
});

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        var action = $('#action').val();
        
        if(action == 'save')
        {
                submiter(data);
        }
        else if(action == 'validate')
        {
                validate(data);
        }
        
});

$("#delete").click(function(){
    
        var id = '<?php echo $bulletin->Id_0; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/bulletin/save/delete_regul'); ?>/' +id;
                $.get(url, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled",true);
                        $('#print').prop("disabled",true);
                        $('#schema').prop("disabled",true);
                        $('#delete').prop("disabled",true);
                        $("#approbation_validate").attr("disabled", true);
                        $("#approbation_save").attr("disabled", true);

                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});


$("#closePanel").click(function(){
   
   $.get("<?php echo base_url($module.'/equalize/display/unequalized'); ?>", function(data, status){
        $("#loader").html('');
        $("#container").html(data);
    });
    
});
function submiter(data){
    
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        var message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        var url = '<?php echo base_url($module.'/equalize/save/save_bulletin'); ?>/<?php echo $encaissement->Sydonia_44; ?>';
        
        scrollUP();
        $('#confirm').prop("disabled",true);
        $("#loader").html('');
            
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E002")
                        {
                                $("#loader").html('');
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white">Desol&eacute; l\'enregistrement a &eacute;chou&eacute; veuillez reprendre!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                    var url = '<?php echo base_url($module.'/bulletin/display/preview'); ?>/<?php echo $encaissement->Sydonia_44; ?>';
                                    $.get(url, function(data, status){
                                        $('#loader').html(message);
                                        $("#message").html('');
                                        $("#pager").html(data);
                                    })
                        }
                },
                error:function(error)
                {
                    $("#message").html('');
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function validate(data)
{
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#validate").prop("disabled", true);
        var url = '<?php echo base_url($module.'/equalize/save/validate_bulletin'); ?>';
        scrollUP();

        $("#loader").html('');
        var message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        
                        if(result.response=='200')
                        {
                                var url = '<?php echo base_url($module.'/bulletin/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succ&egrave;s....<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(result.response === "E162")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E463")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E411")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white">L\'envoi des &eacute;critures &agrave; finacle fait avec succ&egrave;s mais il n\'y a eu aucun retour de finacle, veuillez trouver ce paiement dans le menu r&eacute;gularisation pour le r&eacute;gulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E3238")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "W0205")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E397")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "AD3")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E9999")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "ERR002")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "ERR003")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "P83")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white">Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}


function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>