<?php  //$recieptDate = explode("/",$bulletin->DateL_11); ?>
<div id="pager">
    <div class="col-md-12">
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $this->chtml->box_body_opening('', true);?>

        <div class="col-md-8 bRight">
            
                <div class="box-body">
                    <div class="col-md-12">
                        <h2 class=" f20 w-300 page-header">Traitement de bulletin  pr&eacute;pay&eacute;</h2>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label for="Service_16">Bureau (ou service)</label> 
                            <?php echo form_dropdown('Office',$services['DGDA'],'', 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="year">Banque</label> 
                            <?php echo form_input('Bank','1130', 'class="form-control bg-gray" id="year" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                           <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                            <?php echo form_input('Agent',set_value('Agent', isset($bulletin->Declarant_16) ? $bulletin->Declarant_16 : ""), 'class="form-control" id="declarant" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="Mode">Mode de paiement</label> 
                            <?php echo form_dropdown('Mode', $modes, "7", 'class="form-control" required="required" id="modeId"'); ?>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label for="bank_account" id="accountname">Compte de pr&eacute;paiement &agrave; d&eacute;biter</label>
                            <?php echo form_input('bank_account',$account, 'class="form-control" id="bank_account" placeholder="E.g: 0000100002000030000400005" required="required" '); ?>
                            <input type="hidden" name="account_name" value="" id="account_name">
                            <input type="hidden" name="internal_account" value="" id="internal_account">
							
                        </div>
                        <div id="accountc_panel" class="form-group">
                            <label for="bank_accountc" id="account_c_name">Compte &agrave; d&eacute;biter pour les frais bcc</label>
                            <?php echo form_input('bank_accountc','', 'class="form-control" id="bank_accountc" placeholder="E.g: 0000100002000030000400005" required="required"'); ?>
                            <input type="hidden" name="accountc_name" value="" id="accountc_name">
                            <input type="hidden" name="internal_accountc" value="" id="internal_accountc">
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="Devise_account">Devise de ce compte</label>
                            <?php echo form_dropdown('Devise_account', $devises, "CDF", 'class="form-control" id="account_devise" disabled="disabled"'); ?>
                            <input type="hidden" name="Devise_account" value="<?= $devises['CDF'] ?>" >
                        </div>
                        <div id="devisec_panel" class="form-group">
                            <label for="Devise_account">Devise de ce compte</label>
                            <?php echo form_dropdown('Devise_account_c', $devises, "CDF", 'class="form-control" id="Devise_account_c" required="required"'); ?>
                            <input type="hidden" name="Devise_account_c" value="<?= $devises['CDF'] ?>" >
                        </div>
                    </div>
                    
                    <div class="col-md-7">
                        </br><label>Paie le frais bcc&nbsp;<input type="checkbox" name="frais_bcc" value="<?= 1 ?>" id="frais_bcc" checked></label>
                    </div >
                </div>
                <div id="details" class="col-md-12"></div>
                <div class="box-footer clearfix">
                    <div class="col-md-12">
                        <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="save" class="btn btn-default" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Suivant&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="action" value="" id="action">
                        <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="account_reference" value="<?= $account_reference; ?>" >
                        <input type="hidden" name="prepaid_balance" id="prepaid_balance" value="" >
                        <input type="hidden" name="account_balance_fees" id="account_balance_fees" value="0" >
                        <input type="hidden" name="fees_amount" id="fees_amount" value="<?= $fees_amount ?>" >
                        <input type="hidden" name="prepaid_amount" id="prepaid_amount" value="<?= $total_amount ?>" >
                    </div>
                </div>
        </div>
        <div class="col-md-4 no-padding " id="treatment">

        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
                <br/>
                <div class="col-md-8 no-padding">
                    <label>Liste de bulletins</label><br/>
                </div>
                <div class="col-md-4 no-padding">
                    <label>&nbsp;&nbsp;Montant total du lot <b>:</b></label><span id="total_amount"></span> CDF
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead >
                        <tr class="bg-gray">
                            <th width="250px">Date</th>
                            <th width="100px">Num&eacute;ro imp&ocirc;t</th>
                            <th width="200px">Bulletin</th>
                            <th class="right" width="">Montant</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php foreach($prepayments as $row) :?>
                            <tr>
                                <td  width="250px"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));?></td>
                                <td  width="100px"><?php echo $row->Nif_15;?></td>
                                <td><?php echo $row->Serial_9.''.$row->Number_10; ?></td>
                                <td ><?php echo 'CDF'.' '.number_format($row->Amount_18,2,","," ");?></td>
                            </tr>
                        <?php endforeach;?>
                    </tbody>    
                </table>
                
            </div>
        </div>
        <?php $this->chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>
    </div>
    
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
 var lot = '<?php echo $lot; ?>';
 
 var frais_bcc = true;
 var mad = true;
 var madfbcc = true;
 
 var total = $("#prepaid_amount").val();
$("#total_amount").html(total);
 
 '<?php if($account != "" && $account.length == 14): ?>';
    get_accountname_internal();
 '<?php else:?>'
    get_accountname();
 '<?php endif; ?>'
 
$("#save").click(function(){
    
        $("#action").val('save');
});

$("#treat").click(function(){
    
        $("#action").val('traiter');
});

$("#frais_bcc").change(function(){
    
        if($(this).prop("checked") == true)
        {
                $("#bank_accountc").prop('required', true);
                $("#Devise_account_c").prop('required', true);
                
                frais_bcc = true;
        }
        else
        {
               $("#bank_accountc").prop('required', false);
               $("#Devise_account_c").prop('required', false);
               
               frais_bcc = false;
        }
    
});

$('.chosen-select').chosen({width: "100%"});
   
$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        if(action == 'traiter')
        {
            
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/prepayments/display/verification'); ?>/';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                        if(result === "E003")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E22" || result === "E13")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               
                        }
                        else if(result === "E11")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E000")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#loader').html('');
                                $("#save").removeClass('btn-default');
                                $("#save").addClass('btn-success');
                                $("#save").prop('disabled', false);
                                $('#treatment').html(result);
                        }
                       
                    },
                    error:function(error)
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }
        else if(action == 'save')
        {
                if(mad == false)
                {
                        var verify_prepaid = verify_prepaid_account_balance();

                        var verify_frais_bcc = verify_account_balance_fees();

                        if(verify_prepaid)
                        {
                                if(frais_bcc)
                                {
                                        if(verify_frais_bcc)
                                        {
                                                next_step(data);
                                        }
                                        else
                                        {
                                                $('#loader').html('<div class="alert alert-danger text-white">Le solde du compte courant du client est insuffisant pour le pr&eacute;levement des frais BCC.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        }
                                }
                                else
                                {
                                        next_step(data);
                                }
                        }
                        else
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Le solde du compte de pr&eacute;paiement n\'a pas assez de provision pour payer les bulletins de pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                }
                else
                {
                        //alert(madfbcc);
                        if(madfbcc)
                        {
                                next_step(data);
                        }
                        else
                        {
                                if(verify_frais_bcc)
                                {
                                        if(verify_frais_bcc)
                                        {
                                                next_step(data);
                                        }
                                        else
                                        {
                                                $('#loader').html('<div class="alert alert-danger text-white">Le solde du compte courant du client est insuffisant pour le pr&eacute;levement des frais BCC.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        }
                                }
                        }
                }
                    
        }
});

$("#balance").css('background-color','#00cc33');

$("#close").click(function(){
        location.reload(true);
});

$("#bank_account").change(function(){
   var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            $('#internal_account').val(compte);
            $('#internal_account').prop('disabled', false);
            get_accountname_internal();
            
    }
    else
    {
            $('#internal_account').prop('disabled', true);
            get_accountname();
            
    }
});

$("#Devise_account").change(function(){
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    }
});

$("#bank_accountc").change(function(){
        var comptec = $("#bank_accountc").val();
        if(comptec.length == 14)
        {
                $('#internal_accountc').val(comptec);
                $('#internal_accountc').prop('disabled', false);
                get_internal_account_fees_name();
        }
        else
        {
                $('#internal_accountc').prop('disabled', true);
                get_account_fees_name();
        }

});

$("#Devise_account_c").change(function(){
        var comptec = $("#bank_account").val();
        if(comptec.length == 14)
        {
                get_internal_account_fees_name();
        }
        else
        {
                get_account_fees_name(); 
        }
});

function next_step(data)
{
       $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
       $('#envoyer').prop("disabled", true);
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');
       var url = '<?php echo base_url($module.'/prepayments/display/edit/'); ?>';
       $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                        $('#loader').html('');
                        $("#pager").html(result);
               },
                error:function(error)
                {
                    $("#step-2").removeClass('bg-green-active');
                    $("#step-2").addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray');
                    $("#step-3").addClass('bg-green-active');
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
       });
}


function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        
        mad = false;
        
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $('account_devise').val('');
                                }
                                else
                                {
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        
                                        $("#account_currency").val(reponse.devise);
                                        $("#prepaid_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function get_accountname_internal()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        madfbcc = true;
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}
function get_account_fees_name()
{
        var chtml = $("#account_c_name").html();
        var compte = $('#bank_accountc').val();
        var devise = $('#Devise_account_c option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#account_c_name").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#account_c_name").css('color', 'orange');
                                        $("#account_c_name").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#account_c_name").css('color', 'orange');
                                        $("#account_c_name").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Probl&egrave;me de connexion &agrave; finacle');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Devise du compte incorrecte');
                                        $('#Devise_account_c').val('');
                                }
                                else
                                {
                                        $("#account_c_name").css('color', 'green');
                                        $("#account_c_name").html(reponse.account);
                                        $("#accountc_name").val(reponse.account);
                                        
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance_fees").val(reponse.balance);
                                        
                                        
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#account_c_name").html(chtml);
        } 
}

function get_internal_account_fees_name()
{
        var chtml = $("#account_c_name").html();
        var compte = $('#bank_accountc').val();
        var devise = $('#Devise_account_c option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#account_c_name").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#account_c_name").css('color', 'orange');
                                        $("#account_c_name").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#account_c_name").css('color', 'orange');
                                        $("#account_c_name").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Probl&egrave;me de connexion &agrave; finacle');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#account_c_name").css('color', 'red');
                                        $("#account_c_name").html('Devise du compte incorrecte');
                                        $('#Devise_account_c').val('');
                                }
                                else
                                {
                                        $("#account_c_name").css('color', 'green');
                                        $("#account_c_name").html(reponse.account);
                                        $("#accountc_name").val(reponse.account);
                                        
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance_fees").val(reponse.balance);
                                        
                                        
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#account_c_name").html(chtml);
        } 
}


function verify_prepaid_account_balance()
{
        var prepaid_balance = parseFloat($("#prepaid_balance").val().split(' ').join('').split(',').join('.'));
        var prepaid_amount = parseFloat($("#prepaid_amount").val().split(' ').join('').split(',').join('.'));
        
        if(prepaid_amount > prepaid_balance)
        {
                return false;
        }
        else
        {
                return true;
        }
}

function verify_account_balance_fees()
{
        var account_balance_fees = parseFloat($("#account_balance_fees").val().split(' ').join('').split(',').join('.'));
        var fees_amount = parseFloat($("#fees_amount").val().split(' ').join('').split(',').join('.'));
        
        
        if(fees_amount > account_balance_fees)
        {
                return false;
        }
        else
        {
                return true;
        }
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>
