<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

?>



<br/>
<div class="col-md-7">
    <input type="hidden" name="concat" value="<?= $compte_guichet ?>" >
    <div class="form-group">
        <label for="company">Compte guichet unique</label> 
        <?php echo form_input('Compte_guichet',set_value('Compte_guichet', $compte_guichet), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Compte_guichet" value="<?= $compte_guichet ?>" >
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
        <input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="Commission">Commission</label> 
        <?php echo form_input('Commission',set_value('Commission', $commission), 'class="form-control" id="coms" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Commission" value="<?= $commission ?>" >
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_commission', $devises, isset($commission_devise) ? $commission_devise : "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
        <input type="hidden" name="Devise_commission" value="CDF" >
    </div>
</div>
<div class="col-md-7">
    <?php if(isset($frais_bcc)): ?>
    <div class="form-group">
        <label for="company">Montant total + frais bcc</label> 
        <?php echo form_input('Total_amount',set_value('Total_amount', $total_amount), 'class="form-control" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Total_amount" value="<?= $total_amount ?>" >
    </div>
    <?php else: ?>
        <label for="company">Montant total</label> 
        <?php echo form_input('Total_amount',set_value('Total_amount', $total_amount), 'class="form-control" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Total_amount" value="<?= $total_amount ?>" >
    <?php endif; ?>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_amount', $devises, "CDF", 'class="form-control"  required="required" disabled="disabled" '); ?>
        <input type="hidden" name="Devise_amount" value="<?= $devises['CDF'] ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="reference">R&eacute;f&eacute;rence</label>
        <?php echo form_input('reference',set_value('reference', $referenceOP), 'class="form-control" id="reference"  "'.$disabled.'"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="company">Taux</label> 
        <?php echo form_input('Taux',set_value('Taux', set_value('Taux', isset($bank_rate_applied) ? $bank_rate_applied : $taux)), 'class="form-control" disabled="disabled"'); ?>
        <input type="hidden" name="Taux" value="<?= isset($bank_rate_applied) ? $bank_rate_applied : $taux ?>" >
    </div>
</div>
<script type="text/javascript">
   
 
    
</script>

