<?php 

$lien_details = json_decode($batch->Reservation_27, true);

$button_treat = "";

if($account_type == "current_account")
{
        $releaseLien = "";
        $debit = "hidden";
}
else
{
        $releaseLien = "hidden";
        $debit = "";
}

?>
<div class="col-md-12">
            
    <?php if($integrations[0]->Status_2 == 5 && $_SESSION['Logiref_role']==3): ?>
        <div id="loader2"><div class="alert alert-danger text-white"> Il y avait eu un time out pendant la validation de ce paiement, veuillez vous connecter dans Finacle pour v&eacute;rifier si ce paiement est bien comptabilis&eacute; ou pas. Si le paiement est d&eacute;j&agrave; comptabilis&eacute;, cochez la case [proc&eacute;c&eacute;der &agrave; l'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
    <?php endif; ?>

    <?php if($batch->Status_2 == 1 && $_SESSION['Logiref_role']!=3 ): ?>
        <div id="loader2"><div class="alert alert-info text-white">Lot de bulletins en attente validation, veuillez contacter le validateur pour la suite du processus.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
    <?php endif; ?>
    
    <?php $this->chtml->box_body_opening('', false); ?>
    <?php  echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
        <div class="col-md-12">
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                   <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <label for="site">Bureau</label>
                            <?php echo form_dropdown('Office', $services['DGDA'], $office, 'required class="form-control chosen-select"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="Agent">Declarant</label>
                            <?php echo form_input('Agent', set_value('Agent', $agent), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="Nif">Num&eacute;ro imp&ocirc;t</label>
                            <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="project">Designation</label>
                            <?php echo form_input('designation', set_value('designation', $designation), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="account_name">Intitul&eacute; du compte</label>
                            <?php echo form_input('account_name', set_value('account_name', $account_name), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12">
                            <label for="account">Compte &agrave; d&eacute;biter</label>
                            <?php echo form_input('account', set_value('account', $account), 'id="account" class="form-control" required '); ?>
                        </div>
                    </div>
                    <div class="col-md-6 bLeft">
                        <div class="input-group col-md-12 no-padding">
                            <label for="site">Mode de paiement</label>
                            <?php echo form_dropdown('mode', $modes, $mode, 'required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="total_amount">Montant total du lot</label>
                            <?php echo form_input('total_amount', set_value('total_amount', number_format($total,2,","," ")), 'id="total_amount" required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="coms">Commission totale du lot</label>
                            <?php echo form_input('Commission', set_value('Commission', number_format($commission,2,","," ")), 'id="coms" required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <?php $tva = $commission * 0.16;?>
                            <label for="tva">TVA</label>
                            <?php echo form_input('tva', set_value('tva', number_format($tva,2,","," ")), 'id="tva" class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="total_topaid">Total &agrave; payer</label>
                            <?php echo form_input('total_topaid', set_value('total_topaid', number_format($total_to_paid,2,","," ")), 'id="total_topaid" class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="taux">Taux appliqu&eacute;</label>
                            <?php echo form_input('taux', set_value('taux', number_format($taux,2,","," ")), 'class="form-control"'); ?>
                        </div>
                    </div>
                </div>    
                <div id="footpage" class="box-footer clearfix"></div>
            </div>
            <div class="box-body box-solid no-padding">
                <div class="box-body">
                    <input type="hidden" name="Bank" value ="<?php echo $bank; ?>"/>
                    <input type="hidden" name="refOp" id="refOp" value ="<?php echo $refOp; ?>" />
                    <input type="hidden" name="devise_commision" value ="<?php echo 'CDF'; ?>"/>
                    <input type="hidden" name="cdevise" id="cdevise" value ="<?php echo $cdevise; ?>"/>
                    <input type="hidden" name="batch_id" id="batch_id" value ="<?= isset($batch->Id_0) ? $batch->Id_0 : "" ?>"/>
                    <input type="hidden" name="batch_reference" id="batch_reference" value ="<?= isset($batch->Lot_14) ? $batch->Lot_14 : "" ?>"/>
					<input type="hidden" name="fraisbcc" value="1" id="fraisbcc">
					
					
                    <div class="table-responsive">
                        <table class="table no-margin table-striped table-bordered">
                            <thead class='bg-blue'>
                                <tr>
                                    <th width="10px">#</th>
                                    <th width="80px">Ann&eacute;e</th>
                                    <th width="80px">Bulletin</th>
                                    <th width="50px">Devise</th>
                                    <th width="200px">Montant</th>
                                    <th class="center">Retour de SYDONIA</th>
                                    <th align="center" width="90px">V&eacute;rification</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1;  foreach($bulletins as $bl){ ?>
                                    <tr id="line<?php echo $i?>">
                                        <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                        <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year;?>" name="years[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->number; ?>"  name="serials[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td align="center"><span class="form-control">CDF</span></td>
                                        <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount,2,","," ");?>" name="amounts[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Verifiez l&apos;autheticit&eacute; du bulletin</span></td>
                                        <td align="center" id='btn<?php echo $i; ?>'>
                                           <span class="fa fa-fw text-gray fa-question f20"> </span>
                                        </td>
                                    </tr>
                                <?php $i++;  } ?>
                            </tbody>
                        </table>
                        <div class="col-md-12 no-padding <?php if($integrations[0]->Status_2 !="5" || $_SESSION['Logiref_role']!=3) echo "hidden"; ?>"  id="approbation">
                                <br/>
                                <div class="col-md-5 no-padding">
                                    <label class="pull-left">
                                        <input type="checkbox" id="approbation_debit"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Valider la transaction &agrave; nouveau</span>
                                    </label>
                                </div>
                                <div class="col-md-7 no-padding">
                                    <label class="pull-left">
                                        <input type="checkbox" id="approbation_emarge"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Proc&eacute;c&eacute;der à l'&eacute;margement</span>
                                    </label>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button type="button" id="treat" class="btn btn-primary" <?php echo $releaseLien; ?>" <?php if($_SESSION['Logiref_role']==4) echo "disabled"; ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    
                    
                    <button type="submit" id="releaseLien" class="btn btn-primary <?php echo $releaseLien; ?>" <?php if($_SESSION['Logiref_role']==4) echo "disabled"; ?> disabled="disabled" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Valider &nbsp;&nbsp;</button>&nbsp;&nbsp;
                    
                    <button type="submit" id="debit" class="btn btn-primary <?php echo $debit; ?>" <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?> disabled="disabled" ><i class="fa fa-save"></i>&nbsp;&nbsp;Valider la transaction&nbsp;&nbsp;</button>&nbsp;
                    
                    <button type="submit" id="confirm" class="btn btn-success" <?php if($integrations[0]->Status_2 != 2 || $_SESSION['Logiref_role']==4) echo "disabled" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;Emargement&nbsp;&nbsp;</button>&nbsp;
                    <button type="button" id="recover" class="btn btn-primary hidden" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;cup&eacute;rer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="delete" class="btn btn-danger hidden"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="delete2" class="btn btn-danger hidden"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;

                    <input type="hidden" name="action" value="" id="action">
                    <input type="hidden" name="bulletin_id" value="" disabled="disabled" id="bulletin_id">
                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>  
                </div>
            </div>
        </div>
        <?php echo form_close(); ?> 
    <?php $this->chtml->box_body_closing(); ?> 
</div>

<div class="col-md-12">
   
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
$('.chosen-select').chosen({width: "100%"});


$(document).ready(function(){
    var compte1 = $('#account').val();
    var regie1 = 'DGDA';
    var url1 = '<?php echo base_url($module.'/accounts/data/get_account_tarification'); ?>';

    $.ajax({
            type        : 'POST', 
            url         : url1, 
            data        : { compte : compte1, regie : regie1}, 
            dataType    : 'json', 
            encode      : true,
            success: function(reponse)
            {
                    if(reponse.commission >= 0)
                    {
							//alert(reponse.fraisbcc);
                            $("#fraisbcc").val(reponse.fraisbcc);
                            $("#tva").val(reponse.tva);
                    }
            },
            error:function(error)
            {
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Une erreur est survenue...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }   
    });   
});

$("#extractform").submit(function(event){
    event.preventDefault();
    var data = $(this).serialize();
});

$("#confirm").click(function(){
    
        var data = $("#extractform").serialize();
        next_step(data);
    
});

$("#treat").click(function(){
    
        var data = $("#extractform").serialize();
        batch_tratement(data);
    
});

$("#recover").click(function(){
    
        var data = $("#extractform").serialize();
        batch_recover(data);
    
});

$("#releaseLien").click(function(){
    
        var data = $("#extractform").serialize();
        cancel_reservation(data);
});

$("#debit").click(function(){
    
        var data = $("#extractform").serialize();
        first_transaction_batch(data);
});

$("#buttonCloseModal").click(function(){
        location.reload(true);
});

$("#approbation_debit").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#debit").removeClass('hidden');
                $("#releaseLien").addClass('hidden');
                $("#debit").prop("disabled", false);
                $("#approbation_emarge").prop("checked", false);
                $("#confirm").prop("disabled", true);
        }
        else
        {
                $("#debit").prop("disabled", true);
        }  
});

$("#approbation_emarge").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#confirm").prop("disabled", false);
                $("#approbation_debit").prop("checked", false);
                $("#debit").prop("disabled", true);
        }
        else
        {
                $("#confirm").prop("disabled", true);
        } 
});

$("#delete").click(function(){
    
        var batch_id = $('#batch_id').val();
        var batch_ref = $('#batch_reference').val();
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/bulletin/save/delete_batch'); ?>/' +batch_id+ '/' +batch_ref;
                $.get(url, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#confirm').prop("disabled",true);
                        $('#debit').prop("disabled",true);
                        $('#releaseLien').prop("disabled",true);
                        $("#releaseLien").addClass('hidden');
                        $('#delete').prop("disabled",true);
                        $('#treat').prop("disabled", true);
                        $("#approbation_debit").prop("disabled", true);
                        $("#approbation_emarge").prop("disabled", true);
                        $("#buttonCloseModal").prop("disabled", false);

                        cancel_reservation_btndelete();
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});

$("#delete2").click(function(){
    
        var batch_id = $('#batch_id').val();
        var batch_ref = $('#batch_reference').val();
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/bulletin/save/delete_batch'); ?>/' +batch_id+ '/' +batch_ref;
                $.get(url, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#confirm').prop("disabled",true);
                        $('#debit').prop("disabled",true);
                        $('#releaseLien').prop("disabled",true);
                        $("#releaseLien").addClass('hidden');
                        $('#delete2').prop("disabled",true);
                        $('#treat').prop("disabled", true);
                        $("#approbation_debit").prop("disabled", true);
                        $("#approbation_emarge").prop("disabled", true);
                        $("#buttonCloseModal").prop("disabled", false);
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});


function batch_tratement(data)
{
        $('#treat').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#treat').html();
        $('#treat').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        scrollUP();
        
        var data = data;
        var url = '<?php echo base_url($module.'/bulletin/display/batch_verification'); ?>/';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result)
                    {
                            $('#loader').html(result); 
                            $('#treat').prop("disabled", false);
                            //$('#delete').prop("disabled",false);
                            $("#delete").removeClass('hidden');
                            $('#treat').prop("buttonCloseModal", false);
                            $('#treat').html(button);
                            $('#loader').html('');
                            var result = JSON.parse(result);
                            if(result.response === "OK")
                            {
                                    // Mise a jour du tableau avec le retour de SYDONIA
                                    var bulletins = result.bulletins;
                                    var t = 0;
                                    for(i = 0; i < bulletins.length; i++)
                                    {
                                            t = i + 1;
                                            
                                            if(bulletins[i] === "OK")
                                            {
                                                    $("#btn"+t).html('<span class="fa fa-fw text-green fa-check f20"> </span>');
                                                    $("#sydonia_result"+t).html('<div class="alert alert-success text-white">Bulletin valide!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#recover").addClass('hidden');
                                            }
                                            else if(bulletins[i] === "E13")
                                            {
                                                    $("#btn"+t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Server execption!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(bulletins[i] === "E34")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-danger text-white">Bulletin d&eacute;j&agrave; pay&eacute;!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                                    
                                                    $("#recover").removeClass('hidden');
                                                    $('#treat').prop("disabled", true);
                                                    $('#releaseLien').prop("disabled", true);
                                                    $('#debit').prop("disabled", true);
                                            }
                                            else if(bulletins[i] === "E22")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Bulletin non reconnu!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                            }
                                            else if(bulletins[i] === "E11")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Montant du bulletin est incorrect!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                            }
                                    }
                                    
                                    
                                    // Teste si la balance est suffisante et que tous les bulletins sont valides
                                    if(result.balance === "OK" && result.error === false)
                                    {
                                        // Activation de la reservation des fonds
                                        $("#releaseLien").prop('disabled', false);
                                        $("#debit").prop('disabled', false);
                                        
                                        // Mise a jour du montant total a payer au cas ou la commission serait modifiee
                                        $("#total_amount").val(result.total_amount);
                                        
                                        // Mise a jour du montant total du lot des bulletins au cas ou le montant de bulletin serait modifiee
                                        $("#total_topaid").val(result.total);
                                        
                                        // mise à jour de l'affichage de la TVA
                                        $("#tva").val(result.tva);
                                        
                                        scrollUP();
                                        
                                    }
                                    else if(result.balance === "KO")
                                    {
                                            scrollUP();
                                            $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(result.balance === "E411")
                                    {
                                            scrollUP();
                                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                            }
                            else if(result.response === "E000")
                            {
                                    scrollUP();
                                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E404")
                            {
                                    scrollUP();
                                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E003")
                            {
                                    scrollUP();
                                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: Fatal error...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E18")
                            {
                                    scrollUP();
                                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            
                    },
                    error:function(error)
                    {
                            scrollUP();
                            $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
}

function first_transaction_batch()
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var batch_id = $('#batch_id').val();

    var url = '<?php echo base_url($module.'/bulletin/display/first_transaction_batch'); ?>';
    
    $("#debit").prop('disabled', true);
    $('#treat').prop("disabled", true);
    $('#releaseLien').prop("disabled", true);

    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : {batch_id : batch_id}, 
                dataType    : 'html',  
                encode          : true,
                success: function(result)
                {
                        if(result === "E162")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E463")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E3238")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "W0205")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E397")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "AD3")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E9999")
                        {
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "ERR002")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "ERR003")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "P83")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "200")
                        {
                                $("#loader").html('');
                                $("#loader2").html('');
                                $('#confirm').prop("disabled", false);
                                $('#debit').prop("disabled", true);
                                $('#treat').prop("disabled", true);
                                $('#releaseLien').prop("disabled", true);
                                
                                $('#loader').html('<div class="alert alert-info text-white"> La validation de la transaction a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger le bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {   
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error)
                {
                    $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }  
    });
}

function cancel_reservation()
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        scrollUP();
        var compte = $('#account').val();
        var devise = $('#cdevise').val();
        var batch_id = $('#batch_id').val();
        
        $("#releaseLien").prop('disabled', true);
        
        var url = '<?php echo base_url($module.'/accounts/data/cancel_batch_reservation'); ?>';

        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, batch_id : batch_id}, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {
                            if(response == '200')
                            {
                                    first_transaction_batch();
                            }
                            else
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#releaseLien").prop('disabled', false);
                            }
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}

function cancel_reservation_btndelete()
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        scrollUP();
        var compte = $('#account').val();
        var devise = $('#cdevise').val();
        var batch_id = $('#batch_id').val();
        
        $("#releaseLien").prop('disabled', true);
        
        var url = "<?php echo base_url($module.'/accounts/data/cancel_batch_reservation'); ?>";

        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, batch_id : batch_id}, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {
                            if(response == '200')
                            {
                                    //$('#loader').html('<div class="alert alert-danger text-white">La reservation faite sur le compte est annul&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#loader').html('<div class="alert alert-success text-white">Paiements supprim&eacute;s avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#releaseLien").prop('disabled', false);
                            }
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}

function next_step(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#envoyer').prop("disabled", true);
        
        $("#delete").addClass('hidden');
        $("#delete2").removeClass("hidden");
        
        //$("#recover").addClass('hidden');
        
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        var url = '<?php echo base_url($module.'/bulletin/display/batch_confirmation'); ?>';
        $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                       $('#envoyer').prop("disabled", false);
                       $('#envoyer').html(button);
                       $('#loader').html('');
                       if(result === "E34")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E22")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E21")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E18")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E4")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E11")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E13")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E002")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                       else if(result === "E003")
                       {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                       }
                        else if(result === "E000")
                        {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $('#extourne').removeClass('hidden');
                               $('#reserve').addClass('hidden');
                        }
                        else if(result === "E404")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA n&pos;est pas disponible, r&eacute:essayez plutard!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#extourne').removeClass('hidden');
                                $('#reserve').addClass('hidden');
                        }
                        else if(result === "E444")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA prends du temps pour repondre, veuillez reessayer!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#envoyer').prop("disabled", true);
                                $('#treat').prop("disabled", true);
                                $('#recover').removeClass('hidden');
                                $('#envoyer').addClass('hidden');
                                $('#reserve').prop("disabled", true);
                                $("#extourne").prop("disabled", false);
                        }
                        else if(result === "E501")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#envoyer').prop("disabled", true);
                                $('#extourne').removeClass('hidden');
                                $('#reserve').addClass('hidden');
                        }
                        else 
                        {
                             $('#envoyer').prop("disabled", false);
                             $('#envoyer').html(button);
                             $("#step-2").removeClass('bg-green-active');
                             $("#step-2").addClass('bg-gray');
                             $("#step-3").removeClass('bg-gray');
                             $("#step-3").addClass('bg-green-active');
                             $("#pager").html(result);
                        }
               },
               error:function(error){
                   scrollUP();
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                    $('#loader').html('<div class="alert alert-warning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               }
       });
}

function batch_recover(data)
{
        $('#recover').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        $("#envoyer").addClass('hidden');
        var button = $('#recover').html();
        scrollUP();
        $('#recover').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bulletin/display/batch_recover'); ?>/';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result)
                    {
                            $('#loader').html('');
                            if(result === "E000")
                            {
                                    scrollUP();
                                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E404")
                            {
                                    scrollUP();
                                    $('#recover').prop("disabled", false);
                                    $('#recover').html(button);
                                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E002")
                            {
                                    scrollUP();
                                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $("#pager").html(result);
                            }
                    },
                    error:function(error)
                    {
                            scrollUP();
                            $('#recover').prop("disabled", false);
                            $('#recover').html(button);
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>




