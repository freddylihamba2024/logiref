<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(isset($tax_info) && $tax_info !="")
{
        #when the customer is exempted from tax
        $disabled_1 = "disabled";
        $disabled_2 = "";
}
else 
{
        #when the customer is not exempted from tax
        $disabled_1 = "";
        $disabled_2 = "disabled";
}

 if($total_amount > 0) $total_amount = number_format($total_amount,2,","," ");
 
 if($commission > 0) $commission = number_format($commission,2,","," ");

?>



<br/>
<div class="col-md-12">
    <div class="form-group">
        <label for="designation">Designation</label> 
        <?php echo form_input('designation',set_value('designation', $designation), 'class="form-control" id="designation" required = "required"'); ?>
    </div>
</div>
<div class="col-md-7">
    <input type="hidden" name="concat" value="<?= $compte_guichet ?>" >
    <div class="form-group">
        <label for="company">Compte guichet unique</label> 
        <?php echo form_input('Compte_guichet',set_value('Compte_guichet', $compte_guichet), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Compte_guichet" value="<?= $compte_guichet ?>" >
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
        <input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="company">Commission</label> 
        <?php echo form_input('Commission',set_value('Commission', $commission), 'class="form-control" id="coms" required = "required" '.$disabled_1.''); ?>
        <input type="hidden" name="Commission" value="<?= $commission ?>" <?= $disabled_2 ?> >
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_commission', $devises, isset($commission_devise) ? $commission_devise : "CDF", 'class="form-control"  required="required" id="recetteDevise" '); ?>
        
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="company">Montant total</label> 
        <?php echo form_input('Total_amount',set_value('Total_amount', $total_amount), 'class="form-control" id="total" required = "required"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_amount', $devises, "CDF", 'class="form-control"  required="required" '); ?>
        <input type="hidden" name="Devise_amount" value="<?= $devises['CDF'] ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="reference">R&eacute;f&eacute;rence de de l&apos;OP</label>
        <?php echo form_input('reference',set_value('reference', $referenceOP), 'class="form-control" id="reference"  "'.$disabled.'"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="company">Taux</label> 
        <?php echo form_input('Taux',set_value('Taux', set_value('Taux', isset($bank_rate_applied) ? $bank_rate_applied : $taux)), 'class="form-control" '); ?>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label for="company">Balance du compte</label> 
        <?php echo form_input('balance',set_value('balance', isset($account_balance) ? $account_balance : ""), 'class="form-control" id="balance" disabled="disabled"'); ?>
    </div>
</div>
<script type="text/javascript">
   
'<?php if($balance =="ok"){ ?>'

$("#balance").css('background-color','#00cc33');
$("#balance").css('color','white');
$("#createLien").prop('disabled', false);

'<?php }else{ ?>'

$("#balance").css('background-color','red');
$("#balance").css('color','white');
$("#createLien").prop('disabled', true);

'<?php } ?>'
    
</script>