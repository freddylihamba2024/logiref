    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div class="col-md-12">
            <h1>Bulletin de liquidation</h1>
            <p class="page-header">Traitement des bulletins de liquidation</p>     
        </div>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound bg-green-active f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rifier un Bulletin<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound bg-gray f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmer ce paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound bg-gray f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Imprimer la preuve<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/></div>
        <div id="pager" class="col-md-12">
            <div id="loader"></div>
            <?php $this->chtml->box_body_opening('', true);?>
            <div class="col-md-3 center padding-20">
                <div class="col-md-12 center">
                    <p class="page-header">
                        <br/><br/>Remplissez les champs recquis pour v&eacute;rifier la validit&eacute; d'un bulletin de liquidation
                    </p> 
                </div>
            </div>
            <div class="col-md-9 bLeft">
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
                <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
                    <div class="box-body">
                        <div class="col-md-12">
                            <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Service_16">Bureau (ou service)</label> 
                                <?php echo form_dropdown('Office',$services,'501B', 'class="form-control" id="Service_16" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="year">Ann&eacute;e</label> 
                                <?php echo form_input('Year','2019', 'class="form-control" id="year" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="year">Banque</label> 
                                <?php echo form_input('Bank','1150', 'class="form-control bg-gray" id="year" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                               <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                <?php echo form_input('Agent','0000', 'class="form-control" id="declarant" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="assessment_serial">S&eacute;rie</label>
                                <?php echo form_input('Series','L', 'class="form-control" id="assessment_serial" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="assessment_number">Num&eacute;ro de s&eacute;rie</label>
                                <?php echo form_input('Number','', 'class="form-control" id="assessment_number" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                <?php echo form_input('Nif','', 'class="form-control" id="company" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Montant_11">Montant &agrave; payer (CDF)</label>
                                <?php echo form_input('Amount','', 'class="form-control" id="Montant_11" required = "required"'); ?>
                            </div>
                        </div>
                    </div>
                    <div id="details" class="col-md-12"></div>
                    <div class="box-footer clearfix">
                        <div class="col-md-12">
                            <button type="submit" id='envoyer' class="btn btn-primary pull-left" ><i class="fa fa-save"></i>&nbsp;&nbsp;Continuer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
            <?php $this->chtml->box_body_closing(); ?> 
        </div>
    </div>
    <div class="col-md-1"></div>
<script type="text/javascript">
$("#mainform").submit(function(event){
     event.preventDefault();
     var data = $(this).serialize();
     next_step(data);

});
   
 function next_step(data)
 {
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#envoyer').prop("disabled", true);
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        var url = '<?php echo base_url($module.'/bank/display/checkbl'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        $('#envoyer').prop("disabled", false);
                        $('#envoyer').html(button);
                        $('#loader').html('');
                        if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation a deja ete paye!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E22")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E11")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E002")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E005")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $("#pager").html(result);
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');
                        }
                },
                error:function(error){
                    alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
        });
 }
</script>