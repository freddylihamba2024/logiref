<br/><br/><br/>
<div class="col-md-12">
    <div class="form-group">
        <label for="client">Desigantion</label> 
        <?php echo form_input('client',set_value('client', $designation_client), 'class="form-control" id="client" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="client" value="<?= $designation_client ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="company">Cheque guichet unique</label> 
        <?php echo form_input('Compte_guichet',set_value('Compte_guichet', $compte_guichet), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
        <input type="hidden" name="Compte_guichet" value="<?= $compte_guichet ?>" >
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
        <input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="company">Commission</label> 
        <?php echo form_input('Commission',set_value('Commission', $commission), 'class="form-control" id="coms" required = "required"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_commission', $devises, isset($commission_devise) ? $commission_devise : "CDF", 'class="form-control"  required="required" id="recetteDevise" '); ?>
        
    </div>
</div>
<div class="col-md-7">
    <div class="form-group">
        <label for="company">Montant total</label> 
        <?php echo form_input('Total_amount',set_value('Total_amount', $total_amount), 'class="form-control" required = "required"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="devise">Devise</label>
        <?php echo form_dropdown('Devise_amount', $devises, "CDF", 'class="form-control"  required="required" '); ?>
        <input type="hidden" name="Devise_amount" value="<?= $devises['CDF'] ?>" >
    </div>
</div>

<div class="col-md-7">
    <div class="form-group">
        <label for="company">Balance compte du client</label> 
        <?php echo form_input('balance',set_value('balance', $account_balance), 'class="form-control" id="balance" required = "required" disabled="'.$disabled.'"'); ?>
    </div>
</div>
<div class="col-md-5">
    <div class="form-group">
        <label for="company">Taux</label> 
        <?php echo form_input('Taux',set_value('Taux', ""), 'class="form-control" '); ?>
    </div>
</div>
<script type="text/javascript">
   
'<?php if($disabled ==""){ ?>'

$("#balance").css('background-color','#00cc33');

'<?php } ?>'
    
    
</script>