<tr  id="line<?php echo $bulletin->Id_0;?>"> 
    <td width="4%"><?php echo $i;?></td>
    <td width="10%"><?php echo strftime('%d-%m-%Y',strtotime($bulletin->Date_1));?></td>
    <td width=""><?php echo $bulletin->Year_5; ?></td>
    <td width=""><?php echo $bulletin->Office_6;?></td>
    <td width="15%"><?php echo $bulletin->Agent_10;?></td>
    <td width="15%"><?php echo $bulletin->Serie_7.' '.$bulletin->Number_8;?></td>
    <td width=""><?php echo number_format($bulletin->Amount_12,2,"."," ");?></td>
    <td><?php echo (isset($status[$bulletin->Error_14]))? $status[$bulletin->Error_14] :'';?></td>
    <td width="5%">
        <span class="fa fa-fw fa-check text-blue f14"> </span>
    </td>
    <td width="5%">
        <a style="cursor:pointer" onclick="printA('<?php echo $bulletin->Id_0; ?>')" >
            <span class="fa fa-fw fa-file-pdf-o text-green f14"> </span>
        </a>    
    </td>
    <td width="5%">
        <a style="cursor:pointer" onclick="printQ('<?php echo $bulletin->Id_0; ?>')" >
            <span class="fa fa-fw fa-file-pdf-o text-warning f14"> </span>
        </a> 
    </td>
</tr>