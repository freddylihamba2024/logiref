<div class="col-md-12">
    
    <div id="loader2"></div>
    
    <?php $this->chtml->box_body_opening('', false); ?>
    <?php  echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
        <div class="col-md-12">
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                   <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <label for="site">Bureau</label>
                            <?php echo form_dropdown('Office', $services['DGDA'], $office, 'required class="form-control chosen-select"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="Agent">Declarant</label>
                            <?php echo form_input('Agent', set_value('Agent', $agent), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="Nif">Num&eacute;ro imp&ocirc;t</label>
                            <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="project">Designation</label>
                            <?php echo form_input('designation', set_value('designation', $designation), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="account_name">Intitul&eacute; du compte</label>
                            <?php echo form_input('account_name', set_value('account_name', $account_name), ' class="form-control" required '); ?>
                        </div>
                        <div class="input-group col-md-12">
                            <label for="account">Compte &agrave; d&eacute;biter</label>
                            <?php echo form_input('account', set_value('account', $account), 'id="account" class="form-control" required disabled'); ?>
                            <input type="hidden" value="<?php echo $account; ?>" name="account" id="account"  />
                            <input type="hidden" value="<?php echo $account_type; ?>" name="account_type" id="account_type"  />
                            <input type="hidden" value="<?php echo $account_balance; ?>" name="account_balance" id="account_balance"  />
                        </div>
                    </div>
                    <div class="col-md-6 bLeft">
                        <div class="input-group col-md-12 no-padding">
                            <label for="site">Mode de paiement</label>
                            <?php echo form_dropdown('mode', $modes, $mode, 'required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="total_amount">Montant total du lot</label>
                            <?php echo form_input('total_amount', set_value('total_amount', number_format($total,2,","," ")), 'id="total_amount" required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="coms">Commission totale du lot</label>
                            <?php echo form_input('Commission', set_value('Commission', number_format($commission,2,","," ")), 'id="coms" required class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <?php if($tva == 1) $tva = $commission * 0.16; else $tva = 0;?>
                            <label for="tva">TVA</label>
                            <?php echo form_input('tva', set_value('tva', number_format($tva,2,","," ")), 'id="tva" class="form-control" disabled'); ?>
                            <input type="hidden" name="tva" value="<?php echo $tva; ?>">
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="total_topaid">Total &agrave; payer</label>
                            <?php echo form_input('total_topaid', set_value('total_topaid', number_format($total_to_paid,2,","," ")), 'id="total_topaid" class="form-control"'); ?>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <label for="taux">Taux appliqu&eacute;</label>
                            <?php echo form_input('taux', set_value('taux', number_format($taux,2,","," ")), 'class="form-control"'); ?>
                        </div>
                    </div>
                </div>    
                <div id="footpage" class="box-footer clearfix"></div>
            </div>
            <div class="box-body box-solid no-padding">
                <div class="box-body">
                    <input type="hidden" name="Bank" value ="<?php echo $bank; ?>"/>
                    <input type="hidden" name="refOp" id="refOp" value ="<?php echo $refOp; ?>" />
                    <input type="hidden" name="devise_commision" value ="<?php echo 'CDF'; ?>"/>
                    <input type="hidden" name="cdevise" id="cdevise" value ="<?php echo $cdevise; ?>"/>
                    <input type="hidden" name="account_type" value ="<?php echo $account_type; ?>"/>
					<input type="hidden" name="fraisbcc" value="<?php echo $fraisbcc; ?>" id="">
					
                    <div class="table-responsive">
                        <table class="table no-margin table-striped table-bordered">
                            <thead class='bg-blue'>
                                <tr>
                                    <th width="10px">#</th>
                                    <th width="80px">Ann&eacute;e</th>
                                    <th width="80px">Bulletin</th>
                                    <th width="50px">Devise</th>
                                    <th width="200px">Montant</th>
                                    <th>Retour de SYDONIA</th>
                                    <th align="center" width="90px">V&eacute;rification</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1;  foreach($bulletins as $bl){ ?>
                                    <tr id="line<?php echo $i?>">
                                        <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                        <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year;?>" name="years[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->number; ?>"  name="serials[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td align="center"><span class="form-control">CDF</span></td>
                                        <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount,2,","," ");?>" name="amounts[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                        <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Verifiez l&apos;autheticit&eacute; du bulletin</span></td>
                                        <td align="center" id='btn<?php echo $i; ?>'>
                                           <span class="fa fa-fw text-gray fa-question f20"> </span>
                                        </td>
                                    </tr>
                                <?php $i++;  } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    
                    <?php if($account_type == 'current_account'): ?>
                        <button type="submit" id="createLien" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;
                    <?php else: ?>
                        <button type="submit" id="save" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;
                    <?php endif; ?>
                    <input type="hidden" name="action" value="" id="action">
                    <input type="hidden" name="bulletin_id" value="" disabled="disabled" id="bulletin_id">
                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>  
                </div>
            </div>
        </div>
        <?php echo form_close(); ?> 
    <?php $this->chtml->box_body_closing(); ?> 
</div>

<div class="col-md-12">
   
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('.chosen-select').chosen({width: "100%"});

$("#treat").click(function(){
        $("#action").val('traiter');
});

$("#createLien").click(function(){
        $("#action").val('createLien');
});

$("#save").click(function(){
        $("#action").val('save');
});

$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        
        if(action == 'createLien')
        {
                $("#loader2").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                get_reservation(data);
        }
        else if(action == 'traiter')
        {
                batch_tratement(data);
        }
        else if(action == 'save')
        {
                check_batch(data);
        }
});


$("#buttonCloseModal").click(function(){
        location.reload(true);
});


function submitter(data, type=null)
{
        $("#loader2").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#envoyer').prop("disabled", true);
        $('#save').prop("disabled", true);
        $('#createLien').prop("disabled", true);
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        
        scrollUP();
        
        var url = '<?php echo base_url($module.'/bulletin/display/batch_create_bulletin'); ?>/'+type;
        
        $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                       //$('#envoyer').prop("disabled", false);
                        $('#envoyer').html(button);
                        $('#loader2').html(result);
                        
                        if(result > 0)
                        {
                                $('#loader2').html('<div class="alert alert-success text-white">Paiement enregistr&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Paiement non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
               },
               error:function(error){
                   alert('ERROR! SYDONIA 41.215.253.187 pas disponible...! ');
                   $('#envoyer').html(button);
               }
       });
}

function batch_tratement(data)
{
        $('#treat').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#treat').html();
        $('#treat').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
        $("#loader2").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        scrollUP();
        
        var data = data;
        var url = '<?php echo base_url($module.'/bulletin/display/batch_verification'); ?>/';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result)
                    {
                            $('#treat').prop("disabled", false);
                            $('#treat').prop("buttonCloseModal", false);
                            $('#treat').html(button);
                            $('#loader2').html('');
                            var result = JSON.parse(result);
                            if(result.response === "OK")
                            {
                                    // Mise a jour du tableau avec le retour de SYDONIA
                                    var bulletins = result.bulletins;
                                    var t = 0;
                                    for(i = 0; i < bulletins.length; i++)
                                    {
                                            t = i + 1;
                                            
                                            if(bulletins[i] === "OK")
                                            {
                                                    $("#btn"+t).html('<span class="fa fa-fw text-green fa-check f20"> </span>');
                                                    $("#sydonia_result"+t).html('<div class="alert alert-success text-white">Bulletin valide!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(bulletins[i] === "E13")
                                            {
                                                    $("#btn"+t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Server execption!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(bulletins[i] === "E34")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-danger text-white">Bulletin d&eacute;j&agrave; pay&eacute;!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                            }
                                            else if(bulletins[i] === "E22")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Bulletin non reconnu!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                            }
                                            else if(bulletins[i] === "E11")
                                            {
                                                    $("#sydonia_result"+t).html('<div class="alert alert-warning text-white">Montant du bulletin est incorrect!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                    $("#btn"+t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                            }
                                    }
                                    
                                    
                                    // Teste si la balance est suffisante et que tous les bulletins sont valides
                                    if(result.balance === "OK" && result.error === false)
                                    {
                                        // Activation de la reservation des fonds
                                        $("#createLien").prop('disabled', false);
                                        $('#save').prop("disabled", false);
                                        
                                        // Mise a jour du montant total a payer au cas ou la commission serait modifiee
                                        $("#total_amount").val(result.total_amount);
                                        
                                        // Mise a jour du montant total du lot des bulletins au cas ou le montant de bulletin serait modifiee
                                        $("#total_topaid").val(result.total);
                                        
                                        // mise à jour de l'affichage de la TVA
                                        $("#tva").val(result.tva);
                                        
                                        scrollUP();
                                        
                                    }
                                    else if(result.balance === "KO")
                                    {
                                            $('#loader2').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(result.balance === "E411")
                                    {
                                            $('#loader2').html('<div class="alert alert-danger text-white">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                            }
                            else if(result.response === "E000")
                            {
                                    $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E404")
                            {
                                    $("#loader2").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E003")
                            {
                                    $("#loader2").html('<div class="alert alert-warning text-white">Alerte: Fatal error...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.response === "E18")
                            {
                                    $("#loader2").html('<div class="alert alert-warning text-white">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            
                    },
                    error:function(error)
                    {
                            scrollUP();
                            $('#loader2').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
}

function get_reservation(data)
{
        var compte = $('#account').val();
        var devise = $('#cdevise').val();
        var montant = $('#total_topaid').val();
        var refop = $('#refOp').val();
        
        
        $("#loader2").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/data/get_batch_reservation'); ?>';
        
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, montant : montant, refOp: refop}, 
                    dataType    : 'json',  
                    encode          : true,
                    success: function(response)
                    {	
                            if(response.code == '200')
                            {
                                    $('#loader2').html('<div class="alert alert-info text-white"> Paiement enregistr&eacute; avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#createLien").addClass('hidden');
                                    $("#confirm").removeClass('hidden');
                                    $("#save").addClass('hidden');
                                    $("#save").prop('disabled', false);
                                    $("#treat").prop("disabled", true);
                                    submitter(data, "reservation");

                            }
                            else if(response.code =='E500')
                            {
                                    $('#loader2').html('<div class="alert alert-warning text-white"> Vous avez r&eacute;utilis&eacute; une r&eacute;f&eacute;rence de l\'OP d&eacute;j&agrave; utilis&eacute;e. Veuillez changer de r&eacute;f&eacute;rence sil vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#createLien").addClass('hidden');
                                    $("#treat").addClass('hidden');
                                    $("#confirm").removeClass('hidden');
                                    $("#releaseLien").removeClass('hidden');
                                    
                                    $("#bulletin_id").val(response.id);
                                    $("#confirm").prop('disabled', false);
                                    $("#confirm").prop('disabled', false);
                            }
                            else if(response.code == 'E008')
                            {
                                    $('#loader2').html('<div class="alert alert-danger text-white"> Il y a d&eacute;j&agrave; une reservation de fonds sur ce compte, veuillez contacter le gestionnaire du compte <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(response.code == 'E162')
                            {
                                    $('#loader2').html('<div class="alert alert-danger text-white">Ce compte n\'existe pas.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(response.code == 'E4348')
                            {
                                    $('#loader2').html('<div class="alert alert-danger text-white">La r&eacute;servation de fonds n\'est pas autoris&eacute; pour ce compte.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}


function check_batch(data)
{
        var refop = $('#refOp').val();
        
        var url = '<?php echo base_url($module.'/bulletin/display/check_batch'); ?>/' + refop;
        $.get(url, function(result, status){
            
                if(result == 'E000')
                {
                        scrollUP();
                        $('#loader2').html('<div class="alert alert-warning text-white"> Vous avez r&eacute;utilis&eacute; une r&eacute;f&eacute;rence de l\'OP d&eacute;j&agrave; utilis&eacute;e. Veuillez changer de r&eacute;f&eacute;rence sil vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else 
                {
                        submitter(data);
                }
        });
}


function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader2").offset().top
    }, 20);
}
</script>



