<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="loader1"></div>
    <div class="col-md-12">
        <h1>Pr&eacute;paiements</h1>
        <p class="page-header">Extractions des pr&eacute;paiements</p>     
    </div>
    <div class="col-md-12">
        <div class="col-md-2">
            <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
        </div>
        <div class="col-md-4">
            <div class="pull-left">Filtrage du lot des paiements &agrave; extraire<br/></div>
        </div>
        <div class="col-md-2">
            <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
        </div>
        <div class="col-md-4">
            <div class="pull-left">Validation des pr&eacute;paiements<br/></div>
        </div>
    </div>
    <div class="col-md-12"><br/>
        <div id="loader2"></div>
    </div>
    <div id="panel">
        <?php if($step == 1 || $step == 2 ):?>
            <?php $this->load->view('_prepayments'); ?>
        <?php elseif($step == 3):?>
            <?php $this->load->view('_step_3'); ?>
        <?php else:?>
            <div class="col-md-12">
                <?php $this->chtml->box_body_opening('', true);?>
                    <div class="col-md-4 no-padding">
                        <div class="col-md-12 center">
                            <p class="page-header">
                                <br/><br/>Remplissez les champs recquis pour extraire un lot des pr&eacute;paiments d'une p&eacute;riode donn&eacute;e
                            </p><br/> 
                        </div>
                    </div>
                    <div class="col-md-8 bLeft">
                        <?php echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
                            <div id="details" class="col-md-12"></div>
                            <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
                            <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
                            <div class="box-body">
                                <div class="col-md-4">
                                    <label for="dateDebut">Date d&eacute;but</label> 
                                    <?php echo form_input('dateDebut','', 'class="form-control" id="dateDebut"  required = "required"'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="dateFin">Date fin</label> 
                                    <?php echo form_input('dateFin','', 'class="form-control" id="dateFin"  required = "required"'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="nbrQuittances">Nombre des quittances</label> 
                                    <input type="number" min="1" name="nbrQuittances" class="form-control" required = "required"/>
                                </div>
                            </div>
                            <div class="box-footer clearfix">
                                <div class="col-md-12">
                                    <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-download"></i>&nbsp;&nbsp;Suivant&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                <?php $this->chtml->box_body_closing(); ?> 
            </div>
        <?php endif;?>
    </div>
</div>
<div class="col-md-1"></div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#dateDebut').datepicker({
        format: 'yyyy-mm-dd'
});

$('#dateFin').datepicker({
        format: 'yyyy-mm-dd'
});

$("#extractform").submit(function(event){
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
});
function next_step(data)
{
        $("#loader2").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#sub').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>T&eacute;l&eacute;chargement...</span>');
        var url = '<?php echo base_url($module.'/bank/display/prepayment_step2'); ?>';
        $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                       $('#sub').prop("disabled", false);
                       $('#sub').html(button);
                       $('#loader2').html('');
                       if(result === "E404")
                       {
                            $('#loader2').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E36")
                       {
                            $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Probl&egrave;me d\'acc&eagrave;s &agrave; SYDONIA, contactez l\'administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E37")
                       {
                            $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Date d?but incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E38")
                       {
                            $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Date fin incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E39")
                       {
                            $('#loader2').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E43")
                       {
                            $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Votre code banque n\'est pas reconnu dans SYDINIA, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else 
                       {
                            $("#step-1").removeClass('bg-green-active');
                            $("#step-1").addClass('bg-gray');
                            $("#step-2").removeClass('bg-gray');
                            $("#step-2").addClass('bg-green-active');
                            $("#panel").html(result);
                       }
               },
               error:function(error){
                   alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                   $('#sub').prop("disabled", false);
                   $('#sub').html(button);
               }
       });
       
}

</script>
