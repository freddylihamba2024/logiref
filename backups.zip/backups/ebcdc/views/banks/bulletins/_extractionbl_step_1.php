<div class="col-md-11">
    <div id="loader"></div>
    <?php if(!empty($bulletins)): ?>
    <?php $this->chtml->box_body_opening('', true); ?>
        <table id="tableREN1" class="table table-hover table-striped">
            <thead>
                <tr class="bg-gray">
                    <th width="4%">#</th>
                    <th width="10%">Date</th>
                    <th width="15%">Statut</th>
                    <th width="">Redevable</th>
                    <th width="">Bureau de douane</th>
                    <th width="15%">Num&eacute;ro bulletin</th>
                    <th width="">Montant</th>
                    <th width="5%"><span class="fa fa-fw fa-tasks f14"></span></th>
                    <th width="5%"><span class="fa fa-fw fa-file-pdf-o f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php $i =1; foreach($bulletins as $obj): ?>
                    <tr> 
                        <td width="4%"><?php echo $i;?></td>
                        <td width="10%"><?php echo strftime('%d-%m-%Y',strtotime($obj->Date_1));?></td>
                        <td width="15%"><span class="badge <?php echo $color[$obj->Status_2]; ?>"><?php echo $status[$obj->Status_2];?></span></td>
                        <td width=""><?php echo $obj->Nifimportateur_10.' / '.$obj->Designation_27;?></td>
                        <td width=""><?php echo $obj->Bureau_11;?></td>
                        <td width="15%"><?php echo $obj->Receiptid_5;?></td>
                        <td width=""><?php echo number_format($obj->Amount_14,2,"."," ");?></td>
                        <td width="5%">
                           <a style="cursor:pointer" onclick="view('<?php echo $obj->Declaration_12;?>', '<?php echo $obj->Status_2; ?>')"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                        </td>
                        <td width="5%">
                            <?php if($obj->Status_2 == 3 && $obj->Quittance_13 != ""):?>
                                <a style="cursor:pointer" onclick="printpdf('<?php echo $obj->Quittance_13; ?>')"><span class="fa fa-fw text-yellow fa-file-pdf-o f14"></span></a>
                            <?php else: ?>
                                <span class="fa fa-fw fa-file-pdf-o text-gray f14"> </span>
                            <?php endif;?>
                        </td>
                    </tr>
                <?php $i++;  endforeach;?>
            </tbody>
        </table>
    <?php $this->chtml->box_body_closing(); ?>
    <?php else: ?>
        <section>
            <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute;e!</b></h4>
                <br/>
            </div>
        </section>
    <?php endif;?>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#tableREN1').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

function view(dId, status)
{
        var url = '<?php echo base_url($module.'/bank/display/traitementbl'); ?>/' + status +'/'+ dId;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
}

</script>

