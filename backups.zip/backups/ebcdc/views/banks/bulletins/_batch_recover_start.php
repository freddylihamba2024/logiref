<?php $codeBank = isset($_SESSION['Guichet_code'])? substr($_SESSION['Guichet_code'],1) :'51'; ?>
<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="loader1"></div>
    <div class="col-md-12">
        <h1>Bulletins pay&eacute;s</h1>
        <p class="page-header">Recuperation des bulletins pay&eacute;s dans SYDONIA</p>     
    </div>
    <div class="col-md-12">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Extraction<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Enregistrement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Rapport<br/></div>
        </div>
    </div>
    <div class="col-md-12"><br/>
        <div id="loader"></div>
    </div>
    <div id="pager">
        <?php if($step == 1 || $step == 2 ):?>
            <?php $this->load->view('_batch_recover_step_1'); ?>
        <?php elseif($step == 3):?>
            <?php $this->load->view('_batch_recover_step_1'); ?>
        <?php else:?>
            <div class="col-md-12">
                <?php $this->chtml->box_body_opening('', true);?>
                    <div class="col-md-4 no-padding">
                        <div class="col-md-12 center">
                            <p class="page-header">
                                <br/><br/>Cette section vous permet de recuperer les paiements dans SYDONIA, suivant les informations demand&eacute;es sur le formulaire
                            </p><br/> 
                        </div>
                    </div>
                    <div class="col-md-8 bLeft">
                        <?php echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
                            <div id="details" class="col-md-12"></div>
                            <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
                            <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
                            <div class="box-body">
                                <div class="col-md-12 no-padding no-margin">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Service_16">Bureau (ou service)</label> 
                                            <?php echo form_dropdown('Office',$services['DGDA'],'', 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="guichet">Agence</label>
                                            <?php echo form_input('guichet','', 'class="form-control" id="guichet" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                            <?php echo form_input('Nif','', 'class="form-control" id="company" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="designation">Designation</label>
                                            <?php echo form_input('designation','', 'class="form-control" id="designation" required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <br>
                                </div>
                                <div class="col-md-12 no-padding no-margin">
                                    <p class="page-header">
                                        P&eacute;riode de la quittance
                                    </p>
                                     <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="qserie">S&eacute;rie de la quittance</label> 
                                            <?php echo form_input('qserie','Q', 'class="form-control" id="qserie" required = "required"'); ?>
                                        </div>
                                    </div>
                                     <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="qnumber">Num&eacute;ro de la quittance</label> 
                                            <?php echo form_input('qnumber','', 'class="form-control" id="qnumber" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dateDebut">Date d&eacute;but</label> 
                                            <?php echo form_input('dateDebut','', 'class="form-control" id="dateDebut"  required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dateFin">Date fin</label> 
                                            <?php echo form_input('dateFin','', 'class="form-control" id="dateFin"  required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer clearfix">
                                <div class="col-md-12">
                                    <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-download"></i>&nbsp;&nbsp;Extraire&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                <?php $this->chtml->box_body_closing(); ?> 
            </div>
        <?php endif;?>
    </div>
</div>
<div class="col-md-1"></div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#dateDebut').datepicker({
        format: 'yyyy-mm-dd'
});

$('.chosen-select').chosen({width: "100%"});
   

$('#dateFin').datepicker({
        format: 'yyyy-mm-dd'
});

$("#extractform").submit(function(event){
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
});
function next_step(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#sub').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>T&eacute;l&eacute;chargement...</span>');
        var url = '<?php echo base_url($module.'/bulletin/display/extractbls'); ?>';
        $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                        $('#sub').prop("disabled", false);
                        $('#sub').html(button);
                        $('#loader').html('');
                       
                        if(result === "E404")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA est temporairement indisponible. Veuillez r&eacute;essayer dans 30 secondes...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E405")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA a pris beaucoup pour repondre. R&eacute;essayez dans 30.secondes..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E406")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA n&apos;a donn&eacute; aucun retour. R&eacute;essayez dans 30.secondes..!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E36")
                        {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Mot de passe incorrect !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E37")
                        {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Date d&eacute;but incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E38")
                        {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Date fin incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E39")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Aucun pr&eacute;paiement trouv&eacute!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E44")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Aucune d&eacute;claration disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }   
                        else if(result === "E501")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Aucune quittance disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E502")
                        {
                            $('#loader').html('<div class="alert alert-info text-white">Ces bulletins ont d&eacute;j&agrave; &eacute;t&eacute; recup&eacute;r&eacute;s. consultez le menu paiements non valid&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E514")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Aucune r&eacute;ponse de SYDONIA ressayez plutard!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E43")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: Votre code banque n\'est pas autoris&eacute;, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else if(result === "E000")
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#buttonCloseModal').prop("disabled", '');
                        }
                        else 
                        {
                            
                            $("#pager").html(result);
                        }
               },
               error:function(error){
                   alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                   $('#sub').prop("disabled", false);
                   $('#sub').html(button);
               }
       });
       
}

</script>


