<?php $Standard01=''; $total = 0;  ?>
<table id="table" class="table table-hover table-striped fixed_header">
    <thead class="tScroll">
        <tr class="bg-blue">
            <th width="">B&eacute;n&eacute;ficiaire</th>
             <th width="">Taxe code</th>
            <th width="">Description</th>
            <th width="" class="center">Montant</th>
        </tr>
    </thead>
    <tbody class="fixed_header tScroll">
        <?php foreach($taxesPaid as $taxe) :?>
            <tr class="<?php if(!isset($beneficiaires[$taxe->taxeCode])){ echo "text-red";}?> tScroll">
                <td><?php echo (isset($beneficiaires[$taxe->taxeCode]))? $beneficiaires[$taxe->taxeCode]:$taxe->taxeCode ;?></td>
                <td><?php echo $taxe->taxeCode;?></td>
                <td><?php echo $taxe->taxeDescription;?></td>
                <td  class="right"><?php echo 'CDF '.number_format($taxe->taxeAmount,2,","," ");?></td>
            </tr>
        <?php endforeach; $total = $total + $taxe->taxeAmount; ?>
        <tr class="tScroll">
            <td>[+]</td>
            <td></td>
            <td><b>TOTAL</b></td>
            <td align="right"><b><?php echo number_format($total,2,","," ").' CDF'; ?></b></td>
        </tr>
    </tbody>    
</table>

