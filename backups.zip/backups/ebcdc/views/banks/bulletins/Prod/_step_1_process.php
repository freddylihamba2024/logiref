<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(!isset($balance))
{
        $balance = "";
}

if(!isset($balance))
{
        $balance = "";
}

$date = json_decode($bulletin->Paiementinfo_35);

$date = isset($date->DateL) ? $date->DateL : "";

$lien_details = json_decode($bulletin->Reservation_34, true);

if($integrations[0]->Status_2 != 1 || $_SESSION['Logiref_role']==4)
{
        $button_treat = "disabled";
}
else
{
        $button_treat = "";
}

?>
    <div class="col-md-12">
        <div id="loader1"></div>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification du Bulletin<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Validation<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/>
            
            <?php if($integrations[0]->Status_2 == 5 && $_SESSION['Logiref_role']==3): ?>
                <div id="loader2"><div class="alert alert-danger text-white"> Il y avait eu un time out pendant la validation de ce paiement, veuillez vous connecter dans Finacle pour v&eacute;rifier si ce paiement est bien comptabilis&eacute; ou pas. Si le paiement est d&eacute;j&agrave; comptabilis&eacute;, cochez la case [proc&eacute;c&eacute;der &agrave; l'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
            <?php endif; ?>
                
            <?php if($bulletin->Status_2 == 1 && $_SESSION['Logiref_role']!=3 ): ?>
                <div id="loader2"><div class="alert alert-info text-white">Le bulletin en attente validation, veuillez contacter le validateur pour la suite du processus.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
            <?php endif; ?>
                
            <div id="loader"></div>
            
            <div id="alert"></div>
        </div>
        <div id="pager">
            <?php if($step == 1 || $step == 2 ):?>
                <?php $this->load->view('_step_2'); ?>
            <?php elseif($step == 3):?>
                
                <?php $this->load->view('_step_1'); ?>
            <?php else:?>
                <div class="col-md-12">
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <?php $this->chtml->box_body_opening('', true);?>
                    
                    <div class="col-md-8 bRight">
                        <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
                        <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
                            <div class="box-body">
                                <div class="col-md-12">
                                    <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="Service_16">Bureau (ou service)</label> 
                                        <?php echo form_dropdown('Office',$services['DGDA'],isset($bulletin->Office_6) ? $bulletin->Office_6 : "", 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="year">Ann&eacute;e</label> 
                                        <?php echo form_input('Year',isset($bulletin->Year_5 ) ? $bulletin->Year_5 : "2021", 'class="form-control" id="year" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="year">Banque</label> 
                                        <?php echo form_input('Bank',isset($bulletin->Bank_11) ? $bulletin->Bank_11 : "11", 'class="form-control bg-gray" id="year" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                        <?php echo form_input('Nif',isset($bulletin->Nif_9) ? $bulletin->Nif_9 : "" , 'class="form-control" id="company" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                       <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                        <?php echo form_input('Agent',isset($bulletin->Agent_10) ? $bulletin->Agent_10 : "0000", 'class="form-control" id="declarant" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="assessment_serial">S&eacute;rie</label>
                                        <?php echo form_input('Series',isset($bulletin->Serie_7) ? $bulletin->Serie_7: "L", 'class="form-control" id="assessment_serial" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="assessment_number">Num&eacute;ro du bulletin</label>
                                        <?php echo form_input('Number',isset($bulletin->Number_8) ? $bulletin->Number_8: "", 'class="form-control" id="assessment_number" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Montant_11">Montant &agrave; payer</label>
                                        <?php echo form_input('Amount',isset($bulletin->Amount_12) ? $bulletin->Amount_12 : "", 'class="form-control" id="amount" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="devise">Devise</label>
                                        <?php echo form_dropdown('devise', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27 : "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                        <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="Mode">Mode</label> 
                                        <?php echo form_dropdown('Mode', $modes, isset($bulletin->Mode_30) ? $bulletin->Mode_30 : "", 'class="form-control" required="required" id="modeId"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="DateL">Date liquidation</label>
                                        <?php echo form_input('DateL',set_value('Datevaleur_31', date('Y-m-d', strtotime($date))), 'class="form-control" id="datepicker1" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="Account" id="accountname">Compte du client &agrave; d&eacute;biter</label> <span id="taxinfo" class="text-red"></span>
                                        <?php echo form_input('bank_account',isset($bulletin->Account_28) ? $bulletin->Account_28 : "", 'class="form-control" id="bank_account" placeholder="E.g: 0000100002000030000400005" required="required" '); ?>
                                        <input type="hidden" name="account_name" value="" id="account_name">
                                        <input type="hidden" name="tax_info" value="" id="tax_info">
                                        <input type="hidden" name="account_currency" value="" id="account_currency">
                                        <input type="hidden" name="account_balance" value="" id="account_balance">
                                        <input type="hidden" name="lien_id" value="" id="lien_id">
                                        <input type="hidden" name="date_lien" value="" id="date_lien">
                                        <input type="hidden" name="tarif" value="" id="tarif">
                                        <input type="hidden" name="internal_account" value="" id="internal_account">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="Devise_account">Devise de ce compte</label>
                                        <?php echo form_dropdown('Devise_account', $devises, isset($bulletin->Devise_29) ? $bulletin->Devise_29 : "", 'class="form-control" required="required" id="account_devise" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-7 hidden" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux de change :</b> <span id="exchange_message"></span></div>
                                <input type="hidden" name="exchange_rate" value="" id="exchange_rate" >
<!--                                <div class="col-md-7">
                                    </br><label>Paie TVA&nbsp;<input type="checkbox" name="tva" value="<?= 1 ?>" checked></label>
                                </div >
                                
                                <div class="col-md-5">
                                    </br><label>Paie pour compte&nbsp;<input type="checkbox" name="pourcompte" value="<?= 1 ?>"></label>
                                </div>-->
                                <div class="col-md-12"><br><br><br></div>
                                <div class="col-md-12 no-padding <?php if($integrations[0]->Status_2 !="5" || $_SESSION['Logiref_role']!=3) echo "hidden"; ?>" id="approbation">
                                        <br/>
                                        <div class="col-md-5">
                                            <label class="pull-left">
                                                <input type="checkbox" id="approbation_debit"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Valider la transaction &agrave; nouveau</span>
                                            </label>
                                        </div>
                                        <div class="col-md-7">
                                            <label class="pull-left">
                                                <input type="checkbox" id="approbation_emarge"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Proc&eacute;c&eacute;der à l'&eacute;margement</span>
                                            </label>
                                        </div>
                                </div>
                            </div>
                            <div id="details" class="col-md-12"></div>
                            <div class="box-footer clearfix">
                                <div class="col-md-12">
                                    <button type="submit" id="releaseLien" disabled class="btn btn-primary <?php if($lien_details['lien_id'] =="") echo "hidden" ?> <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?>" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==4) echo "Enregistrer"; else echo "Valider"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="submit" id="debit" disabled class="btn btn-primary <?php if($lien_details['lien_id'] !="") echo "hidden" ?>" <?php if($integrations[0]->Status_2 == 5 || $integrations[0]->Status_2 == 2) echo "disabled" ?> <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==4) echo "Enregistrer"; else echo "Valider"; ?>&nbsp;&nbsp;</button>&nbsp;
                                    <button type="submit" id="treat" class="btn btn-primary" <?php echo $button_treat ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="submit" id="confirm" class="btn btn-success" <?php if($integrations[0]->Status_2 != 2 || $_SESSION['Logiref_role']==4) echo "disabled" ?>><i class="fa fa-save"></i>&nbsp;&nbsp;Emargement&nbsp;&nbsp;</button>&nbsp;
<!--                                    <button type="button" id="delete" disabled class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimert&nbsp;</button>&nbsp;&nbsp;-->
                                    <button type="button" id="delete" class="btn btn-danger hidden"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="delete2" class="btn btn-danger hidden"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;
                    
                                    <input type="hidden" name="action" value="" id="action">
                                    <input type="hidden" name="bulletin_id" value="<?= $bulletin->Id_0 ?>" id="bulletin_id">
                                    <a type="button" href="" id="close" class="btn btn-warning mRight10"><i style="color:#fff" class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;  
                                </div>
                            </div>
                    </div>
                    <div class="col-md-4 no-padding " id="treatment">
                        <div class="col-md-12">
                            </br></br></br>
                            <div class="form-group">
                                <label for="designation">Designation</label> 
                                <?php echo form_input('designation',set_value('designation', isset($bulletin->Designation_23) ? $bulletin->Designation_23 : ""), 'class="form-control" id="designation" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <input type="hidden" name="concat" value="<?//= $compte_guichet ?>" >
                            <div class="form-group">
                                <label for="company">Compte guichet unique</label> 
                                <?php echo form_input('Compte_guichet',set_value('Compte_guichet', isset($bulletin->Account_24) ? $bulletin->Account_24 : ""), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
                                <input type="hidden" name="Compte_guichet" value="<?= $bulletin->Account_24; ?>" >
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="devise">Devise</label>
        			<?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
        			<input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-group">
                                <label for="company">Commission</label> 
                                <?php echo form_input('Commission',set_value('Commission', isset($bulletin->Commission_26) ? $bulletin->Commission_26 : ""), 'class="form-control" id="coms" required = "required" '); ?>
                                <!--<input type="hidden" name="Commission" value="<? =$commission ?>" <?//= $disabled_2 ?> >-->
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="devise">Devise</label>
                                <?php echo form_dropdown('Devise_commission', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27: "CDF", 'class="form-control"  required="required" id="recetteDevise" '); ?>

                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-group">
                                <label for="company">Montant total</label> 
                                <?php echo form_input('Total_amount',set_value('Total_amount',isset($bulletin->Amount_12) ? $bulletin->Amount_25 : ""), 'class="form-control" id="total" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="devise">Devise</label>
                                <?php echo form_dropdown('Devise_amount',$devises,"CDF", 'class="form-control"  required="required" '); ?>
                                <!--<input type="hidden" name="Devise_amount" value="<?//= $devises['CDF'] ?>" >-->
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-group">
                                <label for="reference">R&eacute;f&eacute;rence de de l&apos;OP</label>
                                <?php echo form_input('reference',set_value('reference', isset($bulletin->Reference_19) ? $bulletin->Reference_19 : ""), 'class="form-control" id="reference"  ""'); ?>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="company">Taux</label> 
                                <?php echo form_input('Taux',set_value('Taux', set_value('Taux', isset($bulletin->Taux_31) ? $bulletin->Taux_31 : "")), 'class="form-control" '); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="company">Balance du compte</label> 
                                <?php echo form_input('balance',set_value('balance', isset($account_balance) ? $account_balance : ""), 'class="form-control" id="balance" disabled="disabled"'); ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php $this->chtml->box_body_closing(); ?> 
                    <?php echo form_close(); ?>
                </div>
            <?php endif;?>
        </div>
    </div>
<br/>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
   
'<?php if($balance =="ok"){ ?>'

$("#balance").css('background-color','#00cc33');
$("#balance").css('color','white');
$("#createLien").prop('disabled', false);

'<?php }elseif($balance =="ko"){ ?>'

$("#balance").css('background-color','red');
$("#balance").css('color','white');
$("#createLien").prop('disabled', true);

'<?php } ?>'

'<?php if($integrations[0]->Status_2 == 5 && $_SESSION['Logiref_role']==3): ?>'
$('#delete').prop("disabled",false);
'<?php endif; ?>'

show_account_name();


$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});

$("#confirm").click(function(){
        $("#action").val('confirmer');
});

$("#debit").click(function(){
        $("#action").val('debit');
});

$("#treat").click(function(){
        $("#action").val('traiter');
});

$("#releaseLien").click(function(){
        $("#action").val('releaseLien');
});


$("#approbation_debit").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#debit").prop("disabled", false);
                $("#approbation_emarge").prop("checked", false);
                $("#confirm").prop("disabled", true);
        }
        else
        {
                $("#debit").prop("disabled", true);
        }  
});

$("#approbation_emarge").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#confirm").prop("disabled", false);
                $("#approbation_debit").prop("checked", false);
                $("#debit").prop("disabled", true);
        }
        else
        {
                $("#confirm").prop("disabled", true);
        } 
});

$("#bank_account").change(function(){
    
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            $('#internal_account').val(compte);
            $('#internal_account').prop('disabled', false);
            get_accountname_internal();
    }
    else
    {
            $('#internal_account').val('');
            $('#internal_account').prop('disabled', true);
            get_accountname();
    }
});

$("#account_devise").change(function(){
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    } 
});

$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        if(action == 'confirmer')
        {
                next_step(data);
        }
        else if(action == 'traiter')
        {
                treat_data(data);
        }
        else if(action == 'debit')
        {
                first_transaction();
        }
        else if(action == 'releaseLien')
        {
                cancel_reservation();
        }
});

$("#delete").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');

        var id = '<?php echo $bulletin->Id_0; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/bulletin/save/delete'); ?>/' +id;
                $.get(url, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled",true);
                        $('#print').prop("disabled",true);
                        $('#schema').prop("disabled",true);
                        $('#delete').prop("disabled",true);
                        $('#treat').prop("disabled", true);
                        $("#approbation_debit").prop("disabled", true);
                        $("#approbation_emarge").prop("disabled", true);

                        cancel_reservation_btndelete();
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});

$("#delete2").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');

        var id = '<?php echo $bulletin->Id_0; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
               var url = '<?php echo base_url($module.'/bulletin/save/delete'); ?>/' +id;
                $.get(url, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#confirm').prop("disabled",true);
                        $('#debit').prop("disabled",true);
                        $('#releaseLien').prop("disabled",true);
                        $("#releaseLien").addClass('hidden');
                        $('#delete2').prop("disabled",true);
                        $('#treat').prop("disabled", true);
                        $("#approbation_debit").prop("disabled", true);
                        $("#approbation_emarge").prop("disabled", true);
                        $("#buttonCloseModal").prop("disabled", false);
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});



function cancel_reservation_btndelete()
{
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var bulletin_id = $('#bulletin_id').val();
        
        $("#releaseLien").prop('disabled', true);
        
        var url = '<?php echo base_url($module.'/accounts/data/cancel_reservation'); ?>';

        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, bulletin_id : bulletin_id}, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {
                            if(response != '200')
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#releaseLien").prop('disabled', false);
                            }
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}


function cancel_reservation()
{
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var bulletin_id = $('#bulletin_id').val();
        
        $("#releaseLien").prop('disabled', true);
        
        var url = '<?php echo base_url($module.'/accounts/data/cancel_reservation'); ?>';

        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, bulletin_id : bulletin_id}, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {
                            if(response == '200')
                            {
                                    first_transaction();
                            }
                            else
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#releaseLien").prop('disabled', false);
                            }
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}

function treat_data(data)
{
        var url = '<?php echo base_url($module.'/bulletin/display/verification'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                    //$('#delete').prop("disabled",false);
                    $("#delete").removeClass('hidden');
                    if(result === "E003")
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E22" || result === "E13")
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E11")
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E404")
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA n\'est pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E000")
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E411")
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaÃ®t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E412")
                    {
                            $('#loader').html('');
                            $("#balance").css('background-color','red');
                            $("#balance").css('color','white');
                            $("#balance").val('Solde insuffisant');
                    }
                    else
                    {
                            $('#loader').html('');
                            
                            var account_internal = $('#internal_account').val();
                            
                            
                            
                            if(account_internal != "")
                            {
                                    $("#balance").css('background-color','#ff9933');
                                    $("#balance").css('color','white');
                                    $("#balance").val('Accès à la balance du compte interne non autorisé');
                                    
                                    $("#debit").prop('disabled', false);
                                    $("#releaseLien").addClass('hidden');
                                    $("#debit").removeClass('hidden');
                            }
                            else
                            {
                                    $("#balance").css('background-color','#00cc33');
                                    $("#balance").css('color','white');
                                    $("#balance").val('Approvisionné');
                                    
                                    $("#releaseLien").prop('disabled', false);
                                    $("#debit").addClass('hidden');
                                    $("#releaseLien").removeClass('hidden');
                            }
                    }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function first_transaction()
{
    var bulletin_id = $('#bulletin_id').val();

    var url = '<?php echo base_url($module.'/bulletin/display/first_transaction'); ?>';
    
    $("#debit").prop('disabled', true);
    $('#treat').prop("disabled", true);

    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : {bulletin_id : bulletin_id}, 
                dataType    : 'html',  
                encode          : true,
                success: function(result)
                {
                        if(result === "E162")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E463")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E3238")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "W0205")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E397")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "AD3")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E9999")
                        {
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "ERR002")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "ERR003")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "P83")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "200")
                        {
                                $("#loader").html('');
                                $("#loader2").html('');
                                $('#confirm').prop("disabled", false);
                                $('#debit').prop("disabled", true);
                                
                                $('#loader').html('<div class="alert alert-info text-white"> La validation de la transaction a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger le bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {   
                                $("#loader").html('');
                                $('#approbation').removeClass('hidden');
                                $('#loader').html('<div class="alert alert-danger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error)
                {
                    $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }  
    });
}

function show_account_name()
{
        var compte = $("#bank_account").val();
        if(compte.length == 14)
        {
                $('#internal_account').val(compte);
                $('#internal_account').prop('disabled', false);
                get_accountname_internal();
        }
        else
        {
                $('#internal_account').prop('disabled', true);
                get_accountname();
        }
}

function check_internal_account()
{
        var comptes = $("#bank_account").val();
        if(comptes.length == 14)
        {
                return true;
        }
        else
        {
                return false;
        }   
}

function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function get_accountname_internal()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function next_step(data)
{
       $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
       $('#confirm').prop("disabled", true);
       $("#delete").addClass('hidden');
       $("#delete2").removeClass("hidden");
        
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');
       var url = '<?php echo base_url($module.'/bulletin/display/confirmation'); ?>';
       $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'json', 
               encode      : true,
               success: function(result){
                        $('#loader').html('');
                        console.log(result);
                        
                        if(result.response === "E003")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E34")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E22" || result.response === "E13")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent pas au bulletin comptant, veuillez v&eacute;rifier les informations renseign&eacute;es s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E11")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E002")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E003")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E005")
                        {
                                $('#envoyer').prop("disabled", false);
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E000")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.response === "E404")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               
                        }
                        else if(result === "OK")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Pas de retour attendu...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');
                               
                                var url = '<?php echo base_url($module.'/bulletin/display/edit'); ?>/' + result.response;
                                $.get(url, function(data, status){
                                    $("#loader").html('');
                                    $("#pager").html(data);
                                })
                        }
               },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">L\emargement a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                   $('#envoyer').prop("disabled", false);
                   $('#envoyer').html(button);
                }
       });
                       
}

    
</script>

