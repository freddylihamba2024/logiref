<?php if(!empty($bulletins)): ?>
    <table id="tableREN1" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th width="5px">#</th>
                <th width="50px">Quittance</th>
                <th width="50px">Bulletin</th>
                <th width="50px">Ann&eacute;e</th>
                <th>Montant</th>
                <th class="text-center" >Statut</th>
                <th width="10px" style="text-align:center;"><i class="fa fa-tasks f20"></i></th>
            </tr>
        </thead>
        <tbody>
            <?php $i =1; foreach($bulletins as $obj): ?>
                <tr  id="line<?php echo $obj->Id_0;?>"> 
                    <td width=""><?php echo $i;?></td>
                    <td id="result<?php echo $obj->Id_0;?>"><?php $BL = json_decode($obj->Results_13); echo $BL->receiptSerial.' '.$BL->receiptNumber;?></td>
                    <td width=""><?php echo $obj->Serie_7.' '.$obj->Number_8;?></td>
                    <td width=""><?php echo $obj->Year_5; ?></td>
                    <td ><?php echo number_format($obj->Amount_12,2,".",",");?></td>
                    <td class="text-center"><span id="finacle_result<?php echo $obj->Id_0; ?>" class='text-yellow bold'>Bulletin en attente de validation</span></td>
                    <td align="center" width="" id="pq<?php echo $obj->Id_0;?>">
                        <a style="cursor: pointer" onclick="view('<?php echo $obj->Id_0; ?>')"> 
                           <i class="fa fa-fw fa-file-text f20"></i> 
                        </a>
                    </td>
                    <input name="bulletin_id[]" type="hidden" value="<?php echo $obj->Id_0; ?>">
                </tr>
            <?php $i++;  endforeach;?>
        </tbody>
    </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute;e!</b></h4>
            <br/>
        </div>
    </section>
<?php endif;?>



<script type="text/javascript">
            
      var data = <?= isset($bulletins) ? json_encode($bulletins) : ""; ?> 
      
      if(data=="")
      {
            $('#validate').prop("disabled",true);
            $('#next').prop("disabled",true);
      }
      
            
</script>