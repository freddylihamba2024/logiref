<?php 
$total = 0; $infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_27;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_29;
$cCompte = $encaissement->Account_28;
$taux = $encaissement->Taux_31;
$commission = $encaissement->Commission_26;
$montant = number_format($encaissement->Montant_11,2,","," ");
$integrations = array();
if(isset($comptes['DGDA']['GU']['CDF']))
    $compteG = $comptes['DGDA']['GU']['CDF'];
else $compteG = '00000000000000000000';
$libelle = ' '.$encaissement->Beneficaire_15.' '.$infos['serial'].' '.$infos['serie'].' '.$encaissement->Designation_14.' '.$encaissement->Nif_13;
if($mode == '7' || $mode == '8'){
    
        if(isset($comptesbanks[$banque]['CCV']['CDF']))
            $compteCCV = $comptesbanks[$banque]['CCV']['CDF'];
        else $compteCCV = '00000000000000000000';
        
         if(isset($comptesbanks[$banque]['CPU']['USD']))
            $compteCPU = $comptesbanks[$banque]['CPU']['USD'];
        else $compteCPU = '00000000000000000000';
        
        
        if(($cDevise != $pDevise) &&  $pDevise=="CDF")
        {
                
                if($CFBdevise !="CDF"):
                    
                        $dMontant =  $encaissement->Montant_11  / $taux;
                        $instruction = array('sens'=>'D', 'compte'=>$cCompte, 'libele'=>$libelle, 'montant'=> $cDevise.' '.number_format($dMontant,2,","," "));
                        $integrations[]= $instruction;
                        
                        $instruction = array('sens'=>'C', 'compte'=>$compteCPU, 'libele'=>$libelle, 'montant'=> $cDevise.' '.number_format($encaissement->Montant_11,2,","," "));
                        $integrations[]= $instruction;
                        
                        if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                            $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                        else $compteCFB = '00000000000000000000000';
                        $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Commission'.$libelle, 'montant'=>$CFBdevise.' '.$commission);
                        $integrations[]= $instruction;
                        
                        if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                            $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                        else $compteTVA = '00000000000000000000';
                        $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=>$CFBdevise.' '.($commission * $this->tva));
                        $integrations[]= $instruction;
                        
                else:
                    
                        $dMontant =  ($encaissement->Montant_11 + $commission) / $taux;
                        $instruction = array('sens'=>'D', 'compte'=>$cCompte, 'libele'=>$libelle, 'montant'=> number_format($dMontant,2,","," "));
                        $integrations[]= $instruction;
                        
                        $instruction = array('sens'=>'C', 'compte'=>$compteCPU, 'libele'=>$libelle, 'montant'=> $dMontant);
                        $integrations[]= $instruction;
                        
                        if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                            $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                        else $compteCFB = '00000000000000000000000';
                        $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Commission'.$libelle, 'montant'=>$commission);
                        
                        if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                            $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                        else $compteTVA = '00000000000000000000';
                        $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=>$commission * $this->tva);
                        $integrations[]= $instruction;
                  
                endif;
               
                $integrations[]= $instruction;
                $instruction = array('sens'=>'D', 'compte'=>$compteCCV, 'libele'=>$libelle, 'montant'=>'CDF '.($encaissement->Montant_11 + $commission));
                $integrations[]= $instruction;
                
                if(isset($comptes['DGDA']['GU'][$pDevise]))
                    $compteG = $comptes['DGDA']['GU'][$pDevise];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$pDevise.' '.$encaissement->Montant_11);
                $integrations[]= $instruction;
           
        }
        else if(($cDevise != $pDevise) &&  $pDevise !="CDF")
        {
                $dMontant =  ($encaissement->Montant_11 + $commission) * $taux;
                $instruction = array('sens'=>'D', 'compte'=>$cCompte, 'libele'=>$libelle, 'montant'=> $dMontant);
                $integrations[]= $instruction;
                
                if(isset($comptes['DGDA']['GU'][$pDevise]))
                    $compteG = $comptes['DGDA']['GU'][$pDevise];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$encaissement->Montant_11);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                    $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                else $compteCFB = '00000000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Commission'.$libelle, 'montant'=>$commission);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                    $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                else $compteTVA = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=>$commission * $this->tva);
                $integrations[]= $instruction;
        }
        else if(($cDevise == $pDevise) &&  $pDevise=="CDF")
        {
                $dMontant =  ($encaissement->Montant_11 + $commission) * $taux;
                $instruction = array('sens'=>'D', 'compte'=>$cCompte, 'libele'=>$libelle, 'montant'=> $dMontant);
                $integrations[]= $instruction;
                
                if(isset($comptes['DGDA']['GU']['CDF']))
                  $compteG = $comptes['DGDA']['GU']['CDF'];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$encaissement->Montant_11);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                    $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                else $compteCFB = '00000000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Commission'.$libelle, 'montant'=>$commission);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                    $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                else $compteTVA = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=>$commission * $this->tva);
                $integrations[]= $instruction;
        }
        else if(($cDevise == $pDevise) &&  $pDevise=="USD")
        {
                $dMontant =  ($encaissement->Montant_11 + $commission) * $taux;
                $instruction = array('sens'=>'D', 'compte'=>$cCompte, 'libele'=>$libelle, 'montant'=> $dMontant);
                $integrations[]= $instruction;
                
                if(isset($comptes['DGDA']['GU']['USD']))
                  $compteG = $comptes['DGDA']['GU']['USD'];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$encaissement->Montant_11);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                    $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                else $compteCFB = '00000000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Commission'.$libelle, 'montant'=>$commission);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                    $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                else $compteTVA = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=>$commission * $this->tva);
                $integrations[]= $instruction;
        }
        
       
        
       
       
}else{   
 
        
       
        if(($cDevise == $pDevise) && $pDevise=="CDF")
        {
               
                if(isset($comptes['DGDA']['GU']['CDF']))
                    $compteG = $comptes['DGDA']['GU']['CDF'];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$pDevise.' '.$encaissement->Montant_11);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                    $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                else $compteCFB = '00000000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Frais bancaire'.$libelle, 'montant'=>$commission);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                    $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                else $compteTVA = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=> $commission * $this->tva);
                $integrations[]= $instruction;
        }
        else if(($cDevise == $pDevise) && $pDevise=="USD")
        {
             if(isset($comptes['DGDA']['GU']['USD']))
                    $compteG = $comptes['DGDA']['GU']['USD'];
                else $compteG = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteG, 'libele'=>$libelle, 'montant'=>$pDevise.' '.$encaissement->Montant_11);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['CFB'][$CFBdevise]))
                    $compteCFB = $comptesbanks[$banque]['CFB'][$CFBdevise];
                else $compteCFB = '00000000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteCFB, 'libele'=>'Frais bancaire'.$libelle, 'montant'=>$commission);
                $integrations[]= $instruction;
                
                if(isset($comptesbanks[$banque]['TVA'][$CFBdevise]))
                    $compteTVA = $comptesbanks[$banque]['TVA'][$CFBdevise];
                else $compteTVA = '00000000000000000000';
                $instruction = array('sens'=>'C', 'compte'=>$compteTVA, 'libele'=>'TVA'.$libelle, 'montant'=> $commission * $this->tva);
                $integrations[]= $instruction;
        }

}

?>
<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', true); ?>
    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => 'view')); ?>
    <div class="box-body box-solid no-padding">
            <input type="hidden" name="Paiementid" value="<?php echo $bulletin->Id_0; ?>">
            <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
            <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
            <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
            <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11; ?>" />
            <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
            <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
            <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
            <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
            <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
            <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25; ?>" />
            <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
            <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
            <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
            <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
            <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
            <input type="hidden" name="Infos[Nifdeclarant]" value="" />
            <input type="hidden" name="Infos[agence]" value="<?= isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
            <input type="hidden" name="Infos[standard]" value="<?= isset($infos['standard']) ? $infos['standard'] : ""; ?>" />
            <input type="hidden" name="Infos[moyen]" value="<?= isset($infos['moyen']) ? $infos['moyen'] : ""; ?>" />
            <input type="hidden" name="Infos[taxesPaid]" value="<?= json_encode($infos['taxesPaid']); ?>" />
            <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
            <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28; ?>" />
            <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Notedevise_29; ?>" />
            <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13; ?>" />
            <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
            <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
            <input type="hidden" name="Commission_26" value="<?php echo $encaissement->Commission_26; ?>" />
            <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27; ?>" />
            <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
            <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32; ?>" />
            <?php if($encaissement->Mode_19 == 7 || $encaissement->Mode_19 == 8):?>
                <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34; ?>" />
            <?php endif; ?>
            <?php if(isset($infos) && !empty($infos)) { ?><input type="hidden" name="Paiementid" value="<?= isset($infos['Paiementid']) ? $infos['Paiementid'] : "";?>" /><?php } ?>
        <div class="col-md-12 no-padding">
            <div class="col-md-12">
                <br/><br/>
            </div>
            <div id="messages" class="col-md-12"></div>
            <div class="col-md-6">
                <div class="input-group ">
                    <label for="office">Designation</label>
                    <?php echo $encaissement->Designation_14; ?>
                </div>
                <div class="input-group ">
                    <label for="office">Num&eacute;ro imp&ocirc;t</label>
                    <?php echo $encaissement->Nif_13; ?>
                </div>
                <div class="input-group ">
                    <label for="office">Compte client</label>
                    <?php echo $cCompte.' '.$cDevise; ?>
                </div>
                <div class="input-group ">
                    <label for="office">Mode</label>
                    <?php echo (isset($modes[$encaissement->Mode_19]))?$modes[$encaissement->Mode_19]:""; ?>
                </div>
                <div class="input-group ">
                    <label for="office">ID</label>
                    <?php echo $encaissement->Id_0;?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="input-group ">
                    <label for="office">Bureau</label>
                    <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                </div>
                <div class="input-group ">
                    <label for="office">Declarant</label>
                    <?php echo $bulletin->Agent_10; ?>
                </div>
                <div class="input-group ">
                    <label for="office">Montant total</label>
                    <?php echo 'CDF '.number_format($encaissement->Montant_11,2,","," "); ?>
                </div>
                <div class="input-group ">
                    <label for="office">Commission</label>
                    <?php echo $encaissement->Devise_27.' '.number_format($encaissement->Commission_26,2,","," "); ?>
                </div>
                <div class="input-group ">
                    <label for="office">Reference</label>
                    <?php echo $encaissement->Logirefid_4;?>
                </div>
            </div>
        </div>
        <div class="col-md-12 bTop">
            <br/><label>Comptabilisation</label><br/>
        </div>
        <div class="col-md-12"><br></div>
        <div class="col-md-12">
            <table id="table" class="table table-hover table-striped">
                <thead class="">
                    <tr class="bg-blue">
                        <th width="100px">Titulaire</th>
                        <th width="200px">Compte</th>
                        <th width="100px">Taxe</th>
                        <th width="">Montant</th>
                        <th width="100px">Op&eacute;ration</th>
                        <th width="250px">Libell&eacute;</th>
                        <th width="100px">Cat&eacute;gorie</th>
                    </tr>
                </thead>
                <tbody class="">
                    <?php foreach($integrations as $row) :?>
                    <?php extract($row);?>
                    <tr class="<?php if($compte =='00000000000000000000000') echo 'text-red'; ?> ">
                        <td width="100px"><?php echo ' '.$this->session->userdata('account_business').' '; ?></td>
                        <td width="200px"><?php echo $compte;?></td>
                        <td width="100px"> - </td>
                        <td><?php echo $montant;?></td>
                        <td width="100px"><?php echo $sens;?></td>
                        <td width="250px"><?php echo $libele;?></td>
                        <td width="100px"> - </td>
                    </tr>
                   <?php endforeach;?>
                   <tr>
                       <td colspan="7"> - Cl&eacute;s de repartition</td>
                    </tr> 
                   <?php foreach($infos['taxesPaid'] as $taxe) :?>
                        <tr class="<?php if(!isset($beneficiaires[$taxe->taxeCode])){ echo "text-red";}?> ">
                            <td width="100px"><?php echo (isset($beneficiaires[$taxe->taxeCode]))? $beneficiaires[$taxe->taxeCode]:$taxe->taxeCode ;?></td>
                            <td width="200px" class="<?php if($comptesTaxes[$taxe->taxeCode]=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $comptesTaxes[$taxe->taxeCode];?></td>
                            <td width="100px"><?php echo $taxe->taxeCode;?></td>
                            <td ><?php echo 'CDF '.number_format($taxe->taxeAmount,2,","," ");?></td>
                            <td width="100px"><?php echo "C";?></td>
                            <td width="250px"><?php echo $taxe->taxeDescription;?></td>
                            <td width="100px"><?php echo(isset($typeRecette[$taxe->taxeCode]) && $typeRecette[$taxe->taxeCode] =="TRESOR") ? "Tr&eacute;sor" :"Hors Tr&eacute;sor" ; ?></td>
                        </tr>
                    <?php $total = $total + $taxe->taxeAmount; endforeach;  ?>
                    <tr class="">
                        <td width="100px">[+]</td>
                        <td width="200px"></td>
                        <td width="100px"><b>TOTAL</b></td>
                        <td><b><?php echo 'CDF '.number_format($total,2,","," "); ?></b></td>
                        <td width="100px"></td>
                        <td width="250px"></td>
                        <td width="100px"></td>
                    </tr>
                </tbody>    
            </table>
        </div>
        <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
        <div class="col-md-12" id="Comptabilisation" class=""></div>
    </div>
    <div class="box-footer clearfix" id="block">
        <button id="confirmform" type="submit" class="btn <?php if($role == '3' && $bulletin->Status_2 == 1) echo 'btn-primary'; else echo 'btn-default'; ?>  pull-left" <?php echo($role != '3')? 'disabled' : '' ; ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
        <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>&nbsp;&nbsp;
        <button type="button" id="printA" <?php echo($bulletin->Status_2 == '3')? '' : 'disabled'; ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
        <button type="button" id="pquittance" <?php echo($bulletin->Status_2 == '3' && $bulletin->Pdfcontent_18 == "")? '' : 'disabled'; ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
    </div>
    <?php echo form_close(); ?>
    <?php $this->chtml->box_body_closing(); ?>
</div>
<script type="text/javascript">
var ref = '<?php echo $encaissement->Logirefid_4; ?>'; 
logiref_id = '';
$("#mainform").submit(function(event){
    event.preventDefault();
    var data = $(this).serialize();
    submiter(data);
});

function submiter(data){
        $("#messages").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bulletin/save/comptant'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        $('#messages').html('');
                        if(result === "E406")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $('#messages').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#confirmform').prop("disabled",true);
                                comptabilisation(result.logiref_4);
                                logiref_id = result.logiref_4;
                                $('#printA').prop("disabled",false);
                                $('#pquittance').prop("disabled",false);
                                $('#line'+id).remove();
                                $('#block').html();
                               
                        }
                        
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}   
    
    
function comptabilisation(ref){
        $("#message").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

$("#cancel").click(function(){
   location.reload(true);
});

$("#pquittance").click(function(){
        $("#messages").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#messages").html('');
        var button = $(this).html();
        $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
        var paiementid = '<?= isset($infos['Paiementid']) ? $infos['Paiementid'] : "" ?>';
        var url = '<?php echo base_url($module.'/bank/display/getquittance'); ?>/' + paiementid;
       
        $.ajax({    
                type        : 'POST', 
                url         : url, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        
                    $(this).prop("disabled", false);
                    $('#pquittance').html(button);
                    $('#messages').html('');
                    
                    if(result === "E003")
                    {
                            $('#messages').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#messages').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E22")
                    {
                            $('#messages').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E11")
                    {
                            $('#messages').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E002")
                    {
                            $('#messages').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E001")
                    {
                            $('#messages').html('<div class="alert alert-warning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E003")
                    {
                            $('#messages').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E005")
                    {
                            $('#messages').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E404" || result ==="E41")
                    {
                        $("#messages").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                        printQuittance(result);
                    }
                        
                },
                error:function(error){
                    alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
        });
    
});

$("#quittancedd").click(function(){

       var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url); 
        
});

$("#printA").click(function(){
       
        $('#enregistrer').prop("disabled",true);
        
        var url = '<?php echo base_url($module.'/bank/data/attestationbl'); ?>/' + logiref_id;
        
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});
</script>