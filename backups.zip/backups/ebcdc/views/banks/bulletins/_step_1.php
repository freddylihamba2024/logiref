    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="loader1"></div>
        <div class="col-md-12">
            <?php 
            if(isset($bulletin->Id_0) && $bulletin->Id_0!='' && $bulletin->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de taitement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}
            ?>
            <h1>Bulletin de liquidation</h1>
            
            <p class="page-header">Traitement des bulletins de liquidation</p>     
        </div>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification du Bulletin<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Validation<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/>
            <div id="loader"></div>
			<div id="alert"></div>
        </div>
        <div id="pager">
            <?php if($step == 1 || $step == 2 ):?>
                <?php $this->load->view('_step_2'); ?>
            <?php elseif($step == 3):?>
                
                <?php $this->load->view('_step_1'); ?>
            <?php else:?>
                <div class="col-md-12">
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <?php $this->chtml->box_body_opening('', true);?>
                    
                    <div class="col-md-8 bRight">
                        <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
                        <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
                            <div class="box-body">
                                <div class="col-md-12">
                                    <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="Service_16">Bureau (ou service)</label> 
                                        <?php echo form_dropdown('Office',$services['DGDA'],isset($bulletin->Office_6) ? $bulletin->Office_6 : "", 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="year">Ann&eacute;e</label> 
                                        <?php echo form_input('Year',isset($bulletin->Year_5 ) ? $bulletin->Year_5 : "2021", 'class="form-control" id="year" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="year">Banque</label> 
                                        <?php echo form_input('Bank',isset($bulletin->Bank_11) ? $bulletin->Bank_11 : "11", 'class="form-control bg-gray" id="year" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                        <?php echo form_input('Nif',isset($bulletin->Nif_9) ? $bulletin->Nif_9 : "" , 'class="form-control" id="company" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                       <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                        <?php echo form_input('Agent',isset($bulletin->Agent_10) ? $bulletin->Agent_10 : "0000", 'class="form-control" id="declarant" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="assessment_serial">S&eacute;rie</label>
                                        <?php echo form_input('Series',isset($bulletin->Serie_7) ? $bulletin->Serie_7: "L", 'class="form-control" id="assessment_serial" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="assessment_number">Num&eacute;ro du bulletin</label>
                                        <?php echo form_input('Number',isset($bulletin->Number_8) ? $bulletin->Number_8: "", 'class="form-control" id="assessment_number" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Montant_11">Montant &agrave; payer</label>
                                        <?php echo form_input('Amount',isset($bulletin->Amount_12) ? $bulletin->Amount_12 : "", 'class="form-control" id="amount" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="devise">Devise</label>
                                        <?php echo form_dropdown('devise', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27 : "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                        <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="Mode">Mode</label> 
                                        <?php echo form_dropdown('Mode', $modes, isset($bulletin->Mode_30) ? $bulletin->Mode_30 : "", 'class="form-control" required="required" id="modeId"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="assessment_number">Date liquidation</label>
                                        <?php echo form_input('DateL','', 'class="form-control" id="datepicker1" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="Account" id="accountname">Compte du client &agrave; d&eacute;biter</label> <span id="taxinfo" class="text-red"></span>
                                        <?php echo form_input('bank_account',isset($bulletin->Account_28) ? $bulletin->Account_28 : "", 'class="form-control" id="bank_account" placeholder="E.g: 0000100002000030000400005" required="required" '); ?>
                                        <input type="hidden" name="account_name" value="" id="account_name">
                                        <input type="hidden" name="tax_info" value="" id="tax_info">
                                        <input type="hidden" name="account_currency" value="" id="account_currency">
                                        <input type="hidden" name="account_balance" value="" id="account_balance">
                                        <input type="hidden" name="lien_id" value="" id="lien_id">
                                        <input type="hidden" name="date_lien" value="" id="date_lien">
                                        <input type="hidden" name="tarif" value="" id="tarif">
                                        <input type="hidden" name="internal_account" value="" id="internal_account">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="Devise_account">Devise de ce compte</label>
                                        <?php echo form_dropdown('Devise_account', $devises, isset($bulletin->Devise_29) ? $bulletin->Devise_29 : "", 'class="form-control" required="required" id="account_devise" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-7 hidden" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux de change :</b> <span id="exchange_message"></span></div>
                                <input type="hidden" name="exchange_rate" value="" id="exchange_rate" >
                                <div class="col-md-12"></div>
                                
                                <input type="hidden" name="tva"  value="1" id="tva">
                                <input type="hidden" name="fraisbcc" value="1" id="fraisbcc">
                                
                            </div>
                            <div id="details" class="col-md-12"></div>
                            <div class="box-footer clearfix">
                                <div class="col-md-12">
                                    <button type="submit" id="createLien" class="btn btn-default" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;
                                    <button type="submit" id="save" class="btn btn-success hidden"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;
                                    <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <input type="hidden" name="action" value="" id="action">
                                    <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                                    <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
                                </div>
                            </div>
                    </div>
                    <div class="col-md-4 no-padding " id="treatment">
                        
                    </div>
                    
                    <?php $this->chtml->box_body_closing(); ?> 
                    <?php echo form_close(); ?>
                </div>
            <?php endif;?>
        </div>
    </div>
    <div class="col-md-1 content">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

var bl_treated = false;

$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});

$('#amount').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#coms", function(){
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#createLien").click(function(){
        $("#action").val('createLien');
});

$("#confirm").click(function(){
        $("#action").val('confirmer');
});

$("#save").click(function(){
        $("#action").val('enregistrer');
});

$("#treat").click(function(){
        $("#action").val('traiter');
});
$("#releaseLien").click(function(){
        $("#action").val('releaseLien');
});

$('.chosen-select').chosen({width: "100%"});
   
$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        if(action == 'traiter')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bulletin/display/verification'); ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'json', 
                    encode      : true,
                    success: function(result){
                        
                        if(result.code === "E34")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E13" || result.code === "E003")
                        {
                                disable_buttons();
                                $('#loader').html(result.message);
                        }
                        else if(result.code === "E22")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucune declaration trouv&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E11")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E404")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E405")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E406")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E000")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E15")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E18")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E21")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E411")
                        {
                                disable_buttons();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; amplitude, survenu lors de la recup&eacute;ration de la balance du compte du client<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "OK")
                        {
                                get_details(result.data);
                        }
                        else
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: Aucun bulletin trouv&eacute; avec les informations saisies, veuillez v&eacute;rifier les informations renseign&eacute;es s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    },
                    error:function(error)
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }
        else if(action == 'createLien')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                get_reservation(data);
        }
        else if(action == 'enregistrer')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                create_bulletin(data);
        }
        else if(action == 'confirmer')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                next_step(data);
        }
        else if(action == 'releaseLien')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                cancel_reservation();
        }
});

$("#balance").css('background-color','#00cc33');

$("#cancel").click(function(){
        location.reload(true);
});
   
$("#close").click(function(){
        location.reload(true);
});


$("#bank_account").change(function(){
    get_account_tariff();
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            $('#internal_account').val(compte);
            $('#internal_account').prop('disabled', false);
            get_accountname_internal();
            
            if(bl_treated)
            {
                    $("#createLien").addClass('hidden');
                    $("#save").removeClass('hidden');
                    $("#save").removeClass('btn-default');
                    $("#save").addClass('btn-success');
            }
    }
    else
    {
            $('#internal_account').prop('disabled', true);
            get_accountname();
            
            if(bl_treated)
            {
                    $("#createLien").removeClass('hidden');
                    $("#save").addClass('hidden');
                    $("#createLien").removeClass('btn-default');
                    $("#createLien").addClass('btn-success');
            }
    }
});

$("#account_devise").change(function(){
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    } 
    get_exchange_rate();
});

function disable_buttons()
{
    $("#createLien").prop('disabled', true);
    $("#save").prop('disabled', true);
}

function get_details(data)
{
    var url ="<?php echo base_url($module.'/bulletin/display/step_1_details'); ?>/";

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result){

            if(result == 'E411')
            {
                $('#loader').html('<div class="alert alert-danger text-white">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaÃ®t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else
            {
                var response  = check_internal_account();
                bl_treated = true;
                
                if(response == true)
                {
                    $('#loader').html('');
                    $("#createLien").addClass('hidden');
                    $("#save").removeClass('hidden');
                    $("#save").removeClass('btn-default');
                    $("#save").addClass('btn-success');
                    $("#save").prop('disabled', false);
                    $("#createLien").prop('disabled', false);
                    $('#treatment').html(result);
                }
                else
                {
                    $('#loader').html('');
                    $("#createLien").removeClass('btn-default');
                    $("#createLien").addClass('btn-success');
                    $("#createLien").prop('disabled', false);
                    $("#save").addClass('hidden');
                    $('#treatment').html(result);
                }  
            }
        },
        error:function(error)
        {
            $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}
function check_internal_account()
{
        var comptes = $("#bank_account").val();
        if(comptes.length == 14)
        {
                return true;
        }
        else
        {
                return false;
        }   
}
function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function get_accountname_internal()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function get_account_tariff()
{
        var compte = $('#bank_account').val();
        var regie = 'DGDA';
        var url = '<?php echo base_url($module.'/accounts/data/get_account_tarification'); ?>';
        if(compte !== '')
        {  
                $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, regie : regie}, 
                        dataType    : 'json', 
                        encode      : true,
                        success: function(reponse)
                        {
                            
                                if(reponse.commission >= 0)
                                {
                                        $("#fraisbcc").val(reponse.fraisbcc);
                                        $("#tva").val(reponse.tva);
                                        
                                        if (reponse.commission > 0)
                                        {
                                            $("#tarif").val(reponse.commission);

                                            var commissions = $("#tarif").val(reponse.commission);
                                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                                        }
                                }
                          
                        },
                        error:function(error)
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }   
                });  
        }
        else
        {
                
        }
}
function get_reservation(data)
{
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var montant = $('#amount').val();
        var Office = $('#Service_16').val();
        var Number = $('#assessment_number').val();
        var Series = $('#assessment_serial').val();
        var Nif = $('#company').val();
        var Year = $('#year').val();
        
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/data/get_reservation'); ?>';
        
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, montant : montant, Office: Office, Year: Year, Number: Number, Nif:Nif, Series: Series}, 
                    dataType    : 'json',  
                    encode          : true,
                    success: function(response)
                    {	
                            $("#loader").html('');
                            
                            if(response.code == '200')
                            {
                                    $('#loader').html('<div class="alert alert-info text-white"> Paiement enregistr&eacute; avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#createLien").addClass('hidden');
                                    $("#confirm").removeClass('hidden');
                                    $("#save").addClass('hidden');
                                    $("#save").prop('disabled', false);
                                    $("#treat").prop("disabled", true);
                                    create_bulletin(data, "reservation");

                            }
                            else if(response.code =='E500')
                            {
                                    $('#loader').html('<div class="alert alert-info text-white"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin, veuillez contacter le validateur pour la confirmation de ce paiement<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#createLien").addClass('hidden');
                                    $("#treat").addClass('hidden');
                                    $("#confirm").removeClass('hidden');
                                    $("#releaseLien").removeClass('hidden');
                                    
                                    $("#bulletin_id").val(response.id);
                                    $("#confirm").prop('disabled', false);
                                    $("#confirm").prop('disabled', false);
                            }
                            else if(response.code == 'E008')
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white"> Il y a d&eacute;j&agrave; une reservation de fonds sur ce compte, veuillez contacter le gestionnaire du compte <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(response.code == 'E162')
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">Ce compte n\'existe pas.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(response.code == 'E4348')
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">La r&eacute;servation de fonds n\'est pas autoris&eacute; pour ce compte.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}

function create_bulletin(data, type=null)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bulletin/display/create_bulletin'); ?>/'+type;
        
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {	
                            if(type != null)
                            {
                                    $('#loader').html('<div class="alert alert-info text-white"> Paiement enregistr&eacute; avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    if(response > 0)
                                    {
                                            $('#loader').html('<div class="alert alert-info text-white"> L\'enregistrement fait avec succ&egrave;s, veuillez contacter le validateur pour la condirmation de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            $("#save").prop('disabled', true);
                                            $("#treat").prop('disabled', true);
                                    }
                                    else
                                    {
                                            $('#loader').html('<div class="alert alert-info text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                            }
                    },
                    error:function(error)
                    {
                            $('#message').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}
function cancel_reservation()
{
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var bulletin_id = $('#bulletin_id').val();
        
        var url = '<?php echo base_url($module.'/accounts/data/cancel_reservation'); ?>';
        
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { compte : compte, devise : devise, bulletin_id : bulletin_id}, 
                    dataType    : 'html',  
                    encode          : true,
                    success: function(response)
                    {
                            if(response == '200')
                            {
                                    $('#loader').html('<div class="alert alert-info text-white">La r&eacute;servation de fonds annul&eacute;e avec succÃ¨s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#confirm").prop('disabled', true);
                                    $("#releaseLien").prop('disabled', true);
                            }
                            else
                            {
                                    $('#loader').html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            $("#enregistrer").prop('disabled', false);
                    },
                    error:function(error)
                    {
                        $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
        });
}

function get_exchange_rate()
{
        var devise = $('#account_devise').val();
        var devise_recette = $('#recetteDevise').val();
        var account = $('#bank_account').val();
        
        $('#exchange_bloc').removeClass('hidden');
        
        $("#exchange_message").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                
        var url = '<?php echo base_url($module.'/rates/data/get_taux'); ?>';
        
        $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { devise_compte : devise, devise_recette : devise_recette, account : account}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
				
                                if(reponse.code == '200')
                                {
                                        $("#exchange_rate").val(reponse.rate);
                                        $("#exchange_message").css('color', 'green');
                                        $("#exchange_message").html(reponse.rate+" CDF");
                                        
                                        taux = reponse.rate;
                                        exchange_changes();
                                }
                                else if(reponse.code == '0003')
                                {
                                        $("#exchange_message").css('color', 'red');
                                        $("#exchange_message").html('Probl&egrave;me de connexion &agrave; Finacle, le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                }); 
}

</script>
