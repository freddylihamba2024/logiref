<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', false); ?>
    <div class="box-body box-solid no-padding">
        <?php  echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table no-margin table-striped table-bordered">
                        <thead class='bg-blue'>
                            <tr>
                                <th width="10px">#</th>
                                <th >D&eacute;signation</th>
                                <th >Num&eacute;ro imp&ocirc;t</th>
                                <th >Nombre d'articles</th>
                                <th >Bureau</th>
                                <th >Code banque</th>
                                <th >Num&eacute; quittance</th>
                                <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php   
                                $i = 1;
                                foreach($declarations as $row){ 
                            ?>
                                <tr>
                                    <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                    <td width="30%"><?php echo $row->Designation_8 ?></td>
                                    <td><?php echo $row->Nif_9 ?></td>
                                    <td><?php echo $row->Nombrearticles_14 ?></td>
                                    <td><?php echo $row->Codebureau_10 ?></td>
                                    <td><?php echo $row->Codebank_16?></td>
                                    <td><?php echo $row->Numquittance_17 ?></td>
                                    <td>
                                        <a style="cursor: pointer" onclick="view('<?php echo $row->Id_0; ?>')"> 
                                            <i class="fa fa-edit f20"></i> 
                                        </a>
                                    </td>
                                </tr>
                                
                                
                            <?php 
                            $i++;
                                } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        <?php echo form_close(); ?> 
    </div>
    <?php $this->chtml->box_body_closing(); ?> 
</div>

<div class="modal fade" id="modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Articles de la d&eacute;claration</h4>
          </div>
          <div id="modal-pager" class="modal-body">
            <p>One fine body&hellip;</p>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
</div>

<div class="col-md-12">
   
</div>
<script type="text/javascript">
$("#extractform").submit(function(event){
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
}); 

function view(bId)
{
        var url = '<?php echo base_url($module.'/bank/display/declaration_detail'); ?>/' +bId ;
        $.get(url, function(data, status){
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
}


</script>





