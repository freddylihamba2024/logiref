<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

?>
<div class="col-md-12">
    <div class="col-md-12">
        <h1>Bulletin de liquidation</h1>
        <p class="page-header">Extraction des bulletins par lot</p>     
    </div>
    <div class="col-md-12">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Saisie<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound <?php if($step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Traitement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step == 2){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Confirmation<br/></div>
        </div>
    </div>
    <div class="col-md-12"><br/>
        <div id="loader1"></div>
    </div>
    <div id="panel">
        <div class="col-md-12">
            <?php  echo form_open_multipart('', array('id' => 'extractform', 'class' => 'innovate')); ?>
                <?php $this->chtml->box_body_opening('', false);  ?>
                    <div class="box-body">
                        <div class="col-md-6">
                            <div class="col-md-12">
                                <div class="form-group">
                                   <label for="office">Bureau</label> 
                                    <?php echo form_dropdown('office', $services['DGDA'], '201B', 'class="form-control chosen-select" id="office" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="agent">Num&eacute;ro du d&eacute;clarant</label> 
                                    <?php echo form_input('agent','0000', 'class="form-control" id="agent" required = "required"'); ?>
                                </div>
                                <div class="form-group">
                                    <label for="agent">Banque</label> 
                                    <?php echo form_input('bank','1130', 'class="form-control" id="bank" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Nif">Num&eacute;ro d'imp&ocirc;t</label> 
                                    <?php echo form_input('Nif','', 'class="form-control" id="Nif" placeholder="A0700395N" required = "required"'); ?>
                                </div>
                               <div class="form-group">
                                    <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                        <label for="Nif">Lot des bulletins</label> 
                                        <input type= "file" name="attachement" value="" class="input-document form-control" required = "required"/>
                                    </div>   
                                </div>
								<label>Paie TVA&nbsp;<input type="checkbox" name="tva" checked value="<?= 1?>"><span class="text-red" id="taxinfo"></span></label>
                            </div>
                        </div>
                        <div class="col-md-6 bLeft">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="mode">Mode de paiement</label> 
                                    <?php echo form_dropdown('mode',$modes ,'', 'class="form-control" id="mode" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cdevise">Taux</label> 
                                    <?php echo form_input('Taux',set_value('Taux', $taux['Dollar_4']), 'class="form-control" '); ?>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="account" id="accountname">Compte &agrave; d&eacute;biter</label> 
                                    <?php echo form_input('account','', 'class="form-control" id="account" required = "required"'); ?>
                                    <input type="hidden" value="" name="account_name" id="account_name"  />
                                    <input type="hidden" value="" name="account_type" id="account_type"  />
                                    <input type="hidden" value="" name="account_balance" id="account_balance"  />
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cdevise">Devise</label> 
                                    <?php echo form_dropdown('cdevise',$devises, 'CDF', 'class="form-control" id="cdevise" disabled'); ?>
                                    <input type="hidden" value="CDF" name="cdevise"  />
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="ref">R&eacute;f&eacute;rence de l'OP / EV</label> 
                                    <?php echo form_input('ref','', 'class="form-control" id="ref" required = "required"'); ?>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 box-footer clearfix">
                        <div class="col-md-12">
                            <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-angle-down"></i>&nbsp;&nbsp;Continuer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>
                        </div>
                    </div>
                <?php $this->chtml->box_body_closing(); ?>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('.chosen-select').chosen({width: "100%"});
$("#extractform").submit(function(event){
        event.preventDefault();
        var data = new FormData(this);
        next_step(data);
}); 

$("#buttonCloseModal").click(function(){
        location.reload(true);
});


$("#account").change(function(){
    
    var compte = $("#account").val();
    
    if(compte.length == 14)
    {
            $("#account_type").val('internal_account');
            get_accountname_internal();
    }
    else
    {
            $("#account_type").val('current_account');
            get_accountname();
    }
});

$("#cdevise").change(function(){
    
    var compte = $("#account").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    } 
    
});

$(".input-document").change(function (){
        var f = (this).files[0];
        var name = (this).files[0].name;
        var ext = (this).files[0].type;
        console.log(ext);
        if (f.size > 1388608 || f.fileSize > 1388608)
        {
                //show an alert to the user
                $(".fileinput-filename").html("<span class='text-danger'><i class='fa fa-times'></i> La taille du fichier doit &ecirc;tre inf&eacute;rieur &agrave; 1 m&eacute;ga </span>");

                //reset file upload control
                this.value = null;
        }
        else
        {
                if(ext == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || ext=="vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    $(".fileinput-filename").html("<span class='text-success'>" + name + " <i class='glyphicon glyphicon-ok'></i></span>");
                }
                else
                {
                    $(".fileinput-filename").html("<span class='text-danger'><i class='fa fa-times'></i> Format du fichier invalide, format autoris&eacute;: pdf, jpeg ou png </span>");
                    this.value = null;
                }
            
        }

})

function next_step(data)
{
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#sub').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>Chargement...</span>');
        var url = '<?php echo base_url($module.'/bulletin/display/batch_step_2'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                contentType : false,
                cache       : false,
                processData :false,
               success: function(result){
                       $('#sub').prop("disabled", false);
                       $('#sub').html(button);
                       $('#loader1').html('');
                       if(result === "E003")
                       {
                               $('#loader1').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E34")
                       {
                               $('#loader1').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E22")
                       {
                               $('#loader1').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E11")
                       {
                               $('#loader1').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E002")
                       {
                               $('#loader1').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E003")
                       {
                               $('#loader1').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E200")
                       {
                               $('#loader1').html('<div class="alert alert-warning text-white">Aucun un fichier trouv&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E202")
                       {
                               $('#loader1').html('<div class="alert alert-warning text-white">Le format du fichier n&apos;est pas valide!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else 
                       {
                            $("#step-1").removeClass('bg-green-active');
                            $("#step-1").addClass('bg-gray');
                            $("#step-2").removeClass('bg-gray');
                            $("#step-2").addClass('bg-green-active');
                            $("#pager").html(result);
                       }
               },
               error:function(error){
                   alert('ERROR! SYDONIA 41.215.253.187 pas disponible...! ');
                   $('#sub').prop("disabled", false);
                   $('#sub').html(button);
               }
       });
}

function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#account').val();
        var devise = $('#cdevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                        
                                        
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

function get_accountname_internal()
{
        var chtml = $("#accountname").html();
        var compte = $('#account').val();
        var devise = $('#cdevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                        }
                                        else
                                        {
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val('0');
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

</script>


