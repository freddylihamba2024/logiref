<?php

if(count($bulletins) > 10)
{
        $nombre_validation = 10;
}
else
{
        $nombre_validation = count($bulletins);
}

?>
<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', true); ?>
        <div class="col-md-3 center padding-2">
            <div class="col-md-12 center">
                <p class="page-header">
                    <br/><br/> Veuillez procéder à l'enregistrement des bulletins de ce lot de paiement, ensuite prenez soin de valider en batch l'ensemble de bulletins affichés dans la liste tout en sachant que la validation se fait par lot de 10 bulletins.
                </p> 
            </div>
        </div>
        <div class="col-md-9 bLeft">
            <div class="row">
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box bg-white">
                        <div class="inner">
                            <span class="f15">Montant total du lot trait&eacute;s</span><br/><br/>
                            <p class="text-blue f18"> <b>CDF <?= isset($total_amount) ? number_format($total_amount,2,","," ") : "0" ?><span id="paiements"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box bg-white">
                        <div class="inner">
                            <span class="f15">Nombre total de bulletins du lot</span><br/><br/>
                            <p class="f18"><b><span id="attente"></span></b> <span class="fa fa-fw text-red fa-filter"> </span><?= isset($bulletins) ? count($bulletins) : 0 ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box bg-white">
                        <div class="inner">
                            <span class="f15">Nombre de validations de bulletins par lot</span><br/><br/>
                            <p class="f18"><b><span id="urgent"></span></b> <span class="fa fa-fw text-red fa-filter"> </span><?= isset($nombre_validation) ? $nombre_validation : 0; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box bg-white">
                        <div class="inner">
                            <span class="f15">Montant total frais bcc du lot</span><br/><br/>
                            <p class="text-green f18"><b>CDF 0<span id="fees"></span></b></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body box-solid no-padding bTop">
                <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => '')); ?>
                
                <div class="box-body" id="zone">
                    <div id="contenter">
                    <?php if(!empty($bulletins)): ?>
                        <table id="tableREN1" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-gray">
                                    <th width="5px">#</th>
                                    <th width="50px">Quittance</th>
                                    <th width="50px">Bulletin</th>
                                    <th width="50px">Ann&eacute;e</th>
                                    <th>Montant</th>
                                    <th width="10px" style="text-align:center;"><i class="fa fa-tasks f20"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i =1; foreach($bulletins as $obj): ?>
                                    <tr  id="line<?php echo $obj->Id_0;?>"> 
                                        <td width=""><?php echo $i;?></td>
                                        <td id="result<?php echo $obj->Id_0;?>"><?php $BL = json_decode($obj->Results_13); echo $BL->receiptSerial.' '.$BL->receiptNumber;?></td>
                                        <td width=""><?php echo $obj->Serie_7.' '.$obj->Number_8;?></td>
                                        <td width=""><?php echo $obj->Year_5; ?></td>
                                        <td ><?php echo number_format($obj->Amount_12,2,".",",");?></td>
                                        <td align="center" width="" id="pq<?php echo $obj->Id_0;?>">
                                            <a style="cursor: pointer" onclick="view('<?php echo $obj->Id_0; ?>')"> 
                                               <i class="fa fa-fw fa-file-text f20"></i> 
                                            </a>
                                        </td>
                                    </tr>
                                    
                                <?php $i++;  endforeach;?>
                                
                            </tbody>
                        </table>
                    <?php else: ?>
                        <section>
                            <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute;e!</b></h4>
                                <br/>
                            </div>
                        </section>
                    <?php endif;?>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button id="save"  type="submit" class="btn btn-success pull-left" ><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="validate" class="btn btn-primary" disabled><i class="fa fa-save"></i>&nbsp; Valider &nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="next" class="btn btn-success hidden" disabled><i class="fa fa-save"></i>&nbsp; Suivant -> &nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="quittance" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>
                    <input type="hidden" name="batch_reference" id="batch_reference" value ="<?= isset($batch_reference) ? $batch_reference : "" ?>" />
                    <input type="hidden" id="action" value="">
                    <input type="hidden" id="bulletin_id" value="<?= isset($bulletins[0]->Id_0) ? $bulletins[0]->Id_0 : ""; ?>">

					<input type="hidden" name="fraisbcc" value="<?= isset($fraisbcc)? $fraisbcc: ''?>" id="">
                    <input type="hidden" name="commission" value="<?= isset($batch_lines->Commission_20) ? $batch_lines->Commission_20 : "" ?>">
                    <input type="hidden" name="devise_commission" value="<?= isset($batch_lines->Devise_21) ? $batch_lines->Devise_21 : "" ?>">
                </div>
                <?php echo form_close(); ?>
                
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?>
   
</div>
<div class="modal fade" id="modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 id='title' class="modal-title">Bulletin de liquidation</h4>
          </div>
          <div id="modal-pager" class="modal-body">
            <p>One fine body&hellip;</p>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
var logirefid =''; 
var ref = '';
$('#tableREN1').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$('#validate').click(function(){
    
    $('#action').val('valider');
    
});

$('#save').click(function(){
    
    $('#action').val('save');
    
});

$('#next').click(function(){
    
    $('#action').val('next');
    
});

$("#buttonCloseModal").click(function(){
        location.reload(true);
});


$("#pager").on("submit", "#mainform", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        var data = $(this).serialize();
        
        var action = $('#action').val();
        
        if(action == 'valider')
        {
                submiter(data);
        }
        else if(action == 'save')
        {
                save(data);
        }
        else if(action == 'next')
        {
                next_data();
        }
        
});

$("#quittance").click(function(){
    
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        var button = $(this).html();
        
        $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
        var paiementid = $('#bulletin_id').val();
        var url = '<?php echo base_url($module.'/bulletin/display/getquittance'); ?>/' + paiementid;
        
        $.ajax({    
                type        : 'POST', 
                url         : url, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        
                    $(this).prop("disabled", false);
                    $('#quittance').html(button);
                    $('#message').html('');
                    
                    if(result === "E003")
                    {
                            $('#message').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#message').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E22")
                    {
                            $('#message').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E11")
                    {
                            $('#message').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E002")
                    {
                            $('#message').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E001")
                    {
                            $('#message').html('<div class="alert alert-warning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E003")
                    {
                            $('#message').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E000")
                    {
                            $('#message').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E005")
                    {
                            $('#message').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E404" || result ==="E41")
                    {
                        $("#message").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                        printQuittance(result);
                    }
                        
                },
                error:function(error){
                    alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
        });
    
});

function view(bId)
{
        var url = '<?php echo base_url($module.'/bulletin/display/_batch_2'); ?>/' + bId;
        $.get(url, function(data, status){
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
}

function next_data()
{
        var batch_reference = $('#batch_reference').val();
        
        $('#validate').prop("disabled",false);
                            
        var url = '<?php echo base_url($module.'/bulletin/display/batch_validation'); ?>/' + batch_reference
        $.get(url, function(data, status){
            $("#contenter").html(data);
        })
}

function save(data){
    
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bulletin/save/save_batch'); ?>';
        scrollUP();
        $('#save').prop("disabled",true);
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html',
                encode          : true,
                success: function(result){
                        
                        if(result=='E500')
                        {
                            $("#loader").html('');
                            $('#loader').html('<div class="alert alert-info text-white">Ce lot des paiements existent d&eacute;j&agrave;, veuillez v&eacute;rifier ces bulletins dans la liste de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(isNaN(result)==true)
                        {   
                            $('#save').prop("disabled",false);
                            $("#loader").html('');
                            $('#loader').html('<div class="alert alert-danger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result > 0)
                        {
                            $("#loader").html('');
                            $('#loader').html('<div class="alert alert-success text-white">Bravo! le lot des bulletins encaiss&eacute;s avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            
                            $('#validate').prop("disabled",false);
                            $('#next').removeClass('hidden');
                            $('#save').addClass('hidden');
                            
                            var batch_reference = $('#batch_reference').val();
                            
                            var url = '<?php echo base_url($module.'/bulletin/display/batch_validation'); ?>/' + batch_reference
                            $.get(url, function(data, status){
                                $("#contenter").html(data);
                            })
                        }
                        else
                        {
                            $('#loader').html('');
                            $('#save').prop("disabled",false);
                            
                            $('#loader').html('<div class="alert alert-danger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function submiter(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bulletin'); ?>/save/validate_batch';
        $('#validate').prop("disabled",true);
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    
                    var result = JSON.parse(result);
                    $("#loader").html('');
                    $.each(result, function(key, value)
                    {
                        if(value.response == '200')
                        {
                            $("#finacle_result"+key).html('<div class="alert alert-success text-white">Bulletin valid&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#next').prop("disabled",false);
                        }
                        else if(value.response === "E162")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire pour ce bulletin n\'existe pas.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "E463")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "E411")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez trouver ce bulletin dans le menu r&eacute;gularisation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "E3238")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce bulletin pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "W0205")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "E397")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce bulletin pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "AD3")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "E9999")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion , veuillez trouver ce bulletin dans le menu r&eacute;gularisation !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "ERR002")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "ERR003") 
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(value.response === "P83")
                        {
                            $('#finacle_result'+key).html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est pas encore autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    });
                    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function printQuittance(file)
{
        var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
        
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>


