<div class="col-md-12">
    <?php  echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
        <?php $this->chtml->box_body_opening('', false);  ?>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table no-margin table-striped table-bordered">
                        <thead class='bg-blue'>
                            <tr>
                                <th width="10px">#</th>
                                <th>Bureau (ou service)</th>
                                <th width="100px">D&eacute;clarant</th>
                                <th width="150px">Num&eacute;ro imp&ocirc;t</th>
                                <th width="200px">S&eacute;rie et num&eacute;ro de s&eacute;rie</th>
                                <th width="100px">Banque</th>
                                <th width="100px">Ann&eacute;e</th>
                                <th>Montant</th>
                                <th>R&eacute;ponse</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($failures as $failure => $bl){ ?>
                                <tr>
                                    <td><?php echo $failure; ?></td>
                                    <td><?php echo form_dropdown('offices[]', $services, $bl['Office'], 'class="form-control itemgrid iwtd" required="required"'); ?></td>
                                    <td><input type="text" value="<?php echo $bl['Agent'];?>" name="agents[]"   class="itemgrid" required="required"/></td>
                                    <td><input type="text" value="<?php echo $bl['Nif'];?>" name="nifs[]"   class="itemgrid" required="required" /></span></td>
                                    <td><input type="text" value="<?php echo $bl['Series'].$bl['Number'] ;?>"  name="serials[]"   class="itemgrid" required="required" /></td>
                                    <td><input type="text" value="<?php echo $bl['Bank'];?>" name="banks[]"   class="itemgrid" required="required" /></span></td>
                                    <td><input type="text" value="<?php echo $bl['Year'];?>" name="years[]"   class="itemgrid" required="required" /></td>
                                    <td><input type="text" value="<?php echo $bl['Amount'];?>" name="amounts[]"   class="itemgrid" required="required" /></td>
                                    <td><input type="text" value="<?php echo $bl['response'];?>" name="response[]"   class="itemgrid" required="required" /></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="box-footer clearfix">
                <button type="submit" style="margin-left:0px;" name="submit" class="btn btn-primary pull-left"><i class="fa fa-edit"></i> Extraire</button>
            </div>
        <?php $this->chtml->box_body_closing(); ?>
    <?php echo form_close(); ?> 
</div>
<script type="text/javascript">
$("#extractform").submit(function(event){
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
}); 


function next_step(data)
{
     $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
       $('#envoyer').prop("disabled", true);
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');
       var url = '<?php echo base_url($module.'/bank/display/extractbls'); ?>';
       $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                       $('#envoyer').prop("disabled", false);
                       $('#envoyer').html(button);
                       $('#loader').html('');
                       if(result === "E003")
                       {
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E34")
                       {
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E22")
                       {
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E11")
                       {
                               $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E002")
                       {
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else if(result === "E003")
                       {
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       }
                       else 
                       {
                               $('#envoyer').prop("disabled", false);
                               $('#envoyer').html(button);
                               $("#pager").html(result);
                               $("#step-1").removeClass('bg-green-active');
                               $("#step-1").addClass('bg-gray');
                               $("#step-2").removeClass('bg-gray');
                               $("#step-2").addClass('bg-green-active');
                       }
               },
               error:function(error){
                   alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                   $('#envoyer').prop("disabled", false);
                   $('#envoyer').html(button);
               }
       });
}

</script>




