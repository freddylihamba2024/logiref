<div class="tScroll">
    <div id="messages"></div>
    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => 'view')); ?>
        <div class="box-body">
            <div class="table-responsive">
                <table class="table no-margin table-striped table-bordered">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="10px">#</th>
                            <th >D&eacute;signation</th>
                            <th >Marque</th>
                            <th >Poids</th>
                            <th >Num&eacute;ro de licence</th>
                            <th width="10px" style="text-align:center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php   
                            $i = 1;
                            if(count($articles) > 1)
                            { 
                                
                                foreach($articles as $row)
                                { 
                        ?>
                            <tr>
                                <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                <td width="30%"><?php echo $row->designArt; ?></td>
                                <td><?php echo $row->mark01; ?></td>
                                <td><?php echo $row->poidsNet; ?></td>
                                <td><?php echo $row->numLicence; ?></td>
                                <td>
                                    <a id="apurer" class="btn btn-warning btn-xs" onclick="apurer('<?php echo $row->numLicence; ?>')" href="#" class="text-green"> Apurer </a>
                                </td>
                            </tr>


                        <?php 
                        $i++;
                                }
                            }
                            else
                            {
                        ?>
                            <tr>
                                <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                <td width="30%"><?php echo $articles->designArt; ?></td>
                                <td><?php echo $articles->mark01; ?></td>
                                <td><?php echo $articles->poidsNet; ?></td>
                                <td><?php echo $articles->numLicence; ?></td>
                                <td>
                                    <a id="apurer" class="btn btn-warning btn-xs" href="#" onclick="apurer('<?php echo $articles->numLicence; ?>')" class="text-green"> Apurer </a>
                                </td>
                            </tr>
                        <?php 
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    <?php echo form_close(); ?>
</div>
<script type="text/javascript">

function apurer(id){
    
    $("#messages").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/bank/display/apurement'); ?>/' + id;
    
    $.get(url, function(result, status){
        $("#messages").html("");
        if(result === "E22")
        {
                $('#messages').html('<div class="alert alert-warning text-white">Alerte: API de la banque pas disponible...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}
   
</script>

