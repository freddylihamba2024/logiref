<?php 

$userid = $this->session->userdata("user_id");
$usertype = $this->session->userdata("user_type");
$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span class="">Total paiements</span><br/><br/>
                        <p class="text-blue f18"> <b>CDF <span id="paiements"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span class="">Total commissions</span><br/><br/>
                        <p class="text-green f18"><b>CDF <span id="commissions"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements en attente</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer" onclick="filter('attente')" ><b><span id="attente"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements urgents</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer" onclick="filter('urgents')" ><b><span id="urgent"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
            <h1>Liste des paiements avec probl&egrave;mes</h1>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements avec probl&egrave;mes.</span></h5>
    </div>
    
    
    <div class="col-md-12">
        <div  id="message"></div>
        
            <?php $this->chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($encaissements) || !empty($bulletins) || !empty($prepayments)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th width="50">Date</th>
                                <th>D&eacute;signation</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th width="50">Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        <?php 
                        #Block last BL
                        foreach($bulletins as $row){ 
                            $agence =  (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                            $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr>
                                <td width="5"><b><?= ++$i;  ?></b></span></td>
                                <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                <td class="text-blue">
                                    <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                </td>
                                <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Status_2==1){ ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_32==$_SESSION['Logiref_agence']){ ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else if($_SESSION['Logiref_role']==4 && (isset($row->Makerid_9) && $row->Makerid_9==$this->session->userdata('user_id'))){ ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else { ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                        <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                <?php }else{ ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                    </td>
                                    <td width="25">
                                        <?php if(file_exists(base_url('api/endpoints/sydonia').'/'.$row->Pdfcontent_18)):?>
                                            <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        <?php else: ?>
                                           <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                        <?php endif; ?>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php 
                           
                        } 
                        ?>
                            
                        <?php
                        
                        #Block last Prepayments
                        foreach($prepayments as $row){ 
                            $agence =  (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - ';
                            $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                            $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr>
                                <td width="5"><b><?= ++$i;  ?></b></span></td>
                                <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?><br>
                                    <span class="text-gray">Bulletin pr&eacute;pay&eacute;</span>
                                </td>
                                <td class="text-blue">
                                    <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                                </td>
                                <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                                <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Status_2==1){ ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_32==$_SESSION['Logiref_agence']){ ?>
                                           <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else if($_SESSION['Logiref_role']==4 && (isset($row->Makerid_9) && $row->Makerid_9==$this->session->userdata('user_id'))){ ?>
                                           <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else { ?>
                                           <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                        <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                <?php }else{ ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                    </td>
                                    <td width="25">
                                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php 
                           
                        } 
                        ?>
                            
                        <?php  
                        #Block DGI et DGRAD
                        foreach($encaissements as $row)
                        { 
                            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr>
                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                <td  width="80" <?php if($row->Status_2==3) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"'; ?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                      <br/>
                                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                    <?php endif;?>
                                </td>
                                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')){ ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else { ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                        <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                <?php }else{ ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php 
                        
                            $paiements = $paiements + $row->Contrevaleur_22;
                            $commissions = $commissions + $row->Commission_23;
                            if($row->Status_2==1 && $row->Checkerid_10==0 && $deadline < gmdate('Y-m-d')) $suspend = $suspend + 1;
                            if($row->Status_2==1 && $row->Checkerid_10==0 && $deadline ==gmdate('Y-m-d')) $urgent = $urgent + 1;
                        } 
                        ?>
                        </tbody>    
                    </table>
                    <?php else:?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                Aucun paiement trouv&eacute;!<br/>
                            </div>
                        </section>
                    <?php endif;?>
                </div>
            <?php $this->chtml->box_body_closing(); ?>
        
    </div>
    
</div>


<script type="text/javascript">

$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');
    
function view(id, regie)
{
    var url ='';
    if(regie === 'DGDA')
    {
            var url ="<?php echo base_url($module.'/equalize/display/bulletin'); ?>/"  + id;
    }
    else if(regie === 'DGI')
    {
            var url ="<?php echo base_url($module.'/equalize/display/declaration'); ?>/"  + id;
    }
    else if(regie === 'DGRAD')
    {
            var url ="<?php echo base_url($module.'/equalize/display/note'); ?>/"  + id;
         
    }
          
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function viewPrepayment(id)
{
   
    var url ="<?php echo base_url($module.'/equalize/display/prepayment'); ?>/"  + id;
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}


function print_payment(pid){

        var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}

</script>