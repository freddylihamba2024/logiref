<?php if($regle->Id_0 > 0) {$title='Modifier';}  else {$title ='Nouvelle r&egrave;gle'; }?>
<?php if($regle->Min_11 > 0) $regle->Min_11 = number_format($regle->Min_11,2,","," "); ?>
<?php if($regle->Max_12 > 0) $regle->Max_12 = number_format($regle->Max_12,2,","," "); ?>

<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h2><?php echo $title;?></h2>
    <p class="page-header"></p>
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate'));  ?>
    <?php $this->chtml->box_body_opening('', true);?>
        <div class="box-body">
            <div class="col-md-4">
                <div class="form-group">
                      <label for="priorite">Priorit&eacute;</label>
                      <?php echo form_dropdown('priorite', $priorite, $regle->Priorite_4, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-4">
                <div class="form-group">
                      <label for="min">Min</label>
                      <?php echo form_input('min', set_value('min', $regle->Min_11), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            <div class="col-md-4">
                <div class="form-group">
                      <label for="max">Max</label>
                      <?php echo form_input('max', set_value('max', $regle->Max_12), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="value">Indice (montant ou %)</label>
                      <?php echo form_input('value', set_value('value', $regle->Value_9), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="unite">Unit&eacute</label>
                      <?php $unites = array_merge($devises,array('%'=>'Pourcentage')); ?>
                      <?php echo form_dropdown('unite', $unites, $regle->Unite_10, 'class="form-control" required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-4">
                <div class="form-group">
                      <label for="devise">Devise</label>
                      <?php echo form_dropdown('devise', $devises, $regle->Devise_13, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="beneficiaire">B&eacute;n&eacute;ficiare</label> 
                    <?php echo form_dropdown('beneficiaire', $beneficiaires["RGF"], $regle->Beneficiaire_5, ' id="regies" class="form-control"  '); ?>
                </div>
            </div> 
            <div class="col-md-6">
                <div class="form-group"  id="regie0">
                    <label for="service">Service</label> 
                    <span id="slist"><?php echo form_dropdown('service', array(), $regle->Service_6, 'class="form-control" id="service"  " '); ?></span>
                </div>
                
            </div>  
            
            <div class="col-md-6">
                <div class="form-group">
                      <label for="recette">Recette</label>
                      <span id="slist1"><?php echo form_dropdown('recette', array (), $regle->Recette_7, ' id="recette" class="form-control"'); ?></span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="guichet">Agence bancaire</label>
                      <?php echo form_dropdown('guichet', $guichets, $regle->Guichet_8, ' id="Type1" class="form-control"'); ?>
                </div>
            </div>
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
            
        </div>
    <?php $this->chtml->box_body_closing(); ?> 	  
<?php echo form_close(); ?>
</div>
<div class="col-md-2"></div>






<script type="text/javascript">
 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/fees'); ?>/save/regle/<?php echo $regle->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $regle->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($regle->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

<?php if(isset($regle->Id_0) && $regle->Id_0!='' && $regle->Id_0!=0){?>
      shower();
<?php } ?>
    
$('#regies').change(function(){
      shower();
      
});

function shower()
{
      $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      //$("#Standard01").type='text';
      var regie = $('#regies option:selected').val();
      
      //alert(regie);
      
      var url = '<?php echo base_url($module.'/settings'); ?>/display/dropdowns/' + regie + '/services/<?php echo $regle->Service_6; ?>';
      $.get(url, function(data, status){
            if(data!="")
            {
                $("#slist").html(data);
            }
      });
      var url = '<?php echo base_url($module.'/settings'); ?>/display/dropdowns/' + regie + '/recettes/<?php echo $regle->Recette_7; ?>';
      $.get(url, function(data, status){
            if(data!="")
            {
                $("#slist1").html(data);
            }   
      });
}      

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/regles/fees'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/fees/display/regles'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
}
</script>
