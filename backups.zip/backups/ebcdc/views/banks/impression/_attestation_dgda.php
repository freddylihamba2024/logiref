<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
   
    <span style="padding-top: 300px;">
        <p style="text-align:justify; padding-top: 125px; ">
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?>, Agence de Kinshasa</span> atteste avoir encaiss&eacute; en date du <?php echo $encaissement->Datevaleur_31; ?>&nbsp; d'ordre de
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span>, pour compte de la <span style="font-weight: bold;"><?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]; ?> </span>, la somme de <span style="font-weight: bold;"><?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></span>
            en paiement de la <span style="font-weight: bold;"><?php echo $typeDoc[$encaissement->Notetype_25]; ?></span>/Versement n&deg; <b style="font-weight: bold;"><?php echo $encaissement->Noteid_26; ?></b> du <span style="font-weight: bold;"><?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?></span> au titre <?php echo $encaissement->Typerecette_17; ?>.

        </p>
    </span>

    <div style="padding-top:  200px;">
        <p align="center">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?>.<br>
        </p>
        
        <p align="center">
            <?php echo ' '.$this->session->userdata('account_business').' '; ?>
        </p>
        <p align="center">
            </br></br>
            (Signature autoris&eacute;e et cachet sec)
        </p>

    </div>



   
</body>

</html>

