<?php $infos = json_decode($encaissement->Notereference_30, true);
 
?>
<?php 
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
        
        if(isset($infos['accountname']) && $infos['accountname'] !="")
        {
                $name = substr($encaissement->Designation_14 , 0, 4);
                
                $boolean = stristr($infos['accountname'], $name);
        }
		
		$page= 'http://10.58.202.63/ikwook_files/logos/equitybcdc.png';
		
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>ikwook_bootstraps/v4/css/fonts.css">
</head>
<title></title>
<body style="padding:10px 10px;">
	
    <table style="width: 100%;">
        <tr>
            <td>
                <div style="padding: 50px 50px">
                    
                    <?php //if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $page; ?>" width="150" height="90" />
					<br/>
					<br/>
					<br/>
					<span style="color: #b00020; text-transform:uppercase;  font-family:'Arial'; font-weight:bold; font-size:20px;"><?php echo $numero ?></span>
                </div>
            </td>
         
            <td class="title" align ="right" style="color: #b00020; font-size:20px; font-family:'Arial'; line-height:1.6em;">
                <p>ATTESTATION DE PAIEMENT</p>
                <p>POUR LE COMPTE DE LA</p>
				<p>DGRAD/PASSEPORT</p>
            </td>
        </tr>
    </table>
    
  
 
    <div style="padding-top: 50px; text-align: justify;">
        <!--<h5 style="color:black; padding-top: 40px; font: bold caption 1em; text-align: center; font-size: 17px; border: 1px solid black; padding: 2px;">ATTESTATION DE PAIEMENT POUR LE COMPTE DE LA DGRAD/PASSEPORT<span style="font-weight: bold;"> </span></h5>-->
 
            <p style=" padding-top:45px;font-size: 18px;  font-family:'Arial'; text-align: justify; line-height:1.9em;">
                <span style="text-transform: uppercase; font-weight: bold; "><?php echo $this->session->userdata('account_business'); ?>&nbsp;&nbsp;</span>&nbsp;atteste avoir encaiss&eacute; en date du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31)); ?>&nbsp; d’ordre
                    <?php if(!isset($infos['pourcompte'])){ ?>
                        <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?>,</span>
                    <?php }else{ ?>
                        <span style="text-transform: uppercase;font-weight: bold;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> P/C <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?>,</span>
                    <?php } ?><span style="text-transform: lowercase;"> la somme de </span> <span style="font-weight: bold;"><?php echo $encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," "); ?> <?php //echo " ( ".$number_letter.") "; ?></span>
                    <span style="text-transform: lowercase;"> en paiement de la note de perception  n&deg;<?php echo $encaissement->Noteid_26; ?> du <span style="text-transform: lowercase;"></span> <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?> <span style="text-transform: lowercase;">au titre de  <?php echo $encaissement->Typerecette_17; ?></span>

            </p>
       
    </div>
    
    <table style="width: 100%; padding-top: 300px;">
        <tr>
            <td>
                <div style="padding: 50px 50px">
                    

                    <?php //if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $qrcode; ?>" width="150" height="150" />
                </div>
            </td>
    </table>

    <table style="width: 100%; padding-top: 40px;">
        <tr>
            <td class="title" align ="left" style=" font-family:'Arial'; font-size: 15px;">
                <p>Avertissement: Ce certificat n'est valable que s'il correspond aux d&eacute;tails repris dans le QR Code</p>
                <p>Contactez-nous +243 818 302 700 / 41909 ou par e-mail &agrave; serviceclient@equitybcdc.cd</p>
            </td>
        </tr>
    </table>
	
</body>

</html>