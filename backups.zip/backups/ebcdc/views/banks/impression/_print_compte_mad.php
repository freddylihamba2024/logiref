<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:0.9em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold; text-transform: uppercase;">
            Statistiques des comptes MAD
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Agence</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Guichets</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Comptes</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Libelle</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Compte dest.</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
    </tr>
    
    <?php foreach ($designations as $key => $designation): ?>
    
        <tr>
            <td style="font-size:0.8em;" ><span class="text-blue"><b>CLIENT</b></span></td>
            <td style="font-size:0.8em;" colspan="7"><span class="text-blue">: <b><?php echo $designation; ?></b></span></td>
        </tr>

            
        <?php $i=2; foreach($instructions as $row): ?>
            <?php if ($key == $row->Paiementid_4): ?>
                <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                    <td style="font-size:0.7em;" >
                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                    </td>
                    <td style="font-size:0.8em;"><?php echo isset($agences[$row->Agence_6])? $agences[$row->Agence_6]:'-'; ?></td>
                    <td style="font-size:0.8em;"><?php echo isset($guichets[$row->Guichet_7])? $guichets[$row->Guichet_7]:'-'; ?></td>
                    <td style="font-size:0.8em;"><?php echo $row->Compte_9; ?></td>
                    <td style="font-size:0.8em;"><?php echo $row->Libelle_12; ?></td>
                    <td style="font-size:0.8em;"><?php echo $row->Compte_13; ?></td>
                    <td style="font-size:0.8em;"><?php echo $row->Devise_11. ' '.number_format($row->Montant_10,2,","," "); ?></td>
                </tr>
            <?php endif; ?>
        <?php $i++; endforeach;?>
    <?php endforeach; ?>
</table>
