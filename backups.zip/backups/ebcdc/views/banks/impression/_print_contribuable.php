<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>
<table>
    <tr style="margin-left:8px;">
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?= gmdate('d/m/Y'); ?>
        </td>
    </tr>
    <tr style="margin-left:8px;">
        <?php $page = $_SESSION['account_logo']; ?>
        <?php $logo = (isset($page) && $page != '') ? $page : base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?= $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  ">RAPPORT DES PAIEMENTS PAR CONTIBUABLES</p><br/>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>#</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Client</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>R&eacute;gie</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Service</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Recette</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Agence</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
    </tr>

    <?php $paiements = 0; $i = 2; $j = 0; ?>
    <?php foreach($encaissements as $row) : ?>
        <?php $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - '; ?>
        <tr style="<?php if($i%2 == 0) echo "background-color:#ddd"; ?>">
            <td width="5" style="font-size:0.8em;"><b><?= ++$j; ?></b></td>
            <td width="9%" style="font-size:0.8em;"><?= strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
            <td width="15%" style="font-size:0.8em;"><?= $row->Designation_14; ?></td>
            <td style="font-size:0.8em;"><?= $row->Beneficaire_15; ?></td>
            <td style="font-size:0.8em;"><?= $beneficiaires[$row->Service_16]; ?></td>
            <td style="font-size:0.8em;"><?= $row->Typerecette_17; ?></td>
            <td style="font-size:0.8em;"><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
            <td width="15%" style="font-size:0.8em;"><?= $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> </td>
        </tr>
        <?php $paiements  += $row->Montant_11; ?>
    <?php $i++; endforeach; ?>
    <tr>
        <td colspan="7" style="border-bottom:1px solid black; font-size:0.8em;background-color: #000; color: #fff;">MONTANT TOTAL PAIEMENTS</td>
        <td style="border-bottom:1px solid black; font-size:0.8em; font-weight: bold;"><?= $row->Devise_12 . ' ' . number_format($paiements,2,","," "); ?></td>
    </tr>
</table>
