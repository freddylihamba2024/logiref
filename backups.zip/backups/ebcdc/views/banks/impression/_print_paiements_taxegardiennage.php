<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
	
</style>

<?php $page = $_SESSION['account_logo']; ?>
<?php $logo = (isset($page) && $page != '') ? $page : base_url('ikwook_files').'/logos/nologo.png'; ?>
<table>
    <tr>
        <td style="padding-left: 30px">
            <h6><?php echo $_SESSION['account_business']; ?></h6>
        </td>
        <td style="">
        </td>
    </tr>
    <tr>
        <td style="padding-left: 30px">
            <img style="width: 100px; height: 50px" class='img' src="<?php echo $logo; ?>" alt=""/><br/>
        </td>
        <td style="padding-left: 30px; text-align: center; font-size:0.9em;">
        <h5 style="text-align: center">RELEVE JOURNALIER DES ENCAISSEMENTS POUR COMPTE DGRAD/TAXE DE GARDIENAGE</h5><br>
            <p style="text-align: center; font-size:1em; "><b>Journ&eacute;e du : <?php echo strftime('%d-%m-%Y', strtotime($date_paiement)); ?></b></p>
        </td>
    </tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
    <tr>
        <td style="padding-left: 30px">
            <h6>AGENCE DE <?php echo strtoupper($guichets[$_SESSION['Logiref_guichet']]);?></h6>
        </td>
        
    </tr>
</table>


<table style="border-collapse: collapse; margin-left:30px; margin-right:30px;" width="100%"; cellspace="3"; cellpadding="14;">

    <tr>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>N&ordm;</b></td>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>NOM ou RAISON SOCIALE</b></td>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>NUMERO IMP&Ocirc;T</b></td>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>NATURE DE L'IMP&Ocirc;T</b></td>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>MONTANT PAYE EN CDF</b></td>
            <td style="border-bottom:1px solid black; font-size:0.7em; border: 1px solid black;"><b>N&ordm; NOTE DE PERCEPTION</b></td>
    </tr>
	
    <?php $total_general_paiements = 0;?>
    
    <?php $j=1; $i=2; foreach($encaissements as $row) : ?>
    
    <tr style="<?php if($i%2==0);?>">
        <td style="border: 1px solid black; font-size:0.7em"><?= $j++ ?></td>
        <td style="border: 1px solid black; font-size:0.7em"><?php echo $row->Designation_14; ?></td>
        <td style="border: 1px solid black; font-size:0.7em"><?php echo isset($row->Nif_13) ? $row->Nif_13 : "-"; ?></td>
        <td style="border: 1px solid black; font-size:0.7em"><?php echo $row->Typerecette_17; ?></td>

        <td style="border: 1px solid black; font-size:0.7em"><?php echo number_format($row->Montant_11,2,","," "); ?></td>
        <td style="border: 1px solid black; font-size:0.7em"><?php echo $row->Noteid_26;?></td>
    </tr>
    <?php $total_general_paiements  +=  $row->Montant_11; ?>
    
    <?php $i++; endforeach; ?>
    <tr>
       <td colspan="2" style="text-align: right; border: 1px solid black; font-size:0.7em"><b>Total</b></td>
        <td colspan="2" style="border: 1px solid black; font-size:0.7em"></td>
        <td  class="text-blue" colspan="2" style="border: 1px solid black; font-size:0.7em"><b><?php echo'CDF '.number_format($total_general_paiements,2,","," "); ?></b></td>
    </tr>
    
</table>
<p align="center" style="font-weight: bold; font-size:0.7em">
    <span style="text-transform: lowercase;">Nous disons: </span> <span style="font-weight: bold;"><?php echo 'CDF '.number_format($total_general_paiements,2,","," ");?> <?php echo " ( ".$number_letter.") "; ?></span>
</p>
</br></br></br></br>
<p align="center" style="font-size:0.7em;">
    </br></br>
    (Signatures autoris&eacute;es et cachet)
</p></br>

