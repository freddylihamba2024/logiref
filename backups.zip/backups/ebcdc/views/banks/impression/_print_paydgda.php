<?php 
    $paiements = 0; 
?>
<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table >
    <tr style="margin-left:8px;">
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
            <?= gmdate('d/m/Y'); ?>
        </td>
    </tr>
    <tr style="margin-left:8px;">
        <?php $page = $_SESSION['account_logo']; ?>
        <?= $logo = (isset($page) && $page != '') ? $page : base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?= $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $_SESSION['account_business'].' - '.$guichets[$_SESSION['Logiref_guichet']]; ?>
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.1em;">RAPPORTS PAIEMENTS DGDA</p><br/>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>
<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <th style="border-bottom:1px solid black; font-size:0.7em;">#</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Date Paiement</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Service</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Bulletin</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Montant</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Client</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Agences</th>
        <th style="border-bottom:1px solid black; font-size:0.7em;">Date saisie</th>
    </tr>

    <?php $y=0; $i=2; foreach($bulletins as $row) :

        $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
        $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        $results = json_decode($row->Results_13);
        $recieptDate = explode("/",$results->receiptDate);
        $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
    ?>
    <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
        <td><b><?php echo ++$y; ?></b></span></td>
        <td width="10%"><?= isset($results->DateLi)? $results->DateLi: "-"; ?></td>
        <td><?php echo $services['DGDA'][$row->Office_6]; ?></td>
        <td><?php echo $row->Serie_7."".$row->Number_8; ?></td>
        <td>
             <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
        </td>
        <td><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>

        <td><?= isset($guichets[$row->Agence_32]) ? $guichets[$row->Agence_32] : "-"; ?></td>
        <td <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
             <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
        </td>
    </tr>
    <?php 
        $paiements  +=  $row->Amount_12; 
    ?>
    <?php $i++; endforeach;?>
    <tr>
        <td colspan="4"><b>Montant Total</b></td>
        <td  class="text-blue" colspan="2"><b><?php echo'CDF '.number_format($paiements,2,","," "); ?></b></td>
    </tr>
</table>
<?php unset($_SESSION['bulletins'] ); ?>

