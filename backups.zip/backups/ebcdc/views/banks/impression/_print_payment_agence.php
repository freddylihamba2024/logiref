<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold">
            RAPPORT DES PAIEMENTS GLOBALES PAR AGENCE
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>D&eacute;signation</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>B&eacute;n&eacute;ficiaire</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Recette</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Commissions</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Op&eacute;rateur</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Agence</b></td>
    </tr>
    <?php $montant_toal = 0; $commission_total=0; ?>
    
    <?php $i=2; foreach($encaissements as $row): ?>
            <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                <td style="font-size:0.7em;" >
                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                </td>
                <td style="font-size:0.7em;"><?php echo $row->Designation_14; ?></td>
                <td style="font-size:0.7em;"><b><?php echo $row->Beneficaire_15; ?></b></td>
                <td style="font-size:0.7em;"><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                <td style="font-size:0.7em;"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                      <br/>
                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                    <?php endif;?>
                </td>
                <td style="font-size:0.7em;"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                <td style="font-size:0.7em;"><?php echo (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - '; ?></td>
                <td style="font-size:0.7em;"><b><?php echo (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - '; ?></b></td>
            
            </tr>
    <?php 
                $i++; 
                $montant_toal += $row->Montant_11;
                $commission_total += $row->Commission_23;
        endforeach;
    ?>
    <tr>
        <td style="font-size:0.8em;text-align: right;" colspan="4"><b>TOTAL</b></td>
        <td style="font-size:0.8em;"><b><?php echo number_format($montant_toal,2,","," "); ?></b></td>
        <td style="font-size:0.8em;" colspan="3"><b><?php echo number_format($commission_total,2,","," "); ?></b></td>
    </tr>
</table>
