
<?php $infos = json_decode($encaissement->Notereference_30, true);
        $date= explode('/',$infos["standard"]);
		
        if(count($date) == 3)
        {
                $month = $date[1];
                $year =$date[0];
        }
        elseif(count($date) == 2)
        {
                $month = $date[0];
                $year = $date[1];
        }
        else
        {
                $month = "";
                $year = "";
        }
?>
<?php 
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
        

       
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <table style="width: 100%">
            <tr>
                <td align ="right" style="font-size: 15px;">
                    <div>
                        <p><?php echo $number.'/'.$_SESSION['Guichet_code'].'/'.gmdate("Y").'/'.substr($ville, 0,3); ?> </p>
                    </div>
                </td>
            </tr>
    </table>
	<?php if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == 'DGI' && isset($infos['QuotasDGI']) && $infos['QuotasDGI'] >0 && (isset($infos['QuotasONEM']) && $infos['QuotasONEM'] >0 && isset($infos['QuotasINPP']) && $infos['QuotasINPP'] >0 && isset($infos['QuotasINSS']) && $infos['QuotasINSS'] >0)){ ?>
		<div style="padding-top: 150px;">
			<h5 style="color:black; padding-top: 40px; font: bold caption 1em; text-align: center; font-size: 15px; border: 1px solid black; padding: 2px;">ATTESTATION DE PAIEMENT POUR LE COMPTE DE LA DGI, ONEM, INPP ET CNSS</i><span style="font-weight: bold;"> </span></h5>
 
			<p style=" padding-top:45px; text-align: justify; font-size: 15px;">
                <span style="text-transform: uppercase; font-weight: bold; "><?php echo $this->session->userdata('account_business'); ?>&nbsp;SA&nbsp;</span>A<span style="text-transform: lowercase;" >gence de</span> <?php echo (isset($agences) && $agences !="" )? $agences :'..............';?>,<span style="text-transform: uppercase;"></span>&nbsp;atteste avoir encaiss&eacute; en date du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31)); ?>&nbsp; d'ordre de
                    <?php if(!isset($infos['pourcompte'])){ ?>
                            <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?> </span> <span>N&deg; Imp&ocirc;t <?php echo $encaissement->Nif_13?>,</span>
                    <?php }else{ ?>
                            <span style="text-transform: uppercase;font-weight: bold;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> P/C <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?> </span> <span>N&deg; Imp&ocirc;t <?php echo $encaissement->Nif_13?>,</span>
                    <?php } ?> pour compte de DGI, ONEM, INPP et CNSS, la somme de <span style="font-weight: bold;"><?php echo $encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," "); ?> <?php echo " ( ".$number_letter.") "; ?></span>
                au titre des imp&ocirc;ts, cotisations sociale et contributions patronales sur les r&eacute;mun&eacute;rations du mois de <span style="text-transform: uppercase;" ><?php echo (isset($months[$mois]))?$months[$mois]: "";?></span>, Ann&eacute;e <?php echo (isset($annee))?$annee: "";;?>.</i>
				
            </p>
    
			<table style="width: 100%">
				<tr>
					<td>
						<div>
							<h6>BENEFICIAIRES</h6>
							 <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
							 <?php $dgi = $encaissement->Contrevaleur_22 -  ($infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']); ?>
								<table>
									<tr><td> - DGI &nbsp;&nbsp;</td></tr>
									<tr><td> - ONEM &nbsp;&nbsp;</td></tr>
									<tr><td> - INPP &nbsp;&nbsp;</td></tr>
									<tr><td> - CNSS &nbsp;&nbsp;</td></tr>
									
									<hr>
									<tr><td> TOTAL</td></tr>
								</table>
							 <?php endif;?> 
						</div>
					</td>
					<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
					<td align ="" >   
						<div style="margin-left: -300px;">
							<h6>MONTANT</h6>
							<?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])&& !empty($infos['QuotasDGI'])):?>
							<?php $dgi = $infos['QuotasDGI']+$infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']; ?>
								<table>
									<tr><td style="text-align: right;"><?php echo number_format($infos['QuotasDGI'],2,","," "); ?></td></tr>
									<tr><td style="text-align: right;"><?php echo number_format($infos['QuotasONEM'],2,","," "); ?></td></tr>
									<tr><td style="text-align: right;"><?php echo number_format($infos['QuotasINPP'],2,","," "); ?></td></tr>
									<tr><td style="text-align: right;"><?php echo number_format($infos['QuotasINSS'],2,","," "); ?></td></tr>
									
									<hr>
									<tr><td style="text-align: right; font-weight: bold;"><?php echo number_format($dgi ,2,","," "); ?></td></tr>
								</table>
							<?php endif;?>
						</div>
					</td>
				</tr>
			</table>
	 <div style="padding-top: 50px;  font-size: 15px;">
           <p align="right">
               Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31)); ?>.<br>
           </p>

           <p align="center" style="font-weight: bold;">
               <?php echo ' '.$this->session->userdata('account_business').' '; ?>&nbsp;SA&nbsp;
           </p>
           <p align="center">
               </br></br>
               (Signatures autoris&eacute;es et cachet)
           </p></br>

    </div>
    
	<?php }else{ ?>
		<div style="padding-top: 150px;">
			<h5 style="color:black; padding-top: 40px; font: bold caption 1em; text-align: center; font-size: 17px; border: 1px solid black; padding: 2px;">ATTESTATION DE PAIEMENT POUR LE COMPTE DU CIS<span style="font-weight: bold;"> </span></h5>
				<p style=" padding-top:45px;font-size: 15px; text-align: justify;">
					<span style="text-transform: uppercase; font-weight: bold; "><?php echo $this->session->userdata('account_business'); ?>&nbsp;SA&nbsp;</span>A<span style="text-transform: lowercase;" >gence de&nbsp;</span><?php echo (isset($agences) && $agences !="" )? $agences :'..............';?>,<span style="text-transform: uppercase;"></span>&nbsp;atteste avoir encaiss&eacute; en date du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31)); ?>&nbsp; d'ordre de
					<?php if(!isset($infos['pourcompte'])){ ?>
						<span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?> </span> <span>N&deg; Imp&ocirc;t <?php echo $encaissement->Nif_13 ?>,</span>
					<?php }else{ ?>
						<span style="text-transform: uppercase;font-weight: bold;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> P/C <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Designation_14; ?> </span> <span>N&deg; Imp&ocirc;t <?php echo $encaissement->Nif_13?>,</span>
					<?php } ?> pour compte du CIS, la somme de <span style="text-transform: uppercase;font-weight: bold;"><?php echo $encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," "); ?><?php echo " ( ".$number_letter.") "; ?></span>
					au titre de <?php echo  $encaissement->Typerecette_17; ?> <?php echo $month.'/'. $year;?>.
				</p>
		</div>
    
    
		<div style="padding-top: 100px; font-size: 14px;">
			<p align="right">
				Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo $jour.' '. $months[$mois].' '. $annee; ?>.<br><br>
			</p>
			
			<p align="center" style="font-weight: bold;">
				<?php echo ' '.$this->session->userdata('account_business').' '; ?>&nbsp;SA&nbsp;
			</p>
			<p align="center">
				</br></br>
				(Signatures autoris&eacute;es et cachet)
			</p></br>

		</div>

    <?php } ?>
</body>
</html>
