
<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table>
    <tr style="margin-left:8px;">
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
            <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
    <tr style="margin-left:8px;">
        <?php $page = $_SESSION['account_logo']; ?>
        <?= $logo = (isset($page) && $page != '') ? $page :  base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?= $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $_SESSION['account_business'].' - '.$guichets[$_SESSION['Logiref_guichet']]; ?>
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.1em;">PAIEMENTS JOURNALIERS GUICHET UNIQUE DGDA</p><br/>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>
<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>N&ordm;</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Bulletin</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>R&eacute;gie</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Service</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Recette</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Importateur</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Bordereau</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Quitt.</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Devise</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Montant du bulletin</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Quota recette</b></td>
    </tr>
    <?php
        $user                       = $this->session->userdata('user_id');
        $total_general_bls          = 0;
        $total_general_paiements    = 0;
        $total_bureau               = 0;
        $i                          = 2; 
        $y                          = 1;
    ?>
    
    <?php foreach ($encaissements as $row): ?>
        <?php $Infos = (isset($row->Notereference_30) && $row->Notereference_30 != "" ) ? json_decode($row->Notereference_30, true) : ''; ?>
        <tr style="<?php if($i % 2 == 0) echo "background-color:#ddd"; ?>">
            <td style="font-size:0.7em;"><?= $y; ?></td>
            <td style="font-size:0.7em;"><?= $row->Datevaleur_31; ?></td>
            <td style="font-size:0.7em;"><?= (isset($Infos['serie']) && isset($Infos['number'])) ? $Infos['serie'].$Infos['number'] : ''; ?></td>
            <td style="font-size:0.7em;"><?= $row->Beneficaire_15; ?></td>
            <td style="font-size:0.7em;"><?= $services[$row->Service_16]; ?></td>
            <td style="font-size:0.7em;"><?= $row->Typerecette_17; ?></td>
            <td style="font-size:0.7em;"><?= $row->Designation_14; ?></td>
            <td style="font-size:0.7em;"><?= $row->Reference_32; ?></td>
            <td style="font-size:0.7em;"><?= (isset($Infos['quittanceid']))? $Infos['quittanceid'] :''; ?></td>
            <td style="font-size:0.7em;"><?= 'CDF'; ?></td>
            <td style="font-size:0.7em;"><?= number_format($row->Notemontant_28,2,","," "); ?></td>
            <td style="font-size:0.7em;"><?= number_format($row->Montant_11,2,","," "); ?></td>
        </tr>
   
        <?php  
            $i++; 
            $y++; 

            $total_general_bls          = $total_general_bls + $row->Notemontant_28;
            $total_general_paiements    = $total_general_paiements + $row->Montant_11;
        ?>
    <?php  endforeach;?>
    <tr>
        <td colspan="10" style="text-align: right;">Total g&eacute;n&eacute;ral</td>
        <td style="font-size:0.7em;">
            <b><?php echo number_format($total_general_bls,2,","," ");?></b>
        </td>
        <td style="font-size:0.7em;">
             <b><?php echo number_format($total_general_paiements,2,","," ");?></b>
        </td>
    </tr>
</table>


