<section class="content">
        <div class="col-md-3" style="min-width: 400px">
                <div class="box no-border no-padding">
                        <div class="box-body no-padding">
                            <div class="col-md-12 col-md-12 queenbox bg-orange">
                                   <a class="text-white" href="<?php echo base_url('sales'); ?>"><span class="queentext">iKwook Logiref<br/></span></a><br/>
                                   <span class="text-white f14">
                                       Le paiement d&eacute;mat&eacute;rialis&eacute; des taxes, imp&ocirc;ts et redevances encore beaucoup plus simpli&eacute;.<br/>
                                       (Actuellement limit&eacute; &agrave; la RDC)
                                   </span>
                            </div>
                            <div class="col-md-12 appsbox no-padding">
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-briefcase text-gray"></i><br/>
                                               <span class="text">Recettes publiques</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-file-text text-gray"></i><br/>
                                               <span class="text">m-Recettes</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-send-o text-gray"></i><br/>
                                               <span class="text">Licences BCC</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                            <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-money text-gray"></i><br/>
                                               <span class="text">Cambisme</span>
                                            </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                            <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-coffee text-gray"></i><br/>
                                               <span class="text">e-Recettes</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-desktop text-gray"></i><br/>
                                               <span class="text">T&eacute;l&eacute;paiements</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-list-alt  text-gray"></i><br/>
                                               <span class="text">e-Suscriptions</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                        <a href="<?php echo base_url($module.'/bank/set/list'); ?>" style="cursor:pointer"  class="bg-default">
                                               <i class="fa fa-gear text-green"></i><br/>
                                               <span class="text">Taux de change</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                        <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-history text-gray"></i><br/>
                                               <span class="text">Logs</span>
                                           </a>
                                    </div>
                            </div>
                        </div>
                </div>
        </div>
            
        <div class="col-md-6">
                <div class="row">
                        <div class="col-md-12" id='alert'><?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?></div>
                        <div class="col-md-12">
                            <?php $this->chtml->box_body_opening("", true); ?>
                                    <div class="statistic-box no-border">
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-green f18"><i class="fa fa-user text-green" style="font-size:47px !important; color:#069"></i>&nbsp;&nbsp;<b> <?php echo $users_stats['Actifs']; ?></b></span><br/>
                                              <span class="description-text">Actifs</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-yellow f18"><i class="fa fa-user text-red" style="font-size:50px !important; color:#069"></i><b> <?php echo $users_stats['Inactifs']; ?></b></span><br/>
                                                <span class="description-text">Inactifs</span>
                                            </div><!-- /.description-block -->
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-blue f18"><i class="fa fa-user text-aqua" style="font-size:50px !important; color:#069"></i>&nbsp;&nbsp;<b> <?php echo $users_stats['Suspendus']; ?></b></span><br/>
                                              <span class="description-text">Suspendus</span>
                                            </div><!-- /.description-block -->
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block">
                                                <span class="description-percentage text-red f18"><i class="fa fa-user text-back" style="font-size:50px !important; color:#069"></i>&nbsp;<b> <?php echo $users_stats['Total']; ?></b></span><br/>
                                              <span class="description-text">Total</span>
                                            </div>
                                        </div>
                                    </div>
                            <?php $this->chtml->box_body_closing(); ?>
                        </div>
                </div>
            
                <div class="row">
                            <div class="col-md-6">
                                <?php $this->chtml->box_body_opening("", false); ?>
                                    <div class="col-md-12 no-padding">
                                            <ul class="nav nav-pills nav-stacked">
                                                <li id='' style="padding:10px;"><b>Consultation des r&eacute;f&eacute;rentiels </b></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/villes'); ?>"><i class="fa fa-book"></i> Entit&eacute;s administratives </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/penalites'); ?>"><i class="fa fa-book"></i> R&egrave;gles de p&eacute;nalit&eacute;s </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/beneficiaries'); ?>"><i class="fa fa-book"></i> Institutions publiques (b&eacute;n&eacute;ficiaires)</a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/taxes'); ?>"><i class="fa fa-book"></i> Type de recettes </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/services'); ?>"><i class="fa fa-book"></i> Services de recouvrement </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/villes'); ?>"><i class="fa fa-book"></i> Entit&eacute;s administratives </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/penalites'); ?>"><i class="fa fa-book"></i> R&egrave;gles de p&eacute;nalit&eacute;s </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/beneficiaries'); ?>"><i class="fa fa-book"></i> Institutions publiques (&eacute;n&eacute;ficiaires)</a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/villes'); ?>"><i class="fa fa-book"></i> Entit&eacute;s administratives </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/penalites'); ?>"><i class="fa fa-book"></i> R&egrave;gles de p&eacute;nalit&eacute;s </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/beneficiaries'); ?>"><i class="fa fa-book"></i> Institutions publiques (B&eacute;n&eacute;ficiaires)</a></li>                                              
                                            </ul>
                                    </div>
                                <?php $this->chtml->box_body_closing(); ?>
                            </div>
                            <div class="col-md-6">
                                <?php $this->chtml->box_body_opening("", false); ?>
                                    <div class="col-md-12 no-padding">
                                            <ul class="nav nav-pills nav-stacked">
                                                <li id='' style="padding:10px;"><b>Param&egrave;trages </b></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/comptes'); ?>"><i class="fa fa-gear"></i> G&eacute;rer les comptes </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/guichets'); ?>"><i class="fa fa-gear"></i> G&eacute;rer les points des perceptions </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/regles'); ?>"><i class="fa fa-gear"></i> G&eacute;rer les r&egrave;gles de repartitions </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/privileges'); ?>"><i class="fa fa-gear"></i> G&eacute;rer les privil&egrave;ges </a></li>
                                                <li id=''><a href="#"  class="bg-default" onclick="action()"><i class="fa fa-gear text-gray pointer"></i> G&eacute;rer les applications </a></li>
                                            </ul>
                                    </div>
                                <?php $this->chtml->box_body_closing(); ?>
                            </div>
                </div>
            
                <div class="row">
                        <div class="col-md-12">
                                <div class="box box-info no-border" style='min-height:250px'>
                                    <div class="box-header with-border">
                                        <h3 class="box-title">Notifications</h3>
                                    </div><!-- /.box-header -->
                                    <div class="box-body">
                                      <div class="table-responsive">
                                        <?php if(!empty($notifications)): ?>
                                        <table class="table no-margin">
                                          <tbody style="font-size:12px;">
                                              <?php 
                                              foreach($orders as $row){
                                              $label = str_replace(" ","_",strtolower($row->Title_5));
                                              $canApprove = false;
                                              ?>
                                                  <tr id="line<?php echo $row->Id_0;?>">
                                                      <td>OR<?php echo $row->Id_0; ?></td>
                                                      <td><b><?php echo $row->Title_4; ?></b></td>
                                                      <td><?php echo $supervisors[$row->Createby_18];?></td>
                                                      <td><?php echo $row->Starts_6;?></td>
                                                      <td class="rouge"> <?php echo $row->Deadline_7;?> </td>
                                                  </tr>
                                              <?php } ?>

                                          </tbody>
                                        </table>
                                        <?php else :?>
                                          <p align='center'><span class='text-gray center'>Aucune notification trouv&eacute;e !</span></p>
                                        <?php endif;?>
                                      </div><!-- /.table-responsive -->
                                    </div><!-- /.box-body -->
                                </div><!-- /.box -->
                        </div>
                </div>
        </div>
            
        <div class="col-md-2 bLeft" style='min-height:600px'>
            <div class="col-md-12" style='min-height:300px'>
                <h4>Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br/></h4>
                <?php if(!empty($members)){ ?>
                    <?php foreach($members as $key=>$user){ ?>
                        <div class="padding">
                            <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                            <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                            <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                            <br/><br/>
                        </div>
                        <?php $i++; if($i>10) break; ?>
                    <?php } ?>
                    <div class="padding">...</div>
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune alerte trouv&eacute;e!<br/><br/></span>
                <?php } ?>
            </div>
            <div class="col-md-12 bTop" style="display: block;">
                <h4>Insights<br/></h4>
                <?php if(!empty($members)){ ?>
                    <?php foreach($members as $key=>$user){ ?>
                        <div class="padding">
                            <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                            <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                            <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                            <br/><br/>
                        </div>
                        <?php $i++; if($i>10) break; ?>
                    <?php } ?>
                    <div class="padding">...</div>
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune donn&eacute;ee trouv&eacute;e !<br/><br/></span>
                <?php } ?>
            </div>
        </div> 
</section>
<!-- /.content -->
                
<script type="text/javascript">
function action()
{
        var lang = '<?php echo $lang; ?>';
        if(lang =='fr')
        {
            $("#alert").html('<div class="alert alert-warning"> D&eacute;sol&eacute;! Cette application n\'est pas encore disponible pour votre compte! Merci.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        else
        {
            $("#alert").html('<div class="alert alert-warning">Sorry, this application is not yet actived for your account! Thanks.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
}

</script>
                
               
                
            
             



