<section class="content">
        <div class="col-md-3" style="min-width: 400px">
                <div class="box no-border no-padding">
                        <div class="box-body no-padding">
                            <div class="col-md-12 col-md-12 queenbox bg-orange">
                                   <a class="text-white" href="<?php echo base_url('sales'); ?>"><span class="queentext">iKwook Logiref<br/></span></a><br/>
                                   <span class="text-white f14">
                                       Le paiement d&eacute;mat&eacute;rialis&eacute; des taxes, imp&ocirc;ts et redevances encore beaucoup plus simpli&eacute;.
                                   </span>
                            </div>
                            <div class="col-md-12 appsbox no-padding">
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="<?php echo base_url($module.'/bank/set/overview'); ?>" class="bg-default ">
                                               <i class="fa fa-briefcase text-green"></i><br/>
                                               <span class="text">Recettes</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-file-text text-red"></i><br/>
                                               <span class="text">Commissions</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-send-o text-aqua"></i><br/>
                                               <span class="text">Reversements</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                            <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-money text-gray"></i><br/>
                                               <span class="text">P&eacute;ration d'?changes</span>
                                            </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                            <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-coffee text-gray"></i><br/>
                                               <span class="text">e-Recettes</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-desktop text-gray"></i><br/>
                                               <span class="text">T&eacute;l&eacute;paiements</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a href="#" style="cursor:pointer"  class="bg-default" onclick="action()">
                                               <i class="fa fa-list-alt  text-gray"></i><br/>
                                               <span class="text">Ordres de paiement</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                           <a  href="<?php echo base_url($module.'/bank/set/reporting'); ?>" style="cursor:pointer"  class="bg-default">
                                               <i class="fa fa-file-text-o"></i><br/>
                                               <span class="text">Rapports</span>
                                           </a>
                                    </div>
                                    <div class="col-sm-4 col-xs-4">
                                        <a href="<?php echo base_url($module.'/bank/set/list'); ?>" style="cursor:pointer"  class="bg-default">
                                               <i class="fa fa-gear text-green"></i><br/>
                                               <span class="text">Taux de change</span>
                                           </a>
                                    </div>
                            </div>
                        </div>
                </div>
        </div>
            
        <div class="col-md-6">
                <div class="row">
                        <div class="col-md-12" id='alert'><?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?></div>
                        <div class="col-md-12">
                            <?php $this->chtml->box_body_opening("", true); ?>
                                    <div class="statistic-box no-border">
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-green f18"><i class="fa fa-suitcase text-green" style="font-size:47px !important; color:#069"></i>&nbsp;&nbsp;<b> <?php echo 0; ?></b></span><br/>
                                              <span class="description-text">Encaissement</span>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-yellow f18"><i class="glyphicon glyphicon-check text-red" style="font-size:50px !important; color:#069"></i><b> <?php echo 0; ?></b></span><br/>
                                                <span class="description-text">Validation</span>
                                            </div><!-- /.description-block -->
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block border-right">
                                                <span class="description-percentage text-blue f18"><i class="fa fa-send-o text-aqua" style="font-size:50px !important; color:#069"></i>&nbsp;&nbsp;<b> <?php echo 0; ?></b></span><br/>
                                              <span class="description-text">Reversements</span>
                                            </div><!-- /.description-block -->
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="description-block">
                                                <span class="description-percentage text-red f18"><i class="glyphicon glyphicon-th-list text-blue" style="font-size:50px !important; color:#069"></i>&nbsp;<b> <?php echo 0; ?></b></span><br/>
                                              <span class="description-text">Nivellement</span>
                                            </div>
                                        </div>
                                    </div>
                            <?php $this->chtml->box_body_closing(); ?>
                        </div>
                </div>
            
            
                <div class="row">
                        <div class="col-md-12">
                                <div class="box box-info no-border" style='min-height:250px'>
                                    <div class="box-header with-border">
                                        <h3 class="box-title">Notifications</h3>
                                    </div><!-- /.box-header -->
                                    <div class="box-body">
                                      <div class="table-responsive">
                                        <?php if(!empty($notifications)): ?>
                                        <table class="table no-margin">
                                          <tbody style="font-size:12px;">
                                              <?php 
                                              foreach($orders as $row){
                                              $label = str_replace(" ","_",strtolower($row->Title_5));
                                              $canApprove = false;
                                              ?>
                                                  <tr id="line<?php echo $row->Id_0;?>">
                                                      <td>OR<?php echo $row->Id_0; ?></td>
                                                      <td><b><?php echo $row->Title_4; ?></b></td>
                                                      <td><?php echo $supervisors[$row->Createby_18];?></td>
                                                      <td><?php echo $row->Starts_6;?></td>
                                                      <td class="rouge"> <?php echo $row->Deadline_7;?> </td>
                                                  </tr>
                                              <?php } ?>

                                          </tbody>
                                        </table>
                                        <?php else :?>
                                          <p align='center'><span class='text-gray center'>Aucune notification trouv&eacute;e !</span></p>
                                        <?php endif;?>
                                      </div><!-- /.table-responsive -->
                                    </div><!-- /.box-body -->
                                </div><!-- /.box -->
                        </div>
                </div>
            
            
                <div class="row">
                        <div class="col-md-12 no-padding">
                            <div class="col-md-4">
                                    <?php $this->chtml->box_body_opening("", false); ?>
                                        <div class="col-md-12 no-padding">
                                                <ul class="nav nav-pills nav-stacked">
                                                    <li id='' style="padding:10px;"><b>Nouveau </b></li>
                                                    <li id=''><a href="<?php echo base_url($module.'/bank/set/comptant'); ?>"><i class="fa fa-minus"></i>Paiement Comptant </a></li>
                                                    <li id=''><a href="#"><i class="fa fa-minus"></i> Bulletin de liquidation </a></li>
                                                    <li id=''><a href="#"><i class="fa fa-minus"></i> D&eacute;claration d'imp&ocirc;ts </a></li>
                                                    <li id=''><a href="#"><i class="fa fa-minus"></i> Licence d'importation</a></li>
                                                    <li id=''><a href="#"><i class="fa fa-minus"></i> Note de perception</a></li>
                                                </ul>
                                        </div>
                                    <?php $this->chtml->box_body_closing(); ?>
                            </div>
                            <div class="col-md-4">
                                <?php $this->chtml->box_body_opening("", false); ?>
                                    <div class="col-md-12 no-padding">
                                            <ul class="nav nav-pills nav-stacked">
                                                <li id='' style="padding:10px;"><b>R&eacute;f&eacute;rentiels </b></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/taxes'); ?>"><i class="fa fa-minus"></i> Type de recettes </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/services'); ?>"><i class="fa fa-minus"></i> Services de recouvrement </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/villes'); ?>"><i class="fa fa-minus"></i> Entit&eacute;s administratives </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/penalites'); ?>"><i class="fa fa-minus"></i> R&egrave;gles de p&eacute;nalit&eacute;s </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/beneficiaries'); ?>"><i class="fa fa-minus"></i> B&eacute;n&eacute;ficiaires </a></li>
                                                
                                            </ul>
                                    </div>
                                <?php $this->chtml->box_body_closing(); ?>
                            </div>
                            <div class="col-md-4">
                                <?php $this->chtml->box_body_opening("", false); ?>
                                    <div class="col-md-12 no-padding">
                                            <ul class="nav nav-pills nav-stacked">
                                                <li id='' style="padding:10px;"><b>Parametrages </b></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/comptes'); ?>"><i class="fa fa-minus"></i> Comptes </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/guichets'); ?>"><i class="fa fa-minus"></i> Points de perception </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/regles'); ?>"><i class="fa fa-minus"></i> R&egrave;gles de repartitions </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/agences'); ?>"><i class="fa fa-minus"></i> Agences Bcc </a></li>
                                                <li id=''><a href="<?php echo base_url($module.'/settings/set/privileges'); ?>"><i class="fa fa-minus"></i> Privil&egrave;ges </a></li>
                                            </ul>
                                    </div>
                                <?php $this->chtml->box_body_closing(); ?>
                            </div>
                        </div>
                </div>
        </div>
            
        <div class="col-md-2 bLeft" style='min-height:600px'>
            <div class="col-md-12" style='min-height:300px'>
                <h4>Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br/></h4>
                <?php if(!empty($members)){ ?>
                    <?php foreach($members as $key=>$user){ ?>
                        <div class="padding">
                            <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                            <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                            <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                            <br/><br/>
                        </div>
                        <?php $i++; if($i>10) break; ?>
                    <?php } ?>
                    <div class="padding">...</div>
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune alerte trouv&eacute;e!<br/><br/></span>
                <?php } ?>
            </div>
            <div class="col-md-12 bTop" style="display: block;">
                <h4>Insights<br/></h4>
                <?php if(!empty($members)){ ?>
                    <?php foreach($members as $key=>$user){ ?>
                        <div class="padding">
                            <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                            <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                            <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                            <br/><br/>
                        </div>
                        <?php $i++; if($i>10) break; ?>
                    <?php } ?>
                    <div class="padding">...</div>
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune donn&eacute;ee trouv&eacute;e !<br/><br/></span>
                <?php } ?>
            </div>
        </div> 
</section>
<!-- /.content -->
                
<script type="text/javascript">
function action()
{
        var lang = '<?php echo $lang; ?>';
        if(lang =='fr')
        {
            $("#alert").html('<div class="alert alert-warning"> D&eacute;sol&eacute;! Cette application n\'est pas encore disponible pour votre compte! Merci.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        else
        {
            $("#alert").html('<div class="alert alert-warning">Sorry, this application is not yet actived for your account! Thanks.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
}

</script>
                
               
                
            
             



