<section >
        <div class="col-md-10">
                <div class="col-md-12">
                        <h1>Liste de logs</h1>
                        <h5 class="page-header"><span class="text-gray">Retrouver ici la liste de tous les logs.</span></h5>
                </div>     
                <section id="cat_list">
                    
                    <div class="row fontawesome-icon-list min-height-30pct pTop50 f14 tCenter">
                        
                        <span class="fa fa-warning text-gray mystyle4"></span>
                        <br/><br/>
                        Aucun logs trouv&eacute; !
                        <br/><br/>
                    </div>
                </section>
                
        </div>
            
        <div class="col-md-2 bLeft" style='min-height:600px'>
                <div class="col-md-12" style='min-height:300px'>
                    <h4>Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br/></h4>
                    <?php if(!empty($members)){ ?>
                        <?php foreach($members as $key=>$user){ ?>
                            <div class="padding">
                                <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                                <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                                <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                                <br/><br/>
                            </div>
                            <?php $i++; if($i>10) break; ?>
                        <?php } ?>
                        <div class="padding">...</div>
                    <?php }else { ?>
                        <span class='f16 text-gray'>Aucune alerte trouv&eacute;e!<br/><br/></span>
                    <?php } ?>
                </div>
                <div class="col-md-12 bTop" style="display: block;">
                    <h4>Insights<br/></h4>
                    <?php if(!empty($members)){ ?>
                        <?php foreach($members as $key=>$user){ ?>
                            <div class="padding">
                                <img src="<?php echo base_url($user['profile']); ?>" class='img-circle' width="40" height="40" />
                                <?php echo '#' . $key. ' ' . $user['name'] . ''; ?>
                                <span><i class='fa fa-thumbs-up text-green pull-right'></i></span>
                                <br/><br/>
                            </div>
                            <?php $i++; if($i>10) break; ?>
                        <?php } ?>
                        <div class="padding">...</div>
                    <?php }else { ?>
                        <span class='f16 text-gray'>Aucune donn&eacute;ee trouv&eacute;e !<br/><br/></span>
                    <?php } ?>
                </div>
        </div> 
</section>
<!-- /.content -->
                
<script type="text/javascript">
function action()
{
        var lang = '<?php echo $lang; ?>';
        if(lang =='fr')
        {
            $("#alert").html('<div class="alert alert-warning"> D&eacute;sol&eacute;! Cette application n\'est pas encore disponible pour votre compte! Merci.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        else
        {
            $("#alert").html('<div class="alert alert-warning">Sorry, this application is not yet actived for your account! Thanks.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
}

</script>
                
               
                
            
             



