<div id="contenter">
    <div class="col-md-1" id="col"></div>
    <div class="col-md-10 no-padding" id="content">
            <div id="loader"></div>
            <div class="col-md-12" id="alert"></div>
            <div id="pager">
                <!-- !-->
                <div class="col-md-12">
                        <h2 class="text-blue" ><?php echo " Nouveau..."; ?></h2>
                        <p class="page-header"></p>
                </div>
                <div class="col-md-8 bRight">
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('declaration')" class="bg-default ">
                                    <i class="fa fa-file-text text-aqua f30"></i><br/>
                                    <span class="text">D&eacute;claration (DGI)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('note_perception')" class="bg-default ">
                                    <i class="fa fa-file-text-o text-aqua f30"></i><br/>
                                    <span class="text">Note de perception (DGRAD)</span>
                                </a>
                             </div>
                        </div>
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('passport')" class="bg-default ">
                                    <i class="fa fa-file-text-o text-aqua f30"></i><br/>
                                    <span class="text">Achat des Passeports</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('bulletin')" class="bg-default ">
                                    <i class="fa fa-file-code-o text-aqua f30"></i><br/>
                                    <span class="text">Bulletin de liquidation (DGDA)</span>
                                </a>
                             </div>
                        </div>
			<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="message()" class="bg-default ">
                                    <i class="fa fa-sticky-note text-aqua f30"></i><br/>
                                    <span class="text">Bulletin à cr&eacute;dit (DGDA)</span>
                                </a>
                             </div>
                        </div>

                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('_other')" class="bg-default ">
                                    <i class="fa fa-files-o text-aqua f30"></i><br/>
                                    <span class="text">Autres paiements(DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('_prepaymentList')" class="bg-default ">
                                    <i class="fa fa-file-zip-o text-aqua f30"></i><br/>
                                    <span class="text">Pr&eacute;paiement (DGDA)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="message()" class="bg-default ">
                                    <i class="fa fa-share-square-o text-aqua f30"></i><br/>
                                    <span class="text">Int&eacute;gration manuelle</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('_bulletins')" class="bg-default ">
                                    <i class="fa fa-server text-aqua f30"></i><br/>
                                    <span class="text">Lot des bulletins (DGDA)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox" >
                            <div class="col-sm-4 col-xs-4 box no-border" style="padding-top:3px;">
                                <a onclick="action('_recover')" class="bg-default ">
                                    <i class="fa fa-retweet text-aqua f30"></i><br/>
                                    <span class="text">Recup&eacute;ration des bulletins (DGDA)</span>
                                </a>
                            </div>
                        </div>
                      
                </div>
                <div class="col-md-4 bLeft">
                        <ul class="nav nav-pills nav-stacked">
                                <li id=''><a onclick="action('_taux')" class="text-blue"><i class="fa fa-plus-circle"></i> Changer les taux de change</a></li>
                                <li id=''><a onclick="action('sydonia')" class="text-blue"><i class="fa fa-cogs"></i> Configuration acces SYDONIA</a></li>
                                <li id=''><a onclick="message()" class=""><i class="fa fa-credit-card-alt"></i> Approvisionnement compte pr&eacute;paiement</a></li>
                                <li id=''><a onclick="message()" class=""><i class="fa fa-file-excel-o"></i> Extraction licence BCC</a></li>
                        </ul>
                </div>
                
                <!-- !-->
                <div class="col-md-12">
                        <h2 class="text-blue" ><?php echo " Rapports..."; ?></h2>
                        <p class="page-header"></p>
                </div>
                <div class="col-md-8 bRight">
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('unvalidated')" class="bg-default ">
                                    <i class="fa fa-sticky-note-o text-aqua f30"></i><br/>
                                    <span class="text">Paiements non valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('unvalidatedpassport')" class="bg-default ">
                                    <i class="fa fa-sticky-note-o text-aqua f30"></i><br/>
                                    <span class="text">Passeports non valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('validated')" class="bg-default ">
                                    <i class="fa fa-sticky-note  text-aqua f30"></i><br/>
                                    <span class="text">Paiements valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('validatedpassport')" class="bg-default ">
                                    <i class="fa fa-sticky-note  text-aqua f30"></i><br/>
                                    <span class="text">Paiements des passeports valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('reversed')" class="bg-default ">
                                    <i class="fa fa-share-square-o text-aqua f30"></i><br/>
                                    <span class="text">Paiements revers&eacute;s</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('paiement_tresor')" class="bg-default ">
                                    <i class="fa fa-list-alt  text-aqua f30"></i><br/>
                                    <span class="text">Guichet unique douane (Tresor)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('paiement_propre')" class="bg-default ">
                                    <i class="fa fa-list-ul  text-aqua f30"></i><br/>
                                    <span class="text">Guichet unique (Hors Tresor)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('fond_propre')" class="bg-default ">
                                    <i class="fa fa-list fa-newspaper-o  text-aqua f30"></i><br/>
                                    <span class="text">Fonds propres (DGI & DGRAD)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('paiements_dgda')" class="bg-default ">
                                    <i class="fa fa-list-alt text-aqua f30"></i><br/>
                                    <span class="text">Bulletins comptant(DGDA)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('prepayments')" class="bg-default ">
                                    <i class="fa fa-file-text-o text-aqua f30"></i><br/>
                                    <span class="text">Pr&eacute;paiments (DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="message_up()" class="bg-default ">
                                    <i class="fa fa-files-o text-gray f30"></i><br/>
                                    <span class="text">D&eacute;claration Licence BCC</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="message()" class="bg-default ">
                                    <i class="fa fa-list-alt text-aqua f30"></i><br/>
                                    <span class="text">Int&eacute;grations manuelles</span>
                                </a>
                             </div>
                        </div>
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('taxe')" class="bg-default ">
                                    <i class="glyphicon glyphicon-credit-card text-aqua f30"></i><br/>
                                    <span class="text">Taxe de gardeinnage (DGRAD)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('alltaxe')" class="bg-default ">
                                    <i class="glyphicon glyphicon-credit-card text-aqua f30"></i><br/>
                                    <span class="text">Guichets unique par taxe (DGDA)</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                                <div class="col-sm-4 col-xs-4 box no-border">
                                    <a onclick="action('paiements_passports')" class="bg-default ">
                                        <i class="glyphicon glyphicon-credit-card text-aqua f30"></i><br/>
                                        <span class="text">Paiements des passports</span>
                                    </a>
                                 </div>
                            </div>

                </div>
                <div class="col-md-4 bLeft">
                        <ul class="nav nav-pills nav-stacked">
                                
                                <li id=''><a onclick="action('situation_dgi')" class="text-blue"><i class="fa fa-minus"></i> Situation journali&egrave;re DGI</a></li>
                                <li id=''><a onclick="action('situation_dgrad')" class="text-blue"><i class="fa fa-minus"></i> Situation journali&egrave;re DGRAD</a></li>
                                <li id=''><a onclick="action('situation_dgda')" class="text-blue"><i class="fa fa-minus"></i> Situation journali&egrave;re guichet unique DGDA</a></li>
                                <li id=''><a onclick="" class=""><i class="fa fa-minus"></i> Situation journali&egrave;re de pr&eacute;paiement</a></li>
                                <li id=''><a onclick="action('taux')" class="text-blue"><i class="fa fa-minus"></i> Historique de taux de change</a></li>
								
                        </ul>
                </div>
            </div>
    </div>


    <div class="col-md-1 content" id="cancel">
        <a href="<?php echo base_url($module.'/dashboards/set/overview'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="close">
        <a href="" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    
    <div class="col-md-1 content hidden" id="form_paiement">
        <a href="" class="btn btn-app no-border pull_left" id="close_paymentunique"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_unvalidated">
        <a href="" class="btn btn-app no-border pull_left" id="close_unvalidated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_validated">
        <a href="" class="btn btn-app no-border pull_left" id="close_validated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_order">
        <a href="" class="btn btn-app no-border pull_left" id="close_order"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_orders">
        <a href="" class="btn btn-app no-border pull_left" id="close_orders"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
   
</div>


<script type="text/javascript">
    
    $("#close_unvalidated").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/nvalidated'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_unvalidated").addClass('hidden');
            $("#close").removeClass('hidden');
            
        });
    });
    
    $("#close_paymentunique" ).click(function(){
        $.get("<?php echo base_url($module.'/bank/display/gudouane'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_paiement").addClass('hidden');
            $("#close").removeClass('hidden');
            
        });
    });
    
    $("#close_validated").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/validated'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_validated").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#close_order").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/ordres/new'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_order").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#close_orders").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/ordres'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_orders").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#pager").on("click", "#buttonCloseModal1", function()
    {
        var from = $('#from').val();
        
        if( from == "validated")
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/validated';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_validated").addClass('hidden');
                $("#close").removeClass('hidden');
            });

        }
        else if( from == "payement_unique")
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/gudouane';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_paiement").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }    
        
    });
    
    $("#pager").on("click", "#buttonCloseOrdre", function(){
    
        var from = $('#from').val();
    
        if(from =="new")
        {
            $.get("<?php echo base_url($module.'/bank/display/ordres/new'); ?>", function (data, status) {
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_order").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }
        else
        {
            $.get("<?php echo base_url($module.'/bank/display/ordres'); ?>", function (data, status) {
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_orders").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }

    });
    
    $("#fullscreen").on("click", "#buttonCloseModal", function(){
        location.reload();
    });
    
    function action(which){
    
        $("#alert").html('');
        
        if(which === 'declaration')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/declaration/display/start'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
        if(which === 'note_perception')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/notes/display/start'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#fullscreen").html(data);
                });
        }
		if(which === 'passport')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/passeport/display/passport'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#fullscreen").html(data);
                });
        }
        if(which === 'bulletin')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/bulletin/display/start'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
	if(which === '_credit')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/bulletin/display/credit_start'); ?>", function (data, status) {
                    $("#loader").html('');
                    $("#fullscreen").html(data);
                });
        }
        if(which === 'situation_dgda')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/situation_dgda'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
        if(which === 'situation_dgi')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/situation_dgi'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
        if(which === 'situation_dgrad')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/situation_dgrad'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
        if(which === '_taux')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/rates/display/taux'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }
		
        if(which === '_other')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/others/display/start'); ?>", function (data, status) {
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#close").removeClass('hidden');
                $("#cancel").addClass('hidden');
                $("#col").removeClass('col-md-2');
                $("#col").addClass('col-md-1');
                $("#content").removeClass('col-md-8');
                $("#content").addClass('col-md-10');
                $("#close").removeClass('col-md-2');
                $("#close").addClass('col-md-1');
            });
        }
        
        if(which === '_accise')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/bank/display/comptant'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        
        if(which === '_creditpaiement')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/bank/display/comptant'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        
        if(which === '_order')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/bank/display/ordres/new'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'unvalidated')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/nvalidated'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
		if(which === 'unvalidatedpassport')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/nvalidatedpassports'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'validated')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/pending'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
		if(which === 'validatedpassport')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/pendingpassport'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'reversed')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/transferred'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'paiement_propre')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/paiement_propre'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'paiements_dgda')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/paiements_gu'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        
        if(which === 'paiement_tresor')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/paiement_tresor'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
		if(which === 'taxe')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/taxe_gardeinnage'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
	    if(which === 'alltaxe')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/alltaxe'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'fond_propre')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/fond_propre'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'taux')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/rates/display/list'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        if(which === 'orders')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/bank/display/ordres'); ?>", function (data, status) {
                
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
               
            });
        }
        
        if(which === '_bulletins')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/bulletin/display/batch_start'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === '_recover')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/bulletin/display/batch_recover_start'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#fullscreen").html(data);
                });
        }
        if(which === '_prepaymentList')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/prepayments/display/start'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#fullscreen").html(data);
                });
        }
        if(which === '_prepayment')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/prepayments/display/procurement'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === '_declaration')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/licence/display/start'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === 'prepayments')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/reports/display/prepayments'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === 'declarations')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/reports/display/declarationslist'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === 'sydonia')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/users/display/accountsydonia'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                   $("#pager").addClass('content');
                   $("#close").removeClass('hidden');
                   $("#cancel").addClass('hidden');
                   $("#col").removeClass('col-md-2');
                   $("#col").addClass('col-md-1');
                   $("#content").removeClass('col-md-8');
                   $("#content").addClass('col-md-10');
                   $("#close").removeClass('col-md-2');
                   $("#close").addClass('col-md-1');
                });
        }
        if(which === '_integrations_offline')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/offline/display/paiements'); ?>", function (data, status) {
                    $("#loader").html('');
                    $("#pager").html(data);
                    $("#pager").addClass('content');
                    $("#close").removeClass('hidden');
                    $("#cancel").addClass('hidden');
                    $("#col").removeClass('col-md-2');
                    $("#col").addClass('col-md-1');
                    $("#content").removeClass('col-md-8');
                    $("#content").addClass('col-md-10');
                    $("#close").removeClass('col-md-2');
                    $("#close").addClass('col-md-1');
                });
        }
        if(which === '_integrations')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/offline/display/integrations'); ?>", function (data, status) {
                    $("#loader").html('');
                    $("#pager").html(data);
                    $("#pager").addClass('content');
                    $("#close").removeClass('hidden');
                    $("#cancel").addClass('hidden');
                    $("#col").removeClass('col-md-2');
                    $("#col").addClass('col-md-1');
                    $("#content").removeClass('col-md-8');
                    $("#content").addClass('col-md-10');
                    $("#close").removeClass('col-md-2');
                    $("#close").addClass('col-md-1');
                });
        }
        if(which === 'paiements_passports')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/reports/display/paiements_passports'); ?>", function (data, status) {
                    $("#loader").html('');
                    $("#pager").html(data);
                    $("#pager").addClass('content');
                    $("#close").removeClass('hidden');
                    $("#cancel").addClass('hidden');
                    $("#col").removeClass('col-md-2');
                    $("#col").addClass('col-md-1');
                    $("#content").removeClass('col-md-8');
                    $("#content").addClass('col-md-10');
                    $("#close").removeClass('col-md-2');
                    $("#close").addClass('col-md-1');
                });
        }
        if(which === 'isys')
        {
            
        }
    }
    
    function message(){
        $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Ce menu n\'est pas disponible pour l\'instant, veuillez contacter votre administrateur.</div>');
    }
    
    function message_up(){
        scrollUP();
        $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Ce menu n\'est pas encore disponible, veuillez contacter votre administrateur.</div>');
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>