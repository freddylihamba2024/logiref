<div id="contenter">
    <div class="col-md-1" id="col"></div>
    <div class="col-md-10" id="content">
            <div id="loader"></div>
            <div class="col-md-12" id="alert"></div>
            <div id="pager">
                <!-- !-->
                <div class="col-md-12">
                        <h2 class="text-blue" ><?php echo " Nouveau..."; ?></h2>
                        <p class="page-header"></p>
                </div>
                <div class="col-md-8 bRight">
                        
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('note_perception')" class="bg-default ">
                                    <i class="fa fa-file-text-o text-aqua f30"></i><br/>
                                    <span class="text">Achat des Passeports</span>
                                </a>
                             </div>
                        </div>
                        
                </div>
                <div class="col-md-4 bLeft">
                        <ul class="nav nav-pills nav-stacked">
                                <li id=''><a onclick="action('_taux')" class="text-blue"><i class="fa fa-plus-circle"></i> Changer les taux de change</a></li>
                        </ul>
                </div>
                <!-- !-->
                <div class="col-md-12">
                        <h2 class="text-blue" ><?php echo " Rapports..."; ?></h2>
                        <p class="page-header"></p>
                </div>
                <div class="col-md-8 bRight">
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('unvalidatedpassport')" class="bg-default ">
                                    <i class="fa fa-sticky-note-o text-aqua f30"></i><br/>
                                    <span class="text">Passeports non valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
						<div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('validatedpassport')" class="bg-default ">
                                    <i class="fa fa-sticky-note  text-aqua f30"></i><br/>
                                    <span class="text">Paiements des passeports valid&eacute;s</span>
                                </a>
                             </div>
                        </div>
                        <div class="col-md-4 appsbox">
                            <div class="col-sm-4 col-xs-4 box no-border">
                                <a onclick="action('reversed')" class="bg-default ">
                                    <i class="fa fa-share-square-o text-aqua f30"></i><br/>
                                    <span class="text">Paiements revers&eacute;s</span>
                                </a>
                             </div>
                        </div>
                </div>
                 <div class="col-md-4 bLeft">
                        <ul class="nav nav-pills nav-stacked">
                                
                            <li id=''><a onclick="action('situation_dgrad')" class="text-blue"><i class="fa fa-minus"></i> Situation journali&egrave;re DGRAD</a></li>
                            <li id=''><a onclick="action('taux')" class="text-blue"><i class="fa fa-minus"></i> Historique de taux de change</a></li>
								
                        </ul>
                </div>
               
            </div>
    </div>


    <div class="col-md-1 content" id="cancel">
        <a href="<?php echo base_url($module.'/dashboards/set/overview'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="close">
        <a href="" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    
    <div class="col-md-1 content hidden" id="form_paiement">
        <a href="" class="btn btn-app no-border pull_left" id="close_paymentunique"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_unvalidated">
        <a href="" class="btn btn-app no-border pull_left" id="close_unvalidated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_validated">
        <a href="" class="btn btn-app no-border pull_left" id="close_validated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_order">
        <a href="" class="btn btn-app no-border pull_left" id="close_order"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content hidden" id="form_orders">
        <a href="" class="btn btn-app no-border pull_left" id="close_orders"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
   
</div>

<script type="text/javascript">
    
    $("#close_unvalidated").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/nvalidated'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_unvalidated").addClass('hidden');
            $("#close").removeClass('hidden');
            
        });
    });
    
    $("#close_paymentunique" ).click(function(){
        $.get("<?php echo base_url($module.'/bank/display/gudouane'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_paiement").addClass('hidden');
            $("#close").removeClass('hidden');
            
        });
    });
    
    $("#close_validated").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/validated'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_validated").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#close_order").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/ordres/new'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_order").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#close_orders").click(function(){
        $.get("<?php echo base_url($module.'/bank/display/ordres'); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#form_orders").addClass('hidden');
            $("#close").removeClass('hidden');
        });
    });
    
    $("#pager").on("click", "#buttonCloseModal1", function()
    {
        var from = $('#from').val();
        
        if( from == "validated")
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/validated';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_validated").addClass('hidden');
                $("#close").removeClass('hidden');
            });

        }
        else if( from == "payement_unique")
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/gudouane';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_paiement").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }    
        
    });
    
    $("#pager").on("click", "#buttonCloseOrdre", function(){
    
        var from = $('#from').val();
    
        if(from =="new")
        {
            $.get("<?php echo base_url($module.'/bank/display/ordres/new'); ?>", function (data, status) {
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_order").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }
        else
        {
            $.get("<?php echo base_url($module.'/bank/display/ordres'); ?>", function (data, status) {
                $("#loader").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#form_orders").addClass('hidden');
                $("#close").removeClass('hidden');
            });
        }

    });
    
    $("#fullscreen").on("click", "#buttonCloseModal", function(){
        location.reload();
    });
    
    function action(which){
    
        $("#alert").html('');
        
        
        if(which === 'note_perception')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/passeport/display/passport'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#fullscreen").html(data);
                });
        }
        
        if(which === '_taux')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/rates/display/taux'); ?>", function (data, status) {
               $("#loader").html('');
               $("#fullscreen").html(data);
            });
        }

        if(which === 'unvalidatedpassport')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/nvalidatedpassports'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
		if(which === 'validatedpassport')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/pendingpassport'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }

        if(which === 'reversed')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/reports/display/transferred'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        
        if(which === 'taux')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/rates/display/list'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');
               $("#close").removeClass('hidden');
               $("#cancel").addClass('hidden');
               $("#col").removeClass('col-md-2');
               $("#col").addClass('col-md-1');
               $("#content").removeClass('col-md-8');
               $("#content").addClass('col-md-10');
               $("#close").removeClass('col-md-2');
               $("#close").addClass('col-md-1');
            });
        }
        
    }
    
    function message(){
        $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Ce menu n\'est pas disponible pour l\'instant, veuillez contacter votre administrateur.</div>');
    }
    
    function message_up(){
        scrollUP();
        $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Ce menu n\'est pas encore disponible, veuillez contacter votre administrateur.</div>');
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>