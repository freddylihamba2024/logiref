<?php $this->chtml->box_body_opening('', true); ?> 
<?php if (!empty($prepayments)): ?>
        <table id="table" class="table no-margin table-striped table-bordered">
            <thead class='bg-blue'>
                <tr>
                   <th width="2%">#</th>
                    <th width="10%">Date</th>
                    <th width="15%">Statut</th>
                    <th width="">Num&eacute;ro imp&ocirc;t</th>
                    <th width="">Bureau</th>
                    <th width="15%">Bulletin</th>
                    <th width="">Montant</th>
                    <th width="5%"><span class="fa fa-fw fa-tasks f14"></span></th>
                    <th width="5%"><span class="fa fa-fw fa-check f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php   
                    $i = 1;
                    foreach($prepayments as $row){ 
                ?>
                    <tr>
                        <td><span class="text-blue"><?php echo $i;?></span></td>
                        <td>
                            <?php echo $row->Date_1; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo $color[$row->Status_2];?>"> <?php echo $status[$row->Status_2]; ?></span>
                        </td>
                        <td>
                            <?php echo $row->Nif_15; ?>
                        </td>
                        <td>
                            <?php echo $services['DGDA'][$row->Office_8]; ?>
                        </td>
                        <td>
                            <?php echo $row->Serial_9.''.$row->Number_10; ?>
                        </td>
                        <td>
                           <span class="text-blue"><?php echo 'CDF '.number_format($row->Amount_18,2,","," "); ?></span>
                        </td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1): ?>
                                <a style="cursor:pointer" onclick="edit('<?php echo $row->Id_0;?>')"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                             <?php elseif($row->Status_2 == 2 || $row->Status_2 == 3): ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0;?>')"> <span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            <?php elseif($row->Status_2 == 4): ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0;?>')"> <span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                            <?php endif;?> 
                        </td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1 || $row->Status_2 == 2): ?>
                                <span class="fa fa-fw text-gray fa-question-circle f14"> </span>
                            <?php elseif($row->Status_2 == 3): ?>
                                <input type="checkbox" class="text-blue" id="p<?php echo $row->Id_0;?>"  onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->MessageKey_7; ?>" name="messageskeys[<?php echo $row->Id_0;?>]" />
                            <?php elseif($row->Status_2 == 4): ?>
                                <span class="fa fa-fw text-blue fa-check-circle f14"> </span>
                            <?php elseif($row->Status_2 == 5): ?>
                                <span class="fa fa-fw text-red fa-times-circle f14"> </span>
                            <?php endif;?> 
                        </td>
                    </tr>
                <?php 
                $i++;
                    } ?>
            </tbody>
        </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucun pr&eacute;paiement trouv&eacute; !</b></h4>
            <br/>
        </div>
    </section>
<?php endif; ?> 
<?php $this->chtml->box_body_closing(); ?>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
    "paging": true,
    "order": [[5, "DESC" ]],
    "lengthChange": false,
    "searching": false,
    "ordering": true,
    "info": true,
    "autoWidth": false
});

function view(bId)
{
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments/display/preview'); ?>/' +bId ;
        $.get(url, function(data){
            $("#loader1").html('');
            $("#pager").html(data);
        });
}



function edit(id)
{
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments/display/traitement'); ?>/' +id ;
        $.get(url, function(data){
            $("#loader1").html('');
            $("#pager").html(data);
        });
}
</script>