<div class="col-md-7">
    <h2 class="text-blue">Les pr&eacute;paiments(DGDA)</h2>
    <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente touts les pr&eacute;paiments faits par vos clients &agrave; la douane.</span></h5>
</div>
<?php echo form_open('', array('id' => 'sendack', 'class' => 'innovate')); ?>
<div class="col-md-5">
    <br/>
    <div class="col-md-7 bLeft">
        <div class="form-group">
            <span class="input-group"><label for="message">Message</label></span> 
            <?php echo form_dropdown('message',$messages, '', 'class="form-control" id="message" required = "required"'); ?>
        </div>
    </div>
    <div class="col-md-5" id="ack" style="padding-left: 40px;">
        <div class="form-group">
             <span class="input-group"><label for="message">&nbsp;&nbsp;&nbsp;&nbsp;</label></span> 
            <button type="submit" id="submit" name="submit" disabled="disabled" class="btn btn-success  margin-bottom">Accuser r&eacute;ception <span class="Bold" id="index"></span> <i class="fa fa-check"></i></button>
        </div>
    </div>
</div>
<div><br></div>
<div class="col-md-12">
    <div id="loader" class="col-md-12"></div>
    <div id="panel" class="col-md-12">
        
    </div>
</div>
<?php echo form_close(); ?>
<div class="modal fade" id="modal">
    <div class="modal-dialog">
        <div class="modal-content tScroll">
            <div class="modal-header">
              <button id="CloseModal" type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">D&eacute;tails du paiement</h4>
            </div>
            <div id="modal-pager" class="modal-body">
              <p>One fine body&hellip;</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
        <!-- /.modal-dialog -->
</div>
<script type="text/javascript">
 
get_prepayments();
$("#CloseModal").click(function(){
    get_prepayments();
});



function validate(id)
{
    $("#p"+id).change(function()
        {
                var $checkedInputs = $('#table').find("input:checked");
                var index = $checkedInputs.length;
               
                if(index > 0)
                {
                        $("#ack").css("padding-left", '20px');
                        $("#submit").removeClass("btn-success");
                        $("#submit").prop("disabled",false);
                        $("#submit").addClass("btn-primary");
                        $("#index").html('('+ index+')');
                        

                }
                else if(index <= 0)
                {
                        $("#submit").removeClass("btn-primary");
                        $("#submit").addClass("btn-success");
                        $("#submit").prop("disabled",true);
                        $("#index").html('');
                        $("#ack").css("padding-left", '40px');
                }

        });
}

$('#sendack').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments'); ?>/display/prepaymentsAck';
        var data = $(this).serialize();
        var message = $("#message").val();
        if(message !== "")
        {
            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    
                    if(result ==='41' || result ==='42')
                    {
                        $('#loader').html('');
                        $("#loader").html('<div class="alert alert-success text-white">Bravo! Transaction cl&ocirc;tur&eacute;e avec succ&egrave;s...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result ==='E404')
                    {
                        $('#loader').html('');
                        $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result ==='E401')
                    {
                        $('#loader').html('');
                        $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                   
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
            });
        }
        else
        {
                $("#loader").html('<div class="alert alert-warning text-white">Alerte: Le champ message n\'est peut pas &ecirc;tre vide!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
});

function get_prepayments()
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/prepayments/display/allprepayments'); ?>/", function(data, status){
            $("#loader").html('');
            $("#panel").html(data);
      });
}

</script>

