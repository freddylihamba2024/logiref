<?php  $recieptDate = explode("/",$bulletin->DateL_11); ?>
<div id="pager">
    <div class="col-md-12">
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $this->chtml->box_body_opening('', true);?>

        <div class="col-md-8 bRight">
            <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
            <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
            <input type="hidden" name="Id_0" value="<?php echo $bulletin->Id_0; ?>">
                <div class="box-body">
                    <div class="col-md-12">
                        <h2 class=" f20 w-300 page-header">Traitement de bulletin  pr&eacute;pay&eacute;</h2>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label for="Service_16">Bureau (ou service)</label> 
                            <?php echo form_dropdown('Office',$services['DGDA'],$bulletin->Office_8, 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="year">Ann&eacute;e</label> 
                            <?php echo form_input('Year',$recieptDate[2], 'class="form-control" id="year" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="year">Banque</label> 
                            <?php echo form_input('Bank',$bulletin->CodeBank_13, 'class="form-control bg-gray" id="year" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                            <?php echo form_input('Nif',$bulletin->Nif_15, 'class="form-control" id="company" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                           <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                            <?php echo form_input('Agent',$bulletin->Declarant_16, 'class="form-control" id="declarant" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="assessment_serial">S&eacute;rie</label>
                            <?php echo form_input('Series',$bulletin->Serial_9, 'class="form-control" id="assessment_serial" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="assessment_number">Num&eacute;ro du bulletin</label>
                            <?php echo form_input('Number',$bulletin->Number_10, 'class="form-control" id="assessment_number" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="Montant_11">Montant &agrave; payer</label>
                            <?php echo form_input('Amount',$bulletin->Amount_18, 'class="form-control" id="Montant_11" required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="devise">Devise</label>
                            <?php echo form_dropdown('devise', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                            <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="Mode">Mode de paiement</label> 
                            <?php echo form_dropdown('Mode', $modes, "7", 'class="form-control" required="required" id="modeId"'); ?>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label for="Account" id="accountname">Compte du client &agrave; d&eacute;buter</label>
                            <?php echo form_input('bank_account',$account, 'class="form-control" id="bank_account" placeholder="E.g: 0000100002000030000400005" required="required" '); ?>
                            <input type="hidden" name="account_name" value="" id="account_name">
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="Devise_account">Devise de ce compte</label>
                            <?php echo form_dropdown('Devise_account', $devises, "CDF", 'class="form-control" id="account_devise" disabled="disabled"'); ?>
                            <input type="hidden" name="Devise_account" value="<?= $devises['CDF'] ?>" >
                        </div>
                    </div>
                </div>
                <div id="details" class="col-md-12"></div>
                <div class="box-footer clearfix">
                    <div class="col-md-12">
                        <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="save" class="btn btn-default" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Suivant&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="action" value="" id="action">
                        <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
                    </div>
                </div>
        </div>
        <div class="col-md-4 no-padding " id="treatment">

        </div>

        <?php $this->chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>
    </div>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
 var lot = '<?php echo $lot; ?>';
 
 get_accountname();
 
$("#save").click(function(){
    
        $("#action").val('save');
});

$("#treat").click(function(){
    
        $("#action").val('traiter');
});

$('.chosen-select').chosen({width: "100%"});
   
$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        if(action == 'traiter')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/prepayments/display/verification'); ?>/<?php echo $bulletin->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                        if(result === "E003")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E22" || result === "E13")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               
                        }
                        else if(result === "E11")
                        {
                                $('#loader2').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E000")
                        {
                                $('#loader2').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#loader').html('');
                                $("#save").removeClass('btn-default');
                                $("#save").addClass('btn-success');
                                $("#save").prop('disabled', false);
                                $('#treatment').html(result);
                        }
                       
                    },
                    error:function(error)
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }
        else if(action == 'save')
        {
            next_step(data);
        }
});

$("#balance").css('background-color','#00cc33');

$("#close").click(function(){
        location.reload(true);
});

$("#bank_account").change(function(){
    get_accountname(); 
});

$("#account_devise").change(function(){
    get_accountname(); 
});

   
function next_step(data)
{
       $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
       $('#envoyer').prop("disabled", true);
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');
       var url = '<?php echo base_url($module.'/prepayments/display/edit'); ?>/<?php echo $bulletin->Id_0; ?>';
       $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                        $('#loader').html('');
                        $("#pager").html(result);
               },
                error:function(error)
                {
                    $("#step-2").removeClass('bg-green-active');
                    $("#step-2").addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray');
                    $("#step-3").addClass('bg-green-active');
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
       });
                       
}

function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else
                                {
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse);
                                        $("#account_name").val(reponse);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

</script>
