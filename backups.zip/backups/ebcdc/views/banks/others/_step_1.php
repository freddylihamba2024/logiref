<?php $userid = $this->session->userdata("user_id");  $Infos = $encaissement->Notereference_30; $idBL = '';?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php //if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,0,","," "); ?>
<?php //if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,0,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php $Standard01=''; $total = 0;  ?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="loader"></div>
    <?php $this->chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                <input type="hidden" name="Makerid_9" value="<?php echo $this->session->userdata('user_id'); ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header"><?php echo '#'.$encaissement->Noteid_26; ?>: Renseignez les informations requises</h2>
                </div> 
                
                 <!-------------------------  Titre de perception  ------------------------------>
                
                <div id="DGDAComplement">
                    <div class="col-md-12"><br/><label>Partie 1 : Informations du bulletin</label><br/></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="standard"><div id="StandardLabel01">D&eacute;clarant</div></label> 
                            </span>
                            <?php echo form_input("Infos[Agent]",'0000', ' class="form-control" id="Standard01" required="required" maxlength="25"'); ?>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Service_16">Bureau</label>
                            </span>
                            <?php echo form_dropdown('Service_16', $services,'501B', 'class="form-control chosen-select" id="service" required="required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-12"></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="serie">S&eacute;rie bulletin</label>
                            </span>
                            <?php echo form_input('Infos[serie]', 'L', 'class="form-control" required="required"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="serie">S&eacute;rie quittance</label>
                            </span>
                            <?php echo form_input('Infos[Qserie]', 'Q', 'class="form-control" required="required"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Reference_32">R&eacute;f&eacute;rence OP</label>
                            </span>
                            <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="number">Num&eacute;ro bulletin</label>
                            </span>
                            <?php echo form_input('Infos[number]', '', 'class="form-control" required="required"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="number">Num&eacute;ro quittance</label>
                            </span>
                            <?php echo form_input('Infos[Qnumber]', '', 'class="form-control" required="required"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="bank">Banque</label>
                            </span>
                            <?php echo form_input('Infos[bank]', '1101', 'class="form-control" required="required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                       
                        <div class="input-group">
                            <span class="input-group-addon">
                                <b>Date note</b>
                            </span>
                            <?php echo form_input('Notedate_27', set_value('Notedate_27', gmdate('Y-m-d')), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <b>Date quit</b>
                            </span>
                            <?php echo form_input('Infos[receiptdate]', set_value('Infos[receiptdate]', gmdate('Y-m-d')), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <b>Ann&eacute;e</b>
                            </span>
                            <?php echo form_input('Infos[year]', '2021', 'class="form-control" required="required"'); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-12"></div>
                <!------------------------- Payement  ------------------------------>
                <div class="col-md-5 border"><br/><label>Partie 3 : Client, Assujetti ou Contribuable. </label></div>
                <div class="col-md-7 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"></span><span class="text-red" id="taxinfo"></span></label></div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif_13">NIF Client</label> 
                        </span>
                        <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14">Designation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19">Mode</label> 
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, '', 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41">Taux de change</label> 
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                           <label for="Datevaleur_31">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div >
                        <br/><label>Paie TVA&nbsp;<input type="checkbox" name="tva" id="tva" disabled="disabled" value="<?= 1 ?>" checked></label>
                        <input type="hidden" id="tva_value" name="tva" value="1">
                    </div >
                    
                </div>
                <div class="col-md-5">
                    <div class="input-group"> 
                        <span class="input-group-addon">
                            <label for="Compte_33">Compte &agrave; d&eacute;biter</label> 
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" required="required" id="compteId"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11">Montant &agrave; payer</label> 
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23">Commission</label> 
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), ' id="commission" class="form-control" required="required"'); ?>
                    </div>
                    

                    <div>
                        <br/><label>Paie pour compte&nbsp;<input type="checkbox" name="pourcompte" value="<?= 1 ?>"></label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_34', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required"  id="compteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_12', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF'),'CDF', 'class="form-control" id="commissionDevise"  required="required"'); ?>
                    </div>
                </div>
               
                <!-------------------------  DGDA Informations additionnelles  ------------------------------>
                <div>
                    <div class="col-md-12"><br/><label id="infosTitle">Partie 4 : diff&eacute;rentes taxes </label><br/></div>
                    <div id="details" class="col-md-12">
                        <div class="table-responsive">
                            <table class="table no-margin table-striped table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th>Taxe</th>
                                        <th>Montant</th>
                                        <th class="center" width="2%"><span class="fa fa-fw fa-trash-o f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody id="listTaxes">
                                    <?php for($i=1; $i < 2; $i++){ ?>
                                        <tr id="line<?= $i; ?>"> 
                                            <td><?php echo form_dropdown('taxes[]', $recettes, '', 'class="form-control itemgrid iwtd" required="required"'); ?></td>
                                            <td><input type="text" value="" name="amounts[]"  id="fields<?= $i; ?>" data-id-field="<?= $i; ?>" class="itemgrid form-control fields" required="required"/></td>
                                            <td align="center"><a style="cursor:pointer" onclick="" ><span class="fa fa-fw text-red fa-trash-o f14 text-gray"> </span></a></td>
                                        </tr>
                                    <?php } ?>
                                    <input type="hidden" value="<?= $i-1; ?>" id="increment" >
                                    <input type="hidden" value="0" id="amount_total" >
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td class="pull-right"><b>Montant total du bulletin :</b></td>
                                        <td><b><span id="total">0,00</span> CDF</b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            <button id="addfield" type="button" onclick="addField()" class="btn btn-primary pull-right">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                    <div  id="Comptabilisation" class="col-md-12"></div>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div id="createPaiement" class="col-md-12">
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; Attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="closeModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
$('.chosen-select').chosen({width: "100%"});
var ref = '<?php echo $encaissement->Id_0;?>';



//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	 format: 'yyyy-mm-dd'
});

$("#compteId").change(function(){
     var compte = $("#compteId").val();
    if(compte.length == 14)
    {
            $('#internal_account').val(compte);
            get_accountname_internal();
    }
    else
    {
            $('#internal_account').prop('disabled', true);
            get_accountname();
    }
});

$("#compteDevise").change(function(){
    var compte = $("#compteId").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    } 
});

$('#recetteMontant').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#recetteMontant').change(function(){
    
    $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var montant = $(this).val()
    if(montant !== '')
    {
        checkMontant();
        commission();
    }
   
    
});

$("#closeModal").click(function(){
    location.reload(true);
});

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});


function submiter(data){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/others/display/encaissement'); ?>';
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E404" || result === "E22")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E405")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E13")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Cette D&eacute;claration est introuvable.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34x")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                var url = '<?php echo base_url($module.'/others/display/preview'); ?>/' + result;
                                $.get(url, function(data, status){
                                    $('#loader').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                })
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}



function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

function get_accountname_internal()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#account_devise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        }
}
function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGDA';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var commission = $("#commission").val();
        var recette = '';
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service , recette : recette, devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '' || commission == '0')
                        {
                            $("#commission").html();
                            $("#commission").val(result[0]);
                            $("#commissionDevise").val(result[1]);
                            
                        }
                        //$('#loader').html(reponse);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}

$("#details").on("change", ".fields", function()
{
        var id_field = $(this).attr('data-id-field');
        
        var montant = $('#fields'+id_field).val();
        
        var montant_total = $('#amount_total').val();
        
        var recetteMontant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
        
        var montant = parseFloat($('#fields'+id_field).val().split(' ').join('').split(',').join('.'));
        
        montant_total = parseFloat(montant_total);
        
        montant_total += montant;
        
        if(montant_total > recetteMontant)
        {
            scrollUP();
            $('#loader').html('<div class="alert alert-warning text-white">La somme des montants des taxes ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        else
        {
            $('#amount_total').val(montant_total)
        
            $('#total').html(montant_total.toLocaleString())
        }
        
        
});

$("#details").on("keyup", ".fields", function()
{
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

function addField()
{
        var increment = $('#increment').val();
        increment = parseFloat(increment);
        increment +=1;
        $('#increment').val(increment);
        
        var url = '<?php echo base_url($module.'/others'); ?>/display/selectTaxes';
        $.get(url, function(data, status){

            $("#listTaxes").append('<tr id="line'+increment+'"><td>'+ data +'</td><td><input type="text" name="amounts[]" value="" class="itemgrid form-control fields" id="fields'+increment+'" data-id-field="'+increment+'" required="required"></td><td align="center"><a style="cursor:pointer" onclick="deleField('+increment+')" ><span class="fa fa-fw text-red fa-trash-o f14"></span></a></td></tr>');
        });
        
}

function deleField(id)
{
        var montant = parseFloat($('#fields'+id).val().split(' ').join('').split(',').join('.'));
        
        $('#line'+id).remove();
        
        var montant_total = parseFloat($('#amount_total').val().split(' ').join('').split(',').join('.'));
        
        montant_total = montant_total - montant;
        
        $('#amount_total').val(montant_total);
        
        $('#total').html(montant_total.toLocaleString());
        
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}


function checkMontant()
{
        var MontanTotal = parseFloat($('#amount_total').val().split(' ').join('').split(',').join('.'));
        var recetteMontant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));


        if(recetteMontant <= MontanTotal)
        {
            $('#recetteMontant').val('');
            $('#commission').val('');
        }
}

</script>



