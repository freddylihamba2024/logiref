<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold">
            LISTES DES COMPTES
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Agence</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Type</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Devise</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Compte</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>B&eacute;n&eacute;ficiaire</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Maker</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Checker</b></td>
        <td style="border-bottom:1px solid black; font-size:1em;"><b>Validation</b></td>
    </tr>

    <?php 
        
        $i=2;
        foreach($comptes as $row)
        {
            
            ?>
                    <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                        <td width="15%" style="font-size:1.1em;"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                        <td width="" style="font-size:1em;"><?php if(isset($guichets[$row->Agence_12])) echo $guichets[$row->Agence_12];?></td>
                        <td width="" style="font-size:1em;"><?php echo ' '.$row->Type_4;?></td>
                        <td width="" style="font-size:1em;"><?php echo $row->Devise_8;?></td>
                        <td width="" style="font-size:1em;"><?php if($row->Type_4!='CAC' || $row->Type_4!='CPI') echo '<b>'.$row->Agenceid_15.'</b>'; else echo '<span class="text-red">'.$row->Agenceid_15.'</span>'; ?><?php if($row->Compte_6!='') echo '-'.$row->Compte_6;?><?php if($row->Clef_7!='') echo '-'.$row->Clef_7;?></td>
                        <td width="" style="font-size:1em;"><?php echo ' '.$row->Beneficiaires_5;?></td>
                        <td width="" style="font-size:1em;"> <?php echo(isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';?></td>
                        <td width="" style="font-size:1em;">
                            <?php if($row->Checkerid_11==0){ ?>
                                <span class="text-red"> - </span>
                            <?php }else {?>
                                <?php echo(isset($users[$row->Checkerid_11]))?$users[$row->Checkerid_11]:' - ';?>
                            <?php } ?>
                        </td>
                        <td width="" style="font-size:1em;">
                            <?php if($row->Checkerid_11==0){ ?>
                                <span class="text-red"> En attente </span>
                            <?php }else {?>
                                <?php echo $row->Validation_10;?>
                            <?php } ?>
                        </td>
                    </tr>
            <?php 
            $i++;   
        }
    ?>
</table>
