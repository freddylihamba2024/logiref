<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>

<body style="padding: 20px 20px">
    <table style="width: 100%">
        <tr>
            <td>
                <div style="padding: 10px 10px">
                    <?php $page = $_SESSION['account_logo']; ?>
                    <?php if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $logo; ?>" width="150" height="150" />
                    <h3 style="font-family: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></h3>
                </div>
            </td>
            <td align ="right" style="">
                <div>
                    <p><?= isset($cbs_return['Num_evenement']) ? $cbs_return['Num_evenement'] : ""; ?>/ <?php echo gmdate("d/m/Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    <h3 align="center" style="color:black; padding-top: 100px; border: 1px solid black; padding: 2px; font:italic bold caption 1.3em  sans-serif;">&nbsp;&nbsp;&nbsp;&nbsp; ATTESTATION DE PAIEMENT POUR LE COMPTE DE LA DGI, ONEM, INPP ET CNSS <span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</h3>

    <span style="padding-top: 300px;">
        <p style="text-align:justify; ">
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?>, Agence de KINSHSA-SIEGE</span> atteste avoir encaiss&eacute; en date du <?php echo $encaissement->Datevaleur_31; ?>&nbsp; d'ordre de
                <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo $encaissement->Designation_14; ?></span>, pour compte de DGI, ONEM, INPP & CNSS, la somme de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?>
                au titre des Imp&ocirc;t,Cotisations et contributions patronales sur les remunerations du mois de
        </p>
    </span>
    
    
    <table style="width: 100%">
        <tr>
            <td>
                <div>
                    <h6>BENEFICIAIRES</h6>
                     <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
                     <?php $dgi = $encaissement->Contrevaleur_22 -  ($infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']); ?>
                        <table>
                            <tr><td> - DGI &nbsp;&nbsp;:</td></tr>
                            <tr><td> - CNSS &nbsp;&nbsp;:</td></tr>
                            <tr><td> - INPP &nbsp;&nbsp;:</td></tr>
                            <tr><td> - ONEM &nbsp;&nbsp;:</td></tr>
                            <hr>
                            <tr><td> TOTAL:</td></tr>
                         </table>
                     <?php endif;?> 
                </div>
            </td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
            <td align ="left" style="">   
                <div>
                    <h6>MONTANT</h6>
                    <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
                    <?php $dgi = $encaissement->Contrevaleur_22 -  ($infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']); ?>
                        <table>
                            <tr><td><?php echo 'CDF '.number_format($dgi,2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasINSS'],2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasINPP'],2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasONEM'],2,","," "); ?></td></tr>
                            <hr>
                            <tr><td><?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td></tr>
                        </table>
                    <?php endif;?>
                </div>
            </td>
        </tr>
    </table>
    
    
    <div style="padding-top:  100px;">
        <p align="center">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?>.<br>
        </p>
        
        <p align="center">
            <?php echo ' '.$this->session->userdata('account_business').' '; ?>
        </p>
        <p align="center">
            </br></br>
            (Signature autoris&eacute;e et cachet sec)
        </p></br>

    </div>



    
    
    
    
    <div style="padding-top:  200px;">
        <table style="border: 1px solid black; padding: 5px;" align="center">
            <th>
                <tr>
                    <td> La pr&eacute;sente attestation n'est valable que si le montant est inscrit au Protectograph</td>
                </tr>    
            </th>
        </table>

    </div>
    
    
   

</body>
