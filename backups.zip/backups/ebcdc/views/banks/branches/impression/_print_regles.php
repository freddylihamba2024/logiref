<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold">
            LISTES DES REGLES DES COMMISSIONS
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>
<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Priorit&eacute;</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>B&eacute;n&eacute;ficiaires</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Indice</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Services</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Recette</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Guichet</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Min</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Max</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Validation</b></td>
    </tr>

    <?php 
        
        $i=2;
        foreach($regles as $row)
        {
            
            ?>
                <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                    <td width="10%" style="font-size:0.8em;">P<?php echo $row->Priorite_4; ?></td>
                    <td width="" style="font-size:0.8em;"><?php if($row->Beneficiaire_5=='' or $row->Beneficiaire_5=='0') echo 'TOUS'; else echo ' '.$row->Beneficiaire_5;?></td>
                    <td width="" style="font-size:0.8em;"><?php echo number_format($row->Value_9,2,","," ") .' '.$row->Unite_10;?></td>
                    <td width="" style="font-size:0.8em;"><?php if($row->Service_6=='') echo 'TOUS'; else echo ' '.$services[$row->Beneficiaire_5][$row->Service_6];?></td>
                    <td width="" style="font-size:0.8em;"><?php if($row->Recette_7=='') echo 'TOUTES'; else echo ' '.$row->Recette_7;?></td>
                    <td width="" style="font-size:0.8em;"><?php if($row->Guichet_8=='') echo 'TOUS'; else echo ' '.$guichets[$row->Guichet_8];?></td>
                    <td width="" style="font-size:0.8em;"><?php echo $row->Devise_13.' '.number_format($row->Min_11,2,","," ");?></td>
                    <td width="" style="font-size:0.8em;"><?php echo $row->Devise_13.' '.number_format($row->Max_12,2,","," ");?></td>
                    <td width="" style="font-size:0.8em;">
                        <?php if($row->Checkerid_15==0){ ?>
                            <span class="text-red"> En attente </span>
                        <?php }else {?>
                            <?php echo $row->Validation_16;?>
                        <?php } ?>
                    </td>
                </tr>
            <?php 
            $i++;   
        }
    ?>
</table>


