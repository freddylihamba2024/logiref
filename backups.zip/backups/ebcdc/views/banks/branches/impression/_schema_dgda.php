<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <table style="width: 100%">
        <tr>
            <td>
                <div style="padding: 10px 10px">
                    <?php $page = $_SESSION['account_logo']; ?>
                    <?php if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $logo; ?>" width="150" height="150" />
                    <h3 style="font-family: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></h3>
                </div>
            </td>
            <td align ="right" style="">
                <div>
                    <p><?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]; ?> / <?php echo  $encaissement->Id_0;?> / <?php echo gmdate("Y"); ?> </p>
                    <p> 
                        R&eacute;f&eacute;rence : <?php echo $encaissement->Reference_32;?>
                    </p>
                </div>
            </td>
        </tr>
    </table>
    <h3 align="center" style="color:black; padding-top: 100px; font: bold caption 1.3em  sans-serif;">&nbsp;&nbsp;&nbsp;&nbsp; BORDEREAU DE PAIEMENT <span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</h3>
<hr>
<span style="padding-top: 300px;">
    <p>
        <?php if(!empty($lines)): ?>
            <table style="border-collapse: collapse;" width="100%" cellspace="1" cellpadding="6">
                <thead >
                  <tr style="background-color:#eaeaec;">
                    <th style="font-size:0.7em;" width="9%" align="left">Sens</th>
                    <th style="font-size:0.7em;" align="left">D&eacute;bit</th>
                    <th style="font-size:0.7em;" align="left">Cr&eacute;dit</th>
                    <th style="font-size:0.7em;" align="left">Montant</th>
                    <th style="font-size:0.7em;" align="left">Designation</th>
                    <th style="font-size:0.7em;" width="13%" align="left">N&ordm; finacle</th>
                    <th style="font-size:0.7em;" width="13%" align="left">Statut</th>
                  </tr>
                </thead>
                <tbody>
                    <?php 
                    $i=2;
                    foreach($lines as $row){
                        $infos = json_decode($row->Details_23, true);
                        $num_event = $infos['Num_evenement'];
                    ?>
                        <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                            <td style="font-size:0.8em;"><?php echo $row->Operation_8; ?></td>
                            <?php if($row->Operation_8 == "V"):?>
                                  <td style="font-size:0.7em; <?php if($row->Compte_9=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_9; ?></td>
                                  <td style="font-size:0.7em; <?php if($row->Compte_13=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_13; ?></td>
                            <?php else :?>
                                  <td style="font-size:0.7em;"><?php echo '-'; ?></td>
                                  <td style="font-size:0.7em; <?php if($row->Compte_9=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_9; ?></td>
                            <?php endif;?>
                            <td style="font-size:0.7em;"><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                            <td style="font-size:0.7em;"><?php echo $row->Libelle_12; ?></td>
                            <td style="font-size:0.7em;"><?= isset($cbs_return['Num_evenement']) ? $cbs_return['Num_evenement'] : ""; ?></td>
                            <td style="font-size:0.7em;"><?php if(isset($cbs_return['code']) && $cbs_return['code'] =='200'){ echo "Int&eacute;gr&eacute;"; } elseif(isset($cbs_return['code']) && $cbs_return['code'] =='404'){ echo "Non int&eacute;gr&eacute;"; } elseif(isset($cbs_return['code']) && $cbs_return['code'] =='300'){ echo "En attente"; } else{ echo ""; } ?></td>
                        </tr>
                    <?php 
                    $i++; 
                    } ?>
                </tbody>    
            </table>
      <?php endif;?>
    </p>
    <div style="padding-top:  100px;">
    <p align="right">
        Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d-%m-%Y',strtotime(gmdate('d-m-Y'))); ?>.
    </p>
    <p align="right">
        Par <?php echo $users[$encaissement->Makerid_9];?>
    </p>
    <hr>
    <p align="center" >
       
        Code s&eacute;curit&eacute; : <?php echo  $encaissement->Logirefid_4;?> |<?php echo ' '.$this->session->userdata('account_business').' '; ?>| Logiref | RDC
    </p>
    </div>
</span>
</body>
</html>

