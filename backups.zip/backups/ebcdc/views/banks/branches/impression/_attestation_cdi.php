
<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <table style="width: 100%">
        <tr>
            <td>
                <div style="padding: 50px 50px">
                    <?php $page = $_SESSION['account_logo']; ?>
                    <?php if(isset($page) && $page!= '') $logo = $page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
                    <img src="<?php echo $logo; ?>" width="150" height="150" />
                    <h3 style="font-family: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></h3>
                </div>
            </td>
            <td align ="right" style="">
                <div>
                    <p><?= isset($cbs_return['Num_evenement']) ? $cbs_return['Num_evenement'] : ""; ?>/ <?php echo gmdate("d/m/Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    <h5 align="center" style="color:black; padding-top: 300px; font: bold caption 1.3em  sans-serif; border: 1px solid black; padding: 2px;">&nbsp;&nbsp;&nbsp;&nbsp; ATTESTATION DE PAIEMENT POUR LE COMPTE DU CDI<span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</h5>
    <span style="padding-top: 300px;">
        <p style="text-align:justify; font:  caption 1.1em  sans-serif">
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?>, Agence de Kinshasa</span> atteste avoir encaiss&eacute; en date du <?php echo $encaissement->Datevaleur_31; ?>&nbsp; d'ordre de
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo $encaissement->Designation_14; ?></span>, pour compte du CDI, la somme de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?>
            au titre <?php echo $encaissement->Typerecette_17; ?> <?php if(isset($infos["standard"]))echo $infos["standard"];?>.
        </p>
    </span>
    
    
    
    
    
    <div style="padding-top:  100px;">
        <p align="center">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?>.<br>
        </p>
        
        <p align="center">
            <?php echo ' '.$this->session->userdata('account_business').' '; ?>
        </p>
        <p align="center">
            </br></br>
            (Signature autoris&eacute;e et cachet sec)
        </p></br>

    </div>



    
    
    
    
    <div style="padding-top:  200px;">
        <table style="border: 1px solid black; padding: 5px;" align="center">
            <th>
                <tr>
                    <td> La pr&eacute;sente attestation n'est valable que si le montant est inscrit au Protectograph</td>
                </tr>    
            </th>
        </table>

    </div>
</body>
</html>
