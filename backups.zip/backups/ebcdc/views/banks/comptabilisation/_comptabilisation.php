<?php if(!empty($lines)): ?>
      <table id="table" class="table table-hover table-striped">
          <thead>
            <tr class="bg-gray">
                <th width="6%">Id</th>
                <th width="3%">Sens</th>
                <th>D&eacute;bit</th>
                <th>Cr&eacute;dit</th>
                <th>Montant</th>
                <th>Designation</th>
                <th width="8%">Date</th>
            </tr>
          </thead>
          <tbody>
          <?php 
          foreach($lines as $row){
          ?>
                <?php if($row->Operation_8 == 'C'):?>
                <tr class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>">
                    <td width="6%"><?php echo $row->Id_0; ?></td>
                    <td width="3%"><?php echo $row->Operation_8; ?></td>
                    <td><?php echo '-'; ?></td>
                    <td width="16%" class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_9; ?></td>
                    <td><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                    <td><?php echo $row->Libelle_12; ?></td>
                    <td width="10%"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                </tr>
                <?php else:?>
                <tr class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>">
                    <td width="6%"><?php echo $row->Id_0; ?></td>
                    <td width="3%"><?php echo $row->Operation_8; ?></td>
                    <td width="16%" class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_9; ?></td>
                    <td width="16%" class="<?php if($row->Compte_13=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_13; ?></td>
                    <td><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                    <td><?php echo $row->Libelle_12; ?></td>
                    <td width="8%"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                </tr>
                <?php endif;?>
          <?php } ?>
          </tbody>    
      </table>
<?php endif;?>