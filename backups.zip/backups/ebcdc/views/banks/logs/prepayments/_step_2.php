<?php 
$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");
?>

<?php $userid = $this->session->userdata("user_id");  $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid']; ?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="message"></div>
    <?php $this->chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                
                <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />
                
                <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />
                
                <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                <input type="hidden" name="Sydonia_49" value="<?php echo $encaissement->Sydonia_49; ?>" />
                <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
                
                <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                <input type="hidden" name="Infos[accountname]" value='<?=  isset($infos['accountname']) ? $infos['accountname'] : ""; ?>' />
                <input type="hidden" name="Infos[quittanceid]" value='<?=  isset($infos['quittanceid']) ? $infos['quittanceid'] : ""; ?>' />
                <input type="hidden" name="Comptec" value="<?php echo $encaissement->Comptec; ?>" />
                <input type="hidden" name="Devisec" value="<?php echo $Devisec; ?>" />
                <input type="hidden" name="account_reference" value="<?php echo $account_reference; ?>" />
                <input type="hidden" name="fbank" value="<?php echo $fbank; ?>" />
				
                <div class="col-md-12">
                        <h2 class=" f20 w-300 page-header">Details des bulletins pr&eacute;pay&eacute;s</h2>
                        <br/>
                </div>
                <div class="col-md-6">
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Bureau</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($object_info->Office_8) ? $services['DGDA'][$object_info->Office_8] : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Banque</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($object_info->CodeBank_13) ? $object_info->CodeBank_13 : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Num&eacute;ro du d&eacute;clarant</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($object_info->Declarant_16) ? $object_info->Declarant_16 : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Num&eacute;ro imp&ocirc;t</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($object_info->Nif_15) ? $object_info->Nif_15 : ""; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Mode de paiement</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($object_info->Declarant_16) ? $object_info->Declarant_16 : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Compte de pr&eacute;paiement</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($prepayment_account) ? $prepayment_account : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Devise du compte</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($currency) ? $currency : ""; ?>
                        </div>
                    </div>
                    <div class="input-group col-md-12 no-padding">
                        <div class="col-md-4 no-padding">
                            <label for="office">Montant total du lot</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <span id="total_amount"></span> CDF
                        </div>
                    </div>
                    <br/>
                </div>
                <br/>
                <div class="col-md-12"><br></div>
                <div class="col-md-12 bTop">
                    <br/><label>Liste de bulletins</label>
                </div>
                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead >
                            <tr class="bg-blue">
                                <th width="250px">Date</th>
                                <th width="100px">Num&eacute;ro imp&ocirc;t</th>
                                <th width="200px">Bulletin</th>
                                <th class="right" width="">Montant</th>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php 
                                $total = 0;
                                foreach($prepayments as $row) 
                            :?>
                                <tr>
                                    <td  width="250px"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));?></td>
                                    <td  width="100px"><?php echo $row->Nif_15;?></td>
                                    <td><?php echo $row->Serial_9.''.$row->Number_10; ?></td>
                                    <td ><?php echo 'CDF'.' '.number_format($row->Amount_18,2,","," ");?></td>
                                </tr>
                            <?php 
                                $total = $row->Amount_18 + $total;
                                endforeach;
                            ?>
                        <input type="hidden" value="<?= number_format($total,2,","," ") ?>" id="total">
                        </tbody>    
                    </table>
                </div>
                <div class="col-md-12"><br></div>
                <div class="col-md-12 bTop">
                    <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label>
                </div>
                <div class="col-md-12"></div>
                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead >
                            <tr class="bg-blue">
                                <th width="250px">Libell&eacute;</th>
                                <th width="100px">Op&eacute;ration</th>
                                <th width="200px">D&eacute;bit</th>
                                <th width="300px">Cr&eacute;dit</th>
                                <th width="">Montant</th>
                            </tr>
                        </thead>
                        <tbody class="">
                            <?php foreach($instructions as $row) :?>
                                <?php if($row['Operation_8'] == 'C'):?>
                                <tr>
                                    <td  width="250px"><?php echo $row['Libelle_12'];?></td>
                                    <td  width="100px"><?php echo $row['Operation_8'];?></td>
                                    <td  class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'-'; ?></td>
                                    <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'-'; ?></td>
                                    <td ><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                                </tr>
                                <?php else:?>
                                <tr>
                                    <td  width="250px"><?php echo $row['Libelle_12'];?></td>
                                    <td  width="100px"><?php echo $row['Operation_8'];?></td>
                                    <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'00000000000000000000000'; ?></td>
                                    <td  class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'00000000000000000000000'; ?></td>
                                    <td ><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                                </tr>
                                <?php endif;?>
                           <?php endforeach;?>
                        </tbody>    
                    </table>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div class="col-md-12">
                    <button id="confirm" type="submit" class="btn btn-success pull-left" ><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button id="closePanel" type="button" class="btn btn-warning" ><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <input type="hidden" name="action" value="" id="action">
                    <input type="hidden" name="frais_bcc" value="<?php echo isset($frais_bcc) ? $frais_bcc : "" ?>">
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
var ref = '';
var logiref_id = '';

var total = $("#total").val();
$("#total_amount").html(total);

$("#closePanel").click(function(){
   
   location.reload(true);
    
});

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});

$("#continuer").click(function(event){
    
    var data = $("#confirmform").serialize();
    genQuittance(data);
    
});

$("#print_attestation").click(function(){
       
        var bl = '<?php echo $encaissement->Sydonia_44; ?>';
        
        var url = '<?php echo base_url($module.'/impression/display/attestationbl'); ?>/' + bl;
        
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#schema").click(function(){

        
        var bl = '<?php echo $encaissement->Sydonia_49; ?>';
        
        var url = '<?php echo base_url($module.'/impression/display/schema_prepayment'); ?>/' + bl;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});


function submiter(data){
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments/save/comptant'); ?>';
        
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert alert-success text-white">Bravo! paiements encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        
        scrollUP();
        $("#loader").html('');
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html',
                encode          : true,
                success: function(result){
                        
                        if(result > 0)
                        {
                                $('#message').html(message);
                                $('#schema').prop("disabled",false);
                                $('#confirm').prop("disabled",true);
                        }
                        else if(result == 'E002')
                        {
                                $('#message').html('');
                                $('#message').html('<div class="alert alert-warning text-white">D&eacute;sol&eacute;, il y a d&eacute;j&agrave; un lot de pr&eacute;paiement trait&eacute; en attente de validation, veuillez demander au checker de valider ce lot afin que vous puissiez enregistrer le prochain.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#message').html('');
                                $('#confirm').prop("disabled",false);
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}


</script>
