<?php  



?>

<div class="col-md-12">
  
</div>

<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', false);?>
        <div class="col-md-12">
            <?php if(!empty($prepayments)): ?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin table-striped table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th width="10px">#</th>
                                        <th width="200px">Bureau</th>
                                        <th width="200px">Declarant</th>
                                        <th width="150px">R&eacute;f&eacute;rence du compte</th>
                                        <th width="100px" class="center">Nombre de bulletins</th>
                                        <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i =1; foreach($prepayments as $payment): ?>
                                        <tr  id="line<?php echo $payment->Id_0;?>">
                                            <td width=""><?php echo $i;?></td>
                                            <td width=""><?php echo(isset($services['DGDA'][$payment->Office_8]))? $services['DGDA'][$payment->Office_8]:''; ?></td>
                                            <td width=""><?php echo $payment->Declarant_16;?></td>
                                            <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                            <td width="" class="center"><?php echo $payment->total; ?></td>
                                            <td>
                                                <a style="cursor: pointer" onclick="edit('<?php echo $payment->AccountRef_14; ?>')"> 
                                                    <i class="fa fa-fw fa-edit text-green f20"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                    <?php $i++; endforeach; ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Ce lot des prepaiements est d&eacute;j&agrave; extrait !</b></h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
</div>
<div class="modal fade" id="modal">
    <div class="modal-dialog">
        <div class="modal-content tScroll">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">D&eacute;tails du paiement</h4>
            </div>
            <div id="modal-pager" class="modal-body">
              <p>One fine body&hellip;</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
        <!-- /.modal-dialog -->
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">


function edit(reference)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments/display/traitement'); ?>/' +reference;
        $.get(url, function(data, status){
            $("#loader").html('');
            $('#pager').html(data); 
            $("#step-1").removeClass('bg-green-active');
            $("#step-1").addClass('bg-gray');
            $("#step-2").removeClass('bg-gray');
            $("#step-2").addClass('bg-green-active');
        });
}



</script>

