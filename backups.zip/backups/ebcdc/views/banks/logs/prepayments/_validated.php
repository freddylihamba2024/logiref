<?php echo form_open('', array('id' => 'sendack', 'class' => 'innovate')); ?>
<div id ="message1" class="col-md-12"></div>
<?php $this->chtml->box_body_opening('', true); ?>
<div class="col-sm-12 col-xs-12 center">
    <div class="col-md-7 bRight">
        <div class="form-group">
            <span class="input-group"><label for="message">Message</label></span> 
            <?php echo form_dropdown('message',$messages, '', 'class="form-control" id="message" required = "required"'); ?>
        </div>
    </div>
    <div class="col-md-5" id="ack" style="padding-left: 40px;">
        <div class="form-group">
             <span class="input-group"><label for="message">&nbsp;&nbsp;&nbsp;&nbsp;</label></span> 
            <button type="submit" id="submit" name="submit" disabled="disabled" class="btn btn-success  margin-bottom">Accuser r&eacute;ception <span class="Bold" id="index"></span> <i class="fa fa-check"></i></button>
        </div>
    </div>
</div>
<?php if (!empty($prepayments)): ?>
        <table id="table" class="table no-margin table-striped table-bordered">
            <thead class='bg-blue'>
                <tr>
                   <th width="2%">#</th>
                    <th width="10%">Date</th>
                    <th width="">Importateur</th>
                    <th width="">Num&eacute;ro imp&ocirc;t</th>
                    <th width="">Bureau</th>
                    <th width="15%">Bulletin</th>
                    <th width="">Montant</th>
                    <th width="5%"><span class="fa fa-fw fa-tasks f14"></span></th>
                    <th width="5%"><span class="fa fa-fw fa-check f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php   
                    $i = 1;
                    foreach($prepayments as $row){ 
                ?>
                    <tr>
                        <td><span class="text-blue"><?php echo $i;?></span></td>
                        <td>
                            <?php echo $row->Date_1; ?>
                        </td>
                        <td><?php echo $row->Designation_21;?></td>
                        <td>
                            <?php echo $row->Nif_15; ?>
                        </td>
                        <td>
                            <?php echo $services['DGDA'][$row->Office_8]; ?>
                        </td>
                        <td>
                            <?php echo $row->Serial_9.''.$row->Number_10; ?>
                        </td>
                        <td>
                           <span class="text-blue"><?php echo 'CDF '.number_format($row->Amount_18,2,","," "); ?></span>
                        </td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1): ?>
                                <a style="cursor:pointer" onclick="edit('<?php echo $row->Id_0;?>')"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                             <?php elseif($row->Status_2 == 2 || $row->Status_2 == 3): ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0;?>')"> <span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            <?php elseif($row->Status_2 == 4 || $row->Status_2 == 5): ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0;?>')"> <span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                            <?php endif;?> 
                        </td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1 || $row->Status_2 == 2): ?>
                                <span class="fa fa-fw text-gray fa-question-circle f14"> </span>
                            <?php elseif($row->Status_2 == 3 || $row->Status_2 == 5): ?>
                                <input type="checkbox" class="text-blue" id="p<?php echo $row->Id_0;?>"  onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->MessageKey_7; ?>" name="messageskeys[<?php echo $row->Id_0;?>]" />
                            <?php elseif($row->Status_2 == 4): ?>
                                <span class="fa fa-fw text-blue fa-check-circle f14"> </span>
                            <?php elseif($row->Status_2 == 5): ?>
                                <span class="fa fa-fw text-red fa-times-circle f14"> </span>
                            <?php endif;?> 
                        </td>
                    </tr>
                <?php 
                $i++;
                    } ?>
            </tbody>
        </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucun pr&eacute;paiement trouv&eacute; !</b></h4>
            <br/>
        </div>
    </section>
<?php endif; ?> 
<?php $this->chtml->box_body_closing(); ?>
<?php echo form_close(); ?>
<script type="text/javascript">
    

function validate(id)
{
    $("#p"+id).change(function()
        {
                var $checkedInputs = $('#table').find("input:checked");
                var index = $checkedInputs.length;
               
                if(index > 0)
                {
                        $("#ack").css("padding-left", '20px');
                        $("#submit").removeClass("btn-success");
                        $("#submit").prop("disabled",false);
                        $("#submit").addClass("btn-primary");
                        $("#index").html('('+ index+')');
                        

                }
                else if(index <= 0)
                {
                        $("#submit").removeClass("btn-primary");
                        $("#submit").addClass("btn-success");
                        $("#submit").prop("disabled",true);
                        $("#index").html('');
                        $("#ack").css("padding-left", '40px');
                }

        });
}

$('#sendack').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/prepayments'); ?>/display/prepaymentsAck';
        var data = $(this).serialize();
        var message = $("#message1").val();
        if(message !== "")
        {
            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#message1').html('');
                    if(result =='41')
                    {
                        $('#message1').html('');
                        $("#message1").html('<div class="alert alert-success text-white">Bravo! Transaction cl&ocirc;tur&eacute;e avec succ&egrave;s...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result =='42')
                    {
                        $('#message1').html('');
                        $("#message1").html('<div class="alert alert-danger text-white">Desol&eacute;! L&apos;accus&eacute; de recption a &eacute;chou&eacute;, essayez plutard...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result =='E404')
                    {
                        $('#message1').html('');
                        $("#message1").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result =='E401')
                    {
                        $('#message1').html('');
                        $("#message1").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                   
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
            });
        }
        else
        {
                $("#message1").html('<div class="alert alert-warning text-white">Alerte: Le champ message n\'est peut pas &ecirc;tre vide!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
});
</script>