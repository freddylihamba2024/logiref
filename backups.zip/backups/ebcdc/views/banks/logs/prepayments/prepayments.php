<div class="col-md-12">
        <div class="col-md-4 pull-left">
           <h2 class="text-blue">Les pr&eacute;paiments(DGDA)</h2>
        </div>
        <div class="col-md-8 pull-right">
            <ul class="nav navbar-nav pull-right">
                <li class="dropdown">
                    <a class="f14 bRight" onclick="pager('new')" id="new" style="cursor: pointer; background-color:rgba(0,0,0,0.04);" class="dropdown-toggle" > 
                        <i class="fa fa-file-zip-o text-green f14"></i> <span class="f13" >Nouveaux</span>
                    </a>
                </li>
                <li class="dropdown">
                    <a class="f14 bRight" onclick="pager('nvalidated')" id="nvalidated" > 
                        <i class="fa fa-warning text-yellow f18"></i> <span class="f13" >En attente de validation</span>
                    </a>
                </li>
                <li class="dropdown">
                    <a class="f14 bRight" onclick="pager('validated')" id="validated" > 
                        <i class="fa fa-check text-blue f18"></i> <span class="f13" >Valid&eacute;s</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="col-md-12" style="margin-top:-8px;">
        <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente tous les pr&eacute;paiments extraits pour le traitement.</span></h5>
        </div>
</div>
<div><br></div>
<div class="col-md-12">
    <div id="loader1" class="col-md-12"></div>
    <div id="panel" class="col-md-12">
        
    </div>
</div>
<?php echo form_close(); ?>
<script type="text/javascript">
 
get_prepayments();
$("#CloseModal").click(function(){
    get_prepayments();
});





function get_prepayments()
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/prepayments/display/new'); ?>/", function(data, status){
            $("#loader1").html('');
            $("#panel").html(data);
      });
}

function pager(tab) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module); ?>/prepayments/display/' + tab ;
        $.get(url, function(data, status){
                $("#loader").html('');
                $("#panel").html(data);
                
                if(tab=='new')
                {
                    $("#new").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#nvalidated").css('background-color', '');
                    $("#validated").css('background-color', '');
                    
                }
                else if(tab=='nvalidated')
                {
                    $("#nvalidated").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#new").css('background-color', '');
                    $("#validated").css('background-color', '');
                }
                else if(tab=='validated')
                {
                    $("#validated").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#nvalidated").css('background-color', '');
                    $("#new").css('background-color', '');
                }
                
        });
}
</script>

