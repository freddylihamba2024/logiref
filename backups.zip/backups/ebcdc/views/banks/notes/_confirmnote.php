<div id="pager" class="content">
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="loader"></div>
        <h2 class="text-blue" ><?php echo " Extraire une note de perception (DGRAD, DGRK)"; ?></h2>
        <p class="page-header"></p>
        <div class="col-md-12">
            <div class="col-md-1">
                <div title="" class="bRound bg-green f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Verification de la note<br/></div>
            </div>
            <div class="col-md-1">
                <div title="" class="bRound bg-gray f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div title="" class="bRound bg-gray f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Impression de la preuve<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
            <div class="col-md-12">
                <?php $this->chtml->box_body_opening("", true);?>  
                <div class="col-md-4">
                    <div id="approvalWarning" style="color:#F00"></div><br/>
                    <p>
                        Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de cette d&eacute;claration.
                    </p>
                    <br/><br/>
                </div>
                <div class="col-md-8 bLeft">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                              <?php echo form_input('Reference_32','', 'class="form-control"  id="Reference_32"'); ?>
                        </div>
                    </div>
                    <div class=" clearfix">
                        <button id="saisie" type="button" style="margin-left:5px;" name="button" class="btn btn btn-default pull-left margin" disabled='disabled'><i class="fa fa-pencil"></i> Saisie manuelle </button>&nbsp;
                        <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin pull-right"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                    </div>
                </div>
            </div>
            <?php $this->chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>  
    </div>
    <div class="col-md-1">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>
<script type="text/javascript">
    
$("#mainform").submit(function(event){
     event.preventDefault();
     var data = $(this).serialize();
     next_step(data);

});

function next_step(data)
{
    $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/bank/display/checknote'); ?>';
    
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){

                    $('#loader').html('');

                    if(result === "E22")
                    {
                            $("#loader").html('<div class="alert alert-warning"> D&eacute;sol&eacute;... Aucune information trouv&eacute;e pour ce num&eacute;ro de r&eacute;f&eacute;rences !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#saisie").removeClass('btn-default');
                            $("#saisie").addClass('btn-success');
                            $("#saisie").prop("disabled", '');
                    }
                    else 
                    {
                            $("#container").html(result);
                    }
            },
            error:function(error){
                    alert(error)
            }
    });
}
        
        
$("#saisie").click(function(){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url('logiref/bank'); ?>/display/encaissement';
    $.get(url, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
    });
});


$("#cancel").click(function(){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url('logiref/bank'); ?>/display/notes';
    $.get(url, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
    });
});
</script>