<div class="">
    <div class="col-md-1"></div>
    <div class="col-md-10">
       
        <div class="col-md-12">
            <h2 class="text-blue" ><?php echo " Extraire une note de perception (DGRAD, DGRK)"; ?></h2>
        <p class="page-header"></p>
        </div>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification de la note<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound  <?php if($step==2) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Impression de la preuve<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/>
            <div id="loader"></div>
        </div>
            
            <div id="pager" class="col-md-12">
                
                <?php if($step==2){ 
                    echo $this->load->view('_step_2'); 
                ?>
                        
                <?php }elseif($step==3){ 
                    
                    echo $this->load->view('_step_3'); 
                ?>
                <?php }else{ ?>
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <?php $this->chtml->box_body_opening("", true);?>  
                <div class="col-md-3">
                    <div id="approvalWarning" style="color:#F00"></div><br/>
                    <p>
                        Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de cette note!
                    </p>
                    <br/><br/>
                </div>
                <div class="col-md-9 bLeft">
                    <div class="box-body">
                        
                        <div class="col-md-12">
                            <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'une note de perception</h2>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Service_8"><div id="ServiceId">Service recouvrement</div></label> 
                                <?php echo form_dropdown('Service_9', $services, "", 'class="form-control chosen-select" id="service"  required="required" '); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                <?php echo form_input('Nifclient_7','', 'class="form-control" id="company"'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="company">Taxe</label> 
                                <?php echo form_dropdown('Typerecette_12', $recettes, "", 'class="chosen-select form-control" id="recette"  required="required" '); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="Amount_10">Montant &agrave; payer</label>
                                <?php echo form_input('Amount_10','', 'class="form-control" id="Montant_11" required = "required"'); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="Devise_17">Devise</label>
                                <?php echo form_dropdown('Devise_17', $devises, "", 'class="form-control"  required="required" id="recetteDevise"'); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                                  <?php echo form_input('Reference_8','', 'class="form-control"  id="Reference_32" required = "required"'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <div class="col-md-12">
                            <button id="saisie" type="button" style="margin-left:5px;" name="button" class="btn btn btn-default pull-left margin" disabled='disabled'><i class="fa fa-pencil"></i> Saisie manuelle </button>&nbsp;
                            <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
                <?php $this->chtml->box_body_closing(); ?>
                
                <?php }?>
            </div>
             
          
    </div>
    <div class="col-md-1">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    
$("#mainform").submit(function(event){
    
    event.preventDefault();
    var data = $(this).serialize();
    next_step(data);

});

$('#Montant_11').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('.chosen-select').chosen({width: "100%"});

$("#saisie").click(function(){
    var data = $("#mainform").serialize();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.''); ?>/notes/display/create';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result){

                $('#loader').html('');
                $("#pager").html(result);
                $("#step-1").removeClass('bg-green');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green');
                
        },
        error:function(error){
                alert(error)
        }
    });
});


$("#cancel").click(function(){
   location.reload(true);
});

function next_step(data)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/notes/display/verification'); ?>';
    
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){

                    $('#loader').html('');
                    if(result == "E604")
                    {
                            $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Aucune information trouv&eacute;e pour cette ref&eacute;f&eacute;rence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#saisie").removeClass('btn-default');
                            $("#saisie").addClass('btn-success');
                            $("#saisie").prop("disabled", '');
                    }
                    else if(result == "E000")
                    {
                            $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Logirad n\'est pas disponible !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#saisie").removeClass('btn-default');
                            $("#saisie").addClass('btn-success');
                            $("#saisie").prop("disabled", '');
                    }
                    else if(result == "E002")
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result == "E22")
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">Alerte: La r&eacute;f&eacute;rence n&pos;est pas envoy&eacute;e...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                            $("#pager").html(result);
                            $("#step-1").removeClass('bg-green');
                            $("#step-1").addClass('bg-gray');
                            $("#step-2").removeClass('bg-gray');
                            $("#step-2").addClass('bg-green');
                    }
            },
            error:function(error){
                    alert(error)
            }
    });
}
</script>
