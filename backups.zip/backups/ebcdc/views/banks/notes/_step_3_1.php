<?php
$commission = $encaissement->Commission_23;
$commissionDevise = $encaissement->Devise_24;

if($commissionDevise =='USD'):
    $commission = $commission * $encaissement->Taux_41;
endif;

$total_amount = $commission + $encaissement->Montant_11;
$total_amount = number_format($total_amount,2,","," ");

?>
<?php $userid = $this->session->userdata("user_id"); $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); ?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>




<?php echo form_open('', array('id' => 'form', 'class' => $view)); ?>

    
<style>label {min-width: 150px !important;}</style>
<?php $this->chtml->box_body_opening('', true);?>
 
<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
<input type="hidden" name="Beneficaire_15" value="DGRAD"  id="regies" />

<div class="box-body">

        <div class="col-md-12">
            <h2 class=" f20 w-300 page-header">Renseignez les informations requises</h2>
        </div> 
        <!------------------------- Payement  ------------------------------>
        <div class="col-md-12"><br/><label>B&eacute;n&eacute;ficiare</label><br/></div>
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_15', $beneficiaires['Regies'], 'DGRAD', ' class="form-control bg-gray"'.$disabled.' required="required"  '); ?>
                <?php if($encaissement->Id_0 !=NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-6">
            <div class="input-group"  id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                </span>
                <span id="slist"><?php echo form_dropdown('Service_16', $services, isset($encaissement->Service_16) ? $encaissement->Service_16 : "" , 'class="form-control" id="service"  required="required" '); ?></span>

            </div>
        </div>
        <div class="col-md-12 border"><br/><label>Partie 1 : Client (Assujetti ou Contribuable) </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Nif_13">NIF Client</label> 
                </span>
                <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div> 
        <div class="col-md-7">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Designation_14">D&eacute;signation</label> 
                </span>
                <?php echo form_input('Designation_14', set_value('Designation_14', isset($encaissement->Designation_14) ? $encaissement->Designation_14 : "" ), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Mode_19">Mode</label> 
                </span>
                <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Compte_33">Compte</label> 
                </span>
                <?php echo form_input('Compte_33', set_value('Compte_33',  $encaissement->Compte_33 ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" disabled="disabled" maxlength="86"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control" disabled="disabled" required="required" id="compteDevise"'); ?>

            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="total_amount">Taux de change</label> 
                </span>
                <?php echo form_input('Taux_41', set_value('Taux_41', $encaissement->Taux_41), 'class="form-control" id="recetteMontant" required="required"'); ?>
                <span class="input-group-addon">CDF</span>
            </div>
        </div> 
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Montant_11">Montant &agrave; payer</label> 
                </span>
                <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                   <label for="Datevaleur_31">Date paiement</label>
                </span>
                <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Commission_23">Commission</label> 
                </span>
                <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commissionId" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>

            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Reference_32">R&eacute;f&eacute;rence</label>
                </span>
                <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="total_amount">Montant total</label> 
                </span>
                <?php echo form_input('', set_value('', $total_amount), 'class="form-control" id="total_amount" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('', $devises, "", 'class="form-control"  required="required" '); ?>

            </div>
        </div>
        <!-------------------------  Titre de perception  ------------------------------>
        <div class="col-md-12"><br/><label>Partie 2: Note de perception</label><br/></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-7">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25">Document</label> 
                </span>
                <?php echo form_dropdown('Notetype_25', $documents, 1, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                <input type="hidden" name="Notetype_25" value="1">
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard"><div id="StandardLabel01">Art. budg&eacute;taire</div></label> 
                </span>
                <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $Infos['standard']), ' class="form-control" placeholder = "E.g: 11201808"  maxlength="6"'); ?>
            </div>
        </div>
        <div class="col-md-7">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17">Nature paiement</label> 
                </span>
                <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?></span>
            </div>
        </div>
        <div id="bl" class="col-md-12"></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>

                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        
        
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28">Montant(note)</label> 
                </span>
                <?php echo form_input('Notemontant_28', set_value('Notemontant_28', $encaissement->Notemontant_28), ' id="Notemontant_28" class="form-control"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="Notedevise_29"  required="required"'); ?>
            </div>
        </div>
</div>
<!-------------------------  DGRAD Informations additionnelles  ------------------------------>
<div>
    <div class="col-md-12"><br/><label>Repartition</label><br/></div>
    <div  id="Comptabilisation" class="col-md-12">

    </div>
</div>
<!-------------------------  END  ------------------------------>
<div  class="box-footer clearfix">
    <div id="createPaiement" class="col-md-12">

            <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos;attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
    </div>
</div>
<?php $this->chtml->box_body_closing(); ?>	  

<?php echo form_close(); ?>
  
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>';
var status_print ='<?php  echo($encaissement->Checkerid_10!=0 && $encaissement->Checkerid_10!="")? true: false ;?>'; 
var Dtaux=[];
Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>'; 

shower();

if(status_print)
{
       $('#print').prop("disabled",false);
}   
$('#modeId').change(function(){
      var mode = $('#modeId').val();
      if(mode === '7' || mode == '8'){
          $("#compteId").prop('disabled',''); 
          $("#compteDevise").prop('disabled',''); 
          $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
          $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
          $("#compteId").val('');
      }else{
          $("#compteId").prop('disabled','disabled'); 
          $("#compteDevise").prop('disabled','disabled');
          $("#compteLabel").html('Commission');
          commission();
      }
});

$('#recetteMontant').change(function(){
        commission();
        montantValidation();
});

$('#recetteDevise').change(function()
{
      commission();
      montantValidation();
});

$('#reftitre').change(function(){
        var regie = $('#regies option:selected').val();
        var service = $('#service option:selected').val();
        var titre = $('#reftitre').val();
        if(regie === '3' && service !== null){
            $("#bl").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            extract(titre,regie,service);  
        }
      
});

$('#regies').change(function(){
    shower();
    commission();
});

$('#doc').change(function(){
    var service = $('#service option:selected').val();
    if(service === '00511'){
        $("#DGICotisation").css('display', '');
    }
});

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'dd-mm-yyyy'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

$('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var data = $(this).serialize();
        var regie = $('#regies option:selected').val();
        //Verifier le BL dans Sydonia
        if(regie === 'DGDA-DEL')
        {
                call_sydonia_api(data);
        }
        //Continuer si necessaire
        else
        {
                submiter(data); 
        }  
});

$("#cancel").click(function(){
        location.reload(true);
});

$("#print").click(function(){

        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        
});

function hidder(){
      $("#regie0").css('display', 'none');
      $("#regie1").css('display', 'none');
      $("#regie2").css('display', 'none');
      $("#regie3").css('display', 'none');
      $("#regie4").css('display', 'none');
      
      $("#recette0").css('display', 'none');
      $("#recette1").css('display', 'none');
      $("#recette2").css('display', 'none');
      $("#recette3").css('display', 'none');
      $("#recette4").css('display', 'none');
}

<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        shower();
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#compteId").val('');
        $("#compteDevise").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = $('#regies').val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        
        if(mode === '5' && montant !== '' && regie !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        $("#compteId").val(result[0]);
                        $("#compteDevise").prop("selectedIndex", result[1]);
                        //$('#loader').html(reponse);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                    }  
            });    
        }
}



function shower()
{
    //Standard field 01 
    //DGI
    var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/DGRAD/recettes/TVA';
    $.get(url, function(data, status){
        $("#rlist").html(data);
    });
    
    $("#Standard01").addClass('Standard01');
    $(".Standard01").datepicker({
          todayHighlight: true,
          format: 'dd-mm-yyyy'
      });
    $("#Standard01").prop('disabled','');
    $("#Standard01").prop('maxlength','12');
    $("#Standard01").prop('placeholder','201808');
    $('#doc').prop("selectedIndex", 0);
    $("#ServiceId").html('Service recouvrement');
    $("#DGDAComplement").css('display','none');
    
    
}


function comptabilisation(ref){
        alert(ref);
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/comptabilisation/display/get_details'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}



function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

$("#Notemontant_28").change(function()
{
        montantValidation();

});
$("#Notedevise_29").change(function(){
    
        montantValidation();
});

function montantValidation()
{
        var notemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
        var recettemontant = parseFloat($("#recetteMontant").val().split(' ').join('').split(',').join('.'));
        var rdevise = $("#recetteDevise option:selected").val();
        var ndevise = $("#Notedevise_29 option:selected").val();
        var note =0;
        var recette=0;
       
        
        if(isNaN(recettemontant))
        {
                recettemontant = 0;
        }
        
        if(isNaN(notemontant))
        {
                notemontant = 0;
        }
        
        $("#recetteMontant").closest('div').removeClass("has-error");
        $('#info').text("");
        if((rdevise!='' && ndevise!='') && (recettemontant && notemontant))
        {
                if((rdevise != null && rdevise !="CDF") && (ndevise != null && ndevise !="CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant * Dtaux[rdevise];
                        console.log('ndevise = '+Dtaux[ndevise]+' rdevise '+ Dtaux[rdevise]);
                }
                else if((ndevise!= null && ndevise != "CDF") && (rdevise != null && rdevise == "CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant;
                        console.log('Note montant = '+note);
                }
                else if((rdevise != null && rdevise != "CDF") && (ndevise != null && ndevise == "CDF"))
                {
                        recette = recettemontant * Dtaux[rdevise];
                        note = notemontant;
                        console.log(' Recette devise = '+recette);
                }
                else
                {
                    note = notemontant * 1;
                    recette = recettemontant * 1;
                    console.log('note = '+note+' recette = '+recette);
                }
                
                if( note >= recette)
                {
                        valid = false;
                        $("#recetteMontant").closest('div').removeClass("has-error");
                        $('#info').text("");
                }
                else
                {
                        valid = true;
                }

                if(valid)
                {
                        $("#recetteMontant").closest('div').addClass('has-error');
                        $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
                        //$("#recetteMontant").val("");
                }
        }
}
function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}




function REN_call_sydonia_api(data)
{
        $("#Comptabilisation").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/data/api_sydonia_comptant'); ?>';
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#Comptabilisation').html('');
                        $('#loader').html('');
                        
                        if(result==='100')
                        {
                                $('#Comptabilisation').html(result);
                        }
                        else
                        {
                                $('#Comptabilisation').html('<div class="alert alert-warning text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                submiter(data);
                        }

                },
                error:function(error){
            
                }
        });
}

function RENextract(titre,regie,service)
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/transactions'); ?>/<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : { titre : titre, regie : regie, service : service }, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#bl').html(result);
                },
                error:function(error){
                    $('#bl').html('');
                }
        });
}
</script>



