<?php $user = $this->session->userdata('user_id');?>
<?php $type = $this->session->userdata('user_type');?>
    <div  class="col-md-10">
         <div id="loader"></div>
        <h2 class="text-blue">Les notes de perceptions</h2>
        <h5 class="page-header"><span class="text-gray">Trouvez ici toutes les notes de perceptions confirm&eacute;es</span></h5>
    </div>

    <div class="col-md-2">
        <a id="new" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>   
    </div>


    <div class="col-md-10">
       
            <?php if(!empty($notes)): ?>
            <?php $this->chtml->box_body_opening('', true); ?>
                <table id="tableREN1" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th width="4%">#</th>
                            <th width="12%">Date</th>
                            <th width="10%">Statut</th>
                            <th>D&eacute;signation</th>
                            <th>Service</th>
                            <th class="center">Montant</th>
                            <th width="5%"><span class="fa fa-fw fa-tasks f14"></span></th>
                            <th width="5%"><span class="fa fa-fw fa-file-pdf-o f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 1;
                        foreach($notes as $obj): 
                        ?>
                            <tr> 
                                <td width="4%"><?php echo $i;?></td>
                                <td width="12%"><?php echo strftime('%d-%m-%Y',strtotime($obj->Date_1));?></td>
                                <td width="10%"><span class="badge <?php echo $color[$obj->Status_2]; ?>"><?php echo $status[$obj->Status_2];?></span></td>
                                <td><?php echo $obj->Nifclient_7.' - '.$obj->Designation_15;?></td>
                                <td><?php echo $services[$obj->Service_9];?></td>
                                <td class="center"><?php echo "CDF ". number_format($obj->Amount_10,4,"."," ");?></td>
                                <td width="5%">
                                    <a style="cursor:pointer" onclick="view('<?php echo $obj->Id_0 ?>', '<?php echo $obj->Status_2 ?>', '<?php echo $obj->Payementid_4?>')"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                </td>
                                <td width="5%">
                                    <?php if($obj->Status_2 == 3):?>
                                       <a style="cursor:pointer" onclick="printpdf('<?php echo $obj->Payementid_4; ?>')"><span class="fa fa-fw text-yellow fa-file-pdf-o f14"></span></a>
                                    <?php else: ?>
                                       <span class="fa fa-fw fa-file-pdf-o text-gray f14"> </span>
                                    <?php endif;?>
                                </td>
                            </tr>
                            
                        <?php 
                            $i++;
                        endforeach;
                        ?>
                    </tbody>
                </table>
            <?php $this->chtml->box_body_closing(); ?>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Aucune note de perception trouv&eacute;e!</b></h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
       
    </div>

    <div class="col-md-12"></div>
    
    
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#tableREN1').DataTable({
      
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "bLengthChange": false,
      "bFilter": false
});

$("#new").click(function () {
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
    $.get("<?php echo base_url($module.'/bank/display/note'); ?>", function (data, status) {
       $("#loader").html('');
       $("#container").html(data);
   });
});

function view(id, status, paiementid)
{
    $("#loader").html('<img align="middle" height="30px" src="<?php  echo base_url('ikwook_bootstraps/v0/img/loadbar.gif'); ?>" />');
    
    if(status=='1' || status=='2')
    {
        var url = '<?php echo base_url($module.'/bank/display/confirmnote'); ?>/' + id;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    if(status=='3')
    {
        var url = '<?php echo base_url($module.'/bank/display/printnote'); ?>/' + paiementid;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
}

$("#print").click(function(){

        printpdf(ref);
});

function printpdf (id)
{
    
    var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/'+id;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);
}

</script>


