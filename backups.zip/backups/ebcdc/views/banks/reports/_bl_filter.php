<?php if(!empty($bulletins)): ?>
<table id="table" class="table table-hover table-striped">
    <thead>
        <tr class="bg-blue">
            <th width="10px">#</th>
            <th width="150">Date</th>
            <th width="50px">Ann&eacute;</th>
            <th >Num&eacute;ro BL</th>
            <th >Bureau</th>
            <th >Agence</th>
            <th >Montant</th>
            <th width="">Num&eacute;ro imp&ocirc;t</th>
            <th >Cr&eacute;&eacute; par</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $i = 0;
        foreach($bulletins as $row){
        ?>
            <tr>
                <td><?php echo ++$i; ?></td>
                <td><?php echo $row->Date_1; ?></td>
                <td><?php echo $row->Year_5; ?></td>
                <td><?php echo $row->Serie_7."".$row->Number_8 ?></td>
                <td><?php echo $row->Office_6 ?></td>
                <td><?php echo isset($agences[$row->Agence_32]) ? $agences[$row->Agence_32] : "-"; ?></td>
                <td><?php echo 'CDF '.number_format($row->Amount_12,2,","," "); ?></td>
                <td><?php echo $row->Nif_9; ?></td>
                <td><?php echo isset($users[$row->User_15]) ? $users[$row->User_15] : "-"; ?></td>
            </tr>
        <?php } ?>
    </tbody>    
</table>
<input type="hidden" name = "bulletins" value='<?php echo(!empty($bulletins))? json_encode($bulletins): '';?>'>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucun rapport trouv&eacute; !</b></h4>
            <br/>
        </div>
    </section>
<?php endif; ?>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">

$('#datepicker1').datepicker({
        format: 'yyyy-mm-dd'
});

$('#datepicker2').datepicker({
        format: 'yyyy-mm-dd'
});




</script>

