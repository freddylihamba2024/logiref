<input type="hidden" name = "data" value='<?php echo(!empty($data))? json_encode($data): '';?>'>
<?php $this->chtml->box_body_opening('', true); ?>      
    <?php if (!empty($agences)): ?>
        <table id="table" class="table no-margin table-striped ">
            <thead class='bg-blue'>
                <tr>
                    <th width="5">#</th>
                    <th>Date</th>
                    <th width="30%">Agence</th>
                    <th class="text-center">Nbre de paiements</th>
                    <th>Montant</th>
                    <th>Commissions</th>
                </tr>
            </thead>
            <tbody>
                <?php                                   
                    $i = 1;
                    foreach($agences as $row){
                    if($i==1){
                ?>
                    <tr>
                        <td width="2%"><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                        <td width="20%"><?php echo $row->Date_1 ?></td>
                        <td><?php echo $row->Nom_4; ?></td>
                        <td class="text-center" ><?php if(isset($data[$row->Id_0]['nombre'])) echo $data[$row->Id_0]['nombre']; else echo 0;?></td>
                        <td><?php if(isset($data[$row->Id_0]['paiement'])) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," ");  else echo 0; ?></td>
                        <td><?php if(isset($data[$row->Id_0]['commission'])) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
                    </tr>
                    
                <?php 
                    }
                $i++;
                    } ?>
            </tbody>
        </table>
    <?php else: ?>
        <section>
            <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <h4 align="center"><b>Aucun rapport trouv&eacute pour cette p&eacute;riode !</b></h4>
                <br/>
            </div>
        </section>
    <?php endif; ?>
 <?php $this->chtml->box_body_closing(); ?>
<script type="text/javascript">

$('.table').DataTable({
    pageLength: 10,
    responsive: true,
    "bLengthChange": false,
    "bFilter": false,
    paging: true,
    searching: true,

});
   
$('#datepicker1').datepicker({
        format: 'yyyy-mm-dd'
});

$('#datepicker2').datepicker({
        format: 'yyyy-mm-dd'
});

</script>