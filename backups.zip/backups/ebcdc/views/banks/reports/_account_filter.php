<input type="hidden" name = "comptes" value='<?php echo(!empty($comptes))? json_encode($comptes): '';?>'>
<?php $this->chtml->box_body_opening('', true); ?>
<?php if(!empty($comptes)): ?>
    <table id="tableREN" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th>#</th>
                <th>Agence</th>
                <th width="50">Type</th>
                <th>Taxe</th>
                <th>Libell&eacute;</th>
                <th>Service/Bureau</th>
                <th>Comptes</th>
                <th width="50">R&eacute;gie</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach($comptes as $row){ ?>
                <tr>
                    <td width="5"><?php echo $i; ?></td>
                    <td><?php if(isset($guichets[$row->Agence_12])) echo $guichets[$row->Agence_12];?></td>
                    <td width="10%"><?php echo ' '.$row->Type_4;?></td>
                    <td><?php echo $row->Recette_13?></td>
                    <td><?php if(isset($recettes[$row->Beneficiaires_5][$row->Recette_13])) echo $recettes[$row->Beneficiaires_5][$row->Recette_13]; else echo "";?> </td>
                    <td class="bleu" width="10%" ><?php echo $row->Serviceid_16; ?></td>
                    <td width="50%"><?php if($row->Type_4!='CAC' || $row->Type_4!='CPI') echo '<b>'.$row->Agenceid_15.'</b>'; else echo '<span class="text-red">'.$row->Agenceid_15.'</span>'; ?><?php if($row->Compte_6!='') echo '-'.$row->Compte_6;?><?php if($row->Clef_7!='') echo '-'.$row->Clef_7;?>&nbsp;&nbsp;<?= $row->Devise_8;?></span></td>
                    <td width="50"><?php echo ' '.$row->Beneficiaires_5;?></td>
                </tr>
            <?php $i++;} ?>
        </tbody>    
    </table>
<?php else: ?>
    <section id="cat_list">
        <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 10px;">
        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            Aucun compte trouv&eacute;!<br/>
        </div>
    </section>
<?php endif;?>
<?php $this->chtml->box_body_closing(); ?>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
//
//$('.table').DataTable({
//    pageLength: 10,
//    responsive: true,
//    "bLengthChange": false,
//    "bFilter": false,
//    paging: true,
//    searching: true
//});
   
</script>
