<?php 
    $userid = $this->session->userdata("user_id");
    $usertype = $this->session->userdata("user_type");
    $paiements = 0;
    $validated = 0;
    $suspend = 0;
    $regulate = 0;
    $notreated = 0;
    $i = 0;

    /*** 
        [ 
            ''=>'',
            '1' => 'Initialisé' (Status=0),
            '2' => 'Valid&eacute;' (Status= 1 & Chekerid>0), 
            '3' => 'Regularisation Finacle' (Status= 5), 
            '4' => 'Regularisation Logirad' (Status= 6), 
            '5' => 'Failed' (Status=1 & Chekerid=0, Mauvaise réference OMNI),
            '6' => 'Reversé'
        ]

        [ ''=>'','1'=>'Initialisé','2'=>'Valid&eacute;', '3'=>'Régularisation Finacle', '4'=>'Régularisation Logirad', '5'=>'Échec','6' => 'Reversé']
    ****/
?>
<div class="col-md-12">
    <?php $this->chtml->box_body_opening('', true); ?>
        <div class="statistic-box no-border no-padding">
            <div class="col-md-12 no-margin">
                <h1>Paiement en ligne</h1>
                <h5 class="page-header"></h5>
                <!-- <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente le rapport des paiements passepports en agence.</span></h5> -->
            </div>
            <div class="col-sm-12 mt-2">
                <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="form-group">  
                            <div class="input-group">
                                <span class="input-group-addon"><b>Référence </b></span><?php echo form_input('Noteid_26', set_value('Noteid_26', ''), ' id="noteid" class="form-control"'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12 border-left">
                        <div class="form-group">  
                            <div class="input-group">
                                <span class="input-group-addon"><b>Status </b></span><?php echo form_dropdown('Status_2', $status, '', ' id="" class="form-control"'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <div class="input-daterange input-group">
                                <span class="input-group-addon">Initi&eacute;e entre le</span>
                                <input class="input-sm form-control" name="start" value="" id="datepicker1" type="text">
                                <span class="input-group-addon">et le</span>
                                <input class="input-sm form-control" name="end" value=""  id="datepicker2" type="text">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <button type="button" id="export-online" class="btn btn-success">Exporter</button>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn btn-bitbucket pull-right"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?>

    <div id="loader1" class="col-md-12"></div>

    <?php $this->chtml->box_body_opening('', true); ?>
        <div class="col-md-12 no-padding" id="filterResult">
            <?php if (!empty($encaissements)): ?>
                <table id="table_ponline" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-aqua-active">
                            <th>#</th>
                            <th>Date</th>
                            <th width="">Status</th>
                            <th width="10">R&eacute;gie</th>
                            <th>Recette</th>
                            <th>Client</th>
                            <th width="">Note</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th>Mode</th>
                            <th>Op&eacute;rateur</th>
                            <th><span class="fa fa-fw fa-folder f14"></span></th>
                            <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $paiements = 0;
                        $commissions = 0;
                        $suspend = 0;
                        $urgent = 0;
                        $i=0;

                        foreach ($encaissements as $row):
                            $infos = json_decode($row->Notereference_30);
                            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                        ?>
                            <tr>
                                <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                <td><?php echo $row->Datevaleur_31 ?></td>
                                <td width="10%"><span class="badge <?php echo $colors[$row->Status_2]; ?>"><?php echo $status[$row->Status_2];?></span></td>
                                <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                                <td><b><?php echo $row->Typerecette_17; ?></b></td>
                                <td class="text-blue">
                                    <?php echo $row->Designation_14; ?><br>
                                    <span class="text-gray">
                                        <?php echo (isset($row->Email_54) && $row->Email_54 !="") ? $row->Email_54 : (isset($infos->Email) ? $infos->Email : ''); ?>
                                    </span>
                                </td>
                                <td><b><?php echo strtoupper($row->Noteid_26); ?></b></td>
                                <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>
                                <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                <td>
                                    <?php if ($row->Paymentmode_56 == "8") :?>
                                        <span class="badge label-completed">Mobile</span>
                                    <?php elseif ($row->Paymentmode_56 == "9"): ?>
                                        <span class="badge label-upcoming">Carte</span>
                                    <?php else :?>
                                        ---
                                    <?php endif; ?>
                                </td>
                                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Checkerid_10==0): ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')): ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                        <?php else : ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                        <?php endif; ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:not-allowed; opacity:0.6;" title="Attestation non disponible">
                                            <span class="fa fa-fw fa-file-pdf-o text-secondary f14"></span>
                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                    </td>
                                    <td width="25">
                                        <?php if($row->Status_2==2 || $row->Status_2 == 3):?>
                                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        <?php else: ?>
                                            <a style="cursor:not-allowed; opacity:0.6;" title="Attestation non disponible">
                                                <span class="fa fa-fw fa-file-pdf-o text-secondary f14"></span>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php
                            if ($row->Status_2 == 4)
                                $suspend = $suspend + 1;
                            if (($row->Status_2 == 2 OR $row->Status_2 == 3) && $row->Checkerid_10 > 0)
                                $validated = $validated + 1;
                            if ($row->Status_2 >= 5)
                                $regulate = $regulate + 1;

                        endforeach;
                        ?>

                    </tbody>
                </table>
            <?php else: ?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun paiement trouv&eacute;!<br/>
                    </div>
                </section>
            <?php endif; ?>
        </div>
    <?php $this->chtml->box_body_closing(); ?>
</div>  
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#paiements').html('<?php echo number_format(count($encaissements) ,0,","," "); ?>');
$('#paiements').addClass('text-blue');
$('#validated').html('<?php echo number_format($validated,0,","," "); ?>');
$('#validated').addClass('text-green');
$('#attente').html('<?php echo number_format($suspend,0,","," "); ?>');
$('#attente').addClass('text-yellow');
$('#regulate').html('<?php echo number_format($regulate,0,","," "); ?>');
$('#regulate').addClass('text-red');

$('#table_ponline').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
});

$('#noteid').on('input', function() {
    var currentText = $(this).val();
    var upperText = currentText.toUpperCase();
    $(this).val(upperText);
});

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});

$("#searchform").submit(function(e){
    e.preventDefault();

    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');

    var url = '<?php echo base_url($module.'/reports/display/filter_passport_online'); ?>';
    var data = $(this).serialize(); 

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode          : true,
        success: function(result){
            $('#loader1').html('');
            $('#filterResult').html(result);
        },
        error:function(error){
            alert('ERROR!' + error);
        }
    });
});

$(document).ready(function(){

    $("#export-online").click(function(e){
        e.preventDefault();

        // Récupération des valeurs du formulaire de filtre
        var formData = {
            Noteid_26: $('input[name="Noteid_26"]').val(),
            Status_2: $('select[name="Status_2"]').val(),
            start: $('input[name="start"]').val(),
            end: $('input[name="end"]').val()
        };

        var url = "<?php echo base_url($module.'/impression/display/export_passport'); ?>";

        // Création d’un formulaire invisible pour POST (download Excel via POST)
        var form = $('<form>', {
            action: url,
            method: 'POST',
            target: '_blank' // ouvre le téléchargement dans un nouvel onglet
        }).append($.map(formData, function(val, key) {
            return $('<input>', {type: 'hidden', name: key, value: val});
        }));

        // Envoi du formulaire
        $('body').append(form);
        form.submit();
        form.remove();
    });

});

function view(id, regie)
{
    var url ='';
    var controller = 'reports';
    var from = '<?php echo $display; ?>';
    
    if(regie === 'DGRAD')
    {
            var url ="<?php echo base_url($module.'/passeport/display/preview'); ?>/"  + id  ;
    }

    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url,{ controller : controller, from : from}, function(data, status){
        $("#loader1").html('');
        $("#pager").html(data);
    });
}

function print_payment(pid){

    var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + pid;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);

    $(w).ready(function(){
        w.print();
    });
        
}
</script>