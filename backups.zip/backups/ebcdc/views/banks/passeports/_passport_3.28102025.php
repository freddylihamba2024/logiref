<?php $userid = $encaissement->Makerid_9; $feuille=''; $infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>

<?php if(isset($encaissement->Type_57) && $encaissement->Type_57 == 'mobile'): ?>
<div class="alert alert-warning text-white" id='mobile_payment_msg'> Ce paiement a &eacute;t&eacute; initi&eacute; en ligne, veuillez cliquer sur le bouton modifier pour completer les informations manquantes.</div>
<?php endif;?>
<?php

    if(isset($infos['accounttax']) && $infos['accounttax'] !="")
    {
            #when the customer is exempted from tax
            $disabled_1 = "disabled";
            $disabled_2 = "";
    }
    else 
    {
            #when the customer is not exempted from tax
            $disabled_1 = "";
            $disabled_2 = "disabled";
    }
    
?>

<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($encaissement->Commission_23 > 0) $encaissement->Commission_23 = number_format($encaissement->Commission_23,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $userid==$this->session->userdata("user_id") && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>
 

<?php if(isset($_POST['Reference_14']) && $_POST['Reference_14'] !='') {$reference = $_POST['Reference_14'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nif_17']) && $_POST['Nif_17'] !='') {$nif = $_POST['Nif_17'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else{ $designation = "";}?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        $infos['totalDevise'] = $encaissement->Devise_12;
}
?>

<div id="logirad-message"></div>

<?php echo form_open('', array('id' => 'form', 'class' => $view)); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $this->chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Infos[Email]" value="<?= isset($infos["Email"]) ? $infos["Email"] : "" ?>" id="email">
    <input type="hidden" name="Infos[Phone]" value="<?= isset($infos["Phone"]) ? $infos["Phone"] : "" ?>" id="phone">
    <input type="hidden" name="Email_54" value="<?= isset($encaissement->Email_54) ? $encaissement->Email_54 : "" ?>" id="">
    <input type="hidden" name="Logirad_53" value="<?php echo $encaissement->Logirad_53; ?>" />
    <input type="hidden" name="Logiradid" value="<?php echo $encaissement->Logirad_53; ?>"  id="" />

    <?php $this->chtml->box_body_opening('', true);?>

    <div class="box-body">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader"></div>
            </div> 
            <!------------------------- Beneficiare  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', array('DGRAD'), 'DGRAD', ' class="form-control bg-gray" required="required"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                        </span>
						<?php echo form_input('Service_16', set_value('Service_16', $services['DGRAD'][$encaissement->Service_16]), 'class="form-control" disabled="disabled" id="service" required="required" readonly'); ?>
                        <input type="hidden" name="Service_16" value="0100">
                    </div>
            </div>  
        
            <!-------------------------  Titre de perception  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25" required="required" readonly '); ?>
                </div>
            </div>
            <div class="col-md-7">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                   <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
            <div id="bl" class="col-md-12"></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('', set_value('', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" disabled '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
					<input type="hidden" name="Notedate_27" value="<?= isset($encaissement->Notedate_27) ? date('Y-m-d', strtotime($encaissement->Notedate_27)) : "" ?>">
                </div>
            </div>
            <div class="col-md-7">
                 <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label> 
                    </span>
                    <span id="rlist"><?php echo form_dropdown('', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" disabled="disabled" required="required" '); ?></span>
                    <input type="hidden" name="Typerecette_17" value="<?= isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : "" ?>">
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Art. budg&eacute;taire</label> 
                    </span>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $infos['standard']), ' class="form-control"  maxlength="25" readonly'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label> 
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required" readonly'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required" disabled="disabled" '); ?>
                    <input type="hidden" name="Notedevise_29" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                </div>
            </div>

            <div class="col-md-12 no-padding">
            <!------------------------- Payement  ------------------------------>
                <div class="col-md-5 border"></br><label>Partie 3 :Assujetti ou Contribuable </div>
                <div class="col-md-5 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?></span></label></div>
<!--                <div class="col-md-3 border"></br><label>Paie pour compte&nbsp;<input type="checkbox" name="Infos[pourcompte]" value="<?php echo(isset($infos['pourcompte']))? $infos['pourcompte']:''; ?>" <?php echo isset($infos['pourcompte']) ? 'checked' :''; ?>></label></div>-->

                <input type="hidden" name="Infos[fraisbcc]"  value="1" id="infosFbcc">
                <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
            </div>
            <div class="col-md-12 hidden" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux d'echange : </b> <span id="exchange_message"></span></div>
            <div class="col-md-12 hidden" id="trans_bloc"><b>Détails de la transaction: </b> <span id="trans_message"></span></div>

            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86" readonly'); ?>
                </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" readonly'); ?>
                    </div>
            </div>
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19">Mode de paiement</label> 
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41">Taux de change</label> 
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                        <input type="hidden" value="<?php echo isset($infos['rate_code']) ? $infos['rate_code'] : "" ?>" name="Infos[rate_code]" id="rate_code" >
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                           <label for="Datevaleur_31">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10" disabled="disabled" required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <input type="hidden" name="Datevaleur_31" value="<?php echo date('Y-m-d', strtotime($encaissement->Datevaleur_31))?>" id="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                        <label for="Datetrans">Date transaction</label>
                        </span>
                        <?php 
                            if (isset($encaissement->Mode_19) && $encaissement->Mode_19 == '5'):
                                $date_trans= isset($infos['Datetrans']) ? $infos['Datetrans'] : "";
                                $date_form = date('d-m-Y', strtotime($date_trans));
                                $readonly = '';
                            else:
                                $readonly = 'disabled';
                                $date_form = '';
                            endif;
                        ?>
                        <?php echo form_input('Infos[Datetrans]', set_value('Infos[Datetrans]', $date_form), ' id="dateTrans" class="form-control" maxlength="10" '. $readonly); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                        </span>
                        <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control" id="transID" required="required"'); ?>
                    </div>
            </div> 
            <div class="col-md-5">
                    <div class="input-group"> 
                        <span class="input-group-addon">
                            <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33 ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26" autocomplete="off"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="<?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?>" id="account_name">
                        <input type="hidden" name="account_currency" value="" disabled="disabled" id="account_currency">
                        <input type="hidden" name="account_balance" value="" disabled="disabled" id="account_balance">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11">Montant &agrave; payer</label> 
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required" readonly'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23"><div id="commiision">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" readonly '); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23"><div id="tva">Tva</div></label>
                        </span>
                        <?php $tva = ($encaissement->Commission_23 * 0.16); ?>
                        <?php echo form_input('', set_value('', $tva), 'class="form-control" id="feesTva" readonly '); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Total">Montant total</label> 
                        </span>
                        <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
                    </div>
            </div>
            <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="commissionDevise" disabled="disabled"'); ?>
                        <input type="hidden" name="Devise_12" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('',$devises , "USD", 'class="form-control"  required="required" disabled="disabled" id="tvaDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF','USD'=>'USD'), 'USD', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                    </div>
                    <input type="hidden" name="Devise_24" value="<?php echo isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "" ?>">
            </div>
			<!-------------------------  DGRAD Passport  ------------------------------>
            <div id="DGRADQuotepart" style="<?php echo ($encaissement->Typerecette_17 == "27421600") ? '' : 'display: none;'; ?>">
                <div class="col-md-12"><br/><label>Partie 4 : Informations additionnelle</label><br/></div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefINSS">Quota Comite</label> 
                        <?php echo form_input("Infos[QuotasComite]", set_value("Infos[QuotasComite]", isset($infos['QuotasComite'])? $infos['QuotasComite']:""), 'class="form-control" readonly'); ?>
                    </div>
                </div> 

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasDGI">Quota Prestataire</label> 
                        <?php echo form_input("Infos[QuotasPrestataire]", set_value("Infos[QuotasPrestataire]", isset($infos['QuotasPrestataire'])?$infos['QuotasPrestataire']:""), 'class="form-control" id="" readonly'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasONEM">Quota Service</label> 
                        <?php echo form_input("Infos[QuotasService]", set_value("Infos[QuotasService]", isset($infos['QuotasService'])?$infos['QuotasService']:""), 'class="form-control" id="" readonly'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasINPP"> Quota Tresor Public</label> 
                        <?php echo form_input("Infos[QuotasTresor]", set_value("Infos[QuotasTresor]", isset($infos['QuotasTresor'])? $infos['QuotasTresor']:""), 'class="form-control" id="" readonly'); ?>
                    </div>
                </div>
            </div>

            <!------------------------- Repartitions  ------------------------------>
            <div class="col-md-12 border"><br/><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            <div  id="Comptabilisation" class="col-md-12">

            </div> 
            <!-------------------------  END  ------------------------------>
    </div>
    <div  class="box-footer clearfix">
            <div id="createPaiement" class="col-md-12">
                    <!-------------------------  No valider  ------------------------------> 
                    <?php if($encaissement->Checkerid_10 ==0 && ($userid == $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                        <?php if($_SESSION['Logiref_role']!=5) : ?>
                            <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-trash"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <?php endif; ?>  
                        <!-- <button type="button" id="print" disabled="disabled" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp; -->
                    <?php endif; ?>

                    <!-------------------------  Valider  ------------------------------> 
                    <?php if($encaissement->Checkerid_10 > 0 && ($userid = $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                        <button type="submit" disabled="disabled" class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" disabled="disabled" id="delete" class="btn btn-danger"><i class="fa fa-trash"></i>&nbsp;&nbsp;~Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <!-- <button type="button" id="print" class="btn btn-primary" <?= ($encaissement->Status_2 == 2 ) ? '':'disabled'?>><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp; -->

                        <?php if ($encaissement->Status_2 == 2): ?>
                        <div class="btn-group">
                            <button type="button" id="attestation" class="btn btn-primary no-border no-margin">
                                <i class="fa fa-folder-open"></i> Preuve de paiement
                            </button>

                            <button type="button" class="btn btn-secondary no-border dropdown-toggle f14" id="dropdownToggle">
                                <span class="caret"></span>
                            </button>

                            <ul class="dropdown-menu text-left" role="menu" id="dropdownMenu" style="display: none;">
                                <li><a onclick="print()"><i class="fa fa-print f14"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</a></li>
                                <li class="divider"></li>
                                <li><a onclick="mail()"><i class="fa fa-envelope f14"></i>&nbsp;&nbsp;Envoyer l'attestation par mail&nbsp;&nbsp;</a></li>
                            </ul>
                        </div>
                        <?php endif; ?>


                        <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>
                    
                    <a id="closePanel"  type="button" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
            </div>
    </div>
<?php $this->chtml->box_body_closing(); ?> 	  

<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/jquery-3.6.0.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>'; 
var controller ='<?php echo $controller;?>';
var from = '<?php echo $from;?>';

var compte = $("#compteId").val();
if(compte.length == 14)
{
        get_accountname_internal();
}
else
{
        get_accountname(); 
}

// 
$('.chosen-select').chosen({width: "100%"});

var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

$('#dateTrans').datepicker({
    todayHighlight: true,
    format: 'dd-mm-yyyy',
    autoclose: true
}).on('changeDate', function(e) {
    // Ici ça se déclenche uniquement quand l’utilisateur choisit une date
    handleTransactionChange();
});//

$('#montantNote').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#recetteMontant').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#commission').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#montantNote').change(function(){
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        
        $('#montantNote').val(note);
        $('#recetteMontant').val(note);
        
        if(note !="")
        {
            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#rate_code').val('TTB');
                $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');
            commission();
            get_account_tariff();
        }
});

$('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(devise == 'USD')
            {
                note = note * taux;
                if(note) $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#rate_code').val('TTB');
                if(note) $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');

            commission();
            get_account_tariff();
        }
        
        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();

        if(devise_recette == 'USD' && devise_compte == 'CDF')
        {
            get_exchange_rate();
        }
        else
        {   
            $('#exchange_bloc').addClass('hidden');
            $('#Taux').val(taux);
        }
});

$('#recetteMontant').change(function(){
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
       
        
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);
        
        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                    $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else
            {
                    var commissions = $("#commission").val();

                    if(commissions !='0' && commissions !='')
                    {
                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                            if(deviseNote=='USD')
                            {
                                montant = montant * taux;

                                montant = commissions + montant + (commissions *0.16);

                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }
                    else
                    {
                            if(recetteDevise == 'USD')
                            {
                                montant = montant * taux;
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }

                    $('#info').html('');
                    commission();
                    get_account_tariff();
            } 
        }
});

$('#recetteDevise').change(function(){
        commission();
        get_account_tariff();
});

$('#service').change(function(){
        commission();
        get_account_tariff();
});

$('#commission').change(function(){
        var commissions = $("#commission").val();
        var devise = $('#recetteDevise').val();
        var montant = $('#recetteMontant').val();
        
        
        if(commissions !='0' && commissions !='')
        {
                commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    montant = montant * taux;
                    montant = montant + commissions + (commissions *0.16);

                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    montant = montant + (montant *0.0005) + commissions + (commissions *0.16);
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
        else if(commissions=='0' || commissions=='')
        {
                if(devise == 'USD')
                {
                    montant = montant * taux;
                    
                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
});


$("#pager").on("change", "#recette", function(){
        commission();
        get_account_tariff();
});

$("#modeId").change(function(){

        var mode = $('#modeId option:selected').val();

        if (mode == 5)
        {
                $('#trans_bloc').removeClass('hidden');


                $("#dateTrans").prop("disabled", false);
                $("#dateTrans").prop("required", true);
                $("#transID").val('');
                $("#labelTrans").html("R&eacute;f&eacute;rence de la transaction");
        }
        else
        {
                $('#trans_bloc').addClass('hidden');
                $("#trans_message").html('');

                $("#dateTrans").prop("disabled", true);
                $("#dateTrans").prop("required", false);
                $("#dateTrans").val("");
                $("#transID").val('');
                $("#labelTrans").html("R&eacute;f&eacute;rence de l&apos;OP");
        }
});

// Attach event listeners
$("#modeId").change(handleTransactionChange);

// Désactiver le bouton pendant la saisie
$('#transID').on("keyup", function() {
    var mode = $('#modeId option:selected').val();

    if (mode == 5) 
    {
        $("#enregistrer").prop('disabled', true); 
        $("#dateTrans").prop("disabled", false);
    } 
    else {
        $("#enregistrer").prop('disabled', false);
        $("#dateTrans").prop("disabled", true);
    }
});

// Quand on sort du champ (fin de saisie), lancer la vérif
$('#transID').on("blur", function() {
    var transID = $(this).val();
    var transDate = $("#dateTrans").val();
    var mode = $('#modeId option:selected').val();

    if(mode == 5 && transID !== '' && transDate !== ''){
        get_paiement_transid(transID, transDate);
    }
});

'<?php if (isset($encaissement->Mode_19) && $encaissement->Mode_19 == '5'): ?>';
    var trans_id = $("#transID").val();
    var trans_date = $("#dateTrans").val();

    get_trans_details(trans_id, trans_date);
'<?php endif; ?>';  

$('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      
        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();
        
	    var test_balance = false;
        
        var compte = $("#compteId").val();
        

        if(compte.length == 14)
        {
            test_balance = false;
        }
        else
        {
            test_balance = true;
        
        }
        
        if(test_balance)
        {
            get_account_balance(data);

        }
        else
        {
            '<?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==9): ?>';
                submiter(data, 'update');
            '<?php endif; ?>';

            '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>';
                submiter(data, 'validation');
            '<?php endif; ?>';
        }
        
});

$("#compteId").change(function(){
    get_account_tariff(); 
    var compte = $("#compteId").val();

    if(compte.length == 14)
    {
            get_accountname_internal();
            
    }
    else
    {
            get_accountname();      
    }
});

$("#compteDevise").change(function(){
    var compte = $("#compteId").val();

    if(compte.length == 14)
    {
            get_accountname_internal();    
    }
    else
    {
            get_accountname();    
    }
    commission();
    var devise_recette = $('#deviseNote option:selected').val();
    var devise_compte = $('#compteDevise option:selected').val();
    
    if(devise_recette == 'USD' && devise_compte == 'CDF')
    {
        get_exchange_rate();
    }
    else
    {   
        $('#exchange_bloc').addClass('hidden');
        $('#Taux').val(taux);
    }
});

function handleTransactionChange() 
{
    var mode = $('#modeId option:selected').val();
    var transID = $("#transID").val();
    var transDate = $("#dateTrans").val();

    if (mode == 5) 
    {
        $("#dateTrans").prop("disabled", false);
        $("#dateTrans").prop("required", true);

        if (transID !== '' && transDate !== '')
        {
            get_paiement_transid(transID, transDate);
            //get_trans_details(transID, transDate);
        }
    }
    else
    {
        $("#dateTrans").prop("disabled", true);
        $("#dateTrans").prop("required", false);
        $("#dateTrans").val("");
        $("#transID").val('');
        $("#enregistrer").prop('disabled', false);
    }
}

function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#compteDevise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + (montant *0.0005) + commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            alert('ERROR!' + error);
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

function get_accountname_internal()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname_internal'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else if(reponse.devise == null && reponse.account == null)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                        $("#taxinfo").html('');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#compteDevise').val('');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#tva_value').prop('disabled', true);
                                                $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                $('#tva').prop('checked', '');
                                                
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + commissions;
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                        }
                                        else
                                        {
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                
                                                var total = montant + (montant * 0.0005) +commissions + (commissions *0.16);
                                                
                                                $("#montantTotal").val(total.toLocaleString());
                                                
                                                $('#tva').prop('checked', 'checked');
                                                $('#tva_value').prop('disabled', false);
                                                
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            alert('ERROR!' + error);
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

$("#cancel").click(function(){
        location.reload(true);
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var commission = $("#commission").val();
        var  total_amount = '';
        var customer_code = $("#compteId").val();
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/'); ?>/default<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';

            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, customer_code:customer_code }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '')
                        {
                            if(result[0] !="")
                            {
                                    $("#commission").val(result[0]);
                                    $("#commissionDevise").val(result[1]);
                                    $("#tvaDevise").val(result[1]);
                                    $("#montantTotal").val(result[2]);

                                    $('#recetteDevise').val(result[1]);

                                    var tva = parseFloat(result[0]) * 0.16;
                                   
                                    $("#feesTva").val(tva);

                            }
                            else if(parseFloat(result[0]) == '0' && type_recette == "27421600")
                            {
                                    $("#commission").val('0');
                                    $("#commissionDevise").val('USD');

                                    $("#montantTotal").val(montant);
                                    $('#recetteDevise').val(devise);

                                    $("#feesTva").val(0);
                                    $("#tvaDevise").val(devise);
                            }
                        }
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}

function submiter(data, obj)
{
   
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/passeport/save'); ?>/'+obj+'<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>'
            scrollUP();
            //$('#enregistrer').prop("disabled",true);
            message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php endif; ?>'
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){

                        let pid = result.id;
                        let code = result.code;
                        let msg = result.message;

                        $('#loader').html('');
						$('#mobile_payment_msg').html('');
						
                        if(code === 200)
                        {
                                $('#step2').remove;
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');

                                $('#print').prop("disabled",false);
                                 
                                var url = '<?php echo base_url($module.'/passeport/display/preview'); ?>/' + gid;
                                    
                                $.get(url, function(data, status){
                                    $('#loader').html('<div class="alert alert-success text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(code === "E162")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "E463")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "E411")
                        {
                                $("#message").html('');
                                $('#enregistrer').prop("disabled",false);
                                $('#loader').html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "E3238")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "W0205")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "E397")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "AD3")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "E9999")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "ERR002")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "ERR003")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code === "P83")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(code == "CP604" || code == "CP000" || code=="CP001" || code=="CP002" || code == "CP22"  || code == "CP404")
                        {
                                $("#message").html('');
                                $("#confirm_note").removeClass("hidden");

                                 $('#loader').html('<div class="alert alert-info text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; Finacle, veuillez trouver ce paiement dans le menu r&eacute;gularisation pour le r&eacute;gulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

$("#confirm_note").click(function(event){

    // stop the form from submitting the normal way and refreshing the page
    event.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    
    var url = '<?php echo base_url($module.'/passeport/save/confirm_note'); ?>';
    var data = $("#form").serialize();
        scrollUP();
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){
                    $('#loader').html('');

                    $('#confirm_note').prop("disabled",true);

                    if(result == "CP604" || result == "CP000" || result=="CP001" || result=="CP002" || result == "CP22"  || result == "CP404")
                    {
                            $("#message").html('');
                            $('#logirad-message').html('<div class="alert alert-danger text-white">Info!  La confirmation du paiement dans Logirad n’a pas pu aboutir. Veuillez consulter la section « Paiements en régularisation » pour finaliser la procédure.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "CP200")
                    {
                            $("#message").html('');
                            $('#logirad-message').html('<div class="alert alert-danger text-white"> Paiement de la note de perception a déjà été confirmé avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $("#message").html('');
                            $('#logirad-message').html('<div class="alert alert-success text-white"> Paiement de la note de perception confirmé avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            },
            error:function(error)
            {
                $('#logirad-message').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
    });
    
});

$("#closePanel").click(function(){
   
    closeView(controller,from);
    
});

function get_paiement_transid(transID, transDate)
{
    if(transID !== '')
    {  
            $('#trans_bloc').removeClass('hidden');
            $("#trans_message").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            
            var url = '<?php echo base_url($module.'/passeport/data/get_paiment_transid'); ?>';

            $("#enregistrer").prop('disabled', true);

            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { transID : transID}, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(reponse)
                    {
                            if(reponse == '200')
                            {
                                    $("#loader").html('');
                                    $("#trans_message").html('');
                                    
                                    $("#enregistrer").prop('disabled', false);
                                    
                                    $('#trans_bloc').addClass('hidden');
                                    
                                    get_trans_details(transID, transDate);
                            }
                            else
                            {
                                    scrollUP();
                                    
                                    $('#trans_bloc').removeClass('hidden');
                                    
                                    $("#trans_message").css('color', 'red');
                                    $("#trans_message").html("Numéro de transaction déjà utilisé aujourd'hui");
                                    $('#loader').html('<div class="alert alert-info text-white">INFORMATION : Ce numéro de transaction a déjà été utilisé pour la journée d aujourd hui. Veuillez vérifier et saisir un autre numéro...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    
                                    $("#enregistrer").prop('disabled', true);
                            }
                    },
                    error:function(error)
                    {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }   
            });  
    }
    else
    {
            $('#loader').html('<div class="alert alert-warning text-white">ERREUR :Réference pas saisi...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
}

function get_trans_details(transID, transDate)
{
        if(transID !== '' && transDate !='')
        {  
                $('#trans_bloc').removeClass('hidden');
                
                $("#trans_message").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                
                var compte = $('#compteId').val();
                var devise = $('#compteDevise option:selected').val();
                var montant = $('#recetteMontant').val();
                var designation = $('#designation').val();
                var amount = $("#recetteMontant").val();

                var url = '<?php echo base_url($module.'/accounts/data/get_trans_details'); ?>';

                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { transID : transID, transDate:transDate, compte : compte, devise : devise, designation : designation, amount: amount}, 
                        dataType    : 'json', 
                        encode      : true,
                        success: function(reponse)
                        {
                                if(reponse == '405')
                                {
                                        $("#loader").html('');

                                        $("#trans_message").css('color', 'red');
                                        $("#trans_message").html('Cette réference n&apos;existe pas.');
                                        
                                        $("#enregistrer").prop('disabled', true);
                                }
                                else if(reponse == '404')
                                {
                                        $("#loader").html('');

                                        $("#trans_message").css('color', 'red');
                                        $("#trans_message").html('Le format de cette réference n\'est pas valide');

                                        $("#enregistrer").prop('disabled', true);
                                }
                                else if(reponse == '501')
                                {
                                        scrollUP();

                                        $("#enregistrer").prop('disabled', true);

                                        $("#trans_message").css('color', 'red');
                                        $("#trans_message").html('Les comptes ne correspondent pas');
                                        //$("#trans_message").html(reponse.account+ ' != '+ compte);

                                        $("#message").html('');
                                        $('#loader').html('<div class="alert alert-danger text-white"> Le compte saisi ne correspond pas à celui retourn&eacute par la r&eacutef&eacuterence FINACLE. veuillez saisir le bon compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(reponse.code == '200')
                                {
                                        $("#loader").html('');
                                        $("#trans_message").css('color', 'green');
                                        $("#trans_message").html(reponse.account+ ' / '+ reponse.amount);
                                        
                                        $("#enregistrer").prop('disabled', false);
                                }
                                else
                                {
                                        $("#loader").html('');
                                        $("#trans_message").css('color', 'red');
                                        $("#trans_message").html('Probl&egrave;me de connexion &agrave; finacle!');
                                        
                                        $("#enregistrer").prop('disabled', true);
                                }

                        },
                        error:function(error)
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }   
                });  
        }
        else
        {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR :Réference pas saisi...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

        }
}

function mail() 
{
    $("#loader").html('<img align="middle" height="30px" src="<?= base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
    $('#sendmail').prop("disabled", true);
    $('#logirad-message').html('');

    var id = ref;
    var url = '<?= base_url($module.'/impression/display/email_passport'); ?>/' + id;

    scrollUP();
    
    $.get(url, function(response) {
        $('#loader').html('');

        try {
            var data = JSON.parse(response);

            if (data.status === 1) {
                $('#loader').html(`
                    <div class="alert alert-success text-white">
                        Preuve de paiement envoyée avecss succès !
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    </div>
                `);
            } else {
                $('#loader').html(`
                    <div class="alert alert-danger text-white">
                        ❌ ${data.error || "Erreur lors de l'envoi du mail, veuillez réessayer."}
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    </div>
                `);
                $('#sendmail').prop("disabled", false);
            }

        } catch (e) {
            $('#loader').html(`
                <div class="alert alert-danger text-white">
                    ⚠️ Réponse inattendue du serveur.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                </div>
            `);
            $('#sendmail').prop("disabled", false);
        }
    }).fail(function() {
        $('#loader').html(`
            <div class="alert alert-danger text-white">
                🚫 Impossible de contacter le serveur.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
            </div>
        `);
        $('#sendmail').prop("disabled", false);
    });
}


// function mail() {
//     var id = ref;
//     var url = '<?php echo base_url($module."/impression/display/email_passport"); ?>/' + id;
//     window.open(url, '_blank'); // 👈 ouvre la page test dans un nouvel onglet
// }


function closeView(controller, display)
{
        if(controller != '' && display != '')
        {
                $.get("<?php echo base_url($module.'/'.$controller.'/display/'.$from); ?>", function(data, status){
                    $("#loader").html('');
                    $("#container").html(data);
                });
        }
        else
        {
                location.reload();   
        }
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript"  charset="utf-8">
    
$("#delete").click(function(){

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var id = '<?php echo $encaissement->Id_0; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/passeport/save/deletion'); ?>/'+id;
                $.get(url, {recette:recette}, function (result, status) {
                    var result = JSON.parse(result);
                    
                    if(result.code === 200)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled",true);
                        $('#print').prop("disabled",true);
                        $('#schema').prop("disabled",true);
                        $('#delete').prop("disabled",true);
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});
     
$("#print").click(function(){
        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

function print () {

    $('#enregistrer').prop("disabled",true);
    var id = ref;
    var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + ref;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);

    $(w).ready(function(){
        w.print();
    });
}

function mail () {

    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $('#sendmail').prop("disabled",true);

    $('#logirad-message').html('');

    var id = ref;
            
    var url = '<?php echo base_url($module.'/impression/display/email_passport'); ?>/' + id;
    
    $.get(url, function(data, status){
        
        $('#loader').html('');
        
        if(data)
        {
                $('#loader').html('<div class="alert alert-info text-white">Preuve de paiementenvoy&eacute; par mail avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');  
        }
        else
        {
                $('#loader').html('<div class="alert alert-danger text-white">Preuve de paiement n\'a pas &eacute;t&eacute; envoy&eacute; par mail, une erreur s\'est produite, veuillez reprendre.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#sendmail').prop("disabled",false);
        }
        
    });
}

$("#sendmail").click(function(){

    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $('#sendmail').prop("disabled",true);

    $('#logirad-message').html('');

    var id = ref;
            
    var url = '<?php echo base_url($module.'/impression/display/email_passport'); ?>/' + id;
    
    $.get(url, function(data, status){
        
        $('#loader').html('');
        
        if(data)
        {
                $('#loader').html('<div class="alert alert-info text-white">Preuve de paiementenvoy&eacute; par mail avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');  
        }
        else
        {
                $('#loader').html('<div class="alert alert-danger text-white">Preuve de paiement n\'a pas &eacute;t&eacute; envoy&eacute; par mail, une erreur s\'est produite, veuillez reprendre.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#sendmail').prop("disabled",false);
        }
        
    });
});

$("#schema").click(function(){

        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/schema'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        var mode = $('#modeId').val();
        if(mode === '7' || mode == '8')
        {
               $("#compteId").prop('disabled',''); 
               $("#compteDevise").prop('disabled',''); 
        }
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>

function comptabilisation(ref)
{
    $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/comptabilisation/display/get_details_dgrad'); ?>/' + ref;
    $.get(url, function(data, status){
        $("#Comptabilisation").html(data);
    });
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}


function get_exchange_rate()
{
        var devise = $('#compteDevise').val();
        var devise_recette = $('#recetteDevise').val();
        var note_number = $('#reftitre').val();
        
        $('#exchange_bloc').removeClass('hidden');
        
        $("#exchange_message").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                
        var url = '<?php echo base_url($module.'/rates/data/get_taux'); ?>';
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : { devise_compte : devise, devise_recette : devise_recette, note_number : note_number}, 
            dataType    : 'json', 
            encode          : true,
            success: function(reponse)
            {
                    if(reponse.code == '200')
                    {
                            $("#Taux").val(reponse.rate);
                            $('#rate_code').val('TTS');
                            $("#exchange_message").css('color', 'green');
                            $("#exchange_message").html('Taux de vente r&eacute;cup&eacute;r&eacute; avec succ&egrave;s.');
                    }
                    else if(reponse.code == '0003')
                    {
                            $("#exchange_message").css('color', 'red');
                            $("#exchange_message").html('Probl&egrave;me de connexion &agrave; Finacle, le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                    }
                
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
    }); 
}

function get_account_tariff()
{
        var compte = $('#compteId').val();
        var regie = 'DGI';
        var url = '<?php echo base_url($module.'/accounts/data/get_account_tarification'); ?>';
        
        if(compte !== '')
        {  
                $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, regie : regie}, 
                        dataType    : 'json', 
                        encode      : true,
                        success: function(reponse)
                        {
                            
                                if(reponse.commission >= 0)
                                {
                                        $("#commission").val(reponse.commission);
                                        $("#commissionDevise").val(reponse.devise);
                                        
                                        $("#infosFbcc").val(reponse.fraisbcc);
                                        $("#infosTva").val(reponse.tva);

                                        var commissions = reponse.commission;
                                        var tva = reponse.tva;
                                        var fbcc = reponse.fraisbcc;
                                        
                                        commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                                        //$('#commission').val(commissions.toLocaleString());

                                        
                                        var montant = $('#recetteMontant').val();

                                        var recetteDevise = $('#recetteDevise option:selected').val();
                                        
                                        
                                        if(montant != "")
                                        {
                                            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
                                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                                            
                                            if(recetteDevise=='USD')
                                            {
                                                montant = montant * taux;

                                                montant = commissions + montant + (commissions *0.16);

                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (tva == '0' && fbcc == '0')
                                            {
                                                montant = commissions  + montant;
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (tva == '1')
                                            {
                                                montant = commissions  + montant + (commissions *0.16);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else if (fbcc == '1')
                                            {
                                                montant = commissions  + montant + (montant *0.0005);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                            else
                                            {
                                                montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                                $('#montantTotal').val(montant.toLocaleString());
                                            }
                                        }
                                }
                        },
                        error:function(error)
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }   
                });  
        }
        else
        {
                
        }
}

function get_account_balance(data)
{
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
		
        
        var url = '<?php echo base_url($module.'/accounts/data/get_account_balance'); ?>';
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_compte : devise_compte, balance : balance}, 
            dataType    : 'html',  
            encode          : true,
            success: function(reponse)
            {
                    if(reponse == '200')
                    {
                             '<?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==9): ?>';
                                submiter(data, 'update');
                            '<?php endif; ?>';

                            '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>';
                                submiter(data, 'validation');
                            '<?php endif; ?>';
                    }
                    else if(reponse == '300')
                    {
                            $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant pour le paiement de cette note de perception !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(reponse == '405')
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    $("#enregistrer").prop('disabled', false);
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
}
</script>

<script>
    $(function() {
        const $dropdown = $('#dropdownMenu');

        // Clic sur le bouton → ouvrir/fermer le menu
        $('#dropdownToggle').on('click', function(e) {
            e.stopPropagation(); // empêche la fermeture immédiate
            $dropdown.toggle();  // ouvre/ferme
        });

        // Clic n’importe où ailleurs → ferme le menu
        $(document).on('click', function() {
            $dropdown.hide();
        });

        // Empêche fermeture si on clique à l’intérieur du menu
        $dropdown.on('click', function(e) {
            e.stopPropagation();
        });
    });
</script>



