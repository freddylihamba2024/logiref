
<div class="">
    <div class="col-md-1"></div>
    <div class="col-md-10">
       
        <div class="col-md-12">
            <h2 class="text-blue" ><?php echo " Paiement des passeports"; ?></h2>
        <p class="page-header"></p>
        </div>
        <div class="col-md-12">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification de la note<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound  <?php if($step==2) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Impression de la preuve<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/>
            <div id="loader"></div>
            <div id="logirad-message"></div>
        </div>
            
            <div id="pager" class="col-md-12">
                <?php 
                if($step==2) : 
                    echo $this->load->view('_step_2'); 
                elseif($step==3):
                    echo $this->load->view('_step_3'); 
                else: 
                ?>
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <?php $this->chtml->box_body_opening("", true);?>  
                    <div class="col-md-3">
                        <div id="approvalWarning" style="color:#F00"></div><br/>
                        <p>
                            Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de passeport !
                        </p>
                        <br/><br/>
                    </div>
                        <div class="box-body">
                            <div class="col-md-4">
                                <div id="approvalWarning"></div><br/>
                            </div>
                            <div class="col-md-8 bLeft">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                                                <?php echo form_input('Reference_8','', 'class="form-control"  id="Reference_32" required = "required"'); ?>
                                                <input type="hidden" name="Typerecette_12" value="<?= '27421600' ?>"/> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-footer  clearfix">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                            <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php echo form_close(); ?>
                    <?php $this->chtml->box_body_closing(); ?>
                <?php endif; ?>
            </div>
    </div>
    <div class="col-md-1">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    $("#mainform").submit(function(event){
        event.preventDefault();

        var data = $(this).serialize();
        next_step(data);

    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $('#Reference_32').on('input', function() {
        var currentText = $(this).val();
        var upperText = currentText.toUpperCase();
        $(this).val(upperText);
    });

    function next_step(data) 
    {
        $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . "/passeport/display/verification"); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (res) {
                $('#loader').html('');
                
                switch(res.code) {
                    case "E604":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Aucune information trouv&eacute;e pour cette r&eacute;f&eacute;rence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E000":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Logirad n\'est pas disponible !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "401":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Aucune authorisation trouvée pour Logirad !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "402":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Logirad : Le token d\'autorisation a expiré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "500":
                        $('#loader').html('<div class="alert alert-warning text-white">D&eacute;sol&eacute;!... Logirad: Echec de la connexion : votre mot de passé a expiré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E404":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... Le num&eacute;ro de la note de perception est incorrect! Veuillez v&eacute;rifier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E503":
                        $('#loader').html(res.message);
                        break;
                    case "E504":
                        $('#loader').html(res.message);
                        break;
                    case "E505":
                        $('#loader').html(res.message);
                        break;
                    case "E506":
                        $('#loader').html(res.message);
                        break;
                    case "E507":
                        $('#loader').html(res.message);
                        break;
                    case "E508":
                        $('#loader').html(res.message);
                        break;
					case "E509":
                        $('#loader').html(res.message);
                        break;
                    case "E999":
                        $('#loader').html(res.message);
                        break;
                    case "E000":
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E000...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E001":
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: Erreur inattendue E001...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E002":
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: Erreur inattendue E002...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E22":
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: La r&eacute;f&eacute;rence n&pos;est pas envoy&eacute;e...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E406":
                        $("#loader").html('<div class="alert alert-warning">D&eacute;sol&eacute;!... un probleme est survenu. Merci de reessayer plus tard<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "LOCKOUT":
                        $("#loader").html('<span style="color:#F00">' + res.message + '</span>');
                        break;
                    case "SUCCESS":
                        // Affiche le contenu HTML généré côté serveur
                        $("#pager").html(res.html);
                        $("#step-1").removeClass('bg-green').addClass('bg-gray');
                        $("#step-2").removeClass('bg-gray').addClass('bg-green');
                        break;
                    default:
                        // Par défaut, si code inconnu
                        $("#loader").html('<div class="alert alert-warning">Erreur inattendue. Merci de réessayer.</div>');
                }
            },
            error: function (error) {
                alert("Erreur AJAX : " + error);
            }
        });
    }
</script>
