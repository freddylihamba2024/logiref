<?php $userid = $this->session->userdata("user_id");?>
<?php $usertype = $this->session->userdata("user_type");?>
<div class="col-md-11">
    <div class="col-md-12">
        <div id="loader"></div>
    </div>
    <div class="col-md-12">
        <?php $this->chtml->box_body_opening("", false); ?>
            <div class="statistic-box no-border no-padding">
                <div class="col-md-12 no-margin">
                    <h1>Gestion des tarifications pr&eacute;f&eacute;rentielles</h1>
                    <h5 class="page-header">
                        Consultation de la liste des tarifications
                    </h5>
                </div>
                <div class="col-sm-12">
                    <form id="filter" role="form">
                        <div class="col-md-3">
                            <div class="form-group">   
                                <b>Agence </b><br/><?php echo form_dropdown('agence', $agences, '', 'class="form-control" id="agence" '); ?>
                            </div>
                        </div>
                        <div class="col-md-5 border-left">
                            <div class="form-group">   
                                <b>B&eacute;n&eacute;ficiaire</b><br/><?php echo form_dropdown('beneficiaires', $beneficiaires['RGF'], '', 'class="form-control" id="type" '); ?>
                            </div>
                        </div>
                        <div class="col-md-3 border-left">
                            <div class="form-group">   
                                <b>Devise</b><br/><?php echo form_dropdown('devise', $devises, '', 'class="form-control" id="devise" '); ?>
                            </div>
                        </div>
                        <div class="col-md-1" align="right">
                            <br/><button class="btn btn-bitbucket pull_right" type="submit"> <i class="fa fa-fw fa-refresh text-gray"></i></button><br/>
                        </div>
                    </form>
                </div>
            </div>
        <?php $this->chtml->box_body_closing(); ?>
    </div>
   
    <div class="col-md-12">
        <?php $this->chtml->box_body_opening('', false); ?>
        <div id="list" class="col-md-12">
            <?php if(empty($comptes)) $comptes = $lastestComptes;?>
            <?php if(!empty($tarifications)): ?>
                <table id="tableREN" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-blue">
                            <th>#</th>
                            <th>Agence</th>
                            <th width="50">B&eacute;n&eacute;ficiaire</th>
                            <th width="150">Comptes</th>
                            <th width="120">Frais bancaire</th>
                            <th width="50">Tva</th>
                            <th width="100">Frais BCC</th>
                            <th>Maker</th>
                            <th>Checker</th>
                            <th width="100">Validation</th>
                            <th><span class="fa fa-fw fa-edit f14"></span></th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach($tarifications as $row): 
                            $infos = json_decode($row->Infos_14); 
                            
                        ?>
                            <tr>
                                <td width="5"><?php echo $i++; ?></td>
                                <td><?php if(isset($agences[$row->Agence_12])) echo $agences[$row->Agence_12];?></td>
                                <td width="50"><?php if($row->Beneficiaires_7=='') echo 'TOUTES'; else echo $row->Beneficiaires_7;?></td>
                                
                                <td width="150">
                                        
                                           
									<?php if($row->Compte_8!='') echo $row->Compte_8;?>
                                        
                                </td>
                                <td width="50"><?php if($row->Montant_11=='') echo 'Aucun'; else echo $row->Montant_11.' '.$row->Devise_10;?></td>
                                <td class="bleu" width="50"><?php if(isset($infos->tva) && $infos->tva=='1')echo 'Oui'; else echo 'Non';?></td>
                                <td class="bleu" width="50"><?php if(isset($infos->fraisbcc) && $infos->fraisbcc=='1')echo 'Oui'; else echo 'Non';?></td>
                          
                                <td>
                                    <?php echo(isset($users[$row-> Creator_4]))? $users[$row->Creator_4] :' - ';?>
                                </td>
                                <td>
                                    <?php if($row->Changer_6==0): ?>
                                        <span class="text-red"> - </span>
                                    <?php else: ?>
                                        <?php echo(isset($users[$row->Changer_6]))?$users[$row->Changer_6]:' - ';?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->Changer_6==0): ?>
                                      <span class="text-red"> En attente </span>
                                    <?php else:?>
                                      <?php echo $row->	Validation_13;?>
                                    <?php endif; ?>
                                </td>
                                <td width="25" align="right">
                                    <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2): ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                    <?php else: ?>
                                        <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php endif; ?>
                                </td>
                                
                            </tr>
                        <?php endforeach; ?>
                    </tbody>    
                </table>
            <?php else: ?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucune tarification n'est enregistr&eacute;!<br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
        <?php $this->chtml->box_body_closing(); ?> 
    </div>
</div> 
<div class="col-md-1">
    <div class="col-md-12">
        <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle3"></span></a>
        <br/><br/>
    </div>
</div>  

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

//Add a member
$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        <?php if($_SESSION['Logiref_role']==1){ ?>
        $.get("<?php echo base_url($module.'/accounts/display/tarification_account'); ?>", function(data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });
        <?php }else { ?>
            $("#loader").html('<div class="alert alert-warning text-white">D&eacute;sol&eacute! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
        <?php } ?>
});

$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});


function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/accounts/display/tarification_account'); ?>/' + id;
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
      });
}


$("#filter").submit(function(event){
        event.preventDefault();
        $("#list").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/display/filterTarif'); ?>';
        var data = $(this).serialize();
        $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html',
        encode          : true,
        success: function (result) {
            $('#list').html('');
            $("#list").html(result);
        },
        error: function (error) {
            alert('ERROR!' + error);
        }
       });
});

</script>

