<?php if($tarification->Id_0 > 0) $title='Modifier'; else $title ='Nouvelle tarification'; ?>
<?php $tarifs = isset($tarification->Infos_14)? $tarification->Infos_14: [] ?>
<?php #var_dump(json_decode($tarifs, true)); die; ?>

<?php if($tarification->Id_0 > 0) $tarif = json_decode($tarifs, true); ?>

<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h2><?php echo $title;?></h2>
    <p class="page-header"></p>
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
    <?php $this->chtml->box_body_opening('', true);?>
        <div class="box-body">
            <div class="col-md-5">
                <div class="form-group">
                    <label for="Compte_6">Num&eacute;ro de compte</label>
                    <?php 
                        if($tarification->Agenceid_9!=''):
                            $compte = str_replace($tarification->Agenceid_9,'',$tarification->Compte_8); 
                            $compte = str_replace($tarification->Clef_15,'',$compte);
                            $numCompte = $tarification->Agenceid_9.'-'.$compte; 
                        else : 
                            $numCompte = $tarification->Compte_8; 
                        endif;
                    ?>
                    <?php if($tarification->Clef_15!='') $numCompte = $numCompte.'-'.$tarification->Clef_15;?>
                    <?php echo form_input('Compte_8', set_value('Compte_8', $numCompte), 'class="form-control" required="required" placeholder="Ex: 15051-307010037" maxlength="25"'); ?>
                </div>    
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="Devise_10">Devise</label>
                    <?php echo form_dropdown('Devise_10', $devises, $tarification->Devise_10, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-5" id="agence_id">
                <div class="form-group">
                    <label for="agence">Agence bancaire</label>
                    <?php echo form_dropdown('agence', $guichets, $tarification->Agence_12, ' id="agence" class="form-control" '); ?>
                </div>
            </div>
            
            <div class="col-md-7">
                <div class="form-group">
                    <label for="Produit">Produit</label>
                    <input id="" type="text" value="<?php echo 'Frais bancaire'; ?>" name=""   class="form-control"  required = "required" readonly/>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="amount">Montant</label>
                    <input id="amoun" type="text"  name="amount" value="<?php echo $tarification->Montant_11; ?>"  class="form-control"/>
                    <input name="Id_0" type="hidden" value="<?php echo $tarification->Id_0; ?>" />
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="Devise_1O">Devise</label>
                    <input id="devise" type="text" value="CDF"  name="Devise_1O"  class="form-control" required = "required" readonly/>
                </div>    
            </div>
            
            <?php if ($tarification->Id_0 > 0): ?>
            <div class="col-md-7 border"></br><label>Paie TVA&nbsp;<input type="checkbox" name="Infos[tva]" value="<?= 1?>" <?php echo isset($tarif['tva']) ? (($tarif['tva'] == 1) ? "checked": ""): "" ; ?>  /></label></div>
            <div class="col-md-5 border"></br><label>Paie frais bcc&nbsp;<input type="checkbox" name="Infos[fraisbcc]" value="<?= 1 ?>" <?php echo isset($tarif['fraisbcc']) ? (($tarif['fraisbcc'] == 1) ? "checked": "") : "" ; ?>></label></div>
            <?php else: ?>
            <div class="col-md-7 border"></br><label>Paie TVA&nbsp;<input type="checkbox" name="Infos[tva]" value="<?= 1?>" checked   /></label></div>
            <div class="col-md-5 border"></br><label>Paie frais bcc&nbsp;<input type="checkbox" name="Infos[fraisbcc]" value="<?= 1 ?>" checked ></label></div>
            <?php endif; ?>
            <div class="col-md-12">
                <div id="RGF" class="form-group">
                    <label for="Beneficiaires3">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires3', $beneficiaires['RGF'], $tarification->Beneficiaires_7, ' id="rgf3" class="form-control" '); ?>
                </div> 
                <input name="Id_0" type="hidden" value="<?php echo $tarification->Id_0; ?>" />
            </div>
            
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" id="save" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Valider..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
    <?php echo form_close(); ?>
</div>
<div class="col-md-2">
</div>

<script type="text/javascript">

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/save'); ?>/tarification_account/<?php echo $tarification->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $tarification->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($tarification->Id_0 == ''){ ?>
                        $("#mainform").trigger('reset');
                    <?php }else {?>
                        $('#save').prop("disabled",true);
                    <?php }?>    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
  
        $.get("<?php echo base_url($module.'/accounts/display/tarification_accounts'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
   
}


</script>
