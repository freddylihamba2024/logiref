<?php if($compte->Id_0 > 0) $title='Modifier'; else $title ='Nouveau compte de pr&eacute;paiment' ?>
<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h2><?php echo $title;?></h2>
    <p class="page-header"></p>
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
    <?php $this->chtml->box_body_opening('', true);?>
        <div class="box-body">
            <div class="col-md-8">
                <div class="form-group">
                    <label for="Accountnumber">Num&eacute;ro de compte</label>
                    <?php $Accountnumber = $compte->Accountnumber_8;?>
                    <?php echo form_input('Accountnumber', set_value('Accountnumber', $Accountnumber), 'class="form-control" required="required" maxlength="30"'); ?>
                </div>   
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Devise">Devise</label>
                    <?php echo form_dropdown('Devise', $devises, $compte->Devise_10, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label for="Refsydonia">R&eacute;f&eacute;rence du compte sydonia</label>
                    <?php $Refsydonia = $compte->Refsydonia_9; ?>
                    <?php echo form_input('Refsydonia', set_value('Refsydonia', $Refsydonia), 'class="form-control" required="required" maxlength="30"'); ?>
                </div> 
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Nifimportateur">Num&eacute;ro imp&ocirc;t</label>
                    <?php $Nifimportateur = $compte->Nifimportateur_7; ?>
                    <?php echo form_input('Nifimportateur', set_value('Nifimportateur', $Nifimportateur), 'class="form-control"  maxlength="30"'); ?>
                </div> 
            </div>
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" id="save" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
    <?php echo form_close(); ?>
</div>
<div class="col-md-2">
</div>

<script type="text/javascript">
  
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/save'); ?>/prepayment/<?php echo $compte->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $compte->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($compte->Id_0 == ''){ ?>
                        $("#mainform").trigger('reset');
                    <?php }else {?>
                        $('#save').prop("disabled",true);
                    <?php }?>    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});
$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/prepayments/accounts'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/accounts/display/prepayments'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
}
</script>
