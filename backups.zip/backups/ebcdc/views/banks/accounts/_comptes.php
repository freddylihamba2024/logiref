<?php if(!empty($comptes)): ?>
    <table id="tableREN" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th>#</th>
                <th>Agence</th>
                <th width="50">Type</th>
                <th>Taxe</th>
                <th>Libell&eacute;</th>
                <th>Service/Bureau</th>
                <th width="150">Comptes</th>
                <th width="50">R&eacute;gie</th>
                <th>Maker</th>
                <th>Checker</th>
                <th width="100">Validation</th>
                <th><span class="fa fa-fw fa-edit f14"></span></th>
                <th><span class="fa fa-trash-o f14"></span></th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach($comptes as $row){ ?>
                <tr id="<?php echo $row->Id_0; ?>">
                    <td width="5"><?php echo $i; ?></td>
                    <td><?php if(isset($guichets[$row->Agence_12])) echo $guichets[$row->Agence_12];?></td>
                    <td width="50"><?php echo ' '.$row->Type_4;?></td>
                    <td><?php echo $row->Recette_13?></td>
                    <td><?php if(isset($recettes[$row->Beneficiaires_5][$row->Recette_13])) echo $recettes[$row->Beneficiaires_5][$row->Recette_13]; else echo "";?> </td>
                    <td class="bleu" ><?php echo $row->Serviceid_16; ?></td>
                    <td width="150"><?php if($row->Type_4!='CAC' || $row->Type_4!='CPI') echo '<b>'.$row->Agenceid_15.'</b>'; else echo '<span class="text-red">'.$row->Agenceid_15.'</span>'; ?><?php if($row->Compte_6!='') echo '-'.$row->Compte_6;?><?php if($row->Clef_7!='') echo '-'.$row->Clef_7;?>&nbsp;&nbsp;<?= $row->Devise_8;?></span></td>
                    <td width="50"><?php echo ' '.$row->Beneficiaires_5;?></td>
                    <td>
                        <?php echo(isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';?></td>
                    <td>
                        <?php if($row->Checkerid_11==0){ ?>
                          <span class="text-red"> - </span>
                        <?php }else {?>
                         <?php echo(isset($users[$row->Checkerid_11]))?$users[$row->Checkerid_11]:' - ';?>
                        <?php } ?>
                    </td>
                    <td>
                        <?php if($row->Status_2==2 && $row->Checkerid_11==0){ ?>
                            <span class="text-orange">Supprim&eacute;</span>
                        <?php }elseif($row->Checkerid_11==0){?>
                            <span class="text-red">En attente</span>
                        <?php }else {?>
                          <?php echo $row->Validation_10;?>
                        <?php } ?>
                    </td>
                    <td width="25" align="right">
                        <?php if($_SESSION['Logiref_role']==1){ ?>
                            <?php if($row->Status_2 == "2"):?>
                                <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                            <?php else:?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                            <?php endif;?>
                        <?php }elseif($_SESSION['Logiref_role']==2) {?>
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                        <?php }else{ ?>
                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                        <?php }?>
                    </td>
                    <td>
                        <?php if($_SESSION['Logiref_role']==1){ ?>
                            <?php if($row->Status_2 == "1" && $row->Checkerid_11 !="0"):?>
                                <span class="fa fa-fw text-gray fa fa-trash-o f14"> </span> 
                            <?php elseif($row->Status_2 == "2"):?>
                                <span class="fa fa-fw text-gray fa fa-trash-o f14"> </span>
                            <?php else:?>
                                <a style="cursor:pointer" onclick="remove('<?php echo $row->Id_0; ?>')"><span class="fa fa-trash-o text-red f14"></span></a>
                            <?php endif;?>
                        <?php }elseif($_SESSION['Logiref_role']==2) {?>
                            <?php if($row->Status_2 == "1" && $row->Checkerid_11 =="0"):?>
                                <span class="fa fa-fw text-gray fa fa-trash-o f14"> </span> 
                            <?php elseif($row->Status_2== "2"):?>
                                <a style="cursor:pointer" onclick="remove('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-danger" >Supprim&eacute;</a>
                            <?php else:?>
                                <a style="cursor:pointer" onclick="remove('<?php echo $row->Id_0; ?>')"><span class="fa fa-trash-o text-red f14"></span></a>
                            <?php endif; ?> 
                        <?php }else{ ?>
                            <span class="fa fa-fw text-gray fa fa-trash-o f14"> </span>   
                        <?php } ?>

                    </td>
                </tr>
            <?php $i++; } ?>
        </tbody>    
    </table>
<?php else: ?>
    <section id="cat_list">
        <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            Aucun compte n'est enregistr&eacute;!<br/>
        </div>
    </section>
<?php endif;?>

<script type="text/javascript">
    
function remove(Id){
   var cHtml = '<div class="alert alert-warning text-black" style="width:96%; position:absolute;display:block; z-index:10000"> Voulez-vous supprimer ce compte?<br/> <button class="btn btn-primary btn-flat" type="button" id="delYes">Oui</button> <button class="btn btn-gray btn-flat" type="button" id="delNo">Non</button><br/><br/></div>';
    var dHtml = $("#"+ Id ).html();
    $("#"+ Id ).html('');
    $("#"+ Id ).html(cHtml);
    $("#delYes").click(function(){
        $("#"+ Id ).html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/save/delete'); ?>/' + Id;
        $.get(url,{object:'remove_account'}, function(data, status){
            $("#"+ Id ).html('');
            $("#loader").html(data);
            $('#' + Id ).remove();
        });
    });
    $("#delNo").click(function(){
        $("#"+ Id ).html('');
        $("#"+ Id ).html(dHtml);
    });
}


</script>