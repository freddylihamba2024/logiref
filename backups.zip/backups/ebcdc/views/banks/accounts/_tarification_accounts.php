<?php if(!empty($tarifications)): ?>
                <table id="tableREN" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-blue">
                            <th>#</th>
                            <th>Agence</th>
                            <th width="50">B&eacute;n&eacute;ficiaire</th>
                            <th width="150">Comptes</th>
                            <th width="120">Frais bancaire</th>
                            <th width="50">Tva</th>
                            <th width="100">Frais BCC</th>
                            <th>Maker</th>
                            <th>Checker</th>
                            <th width="100">Validation</th>
                            <th><span class="fa fa-fw fa-edit f14"></span></th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach($tarifications as $row): 
                            $infos = json_decode($row->Infos_14); 
                            
                        ?>
                            <tr>
                                <td width="5"><?php echo $i++; ?></td>
                                <td><?php if(isset($agences[$row->Agence_12])) echo $agences[$row->Agence_12];?></td>
                                <td width="50"><?php if($row->Beneficiaires_7=='') echo 'TOUTES'; else echo $row->Beneficiaires_7;?></td>
                                
                                <td width="150">
									
										<?php if($row->Compte_8!='') echo $row->Compte_8;?>
									
								</td>
                                <td width="50"><?php if($row->Montant_11=='') echo 'Aucun'; else echo $row->Montant_11.' '.$row->Devise_10;?></td>
                                <td class="bleu" width="50"><?php if(isset($infos->tva) && $infos->tva=='1')echo 'Oui'; else echo 'Non';?></td>
                                <td class="bleu" width="50"><?php if(isset($infos->fraisbcc) && $infos->fraisbcc=='1')echo 'Oui'; else echo 'Non';?></td>
                          
                                <td>
                                    <?php echo(isset($users[$row-> Creator_4]))? $users[$row->Creator_4] :' - ';?>
                                </td>
                                <td>
                                    <?php if($row->Changer_6==0): ?>
                                        <span class="text-red"> - </span>
                                    <?php else: ?>
                                        <?php echo(isset($users[$row->Changer_6]))?$users[$row->Changer_6]:' - ';?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->Changer_6==0): ?>
                                      <span class="text-red"> En attente </span>
                                    <?php else:?>
                                      <?php echo $row->	Validation_13;?>
                                    <?php endif; ?>
                                </td>
                                <td width="25" align="right">
                                    <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2): ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                    <?php else: ?>
                                        <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php endif; ?>
                                </td>
                                
                            </tr>
                        <?php endforeach; ?>
                    </tbody>    
                </table>
            <?php else: ?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucune tarification n'est enregistr&eacute;!<br/>
                    </div>
                </section>
            <?php endif;?>