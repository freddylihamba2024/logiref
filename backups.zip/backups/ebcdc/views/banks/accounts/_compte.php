<?php if($compte->Id_0 > 0) $title='Modifier'; else $title ='Nouveau compte'; ?>
<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h2><?php echo $title;?></h2>
    <p class="page-header"></p>
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
    <?php $this->chtml->box_body_opening('', true);?>
        <div class="box-body">
            <div class="col-md-8">
                <div class="form-group">
                    <label for="Compte_6">Num&eacute;ro de compte</label>
                    <?php $numCompte = $compte->Agenceid_15; if($compte->Compte_6!='') $numCompte = $numCompte.'-'.$compte->Compte_6; if($compte->Clef_7!='') $numCompte = $numCompte.'-'.$compte->Clef_7?>
                    <?php echo form_input('Compte_6', set_value('Compte_6', $numCompte), 'class="form-control" required="required" placeholder="Ex: 15051-307010037" maxlength="25"'); ?>
                </div>    
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Devise_8">Devise</label>
                    <?php echo form_dropdown('Devise_8', $devises, $compte->Devise_8, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Type_4">Type de compte</label>
                    <?php echo form_dropdown('Type_4', $types, $compte->Type_4, ' id="Type1" class="form-control" required="required"'); ?>
                    <input name="Id_0" type="hidden" value="<?php echo $compte->Id_0; ?>" />
                </div>
            </div>
            <div class="col-md-6">
                <div id="AIP" class="form-group" style="display: none; ">
                    <label for="Beneficiaires1">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires1', $beneficiaires, $compte->Beneficiaires_5, ' id="aip2" class="form-control" '); ?>
                </div> 
                <div id="BKC" class="form-group">
                    <label for="Beneficiaires2">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires2', $banque['BKC'], $compte->Beneficiaires_5, ' id="bkc2" class="form-control" '); ?>
                </div> 
                <div id="RGF" class="form-group">
                    <label for="Beneficiaires3">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires3', $banque['RGF'], $compte->Beneficiaires_5, ' id="rgf3" class="form-control" '); ?>
                </div> 
            </div>
            <div class="col-md-6" id="service_id">
                <div class="form-group">
                    <label for="service">Service/Bureau</label>
                    <span id="slist"><?php echo form_dropdown('service', $services, $compte->Serviceid_16, ' id="service" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6 hidden" id="servicetype_id">
                <div class="form-group">
                    <label for="service">Service</label>
                    <span id="slist"><?php echo form_dropdown('service1', $service_types, $compte->Serviceid_16, ' id="servicetype_id" class="form-control" '); ?></span>
                </div>
            </div>
            
            <div class="col-md-6" id="recette_id">
                <div class="form-group">
                    <label for="recette">Recette</label>
                    <span id="rlist"><?php echo form_dropdown('recette', $recettes, $compte->Recette_13, ' id="recette" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="nif">
                <div class="form-group">
                    <label for="nif">Num&eacute;ro imp&ocirc;t</label>
                    <span ><?php echo form_input('nif', $compte->Nif_17, ' id="nif" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="csydonia">
                <div class="form-group">
                    <label for="comptesydonia">Compte SYDONIA</label>
                    <span ><?php echo form_input('comptesydonia', $compte->Comptesydonia_18, ' id="comptesydonia" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="agence_id">
                <div class="form-group">
                    <label for="agence">Agence bancaire</label>
                    <?php echo form_dropdown('agence', $guichets, $compte->Agence_12, ' id="agence" class="form-control" '); ?>
                </div>
            </div>
	    <div class="col-md-6">
                <div class="form-group">
                    <label for="ville">Ville</label>
                    <?php echo form_dropdown('ville', $villes, $compte->Ville_14, ' id="ville" class="form-control" '); ?>
                </div>
            </div>
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <?php if($_SESSION['Logiref_role']==1):?>
                    <button type="submit" id="save" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
                <?php elseif($_SESSION['Logiref_role']==2):?>
                    <?php if($compte->Status_2 == "2"){?>
                        <button type="submit" id="save" class="btn btn-primary pull-left" disabled="disabled"><i class="fa fa-save"></i>&nbsp;Valider..&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;       
                    <?php }else{?>
                        <button type="submit" id="save" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;Valider..&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;       
                    <?php } ?>
                <?php endif;?>
                
            </div>
        </div>
    <?php $this->chtml->box_body_closing(); ?> 
    <?php echo form_close(); ?>
</div>
<div class="col-md-2">
</div>

<script type="text/javascript">
onload();
inload();

function inload(){
    var isOfregie= '<?php echo $compte->Beneficiaires_5; ?>';

    if(isOfregie ==="DGI" )
    {
            $('#service_id').css( "display", "none");
            $('#servicetype_id').removeClass('hidden');
            $('#servicetype_id').css( "display", "");

            $("#servicetype_id").prop('required', true);
            $("#service_id").prop('required', false);
    }
    else
    {
            $('#servicetype_id').css( "display", "none");
            $('#service_id').css( "display", "");

            $("#service_id").prop('required', true);
            $("#servicetype_id").prop('required', false);
    }
    
}
function onload(){
    var isOfType = '<?php echo $compte->Type_4; ?>';
    if(isOfType ==="CAC" || isOfType ==="CPI" || isOfType ==="CFE")
    {
        $("#BKC").css( "display", "none");
        $("#RGF").css( "display", "none");
        $("#AIP").css( "display", "");
        
        $("#aip2").prop('required', true);
        $("#bkc2").prop('required', false);
        $("#rgf3").prop('required', false);
    }
    else if(isOfType === "CPT" || isOfType === "CGU" || isOfType === "CTP")
    {
        $("#RGF").css( "display", "");
        $("#BKC").css( "display", "none");
        $("#AIP ").css( "display", "none");
        
        $("#rgf3").prop('required', true);
        $("#bkc2").prop('required', false);
        $("#aip2 ").prop('required', false);
    }
    else if(isOfType ==="CSO" || isOfType ==="CPS")
    {
        $("#BKC").css( "display", "");
        $("#RGF").css( "display", "none");
        $("#AIP ").css( "display", "none");
        
        $("#bkc2").prop('required', true);
        $("#rgf3").prop('required', false);
        $("#aip2 ").prop('required', false);
    }
    else 
    {   
        $("#BKC").css( "display", "");
        $("#AIP").css( "display", "none");
        $("#RGF").css( "display", "none");
        
        $("#bkc2").prop('required', true);
        $("#aip2").prop('required', false);
        $("#rgf3").prop('required', false);
    }   
};  

$("#Type1").change(function(){
    
    var isOfType = $('#Type1 option:selected').attr('value');
    
    if(isOfType ==="CAC"){
        $("#BKC").css( "display", "none");
        $("#RGF").css( "display", "none");
        $("#AIP").css( "display", "");
        
        $("#aip2").prop('required', true);
        $("#bkc2").prop('required', false);
        $("#rgf3").prop('required', false);
    }
    else if(isOfType ==="CPI" || isOfType === "CFE")
    {
        $("#BKC").css( "display", "none");
        $("#RGF").css( "display", "none");
        $("#AIP").css( "display", "");
        
        $("#aip2").prop('required', true);
        $("#bkc2").prop('required', false);
        $("#rgf3").prop('required', false);
        
       
    }
    else if(isOfType === "CFB") {
        
        $("#bkc2").prop('required', true);
        $("#aip2").prop('required', false);
        $("#rgf3").prop('required', false);
        
        $("#BKC").css( "display", "");
        $("#AIP").css( "display", "none");
        $("#RGF").css( "display", "none");
       
    }
    else if(isOfType === "CPT" || isOfType === "CTP"){
        
        $("#aip2").prop('required', false);
        $("#bkc2").prop('required', false);
        $("#rgf3").prop('required', true);
        
        $("#RGF").css( "display", "");
        $("#BKC").css( "display", "none");
        $("#AIP").css( "display", "none");
        
    }
    else if(isOfType ==="CCV" || isOfType ==="CPU" || isOfType ==="TVA" || isOfType ==="CSO" || isOfType ==="CPS")
    {
        $("#BKC").css( "display", "");
        $("#RGF").css( "display", "none");
        $("#AIP").css( "display", "none");
        
        $("#bkc2").prop('required', true);
        $("#aip2").prop('required', false);
        $("#rgf3").prop('required', false);
    }
    else if(isOfType ==="CGU")
    {
       
        $("#aip2").prop('required', false);
        $("#bkc2").prop('required', false);
        $("#rgf3").prop('required', true);
        
        $("#RGF").css( "display", "");
        $("#BKC").css( "display", "none");
        $("#AIP").css( "display", "none");
     
    }
    else 
    {
        $("#BKC").css( "display", "");
        $("#RGF").css( "display", "none");
        $("#AIP").css( "display", "none");
        
        $("#bkc2").prop('required', true);
        $("#aip2").prop('required', false);
        $("#rgf3").prop('required', false);
      
    }    
    
});




$("#recette").change(function(){
    
    var recette = $('#recette option:selected').attr('value');
    
    if(recette != "")
    {
        $('#regie').prop('disabled', true);
    }
    else
    {
        $('#regie').prop('disabled', false);
    }
});

$("#rgf3").change(function(){
    
        var regie = $('#rgf3 option:selected').attr('value');
        if(regie == 'DGI')
        {
                $('#servicetype_id').css( "display", "");
                $('#servicetype_id').removeClass('hidden');
                $('#service_id').addClass('hidden');
                
        }
        else
        {
                $('#service_id').removeClass('hidden');
                $('#servicetype_id').addClass('hidden');
        }
});


 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/accounts/save'); ?>/compte/<?php echo $compte->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $compte->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($compte->Id_0 == ''){ ?>
                        $("#mainform").trigger('reset');
                    <?php }else {?>
                        $('#save').prop("disabled",true);
                    <?php }?>    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/comptes/accounts'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/accounts/display/comptes'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
}


</script>
