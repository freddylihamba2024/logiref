<?php $infos = json_decode($encaissement->Notereference_30, true);

        $date= explode('-',$infos["standard"]);
        if(count($date) == 3)
        {
                $mois = $date[1];
                $annee = $date[2];
        }
        else
        {
                $mois = "";
                $annee = "";
        }


?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>

<body style="padding: 20px 20px">

    <span style="padding-top: 300px;">
        <p style="text-align:justify; ">
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?>, Agence de KINSHSA-SIEGE</span> atteste avoir encaiss&eacute; en date du <?php echo $encaissement->Datevaleur_31; ?>&nbsp; d'ordre de
                <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span>, pour compte de DGI, ONEM, INPP & CNSS, la somme de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?> <?php echo "( ".$number_letter.") "; ?>
                au titre des Imp&ocirc;t,Cotisations et contributions patronales sur les remunerations du mois de &nbsp;<span style="text-transform: uppercase;" ><?php echo $months[$mois]?></span>, Ann&eacute;e <?php echo $annee;?>
        </p>
    </span>
    
    
    <table style="width: 100%">
        <tr>
            <td>
                <div>
                    <h6>BENEFICIAIRES</h6>
                     <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
                     <?php $dgi = $encaissement->Contrevaleur_22 -  ($infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']); ?>
                        <table>
                            <tr><td> - DGI &nbsp;&nbsp;:</td></tr>
                            <tr><td> - CNSS &nbsp;&nbsp;:</td></tr>
                            <tr><td> - INPP &nbsp;&nbsp;:</td></tr>
                            <tr><td> - ONEM &nbsp;&nbsp;:</td></tr>
                            <hr>
                            <tr><td> TOTAL:</td></tr>
                         </table>
                     <?php endif;?> 
                </div>
            </td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
            <td align ="left" style="">   
                <div>
                    <h6>MONTANT</h6>
                    <?php if(!empty($infos['QuotasINSS']) && !empty($infos['QuotasINPP']) && !empty($infos['QuotasONEM'])):?>
                    <?php $dgi = $encaissement->Contrevaleur_22 -  ($infos['QuotasINSS']+$infos['QuotasINPP']+$infos['QuotasONEM']); ?>
                        <table>
                            <tr><td><?php echo 'CDF '.number_format($dgi,2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasINSS'],2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasINPP'],2,","," "); ?></td></tr>
                            <tr><td><?php echo 'CDF '.number_format($infos['QuotasONEM'],2,","," "); ?></td></tr>
                            <hr>
                            <tr><td><?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td></tr>
                        </table>
                    <?php endif;?>
                </div>
            </td>
        </tr>
    </table>
    
    
    <div style="padding-top:  200px;">
        <p align="center">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?>.<br>
        </p>
        
        <p align="center">
            <?php echo ' '.$this->session->userdata('account_business').' '; ?>
        </p>
        <p align="center">
            </br></br>
            (Signature autoris&eacute;e et cachet sec)
        </p></br>

    </div>



    
    
    
    
   
    
   

</body>
