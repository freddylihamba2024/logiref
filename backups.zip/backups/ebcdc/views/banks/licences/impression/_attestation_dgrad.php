<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <span style="padding-top: 300px;">
        <p style="text-align:justify; padding-top: 125px;">
            <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo ' '.$this->session->userdata('account_business').' '; ?>, Agence de Kinshasa</span> atteste avoir encaiss&eacute; en date du <?php echo $encaissement->Datevaleur_31; ?>&nbsp; d'ordre de
            <span style="text-transform: uppercase;"><span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span>, pour compte de la <span><?php echo $encaissement->Designation_14; ?></span> , la somme de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?><?php echo "( ".$number_letter.") "; ?>
            en paiement de la <?php echo $typeDoc[$encaissement->Notetype_25]; ?>/Versement n&deg; <?php echo $encaissement->Noteid_26; ?> du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?> au titre <?php echo $encaissement->Typerecette_17; ?>.

        </p>
    </span>

    <div style="padding-top:  200px;">
        <p align="center">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?>.<br>
        </p>
        
        <p align="center" style="padding-bottom: 80px">
            <?php echo ' '.$this->session->userdata('account_business').' '; ?>
        </p>
        <p align="center">
            </br></br>
            (Signature autoris&eacute;e et cachet sec)
        </p>

    </div>



    
</body>

</html>