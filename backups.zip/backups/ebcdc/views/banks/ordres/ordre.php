<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="message"></div><br/>
    <div class="col-md-12">
        <h1 class="text-blue">Ordre de paiement</h1>
        <p class="page-header"></p>     
    </div>
    <div class="col-md-12">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound bg-gray f18 center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">V&eacute;rification<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound <?php if($step == 2){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Confirmer le paiement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Imprimer la preuve<br/></div>
        </div>
    </div>
    
    <div id="pager" class="col-md-12">
        <?php if($obj == 'bulletin'):?>
            <?php if($status == 1):?>
                <?php $this->load->view('_blOrdreStep_2'); ?>
            <?php elseif($status == 2):?>
                <?php $this->load->view('_blOrdreStep_3'); ?>
            <?php endif;?>
        <?php elseif($obj == 'declaration'):?>
            <?php if($status == 1):?>
                <?php $this->load->view('_dOrdreStep_2'); ?>
            <?php elseif($status == 2):?>
                <?php $this->load->view('_dOrdreStep_3'); ?>
            <?php endif;?>
        <?php elseif($obj == 'note'):?>
            <?php if($status == 2):?>
                <?php $this->load->view('_noteOrdreStep_2'); ?>
            <?php elseif($status == 3):?>
                <?php $this->load->view('_noteOrdreStep_3'); ?>
            <?php endif;?>
        <?php endif;?>    
    </div>
</div>
<div class="col-md-1"></div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
    
</script>