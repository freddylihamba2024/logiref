<?php 
        $disabled = "disabled";
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
        $mode = '';
        $amount = number_format($note->Amount_10,4,","," ");
        $noteMontant = number_format($note->Notemontant_22,4,","," "); 
        $Infos = json_decode($note->Notereference_26, true); 
        if(isset($_SESSION['Bank_rates'])):
            $taux = json_decode($_SESSION['Bank_rates'], true);
        else: 
            $taux['Dollar_4']  = 00;
            $taux['Euro_5']  = 00;
            $taux['Rand_6']  = 00;
        endif;
        
        if(isset($note->Status_2) && $note->Status_2 == 2) 
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = isset($orders->Account_10) ? $orders->Account_10 : "";
                $devise01 = isset($orders->Currency_11) ? $orders->Currency_11 : "";
                $valeur_account = isset($orders->Account_10) ? $orders->Account_10 : "";
                $devise_account = isset($orders->Currency_11) ? $orders->Currency_11 : "";

                $mode = 7;
                $devise_montant = 'CDF';
        }

?>
<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>

<?php if(isset($Ordreid) && $Ordreid != ""){ ?>
<input type="hidden" name="Ordreid" value="<?= isset($Ordreid) ? $Ordreid : ""; ?>" />
<?php }?>

<?php if(isset($valeur_account) && $valeur_account != ""){ ?>
<input type="hidden" name="Compte_33" value="<?= isset($valeur_account) ? $valeur_account : ""; ?>">
<input type="hidden" name="Devise_34" value="<?= isset($devise_account) ? $devise_account : ""; ?>">
<?php }?>

<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Beneficaire_15" value="<?= $regie ?>"  id="regies" />
<input type="hidden" name="Service_16" value="<?php echo $note->Service_9; ?>"  id="service" />
<input type="hidden" name="Typerecette_17" value="<?php echo $note->Typerecette_12;?>"   id="recette" />
<input type="hidden" name="note_id" value="<?php echo $note_id; ?>" />
<input type="hidden" name="Ordreid" value="<?php echo $Ordreid; ?>" />
        <div id="loader"></div>
        <?php $this->chtml->box_body_opening('', true);?>
            <?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
            <div class="box-body">
                <!------------------------- B�n�ficiare  ------------------------------>
                <div class="col-md-12"><br/><label>B&eacute;n&eacute;ficiare</label><br/></div>
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', $Regies['Regies'], $regie, ' id="regies" class="form-control"'.$disabled.' required="required"  '); ?>
                    </div>
                </div> 
                <div class="col-md-6">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                        </span>
                        <span id="slist"><?php echo form_dropdown('Service_16', $services, $note->Service_9, 'class="form-control" id="service" '.$disabled.' required="required" '); ?></span>
                    </div>
                </div>
                <div class="col-md-12 border"><br/><label>Client (assujetti ou contribuable) </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Nif_13">NIF Client</label> 
                            </span>
                            <?php echo form_input('Nif_13', set_value('Nif_13', $note->Nifclient_7), 'class="form-control" required="required" maxlength="86"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-7">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Designation_14">Client</label> 
                            </span>
                            <?php echo form_input('Designation_14', set_value('Designation_14', isset($client->Designation_5) ? $client->Designation_5 : "" ), 'class="form-control" required="required" maxlength="86"'); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                               <label for="Datevaleur_31">Date paiement</label>
                            </span>
                            <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Mode_19">Mode de paiement</label> 
                            </span>
                            <?php echo form_dropdown('Mode_19', $modes, $mode, 'class="form-control" required="required" id="modeId"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Montant_11">Montant &agrave; payer</label> 
                            </span>
                            <?php echo form_input('Montant_11', set_value('Montant_11', $amount), 'class="form-control" id="recetteMontant" required="required"'); ?>
                        </div>
                        <div class="input-group"> 
                            <span class="input-group-addon">
                                <label for="Compte_33"><div id="compteLabel"><?= $label01; ?></div></label> 
                            </span>
                            <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" disabled="" id="compteId"'); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_12', $devises, $note->Devise_17, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_34', $devises, $devise01, 'class="form-control"  required="required" disabled="" id="compteDevise"'); ?>
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Reference_32">R&eacute;f&eacute;rence du client</label>
                            </span>
                            <?php echo form_input('Reference_32', set_value('Reference_32', $note->Reference_8), 'class="form-control"'); ?>
                        </div>
                    </div> 
                <!-------------------------  Titre de perception  ------------------------------>
                <div class="col-md-12"><br/><label>Titre de perception</label><br/></div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Noteid_26"><div id="TitreId">R&eacute;f&eacute;rence titre</div></label> 
                        </span>
                        <?php echo form_input('Noteid_26', set_value('Noteid_26', $note->Ref_titre_25), ' class="form-control" id="reftitre" maxlength="25"'); ?>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="input-group"  id="recette0">
                        <span class="input-group-addon">
                            <label for="Typerecette_17">Nature paiement</label> 
                        </span>
                        <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $note->Typerecette_12, 'class="form-control" id="recette" required="required" '); ?></span>
                    </div>
                </div>
                <div id="bl" class="col-md-12"></div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notedate_27">Date &eacute;mission</label>
                        </span>
                        <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                        
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notetype_25">Type note</label> 
                        </span>
                        <?php echo form_dropdown('Notetype_25', $documents, 1, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                        <input type="hidden" name="Notetype_25" value="1">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="standard"><div id="StandardLabel01">Art. budg&eacute;taire</div></label> 
                        </span>
                        <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $Infos['standard']), ' class="form-control" placeholder = "E.g: 11201808"  maxlength="6"'); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notemontant_28">Montant de la note</label> 
                        </span>
                        <?php echo form_input('Notemontant_28', set_value('total', $amount), ' id="Notemontant_28" class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Notedevise_29', $devises, $note->Notedevise_23, 'class="form-control" id="Notedevise_29"  required="required"'); ?>
                    </div>
                </div>
        </div>
        <div class="box-footer clearfix">
            <div id="createPaiement" class="col-md-12">
                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="buttonCloseOrdre" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <input type="hidden" name="from" id="from" value="<?= $from; ?>">
            </div>
        </div>
        <?php $this->chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    
    $('#modeId').change(function(){
        var mode = $('#modeId').val();

        if(mode === '7' || mode == '8'){
            $("#compteId").prop('disabled',''); 
            $("#compteDevise").prop('disabled',''); 
            $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
            $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
            $("#compteId").val('');
        }else{
            $("#compteId").prop('disabled','disabled'); 
            $("#compteDevise").prop('disabled','disabled');
            $("#compteLabel").html('Commission');
            commission();
        }
    });
    
    $('#datepicker1').datepicker({
    
    format: 'dd-mm-yyyy'
    });
    $('#datepicker2').datepicker({
            
            format: 'dd-mm-yyyy'
    });
    
    $("#cancel1").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/ordres'); ?>';
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    });
    
    $('#form').submit(function(event) {
            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            scrollUP();
            var data = $(this).serialize();
            //Verifier le BL dans Sydonia
            submiter(data);
    });
    
    var Dtaux = [];
    Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
    Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
    Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>';

    function commission(){
           $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
           $("#compteId").val('');
           $("#compteDevise").prop("selectedIndex", 0);
           var mode = $('#modeId').val();
           var montant = $('#recetteMontant').val();
           var regie = $('#regies').val();
           var service = $('#service').val();
           var devise = 'CDF';
           var recette = $('#recette').val();
           var guichet = $('#guichetId').val();
           

           if(mode === '5' && montant !== '' && regie !== '' && service !== ''){
               var url = '<?php echo base_url($module.'/bank/display/charges'); ?>';
               $.ajax({
                       type        : 'POST', 
                       url         : url, 
                       data        : {mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                       dataType    : 'html', 
                       encode          : true,
                       success: function(reponse)
                       {
                           
                           var result = JSON.parse(reponse);
                           
                           $("#commission").val(result[0]);
                           $('#compteId').val(result[0]);
                           $("#compteDevise").prop("selectedIndex", result[1]);
                           $("#Devise").prop("selectedIndex", result[1]);
                           
                       },
                       error:function(error)
                       {

                       }  
               });    
            }
    }
    
    function submiter(data){
            var url = '<?php echo base_url($module.'/bank/display/printnote'); ?>';
            
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                            $('#message').html('');
                            if(result === "E404")
                            {
                                    $('#message').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer cette note de perception.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $('#message').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(result);
                                    $("#step-2").removeClass('bg-green');
                                    $("#step-2").addClass('bg-gray');
                                    $("#step-3").removeClass('bg-gray');
                                    $("#step-3").addClass('bg-green');
                            }
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    }
    
    function comptabilisation(ref){
            $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
            $.get(url, function(data, status){
                $("#Comptabilisation").html(data);
            });
    }
    $("#Notemontant_28").change(function()
    {
            montantValidation();

    });
        $('#recetteDevise').change(function()
    {
          commission();
          montantValidation();
    });
    $("#Notedevise_29").change(function(){

            montantValidation();
    });
    $("#recetteMontant").change(function(){
            montantValidation();
    });

    function montantValidation()
    {
            var notemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
            var recettemontant = parseFloat($("#recetteMontant").val().split(' ').join('').split(',').join('.'));
            var rdevise = $("#recetteDevise option:selected").val();
            var ndevise = $("#Notedevise_29 option:selected").val();
            var note =0;
            var recette=0;


            if(isNaN(recettemontant))
            {
                    recettemontant = 0;
            }

            if(isNaN(notemontant))
            {
                    notemontant = 0;
            }

            $("#recetteMontant").closest('div').removeClass("has-error");
            $('#info').text("");
            if((rdevise!='' && ndevise!='') && (recettemontant && notemontant))
            {
                    if((rdevise != null && rdevise !="CDF") && (ndevise != null && ndevise !="CDF"))
                    {
                            note = notemontant * Dtaux[ndevise];
                            recette = recettemontant * Dtaux[rdevise];

                    }
                    else if((ndevise!= null && ndevise != "CDF") && (rdevise != null && rdevise == "CDF"))
                    {
                            note = notemontant * Dtaux[ndevise];
                            recette = recettemontant;

                    }
                    else if((rdevise != null && rdevise != "CDF") && (ndevise != null && ndevise == "CDF"))
                    {
                            recette = recettemontant * Dtaux[rdevise];
                            note = notemontant;

                    }
                    else
                    {
                            note = notemontant * 1;
                            recette = recettemontant * 1;

                    }
                    if( note >= recette)
                    {
                            valid = false;
                            $("#recetteMontant").closest('div').removeClass("has-error");
                            $('#info').text("");
                    }
                    else
                    {
                            valid = true;
                    }
                    if(valid)
                    {
                            $("#recetteMontant").closest('div').addClass('has-error');
                            $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
                            //$("#recetteMontant").val("");
                    }        
            }  
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
    
    
</script>