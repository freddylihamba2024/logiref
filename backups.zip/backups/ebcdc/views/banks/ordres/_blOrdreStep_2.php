<?php $userid = $this->session->userdata("user_id");  $Infos = $encaissement->Notereference_30;?>
   <?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
   <?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,0,","," "); ?>
   <?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,0,","," "); ?>
   <?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
   <?php $Standard01=''; $total = 0;  ?>
   <?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
   <?php $listTaxes = json_encode($infos['amountSERVICES'], TRUE); ?>
   <?php

   if(isset($_SESSION['Bank_rates'])):
       $taux = json_decode($_SESSION['Bank_rates'], true);
   else: 
       $taux['Dollar_4']  = 00;
       $taux['Euro_5']  = 00;
       $taux['Rand_6']  = 00;
   endif;
   if($encaissement->Id_0==NULL) 
   {
           if($encaissement->Mode_19 == 5)
           {
                   $label01 = 'Commission';
                   $valeur01 = $encaissement->Commission_23;
                   $devise01 = $encaissement->Devise_24;
           }
           else
           {
                   $label01 = 'Compte &agrave; d&eacute;biter';
                   $valeur01 = $encaissement->Compte_33;
                   $devise01 = $encaissement->Devise_34;
           }
   }
   else 
   {
           $label01 = '--------';
           $valeur01 = '';
           $devise01 = '';
   }
   ?>
   <?php $this->chtml->box_body_opening('', true);?>
       <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
           <div class="box-body">
               <input type="hidden" name="Account" value="<?php echo $this->session->userdata('account_id'); ?>">
               <input type="hidden" name="User" value="<?php echo $this->session->userdata('user_id'); ?>">
               <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
               <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
               <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
               <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
               <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
               <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
               <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
               <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
               <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
               <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
               <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25; ?>" />
               <input type="hidden" name="Infos[Year]" value="<?php echo $infos['year']; ?>" />
               <input type="hidden" name="Infos[Number]" value="<?php echo $infos['serie']; ?>" />
               <input type="hidden" name="Infos[Series]" value="<?php echo $infos['serial']; ?>" />
               <input type="hidden" name="Infos[Bank]" value="<?php echo $infos['bank']; ?>" />
               <input type="hidden" name="Infos[amountDGDA]" value="<?php echo $infos['amountDGDA']; ?>" />
               <input type="hidden" name="Infos[amountDGI]" value="<?php echo $infos['amountDGI']; ?>" />
               <input type="hidden" name="Infos[amountPRDGDA]" value="<?php echo $infos['amountPRDGDA']; ?>" />
               <input type="hidden" name="Infos[amountDGRAD]" value="<?php echo $infos['amountDGRAD']; ?>" />
               <input type="hidden" name="Infos[amountSERVICES]" value="<?php echo $listTaxes; ?>" />
               <input type="hidden" name="Infos[taxesPaid]" value='<?php echo json_encode($infos['taxesPaid']); ?>' />
               <input type="hidden" name="Infos[Nifdeclarant]" value="" />
               <input type="hidden" name="Infos[agence]" value="<?php echo $infos['agence']; ?>" />
               <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
               <input type="hidden" name="Ordreid" value="<?php echo $encaissement->Ordreid; ?>" />
               <?php if(isset($infos) && !empty($infos)) { ?><input type="hidden" name="Paiementid" value="<?php echo $infos['Paiementid']; ?>" /><?php } ?>
               <div class="col-md-12">
                   <h2 class=" f20 w-300 page-header"><?php echo '#'.$encaissement->Noteid_26; ?>: Renseignez les informations requises</h2>
               </div>        
               <!------------------------- Payement  ------------------------------>
               <div class="col-md-12 border"><span id="info" class="text-red" style="padding-left:180px; "></span></div>
               <div class="col-md-5">
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="Nif_13">NIF Client</label> 
                       </span>
                       <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
                   </div>
               </div>
               <div class="col-md-7">
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="Designation_14">Client</label> 
                       </span>
                       <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                   </div>
               </div>
               <div class="col-md-5">
                   <div class="input-group">
                       <span class="input-group-addon">
                          <label for="Datevaleur_31">Date paiement</label>
                       </span>
                       <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                   </div>
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="Notedate_27">Date &eacute;mission</label>
                       </span>
                       <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                   </div>
               </div>
               <div class="col-md-5">
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="Montant_11">Montant &agrave; payer</label> 
                       </span>
                       <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                   </div>
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="Notemontant_28">Montant de la note</label> 
                       </span>
                       <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="Notemontant_28" class="form-control"'); ?>
                   </div>
               </div>
               <div class="col-md-2">
                   <div class="input-group">
                       <span class="input-group-addon" style="padding-left:0px !important"></span>
                       <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                   </div>
                   <div class="input-group">
                       <span class="input-group-addon" style="padding-left:0px !important"></span>
                       <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="Notedevise_29"  required="required"'); ?>
                   </div>
               </div>
               <!-------------------------  Titre de perception  ------------------------------>
               <div class="col-md-5">
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="InfoLibelle">Moyen paiments</label> 
                       </span>
                       <?php echo form_dropdown("Infos[moyen]", $moyens, $infos['moyen'], 'class="form-control" id="moyenId"'); ?>
                   </div>
               </div>
               <div class="col-md-7">
                   <div class="input-group">
                       <span class="input-group-addon">
                           <label for="standard"><div id="StandardLabel01">D&eacute;clarant</div></label> 
                       </span>
                       <?php echo form_input("Infos[Agent]",$infos['standard'], ' class="form-control" id="Standard01" maxlength="25"'); ?>
                   </div>
               </div>
               <div id="bl" class="col-md-12"></div>

               <!-------------------------  DGDA Informations additionnelles  ------------------------------>
               <div id="DGDAComplement">
                   <div class="col-md-12"><br/><label>Informations additionnelle</label><br/></div>
                   <div class="col-md-12">
                       <input type="hidden" value="Comptant"  id="optionsRadios1" name="Infos['type']">
                   </div>
                   <div class="col-md-5">
                       <div class="input-group">
                           <span class="input-group-addon">
                               <label for="Mode_19">Type</label> 
                           </span>
                           <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control bg-gray" required="required" id="modeId"'); ?>
                       </div>
                   </div>
                   <div class="col-md-5">
                       <div class="input-group"> 
                           <span class="input-group-addon">
                               <label for="Compte_33"><div id="compteLabel"><?php echo $label01; ?></div></label> 
                           </span>
                           <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" disabled="" id="compteId"'); ?>
                           <input type="hidden" name="commission" value="" id="commission" >
                       </div>
                   </div>
                   <div class="col-md-2">
                       <div class="input-group">
                           <span class="input-group-addon" style="padding-left:0px !important"></span>
                           <?php echo form_dropdown('Devise_34', $devises, $devise01, 'class="form-control"  required="required" disabled="" id="compteDevise"'); ?>
                           <input type="hidden" name="devise" value="CDF" id="devise" >
                       </div>
                   </div>
                   <div class="col-md-12">
                       <div class="input-group">
                           <span class="input-group-addon">
                               <label for="Reference_32">R&eacute;f&eacute;rence</label>
                           </span>
                           <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                       </div>
                   </div>
                   <div class="col-md-6">
                       <div class="input-group">
                           <span class="input-group-addon">
                               <label for="Email">Adresse mail</label>
                           </span>
                           <?php echo form_input('Email', '', 'class="form-control"'); ?>
                       </div>
                   </div>
                   <div class="col-md-6">
                       <div class="input-group">
                           <span class="input-group-addon">
                               <label for="Phone">T&eacute;l&eacute;phone</label>
                           </span>
                           <?php echo form_input('Phone', '', 'class="form-control"'); ?>
                       </div>
                   </div>


               </div>
               <!-------------------------  DGDA Informations additionnelles  ------------------------------>
               <div>
                   <?php if(isset($infos) && !empty($infos)){ ?>
                   <div class="col-md-12"><br/><label>D&eacute;tails du paiement </label><br/></div>
                   <div class="col-md-12">
                       <table id="table" class="table table-hover table-striped fixed_header">
                           <thead class="tScroll">
                               <tr class="bg-blue">
                                   <th width="">B&eacute;n&eacute;ficiaire</th>
                                    <th width="">Taxe code</th>
                                   <th width="">Description</th>
                                   <th width="" class="center">Montant</th>
                               </tr>
                           </thead>
                           <tbody class="fixed_header tScroll">
                               <?php foreach($infos['taxesPaid'] as $taxe) :?>
                                   <tr class="<?php if(!isset($beneficiaires[$taxe->taxeCode])){ echo "text-red";}?> tScroll">
                                       <td><?php echo (isset($beneficiaires[$taxe->taxeCode]))? $beneficiaires[$taxe->taxeCode]:$taxe->taxeCode ;?></td>
                                       <td><?php echo $taxe->taxeCode;?></td>
                                       <td><?php echo $taxe->taxeDescription;?></td>
                                       <td align="right" class="right"><?php echo 'CDF '.number_format($taxe->taxeAmount,2,","," ");?></td>
                                   </tr>
                               <?php endforeach; $total = $total + $taxe->taxeAmount; ?>
                               <tr  class="tScroll">
                                   <td>[+]</td>
                                   <td></td>
                                   <td><b>TOTAL</b></td>
                                   <td align="right"><b><?php echo 'CDF'.number_format($total,2,","," "); ?></b></td>
                               </tr>
                           </tbody>    
                       </table>
                   </div>
                   <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                   <div  id="Comptabilisation" class="col-md-12"></div>
                   <?php
                   }
                   ?>
               </div>
           </div>
           <div class="box-footer clearfix">
               <div id="createPaiement" class="col-md-12">
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="continuer" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Continuer &nbsp;&nbsp;</button>&nbsp;&nbsp;
               </div>
           </div>
       <?php echo form_close(); ?>
   <?php $this->chtml->box_body_closing(); ?> 
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
//commission();

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'dd-mm-yyyy'
});

$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

$("#confirmform").submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});


$("#continuer").click(function(event){
    
    var data = $("#confirmform").serialize();
    genQuittance(data);
    
});

function submiter(data){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/confirmbl'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E404" || result === "E22")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E405")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E13")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Declaration est introuvable.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34x")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "C200")
                        {
                                $('#enregistrer').prop("disabled", true);
                                $('#continuer').prop("disabled", '');
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}
//montantValidation();
$('#modeId').change(function(){
      var mode = $('#modeId').val();
      if(mode === '7' || mode == '8'){
          $("#compteId").prop('disabled',''); 
          $("#compteDevise").prop('disabled',''); 
          $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
          $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
          $("#compteId").val('');
      }else{
          $("#compteId").prop('disabled','disabled'); 
          $("#compteDevise").prop('disabled','disabled');
          $("#compteLabel").html('Commission');
          commission();
      }
});

var Dtaux=[];
Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>'; 

$("#genQ").submit(function(event){
    event.preventDefault();
    var data = $(this).serialize();
    genQuittance(data);
    
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#compteId").val('');
        $("#compteDevise").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = $('#regies').val();
        var service = $('#service').val();
        var devise = 'CDF';
        var recette = $('#recette').val();
        var guichet = $('#guichetId').val();
        
        if(mode === '5' && montant !== '' && regie !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/bank/display/charges'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        $("#compteId").val(result[0]);
                        $("#compteDevise").prop("selectedIndex", result[1]);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                    }  
            });    
        }
}

function extract(titre,regie,service){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/transactions'); ?>/<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : { titre : titre, regie : regie, service : service }, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#bl').html(result);
                },
                error:function(error){
                    $('#bl').html('');
                }
        });
}

$("#printQ").click(function(){
    
        $('#quittance').prop("disabled",true);
        var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/'+ quittance;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#printA").click(function(){
    
        var url = '<?php echo base_url($module.'/bank/data/printquittance'); ?>/' + ref +'/'+Bl;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});


function comptabilisation(ref){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

$("#Notemontant_28").change(function()
{
        montantValidation();
});

$("#recetteMontant").change(function(){
        montantValidation();
});

function montantValidation()
{
        var notemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
        var recettemontant = parseFloat($("#recetteMontant").val().split(' ').join('').split(',').join('.'));
        var rdevise = $("#recetteDevise option:selected").val();
        var ndevise = $("#Notedevise_29 option:selected").val();
        var note =0;
        var recette=0;
       
        
        if(isNaN(recettemontant))
        {
                recettemontant = 0;
        }
        
        if(isNaN(notemontant))
        {
                notemontant = 0;
        }
        
        $("#recetteMontant").closest('div').removeClass("has-error");
        $('#info').text("");
        if((rdevise!='' && ndevise!='') && (recettemontant && notemontant))
        {
                if((rdevise != null && rdevise !="CDF") && (ndevise != null && ndevise !="CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant * Dtaux[rdevise];
                       
                }
                else if((ndevise!= null && ndevise != "CDF") && (rdevise != null && rdevise == "CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant;
                       
                }
                else if((rdevise != null && rdevise != "CDF") && (ndevise != null && ndevise == "CDF"))
                {
                        recette = recettemontant * Dtaux[rdevise];
                        note = notemontant;
                       
                }
                else
                {
                    note = notemontant * 1;
                    recette = recettemontant * 1;
                    
                }
                
                if( note >= recette)
                {
                        valid = false;
                        $("#recetteMontant").closest('div').removeClass("has-error");
                        $('#info').text("");
                }
                else
                {
                        valid = true;
                }

                if(valid)
                {
                        $("#recetteMontant").closest('div').addClass('has-error');
                        $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
                }
                 
        }  
}


function genQuittance(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $('#envoyer').html('<span>T&eacute;l&eacute;chargement...</span>');
        var url = '<?php echo base_url($module.'/bank/display/genquittance'); ?>';
        var button = $('#gen').html();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        $('#gen').prop("disabled", false);
                        $('#gen').html(button);
                        $('#gen').html("T&eacute;l&eacute;chargement");
                        $('#loader').html('');
                        if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E41")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucune quittance trouv&eacute;e. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                scrollUP();
                        }
                        else if(result === "E11")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E002")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E005")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                
                                quittance = result;
                                $('#printQ').prop("disabled", false);
                                $('#gen').html(button);
                                $("#loader").html('');
                                
                        }
                },
                error:function(error){
                    alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
        });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>