<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="loader1"></div>
    <div class="col-md-12">
        <h1 class="text-blue">Ordre de paiement</h1>
        <p class="page-header"></p>     
    </div>
    <div class="col-md-12">
        <div class="col-md-2">
            <div id="step-2" title="" class="bRound bg-green-active f18 center pull-right">1</div>
        </div>
        <div class="col-md-4">
            <div class="pull-left">Confirmer ce paiement<br/></div>
        </div>
        <div class="col-md-2">
            <div id="step-3" title="" class="bRound bg-gray f18 center pull-right">2</div>
        </div>
        <div class="col-md-4">
            <div class="pull-left">Imprimer la preuve<br/></div>
        </div>
    </div>
    <div class="col-md-12"><br/></div>
    <div id="pager" class="col-md-12">
        
    </div>
</div>
<div class="col-md-1"></div>
<script type="text/javascript">
    
</script>

