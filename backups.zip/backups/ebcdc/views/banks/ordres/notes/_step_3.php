<?php $userid = $encaissement->Makerid_9; $feuille=''; $infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>

<?php
    if(isset($infos['accounttax']) && $infos['accounttax'] !="")
    {
            #when the customer is exempted from tax
            $disabled_1 = "disabled";
            $disabled_2 = "";
    }
    else 
    {
            #when the customer is not exempted from tax
            $disabled_1 = "";
            $disabled_2 = "disabled";
    }
    
?>

<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $userid==$this->session->userdata("user_id") && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>
 

<?php if(isset($_POST['Reference_14']) && $_POST['Reference_14'] !='') {$reference = $_POST['Reference_14'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nif_17']) && $_POST['Nif_17'] !='') {$nif = $_POST['Nif_17'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else{ $designation = "";}?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        $infos['totalDevise'] = $encaissement->Devise_12;
}
?>


<?php echo form_open('', array('id' => 'form', 'class' => $view)); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $this->chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <?php $this->chtml->box_body_opening('', true);?>

    <div class="box-body">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader"></div>
            </div> 
            <!------------------------- Beneficiare  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', array('DGRAD'), 'DGRAD', ' class="form-control bg-gray" required="required"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                        </span>
                        <span id="slist"><?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control chosen-select" id="service" required="required" '); ?></span>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
                        <?php endif; ?>
                    </div>
            </div>  
        
            <!-------------------------  Titre de perception  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25" required="required" '); ?>
                </div>
            </div>
            <div class="col-md-7">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                   <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
            <div id="bl" class="col-md-12"></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7">
                 <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label> 
                    </span>
                    <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?></span>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Art. budg&eacute;taire</label> 
                    </span>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $infos['standard']), ' class="form-control"  maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label> 
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
                </div>
            </div>
        
        
        
        
        
            <!------------------------- Payement  ------------------------------>
            <div class="col-md-5 border"><br/><label>Partie 3 : Client, Assujetti ou Contribuable </label><span id="info" class="text-red" style="padding-left:90px; "></span></div>
            <div class="col-md-7 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?></span> <span class="text-red" id="taxinfo"><?php echo(isset($infos['accounttax']))? $infos['accounttax']:''; ?></span></label></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86"'); ?>
                </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
            </div>
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19">Mode de paiement</label> 
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41">Taux de change</label> 
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                           <label for="Datevaleur_31">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                        </span>
                        <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control" required="required"'); ?>
                    </div>
            </div> 
            <div class="col-md-5">
                    <div class="input-group"> 
                        <span class="input-group-addon">
                            <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33 ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="<?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?>" id="account_name">
                        <input type="hidden" name="account_currency" value="" disabled="disabled" id="account_currency">
                        <input type="hidden" name="account_balance" value="" disabled="disabled" id="account_balance">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11">Montant &agrave; payer</label> 
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23"><div id="commiision">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" '.$disabled_1.''); ?>
                        <input type="hidden" name="Commission_23" value="<?= $encaissement->Commission_23 ?>" id="commission_2" <?= $disabled_2 ?> >
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Total">Montant total</label> 
                        </span>
                        <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
                    </div>
            </div>
            <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="commissionDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF'), 'CDF', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                    </div>
            </div>
        
            
            <!------------------------- Repartitions  ------------------------------>
            <div class="col-md-12 border"><br/><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            <div  id="Comptabilisation" class="col-md-12">

            </div>
            
            <!-------------------------  END  ------------------------------>
    </div>
    <div  class="box-footer clearfix">
            <div id="createPaiement" class="col-md-12">
                    <!-------------------------  No valider  ------------------------------> 
                    <?php if($encaissement->Checkerid_10 ==0 && ($userid == $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                        <?php if($_SESSION['Logiref_role']!=5){?>
                            <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <?php } ?>  
                        <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>

                    <!-------------------------  Valider  ------------------------------> 
                    <?php if($encaissement->Checkerid_10 > 0 && ($userid = $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                        <button type="submit" disabled="" class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" disabled="" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;~Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>
                    <?php if($encaissement->Checkerid_10 > 0){?>
                        <button type="button" id="print" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php } ?>
                    <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <a id="closePanel"  type="button" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
            </div>
    </div>
<?php $this->chtml->box_body_closing(); ?> 	  

<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>'; 
var controller ='<?php echo $controller;?>';
var from = '<?php echo $from;?>';

// 
$('.chosen-select').chosen({width: "100%"});

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

$('#montantNote').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#recetteMontant').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#commission').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$('#montantNote').change(function(){
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        
        $('#montantNote').val(note);
        $('#recetteMontant').val(note);
        
        if(note !="")
        {
            
            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');
            commission();
        }
});

$('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(devise == 'USD')
            {
                note = note * taux;
                if(note) $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                if(note) $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');

            commission();
        }
});

$('#recetteMontant').change(function(){
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        
        $('#recetteMontant_2').val(montant);
        
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);
        
        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

            $('#recetteMontant').val(montant.toLocaleString());

            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                    $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
            }
            else
            {
                    var commissions = $("#commission").val();

                    if(commissions !='0' && commissions !='')
                    {
                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                            if(deviseNote=='USD')
                            {
                                montant = montant * taux;

                                montant = commissions + montant + (commissions *0.16);

                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                montant = commissions + montant + (commissions *0.16);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }
                    else
                    {
                            if(recetteDevise == 'USD')
                            {
                                montant = montant * taux;
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }

                    $('#info').html('');
                    commission();
            } 
        }
});

$('#recetteDevise').change(function(){
        commission();
});

$('#service').change(function(){
        commission();
});

$('#commission').change(function(){
        var commissions = $("#commission").val();
        var devise = $('#recetteDevise').val();
        var montant = $('#recetteMontant').val();
        
        $("#commission").val(commissions);
        
        if(commissions !='0' && commissions !='')
        {
                commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    montant = montant * taux;
                    montant = montant + commissions + (commissions *0.16);

                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    montant = montant + commissions + (commissions *0.16);
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
        else if(commissions=='0' || commissions=='')
        {
                if(devise == 'USD')
                {
                    montant = montant * taux;
                    
                    $('#montantTotal').val(montant.toLocaleString());
                }
                else
                {
                    $('#montantTotal').val(montant.toLocaleString());
                }
        }
});


$("#pager").on("change", "#recette", function(){
        commission();
});



$('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      
        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();
        
		submiter(data);
        
});

$("#compteId").change(function(){
    get_accountname(); 
});

$("#compteDevise").change(function(){
    get_accountname(); 
});

$("#cancel").click(function(){
        location.reload(true);
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var commission = $("#commission").val();
        var  total_amount = '';
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '')
                        {
                            if(result[0] !="")
                            {
                                    $("#commission").val(result[0]);
                                    $("#montantTotal").val(result[2]);
                                    
                                    commission = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                                    total_amount = parseFloat($("#montantTotal").val().split(' ').join('').split(',').join('.'));
                                    
                                    $("#commission").val(commission.toLocaleString());
                                    $("#commissionDevise").val(result[1]);
                                    $("#montantTotal").val(total_amount.toLocaleString());
                            }
                        }
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}


function submiter(data)
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/notes/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>'
            scrollUP();
            $('#enregistrer').prop("disabled",true);
            message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php endif; ?>'
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E162")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez contacter votre administrateur<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E463")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#message").html('');
								$('#enregistrer').prop("disabled",false);
                                $('#loader').html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E3238")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes interne intervenant dans ce paiement pose probl&egrave;me, veuillez contacter votre administrateur s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "W0205")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E397")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes interne intervenant dans ce paiement pose probl&egrave;me, veuillez contacter votre administrateur s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "AD3")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "E9999")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "ERR002")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
						else if(result === "ERR003")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#step2').remove;
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                
                                var url = '<?php echo base_url($module.'/notes/display/preview'); ?>/' + result;
                                $.get(url, function(data, status){
                                    $('#loader').html(message);
                                    $("#pager").html(data);
                                })
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

$("#closePanel").click(function(){
   
    closeView(controller,from);
    
});

function closeView(controller, display)
{
        if(controller != '' && display != '')
        {
                $.get("<?php echo base_url($module.'/'.$controller.'/display/'.$from); ?>", function(data, status){
                    $("#loader").html('');
                    $("#container").html(data);
                });
        }
        else
        {
                location.reload();   
        }
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript"  charset="utf-8">
    
$("#delete").click(function(){

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/notes/save/delete'); ?>/'+reference;
                $.get(url, {recette:recette}, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled",true);
                        $('#print').prop("disabled",true);
                        $('#schema').prop("disabled",true);
                        $('#delete').prop("disabled",true);
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});
   
   
   
$("#print").click(function(){

        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
});

$("#schema").click(function(){

        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/schema'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        var mode = $('#modeId').val();
        if(mode === '7' || mode == '8')
        {
               $("#compteId").prop('disabled',''); 
               $("#compteDevise").prop('disabled',''); 
        }
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>

function comptabilisation(ref){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/comptabilisation/display/get_details_dgrad'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'json', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse.devise != devise)
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Devise du compte incorrecte');
                                        $("#taxinfo").html('');
                                        $('#compteDevise').val('');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else
                                {
                                        if(reponse.tax_info =='200')
                                        {
                                                $('#commission').val('0');
                                                $('#commission').prop('disabled', true);
                                                $('#commission_2').prop('disabled', false);
                                                $('#commission_2').val('0');
                                                $("#taxinfo").html(' client exonéré');
                                                $("#tax_info").val('client exonéré');
                                                var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                
                                                $("#montantTotal").val(montant.toLocaleString());
                                        }
                                        else
                                        {
                                                var commission = $('#commission').val();
                                                
                                                $('#commission').val(commission);
                                                $('#commission').prop('disabled', false);
                                                $('#commission_2').prop('disabled', true);
                                                $('#commission_2').val('0');
                                                $("#taxinfo").html('');
                                                $("#tax_info").val('');
                                        }
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse.account);
                                        $("#account_name").val(reponse.account);
                                        $("#account_currency").val(reponse.devise);
                                        $("#account_balance").val(reponse.balance);
                                }
                        },
                        error:function(error)
                        {
                            alert('ERROR!' + error);
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}

function get_account_balance(data)
{
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
		
        
        var url = '<?php echo base_url($module.'/accounts/data/get_account_balance'); ?>';
        
        $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_compte : devise_compte, balance : balance}, 
                        dataType    : 'html',  
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '200')
                                {
                                        submiter(data);
                                }
                                else if(reponse == '300')
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant pour le paiement de cette note de perception !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(reponse == '405')
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else
                                {
                                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                $("#enregistrer").prop('disabled', false);
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
        });
}
</script>



