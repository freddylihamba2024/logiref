<?php $reset_form = isset($reset) ? $reset : 0;  ?>
<?php 
    if($usd != 0):
        $usd = number_format($usd,4,"."," "); 
    else:
        $usd = ''; 
    endif;

?>
<?php 
    if($eur != 0):
        $eur = number_format($eur,4,"."," ");
    else:
        $eur = ''; 
    endif;
?>

<div class="content">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <div id="loader"></div>
        <h1><?php echo 'Taux de change d\'achat'; ?></h1>
        <p class="page-header">
           Publier un nouveau taux
        </p>   
        <?php $this->chtml->box_body_opening("", true);?>
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <div class="box-body">
                    <div class="col-md-8">
                        <div class="input-group">
                            <span class="input-group-addon"><label for="usd">Taux d'achat USD</label></span>
                            <?php echo form_input('usd', set_value('usd', $usd), 'class="form-control" placeholder= "0.0000" required="required" id="usd" maxlength="86"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon"><label for="eur">Taux d'achat EUROS</label></span>
                            <?php echo form_input('eur', set_value('eur', $eur), 'class="form-control" placeholder= "0.0000" required="required" id="euro" maxlength="86"'); ?>
                        </div>
                    </div>
                    <div class="col-md-4"> 
                        <div id="msg">
                            <?php echo $msg; ?>
                        </div>
                        <input type='hidden' value='<?php echo $is_checker; ?>' name='is_checker' />
                        <input type='hidden' value='<?php echo $action; ?>' name='action' />
                        <input type='hidden' value='' name='id_taux' id="id_taux" />
                    </div>  
                </div>
            <?php if($action != ''){ ?>
            <div id="continue" class="box-footer clearfix">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php echo $action; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
            <?php } ?>
            <?php echo form_close(); ?>
        <?php $this->chtml->box_body_closing(); ?> 	  
    </div>
    <div class="col-md-3">
        <a id="cancel" class="btn btn-app no-border pull_left" href=""><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div> 
</div>
<script type="text/javascript">
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/rates/save/'); ?>/taux/<?php echo $id; ?>';
        var data = $(this).serialize();
        var cid = "<?= isset($id) ? $id : $reset_form; ?>";
        
        var session = "<?= isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : 0; ?>";
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    result = JSON.parse(result);
                    
                    $('#id_taux').val(result.id);
                    $('#loader').html('');
                    $('#loader').html(result.msg);
                    
                    if(session == "3")
                    {
                        $('#msg').html('');
                    }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

</script>


                
               
                
            
             