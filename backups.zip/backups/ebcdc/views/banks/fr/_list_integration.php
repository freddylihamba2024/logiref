<div class="col-md-12" style="height:200px; overflow: auto;">

<table id="table" class="table table-hover table-striped">
    <thead>
        <tr class="bg-gray">
            <th></th>
            <th>Date</th>
            <th>Client</th>
            <th>Direction</th>
            <th>Service</th>
            <th>Montant</th>
            <th>Erreur d'int&eacute;gration</th>
            <th class="text-center"><span class="fa fa-fw fa-check-square f14"></span></th>
        </tr>
    </thead>
    <tbody>
    <?php 

    foreach($encaissements as $row){
    ?>
        <tr>
            <td width="5"><b><?php echo ++$i; ?></b></span></td>
            <td width="50" <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
            <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span class="text-gray"><?php echo $row->Nif_13; ?></span></td>
            <td width="50"><b><?php echo $regie = $regies['Regies'][$row->Beneficaire_15]; ?></b></td>                      
            <td><b><?php echo $beneficiaires[$row->Service_16]; ?></b></td>
            <td class="text-blue">
                <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?>
                <input type='hidden' value='<?php echo $row->Montant_11; ?>' name="total[]" id="t<?php echo $row->Id_0; ?>" />
                <input type='hidden' value='<?php echo $row->Devise_12; ?>' name="devise_integration[]" id="d<?php echo $row->Id_0; ?>" />
            </td>
            <td>
                <span class='text-green'>
                <?php
                if($row->Isyserrors_47 =="200")
                {
                    echo "Aucune erreur, int&eacute;gration faite avec succ&eacute;s";
                
                
                ?>
                </span>
                <span class="text-red">
                <?php
                }
                elseif($row->Isyserrors_47 =="" ||  $row->Isyserrors_47 ==NULL) 
                {
                    echo '<span class="text-red">';
                    echo "Isys n\'est pas disponible, v&eacute;uillez r&eacute;essayer l\'int&eacute;gration s\'il vous pla&icirc;t";
                    echo '</span>';
                }
                else
                {
                    echo '<span class="text-red">';
                    echo $row->Isyserrors_47;
                    echo '</span>';
                }
                
                ?>
                </span>
            </td>
            <td width="25" class="text-center" id="tt<?php echo $row->Id_0; ?>">

                <?php 
                if ($row->Isyserrors_47 =="200")
                {
                ?>
                <input id="<?php echo $row->Id_0; ?>" type="checkbox" value="<?php echo $row->Id_0; ?>" data-id-paiement="<?php echo $row->Id_0; ?>" class="check" name="ids[]" onchange="calculate('<?php echo $row->Id_0; ?>');" /> 
                <?php

                }elseif($row->Isyserrors_47 =="" || $row->Isyserrors_47 ==NULL)
                {
                ?>
                <a id="<?php echo $row->Id_0; ?>" class="btn btn-warning btn-xs integrate" href="#" data-btnid="<?php echo $row->Id_0; ?>" class="text-green"> R&eacute;int&eacute;grer </a>
                <?php

                }else
                {
                ?>
                <a id="<?php echo $row->Id_0; ?>" class="btn btn-warning btn-xs integrate" href="#" data-btnid="<?php echo $row->Id_0; ?>" class="text-green"> R&eacute;int&eacute;grer </a>
                <?php
                }
                ?>
            </td>
        </tr>
        <?php $Infos = json_decode($row->Notereference_30, true); ?>
        <input type='hidden' id="numero_Releve_Paiement<?php echo $row->Id_0; ?>"  value='<?php echo round(2,9999).mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$i; ?>' disabled="disabled" name="numero_Releve_Paiement[]" />
        <input type='hidden' id="numero_Titre_De_Perception<?php echo $row->Id_0; ?>" value='<?php echo $row->Noteid_26; ?>' disabled="disabled" name="numero_Titre_De_Perception[]" />
        <input type='hidden' id="numero_Impot<?php echo $row->Id_0; ?>" value='<?php echo $row->Nif_13; ?>' disabled="disabled" name="numero_Impot[]" />
        <input type='hidden' id="designation_Contribuable<?php echo $row->Id_0; ?>" value='<?php echo $row->Designation_14; ?>' disabled="disabled" name="designation_Contribuable[]" />
        <?php if(isset($Infos['year'])){ ?><input type='hidden' value='<?php echo $Infos['year']; ?>' id="periode_Paiement<?php echo $row->Id_0; ?>" disabled="disabled" name="periode_Paiement[]" /><?php } else{ ?><input type='hidden' value='<?php echo ''; ?>' id="periode_Paiement<?php echo $row->Id_0; ?>" name="periode_Paiement" /><?php } ?>
        <input type='hidden' id="montant_Note<?php echo $row->Id_0; ?>" value='<?php echo $row->Notemontant_28; ?>' disabled="disabled" name="montant_Note[]" />
        <input type='hidden' id="date_Note<?php echo $row->Id_0; ?>" value='<?php echo $row->Notedate_27; ?>' disabled="disabled" name="date_Note[]" />
        <input type='hidden' id="devise<?php echo $row->Id_0; ?>" value='<?php echo $row->Devise_12; ?>' disabled="disabled" name="devise[]" />
        <input type='hidden' id="regie<?php echo $row->Id_0; ?>" value='<?php echo $row->Beneficaire_15; ?>' disabled="disabled" name="regie[]" />
        <input type='hidden' id="numero_Paiement<?php echo $row->Id_0; ?>" value='<?php echo $row->Logirefid_4; ?>' disabled="disabled" name="numero_Paiement[]" />
        <input type='hidden' id="montant_Paiement<?php echo $row->Id_0; ?>" value='<?php echo $row->Montant_11; ?>' disabled="disabled" name="montant_Paiement[]" />
        <input type='hidden' id="date_De_Paiement<?php echo $row->Id_0; ?>" value='<?php echo $row->Datevaleur_31; ?>' disabled="disabled" name="date_De_Paiement[]" />
        <input type='hidden' id="numero_Quittance<?php echo $row->Id_0; ?>" value='<?php echo $row->Noteid_26; ?>' disabled="disabled" name="numero_Quittance[]" />
        <input type='hidden' id="code_Service_Recouvrement<?php echo $row->Id_0; ?>" value='<?php echo $row->Service_16; ?>' disabled="disabled" name="code_Service_Recouvrement[]" />
        <input type='hidden' id="code_Type_Recette_Etat<?php echo $row->Id_0; ?>" value='<?php echo $row->Typerecette_17; ?>' disabled="disabled" name="code_Type_Recette_Etat[]" />
        <input type='hidden' id="id_paiement<?php echo $row->Id_0; ?>" value='<?php echo $row->Id_0; ?>' disabled="disabled" name="id_paiement[]" />
    <?php 

    } 
    ?>
    </tbody>    
</table>
</div>

