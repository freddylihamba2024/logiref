<div class="row bBottom style_topper1">
    <div class="col-md-12">
        <div class="col-md-5 pull-left">
            <ul class="nav navbar-nav">
                <li><a id="Add" class="f14" href="<?php echo base_url('logiref'); ?>"> <span class="fa fa-home f18 text-blue"></span> &nbsp; Tableau de bord</a></li>
            </ul>
        </div>
        <div class="col-md-7 pull-right">
            <ul class="nav navbar-nav pull-right">
                <li><a class="f14 bRight" id="rapport_syntheses"  style="cursor: pointer;"> <i class="fa fa-fw text-green fa-folder f14"></i> R&eacute;sum&eacute;s</a></li>
                <li class="dropdown">
                        <a class="f14 bRight" id="rapport_detailles" style="cursor: pointer; background-color:rgba(0,0,0,0.04);" class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> 
                            <i class="fa fa-file-text-o" ></i> Relev&eacute;s<i class="caret text-green"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li role="presentation"><a id="all" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-filter"></i> Tous les paiements</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="dgi" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-minus"></i> Paiements DGI</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="dgda" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-minus"></i>Paiements DGDA</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="dgrad" role="menuitem" tabindex="-1" href="#"><i class="fa fa-minus"></i>Paiements DGRAD</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="dgrad" role="menuitem" tabindex="-1" href="#"><i class="fa fa-minus"></i>Autres paiements</a></li>
                        </ul>
                </li>
                <li class="dropdown">
                        <a class="f14 bRight" id="integration" style="cursor: pointer;" class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> 
                            <i class="fa fa-files-o" ></i> Int&eacute;grations<i class="caret text-green"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li role="presentation"><a id="cbs" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-minus"></i> Int&eacute;grations CBS</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="isys" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-minus"></i> Reversements ISYS-R&eacute;gies</a></li>
                            <li role="presentation" class="divider"></li>
                            <li role="presentation"><a id="rtgs" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-minus"></i>Int&eacute;grations RTGS/ATS</a></li>
                        </ul>
                </li>
                <li class="dropdown">
                    <a class="f14" class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> 
                        <i class="fa fa-print text-blue f20"></i><i class="caret text-green"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li role="presentation"><a id="d-excel" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-file-excel-o f18 text-green"></i> Fichier MS Excel</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a id="d-pdf" class="pdf" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-file-pdf-o f18 text-red"></i>Fichier PDF</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a id="d-csv" role="menuitem" tabindex="-1" href="#"><i class="fa fa-html5 f18 text-blue"></i>Fichier CSV</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>


<div class="col-md-1"></div>

<div class="col-md-10">
    <div id="loader" class="col-md-12 no-padding"></div>
        <div id="pager">
        </div>
</div>
<div class="col-md-1"></div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    
    
    
    pager('rapport_syntheses');
    
    $("#d-excel").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Fonctionnalit&eacute; pas encore disponible!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    });
    
    
    $("#d-pdf").click(function(){
        
            if(object=='synthese')
            {
               printpdf('synthese'); 
            }
            
    });
    
    $("#d-csv").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#loader").html('<div class="alert alert-warning text-white">Fonctionnalit&eacute; pas encore disponible!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    });
    
    var from = '<?= isset($from) ? $from : "" ?>';
    if(from=='rapport_detailles')
    {
            $("#dgi").click(function(){
                content('rapport_detailles', 'dgi')
            });
            $("#dgda").click(function(){
                content('rapport_detailles', 'dgda')
            });
            $("#dgrad").click(function(){
                content('rapport_detailles', 'dgrad')
            });
            $("#all").click(function(){
                content('rapport_detailles', "")
            });
    }
    else
    {
            $("#dgi").click(function(){
                pager('rapport_detailles', 'dgi')
            });
            $("#dgda").click(function(){
                pager('rapport_detailles', 'dgda')
            });
            $("#dgrad").click(function(){
                pager('rapport_detailles', 'dgrad')
            });
            $("#all").click(function(){
                pager('rapport_detailles', "")
            });
            
    }
    
    $("#rapport_syntheses").click(function(){
        pager('rapport_syntheses')
    });
    $("#cbs").click(function(){
        pager('integration_cbs')
    });
    $("#isys").click(function(){
        pager('integration_isys')
    });
    $("#rtgs").click(function(){
        pager('integration_rtgs')
    });
    
    function content(menu,regie) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display'); ?>/' + menu+'/'+regie;
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#content").html(data);
            if(menu=='rapport_syntheses')
            {
                $("#rapport_syntheses").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_detailles").css('background-color', '');
            }
            else
            {
                $("#rapport_detailles").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_syntheses").css('background-color', '');
            }
            
        }); 
    }
    var object = "";
    function pager(menu,regie) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display'); ?>/' + menu+'/'+regie;
        $.get(url, {object:menu}, function(data, status){
            $("#loader").html('');
            $("#pager").html(data);
            if(menu=='rapport_syntheses')
            {
                $("#rapport_syntheses").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_detailles").css('background-color', '');
                $("#integration").css('background-color', '');
                object = "synthese";
            }
            else if(menu=='integration_cbs')
            {
                $("#integration").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_detailles").css('background-color', '');
                $("#rapport_syntheses").css('background-color', '');
            }
            else if(menu=='integration_isys')
            {
                $("#integration").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_detailles").css('background-color', '');
                $("#rapport_syntheses").css('background-color', '');
            }
            else if(menu=='integration_rtgs')
            {
                $("#integration").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_detailles").css('background-color', '');
                $("#rapport_syntheses").css('background-color', '');
            }
            else
            {
                $("#rapport_detailles").css('background-color', 'rgba(0,0,0,0.04)');
                $("#rapport_syntheses").css('background-color', '');
                $("#integration").css('background-color', '');
                object = "details";
            }
            
        }); 
    }
    
    
        function printpdf (object)
        {
            if(object=='synthese')
            {
                var url = '<?php echo base_url($module.'/bank/data/print_rapport'); ?>/'+object;
                //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
                // window.print();
                var w = window.open(url);
                $('#loader').removeClass('hidden');
                $("#loader").html('');
            }
        }
    

    
</script>