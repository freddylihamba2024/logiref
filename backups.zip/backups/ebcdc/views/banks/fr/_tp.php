<div class="row bBottom style_topper1">
    <div class="col-md-12">
        <div class="col-md-5 pull-left">
            <ul class="nav navbar-nav">
                <li><a id="Add" class="f14" href="<?php echo base_url('logiref'); ?>"> <span class="fa fa-home f18 text-blue"></span> &nbsp; Tableau de bord</a></li>
            </ul>
        </div>
        <div class="col-md-7 pull-right">
            <ul class="nav navbar-nav pull-right">
                <li class="dropdown">
                    <a class="f14" class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"> 
                        <i class="fa fa-download f14 text-blue"></i> T&eacute;l&eacute;charger <i class="caret text-green"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li role="presentation"><a id="d-excel" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-file-excel-o f18 text-green"></i> Fichier MS Excel</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a id="d-pdf" role="menuitem" tabindex="-1" href="#"><i class="fa  fa-file-pdf-o f18 text-red"></i>Fichier PDF</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a id="d-csv" role="menuitem" tabindex="-1" href="#"><i class="fa fa-html5 f18 text-blue"></i>Fichier CSV</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<div id="pager" class="content">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
            <div class="col-md-12">
                <div id="loader"></div>
                <h2 class="text-blue" ><?php echo " Trouvez une d&eacute;claration."; ?></h2>
                <p class="page-header"></p>
                <?php $this->chtml->box_body_opening("", true);?>  
                <div class="col-md-4">
                    <div id="approvalWarning" style="color:#F00"></div><br/>
                    <p>
                        Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de cette d&eacute;claration!
                    </p>
                    <br/><br/>
                </div>
                <div class="col-md-8 bLeft">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="type">Num&eacute;ro de la d&eacute;claration</label>
                              <?php echo form_input('Reference_32','', 'class="form-control"  id="Reference_32"'); ?>
                        </div>
                    </div>
                    <div class=" clearfix">
                        <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary pull-right margin"><i class="fa fa-send"></i> Suivant </button>&nbsp;
                    </div>
                </div>
            </div>
            <?php $this->chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>  
    </div>
    <div class="col-md-2"></div>
</div>
<script type="text/javascript">
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var ref = $('#Reference_32').val();
        if(ref != ""&& ref != null)
        {
            next_step(ref);
        }
        else
        {
                $("#loader").html('<div class="alert alert-warning"> Merci de vouloir s&eacute;l&eacute;ctioner un type de d&eacute;claration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
});

function next_step(ref)
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                var url = '<?php echo base_url($module.'/bank/display/tp'); ?>';
                $.get(url, {Reference_32:ref}, function(data, status){
                $("#loader").html('');
                if(data == 401)
                {
                   $("#loader").html('<div class="alert alert-warning"> D&eacute;sol&eacute;... Aucune information trouv&eacute;e pour cette r&eacute;f&eacute;rence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                        $("#pager").html(data);
                }
               
            });
        }
</script>