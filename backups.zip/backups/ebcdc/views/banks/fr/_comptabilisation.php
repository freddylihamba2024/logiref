<?php if(!empty($lines)): ?>
      <table id="table" class="table table-hover table-striped">
          <thead>
              <tr class="bg-gray">
                  <th width="8%">Id</th>
                  <th width="8%">Sens</th>
                  <th>Compte</th>
                  <th>Montant</th>
                  <th>Designation</th>
                  <th width="10%">Date</th>
              </tr>
          </thead>
          <tbody>
          <?php 
          foreach($lines as $row){
          ?>
              <tr class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>">
                  <td width="8%"><?php echo $row->Id_0; ?></td>
                  <td width="8%"><?php echo $row->Operation_8; ?></td>
                  <td><?php echo $row->Compte_9; ?></td>
                  <td><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                  <td><?php echo $row->Libelle_12; ?></td>
                  <td width="10%"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_13)); ?></td>
              </tr>
          <?php } ?>
          </tbody>    
      </table>
<?php endif;?>