    <?php if(!empty($encaissements)): ?>
        <div class="bTop title"><h4>Liste des paiements</h4></div>
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-gray">
                    <th></th>
                    <th>Date</th>
                    <th>Client</th>
                    <th>Direction</th>
                    <th>Service</th>
                    <th>Montant</th>
                    <th>Recette</th>
                    <th>Guichet</th>
                    <th><span class="fa fa-fw fa-check-square f14"></span></th>
                </tr>
            </thead>
            <tbody>
            <?php 
            $paiements = 0;
            $commissions = 0;
            $suspend = 0;
            $urgent = 0;
            foreach($encaissements as $row){
            ?>
                <tr>
                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                    <td width="50" <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
                    <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span class="text-gray"><?php echo $row->Nif_13; ?></span></td>
                    <td width="50"><b><?php echo $regie = $regies['Regies'][$row->Beneficaire_15]; ?></b></td>                      
                    <td><b><?php echo $beneficiaires[$row->Service_16]; ?></b></td>
                    <td class="text-blue">
                        <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?>
                        <input type='hidden' value='<?php echo $row->Montant_11; ?>' name="total[]" id="t<?php echo $row->Id_0;?>" />
                    </td>
                    <td><?php echo $recettes[$regie][$row->Typerecette_17]; ?></td>
                    <td><?php echo '<span  class="text-blue">'.$guichets[$row->Guichet_21].'<br/><span  class="text-gray"> '.$users[$row->Makerid_9].'</span>'; ?></td>

                    <td width="25">
                        <input id="<?php echo $row->Id_0; ?>" type="checkbox" value="<?php echo $row->Id_0; ?>" name="ids[]" onchange="calculate('<?php echo $row->Id_0; ?>');" /> 
                    </td>
                </tr>
            <?php 
                  $paiements = $paiements + $row->Contrevaleur_22;
                  $commissions = $commissions + $row->Commission_23;
                  if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                  if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
            } 
            ?>
            </tbody>    
        </table>
    <?php else: ?>
          <div class="bg-yellow" style="padding:10px;"><h4>Aucun paiement trouv&eacute;</h4></div>
    <?php endif;?>