<style>
   .img
   {
        width: 80px;
        height: 75px;
        margin-left: 30px
    }
  
</style>

<div style="width: 100%; height: 100%;border: 1px solid black;">
    
    <table style="margin-left:8px;">
        <tr>
            <td style="width:950px; font-size:1.1em;">
                <b>STANDARD BANK CONGO</b><br/>KINSHASA
            </td>
            <td style="width:200px; font-size:1.1em;">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo base_url('ikwook_files'); ?>/logos/36/Standard_Bank_Logo.png" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Standard Bank
            </td>
        </tr>
    </table>
    <p style="font-size:1.0em; margin-left:8px; margin-top:-15px;">Date: <?php echo gmdate('d/m/Y'); ?></p>
    <br/>
    <p align="center" style="font-weight:bold; font-size:1.0em; text-decoration:underline;">SYNTHESE DES PAIEMENTS</p>
    
    <table style="border-collapse: collapse; border: 1px solid black; margin-left:30px; margin-right:30px;" width="100%" cellspace="8" cellpadding="8">
        <tr>
            <td width="19.8%" rowspan="6" style="border: 1px solid black; text-align: center;"><code>Journalier</code></td>
            <td width="5%" style="border-bottom:1px solid black;" colspan="1"></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en USD</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en CDF</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Commission</code></td>
            <td width="15%" style="border-bottom:1px solid black;"><code>TVA</code></td>
        </tr>
        <tr>
            <td><code>DGI</code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgi_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgi_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgi_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgi_day'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td><code>DGDA</code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgda_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgda_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgda_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgda_day'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td><code>DGRAD</code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgrad_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgrad_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgrad_day'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgrad_day'],2,","," "); else echo 0;?></code></td>
        </tr>
        
    </table>
    <table style="border-collapse: collapse; border: 1px solid black; border-top: none; margin-left:30px; margin-right:30px;" width="100%" cellspace="8" cellpadding="8">
        <tr>
            <td width="20%" rowspan="6" style="border: 1px solid black; border-top: none; text-align: center;"><code>Mensuel</code></td>
            <td width="5%" style="border-bottom:1px solid black;" colspan="1"></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en USD</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en CDF</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Commission</code></td>
            <td width="15%" style="border-bottom:1px solid black;"><code>TVA</code></td>
        </tr>
        <tr>
            <td>DGI</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgi_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgi_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgi_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgi_month'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td>DGDA</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgda_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgda_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgda_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgda_month'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td>DGRAD</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgrad_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgrad_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgrad_month'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgrad_month'],2,","," "); else echo 0;?></code></td>
        </tr>
        
    </table>
    <table style="border-collapse: collapse; border: 1px solid black; border-top: none; margin-left:30px; margin-right:30px;" width="100%" cellspace="8" cellpadding="8">
        <tr>
            <td width="20%" rowspan="6" style="border: 1px solid black; border-top: none; text-align: center;"><code>Annuel</code></td>
            <td width="5%" style="border-bottom:1px solid black;" colspan="1"></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en USD</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Paiement en CDF</code></td>
            <td width="20%" style="border-bottom:1px solid black;"><code>Commission</code></td>
            <td width="15%" style="border-bottom:1px solid black;"><code>TVA</code></td>
        </tr>
        <tr>
            <td>DGI</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgi_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgi_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgi_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgi_year'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td>DGDA</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgda_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgda_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgda_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgda_year'],2,","," "); else echo 0;?></code></td>
        </tr>
        <tr>
            <td>DGRAD</td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['payusd_dgrad_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'USD '.number_format($data['paycdf_dgrad_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['commission_dgrad_year'],2,","," "); else echo 0;?></code></td>
            <td><code><?php if(isset($data)) echo 'CDF '.number_format($data['tva_dgrad_year'],2,","," "); else echo 0;?></code></td>
        </tr>
        
    </table>
    <br/><br/>
    <table>
        <tr>
            <td width="80%"></td>
            <td>Fait &agrave; Kinshasa le <?php echo gmdate('d/m/Y'); ?></td>
        </tr>
    </table>
    
</div>

