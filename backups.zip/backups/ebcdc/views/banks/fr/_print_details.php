<style>
   .img
   {
        width: 80px;
        height: 75px;
        margin-left: 30px
    }
  
</style>

<div style="width: 100%; height: 100%;border: 1px solid black;">
    <table style="margin-left:8px;">
        <tr>
            <td style="width:950px; font-size:1.1em;">
                <b>STANDARD BANK CONGO</b><br/>KINSHASA
            </td>
            <td style="width:200px; font-size:1.1em;">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo base_url('ikwook_files'); ?>/logos/36/Standard_Bank_Logo.png" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Standard Bank
            </td>
        </tr>
    </table>
    
    <p align="center" style="font-weight:bold; font-size:1.0em; text-decoration:underline;">RELEVE DES ENCAISSEMENTS</p>
    <p align="center" style="font-weight:bold; font-size:0.9em;">P&eacute;riode : <?php echo "du ".$start." au ".$end; ?></p>
    <table style="border-collapse: collapse; border: 1px solid black; margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="3">
        <tr>
            <td style="border-bottom:1px solid black;">Ref&eacute;rence</td>
            <td style="border-bottom:1px solid black;">Client</td>
            <td style="border-bottom:1px solid black;">B&eacute;n&eacute;ficiaire</td>
            <td style="border-bottom:1px solid black;">Recettes</td>
            <td style="border-bottom:1px solid black;">Montant pay&eacute;</td>
            <td style="border-bottom:1px solid black;">Contre-valeur</td>
            <td style="border-bottom:1px solid black;">Commissions</td>
            <td style="border-bottom:1px solid black;">Guichet</td>
        </tr>
        <?php 
        
            foreach($data as $row)
            {
        ?>
                <tr>
                    <td><b><?php echo $row->Logirefid_4; ?></b></td>
                    <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span style="color:gray;"><?php echo $row->Nif_13; ?></span></td>
                    <td><b><?php echo $beneficiaires[$row->Service_16]; ?></b></td>
                    <td><?php echo $row->Typerecette_17; ?></td>
                    <td><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?></td>
                    <td><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></td>
                    <td ><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                    <td><?php echo $guichets[$row->Guichet_21].'<br/><span  style="color:gray;"> '.$users[$row->Makerid_9].'</span>'; ?></td>
                </tr>
        <?php 
        
            }
        ?>
    </table>
</div>