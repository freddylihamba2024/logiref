<div class="col-md-1"></div> 
<div class="col-md-10">
    <div id="message"></div>
    <h1>Editer un reversement</h1>
    <p class="page-header">
        G&eacute;rer les informations du reversement.
    </p>
    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => 'innovate')); ?>
    <?php $this->chtml->box_body_opening('', true); ?>
    <div class="box-body">
        <div class="col-md-12 no-padding">
            <div class="col-md-4 text-center border-right">
                    <p class="f15 text-blue" id="regie"><b><?php echo $regies['Regies'][$integration->Beneficiaire_10]; ?></b></p>
                    <span class=" f14 text-yellow"><?php echo $integration->Nombrepaiement_22.' paiemet(s)' ?></span>
            </div>
            <div class="col-md-8 text-center " style="margin-top:16px;">
                <span class="f15 text-yellow"><?php echo $integration->Devise_9.' '.number_format($integration->Montant_8,2,","," "); ?></span>
            </div>
        </div>
        <br/><br/>
        <div class="col-md-12 no-padding bTop" style="margin-top:15px;">

            <div class="col-md-6">
                <p class="page-header"> Envois</p><br/>
                <input type="hidden" name="Id_0" value="<?php echo $integration->Id_0; ?>" />
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Banqueid_5"><div>R&eacute;f&eacute;rence Banque</div></label> 
                    </span>
                    <?php echo form_input('Banqueid_5', set_value('Banqueid_5', $integration->Banqueid_5), ' class="form-control" id="banqueid" disabled="disabled"'); ?>
                </div>
                <div class="form-group">
                    <label for="Description_6">Description</label>
                    <?php echo form_textarea(array('name' => 'Description_6', 'cols' => 40, 'rows' => 2), set_value('Description_6', $integration->Description_6), 'id="comment" class="form-control" maxlength="761" disabled="disabled"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for=""><div >Banque</div></label> 
                    </span>
                    <?php echo form_input('', $_SESSION['account_business'], ' class="form-control" id="" disabled="disabled"'); ?>
                </div>
            </div>
            <div class="col-md-6 bLeft">
                <p class="page-header">Retour</p><br/>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_isys_17"><div >R&eacute;f&eacute;rence isys</div></label> 
                    </span>
                    <?php echo form_input('Reference_isys_17', $integration->Reference_isys_17, ' class="form-control" id="retourIsys" '); ?>
                </div>
                <div class="form-group">
                    <label for="Retourdetails_19">Description</label>
                    <?php echo form_textarea(array('name' => 'Retourdetails_19', '', 'cols' => 40, 'rows' => 2), set_value('Retourdetails_19', $integration->Retourdetails_19), 'id="descriptionIsys" class="form-control" maxlength="761" '); ?>
                </div>
            </div>
        </div>
       
    </div>
    <div class="box-footer clearfix">
        <div class="col-md-12">
            <button  href = "#step-1" type="submit" class="btn btn-success" id="confirmer"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <a  href="<?php echo base_url('logiref/bank/data/export_isys');?>" class="btn btn-primary" id="upload"><i class="fa fa-file-excel-o" style="color:white;"></i>&nbsp;&nbsp;T&eacute;l&eacute;charger&nbsp;&nbsp;</a>&nbsp;
        </div>
    </div>
    <?php $this->chtml->box_body_closing(); ?>
    <?php echo form_close(); ?>
    
</div>
<div class="col-md-1">
    <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
</div>

<script>

    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        
        var url = '<?php echo base_url($module.'/bank/save/integration_isys'); ?>';
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(loader){
                    
                    if(loader=='100'){
                        $('#message').html('<div class="alert alert-success text-white">Bravo! Reversement enregistr&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        
                    }else if(loader=='303'){
                        $('#message').html('<div class="alert alert-warning text-white">Avertissement! Impossible de reverser ces paiement... une erreur s\'est produite.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    $("#cancel").click(function(){
        closeModal();
    });

    function closeModal(){
        $.get("<?php echo base_url($module.'/bank/display/isys'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }

</script>

