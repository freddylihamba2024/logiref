<?php 

$userid = $this->session->userdata("user_id");
$usertype = $this->session->userdata("user_type");
$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>

<div id="pager"  class="col-md-12"> 
    
    <div class="col-md-12">
            <h1>Retard de reversement </h1>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements non revers&eacute;s avant la dur&eacute; fix&eacute;e.</span></h5>
    </div>
    
    <div class="col-md-12">
        <div  id="loader"></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <?php $this->chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($encaissements)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Service</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th>Guichet</th>
                                <th>Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php  foreach($encaissements as $row){ 
                            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr>
                                <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                <td width="50" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                <td><?php echo $beneficiaires[$row->Service_16]; ?></td>
                                <td><?php echo $row->Typerecette_17; ?></td>
                                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                      <br/>
                                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                    <?php endif;?>
                                </td>
                                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                <td><?php echo '<span  class="text-blue">'.$guichet.'</span>'; ?></td>
                                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                           <input type="checkbox" class="text-blue" id='' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')){ ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                        <?php }else { ?>
                                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                        <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                <?php }else{ ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php 
                              $paiements = $paiements + $row->Contrevaleur_22;
                              $commissions = $commissions + $row->Commission_23;
                              if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                              if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
                        } 
                        ?>
                        </tbody>    
                    </table>
                    <?php else: ?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            Aucune penalit&eacute; n'est enregistr&eacute;e !<br/>
                            </div>
                        </section>
                    <?php endif;?>
                </div>
            <?php $this->chtml->box_body_closing(); ?>
        <?php echo form_close(); ?>
    </div>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#attente').html('<?php echo number_format($suspend,2,","," "); ?>');
$('#urgent').html('<?php echo number_format($urgent,2,","," "); ?>');
    
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
});

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank'); ?>/display/validate';
        var data = $(this).serialize();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $("#paiementslist").html(result);
                    $("#loader").html('<div class="alert alert-success text-white">Changements effectues avec succes...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

function filter(type){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/bank/display/encaissements'); ?>/list/" + type, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
      });
}

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/bank/display/encaissement'); ?>/" + id, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
      });
}

function refreshit(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/tax/encaissements'); ?>/va/", function(data, status){
        $("#loader").html('');
        
      });
}

function print_payment(pid)
{
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
}
</script>
