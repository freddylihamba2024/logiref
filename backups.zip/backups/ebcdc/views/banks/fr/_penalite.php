<?php if($penalite->Id_0 > 0) $title='Modifier'; else $title ='Nouvelle r&egrave;gle de p&eacute;nalit&eacute;' ?>

<div class="col-md-2"></div><div class="col-md-2"></div>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<div class="col-md-12">
    <?php $this->chtml->box_modal_opening($title, true);?>
        <div id="loader" class="col-md-12"></div>
        <div class="box-body">
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="value">Indice (montant ou %)</label>
                      <?php echo form_input('value', set_value('value', $penalite->Value_9), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="max">Max</label>
                      <?php echo form_input('max', set_value('max', $penalite->Max_12), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="min">Min</label>
                      <?php echo form_input('min', set_value('min', $penalite->Min_11), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                      <label for="unite">Unit&eacute</label>
                      <?php $unites = array_merge($devises,array('%'=>'Pourcentage')); ?>
                      <?php echo form_dropdown('unite', $unites, $penalite->Unite_10, 'class="form-control" required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="devise">Devise</label>
                      <?php echo form_dropdown('devise', $devises, $penalite->Devise_13, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            
            <div class="col-md-6">
                  <div class="form-group">
                      <label for="beneficiaire">B&eacute;n&eacute;ficiaire</label>
                      <?php echo form_dropdown('beneficiaire', $beneficiaires, $penalite->Beneficiaire_5, ' class="form-control"'); ?>
                      <input name="Id_0" type="hidden" value="<?php echo $penalite->Id_0; ?>" />
                  </div>  
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="service">Service</label>
                      <?php echo form_dropdown('service', $services, $penalite->Service_6, ' class="form-control" required="required"'); ?>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                      <label for="recette">Recette</label>
                      <?php echo form_dropdown('recette', $recettes, $penalite->Recette_7, ' id="Type1" class="form-control"'); ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="guichet">Guichet_8</label>
                      <?php echo form_dropdown('guichet', $guichets, $penalite->Guichet_8, ' id="Type1" class="form-control"'); ?>
                </div>
            </div>
            
           
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
            
        </div>
    <?php $this->chtml->box_body_closing(); ?> 	  
</div>
<?php echo form_close(); ?>



<script type="text/javascript">
 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/settings'); ?>/save/penalite/<?php echo $penalite->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $penalite->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($penalite->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
      $.get("<?php echo base_url($module.'/settings/display'); ?>/penalites/", function(data, status){
            $("#loader").html('');
            $("#fullscreen").html(data);
      });
}
</script>


