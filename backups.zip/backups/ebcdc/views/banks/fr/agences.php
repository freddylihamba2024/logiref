<?php $userid = $this->session->userdata("user_id");?>
<?php $usertype = $this->session->userdata("user_type");?>

<div class="row bBottom style_topper1">
        <div class="col-md-12">
                <div class="col-md-5 pull-left">
                        <ul class="nav navbar-nav">
                            <li><a class="f14" href="<?php echo base_url('logiref'); ?>"> <span class="fa fa-home f18 text-blue"></span> &nbsp; Tableau de bord</a></li>
                        </ul>
                </div>
                <div class="col-md-7 pull-right">
                        <ul class="nav navbar-nav pull-right">
                            <li><a class="f14 bRight" id="add" style="cursor: pointer;"> <i class="fa fa-fw fa-plus-circle f18"></i> Nouvelle..</a></li>
                            <li><a class="f14 bRight pointer" id="help"> <i class="fa fa-fw fa-whatsapp text-green f25"></i></a></li>
                        </ul>
                </div>
        </div>
</div>


<div class="content">
    <div class="col-md-2"></div>

    <div class="col-md-8">
        
        <div id="loader" class="col-md-12"><br/><br/></div>

           <div class="col-md-12">
               <h1><i class="fa fa-book f35 text-green"></i>&nbsp;&nbsp;<span class="text-blue">R&eacute;f&eacute;rentiel des agences</span></h1>
           </div>
            
            <div class="col-md-12">
                    <?php $this->chtml->box_body_opening('', true); ?>
                        <?php if(!empty($agences)): ?>
                             <div class="row pBottom50">
                                   <div class="col-md-12">
                                          <div class="row fontawesome-icon-list">
                                            <?php foreach($agences as $row){ ?>
                                                <div class="col-md-4 col-sm-4">
                                                <span> <i class="fa fa-check-square text-green"></i> <?php echo '<span class="fa text-blue">'.$row->Code_5.'</span> '.$row->Nom_4; ?> </span>
                                                <?php if($row->Account_3!=0 && $usertype==200) {?>
                                                <a style="cursor:pointer" onclick="editCategory('<?php echo $row->Id_0; ?>','<?php echo $row->Nom_4;?>')"><i class="fa fa-edit"></i></a>
                                                &nbsp;&nbsp;&nbsp;
                                                <a style="cursor:pointer" onclick="deleteCategory('<?php echo $row->Id_0; ?>','<?php echo $row->Nom_4;?>')"><span class="fa fa-trash-o text-red"></span></a>
                                                <?php } ?>
                                                </div>
                                            <?php } ?>
                                          </div>
                                   </div>
                             </div>
                        <?php endif;?>
                    <?php $this->chtml->box_body_closing(); ?> 	  
            </div>
    </div>

    <div class="col-md-2"></div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#add").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      
}
</script>
