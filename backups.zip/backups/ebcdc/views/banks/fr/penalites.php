<?php $userid = $this->session->userdata("user_id");?>
<?php $usertype = $this->session->userdata("user_type");?>
   
<div class="row bBottom style_topper1">
        <div class="col-md-12">
                <div class="col-md-5 pull-left">
                        <ul class="nav navbar-nav">
                            <li><a class="f14" href="<?php echo base_url('logiref'); ?>"> <span class="fa fa-home f18 text-blue"></span> &nbsp; Tableau de bord</a></li>
                        </ul>
                </div>
                <div class="col-md-7 pull-right">
                        <ul class="nav navbar-nav pull-right">
                            <li><a class="f14 bRight" id="add" style="cursor: pointer;"> <i class="fa fa-fw fa-plus-circle f18"></i> Nouvelle..</a></li>
                            <li><a class="f14 bRight pointer" id="help"> <i class="fa fa-fw fa-whatsapp text-green f25"></i></a></li>
                        </ul>
                </div>
        </div>
</div>


<div id="pager" class="content">  
    <div class="col-md-1"></div>
    
    <div class="col-md-10">
        <div id="loader" class="col-md-12"></div>

        <div class="col-md-12">
            <h1><i class="fa fa-book f35 text-green"></i>&nbsp;&nbsp;<span class="text-blue">Gestion des R&egrave;gles de p&eacute;nalit&eacute;</span></h1>
            <h5>
                    Ce r&eacute;f&eacute;rentiel des recettes (taxes et autres) est mis &agrave; automatiquement et synchronis&eacute; avec le r&eacute;f&eacute;rentiel de la Banque Central du Congo.
                    <br><br/>
            </h5>
        </div>
        <div class="col-md-12">
            <?php $this->chtml->box_body_opening('', true); ?>
                <?php if(!empty($penalites)): ?>
                      <table id="table" class="table table-hover table-striped">
                          <thead>
                              <tr class="bg-blue">
                                  <th>#</th>
                                  <th>Priorit&eacute;</th>
                                  <th>B&eacute;n&eacute;ficiaire</th>
                                  <th>Indice</th>
                                  <th>Service</th>
                                  <th>Recette</th>
                                  <!--<th>Guichet</th>-->
                                  <th>Min</th>
                                  <th>Max</th>
                                  <!--<th>Validation</th>-->
                                  <th><span class="fa fa-fw fa-edit f14"></span></th>
                              </tr>
                          </thead>
                          <tbody>
                          <?php foreach($penalites as $row){ ?>
                              <tr>
                                  <td width="5"><?php echo $row->Id_0; ?></td>
                                  <td class="bg-red" align="center"><b>P<?php echo $row->Priorite_4; ?></b></td>
                                  <td><?php if($row->Beneficiaire_5=='' or $row->Beneficiaire_5=='0') echo 'TOUS'; else echo ' '.$row->Beneficiaire_5;?></td>
                                  <td class="bleu"><b><?php echo $row->Value_9.' '.$row->Unite_10;?></b></td>
                                  <td><?php if($row->Service_6=='') echo 'TOUS'; else echo ' '.$services[$row->Beneficiaire_5][$row->Service_6];?></td>
                                  <td><?php if($row->Recette_7=='') echo 'TOUTES'; else echo ' '.$row->Recette_7;?></td>
                                  <!--<td><?php //if($row->Guichet_8=='') echo 'TOUS'; else echo ' '.$guichets[$row->Guichet_8];?></td>-->
                                  <td class="bleu"><?php echo $row->Devise_13.' '.$row->Min_11;?></td>
                                  <td class="bleu"><?php echo $row->Devise_13.' '.$row->Max_12;?></td>
                                  <!--<td>
                                      <!--<?php //if($row->Checkerid_15==0){ ?>
                                        <span class="text-red"> En attente </span>
                                      <?php //}else {?>
                                        <?php //echo $row->Validation_16;?>
                                      <?php //} ?>-->
                                  <!--</td>-->
                                  <td width="25" align="right">
                                      <?php //if($_SESSION['Logiref_role']!=1 || $_SESSION['Logiref_role']==2){ ?>
                                      <?php if($_SESSION['Logiref_role']==0){ ?>
                                      <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                      <?php }else {?>
                                      <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                      <?php } ?>
                                  </td>
                              </tr>
                          <?php } ?>
                          </tbody>    
                      </table>
                <?php else: ?>
                    <section id="cat_list">
                        <div class="row fontawesome-icon-list  f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-yellow mystyle4"></i><br/>
                        Aucune r&egrave;gle n'est enregistr&eacute;e!<br/>
                        </div>
                    </section>
                <?php endif;?>
            <?php $this->chtml->box_body_closing(); ?>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>    

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

//Add a member
$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        <?php if($_SESSION['Logiref_role']!=1){ ?>
    $.get("<?php echo base_url($module.'/settings/display/penalite'); ?>", function(data, status) {
        $("#loader").html('');
        $("#pager").html(data);
    });
    <?php }else { ?>
        $("#loader").html('<div class="alert alert-warning text-white">D&eacute;sol&eacute! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    <?php } ?>  
});

$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/settings/display/penalite'); ?>/' + id ;
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#fullscreen").html(data);
      });
}
</script>


