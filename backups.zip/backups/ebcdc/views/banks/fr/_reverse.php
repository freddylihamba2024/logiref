<?php 

    if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates']!==0)
    {
        $bank = json_decode($_SESSION['Bank_rates'], true);
        $usd = $bank['Dollar_4'];
        $eur = $bank['Euro_5'];
        $rand = $bank['Rand_6'];
        $pound = $bank['Pound_7'];
    }

?>
<div>
    <div class="col-md-1"></div>

    <div class="col-md-10 no-padding">
        <div id="message"></div>
        <div class="col-md-12">
            <h2 class="text-blue" ><?php echo " Reversement des paiements"; ?></h2>
        <p class="page-header"></p>
        </div>
        <div class="col-md-12">
            <div class="col-md-2">
                <div id="step-1" title="" class="bRound <?php if($id !="") echo "bg-gray"; else echo "bg-green"; ?> f18 center pull-right">1</div>
            </div>
            <div class="col-md-4">
                <div class="pull-left">Int&eacute;gration<br/></div>
            </div>
            <div class="col-md-2">
                <div id="step-2" title="" class="bRound <?php if($id !="") echo "bg-green"; else echo "bg-gray"; ?> f18 center pull-right">2</div>
            </div>
            <div class="col-md-4">
                <div class="pull-left">Validation<br/></div>
            </div>
        </div>
        <div class="col-md-12"><br/></div>
        <?php if($id ==""){ ?>
        <div class="col-md-12" id="bloc-1" >
            <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => '')); ?>
            <?php $this->chtml->box_body_opening('', true);?>

                <div class="col-md-3 border-right text-center">
                        <p class="f14"><b>Nombre total</b></p>
                        <span class=" f14" id="total" >0</span>
                </div>
                <div class="col-md-3 border-right text-center">
                        <p class="f14"><b>Montant total</b></p>
                        <span class=" f14" id="budget" ></span>
                </div>
                <div class="col-md-3 border-right text-center">
                        <p class="f14"  ><b>CDF</b></p>
                        <span class=" f14" id="budget_cdf" ></span>
                </div>
                <div class="col-md-3 text-center">

                        <p class="f14" ><b>USD</b></p>
                        <span class=" f14" id="budget_usd" ></span>
                </div>

            <?php $this->chtml->box_body_closing(); ?>
            

            <?php $this->chtml->box_body_opening('', true);?>


                    <div class="col-md-4"><h4>&nbsp;&nbsp;Liste des paiements</h4></div>
                    <div class="form-group col-md-8">   

                    </div>
                    <?php if(!empty($encaissements)): ?>
                    <div id="content">
                        <div class="box-body" id="pager">
                            <div class="col-md-12" style="height:200px; overflow: auto;">

                            <table id="table" class="table table-hover table-striped">
                                <thead>
                                    <tr class="bg-gray">
                                        <th></th>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>Direction</th>
                                        <th>Montant</th>
                                        <th>Erreur d'int&eacute;gration</th>
                                        <th class="text-center"><span class="fa fa-fw fa-check-square f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 

                                foreach($encaissements as $row){
                                ?>
                                    <tr>
                                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                        <td width="50" <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
                                        <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span class="text-gray"><?php echo $row->Nif_13; ?></span></td>
                                        <td width="50"><b><?php echo $regie = isset($regies['Regies'][$row->Beneficaire_15]) ? $regies['Regies'][$row->Beneficaire_15]: ''; ?></b></td>                      
                                        <td class="text-blue" width="100">
                                            <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?>
                                            <input type='hidden' value='<?php echo $row->Montant_11; ?>' name="total[]" id="t<?php echo $row->Id_0; ?>" />
                                            <input type='hidden' value='<?php echo $row->Devise_12; ?>' name="devise_integration[]" id="d<?php echo $row->Id_0; ?>" />
                                        </td>
                                        <td>
                                            <span class="text-green">
                                            <?php
                                            if($row->Isyserrors_47=="200")
                                            {
                                                echo "Aucune erreur, int&eacute;gration faite avec succ&eacute;s";

                                            ?>
                                            </span>

                                            <?php
                                            }
                                            elseif($row->Isyserrors_47 =="" ||  $row->Isyserrors_47 ==NULL) 
                                            {
                                            ?>
                                            <span class="text-red">  
                                            <?php
                                                echo "Isys n'est pas disponible, v&eacute;uillez r&eacute;essayer l'int&eacute;gration s'il vous pla&icirc;t";

                                            ?>
                                            </span>
                                            <?php
                                            }else
                                            {
                                            ?>
                                            <span class="text-red">
                                            <?php
                                                echo $row->Isyserrors_47;
                                            ?>
                                            </span>
                                            <?php
                                            }

                                            ?>
                                        </td>
                                        <td width="25" class="text-center" id="tt<?php echo $row->Id_0; ?>">

                                            <?php 
                                            if ($row->Isyserrors_47 =="200")
                                            {
                                            ?>
                                            <input id="<?php echo $row->Id_0; ?>" type="checkbox" value="<?php echo $row->Id_0; ?>" data-id-paiement="<?php echo $row->Id_0; ?>" class="check" name="ids[]" onclick="valider('<?php echo $row->Id_0;?>')" onchange="calculate('<?php echo $row->Id_0; ?>');" /> 
                                            <?php

                                            }elseif($row->Isyserrors_47 =="" || $row->Isyserrors_47 ==NULL)
                                            {
                                            ?>
                                            <a id="<?php echo $row->Id_0; ?>" class="btn btn-warning btn-xs integrate" href="#" data-btnid="<?php echo $row->Id_0; ?>" class="text-green"> R&eacute;int&eacute;grer </a>
                                            <?php

                                            }else
                                            {
                                            ?>
                                            <a id="<?php echo $row->Id_0; ?>" class="btn btn-warning btn-xs integrate" href="#" data-btnid="<?php echo $row->Id_0; ?>" class="text-green"> R&eacute;int&eacute;grer </a>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                    
                                <?php 

                                } 
                                ?>
                                </tbody>    
                            </table>
                            </div>
                        </div>
                    </div>
                    <div id="footpage" class="box-footer clearfix">
                        <div class="col-md-12">
                            <button type="submit" id="validation" disabled="disabled" class="btn btn-success pull-left"> Continuer <i class="fa fa-arrow-right"></i></button>&nbsp;&nbsp;&nbsp;
                            <span><button type="button" class="btn btn-primary" id="export"><i class="fa  fa-file-pdf-o"></i> Excel</button></span>&nbsp;
                            <span><a  href="<?php echo base_url($module.'/bank/data/export_integration');?>" class="btn btn-primary" disabled="disabled" id="csv"><i class="fa fa-html5" style="color:white;"></i>&nbsp;&nbsp;CSV&nbsp;&nbsp;</a></span>&nbsp;
                            
                        </div>
                    </div>


            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                        <span class="fa fa-warning text-gray mystyle4"></span>
                        <br/><br/>
                        Aucun paiement trouv&eacute;
                        <br/><br/>
                    </div>
                </section>
            <?php endif;?>
            <?php $this->chtml->box_body_closing(); ?>
            <?php echo form_close(); ?>
        </div>
        <div class="col-md-12" id="bloc-2">
            
        </div>
        <?php }else{ ?>
        <div class="col-md-12" id="bloc-2">
            
        </div>
        <?php } ?>
    </div>
    <div class="col-md-1">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

<script>
    
    var devise='';
    var regie='';
    
    <?php if(isset($view) && $view !=""){ ?>
        
        var id = '<?= $view ?>';
        validation_details(id);
    <?php } ?>

    $(".reverser").on("click",function(){
        var target = $(this).data("btnid");
        devise = $('#devise'+target).val();
        regie = $('#regie'+target).val();
        $(".key"+target).prop("disabled", '');
        $(".reverser").not(this).attr("disabled",true);
        $("#btn_confirm").prop("disabled",false);

    });

    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();

        var url = '<?php echo base_url($module.'/bank'); ?>/display/paiement_validation';
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');


        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(loader){

                    $("#bloc-1").addClass('hidden');
                    $("#bloc-2").removeClass('hidden');
                    $("#step-1").removeClass('bg-green');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green');
                    
                    $("#message").html('');
                    $("#bloc-2").html(loader);

                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    $("#export").click(function(){
    
        var url = '<?php echo base_url($module.'/bank/display/export'); ?>/';
        
        var w = window.open(url);
        
    });
    
    $('#budget').html('0,00');
    $('#budget_cdf').html('0,00');
    $('#budget_usd').html('0,00');
    $('#contrevaleur').html('0,00');
    $('#total').html('0');
    
    var usd = '<?= isset($usd) ? $usd : "" ?>';
    var total = 1;
    
    
    $("#content").on("change", ".check", function()
    {       
            var $checedInputs = $('#table').find("input:checked");
            var index = $checedInputs.length;
            
            
            if(index > 0)
            {
                    $("#validation").prop("disabled",false);
            }
            else if(index <= 0)
            {
                    $("#validation").prop("disabled",true);
            }
    });
    
    $("#cancel").click(function(){
        quit();
    });
    
    $("#pager").on("click", ".integrate", function()
    {
        var btn_id = $(this).attr('data-btnid');
        $("#tt"+ btn_id ).html('');
        $("#tt"+ btn_id ).html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        var paiement_id = '<?= isset($paiement_id) ? $paiement_id : ""; ?>'
        
        var url = '<?php echo base_url($module.'/bank/display/integration_isys'); ?>/'+ btn_id;
        $.get(url, function(data, status){
            
            if(data !="")
            {
                var url = '<?php echo base_url($module.'/bank/display/list_integration'); ?>';
                $.get(url, {object:paiement_id}, function(data, status){
                    $("#pager").html('');
                    $("#pager").html(data);
                });
            }
        });
        
    });
    
    function calculate(id){
        
        var budget = $('#budget').html();
        var budget_cdf = $('#budget_cdf').html();
        var contrevaleur = $('#contrevaleur').html();
        var budget_usd = $('#budget_usd').html();
       
        var cost = $('#t'+id).val();
        var devise = $('#d'+id).val();
        
        if ($('#'+id).is(':checked')) 
        {
            if(devise=='CDF')
            {
                budget_cdf = parseFloat(budget_cdf) + parseFloat(cost);
            }
            if(devise=='USD')
            {
                budget_usd = parseFloat(budget_usd) + parseFloat(cost);
                
            }
            budget = (parseFloat(budget_usd)*usd) + parseFloat(budget_cdf)
            
            
        }
        else
        {

            if(devise=='CDF')
            {
                budget_cdf = parseFloat(budget_cdf) - parseFloat(cost);
            }
            if(devise=='USD')
            {
                budget_usd = parseFloat(budget_usd) - parseFloat(cost);
            }
            budget = (parseFloat(budget_usd)*usd) + parseFloat(budget_cdf)
            
            
        }  
        contrevaleur = parseFloat(budget_usd)*usd;
        var result= $('input[type="checkbox"]:checked');
        var total = result.length;
        $('#budget').html(budget);
        $('#budget_cdf').html(budget_cdf);
        $('#budget_usd').html(budget_usd);
        $('#total').html(total);
        $('#budget_usd').html(budget_usd);
        $('#Montant_8').val(budget);
        $('#Nombrepaiement_7').val(total);
    }
    
    function validation_details(id){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/bank/display/paiement_validation'); ?>/" + id +'/details', function(data, status){
          $("#loader").html('');
          $("#bloc-2").html(data);
        });
    }
    function quit(){
        
        var view = '<?= isset($view) ? $view : "" ?>'
        
        if(view!="")
        {
            $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/transferred';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#container").html(data);
            });
        }
        else
        {
            $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/bank'); ?>/display/validated';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#container").html(data);
            });
        }
    }
    
    
</script>