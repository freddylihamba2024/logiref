<?php $userid = $this->session->userdata("user_id"); $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); ?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php if(isset($edit) && $edit!='') {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}?>
<?php if($_SESSION['Logiref_role']==3 && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php if($_SESSION['Logiref_role']==3 && $encaissement->Status_2==1 && $encaissement->Checkerid_10!=0) $feuille='view';?>

<?php $Standard01='';?>

<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>

<div id="pager"> 
        <div class="col-md-1"></div>

        <?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
        <div class="col-md-10">
            <div id="message"></div>
            <h1><?php echo $title;?></h1>
            <span class="page-header">
                Effectuer un encaissement
            </span>
        <style>label {min-width: 150px !important;}</style>
        <?php $this->chtml->box_body_opening('', true); ?>
            <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
            <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
            <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
            <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9; ?>" />
            <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
            <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
            <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
            <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
        <?php if($encaissement->Id_0!=NULL && $encaissement->Mode_19 != 5):?>
            <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33; ?>" />
            <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34; ?>" />
        <?php endif;?>
        <?php if($encaissement->Beneficaire_15 =="DGDA") :?>
            <input type="hidden" name="Infos[year]" value="<?= isset($Infos['year']) ? $Infos['year'] : ""; ?>" />
            <input type="hidden" name="Infos[number]" value="<?= isset($Infos['serie']) ? $Infos['serie'] : ""; ?>" />
            <input type="hidden" name="Infos[serie]" value="<?php if(isset($Infos['number']))echo $Infos['number'];else if(isset($Infos['serial'])) echo $Infos['serial']; ?>" />
            <input type="hidden" name="Infos[taxesPaid]" value="<?= isset($Infos['taxesPaid']) ? $Infos['taxesPaid'] : ""; ?>" />
            <input type="hidden" name="Infos[quittance]" value="<?php isset($Infos['quittance']) ? $Infos['quittance'] : ""; ?>" />
            <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($Infos['amountDGDA']) ? $Infos['amountDGDA'] : ""; ?>" />
            <input type="hidden" name="Infos[amountSERVICES]" value="<?= isset($Infos['amountSERVICES']) ? json_encode($Infos['amountSERVICES']) : ""; ?>" />
        <?php endif; ?>
            <div class="box-body">
                <!------------------------- B�n�ficiare  ------------------------------>
                <div class="col-md-12"><br/><label>B&eacute;n&eacute;ficiare</label><br/></div>
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', $beneficiaires['Regies'], $encaissement->Beneficaire_15, ' id="regies" class="form-control"'.$disabled.' requireds="requireds"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
                </div> 
                <div class="col-md-6">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                        </span>
                        <span id="slist"><?php echo form_dropdown('Service_16', array(), $encaissement->Service_16, 'class="form-control" id="service" '.$disabled.' requireds="requireds" '); ?></span>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
                        <?php endif; ?>
                    </div>
                </div> 
                <!------------------------- Payement  ------------------------------>
                <div class="col-md-12 border"><br/><label>Client (assujetti ou contribuable) </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                            </span>
                            <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" requireds="requireds" maxlength="86"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-7">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Designation_14">D&eacute;signation</label> 
                            </span>
                            <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" requireds="requireds" maxlength="86"'); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                               <label for="Datevaleur_31">Date paiement</label>
                            </span>
                            <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  requireds="requireds" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Notedate_27">Date &eacute;mission</label>
                            </span>
                            <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  requireds="requireds" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Mode_19">Mode de paiement</label> 
                            </span>
                            <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" requireds="requireds" id="modeId"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Montant_11">Montant pay&eacute;</label> 
                            </span>
                            <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" requireds="requireds"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Notemontant_28">Montant de la note</label> 
                            </span>
                            <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="Notemontant_28" class="form-control"'); ?>
                        </div>
                        <div class="input-group"> 
                            <span class="input-group-addon">
                                <label for="Compte_33"><div id="compteLabel"><?php echo $label01; ?></div></label> 
                            </span>
                            <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" id="compteId"'); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  requireds="requireds" id="recetteDevise"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="Notedevise_29"  required="required"'); ?>

                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_34', $devises, $devise01, 'class="form-control"  requireds="requireds" id="compteDevise"'); ?>
                        </div>
                    </div>
                    <div class="col-md-12" id="reference_id">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Reference_32">R&eacute;f&eacute;rence du client</label>
                            </span>
                            <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                        </div>
                    </div> 
                
                <!-------------------------  Titre de perception  ------------------------------>
                <div id="main_field">
                    <div class="col-md-12"><br/><label id="title">Titre de perception</label><br/></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Noteid_26"><div id="TitreId">R&eacute;f&eacute;rence titre</div></label> 
                            </span>
                            <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="input-group"  id="recette0">
                            <span class="input-group-addon">
                                <label for="Typerecette_17">Nature paiement</label> 
                            </span>
                            <span id="rlist"><?php echo form_dropdown('Typerecette_17', array(), $encaissement->Typerecette_17, 'class="form-control" id="recette" disabled="disabled" requireds="requireds" '); ?></span>
                        </div>
                    </div>
                    <div id="bl" class="col-md-12"></div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Notedate_27">Date &eacute;mission</label>
                            </span>
                            <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  requireds="requireds" '); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Notetype_25" id="title2">Type note</label> 
                            </span>
                            <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" id="doc" requireds="requireds" '); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="standard" id="StandardLabel01">----------</label> 
                            </span>
                            <?php echo form_input("Infos[standard]", set_value("Infos[standard]", ""), ' class="form-control" id="Standard01" disabled="" maxlength="25"'); ?>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Notemontant_28">Montant de la note</label> 
                            </span>
                            <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="Notemontant_28" class="form-control"'); ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="Notedevise_29"  requireds="requireds"'); ?>
                        </div>
                    </div>
                </div>
                <!-------------------------  DGI Cotisation  ------------------------------>
                <div id="DGICotisation" style="display: none;">
                    <div class="col-md-12"><br/><label>Information additionnelle</label><br/></div>
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="RefINSS">R&eacute;f&eacute;rence INSS</label> 
                            </span>
                            <?php echo form_input("Infos[RefINSS]", set_value("Infos[RefINSS]", $Infos['RefINSS']), 'class="form-control"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="RefINPP">R&eacute;f&eacute;rence INPP</label> 
                            </span>
                            <?php echo form_input("Infos[RefINPP]", set_value("Infos[RefINPP]", $Infos['RefINPP']), 'class="form-control"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="RefONEM">R&eacute;f&eacute;rence ONEM</label> 
                            </span>
                            <?php echo form_input("Infos[RefONEM]", set_value("Infos[RefONEM]", $Infos['RefONEM']), 'class="form-control"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="QuotasINSS">Quotas INSS</label> 
                            </span>
                            <?php echo form_input("Infos[QuotasINSS]", set_value("Infos[QuotasINSS]", $Infos['QuotasINSS']), 'class="form-control"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="QuotasINPP">Quotas INPP</label> 
                            </span>
                            <?php echo form_input("Infos[QuotasINPP]", set_value("Infos[QuotasINPP]", $Infos['QuotasINPP']), 'class="form-control"'); ?>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="input-group"  id="regie0">
                            <span class="input-group-addon">
                                <label for="QuotasONEM">Quatas ONEM</label> 
                            </span>
                            <?php echo form_input("Infos[QuotasONEM]", set_value("Infos[QuotasONEM]", $Infos['QuotasONEM']), 'class="form-control"'); ?>
                        </div>
                    </div>
                </div>
                <!-------------------------  DGDA Informations additionnelles  ------------------------------>
                <div>
                    <div class="col-md-12"><br/><label>Repartition</label><br/></div>
                    <div  id="Comptabilisation" class="col-md-12">
                            
                    </div>
                    <br/>
                    <div  id="message_isys" class="col-md-12">
                        
                    </div>
                    <div  id="loading" class="col-md-12">
                        
                    </div>
                </div>
                <!-------------------------  END  ------------------------------>
            </div>
            <div  class="box-footer clearfix">
                <div id="createPaiement" class="col-md-12">
                    <?php if($encaissement->Checkerid_10 ==0 && ($userid = $this->session->userdata("user_id") || $_SESSION['Logiref_role']==3)): ?>
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>
                    <?php if($feuille=='' && $_SESSION['Logiref_role']==4): ?>
                        <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php elseif($feuille !='' && $_SESSION['Logiref_role']==4 && $encaissement->Checkerid_10 !=0): ?>
                        <button type="button" id="print" class="btn btn-primary" disabled=""><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <a type="button" class="btn btn-warning" href=""><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                        <input type="hidden" name="from" value="<?php echo $from; ?>" id="from">
                    <?php elseif($feuille =='' && $_SESSION['Logiref_role']==3 && $encaissement->Checkerid_10 !=0): ?>
                        <button type="button" id="print" class="btn btn-primary" disabled=""><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <a type="button" class="btn btn-warning" href=""><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                    <?php elseif($feuille =='' && $_SESSION['Logiref_role']==3 && $encaissement->Checkerid_10 ==0): ?>
                        <a type="button" class="btn btn-warning" href=""><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                        <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    
                    <?php else: ?>
                        <a type="button" class="btn btn-warning" href=""><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                        <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>
                </div>
            </div>
        <?php $this->chtml->box_body_closing(); ?> 	  
        </div>
        <?php echo form_close(); ?>
        <div class="col-md-1">
            <?php if($_SESSION['Logiref_role'] !=4){ ?>
                <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
            <?php } ?>
        </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>';
var status_print ='<?php  echo($encaissement->Checkerid_10!=0 && $encaissement->Checkerid_10!="")? true: false ;?>'; 
var Dtaux=[];
Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>'; 


if(status_print)
{
       $('#print').prop("disabled",false);
}   
$('#modeId').change(function(){
      var mode = $('#modeId').val();
      if(mode === '7' || mode == '8'){
          $("#compteId").prop('disabled',''); 
          $("#compteDevise").prop('disabled',''); 
          $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
          $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
          $("#compteId").val('');
      }else{
          $("#compteId").prop('disabled',''); 
          $("#compteDevise").prop('disabled','');
          $("#compteLabel").html('Commission');
          commission();
      }
});

$('#recetteMontant').change(function(){
        commission();
        montantValidation();
});

$('#recetteDevise').change(function()
{
      commission();
      montantValidation();
});

$('#reftitre').change(function(){
        var regie = $('#regies option:selected').val();
        var service = $('#service option:selected').val();
        var titre = $('#reftitre').val();
        if(regie === '3' && service !== null)
        {
            $("#bl").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
            extract(titre,regie,service);  
        }
      
});

$('#regies').change(function(){
    shower();
    commission();
});

$('#validate').change(function(){
    
    $('#action').val('valider')
    
});

$("#pager").on("change", "#recette", function(){
    
    commission();
    
    var recette = $('#recette option:selected').val();
    if(recette === 'IPRIER'){
        $("#DGICotisation").css('display', '');
    }
    else
    {
        $("#DGICotisation").css('display', 'none');
    }
    
});

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'dd-mm-yyyy'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var data = $(this).serialize();
        
        validate(data);
        
});

$("#cancel").click(function(){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/bank'); ?>/display/nvalidated';
    $.get(url, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
    });
});

$("#print").click(function(){

        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
});

function hidder(){
      $("#regie0").css('display', 'none');
      $("#regie1").css('display', 'none');
      $("#regie2").css('display', 'none');
      $("#regie3").css('display', 'none');
      $("#regie4").css('display', 'none');
      
      $("#recette0").css('display', 'none');
      $("#recette1").css('display', 'none');
      $("#recette2").css('display', 'none');
      $("#recette3").css('display', 'none');
      $("#recette4").css('display', 'none');
}

<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        shower();
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>
    
    
function closeModal(){
    
}
function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#compteId").val('');
        $("#compteDevise").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = $('#regies option:selected').val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        
        var guichet = $('#guichetId').val();
        if(mode === '5' && montant !== '' && regie !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/bank/display/charges'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        $("#compteId").val(result[0]);
                        $("#compteDevise").prop("selectedIndex", result[1]);
                        //$('#loader').html(reponse);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                    }  
            });    
        }
}

function extract(titre,regie,service){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/transactions'); ?>/<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : { titre : titre, regie : regie, service : service }, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#bl').html(result);
                },
                error:function(error){
                    $('#bl').html('');
                }
        });
}

function submiter(data){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E404" || result === "E22")
                        {
                                $('#message').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E405")
                        {
                                $('#message').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $('#message').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#message').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34x")
                        {
                                $('#message').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#message').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                scrollUP();
                                comptabilisation(result.logiref_4);
                                ref = result.ref;
                                
                                
                                    
                                
                        }
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function validate(data){
        var url = '<?php echo base_url($module.'/bank/save/validation_paiements'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode          : true,
                success: function(result){
                        $('#message').html('');
                        
                        <?php if($_SESSION['Logiref_role']==3):?>
                                            
                            $('#print').prop("disabled",false);
                            $("#enregistrer").prop('disabled', true);
                            $('#mainform').addClass('view'); 
                            
                            $('#message').html('<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            
                        <?php else:?> 
                            
                            $('#message').html('<div class="alert alert-success text-white">Bravo! paiement modifi&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            
                        <?php endif; ?>
                        
                        
                        scrollUP();
                        comptabilisation(result.logiref_4);
                        ref = result.ref;
                        
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function shower()
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#Standard01").removeClass('Standard01');
        var regie = $('#regies option:selected').val();
        var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/services/<?php echo $encaissement->Service_16; ?>';
        $.get(url, function(data, status){
            $("#slist").html(data);
        });
        var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/recettes/<?php echo $encaissement->Typerecette_17; ?>';
        $.get(url, function(data, status){
            $("#rlist").html(data);
        });
      
        //Standard field 01 
        //DGI
        if(regie === 'DGI'){
                $("#StandardLabel01").html('Ech&eacute;ance');
                $("#Standard01").addClass('Standard01');
                $(".Standard01").datepicker({
                      todayHighlight: true,
                      format: 'dd-mm-yyyy'
                  });
                $("#Standard01").prop('disabled','');
                $("#Standard01").prop('maxlength','12');
                 $("#Standard01").val('<?php echo $Infos['standard'];?>');
                $("#Standard01").prop('placeholder','201808');
                $('#doc').prop("selectedIndex", 0);
                $("#ServiceId").html('Service recouvrement');
                $("#DGDAComplement").css('display','none');
                $("#title").html('D&eacute;claration');
                $("#title2").html('D&eacute;claration');
                $("#TitreId").html('R&eacute;f&eacute;rence d&eacute;claration');
                
        //DGRAD
        }else if(regie === 'DGRAD'){
                $("#Standard01").removeClass('Standard01');
                $("#StandardLabel01").html('Art. budg&eacute;taire');
                $("#Standard01").type='text';
                $("#Standard01").prop('disabled','');
                $("#Standard01").prop('maxlength','6');
                $("#Standard01").prop('placeholder','E.g: 11201808');
                $('#doc').prop("selectedIndex", 1);
                $("#ServiceId").html('Service recouvrement');
                $("#DGDAComplement").css('display','none');
                $("#title").html('Note de perception');
                $("#title2").html('Note de perception');
                $("#TitreId").html('R&eacute;f&eacute;rence note');
        //DGDA
        }
        else if(regie === 'DGDA')
        {
                $("#Standard01").removeClass('Standard01');
                $("#TitreId").html('Num&eacute;ro B.L.');
                $("#StandardLabel01").html('D&eacute;clarant/R&eacute;f&eacute;rence');
                $("#Standard01").type='text';
                $("#Standard01").prop('disabled','');
                $("#Standard01").prop('maxlength','6');
                $("#Standard01").prop('placeholder','E.g:');
                $("#ServiceId").html('Bureau en douane');
                $('#doc').prop("selectedIndex", 2);
                $("#DGDAComplement").css('display','');
                $('#moyenId').prop("requireds", "requireds");
                $("#title").html('Bulletin de liquidation');
                $("#title2").html('Bulletin de liquidation');
                $("#TitreId").html('R&eacute;f&eacute;rence bulletin');
                $("#reference_id").addClass("hidden");
                $("#main_field").addClass("hidden");
            //ESES
        }
        else
        {
                $("#Standard01").removeClass('Standard01');
                $("#StandardLabel01").html('NIF B&eacute;n&eacute;ficiaire');
                $("#Standard01").type='text';
                $("#Standard01").prop('disabled','');
                $("#Standard01").prop('maxlength','20');
                $("#Standard01").prop('placeholder','');
                $("#ServicdId").html('Service recouvrement');
                $('#doc').prop("selectedIndex", 3);
                $("#DGDAComplement").css('display','none');
        }
}


function comptabilisation(ref){

        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

function integration_isys(){
        $("#loading").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/integration_isys'); ?>/'+ ref;
        $.get(url, function(data, status){
            $('#message_isys').html(data);
            $("#loading").html('');
        });
}

$("#validate").click(function(){
        $("#message").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/api_cbs'); ?>';
        
        var mode = '<?= isset($encaissement->Mode_19) ? $encaissement->Mode_19 : "";?>';
        var ref = '<?= isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";?>';
        
        var data = {mode:mode, ref:ref}
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                
                success: function(result){
                        $('#message').html('');
                        $('#message').html(result);
                },
                error:function(error){
            
                }
        });
});

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

$("#Notemontant_28").change(function()
{
        montantValidation();

});
$("#Notedevise_29").change(function(){
    
        montantValidation();
});

function montantValidation()
{
        var notemontant = parseFloat($("#Notemontant_28").val().split(' ').join('').split(',').join('.'));
        var recettemontant = parseFloat($("#recetteMontant").val().split(' ').join('').split(',').join('.'));
        var rdevise = $("#recetteDevise option:selected").val();
        var ndevise = $("#Notedevise_29 option:selected").val();
        var note =0;
        var recette=0;
       
        
        if(isNaN(recettemontant))
        {
                recettemontant = 0;
        }
        
        if(isNaN(notemontant))
        {
                notemontant = 0;
        }
        
        $("#recetteMontant").closest('div').removeClass("has-error");
        $('#info').text("");
        if((rdevise!='' && ndevise!='') && (recettemontant && notemontant))
        {
                if((rdevise != null && rdevise !="CDF") && (ndevise != null && ndevise !="CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant * Dtaux[rdevise];
                        
                }
                else if((ndevise!= null && ndevise != "CDF") && (rdevise != null && rdevise == "CDF"))
                {
                        note = notemontant * Dtaux[ndevise];
                        recette = recettemontant;
                       
                }
                else if((rdevise != null && rdevise != "CDF") && (ndevise != null && ndevise == "CDF"))
                {
                        recette = recettemontant * Dtaux[rdevise];
                        note = notemontant;
                        
                }
                else
                {
                    note = notemontant * 1;
                    recette = recettemontant * 1;
                    
                }
                
                if( note >= recette)
                {
                        valid = false;
                        $("#recetteMontant").closest('div').removeClass("has-error");
                        $('#info').text("");
                        $("#enregistrer").prop('disabled', false);
                }
                else
                {
                        valid = true;
                }

                if(valid)
                {
                        $("#recetteMontant").closest('div').addClass('has-error');
                        $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
                        $("#enregistrer").prop('disabled', true);
                }
                 
        }
       
        
       
}
function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

function gotoBottom(){
    
    $("html, body").animate({ 
        scrollTop: $( 
          'html, div').get(0).scrollHeight 
    }, 2000); 
}
</script>