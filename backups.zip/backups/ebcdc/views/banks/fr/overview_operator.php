<?php 
if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates']!==0){
    $bank = json_decode($_SESSION['Bank_rates'], true);
    $usd = $bank['Dollar_4'];
    $eur = $bank['Euro_5'];
    $rand = $bank['Rand_6'];
    $pound = $bank['Pound_7'];
}else {
    $usd = $eur = $rand = $pound = 0.0;    
}
?>


<div class="col-md-1 content text-center">
    <a href="<?php echo base_url($module.'/bank/set/menu'); ?>"><span class="fa fa-bars text-blue f40"></span></a>
</div>
<div class="col-md-10 content">
        <div id="loader"></div>
        <div class="col-md-12">
                <?php $this->chtml->box_body_opening("", true); ?>
                <div class="statistic-box no-border">
                        <div class="col-sm-4 col-xs-4">
                            <div class="description-block border-right" >
                                <div class="col-md-12"><span class="f13"><b>DGI</b></span></div>
                                <div class="col-md-6 description-block ">
                                    <span class="text-gray"><?php echo $paiement_regie['dgi_validated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgi_validated']." CDF"; ?></span><br/>
                                    <span class="text-green">Valid&eacute;s</span>
                                </div>
                                <div class="col-md-6 description-block border-left">
                                    <span class="text-gray"><?php echo $paiement_regie['dgi_unvalidated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgi_unvalidated']." CDF"; ?></span><br/>
                                    <span class="text-yellow">Non valid&eacute;s</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-4 bLeft">
                            <div class="description-block border-right" >
                                <div class="col-md-12"><span class="f13"><b>DGRAD</b></span></div>
                                <div class="col-md-6 description-block ">
                                    <span class="text-gray"><?php echo $paiement_regie['dgrad_validated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgrad_validated']." CDF"; ?></span><br/>
                                    <span class="text-green">Valid&eacute;s</span>
                                </div>
                                <div class="col-md-6 description-block border-left">
                                    <span class="text-gray"><?php echo $paiement_regie['dgrad_unvalidated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgrad_unvalidated']." CDF"; ?></span><br/>
                                    <span class="text-yellow">Non valid&eacute;s</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-4 bLeft">
                            <div class="description-block border-right" >
                                <div class="col-md-12"><span class="f13"><b>DGDA</b></span></div>
                                <div class="col-md-6 description-block ">
                                    <span class="text-gray"><?php echo $paiement_regie['dgda_validated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgda_validated']." CDF"; ?></span><br/>
                                    <span class="text-green">Valid&eacute;s</span>
                                </div>
                                <div class="col-md-6 description-block border-left">
                                    <span class="text-gray"><?php echo $paiement_regie['dgda_unvalidated_number']; ?></span><br/>
                                    <span class="f14"><?php echo $paiement_regie['dgda_unvalidated']." CDF"; ?></span><br/>
                                    <span class="text-yellow">Non valid&eacute;s</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php $this->chtml->box_body_closing(); ?>
        </div>
        <div class="col-md-12 no-padding"><div class="col-md-12"><h3>Situation des paiements</h3></div></div>
        <div class="col-md-12">
                <?php $this->chtml->box_body_opening('', false); ?>
                <div class="col-md-12">
                        <div class="col-md-8 no-padding  ">
                            <div class="col-md-6 no-padding">
                                    <div class="center col-md-12"><br/>Paiements en CDF</div>
                                    <div class="box-body margin padding">
                                        <canvas id="lineChart" width="80" height="100"></canvas>
                                    </div>

                            </div>
                            <div class="col-md-6 no-padding">
                                <div class="center col-md-12"><br/>Paiements en USD</div>
                                <div class="bLeft bRight">
                                    <div class="box-body margin padding">
                                        <canvas id="pieChart" width="80" height="100"></canvas>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-12 no-padding">
                               
                                    <div class="col-md-4"><span class="label bg-yellow"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements non valid&eacute;s</span></div>
                                    <div class="col-md-4"><span class="label bg-green"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements valid&eacute;s</span></div>
                                    <div class="col-md-4"><span class="label bg-blue"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements revers&eacute;s aujourd'hui</span></div><br/><br/>
                                
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="statistic-box" style="margin-top:10px;">
                                    <ul class="list-group clear-list m-t">
                                        <li class="list-group-item fist-item">
                                            <span class="pull-right">
                                                <span class="label label-success" style="color:white !important;">CDF <?php echo number_format($usd,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-dollar text-black"></i> Dollars
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                               <span class="label label-info" style="color:white !important;">CDF <?php echo number_format($eur,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-euro text-black"></i>Euros
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                                <span class="label label-danger" style="color:white !important;">CDF <?php echo  number_format($pound,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-gbp text-black"></i>Pounds
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                                <span class="label label-warning" style="color:white !important;">CDF <?php echo number_format($rand,2,","," "); ?></span>
                                            </span>
                                            <span class="text-black"><b>&nbsp;R</b></span> Rands
                                        </li>
                                    </ul>
                            </div>
                        </div>
                </div>
                <?php $this->chtml->box_body_closing(); ?>
        </div>
        
        <div class="col-md-12 no-padding"><div class="col-md-12"><h3>Retard de reversement</h3></div></div>
        <div class="col-md-12">
        <?php $this->chtml->box_body_opening('', false); ?>
        <div class="col-md-12">
            <?php if(!empty($encaissements)): ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th></th>
                            <th>Date</th>
                            <th>Client</th>
                            <th>B&eacute;n&eacute;ficiaire</th>
                            <th>Service</th>
                            <th>Recette</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th>Guichet</th>
                            <th>Op&eacute;rateur</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php  foreach($encaissements as $row){ 
                        $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                        $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                        $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                    ?>
                        <tr>
                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                            <td width="50" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                            </td>
                            <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                            <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                            <td><?php echo $beneficiaires[$row->Service_16]; ?></td>
                            <td><?php echo $row->Typerecette_17; ?></td>
                            <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                  <br/>
                                  <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                <?php endif;?>
                            </td>
                            <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                            <td><?php echo '<span  class="text-blue">'.$guichet.'</span>'; ?></td>
                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                        </tr>
                    <?php 
                          
                    } 
                    ?>
                    </tbody>    
                </table>
                        
            
            <?php else: ?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                        <span class="fa fa-warning text-gray mystyle4"></span>
                        <br/><br/>
                        Aucune information suppl&eacute;mentaire trouv&eacute;e
                        <br/><br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
        <?php $this->chtml->box_body_closing(); ?>
        </div>
</div>

<div class="col-md-1"></div>

<script src="<?php echo base_url('ikwook_bootstraps/v2/plugins/chartjs/Chart.min.js'); ?>" type="text/javascript"></script>
<link href="<?php echo base_url('ikwook_bootstraps/v4'); ?>/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
 
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": false,
      "bLengthChange": false,
});

$("#menu").click(function () {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module.'/bank/display/menu/'); ?>", function (data, status) {
            $("#loader").html('');
            $("#fullscreen").html(data);
        });
});
 
//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#lineChart").get(0).getContext("2d");
    //alert('Ok');
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_situation_cdf)) echo $pie_situation_cdf; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-


//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
    //alert('Ok');
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_situation_usd)) echo $pie_situation_usd; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-


</script>