<?php 
$userid = $this->session->userdata("user_id");
$usertype = $this->session->userdata("user_type");
$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;
?>

<div id="pager"  class="col-md-12"> 
        <div class="col-md-5">
                <h1>Int&eacute;gration RTGS</h1>
               <p class="page-header">Cette section vous pr&eacute;sente les d&eacute;tails des paiements per&ccedil;us pour diff&eacute;rents b&eacute;n&eacute;ficiaires par rapport &agrave; une p&eacute;riode donn&eacute;e.</p>  
               <div id="loader"></div>
        </div>
       <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total paiements</span><br/><br/>
                            <p class="text-blue f16"> <b>CDF <span id="paiements"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total DGI</span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgi"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGDA </span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgda"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGRAD</span><br/><br/>
                            <p class="f16"><b>CDF <span id="dgrad"></span></b></p>
                          </div>
                        </div>
                    </div>
                </div>
       </div>
        <div class="col-md-1" style="padding-left:1px;">
            <a id="Create" href="#"><span class="fa fa-fw fa-plus-circle <?php if($_SESSION['Logiref_role']!=3) echo 'text-gray';?> mystyle4"></span></a>
            <br/>
        </div>
</div>

<div class="col-md-12">
        <div class="col-md-12">
                <?php if(!empty($integrations)): ?>
                <?php $this->chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th>#</th>
                                <th>Dates</th>
                                <th>Direction</th>
                                <th>Service</th>
                                <th>Montant</th>
                                <th>R&eacute;f&eacuterence</th>
                                <th>Agence</th>
                                <th>Valid&eacute; par</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 

                        foreach($integrations as $row){
                        ?>
                            <tr>
                                <td ><b><?php echo ++$i; ?></b></span></td>
                                <td ><?php echo $row->Date_1; ?></td>
                                <td ><?php echo $regies['Regies'][$row->Beneficiaire_9]; ?></td>
                                <td><?php if(isset($beneficiaires[$row->Service_10])) echo $beneficiaires[$row->Service_10]; ?></td>
                                <td class="text-blue"><?php echo $row->Devise_8.' '.number_format($row->Montant_7,2,","," "); ?></td>
                                <td><?php echo $row->Reference_isys_16; ?></td>
                                <td class="text-black"><?php echo ucfirst(strtolower($agences[$row->Agence_14])); ?></td>
                                <td class=""><?= isset($users[$row->Makerid_6]) ? $users[$row->Makerid_6] : ""; ?></td>
                            </tr>
                        <?php 

                        } 
                        ?>
                        </tbody>    
                    </table>

                </div>
                <?php $this->chtml->box_body_closing(); ?>
        </div>
        <?php else: ?>
            <section id="cat_list">
                <h4 class="page-header" align="center"><b></b></h4>
                <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                    <span class="fa fa-warning text-gray mystyle4"></span>
                    <br/><br/>
                    Aucun paiement trouv&eacute;
                    <br/><br/>
                </div>
            </section>
        <?php endif;?>
</div>


<script type="text/javascript">
    
    var print = "";
     $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        
        var url = '<?php echo base_url($module.'/bank/display/rapport_detailles'); ?>';
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(data){
                    $("#loader").html('');
                    $("#pager").html(data);
                    
                    print = 'details';
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    $("#Create").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/bank/display/wizard_rtgs'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    });
    
    function view(id) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/isys'); ?>/' + id;
        $.get(url, function (data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    
    
</script>



