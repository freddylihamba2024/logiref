    <div class="col-md-12 no-padding" style="height:200px; overflow: auto;">

        <div id="content">
            <?php $this->chtml->box_body_opening('', true);?>

                    <div class="col-md-4 no-padding"><h4>Liste des paiements</h4></div>
                    <div class="form-group col-md-8">   

                    </div>

                    <?php if(!empty($paiements)): ?>

                        <div class="col-md-12 no-padding">
                            <table id="" class="table table-hover table-striped">
                                <thead>
                                    <tr class="bg-gray">
                                        <th></th>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>Direction</th>
                                        <th>Service</th>
                                        <th>Montant</th>
                                        <th>Recette</th>
                                        <th>Guichet</th>
                                        <th><span class="fa fa-fw fa-check-square f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 

                                foreach($paiements as $row){
                                ?>
                                    <tr>
                                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                        <td width="50" <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
                                        <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span class="text-gray"><?php echo $row->Nif_13; ?></span></td>
                                        <td width="50"><b><?php echo $regie = $regies['Regies'][$row->Beneficaire_15]; ?></b></td>                      
                                        <td><b><?php echo $beneficiaires[$row->Service_16]; ?></b></td>
                                        <td class="text-blue">
                                            <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?>
                                            <input type='hidden' value='<?php echo $row->Montant_11; ?>' name="total[]" id="t<?php echo $row->Id_0; ?>" />
                                            <input type='hidden' value='<?php echo $row->Devise_12; ?>' name="devise[]" id="d<?php echo $row->Id_0; ?>" />
                                        </td>
                                        <td><?php echo $recettes[$regie][$row->Typerecette_17]; ?></td>
                                        <td><?php echo '<span  class="text-blue">'.$guichets[$row->Guichet_21].'<br/><span  class="text-gray"> '.$users[$row->Makerid_9].'</span>'; ?></td>

                                        <td width="25">
                                            <input id="<?php echo $row->Id_0; ?>" type="checkbox" value="<?php echo $row->Id_0; ?>" class="check" name="ids[]" onchange="calculate('<?php echo $row->Id_0; ?>');" /> 
                                        </td>
                                    </tr>
                                <?php 

                                } 
                                ?>
                                </tbody>    
                            </table>
                        </div>

                    <?php else: ?>
                        <section>
                            <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                                <span class="fa fa-warning text-gray mystyle4"></span>
                                <br/><br/>
                                Aucun paiement trouv&eacute;
                                <br/><br/>
                            </div>
                        </section>
                    <?php endif;?>
            <?php $this->chtml->box_body_closing(); ?>
        </div>
    </div>
