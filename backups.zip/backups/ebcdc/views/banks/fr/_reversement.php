<?php if(isset($reversement->Id_0) && $reversement->Id_0!='' && $reversement->Id_0!=0) { $title ="Reversement"; $feuille='view';}else{$title ="Reversement"; $feuille='';}?>
<?php $userid = $this->session->userdata("user_id"); ?>


<div class="col-md-2" style="padding-right:0px; margin-top:85px;">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="small-box bg-white">
            <div class="inner">
              <b><span id="currency" class="f25"><?php echo $reversement->Devise_12; ?></span> <span id="budget" class="f25"><?php echo $reversement->Montant_11; ?></span> </b> <br/>              
            </div>
            <br/>
        </div>
    </div>
</div>


<?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
<div class="col-md-8">
    <div id="loader"></div>
    <h1><?php echo $title; ?></h1>
    <span class="page-header">
        Effectuer un reversement.
    </span>
    <style>label {min-width: 150px !important;}</style>
    <?php $this->chtml->box_body_opening("", true);?>
    <input type="hidden" name="Id_0" value="<?php echo $reversement->Id_0; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $reversement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_18" value="<?php echo $reversement->Agence_18; ?>" />
    <input type="hidden" id="Montant_11" name="Montant_11" value="<?php echo $reversement->Montant_11; ?>" />
    <div class="box-body">
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_13">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_13', $beneficiaires['Regies'], $reversement->Beneficaire_13, ' id="regies" class="form-control" required="required" style="max-width:70%"'); ?>
                <?php echo form_dropdown('Devise_12', $devises, $reversement->Devise_12, 'class="form-control" id="devise" required="required"  style="max-width:30%"'); ?>
            </div>
        </div> 
        <div class="col-md-6 bLeft">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Chequeid_6">Num&eacute;ro du ch&egrave;que</label> 
                </span>
                <?php echo form_input('Chequeid_6', set_value('Chequeid_6', $reversement->Chequeid_6), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div> 
        <div class="col-md-12">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Designation_17">R&eacute;f&eacute;rence du ch&egrave;que</label> 
                </span>
                <?php echo form_input('Designation_17', set_value('Designation_17', $reversement->Designation_17), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div>

        <div class="col-md-12">
            <div class="input-group">
                <div class="input-group-addon">
                    <label for="Journee_16">Paiements du</label>
                    <i class="fa fa-calendar" style="margin-left:-14px"></i>
                </div>
                <input type="text" name="Journee_16" id="daterange" class="form-control" value="<?php echo date("Y/m/d") . " - " . date("Y/m/d"); ?>" />
            </div>
        </div>
        <div class="col-md-6">
            <div class="input-group"  id="regie0">
                <span class="input-group-addon">
                    <label for="Service_14">Service de recouvrement</label> 
                </span>
                <span id="slist"><?php echo form_dropdown('Service_14', array(), $reversement->Service_14, 'class="form-control" disabled="disabled"'); ?></span>
            </div>
        </div>
        <div class="col-md-6 bLeft">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_15">Nature paiement</label> 
                </span>
                <span id="rlist"><?php echo form_dropdown('Typerecette_15', array(), $reversement->Typerecette_15, 'class="form-control" disabled="disabled"'); ?></span>
            </div>
        </div>
        <div class="col-md-12" id="message">
            <input type="hidden" id="ids" name="ids[]" value="" />
        </div>
    </div>
    <div  class="box-footer clearfix">
        <div class="col-md-6">
            <button type="button" id="buttonClose" class="btn btn-gray  pull-left"><i class="fa fa-angle-double-left"></i>&nbsp;&nbsp;Pr&eacute;c&eacute;dent</button>&nbsp;&nbsp;&nbsp;
            <button type="submit" id="submit" class="btn btn-primary  mRight10">&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i></button>
        </div>
    </div>
<?php $this->chtml->box_body_closing(); ?> 	  
</div>
<?php echo form_close(); ?>


<div class="col-md-2">
    <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
</div>


<script src="<?php echo base_url('ikwook_bootstraps/v4/js/daterangepicker/daterangepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#devise').change(function(){
      var devise = $('#devise option:selected').val();
      $("#currency").html(devise);
      $('#message').html('');
      $('#budget').html('0');
      $('#submit').html('&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
      $('#submit').removeClass('bg-green');
});

$('#regies').change(function(){
        shower();
        $('#message').html('');
        $('#budget').html('0');
        $('#submit').val('&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
        $('#submit').removeClass('bg-green');
});

$('#service').change(function(){
      $('#message').html('');
      $('#budget').html('0');
      $('#submit').html('&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
      $('#submit').removeClass('bg-green');
});

$('#recette').change(function(){
      $('#message').html('');
      $('#budget').html('0');
      $('#submit').html('&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
      $('#submit').removeClass('bg-green');
});

//Datepicker
$('#datepicker1').datepicker({
	format: 'yyyy-mm-dd'
});
$('#datepicker1').val('');

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        var budget = $('#budget').html();
        if(budget>0){
           var url = '<?php echo base_url($module.'/bank/save/reversement'); ?>/<?php echo $reversement->Id_0; ?>';
           $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        }else{
           $('#budget').html('0');  
           var url = '<?php echo base_url($module.'/bank/display/extract'); ?>/<?php echo $reversement->Id_0; ?>';
           $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        }
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(loader){
                    
                    if(loader=='100'){
                        $('#submit').css('display','none');
                        $('#loader').html('<div class="alert alert-success text-white">Bravo! Paiements enregistres avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#cancel').html('&nbsp;&nbsp;Quitter&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
                        $('#cancel').addClass('bg-red');
                    }else if(loader=='303'){
                        $('#submit').css('display','none');
                        $('#loader').html('<div class="alert alert-warning text-white">Avertissement! Impossible de reverser ces paiement...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#cancel').html('&nbsp;&nbsp;Quitter&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
                        $('#cancel').addClass('bg-red');
                    }else{
                        $('#message').html('');
                        $('#message').html(loader);
                    }
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
      quit();
});


$("#buttonClose").click(function(){
      quit();
});

function quit(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/bank'); ?>/display/reversements';
      $.get(url, function(data, status){
          $("#loader").html('');
          $("#container").html(data);
      });
}

function hidder(){
      $("#regie0").css('display', 'none');
      $("#regie1").css('display', 'none');
      $("#regie2").css('display', 'none');
      $("#regie3").css('display', 'none');
      $("#regie4").css('display', 'none');
      
      $("#recette0").css('display', 'none');
      $("#recette1").css('display', 'none');
      $("#recette2").css('display', 'none');
      $("#recette3").css('display', 'none');
      $("#recette4").css('display', 'none');
}
<?php if(isset($reversement->Id_0) && $reversement->Id_0!='' && $reversement->Id_0!=0){?>
      shower();
<?php } ?>


function calculate(id){
      var budget = $('#budget').html();
      var cost = $('#t'+id).val();
      if ($('#'+id).is(':checked')) {
        budget = parseFloat(budget) + parseFloat(cost);
      }else{
        budget = budget - cost; 
      }   
      $('#budget').html(budget);
      $('#Montant_11').val(budget);
      
      if(budget>0){
          $('#submit').html('&nbsp;&nbsp;Reverser&nbsp;&nbsp;<i class="fa fa-save"></i>');
          $('#submit').addClass('bg-green');
      }else{
          $('#submit').html('&nbsp;&nbsp;Continuer&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>');
          $('#submit').removeClass('bg-green');
      }
}

function shower()
{
    var regie = $('#regies option:selected').val();
    var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/services-o/<?php echo $reversement->Service_14; ?>';
    $.get(url, function(data, status){
        $("#slist").html(data);
    });
    var url = '<?php echo base_url($module.'/bank'); ?>/display/dropdowns/' + regie + '/recettes-o/<?php echo $reversement->Typerecette_15; ?>';
    $.get(url, function(data, status){
        $("#rlist").html(data);
    });
      
}
//Date range picker
$('#daterange').daterangepicker({
    format: 'YYYY/MM/DD'
});

</script>