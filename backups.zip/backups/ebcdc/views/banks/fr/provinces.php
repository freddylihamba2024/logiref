<?php $userid = $this->session->userdata("user_id");?>
<?php $usertype = $this->session->userdata("user_type");?>

<div class="content">
    <div class="col-md-2"></div>

    <div class="col-md-8">
            <div class="col-md-7">
                <h1><span class="text-blue">R&eacute;f&eacute;rentiel des provinces</span></h1>
                <h5> </h5>
            </div>
            <div class="col-md-5 tRight">
                <a href="<?php echo base_url('logiref'); ?>" class="btn btn-app no-border"> <i class="fa  fa-home f35 text-blue"></i> Tableau de bord</a>
                <a id="Add" class="btn btn-app no-border"> <i class="fa fa-fw fa-plus-circle f35"></i> Ajouter</a>
                <a id="Alertes" class="btn btn-app no-border"> <i class="fa fa-comments f35 text-green"></i> Alertes </a>
            </div>

            <div id="loader" class="col-md-12"><br/><br/></div>
            <div class="col-md-12">
                    <?php $this->chtml->box_body_opening('', true); ?>
                        <?php if(!empty($provinces)): ?>
                              <div class="row pBottom50">
                                      <div class="col-md-12">
                                          <div class="row fontawesome-icon-list">
                                            <?php foreach($provinces as $row){ ?>
                                                <div class="col-md-4 col-sm-4">
                                                <span> <i class="fa fa-check-square text-green"></i> <?php echo '<span class="fa text-blue">'.$row->Code_5.'</span> '.$row->Option_4; ?> </span>
                                                <?php if($row->Account_3!=0 && $usertype==200) {?>
                                                <a style="cursor:pointer" onclick="editCategory('<?php echo $row->Id_0; ?>','<?php echo $row->Category_5;?>')"><i class="fa fa-edit"></i></a>
                                                &nbsp;&nbsp;&nbsp;
                                                <a style="cursor:pointer" onclick="deleteCategory('<?php echo $row->Id_0; ?>','<?php echo $row->Category_5;?>')"><span class="fa fa-trash-o text-red"></span></a>
                                                <?php } ?>
                                                </div>
                                            <?php } ?>
                                          </div>
                                      </div>
                              </div>
                        <?php endif;?>
                    <?php $this->chtml->box_body_closing(); ?> 	  
            </div>
    </div>

    <div class="col-md-2"></div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#Add").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

$("#Alertes").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      
}
</script>
