<?php 
$userid = $this->session->userdata("user_id");
$usertype = $this->session->userdata("user_type");
$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;
?>

<div id="pager"  class="col-md-12"> 
        <div class="col-md-5">
                <h1>Paiements revers&eacute;s</h1>
               <p class="page-header">Cette section vous pr&eacute;sente les reversements des paiements &agrave; la BCC.</p>  
               <div id="loader"></div>
        </div>
       <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total paiements</span><br/><br/>
                            <p class="text-blue f16"> <b>CDF <span id="paiements"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total DGI</span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgi"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGDA </span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgda"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGRAD</span><br/><br/>
                            <p class="f16"><b>CDF <span id="dgrad"></span></b></p>
                          </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="col-md-1" style="padding-left:1px;">
            <?php if($_SESSION['Logiref_role']!=3):?>
                <a href="#"><span class="fa fa-fw fa-plus-circle text-gray mystyle4"></span></a>
            <?php else:?>
                <a id="Create" href="#"><span class="fa fa-fw fa-plus-circle text-blue mystyle4"></span></a>
            <?php endif;?>
            
            <br/>
        </div>
</div>

<div class="col-md-12">
        <div class="col-md-12">
                <?php if(!empty($reversements)): ?>
                <?php $this->chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th>Reversement</th>
                                <th>Direction</th>
                                <th>Service</th>
                                <th>Montant</th>
                                <th>R&eacute;f&eacuterence</th>
                                <th>Agence</th>
                                <th>Cr&eacute;&eacute; par</th>
                                <th>Statut</th>
                                <th><span class="fa fa-fw fa-folder text-green f14"></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 

                        foreach($reversements as $row){
                        ?>
                            <tr>
                                <td ><b><?php echo ++$i; ?></b></span></td>
                                <td ><?php echo $row->Date_1; ?></td>
                                <td ><?php echo $regies['Regies'][$row->Beneficiaire_10]; ?></td>
                                <td><?php if(isset($row->Service_11) && $row->Service_11="") echo $beneficiaires[$row->Service_11]; ?></td>
                                <td class="text-blue"><?php echo $row->Devise_9.' '.number_format($row->Montant_8,2,","," "); ?></td>
                                <td><?php echo $row->Banqueid_5; ?></td>
                                <td class="text-black"><?php echo ucfirst(strtolower($agences[$row->Agence_15])); ?></td>
                                <td class=""><?php echo $users[$row->Makerid_7]; ?></td>
                                <td class="text-black"><?php echo $status[$row->Status_2]; ?></td>
                                <td >
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-edit font-action-edit text-green  f14"> </span></a>
                                </td>
                            </tr>
                        <?php 

                        } 
                        ?>
                        </tbody>    
                    </table>

                </div>
                <?php $this->chtml->box_body_closing(); ?>
        </div>
        <?php else: ?>
            <section id="cat_list">
                <h4 class="page-header" align="center"><b></b></h4>
                <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                    <span class="fa fa-warning text-gray mystyle4"></span>
                    <br/><br/>
                    Aucun reversement trouv&eacute;
                    <br/><br/>
                </div>
            </section>
        <?php endif;?>
</div>




<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#dgi').html('<?php echo number_format($dgi,2,","," "); ?>');
$('#dgrad').html('<?php echo number_format($dgrad,2,","," "); ?>');
$('#dgda').html('<?php echo number_format($dgda,2,","," "); ?>');
    
    
    var print = "";
     $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        
        var url = '<?php echo base_url($module.'/bank/display/rapport_detailles'); ?>';
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(data){
                    $("#loader").html('');
                    $("#pager").html(data);
                    
                    print = 'details';
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    $("#Create").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/bank/display/wizard_isys'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    });
    
    function view(id) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/isys'); ?>/' + id;
        $.get(url, function (data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });
    }
</script>
