<?php $this->chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $reversement->Id_0; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $reversement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_14" value="<?php echo $reversement->Agence_15; ?>" />
    <input type="hidden" name="Montant_7" value="<?php echo $reversement->Montant_8; ?>" />
    <input type="hidden" name="Devise_8" value="<?php echo $reversement->Devise_9; ?>" />
    <input type="hidden" name="Nombrepaiement_17" value="<?php echo $reversement->Nombrepaiement_22; ?>" />
    <input type="hidden" name="Beneficiaire_9" value="<?php echo $reversement->Beneficiaire_10; ?>" />
    <input type="hidden" name="Service_10" value="<?php echo $reversement->Service_11; ?>" />
    <input type="hidden" name="Typerecette_11" value="<?php echo $reversement->Typerecette_12; ?>" />
    <input type="hidden" name="Designation_13" value="<?php echo $reversement->Designation_14; ?>" />
    <input type="hidden" name="Contrevaleur_15" value="<?php echo $reversement->Contrevaleur_16; ?>" />
    <input type="hidden" name="Reference_isys_16" value="<?php echo $reversement->Reference_isys_17; ?>" />
    
    <table id="" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th>R&eacute;gies</th>
                <th>D&eacute;vise</th>
                <th>Montant</th>
                <th class="text-center">R&eacute;f&eacute;rence ISYS</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $reversement->Beneficiaire_10 ?></td>
                <td><?php echo $reversement->Devise_9; ?></td>
                <td><?php echo $reversement->Montant_8; ?></td>
                <td class="text-center"><?php echo $reversement->Reference_isys_17 ?></td>                      
                <td><?php echo $reversement->Journee_13 ?></td>
            </tr>
        </tbody>    
    </table>
<?php $this->chtml->box_body_closing(); ?>


