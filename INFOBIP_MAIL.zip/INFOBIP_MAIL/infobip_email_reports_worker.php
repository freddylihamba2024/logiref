<?php
/**
 * Infobip Email Delivery Reports Worker (CLI)
 *
 * Fetches delivery reports ("accusés de réception") from Infobip Email API.
 * Note: Infobip delivery reports are one-time fetch (each report is returned only once).
 *
 * Usage examples:
 *   php ikwook_application/libraries/infobip_email_reports_worker.php --once
 *   php ikwook_application/libraries/infobip_email_reports_worker.php --interval=30 --max-loops=0
 *   php ikwook_application/libraries/infobip_email_reports_worker.php --query='{"messageId":"..."}'
 *   php ikwook_application/libraries/infobip_email_reports_worker.php --log-file=/tmp/infobip_reports.jsonl
 */

if (PHP_SAPI !== 'cli') {
	fwrite(STDERR, "This script must be run from CLI.\n");
	exit(2);
}

function argv_value(string $name): ?string {
	global $argv;
	foreach ($argv as $arg) {
		if (str_starts_with($arg, $name . '=')) {
			return substr($arg, strlen($name) + 1);
		}
	}
	return null;
}

function argv_flag(string $name): bool {
	global $argv;
	return in_array($name, $argv, true);
}

function safe_mkdir(string $dir): bool {
	if (is_dir($dir)) return true;
	return @mkdir($dir, 0775, true);
}

function append_jsonl(string $file, array $data): void {
	$fh = @fopen($file, 'ab');
	if ($fh === false) {
		return;
	}

	fwrite($fh, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
	fclose($fh);
}

$once = argv_flag('--once');
$interval = (int) (argv_value('--interval') ?? 30);
$maxLoops = (int) (argv_value('--max-loops') ?? 0);
$queryJson = argv_value('--query') ?? '';
$logFile = argv_value('--log-file');
$noLock = argv_flag('--no-lock');
$dbConn = null;
$trackedMessageId = trim((string)(argv_value('--tracked-message-id') ?? ''));

if ($interval < 1) $interval = 1;
if ($maxLoops < 0) $maxLoops = 0;

// Load config without bootstrapping CodeIgniter.
$appPath = realpath(__DIR__ . '/..');
if ($appPath === false) {
	fwrite(STDERR, "Unable to resolve application path.\n");
	exit(3);
}

$configFile = $appPath . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'infobip.php';
if (!is_file($configFile)) {
	fwrite(STDERR, "Missing config file: {$configFile}\n");
	exit(4);
}

// Minimal BASEPATH to satisfy config file guard.
if (!defined('BASEPATH')) define('BASEPATH', $appPath);

/** @var array $config */
$config = [];
require $configFile;
$cfg = (array)($config['infobip'] ?? []);

$baseUrl = rtrim((string)($cfg['baseUrl'] ?? ''), '/');
$apiKey = (string)($cfg['apiKey'] ?? '');
$reportsPath = (string)($cfg['reportsPath'] ?? '/email/1/reports');
$timeout = (int)($cfg['timeoutSeconds'] ?? 30);
$sslVerify = (bool)($cfg['sslVerify'] ?? true);

if ($baseUrl === '' || $apiKey === '') {
	fwrite(STDERR, "Infobip config missing baseUrl/apiKey in {$configFile}\n");
	exit(5);
}

$query = [];
if ($queryJson !== '') {
	$decoded = json_decode($queryJson, true);
	if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
		fwrite(STDERR, "Invalid --query JSON.\n");
		exit(6);
	}
	$query = $decoded;
}

$logsDir = $appPath . DIRECTORY_SEPARATOR . 'logs';
if (!safe_mkdir($logsDir)) {
	fwrite(STDERR, "Unable to create logs dir: {$logsDir}\n");
	exit(7);
}

if ($logFile === null || $logFile === '') {
	$logFile = $logsDir . DIRECTORY_SEPARATOR . 'infobip_email_reports_' . date('Ymd') . '.jsonl';
}

$dbLogFile = $logsDir . DIRECTORY_SEPARATOR . 'infobip_email_db_updates_' . date('Ymd') . '.jsonl';

// Single instance lock.
$lockHandle = null;
if (!$noLock) {
	$lockFile = $logsDir . DIRECTORY_SEPARATOR . 'infobip_email_reports_worker.lock';
	$lockHandle = @fopen($lockFile, 'c+');
	if ($lockHandle === false) {
		fwrite(STDERR, "Unable to open lock file: {$lockFile}\n");
		exit(8);
	}
	if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
		fwrite(STDERR, "Worker already running (lock busy).\n");
		exit(9);
	}
	ftruncate($lockHandle, 0);
	fwrite($lockHandle, (string)getmypid());
	fflush($lockHandle);
}

function db_connect(string $appPath): ?mysqli {
	$dbFile = $appPath . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'database.php';
	if (!is_file($dbFile)) {
		return null;
	}

	$db = [];
	$active_group = 'default';
	$query_builder = false;
	$active_record = true;
	require $dbFile;

	$cfg = $db['logiref_ebcdc_main'] ?? $db['default'] ?? null;
	if (!is_array($cfg)) {
		return null;
	}

	$port = null;
	$socket = null;
	if (!empty($cfg['hostname']) && strpos($cfg['hostname'], ':') !== false) {
		[$host, $portPart] = explode(':', $cfg['hostname'], 2);
		$cfg['hostname'] = $host;
		if (ctype_digit($portPart)) {
			$port = (int)$portPart;
		}
	}

	$conn = @mysqli_init();
	if (!$conn) {
		return null;
	}

	$host = (string)($cfg['hostname'] ?? 'localhost');
	$user = (string)($cfg['username'] ?? '');
	$pass = (string)($cfg['password'] ?? '');
	$database = (string)($cfg['database'] ?? '');
	$portValue = (int)($port ?? ini_get("mysqli.default_port"));

	$connected = @mysqli_real_connect(
		$conn,
		$host,
		$user,
		$pass,
		$database,
		$portValue,
		$socket
	);

	if (!$connected && $host === 'localhost') {
		$connected = @mysqli_real_connect(
			$conn,
			'127.0.0.1',
			$user,
			$pass,
			$database,
			$portValue,
			null
		);
	}

	if (!$connected) {
		return null;
	}

	$charset = (string)($cfg['char_set'] ?? 'utf8');
	@mysqli_set_charset($conn, $charset);

	return $conn;
}

function db_allowed_statuses(mysqli $dbConn): array {
	$statuses = ['PENDING', 'SENT', 'FAILED', 'DELIVERED', 'UNDELIVERED'];
	$sql = "SHOW COLUMNS FROM `logiref_email_logs` LIKE 'Status_8'";
	$res = @mysqli_query($dbConn, $sql);
	if (!$res) {
		return $statuses;
	}

	$row = mysqli_fetch_assoc($res);
	mysqli_free_result($res);
	$type = $row['Type'] ?? '';
	if (preg_match("/^enum\\((.*)\\)$/i", $type, $matches)) {
		$values = str_getcsv($matches[1], ',', "'");
		$values = array_values(array_filter(array_map(static fn($v) => strtoupper(trim((string)$v)), $values)));
		if (!empty($values)) {
			return $values;
		}
	}

	return $statuses;
}

function normalize_status_for_db(string $status, array $allowedStatuses): string {
	$status = strtoupper(trim($status));
	if (in_array($status, $allowedStatuses, true)) {
		return $status;
	}

	if ($status === 'NOT_DELIVERED' && in_array('UNDELIVERED', $allowedStatuses, true)) {
		return 'UNDELIVERED';
	}

	if (($status === 'NOT_DELIVERED' || $status === 'UNDELIVERED') && in_array('FAILED', $allowedStatuses, true)) {
		return 'FAILED';
	}

	return in_array('PENDING', $allowedStatuses, true) ? 'PENDING' : $allowedStatuses[0];
}

function parse_infobip_datetime(?string $value): ?string {
	if (!is_string($value) || trim($value) === '') {
		return null;
	}

	$dt = DateTime::createFromFormat('Y-m-d\TH:i:s.vO', $value);
	if (!$dt) {
		$ts = strtotime($value);
		return $ts ? date('Y-m-d H:i:s', $ts) : null;
	}

	return $dt->format('Y-m-d H:i:s');
}

function normalize_email_value(?string $value): string {
	if (!is_string($value)) {
		return '';
	}

	return strtolower(trim($value));
}

function split_recipient_emails(?string $value): array {
	if (!is_string($value) || trim($value) === '') {
		return [];
	}

	$parts = preg_split('/[;,]/', $value) ?: [];
	$emails = [];
	foreach ($parts as $part) {
		$email = normalize_email_value($part);
		if ($email !== '') {
			$emails[] = $email;
		}
	}

	return array_values(array_unique($emails));
}

function get_expected_recipient_emails(mysqli $dbConn, string $providerMessageId): array {
	if ($providerMessageId === '') {
		return [];
	}

	$sql = "SELECT `RecipientEmail_3` FROM `logiref_email_logs` WHERE `ProviderMessageId_7` = ? ORDER BY `Id` DESC LIMIT 1";
	$stmt = @mysqli_prepare($dbConn, $sql);
	if (!$stmt) {
		return [];
	}

	@mysqli_stmt_bind_param($stmt, 's', $providerMessageId);
	@mysqli_stmt_execute($stmt);
	$result = @mysqli_stmt_get_result($stmt);
	$row = $result ? mysqli_fetch_assoc($result) : null;
	if ($result) {
		mysqli_free_result($result);
	}
	@mysqli_stmt_close($stmt);

	return split_recipient_emails($row['RecipientEmail_3'] ?? null);
}

function update_email_log_status(mysqli $dbConn, string $providerMessageId, string $status, array $payload = [], ?string $errorMessage = null): bool {
	if ($providerMessageId === '') {
		return false;
	}

	$allowedStatuses = db_allowed_statuses($dbConn);
	$normalizedStatus = normalize_status_for_db($status, $allowedStatuses);
	$sentAt = parse_infobip_datetime($payload['sentAt'] ?? null);
	$responsePayload = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	if ($responsePayload === false) {
		$responsePayload = null;
	}

	$sql = "UPDATE `logiref_email_logs`
		SET `Status_8` = ?,
			`ResponsePayload_10` = ?,
			`ErrorMessage_9` = ?,
			`SentAt_11` = COALESCE(?, `SentAt_11`)
		WHERE `ProviderMessageId_7` = ?";

	$stmt = @mysqli_prepare($dbConn, $sql);
	if (!$stmt) {
		return false;
	}

	@mysqli_stmt_bind_param($stmt, 'sssss', $normalizedStatus, $responsePayload, $errorMessage, $sentAt, $providerMessageId);
	$ok = @mysqli_stmt_execute($stmt);
	@mysqli_stmt_close($stmt);

	return $ok;
}

function infobip_get_reports(string $baseUrl, string $apiKey, string $reportsPath, array $query, int $timeout, bool $sslVerify): array {
	$url = $baseUrl . '/' . ltrim($reportsPath, '/');
	if (!empty($query)) {
		$url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($query);
	}

	$headers = [
		'Authorization: App ' . $apiKey,
		'Accept: application/json',
	];

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	if (!$sslVerify) {
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	}

	$raw = curl_exec($ch);
	$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$error = curl_error($ch);
	curl_close($ch);

	$json = null;
	if (is_string($raw) && $raw !== '') {
		$decoded = json_decode($raw, true);
		if (json_last_error() === JSON_ERROR_NONE) {
			$json = $decoded;
		}
	}

	return [
		'ok' => ($raw !== false) && ($httpCode >= 200 && $httpCode < 300),
		'httpCode' => $httpCode,
		'error' => ($raw === false) ? $error : null,
		'raw' => ($raw === false) ? null : $raw,
		'json' => $json,
		'url' => $url,
	];
}

function extract_reports($json): array {
	if (!is_array($json)) return [];
	if (isset($json['results']) && is_array($json['results'])) return $json['results'];
	if (isset($json['reports']) && is_array($json['reports'])) return $json['reports'];
	if (isset($json[0]) && is_array($json[0])) return $json;
	return [];
}

function report_status(array $report): string {
	$groupName = strtoupper(trim((string)($report['status']['groupName'] ?? '')));
	$name = strtoupper(trim((string)($report['status']['name'] ?? '')));
	if ($groupName === 'DELIVERED' || str_contains($name, 'DELIVERED')) {
		return 'DELIVERED';
	}

	return 'UNDELIVERED';
}

$dbConn = db_connect($appPath);
$deliveryUpdated = false;
$expectedRecipientsCache = [];

if (!($dbConn instanceof mysqli)) {
	append_jsonl($dbLogFile, [
		'ts' => date('c'),
		'worker' => 'infobip_email_reports_worker',
		'level' => 'error',
		'trackedMessageId' => $trackedMessageId,
		'message' => 'Database connection failed in worker; no DB update will be attempted.',
	]);
}

$loops = 0;
do {
	$loops++;
	$res = infobip_get_reports($baseUrl, $apiKey, $reportsPath, $query, $timeout, $sslVerify);

	$lineBase = [
		'ts' => date('c'),
		'ok' => $res['ok'],
		'httpCode' => $res['httpCode'],
		'url' => $res['url'],
	];

	if ($res['ok']) {
		$reports = extract_reports($res['json']);
		// Write one JSON line per report for easy ingestion.
		if (!empty($reports)) {
			$fh = @fopen($logFile, 'ab');
			if ($fh !== false) {
				foreach ($reports as $report) {
					$line = $lineBase + ['report' => $report];
					fwrite($fh, json_encode($line, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
					if (
						$dbConn instanceof mysqli
						&& !empty($report['messageId'])
						&& ($trackedMessageId === '' || $trackedMessageId === (string)$report['messageId'])
					) {
						$providerMessageId = (string)$report['messageId'];
						if (!array_key_exists($providerMessageId, $expectedRecipientsCache)) {
							$expectedRecipientsCache[$providerMessageId] = get_expected_recipient_emails($dbConn, $providerMessageId);
						}

						$reportRecipient = normalize_email_value($report['to'] ?? null);
						$expectedRecipients = $expectedRecipientsCache[$providerMessageId];
						if (!empty($expectedRecipients) && !in_array($reportRecipient, $expectedRecipients, true)) {
							append_jsonl($dbLogFile, [
								'ts' => date('c'),
								'worker' => 'infobip_email_reports_worker',
								'level' => 'info',
								'trackedMessageId' => $trackedMessageId,
								'providerMessageId' => $providerMessageId,
								'reportRecipient' => $reportRecipient,
								'expectedRecipients' => $expectedRecipients,
								'message' => 'Report ignored because recipient is not the primary TO address stored in DB.',
							]);
							continue;
						}

						$status = report_status($report);
						$errorMessage = null;
						if ($status !== 'DELIVERED') {
							$errorMessage = (string)($report['error']['description'] ?? 'Delivery report indicates non-delivered email');
						}
						$updated = update_email_log_status($dbConn, $providerMessageId, $status, $report, $errorMessage);
						append_jsonl($dbLogFile, [
							'ts' => date('c'),
							'worker' => 'infobip_email_reports_worker',
							'level' => $updated ? 'info' : 'error',
							'trackedMessageId' => $trackedMessageId,
							'providerMessageId' => $providerMessageId,
							'reportRecipient' => $reportRecipient,
							'expectedRecipients' => $expectedRecipients,
							'status' => $status,
							'dbUpdateOk' => $updated,
							'errorMessage' => $errorMessage,
						]);
						if ($updated) {
							if ($trackedMessageId !== '' && $trackedMessageId === $providerMessageId) {
								$deliveryUpdated = true;
							}
						}
					}
				}
				fclose($fh);
			} else {
				fwrite(STDERR, "Unable to open log file: {$logFile}\n");
			}
		}
	} else {
		$fh = @fopen($logFile, 'ab');
		if ($fh !== false) {
			$line = $lineBase + ['error' => $res['error'], 'raw' => $res['raw']];
			fwrite($fh, json_encode($line, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
			fclose($fh);
		}
	}

	if ($once) break;
	if ($maxLoops > 0 && $loops >= $maxLoops) break;
	sleep($interval);
} while (true);

if ($trackedMessageId !== '' && !$deliveryUpdated) {
	append_jsonl($logFile, [
		'ts' => date('c'),
		'ok' => true,
		'trackedMessageId' => $trackedMessageId,
		'worker' => 'infobip_email_reports_worker',
		'message' => 'Delivery report not found within polling window; status left unchanged.',
		'loops' => $loops,
	]);
	append_jsonl($dbLogFile, [
		'ts' => date('c'),
		'worker' => 'infobip_email_reports_worker',
		'level' => 'warning',
		'trackedMessageId' => $trackedMessageId,
		'message' => 'No matching delivery report found; database status left unchanged.',
		'loops' => $loops,
	]);
}

if (is_resource($lockHandle)) {
	@flock($lockHandle, LOCK_UN);
	@fclose($lockHandle);
}

if ($dbConn instanceof mysqli) {
	@mysqli_close($dbConn);
}

exit(0);
