<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mail_model extends CI_Model
{
	protected $table = 'logiref_email_logs';
	protected $allowedStatuses = null;

	public function __construct()
	{
		parent::__construct();

		if (isset($this->db) && $this->db) {
			$this->db->close();
			$this->db = null;
		}

		$this->db = $this->load->database('logiref_ebcdc_main', true);
	}

	public function insert_email_log(array $data)
	{
		if (!$this->db->table_exists($this->table)) {
			return false;
		}

		$payload = [
			'Module_1' => $this->limit($data['Module_1'] ?? null, 100),
			'Reference_2' => $this->limit($data['Reference_2'] ?? null, 100),
			'RecipientEmail_3' => $this->limit((string)($data['RecipientEmail_3'] ?? ''), 150),
			'Subject_4' => $this->limit((string)($data['Subject_4'] ?? ''), 255),
			'Message_5' => $data['Message_5'] ?? null,
			'Provider_6' => $this->limit($data['Provider_6'] ?? null, 100),
			'ProviderMessageId_7' => $this->limit($data['ProviderMessageId_7'] ?? null, 150),
			'Status_8' => $this->normalize_status($data['Status_8'] ?? 'PENDING'),
			'ErrorMessage_9' => $data['ErrorMessage_9'] ?? null,
			'ResponsePayload_10' => $this->normalize_payload($data['ResponsePayload_10'] ?? null),
			'SentAt_11' => $data['SentAt_11'] ?? null,
			'PaymentId_14' => $this->normalize_bigint($data['PaymentId_14'] ?? null),
			'NoteNumbers_15' => $data['NoteNumbers_15'] ?? null,
		];

		if ($payload['RecipientEmail_3'] === '' || $payload['Subject_4'] === '') {
			return false;
		}

		$ok = $this->db->insert($this->table, $payload);
		return $ok ? (int)$this->db->insert_id() : false;
	}

	public function save_log(array $data)
	{
		return $this->insert_email_log($this->map_legacy_log($data));
	}

	public function update_email_status_by_provider_message_id($providerMessageId, $status, $responsePayload = null, $errorMessage = null)
	{
		if (!$this->db->table_exists($this->table) || empty($providerMessageId)) {
			return false;
		}

		$update = [
			'Status_8' => $this->normalize_status($status),
			'ResponsePayload_10' => $this->normalize_payload($responsePayload),
			'ErrorMessage_9' => $errorMessage,
		];

		if ($update['Status_8'] === 'DELIVERED') {
			$update['SentAt_11'] = date('Y-m-d H:i:s');
		}

		$this->db->where('ProviderMessageId_7', $providerMessageId);
		return $this->db->update($this->table, $update);
	}

	protected function map_legacy_log(array $data)
	{
		$isSent = !empty($data['Sent_7']);

		return [
			'Module_1' => $data['Type_11'] ?? 'MAIL',
			'Reference_2' => $data['Reference_10'] ?? null,
			'RecipientEmail_3' => $data['Email_6'] ?? '',
			'Subject_4' => $data['Subject_3'] ?? '',
			'Message_5' => $data['Message_4'] ?? null,
			'Provider_6' => $data['Provider_6'] ?? 'APPLICATION',
			'ProviderMessageId_7' => $data['ProviderMessageId_7'] ?? null,
			'Status_8' => $isSent ? 'SENT' : 'FAILED',
			'ErrorMessage_9' => $data['ErrorMessage_9'] ?? null,
			'ResponsePayload_10' => $data['ResponsePayload_10'] ?? null,
			'SentAt_11' => $isSent ? date('Y-m-d H:i:s') : null,
			'PaymentId_14' => $data['PaymentId_14'] ?? null,
			'NoteNumbers_15' => $data['NoteNumbers_15'] ?? ($data['Reference_10'] ?? null),
		];
	}

	protected function normalize_status($status)
	{
		$status = strtoupper(trim((string)$status));
		$allowed = $this->get_allowed_statuses();
		if (in_array($status, $allowed, true)) {
			return $status;
		}

		if ($status === 'NOT_DELIVERED' && in_array('UNDELIVERED', $allowed, true)) {
			return 'UNDELIVERED';
		}

		if (($status === 'NOT_DELIVERED' || $status === 'UNDELIVERED') && in_array('FAILED', $allowed, true)) {
			return 'FAILED';
		}

		return in_array('PENDING', $allowed, true) ? 'PENDING' : $allowed[0];
	}

	protected function normalize_payload($payload)
	{
		if ($payload === null || $payload === '') {
			return null;
		}

		if (is_array($payload) || is_object($payload)) {
			$json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
			return ($json === false) ? null : $json;
		}

		return (string)$payload;
	}

	protected function normalize_bigint($value)
	{
		if ($value === null || $value === '') {
			return null;
		}

		return is_numeric($value) ? (int)$value : null;
	}

	protected function limit($value, $length)
	{
		if ($value === null) {
			return null;
		}

		$value = trim((string)$value);
		if ($value === '') {
			return null;
		}

		return function_exists('mb_substr') ? mb_substr($value, 0, $length) : substr($value, 0, $length);
	}

	protected function get_allowed_statuses()
	{
		if (is_array($this->allowedStatuses)) {
			return $this->allowedStatuses;
		}

		$this->allowedStatuses = ['PENDING', 'SENT', 'FAILED', 'DELIVERED', 'UNDELIVERED'];

		if (!$this->db->table_exists($this->table)) {
			return $this->allowedStatuses;
		}

		$query = $this->db->query("SHOW COLUMNS FROM `{$this->table}` LIKE 'Status_8'");
		$row = $query ? $query->row_array() : null;
		$type = $row['Type'] ?? '';

		if (preg_match("/^enum\\((.*)\\)$/i", $type, $matches)) {
			$values = str_getcsv($matches[1], ',', "'");
			$values = array_values(array_filter(array_map('trim', $values)));
			if (!empty($values)) {
				$this->allowedStatuses = array_map('strtoupper', $values);
			}
		}

		return $this->allowedStatuses;
	}
}
