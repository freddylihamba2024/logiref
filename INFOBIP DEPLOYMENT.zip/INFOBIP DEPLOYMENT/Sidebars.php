<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sidebars {
    /*
     * CodeIgniter Library of:
     * Bootstrap form html
     *
     * Thanks to original author!
     *
     * By Papin d'Eve Mpengele
     *
     * Run as:
     * echo $this->formhtml->input($from_time, $to_time);
     *
     */
    
    /*******************************************************************************************************************************/
    /************************************************  Core             ************************************************************/    
    /*******************************************************************************************************************************/    
 
    function format($items, $skin = NULL) {
        $wrap_open = '<aside class="left-side sidebar-offcanvas skin-project">';
        $wrap_open .= '<section class="sidebar">';
        $wrap_open .= '<ul class="sidebar-menu">';
        $wrap_close = '</ul>';
        $wrap_close .= '</section>';
        $wrap_close .= '</aside>';
        $wrap_body = '';

        $CI = & get_instance();
        $uri_segments = $CI->uri->uri_string();
        unset($CI);

        foreach ($items as $item) {
            if ($uri_segments == $item['url'])
                $is_active = 'class="active"';
            else
                $is_active = '';
            $wrap_body .= '<li ' . $is_active . '>';
            $wrap_body .= '<a href="' . base_url($item['url']) . '">';
            $wrap_body .= '<i class="fa ' . $item['icon'] . '"></i> <span>' . $item['label'] . '</span>';
            $wrap_body .= '</a>';
            $wrap_body .= '</li>';
        }

        return $wrap_open . $wrap_body . $wrap_close;
    }

    function format2levels($items, $submenu, $skin = NULL, $sideTitle = NULL, $sideColor = 'bg-blue', $sideIcon = 'fa fa-fw fa-tag') {
        $wrap_open = '<aside class="left-side sidebar-offcanvas skin-project">';
        $wrap_open .= '<section class="sidebar">';
        if($sideTitle != "")
        {
                $wrap_open .= '<div class="'.$sideColor.' bBottom f16 w50 padding-20"><br/>&nbsp;&nbsp; <i class="'.$sideIcon.' f25"></i>&nbsp;'.$sideTitle.'<br/><br/></div>';
        }
        $wrap_open .= '<ul class="sidebar-menu">';
        $wrap_close = '</ul>';
        $wrap_close .= '</section>';
        $wrap_close .= '</aside>';
        $wrap_body = '';

        $CI = & get_instance();
        $uri_segments = $CI->uri->uri_string();
        unset($CI);

        foreach ($items as $item) {
            $treeview = $item['treeview'];
            if ($treeview == '') {
                $id = '';
                $wrap_body .= '<li class="text-blue"><a href="' . base_url($item['url']) . '"><i class="fa ' . $item['icon'] . '"></i> <span>' . $item['label'] . '</span></a></li>';
            } else {
                $sublist = $submenu[$treeview];
                $wrap_body .='<li class="treeview">';
                $wrap_body .='<a><i class="fa ' . $item['icon'] . '"></i> <span> ' . $item['label'] . '</span></a>';
                $wrap_body .='<ul class="treeview-menu menu-open" style="display: block;">';
                foreach ($sublist as $subitem) {
                    if ($uri_segments == $subitem['url'])
                        $is_active = 'class="active"';
                    else
                        $is_active = '';
                    $id = str_replace(' ', '_', $subitem['label']);
                    $wrap_body .= '<li id="' . $id . '" ' . $is_active . '><a href="' . base_url($subitem['url']) . '"><i class="fa ' . $subitem['icon'] . '"></i> <span>' . $subitem['label'] . '</span></a></li>';
                    $id = '';
                }
                $wrap_body .='</ul>';
                $wrap_body .='</li>';
            }
            $id = '';
        }
        return $wrap_open . $wrap_body . $wrap_close;
    }

    
    /*******************************************************************************************************************************/
    /************************************************ Main              ************************************************************/    
    /*******************************************************************************************************************************/  
    function main_settings() {
        if ($_SESSION['user_lang'] == 'fr') {
            $menu[] = array('label' => 'Compte iKwook', 'icon' => 'fa-clipboard', 'url' => '', 'treeview' => 'Account');
            $submenu['Account'][] = array('label' => 'Manage users', 'icon' => 'fa-users', 'url' => 'main/user/manage');
            $submenu['Account'][] = array('label' => 'Billing information', 'icon' => 'fa-clipboard', 'url' => 'main/billing');
            $submenu['Account'][] = array('label' => 'Manage branches', 'icon' => 'fa-sitemap', 'url' => 'main/site');
            $submenu['Account'][] = array('label' => 'Organize Teams', 'icon' => 'fa-tag', 'url' => 'main/group');
            $submenu['Account'][] = array('label' => 'Account details', 'icon' => 'fa-gear', 'url' => 'main/account');
            $submenu['Account'][] = array('label' => 'My profile', 'icon' => 'fa-user', 'url' => 'main/myprofile');
            $menu[] = array('label' => 'D�connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
        } else {
            $menu[] = array('label' => 'Account', 'icon' => 'fa-clipboard', 'url' => '', 'treeview' => 'Account');
            $submenu['Account'][] = array('label' => 'Manage users', 'icon' => 'fa-users', 'url' => 'main/user/manage');
            $submenu['Account'][] = array('label' => 'Billing information', 'icon' => 'fa-clipboard', 'url' => 'main/billing');
            $submenu['Account'][] = array('label' => 'Manage branches', 'icon' => 'fa-sitemap', 'url' => 'main/site');
            $submenu['Account'][] = array('label' => 'Organize Teams', 'icon' => 'fa-tag', 'url' => 'main/group');
            $submenu['Account'][] = array('label' => 'Account details', 'icon' => 'fa-gear', 'url' => 'main/account');
            $submenu['Account'][] = array('label' => 'My profile', 'icon' => 'fa-user', 'url' => 'main/myprofile');
            $menu[] = array('label' => 'Logout', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
        }
        $html = $this->format2levels($menu, $submenu, NULL);
        echo $html;
    }
    
    function main_manage() 
    {
            if ($_SESSION['user_lang'] == 'fr') 
            {
                    $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-th', 'url' => 'main/manage', 'treeview' => '');
                    $menu[] = array('label' => 'Comptes actifs', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Comptes');
                    $menu[] = array('label' => 'Autres comptes', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Autres');

                    $submenu['Comptes'][] = array('label' => "Business", 'icon' => 'fa-briefcase', 'url' => 'main/manage/set/business');
                    $submenu['Comptes'][] = array('label' => "Entreprises", 'icon' => 'fa-university', 'url' => 'main/manage/set/entreprise');
                    $submenu['Comptes'][] = array('label' => "Personnels", 'icon' => 'fa-user', 'url' => 'main/manage/set/personnal');
                    
                    $submenu['Autres'][] = array('label' => 'Comptes Supprim&eacute;s', 'icon' => 'fa-times-circle', 'url' => 'main/manage/set/delete');
                    $submenu['Autres'][] = array('label' => 'Comptes Expir&eacute;s', 'icon' => 'fa-clock-o', 'url' => 'main/manage/set/expire');
                    
                    $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            } 
            else 
            {
                    $menu[] = array('label' => 'Dashboard', 'icon' => 'fa-th', 'url' => 'main/manage', 'treeview' => '');
                    $menu[] = array('label' => 'List of accounts', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Accounts');
                    $menu[] = array('label' => 'List of activities', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Activity');
                    $menu[] = array('label' => 'List of test accounts', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Essaie');

                    $submenu['Accounts'][] = array('label' => 'All accounts', 'icon' => 'fa-tasks', 'url' => 'main/manage/set/accounts');
                    
                    
                    
                    $submenu['Activity'][] = array('label' => 'Active accounts', 'icon' => 'fa-plus-circle', 'url' => 'main/manage/set/active');
                    $submenu['Activity'][] = array('label' => 'Inactive account', 'icon' => 'fa-plus-circle', 'url' => 'main/manage/set/inactive');
                    $submenu['Activity'][] = array('label' => 'Account deleted', 'icon' => 'fa-plus-circle', 'url' => 'main/manage/set/delete');
                    $submenu['Activity'][] = array('label' => 'User connects', 'icon' => 'fa-plus-circle', 'url' => 'main/manage/set/loggin');

                    
                    $submenu['Essaie'][] = array('label' => 'Open account', 'icon' => 'fa-edit', 'url' => 'main/manage/set/balance');

                    $menu[] = array('label' => 'Logout', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            }
            $html = $this->format2levels($menu, $submenu, NULL);
            echo $html;
    }

    
    
    
    
    /*******************************************************************************************************************************/
    /************************************************  Page          ************************************************************/    
    /*******************************************************************************************************************************/
    function page_settings() 
    {
            if($_SESSION['user_lang']=='fr')
            {
                    $menu[] = array('label'=>'Tableau de bord', 'icon'=>'fa-dashboard','url'=>'finance', 'treeview'=>'');
                    $menu[] = array('label'=>'Rapport financier', 'icon'=>'fa-cog','url'=>'','treeview'=>'manage');
                    $menu[] = array('label'=>'Param&egrave;tres du compte', 'icon'=>'fa-cog','url'=>'','treeview'=>'settings');

                    $submenu['manage'][] = array('label' => 'Intervenants', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/stakeholders');
                    $submenu['manage'][] = array('label' => 'Projets', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/projects');
                    $submenu['manage'][] = array('label' => 'Compte d\'entreprise', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/accounts');
                    $submenu['manage'][] = array('label' => 'Compte de paiements', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/banks');

                    $submenu['settings'][] = array('label'=>'Cat&eacute;gories de revenus', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/incomes');
                    $submenu['settings'][] = array('label'=>'Cat&eacute;gories de d&eacute;penses', 'icon'=>'fa-minus','url'=>'finance/settings/set/expenses');
                    $submenu['settings'][] = array('label'=>'Cat&eacute;gories de participants', 'icon'=>'fa-minus','url'=>'finance/settings/set/interveners');
                    $submenu['settings'][] = array('label'=>'Cat&eacute;gories de  cr&eacute;dits', 'icon'=>'fa-minus','url'=>'finance/settings/set/liabilities');
                    $submenu['settings'][] = array('label'=>'Cat&eacute;gories d\'actifs', 'icon'=>'fa-minus','url'=>'finance/settings/set/assets');

                    $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            }
            else
            {
                    $menu[] = array('label'=>'Dashboard', 'icon'=>'fa-dashboard','url'=>'finance', 'treeview'=>'');
                    $menu[] = array('label'=>'Financial items', 'icon'=>'fa-cog','url'=>'','treeview'=>'manage');
                    $menu[] = array('label'=>'Account settings', 'icon'=>'fa-cog','url'=>'','treeview'=>'settings');

                    $submenu['manage'][] = array('label' => 'Stakeholders', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/stakeholders');
                    $submenu['manage'][] = array('label' => 'Projects', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/projects');
                    $submenu['manage'][] = array('label' => 'Business accounts', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/accounts');
                    $submenu['manage'][] = array('label' => 'Payment accounts', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/banks');

                    $submenu['settings'][] = array('label'=>'Categories of Incomes', 'icon' => 'fa-minus', 'url' => 'finance/settings/set/incomes');
                    $submenu['settings'][] = array('label'=>'Categories of Expenses', 'icon'=>'fa-minus','url'=>'finance/settings/set/expenses');
                    $submenu['settings'][] = array('label'=>'Categories of Stakeholders', 'icon'=>'fa-minus','url'=>'finance/settings/set/interveners');
                    $submenu['settings'][] = array('label'=>'Categories of Liabilities', 'icon'=>'fa-minus','url'=>'finance/settings/set/liabilities');
                    $submenu['settings'][] = array('label'=>'Categories of Assets', 'icon'=>'fa-minus','url'=>'finance/settings/set/assets');

                    $menu[] = array('label' => 'Logout', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            }
            $html = $this->format2levels($menu, $submenu, NULL);
            echo $html;
    }
    
    function page_manage() 
    {
            $submenu = NULL; 
            if ($_SESSION['user_lang'] == 'fr') 
            {
                    $menu[] = array('label' => 'Dashboard', 'icon' => 'fa-dashboard', 'url' => 'relations', 'treeview' => '');
                    $menu[] = array('label' => 'Sales', 'icon' => 'fa fa-shopping-cart', 'url' => '', 'treeview' => '');
                    $menu[] = array('label' => 'Manage', 'icon' => 'fa fa-fw fa-wrench ', 'url' => '', 'treeview' => '');
                    $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            } 
            else 
            {
                    $menu[] = array('label' => 'Dashboard', 'icon' => 'fa-dashboard', 'url' => 'relations', 'treeview' => '');
                    $menu[] = array('label' => 'Sales', 'icon' => 'fa fa-shopping-cart', 'url' => '', 'treeview' => 'Sales');
                    $menu[] = array('label' => 'Manage', 'icon' => 'fa fa-fw fa-wrench ', 'url' => '', 'treeview' => 'Manage');

                    $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            }
            $html = $this->format2levels($menu, $submenu, NULL);
            echo $html;
    }
    
    function page_main() 
    {
        
    }
    
    
    
    
    
    /*******************************************************************************************************************************/
    /************************************************  Logiref          ************************************************************/    
    /*******************************************************************************************************************************/
    function logiref_bank($role = NULL) 
    {
            

            if ($_SESSION['user_type'] == '200') 
            {
                    $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'logiref/dashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Param&egrave;trages', 'icon' => 'fa-cog', 'url' => '', 'treeview' => 'Parametrages');
                    $menu[] = array('label' => 'Gestion des acc&egrave;s', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Access');
                    $menu[] = array('label' => 'Monitoring', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Monitoring');
            
                    $submenu['Parametrages'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-trello', 'url' => 'logiref/accounts/set/comptes');
                    $submenu['Parametrages'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-cog', 'url' => 'logiref/fees/set/regles');
                    $submenu['Parametrages'][] = array('label' => 'Agences bancaires', 'icon' => 'fa-bank', 'url' => 'logiref/branches/set/guichets');
                      
                 
                    $submenu['Access'][] = array('label' => 'Comptes utilisateurs', 'icon' => 'fa-users', 'url' => 'logiref/users/set/privileges');
                    $submenu['Access'][] = array('label' => 'Plateformes des r&eacute;gies', 'icon' => 'fa-cloud', 'url' => 'logiref/settings/set/settings_regies');
                    $submenu['Access'][] = array('label' => 'Plateformes de la BCC', 'icon' => 'fa-book', 'url' => 'logiref/settings/set/settings_bcc');
                    
                    $submenu['Monitoring'][] = array('label' => 'Logs des int&eacute;grations', 'icon' => 'fa-window-maximize', 'url' => 'logiref/settings/set/integrations');
                    $submenu['Monitoring'][] = array('label' => 'Logs des op&eacute;rations', 'icon' => 'fa-wpforms', 'url' => 'logiref/reports/set/rapport');
            } 
            else 
            {
                    if ($role == 2) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'logiref/dashboards/set/overview', 'treeview' => '');
                            $menu[] = array('label' => 'Op&eacute;rations', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Param&eacute;trages', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                    
                            $submenu['Edition'][] = array('label' => 'Validation des paiements', 'icon' => 'fa-credit-card', 'url' => 'logiref/reports/set/nvalidated');
                            $submenu['Edition'][] = array('label' => 'Reversement paiements', 'icon' => 'fa-server', 'url' => 'logiref/reports/set/validated');
                            $submenu['Edition'][] = array('label' => 'Rapport des passports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/rapport');
							$submenu['Edition'][] = array('label' => 'Autres rapports', 'icon' => 'fa-list', 'url' => 'logiref/reports/set/rapport');
                            
                            $submenu['Consultation'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-trello', 'url' => 'logiref/accounts/set/comptes/settings');
                            $submenu['Consultation'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-list-ol', 'url' => 'logiref/fees/set/regles');
                            $submenu['Consultation'][] = array('label' => 'Autres param&eacute;trages', 'icon' => 'fa-cog', 'url' => 'logiref/settings/set/settings');
                    } 
                    elseif ($role == 3) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'logiref/dashboards/set/overview', 'treeview' => '');
                            $menu[] = array('label' => 'Edition', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Consultation', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                            
                            $submenu['Edition'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'logiref/rates/set/list');
                            $submenu['Edition'][] = array('label' => 'Validation des paiements', 'icon' => 'fa-credit-card', 'url' => 'logiref/reports/set/nvalidated');
                            $submenu['Edition'][] = array('label' => 'Reversements ISYS', 'icon' => 'fa-server', 'url' => 'logiref/reports/set/validated');
                            
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-briefcase', 'url' => 'logiref/reports/set/transferred');
                            $submenu['Consultation'][] = array('label' => 'Rapport de paiements', 'icon' => 'fa-clipboard', 'url' => 'logiref/reports/set/reports');
							$submenu['Consultation'][] = array('label' => 'Rapport des passports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/passports');
                            $submenu['Consultation'][] = array('label' => 'Rapports', 'icon' => 'fa-list', 'url' => 'logiref/reports/set/rapport');
                           
                    } 
                    elseif ($role == 4) 
                    {
                            $menu[] = array('label' => 'Tableau de board', 'icon' => 'fa-dashboard', 'url' => 'logiref', 'treeview' => '');
                            $menu[] = array('label' => 'Nouveau..', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Consultation', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Consultation');
                            
                            $submenu['Edition'][] = array('label' => 'Paiement comptant', 'icon' => 'fa-calculator', 'url' => 'logiref/bank/set/comptant');
                            $submenu['Edition'][] = array('label' => 'Bulletin de liquidation', 'icon' => 'fa-dot-circle-o', 'url' => 'logiref/bank/set/bulletins');
                            $submenu['Edition'][] = array('label' => 'D&eacute;claration DGI', 'icon' => 'fa-clipboard', 'url' => 'logiref/bank/set/declarations');
                            $submenu['Edition'][] = array('label' => 'Note de perception', 'icon' => 'fa-puzzle-piece', 'url' => 'logiref/bank/set/notes');
                            $submenu['Edition'][] = array('label' => 'Ordres des paiements', 'icon' => 'fa-list-alt', 'url' => 'logiref/bank/set/ordres');
                            $submenu['Edition'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'logiref/bank/set/list');
                            
						
                            $submenu['Consultation'][] = array('label' => 'Paiements en cours', 'icon' => 'fa-credit-card', 'url' => 'logiref/bank/set/encaissements');
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-send', 'url' => 'logiref/bank/set/reversements');
                            $submenu['Consultation'][] = array('label' => 'Guichet Unique DGDA', 'icon' => 'fa-bank', 'url' => 'logiref/bank/set/gudouane');
                            $submenu['Consultation'][] = array('label' => 'Rapports', 'icon' => 'fa-bar-chart', 'url' => 'logiref/bank/set/reports');

                    }
                    elseif ($role == 5) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'logiref/dashboards/set/overview', 'treeview' => '');
                            
                            $menu[] = array('label' => 'Op&eacute;rations en cours..', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                            $menu[] = array('label' => 'Autres rapports', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapports');
                            
                            $submenu['Consultation'][] = array('label' => 'Paiements non valid&eacute;s', 'icon' => 'fa-credit-card', 'url' => 'logiref/reports/set/nvalidated');
                            $submenu['Consultation'][] = array('label' => 'Paiements valid&eacute;s', 'icon' => 'fa-server', 'url' => 'logiref/reports/set/pending');
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-briefcase', 'url' => 'logiref/reports/set/transferred');
                            
                            
                            $submenu['Rapports'][] = array('label' => 'Rapport de paiements', 'icon' => 'fa-clipboard', 'url' => 'logiref/reports/set/reports');
                            $submenu['Rapports'][] = array('label' => 'Rapport de commissions', 'icon' => 'fa-list-ol', 'url' => 'logiref/reports/set/commissions');
                            $submenu['Rapports'][] = array('label' => 'Retard de reversement', 'icon' => 'fa-file-powerpoint-o', 'url' => 'logiref/reports/set/penalities');
                            $submenu['Rapports'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'logiref/reports/set/list');
							$submenu['Rapports'][] = array('label' => 'Autres rapports', 'icon' => 'fa-list', 'url' => 'logiref/reports/set/rapport');
                    }
            }
            
            $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            $html = $this->format2levels($menu, $submenu, NULL, " iKwook Logiref ", "bg-yellow", "fa fa-recycle");
            
            echo $html;
    }
    
    function logiref_ebcdc($role = NULL) 
    {
            
             if ($_SESSION['user_type'] == '200') 
            {
                    $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'ebcdc/dashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Param&egrave;trages', 'icon' => 'fa-cog', 'url' => '', 'treeview' => 'Parametrages');
                    $menu[] = array('label' => 'Gestion des acc&egrave;s', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Access');
                    $menu[] = array('label' => 'Monitoring', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Monitoring');
            
                    $submenu['Parametrages'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-trello', 'url' => 'ebcdc/accounts/set/comptes');
                    $submenu['Parametrages'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-cog', 'url' => 'ebcdc/fees/set/regles');
                    $submenu['Parametrages'][] = array('label' => 'Agences bancaires', 'icon' => 'fa-bank', 'url' => 'ebcdc/branches/set/guichets');
                    $submenu['Parametrages'][] = array('label' => 'Tarifications pr&eacute;f&eacute;rentielles', 'icon' => 'fa-cogs', 'url' => 'ebcdc/accounts/set/tarification_accounts');
					$submenu['Parametrages'][] = array('label' => "Recettes", 'icon' => 'fa-plus-circle', 'url' => 'ebcdc/settings/set/recettes');
                    $submenu['Parametrages'][] = array('label' => "Services", 'icon' => 'fa-book', 'url' => 'ebcdc/settings/set/services'); 
                    //$submenu['Parametrages'][] = array('label' => "B&eacuteneficaires", 'icon' => 'fa-cloud', 'url' => 'ebcdc/settings/set/beneficiaries'); 
                    $submenu['Parametrages'][] = array('label' => "Provinces/Villes", 'icon' => 'fa-folder-open', 'url' => 'ebcdc/settings/set/villes'); 
                    $submenu['Parametrages'][] = array('label' => 'Adresse IP bloqu&eacute;e', 'icon' => 'fa-adjust', 'url' => 'ebcdc/settings/set/ipaddress'); 
                 
                    $submenu['Access'][] = array('label' => 'Comptes utilisateurs', 'icon' => 'fa-users', 'url' => 'ebcdc/users/set/privileges');
                    $submenu['Access'][] = array('label' => 'Plateformes des r&eacute;gies', 'icon' => 'fa-cloud', 'url' => 'ebcdc/settings/set/settings_regies');
                    $submenu['Access'][] = array('label' => 'Plateformes de la BCC', 'icon' => 'fa-book', 'url' => 'ebcdc/settings/set/settings_bcc');
                    
                    $submenu['Monitoring'][] = array('label' => 'Logs des int&eacute;grations', 'icon' => 'fa-window-maximize', 'url' => 'ebcdc/settings/set/integrations');
                    $submenu['Monitoring'][] = array('label' => 'Logs des op&eacute;rations', 'icon' => 'fa-wpforms', 'url' => 'ebcdc/reports/set/rapport');
                    $submenu['Monitoring'][] = array('label' => 'Logs des emails', 'icon' => 'fa-envelope-o', 'url' => 'ebcdc/email_logs/set/logs');
            } 
            else 
            {
                    if ($role == 2) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'ebcdc/dashboards/set/overview', 'treeview' => '');
                            $menu[] = array('label' => 'Op&eacute;rations', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Param&eacute;trages', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                    
                            $submenu['Edition'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'ebcdc/rates/set/list');
                            $submenu['Edition'][] = array('label' => 'Validation des paiements', 'icon' => 'fa-credit-card', 'url' => 'ebcdc/reports/set/nvalidated');
                            $submenu['Edition'][] = array('label' => 'Reversement paiements', 'icon' => 'fa-server', 'url' => 'ebcdc/reports/set/validated');
                            $submenu['Edition'][] = array('label' => 'Rapport des passports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/paiements_passports');
							$submenu['Edition'][] = array('label' => 'Autres rapports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/rapport');
                            
                            $submenu['Consultation'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-trello', 'url' => 'ebcdc/accounts/set/comptes/settings');
                            $submenu['Consultation'][] = array('label' => 'Tarifications pr&eacute;f&eacute;rentielles', 'icon' => 'fa-cogs', 'url' => 'ebcdc/accounts/set/tarification_accounts');
                            $submenu['Consultation'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-list-ol', 'url' => 'ebcdc/fees/set/regles');
                            $submenu['Consultation'][] = array('label' => 'Autres param&eacute;trages', 'icon' => 'fa-cog', 'url' => 'ebcdc/settings/set/settings');
                    } 
                    elseif ($role == 3) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'ebcdc/dashboards/set/overview', 'treeview' => '');
                            $menu[] = array('label' => 'Edition', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Consultation', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                            
                            $submenu['Edition'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'ebcdc/rates/set/list');
                            $submenu['Edition'][] = array('label' => 'Validation des paiements', 'icon' => 'fa-credit-card', 'url' => 'ebcdc/reports/set/nvalidated');
			$submenu['Edition'][] = array('label' => 'Validation des passeports', 'icon' => 'fa-calculator', 'url' => 'ebcdc/reports/set/nvalidatedpassports');
                            $submenu['Edition'][] = array('label' => 'Acc&egrave;s Sydonia', 'icon' => 'fa fa-cogs', 'url' => 'ebcdc/users/set/accountsydonia');
                            $submenu['Edition'][] = array('label' => 'Validation des prepaiements', 'icon' => 'fa-credit-card-alt', 'url' => 'ebcdc/reports/set/prepaids');
                            $submenu['Edition'][] = array('label' => 'Validation en lot', 'icon' => 'fa-clone', 'url' => 'ebcdc/reports/set/batchs');
                            $submenu['Edition'][] = array('label' => 'Regularisations', 'icon' => 'fa-refresh', 'url' => 'ebcdc/equalize/set/unequalized');
							$submenu['Edition'][] = array('label' => 'Regularisations passeports', 'icon' => 'fa-refresh', 'url' => 'ebcdc/equalize/set/unequalizedpassports');
                            $submenu['Edition'][] = array('label' => 'Reversements ISYS', 'icon' => 'fa-server', 'url' => 'ebcdc/reports/set/validated');
                            $submenu['Edition'][] = array('label' => 'ISYS passeports ', 'icon' => 'fa-server', 'url' => 'ebcdc/reports/set/validatedpassport');
							
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-briefcase', 'url' => 'ebcdc/reports/set/transferred');
                            $submenu['Consultation'][] = array('label' => 'Rapport de paiements', 'icon' => 'fa-clipboard', 'url' => 'ebcdc/reports/set/reports');
							$submenu['Consultation'][] = array('label' => 'Rapport des passports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/passports');
							$submenu['Consultation'][] = array('label' => 'Rapport CashCloud', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/online-taxes');
                            $submenu['Consultation'][] = array('label' => 'Rapports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/rapport');
                           
                    } 
                    elseif ($role == 4) 
                    {
                            $menu[] = array('label' => 'Tableau de board', 'icon' => 'fa-dashboard', 'url' => 'ebcdc', 'treeview' => '');
                            $menu[] = array('label' => 'Nouveau..', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Edition');
                            $menu[] = array('label' => 'Consultation', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Consultation');
                            
                            $submenu['Edition'][] = array('label' => 'Paiement comptant', 'icon' => 'fa-calculator', 'url' => 'ebcdc/bank/set/comptant');
                            $submenu['Edition'][] = array('label' => 'Bulletin de liquidation', 'icon' => 'fa-dot-circle-o', 'url' => 'ebcdc/bank/set/bulletins');
                            $submenu['Edition'][] = array('label' => 'D&eacute;claration DGI', 'icon' => 'fa-clipboard', 'url' => 'ebcdc/bank/set/declarations');
                            $submenu['Edition'][] = array('label' => 'Note de perception', 'icon' => 'fa-puzzle-piece', 'url' => 'ebcdc/bank/set/notes');
                            $submenu['Edition'][] = array('label' => 'Ordres des paiements', 'icon' => 'fa-list-alt', 'url' => 'ebcdc/bank/set/ordres');
                            $submenu['Edition'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'ebcdc/bank/set/list');
                            
                            $submenu['Consultation'][] = array('label' => 'Paiements en cours', 'icon' => 'fa-credit-card', 'url' => 'ebcdc/bank/set/encaissements');
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-send', 'url' => 'ebcdc/bank/set/reversements');
                            $submenu['Consultation'][] = array('label' => 'Guichet Unique DGDA', 'icon' => 'fa-bank', 'url' => 'ebcdc/bank/set/gudouane');
                            $submenu['Consultation'][] = array('label' => 'Rapports', 'icon' => 'fa-bar-chart', 'url' => 'ebcdc/bank/set/reports');

                    }
                    elseif ($role == 5) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'ebcdc/dashboards/set/overview', 'treeview' => '');
                            
                            $menu[] = array('label' => 'Op&eacute;rations en cours..', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                            $menu[] = array('label' => 'Autres rapports', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapports');
                            
                            $submenu['Consultation'][] = array('label' => 'Paiements non valid&eacute;s', 'icon' => 'fa-credit-card', 'url' => 'ebcdc/reports/set/nvalidated');
                            $submenu['Consultation'][] = array('label' => 'Paiements valid&eacute;s', 'icon' => 'fa-server', 'url' => 'ebcdc/reports/set/pending');
                            $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-briefcase', 'url' => 'ebcdc/reports/set/transferred');
                            
                            
                            $submenu['Rapports'][] = array('label' => 'Rapport de paiements', 'icon' => 'fa-clipboard', 'url' => 'ebcdc/reports/set/reports');
                            $submenu['Rapports'][] = array('label' => 'Rapport de commissions', 'icon' => 'fa-list-ol', 'url' => 'ebcdc/reports/set/commissions');
                            $submenu['Rapports'][] = array('label' => 'Retard de reversement', 'icon' => 'fa-file-powerpoint-o', 'url' => 'ebcdc/reports/set/penalities');
                            $submenu['Rapports'][] = array('label' => 'Taux de change', 'icon' => 'fa-tags', 'url' => 'ebcdc/reports/set/list');
							$submenu['Rapports'][] = array('label' => 'Autres rapports', 'icon' => 'fa-list', 'url' => 'ebcdc/reports/set/rapport');
                    }
					elseif ($role == 6) 
                    {
                            $menu[] = array('label' => 'Tableau de bord', 'icon' => 'fa-dashboard', 'url' => 'ebcdc/dashboards/set/overview', 'treeview' => '');
                            
                            $menu[] = array('label' => 'Op&eacute;rations en cours..', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                            $menu[] = array('label' => 'Autres rapports', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapports');
                            
							
                            $submenu['Consultation'][] = array('label' => 'Paiements valid&eacute;s', 'icon' => 'fa-server', 'url' => 'ebcdc/reports/set/pending');
                           
							$submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa-briefcase', 'url' => 'ebcdc/reports/set/transferred');

							
							$submenu['Rapports'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-credit-card', 'url' => 'ebcdc/reports/set/comptes');
							$submenu['Rapports'][] = array('label' => 'Grille tarifaire', 'icon' => 'fa-briefcase', 'url' => 'ebcdc/reports/set/commissions');
                            $submenu['Rapports'][] = array('label' => 'Utilisateurs', 'icon' => 'fa-briefcase', 'url' => 'ebcdc/reports/set/report_users');
                            $submenu['Rapports'][] = array('label' => 'Rapports', 'icon' => 'fa-clipboard', 'url' => 'ebcdc/reports/set/report_payments');
							
                    }
            }
            
            $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');
            $html = $this->format2levels($menu, $submenu, NULL, " iKwook Logiref ", "bg-yellow", "fa fa-recycle");
            
            echo $html;
    }
    
    
    function logiref_clients($role = NULL) 
    {
            $menu[] = array('label' => 'Accueil', 'icon' => 'fa-home', 'url' => 'logiref/clients/', 'treeview' => '');
            $menu[] = array('label' => 'Nouveau...', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Nouveau');
            $menu[] = array('label' => 'Consultation', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Consultation');

            $submenu['Nouveau'][] = array('label' => "Ordres de paiement", 'icon' => 'fa-plus-circle', 'url' => 'logiref/clients/set/ordres');
            $submenu['Nouveau'][] = array('label' => 'D&eacute;clarations d\'imp&ocirc;ts', 'icon' => 'fa-plus-circle', 'url' => 'logiref/clients/set/declarations');
            $submenu['Nouveau'][] = array('label' => 'Notes de perception ', 'icon' => 'fa-plus-circle', 'url' => 'logiref/clients/set/notes');
            $submenu['Nouveau'][] = array('label' => 'Bulletins de liquidation', 'icon' => 'fa-plus-circle', 'url' => 'logiref/clients/set/bulletins');

            $submenu['Consultation'][] = array('label' => "Tous les paiements", 'icon' => 'fa-folder-open', 'url' => 'logiref/clients/set/paiements');
            $submenu['Consultation'][] = array('label' => 'P&eacute;nalit&eacute;s & amendes', 'icon' => 'fa-folder-open', 'url' => 'logiref/clients/set/penalites');
            $submenu['Consultation'][] = array('label' => 'Services de recrouvrement', 'icon' => 'fa-folder-open', 'url' => 'logiref/clients/set/services');
            $submenu['Consultation'][] = array('label' => 'Types de recettes', 'icon' => 'fa-folder-open', 'url' => 'logiref/clients/set/recettes');

            $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');

            $html = $this->format2levels($menu, $submenu, NULL, " iKwook Logiref ", "bg-orange", "fa fa-recycle");
            echo $html;
    }
    
    function logiref_regies($role = NULL) 
    {
            $menu[] = array('label' => 'Accueil', 'icon' => 'fa-home', 'url' => 'logiref/regies/', 'treeview' => '');
            $menu[] = array('label' => 'Nouveau...', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Nouveau');
            $menu[] = array('label' => 'T&eacute;l&eacute;-procedures', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'edition');
            $menu[] = array('label' => 'Param&egrave;trages', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'settings');
            
            $submenu['Nouveau'][] = array('label' => "D&eacute;nonciations de la fraude", 'icon' => 'fa-plus-circle', 'url' => 'logiref/regies/set/denonciations');
            $submenu['Nouveau'][] = array('label' => "R&eacute;clamations", 'icon' => 'fa-plus-circle', 'url' => 'logiref/regies/set/reclamations');
            

            if($_SESSION['Logiref_regies']== 'DGI')
            {
                    $submenu['Nouveau'][] = array('label' => 'Contribuables non-identifi&eacute;s', 'icon' => 'fa-plus-circle', 'url' => 'logiref/regies/set/prospects');
                    $submenu['Nouveau'][] = array('label' => 'Demandes d\'assujet. TVA', 'icon' => 'fa-plus-circle', 'url' => 'logiref/regies/set/assujettissements');
                    $submenu['edition'][] = array('label' => 'T&eacute;l&eacute;-d&eacute;clarations', 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/declarations');
            }
            if($_SESSION['Logiref_regies']== 'DGRAD')
            {
                    $submenu['edition'][] = array('label' => 'Notes de perception ', 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/notes');
            }
            if($_SESSION['Logiref_regies']== 'DGDA')
            {
                    $submenu['edition'][] = array('label' => 'Pr&eacute;paiements & cr&eacute;dits', 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/prepaiements');
            }
            $submenu['edition'][] = array('label' => "Ordres de paiements", 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/ordres');
            $submenu['edition'][] = array('label' => 'T&eacute;l&eacute;-paiements confirm&eacute;s', 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/reportings');
            $submenu['edition'][] = array('label' => "Encaissements journaliers", 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/encaissements');
            $submenu['edition'][] = array('label' => 'Missions de contr&ocirc;les', 'icon' => 'fa-edit', 'url' => 'logiref/regies/set/missions');
            
            $submenu['settings'][] = array('label' => 'R&egrave;gles des p&eacute;nalit&eacute;s', 'icon' => 'fa-gear', 'url' => 'logiref/regies/set/penalites');
            $submenu['settings'][] = array('label' => 'Services de recrouvrement', 'icon' => 'fa-gear', 'url' => 'logiref/regies/set/services');
            $submenu['settings'][] = array('label' => 'Types de recettes', 'icon' => 'fa-gear', 'url' => 'logiref/regies/set/recettes');
            
            $menu[] = array('label' => 'D&eacute;connexion', 'icon' => 'fa-sign-out', 'url' => 'main/user/logout', 'treeview' => '');

            $html = $this->format2levels($menu, $submenu, NULL, " iKwook Logiref ", "bg-orange", "fa fa-recycle");
            echo $html;
            
            

    }
    
    
    
}

?>
