<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Email_logs extends MY_Controller
{
	public $menus = array('logs');
	public $roles = '5';
	public $group = 'banks';
	public $module = 'ebcdc';
	public $folder = 'email_logs';

	public function __construct()
	{
		parent::__construct();

		$this->load->model('MY_Logiref_Ebcdc');
		$this->load->model('MY_Logiref_Main');
		$this->load->model('MY_Main');
		$this->load->model('main/main_model');
		$this->load->model('logiref/logiref_model');
		$this->load->model('Mail_model', 'mail_model');
		$this->load->library('infobip');

		$user_roles = $this->session->userdata('user_roles');

		$this->data['module'] = $this->module;
		$this->data['application'] = 'email_logs';
		$this->data['function'] = '';
		$this->data['role'] = $_SESSION['Logiref_role'];
		$this->data['sidebar'] = 'bank';
		$this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
		$this->data['folder'] = $this->folder;
		$this->data['group'] = $this->group;
		$this->data['documents'] = $this->logiref_model->documents;
		$this->data['devises'] = $this->logiref_model->devises;
		$this->data['modes'] = $this->logiref_model->modes;
		$this->data['moyens'] = $this->logiref_model->moyens;
		$this->data['infos'] = $this->logiref_model->infos;
		$this->data['currency'] = $this->session->userdata('account_currency');
		$this->data['fullname'] = $this->session->userdata('user_fname');
		$this->data['userid'] = $this->session->userdata('user_id');
		$this->data['i'] = 0;

		if (!isset($_SESSION['Logiref_privileges'])) {
			$this->data("set_privilegies");
		} elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
			$this->roles = json_decode($user_roles['Logiref_privileges'], true);
		}

		if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
			$this->group = $_SESSION['Logiref_groupe'];
			$this->role = $_SESSION['Logiref_role'];
		} else {
			redirect($this->module, 'refresh');
		}
	}

	public function attachment($id = null)
	{
		$this->stream_attachment($id);
	}

	public function resend($id = null)
	{
		$this->resend_email_log($id);
	}

	public function index()
	{
		$this->data['subview'] = 'container';
		$this->load->view('_layout_' . $this->module, $this->data);
	}

	public function set($needle)
	{
		if (in_array($needle, $this->menus)) {
			$this->index();
		}
	}

	public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
	{
		if ($obj == 'logs') {
			$filters = $this->get_filters();
			$this->data['filters'] = $filters;
			$this->data['logs'] = $this->mail_model->get_email_logs($filters, 250);
			$this->data['summary'] = $this->mail_model->get_email_logs_summary($filters);
			$this->data['modules_filter'] = $this->mail_model->get_distinct_values('Module_1');
			$this->data['providers_filter'] = $this->mail_model->get_distinct_values('Provider_6');
			$this->data['statuses_filter'] = $this->mail_model->get_distinct_values('Status_8');
			$this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/logs', $this->data);
		} elseif ($obj == 'filter') {
			$filters = $this->get_filters(true);
			$this->data['filters'] = $filters;
			$this->data['logs'] = $this->mail_model->get_email_logs($filters, 250);
			$this->data['summary'] = $this->mail_model->get_email_logs_summary($filters);
			$this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_results', $this->data);
		} elseif ($obj == 'attachment') {
			$this->stream_attachment($id);
		}
	}

	public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
	{
		if ($obj === 'resend') {

			$this->resend_email_log($id);
			return;
		}
		show_404();
	}

	protected function get_filters($fromPost = false)
	{
		$source = $fromPost ? $_POST : $_GET;

		return [
			'search' => trim((string)($source['search'] ?? '')),
			'status' => trim((string)($source['status'] ?? '')),
			'module' => trim((string)($source['module'] ?? '')),
			'provider' => trim((string)($source['provider'] ?? '')),
			'date_from' => trim((string)($source['date_from'] ?? '')),
			'date_to' => trim((string)($source['date_to'] ?? '')),
		];
	}

	protected function stream_attachment($id = null)
	{
		$log = $this->mail_model->get_email_log_by_id($id);
		if (!$log || empty($log->AttachmentPath_16) || !is_file($log->AttachmentPath_16) || !is_readable($log->AttachmentPath_16)) {
			show_404();
			return;
		}

		$path = $log->AttachmentPath_16;
		$filename = basename($path);
		$mime = function_exists('mime_content_type') ? mime_content_type($path) : 'application/octet-stream';
		if (!$mime) {
			$mime = 'application/octet-stream';
		}

		$this->output->set_header('Content-Description: File Transfer');
		$this->output->set_header('Content-Type: ' . $mime);
		$this->output->set_header('Content-Disposition: attachment; filename="' . $filename . '"');
		$this->output->set_header('Content-Length: ' . filesize($path));
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
		$this->output->set_header('Pragma: public');
		$this->output->set_output(file_get_contents($path));
	}

	protected function resend_email_log($id = null)
	{
		$this->append_resend_trace([
			'stage' => 'entry',
			'requestedId' => $id,
			'userId' => $this->session->userdata('user_id'),
			'requestMethod' => $_SERVER['REQUEST_METHOD'] ?? null,
			'isAjax' => $this->input->is_ajax_request(),
		]);

		$log = $this->mail_model->get_email_log_by_id($id);
		if (!$log) {
			$this->append_resend_trace([
				'stage' => 'log_not_found',
				'requestedId' => $id,
			]);
			$this->respond_json(['ok' => false, 'message' => 'Log introuvable']);
			return;
		}

		$attachments = [];
		if (!empty($log->AttachmentPath_16) && is_file($log->AttachmentPath_16) && is_readable($log->AttachmentPath_16)) {
			$attachments[] = $log->AttachmentPath_16;
		}

		$recipients = $this->extract_recipients_from_log($log);
		if (empty($recipients)) {
			$this->append_resend_trace([
				'stage' => 'no_recipients',
				'requestedId' => $id,
				'originalLogId' => $log->Id ?? null,
			]);
			$this->respond_json(['ok' => false, 'message' => 'Aucun destinataire valide']);
			return;
		}

		$from = 'passeport@equitybcdc.cd';
		$sendRes = null;
		$trackingRes = null;
		$providerMessageId = null;
		$wasSent = false;
		$errorMessage = null;

		try {
			$sendRes = $this->infobip->sendEmail(
				$from,
				$recipients,
				(string)$log->Subject_4,
				strip_tags((string)$log->Message_5),
				(string)$log->Message_5,
				$attachments,
				[],
				[],
				[],
				'success'
			);

			$wasSent = (bool)($sendRes['ok'] ?? false);
			$providerMessageId = $sendRes['messageId'] ?? null;
			$errorMessage = $sendRes['error'] ?? null;
			$this->append_resend_trace([
				'stage' => 'after_send',
				'requestedId' => $id,
				'originalLogId' => $log->Id ?? null,
				'ok' => $wasSent,
				'providerMessageId' => $providerMessageId,
				'httpCode' => $sendRes['httpCode'] ?? null,
				'error' => $errorMessage,
			]);

		} catch (Throwable $e) {
			$sendRes = [
				'ok' => false,
				'exception' => get_class($e),
				'message' => $e->getMessage(),
			];
			$errorMessage = $e->getMessage();
			$this->append_resend_trace([
				'stage' => 'send_exception',
				'requestedId' => $id,
				'originalLogId' => $log->Id ?? null,
				'exception' => get_class($e),
				'message' => $e->getMessage(),
			]);
		}

		$newLogId = $this->mail_model->insert_email_log([
			'Module_1' => $log->Module_1 ? $log->Module_1 . '_RESEND' : 'MAIL_RESEND',
			'Reference_2' => $log->Reference_2,
			'RecipientEmail_3' => implode(',', $recipients),
			'Subject_4' => $log->Subject_4,
			'Message_5' => $log->Message_5,
			'Provider_6' => 'INFOBIP',
			'ProviderMessageId_7' => $providerMessageId,
			'Status_8' => $wasSent ? 'SENT' : 'FAILED',
			'ErrorMessage_9' => $errorMessage,
			'ResponsePayload_10' => $sendRes,
			'SentAt_11' => $wasSent ? date('Y-m-d H:i:s') : null,
			'PaymentId_14' => $log->PaymentId_14,
			'NoteNumbers_15' => $log->NoteNumbers_15,
			'AttachmentPath_16' => $log->AttachmentPath_16,
		]);
		$this->append_resend_trace([
			'stage' => 'after_insert',
			'requestedId' => $id,
			'originalLogId' => $log->Id ?? null,
			'newLogId' => $newLogId,
			'status' => $wasSent ? 'SENT' : 'FAILED',
			'providerMessageId' => $providerMessageId,
		]);

		if ($wasSent && !empty($providerMessageId)) {
			$trackingRes = $this->infobip->launchDeliveryTrackingWorker($providerMessageId);
			$this->append_resend_trace([
				'stage' => 'tracking_started',
				'requestedId' => $id,
				'originalLogId' => $log->Id ?? null,
				'newLogId' => $newLogId,
				'providerMessageId' => $providerMessageId,
				'tracking' => $trackingRes,
			]);
		}

		$message = $wasSent ? 'Email renvoye avec succes' : ($errorMessage ? 'Echec du renvoi: ' . $errorMessage : 'Echec du renvoi du mail');

		$payload = [
			'ok' => $wasSent,
			'message' => $message,
			'logId' => $newLogId,
			'providerMessageId' => $providerMessageId,
			'tracking' => $trackingRes,
			'response' => $sendRes,
		];
		$this->respond_json($payload);
	}

	protected function extract_recipients_from_log($log)
	{
		$emails = array_values(array_filter(array_map('trim', preg_split('/[;,]/', (string)$log->RecipientEmail_3))));
		if (!empty($emails)) {
			return $emails;
		}

		$payload = json_decode((string)$log->ResponsePayload_10, true);
		if (!is_array($payload) || empty($payload['json']['messages']) || !is_array($payload['json']['messages'])) {
			return [];
		}

		foreach ($payload['json']['messages'] as $message) {
			if (!empty($message['to']) && is_string($message['to'])) {
				$emails[] = trim($message['to']);
			}
		}

		return array_values(array_unique(array_filter($emails)));
	}

	protected function respond_json(array $payload)
	{
		$this->output
			->set_content_type('application/json')
			->set_output(json_encode($payload));
	}

	protected function append_resend_trace(array $payload)
	{
		$logsDir = rtrim(APPPATH, '/\\') . DIRECTORY_SEPARATOR . 'logs';
		if (!is_dir($logsDir)) {
			@mkdir($logsDir, 0775, true);
		}

		$file = $logsDir . DIRECTORY_SEPARATOR . 'email_logs_resend_' . date('Ymd') . '.jsonl';
		$payload['ts'] = date('c');
		$payload['controller'] = 'Email_logs';
		$payload['function'] = 'resend_email_log';

		$line = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if ($line === false) {
			$line = json_encode([
				'ts' => date('c'),
				'controller' => 'Email_logs',
				'function' => 'resend_email_log',
				'stage' => 'trace_encode_failed',
			]);
		}

		@file_put_contents($file, $line . PHP_EOL, FILE_APPEND);
	}
}
