<?php
$total = isset($summary['total']) ? (int)$summary['total'] : 0;
$sent = isset($summary['sent']) ? (int)$summary['sent'] : 0;
$delivered = isset($summary['delivered']) ? (int)$summary['delivered'] : 0;
$pending = isset($summary['pending']) ? (int)$summary['pending'] : 0;
$failed = (isset($summary['failed']) ? (int)$summary['failed'] : 0) + (isset($summary['undelivered']) ? (int)$summary['undelivered'] : 0);
?>

<div class="row">
    <div class="col-md-12">
        <div class="col-md-3">
            <div class="mail-stat-card mail-stat-total">
                <div class="mail-stat-accent"><i class="fa fa-envelope-o"></i></div>
                <div class="mail-stat-label">Total logs</div>
                <div class="mail-stat-value"><?php echo number_format($total, 0, ',', ' '); ?></div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="mail-stat-card mail-stat-sent">
                <div class="mail-stat-accent"><i class="fa fa-paper-plane-o"></i></div>
                <div class="mail-stat-label">Envoy&eacute;s</div>
                <div class="mail-stat-value"><?php echo number_format($sent, 0, ',', ' '); ?></div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="mail-stat-card mail-stat-delivered">
                <div class="mail-stat-accent"><i class="fa fa-check"></i></div>
                <div class="mail-stat-label">D&eacute;livr&eacute;s</div>
                <div class="mail-stat-value"><?php echo number_format($delivered, 0, ',', ' '); ?></div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="mail-stat-card mail-stat-pending">
                <div class="mail-stat-accent"><i class="fa fa-clock-o"></i></div>
                <div class="mail-stat-label">En attente</div>
                <div class="mail-stat-value"><?php echo number_format($pending, 0, ',', ' '); ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="mail-stat-card mail-stat-failed">
                <div class="mail-stat-accent"><i class="fa fa-warning"></i></div>
                <div class="mail-stat-label">En &eacute;chec / non d&eacute;livr&eacute;s</div>
                <div class="mail-stat-value"><?php echo number_format($failed, 0, ',', ' '); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="mail-table-card">
    <div class="mail-table-head">
        <h4>Historique des emails</h4>
        <p>Affichage limit&eacute; aux 250 logs les plus r&eacute;cents correspondant &agrave; votre filtre.</p>
    </div>

    <?php if (!empty($logs)): ?>
        <div class="table-responsive">
            <table id="email-log-table" class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Destinataire</th>
                        <th>Objet</th>
                        <th>Module</th>
                        <th>Provider</th>
                        <th>Statut</th>
                        <th>R&eacute;f&eacute;rence</th>
                        <th>D&eacute;tails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $index => $row): ?>
                        <?php
                        $status = strtoupper((string)$row->Status_8);
                        $detailId = 'email-log-detail-' . (int)$row->Id;
                        $date = $row->CreatedAt_12 ? $row->CreatedAt_12 : ($row->SentAt_11 ? $row->SentAt_11 : $row->UpdatedAt_13);
                        $payload = trim((string)$row->ResponsePayload_10);
                        $message = trim((string)$row->Message_5);
                        $error = trim((string)$row->ErrorMessage_9);
                        $hasAttachment = !empty($row->AttachmentPath_16) && is_file($row->AttachmentPath_16);
                        ?>
                        <tr class="mail-row-trigger" data-toggle="collapse" data-target="#<?php echo $detailId; ?>" aria-expanded="false">
                            <td><?php echo $index + 1; ?></td>
                            <td>
                                <div class="mail-cell-title"><?php echo html_escape($date ? $date : '-'); ?></div>
                               
                            </td>
                            <td>
                                <div class="mail-cell-title"><?php echo html_escape($row->RecipientEmail_3); ?></div>
                                <div class="mail-cell-subtitle"><?php echo html_escape($row->ProviderMessageId_7 ? $row->ProviderMessageId_7 : 'Sans message ID'); ?></div>
                            </td>
                            <td>
                                <div class="mail-cell-title"><?php echo html_escape($row->Subject_4); ?></div>
                                <div class="mail-cell-subtitle">
                                    <?php if ($hasAttachment): ?>
                                        <i class="fa fa-paperclip text-blue"></i>
                                    <?php endif; ?>
                                    <?php echo html_escape($row->NoteNumbers_15 ? $row->NoteNumbers_15 : 'Sans note associ&eacute;e'); ?>
                                </div>
                            </td>
                            <td><?php echo html_escape($row->Module_1 ? $row->Module_1 : '-'); ?></td>
                            <td><?php echo html_escape($row->Provider_6 ? $row->Provider_6 : '-'); ?></td>
                            <td><span class="mail-status-badge mail-status-<?php echo html_escape($status); ?>"><?php echo html_escape($status ? $status : 'PENDING'); ?></span></td>
                            <td>
                                <div class="mail-cell-title"><?php echo html_escape($row->Reference_2 ? $row->Reference_2 : '-'); ?></div>
                                <div class="mail-cell-subtitle">
                                    <?php echo $row->PaymentId_14 ? 'Paiement #' . html_escape($row->PaymentId_14) : 'Aucun paiement li&eacute;'; ?>
                                    <span class="mail-attachment-badge <?php echo $hasAttachment ? 'mail-attachment-badge-on' : 'mail-attachment-badge-off'; ?>">
                                        <?php echo $hasAttachment ? 'Avec PJ' : 'Sans PJ'; ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <span class="mail-toggle-indicator">Voir <i class="fa fa-chevron-down"></i></span>
                            </td>
                        </tr>
                        <tr class="mail-detail-row">
                            <td colspan="9">
                                <div id="<?php echo $detailId; ?>" class="collapse mail-detail-panel">
                                    <div class="mail-detail-meta">
                                        <strong>Message ID:</strong> <?php echo html_escape($row->ProviderMessageId_7 ? $row->ProviderMessageId_7 : '-'); ?>
                                        &nbsp; | &nbsp;
                                        <strong>Mis &agrave; jour:</strong> <?php echo html_escape($row->UpdatedAt_13 ? $row->UpdatedAt_13 : '-'); ?>
                                    </div>
                                    <div class="mail-detail-actions">
                                        <?php if ($hasAttachment): ?>
                                            <a
                                                class="btn btn-default btn-xs js-download-attachment"
                                                href="<?php echo base_url($module . '/email_logs/display/attachment/' . (int)$row->Id); ?>">
                                                <i class="fa fa-paperclip"></i> T&eacute;l&eacute;charger la pi&egrave;ce jointe
                                            </a>
                                        <?php endif; ?>
                                        <button
                                            type="button"
                                            class="btn btn-primary btn-xs mail-resend-link js-resend-email"
                                            data-id="<?php echo (int)$row->Id; ?>"
                                            data-url="<?php echo base_url($module . '/email_logs/save/resend/' . (int)$row->Id); ?>" onclick="resendEmail($(this))">
                                            <i class="fa fa-repeat"></i> Renvoyer le mail
                                        </button>
                                        <span class="mail-inline-feedback" aria-live="polite"></span>
                                    </div>
                                    <?php if ($error !== ''): ?>
                                        <div class="mail-detail-box"><?php echo html_escape($error); ?></div>
                                    <?php endif; ?>
                                    <?php if ($payload !== ''): ?>
                                        <div class="mail-detail-box"><?php echo html_escape($payload); ?></div>
                                    <?php endif; ?>
                                    <?php if ($message !== '' && $payload === '' && $error === ''): ?>
                                        <div class="mail-detail-box"><?php echo html_escape($message); ?></div>
                                    <?php endif; ?>
                                    <?php if ($message === '' && $payload === '' && $error === ''): ?>
                                        <div class="mail-cell-subtitle" style="margin-top:10px;">Aucun d&eacute;tail suppl&eacute;mentaire disponible.</div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="mail-empty">
            <i class="fa fa-envelope-o"></i>
            <h4><b>Aucun log email trouv&eacute;</b></h4>
            <p>Essayez un autre filtre ou laissez le syst&egrave;me g&eacute;n&eacute;rer de nouveaux envois pour voir l&apos;historique appara&icirc;tre ici.</p>
        </div>
    <?php endif; ?>
</div>

<script type="text/javascript">

    $(document).ready(function() {
        

        if ($.fn.DataTable && $('#email-log-table').length) {
            if ($.fn.DataTable.isDataTable('#email-log-table')) {
                $('#email-log-table').DataTable().destroy();
            }

            $('#email-log-table').DataTable({
                paging: true,
                lengthChange: true,
                searching: false,
                ordering: true,
                info: true,
                autoWidth: false,
                pageLength: 25,
                order: [[1, 'desc']]
            });
        }
    });

    function reloadEmailLogsResults() {
        var $filterForm = $('#email-log-filter-form');
        var payload = $filterForm.length ? $filterForm.serialize() : {};

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url($module . '/email_logs/display/filter'); ?>',
            data: payload,
            dataType: 'html',
            success: function (result) {
                $('#email-log-results').html(result);
            },
            error: function () {
                showTopAlert('warning', 'Le tableau n\'a pas pu etre recharge apres le renvoi.');
            }
        });
    }

    function escapeHtml(value) {
            return $('<div>').text(value == null ? '' : value).html();
        }

        function showTopAlert(type, message) {
            $('#email-log-results').prepend('<div class="alert alert-' + type + '">' + escapeHtml(message) + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }

        function buildBackendSummary(result) {
            if (!result || typeof result !== 'object') {
                return '';
            }

            var parts = [];
            if (result.logId) {
                parts.push('Log #' + result.logId);
            }
            if (result.providerMessageId) {
                parts.push('MessageId: ' + result.providerMessageId);
            }
            if (result.response && result.response.httpCode) {
                parts.push('HTTP: ' + result.response.httpCode);
            }
            if (result.tracking && result.tracking.mode) {
                parts.push('Worker: ' + result.tracking.mode);
            }

            return parts.join(' | ');
        }

    function parseAjaxResult(responseText) {
            if (typeof responseText === 'object' && responseText !== null) {
                return responseText;
            }

            if (typeof responseText !== 'string') {
                return null;
            }

            try {
                return JSON.parse(responseText);
            } catch (e) {
                return null;
            }
    }

    function looksLikeHtmlResponse(responseText) {
        if (typeof responseText !== 'string') {
            return false;
        }

        var value = $.trim(responseText).toLowerCase();
        return value.indexOf('<!doctype') === 0
            || value.indexOf('<html') === 0
            || value.indexOf('<div id="email-log-page"') === 0
            || value.indexOf('<script') === 0;
    }

    function setResendIdleState(button, detailRow) {
        button.prop('disabled', false)
            .removeClass('is-loading')
            .removeData('request-running')
            .html('<i class="fa fa-repeat"></i> Renvoyer le mail');
        detailRow.removeClass('mail-detail-row-loading');
    }

    function resendEmail(button) {
        if (button.data('request-running') === '1') {
            return false;
        }

        var id = button.data('id');
      
        var detailPanel = button.closest('.mail-detail-panel');
        var feedback = detailPanel.find('.mail-inline-feedback').first();
        var detailRow = button.closest('.mail-detail-row');

        button.prop('disabled', true).addClass('is-loading').data('request-running', '1').html('<i class="fa fa-spinner fa-spin"></i> Envoi...');
        detailRow.addClass('mail-detail-row-loading');
        feedback.removeClass('mail-inline-feedback-error mail-inline-feedback-success').addClass('mail-inline-feedback-pending').html('<i class="fa fa-spinner fa-spin"></i> Renvoi du mail en cours...');

        $.ajax({
            type: 'POST',
            url: button.data('url'),
            data: { source_log_id: id },
            dataType: 'text',
            success: function (responseText) {
                var result = parseAjaxResult(responseText);
                console.debug('email_logs.resend.success', result || responseText);

                if (!result) {
                    if (looksLikeHtmlResponse(responseText)) {
                        feedback.removeClass('mail-inline-feedback-pending mail-inline-feedback-error').addClass('mail-inline-feedback-success').html('<i class="fa fa-refresh fa-spin"></i> Reponse HTML recue, synchronisation du tableau...');
                        showTopAlert('warning', 'Le backend a repondu avec du HTML au lieu du JSON attendu. Le tableau va etre recharge pour recuperer l\'etat serveur.');
                        setResendIdleState(button, detailRow);
                        setTimeout(function () {
                            reloadEmailLogsResults();
                        }, 400);
                        return false;
                    }

                    feedback.removeClass('mail-inline-feedback-pending mail-inline-feedback-success').addClass('mail-inline-feedback-error').text('Reponse serveur invalide pendant le renvoi.');
                    showTopAlert('warning', 'Le serveur a repondu, mais la reponse n\'etait pas exploitable. Verifiez si le mail est tout de meme parti.');
                    setResendIdleState(button, detailRow);
                    return false;
                }

                var klass = result && result.ok ? 'success' : 'warning';
                var msg = result && result.message ? result.message : 'Reponse inconnue';
                var backendSummary = buildBackendSummary(result);
                showTopAlert(klass, backendSummary ? (msg + ' | ' + backendSummary) : msg);
                if (result.ok) {
                    var extra = '';
                    if (result.logId) {
                        extra += ' Nouveau log #' + result.logId + '.';
                    }
                    if (result.providerMessageId) {
                        extra += ' MessageId: ' + result.providerMessageId + '.';
                    }
                    feedback.removeClass('mail-inline-feedback-pending mail-inline-feedback-error').addClass('mail-inline-feedback-success').html('<i class="fa fa-check"></i> Mail renvoye via AJAX.' + extra);
                    button.attr('data-last-log-id', result.logId || '');
                } else {
                    feedback.removeClass('mail-inline-feedback-pending mail-inline-feedback-success').addClass('mail-inline-feedback-error').text(msg);
                }
                setResendIdleState(button, detailRow);
                if (result && result.ok) {
                    setTimeout(function () {
                        reloadEmailLogsResults();
                    }, 700);
                }
                return false;
            },
            error: function (xhr) {
                var sessionExpired = xhr && xhr.responseText && xhr.responseText.indexOf('session has expired') !== -1;
                var rawText = xhr && xhr.responseText ? $.trim(xhr.responseText) : '';
                var parsed = rawText !== '' ? parseAjaxResult(rawText) : null;
                var errorMessage = sessionExpired
                    ? 'Votre session a expire. Reconnectez-vous puis relancez le renvoi.'
                    : 'Une erreur est survenue lors du renvoi du mail.';
                if (!sessionExpired && parsed && parsed.message) {
                    errorMessage = parsed.message;
                }

                console.debug('email_logs.resend.error', {
                    status: xhr ? xhr.status : null,
                    responseText: rawText,
                    parsed: parsed
                });

                showTopAlert('warning', errorMessage);
                feedback.removeClass('mail-inline-feedback-pending mail-inline-feedback-success').addClass('mail-inline-feedback-error').text(errorMessage);
                setResendIdleState(button, detailRow);
            },
            complete: function () {
                setResendIdleState(button, detailRow);
            }
        });

        return false;
    }
</script>
