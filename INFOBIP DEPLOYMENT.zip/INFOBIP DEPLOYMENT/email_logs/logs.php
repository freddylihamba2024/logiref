<div id="email-log-page">
    <link href="<?php echo base_url('ikwook_bootstraps/v0/css/mail-logs.css'); ?>" rel="stylesheet" type="text/css" />

    <?php $emailLogsFeedback = $this->session->flashdata('email_logs_feedback'); ?>
    <?php if (!empty($emailLogsFeedback['message'])): ?>
        <div class="alert alert-<?php echo html_escape($emailLogsFeedback['type'] ?? 'info'); ?>">
            <?php echo html_escape($emailLogsFeedback['message']); ?>
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
        </div>
    <?php endif; ?>

    <div class="mail-hero">
        <div class="mail-hero-body">
            <span class="mail-kicker">Monitoring Emails</span>
            <h2>Logs des emails envoy&eacute;s</h2>
            <p>Suivez rapidement les statuts d&apos;envoi, filtrez les journaux par module, fournisseur, statut ou p&eacute;riode, et consultez les d&eacute;tails techniques utiles au support.</p>
        </div>
    </div>

    <div class="mail-filter-card">
        <div class="row">
            <div class="col-md-12">
                <div class="mail-filter-title">Filtres de recherche</div>
            </div>
        </div>
        <form id="email-log-filter-form">
            <div class="row">
                <div class="col-md-3">
                    <label>Recherche</label>
                    <input type="text" class="form-control" name="search" value="<?php echo html_escape($filters['search']); ?>" placeholder="Email, r&eacute;f&eacute;rence, sujet..." />
                </div>
                <div class="col-md-2">
                    <label>Statut</label>
                    <select name="status" class="form-control">
                        <option value="">Tous</option>
                        <?php foreach ($statuses_filter as $status): ?>
                            <option value="<?php echo html_escape($status); ?>" <?php echo ($filters['status'] === $status) ? 'selected' : ''; ?>>
                                <?php echo html_escape($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Module</label>
                    <select name="module" class="form-control">
                        <option value="">Tous</option>
                        <?php foreach ($modules_filter as $moduleName): ?>
                            <option value="<?php echo html_escape($moduleName); ?>" <?php echo ($filters['module'] === $moduleName) ? 'selected' : ''; ?>>
                                <?php echo html_escape($moduleName); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Fournisseur</label>
                    <select name="provider" class="form-control">
                        <option value="">Tous</option>
                        <?php foreach ($providers_filter as $providerName): ?>
                            <option value="<?php echo html_escape($providerName); ?>" <?php echo ($filters['provider'] === $providerName) ? 'selected' : ''; ?>>
                                <?php echo html_escape($providerName); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-1">
                    <label>Du</label>
                    <input type="date" class="form-control" name="date_from" value="<?php echo html_escape($filters['date_from']); ?>" />
                </div>
                <div class="col-md-1">
                    <label>Au</label>
                    <input type="date" class="form-control" name="date_to" value="<?php echo html_escape($filters['date_to']); ?>" />
                </div>
                <div class="col-md-1 mail-actions">
                    <button type="submit" class="btn btn-mail-primary btn-block">
                        <i class="fa fa-search"></i>
                    </button>
                    <a href="<?php echo base_url($module . '/email_logs/set/logs'); ?>" class="btn btn-mail-ghost btn-block" style="margin-top:10px;">
                        <i class="fa fa-refresh"></i>
                    </a>
                </div>
            </div>
        </form>
    </div>

    <div id="email-log-results">
        <?php $this->load->view($module . '/' . $group . '/' . $folder . '/_results', $this->data); ?>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#email-log-filter-form').off('submit').on('submit', function (e) {
            e.preventDefault();

            $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif'); ?>" />');

            $.ajax({
                type: 'POST',
                url: '<?php echo base_url($module . '/email_logs/display/filter'); ?>',
                data: $(this).serialize(),
                dataType: 'html',
                success: function (result) {
                    $("#loader").html('');
                    $('#email-log-results').html(result);
                },
                error: function () {
                    $("#loader").html('');
                    $('#email-log-results').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement des logs emails.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        });
    });
</script>
