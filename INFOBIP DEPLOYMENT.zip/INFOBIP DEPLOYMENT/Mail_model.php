<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mail_model extends CI_Model
{
	protected $table = 'logiref_email_logs';
	protected $allowedStatuses = null;

	protected function array_get($array, $key, $default = null)
	{
		return (is_array($array) && array_key_exists($key, $array)) ? $array[$key] : $default;
	}

	public function __construct()
	{
		parent::__construct();

		if (isset($this->db) && $this->db) {
			$this->db->close();
			$this->db = null;
		}

		$this->db = $this->load->database('logiref_ebcdc_main', true);
	}

	public function insert_email_log($data)
	{
		if (!$this->db->table_exists($this->table)) {
			return false;
		}

		$payload = [
			'Module_1' => $this->limit($this->array_get($data, 'Module_1'), 100),
			'Reference_2' => $this->limit($this->array_get($data, 'Reference_2'), 100),
			'RecipientEmail_3' => $this->limit((string)$this->array_get($data, 'RecipientEmail_3', ''), 150),
			'Subject_4' => $this->limit((string)$this->array_get($data, 'Subject_4', ''), 255),
			'Message_5' => $this->array_get($data, 'Message_5'),
			'Provider_6' => $this->limit($this->array_get($data, 'Provider_6'), 100),
			'ProviderMessageId_7' => $this->limit($this->array_get($data, 'ProviderMessageId_7'), 150),
			'Status_8' => $this->normalize_status($this->array_get($data, 'Status_8', 'PENDING')),
			'ErrorMessage_9' => $this->array_get($data, 'ErrorMessage_9'),
			'ResponsePayload_10' => $this->normalize_payload($this->array_get($data, 'ResponsePayload_10')),
			'SentAt_11' => $this->array_get($data, 'SentAt_11'),
			'PaymentId_14' => $this->normalize_bigint($this->array_get($data, 'PaymentId_14')),
			'NoteNumbers_15' => $this->array_get($data, 'NoteNumbers_15'),
			'AttachmentPath_16' => $this->array_get($data, 'AttachmentPath_16'),
		];

		if ($payload['RecipientEmail_3'] === '' || $payload['Subject_4'] === '') {
			return false;
		}

		$ok = $this->db->insert($this->table, $payload);
		return $ok ? (int)$this->db->insert_id() : false;
	}

	public function save_log($data)
	{
		return $this->insert_email_log($this->map_legacy_log($data));
	}

	public function get_email_logs($filters = array(), $limit = 250)
	{
		if (!$this->db->table_exists($this->table)) {
			return [];
		}

		$this->apply_filters($filters);
		$this->db->select('
			Id,
			Module_1,
			Reference_2,
			RecipientEmail_3,
			Subject_4,
			Message_5,
			Provider_6,
			ProviderMessageId_7,
			Status_8,
			ErrorMessage_9,
			ResponsePayload_10,
			SentAt_11,
			CreatedAt_12,
			UpdatedAt_13,
			PaymentId_14,
			NoteNumbers_15,
			AttachmentPath_16
		');
		$this->db->select('COALESCE(CreatedAt_12, UpdatedAt_13, SentAt_11) AS LogDate_16', false);
		$this->db->from($this->table);
		$this->db->order_by('LogDate_16', 'DESC');
		$this->db->order_by('Id', 'DESC');

		if ((int)$limit > 0) {
			$this->db->limit((int)$limit);
		}

		$query = $this->db->get();
		return $query ? $query->result() : [];
	}

	public function get_email_logs_summary($filters = array())
	{
		$summary = [
			'total' => 0,
			'sent' => 0,
			'delivered' => 0,
			'pending' => 0,
			'failed' => 0,
			'undelivered' => 0,
		];

		if (!$this->db->table_exists($this->table)) {
			return $summary;
		}

		$this->apply_filters($filters);
		$this->db->select("
			COUNT(*) AS total,
			SUM(CASE WHEN Status_8 = 'SENT' THEN 1 ELSE 0 END) AS sent,
			SUM(CASE WHEN Status_8 = 'DELIVERED' THEN 1 ELSE 0 END) AS delivered,
			SUM(CASE WHEN Status_8 = 'PENDING' THEN 1 ELSE 0 END) AS pending,
			SUM(CASE WHEN Status_8 = 'FAILED' THEN 1 ELSE 0 END) AS failed,
			SUM(CASE WHEN Status_8 = 'UNDELIVERED' THEN 1 ELSE 0 END) AS undelivered
		", false);
		$this->db->from($this->table);

		$row = $this->db->get()->row_array();
		if (!$row) {
			return $summary;
		}

		foreach ($summary as $key => $value) {
			$summary[$key] = isset($row[$key]) ? (int)$row[$key] : 0;
		}

		return $summary;
	}

	public function get_email_log_by_id($id)
	{
		if (!$this->db->table_exists($this->table) || !is_numeric($id)) {
			return null;
		}

		$this->db->select('
			Id,
			Module_1,
			Reference_2,
			RecipientEmail_3,
			Subject_4,
			Message_5,
			Provider_6,
			ProviderMessageId_7,
			Status_8,
			ErrorMessage_9,
			ResponsePayload_10,
			SentAt_11,
			CreatedAt_12,
			UpdatedAt_13,
			PaymentId_14,
			NoteNumbers_15,
			AttachmentPath_16
		');
		$this->db->from($this->table);
		$this->db->where('Id', (int)$id);
		return $this->db->get()->row();
	}

	public function get_distinct_values($column)
	{
		$allowed = ['Module_1', 'Provider_6', 'Status_8'];
		if (!in_array($column, $allowed, true) || !$this->db->table_exists($this->table)) {
			return [];
		}

		$this->db->distinct();
		$this->db->select($column);
		$this->db->from($this->table);
		$this->db->where($column . ' IS NOT NULL', null, false);
		$this->db->where($column . " <> ''", null, false);
		$this->db->order_by($column, 'ASC');
		$query = $this->db->get();

		if (!$query) {
			return [];
		}

		$values = [];
		foreach ($query->result_array() as $row) {
			$values[] = $row[$column];
		}

		return $values;
	}

	public function update_email_status_by_provider_message_id($providerMessageId, $status, $responsePayload = null, $errorMessage = null)
	{
		if (!$this->db->table_exists($this->table) || empty($providerMessageId)) {
			return false;
		}

		$update = [
			'Status_8' => $this->normalize_status($status),
			'ResponsePayload_10' => $this->normalize_payload($responsePayload),
			'ErrorMessage_9' => $errorMessage,
		];

		if ($update['Status_8'] === 'DELIVERED') {
			$update['SentAt_11'] = date('Y-m-d H:i:s');
		}

		$this->db->where('ProviderMessageId_7', $providerMessageId);
		return $this->db->update($this->table, $update);
	}

	protected function map_legacy_log($data)
	{
		$isSent = !empty($data['Sent_7']);

		return [
			'Module_1' => $this->array_get($data, 'Type_11', 'MAIL'),
			'Reference_2' => $this->array_get($data, 'Reference_10'),
			'RecipientEmail_3' => $this->array_get($data, 'Email_6', ''),
			'Subject_4' => $this->array_get($data, 'Subject_3', ''),
			'Message_5' => $this->array_get($data, 'Message_4'),
			'Provider_6' => $this->array_get($data, 'Provider_6', 'APPLICATION'),
			'ProviderMessageId_7' => $this->array_get($data, 'ProviderMessageId_7'),
			'Status_8' => $isSent ? 'SENT' : 'FAILED',
			'ErrorMessage_9' => $this->array_get($data, 'ErrorMessage_9'),
			'ResponsePayload_10' => $this->array_get($data, 'ResponsePayload_10'),
			'SentAt_11' => $isSent ? date('Y-m-d H:i:s') : null,
			'PaymentId_14' => $this->array_get($data, 'PaymentId_14'),
			'NoteNumbers_15' => $this->array_get($data, 'NoteNumbers_15', $this->array_get($data, 'Reference_10')),
			'AttachmentPath_16' => $this->array_get($data, 'AttachmentPath_16'),
		];
	}

	protected function normalize_status($status)
	{
		$status = strtoupper(trim((string)$status));
		$allowed = $this->get_allowed_statuses();
		if (in_array($status, $allowed, true)) {
			return $status;
		}

		if ($status === 'NOT_DELIVERED' && in_array('UNDELIVERED', $allowed, true)) {
			return 'UNDELIVERED';
		}

		if (($status === 'NOT_DELIVERED' || $status === 'UNDELIVERED') && in_array('FAILED', $allowed, true)) {
			return 'FAILED';
		}

		return in_array('PENDING', $allowed, true) ? 'PENDING' : $allowed[0];
	}

	protected function normalize_payload($payload)
	{
		if ($payload === null || $payload === '') {
			return null;
		}

		if (is_array($payload) || is_object($payload)) {
			$json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
			return ($json === false) ? null : $json;
		}

		return (string)$payload;
	}

	protected function normalize_bigint($value)
	{
		if ($value === null || $value === '') {
			return null;
		}

		return is_numeric($value) ? (int)$value : null;
	}

	protected function limit($value, $length)
	{
		if ($value === null) {
			return null;
		}

		$value = trim((string)$value);
		if ($value === '') {
			return null;
		}

		return function_exists('mb_substr') ? mb_substr($value, 0, $length) : substr($value, 0, $length);
	}

	protected function get_allowed_statuses()
	{
		if (is_array($this->allowedStatuses)) {
			return $this->allowedStatuses;
		}

		$this->allowedStatuses = ['PENDING', 'SENT', 'FAILED', 'DELIVERED', 'UNDELIVERED'];

		if (!$this->db->table_exists($this->table)) {
			return $this->allowedStatuses;
		}

		$query = $this->db->query("SHOW COLUMNS FROM `{$this->table}` LIKE 'Status_8'");
		$row = $query ? $query->row_array() : null;
		$type = $this->array_get($row, 'Type', '');

		if (preg_match("/^enum\\((.*)\\)$/i", $type, $matches)) {
			$values = str_getcsv($matches[1], ',', "'");
			$values = array_values(array_filter(array_map('trim', $values)));
			if (!empty($values)) {
				$this->allowedStatuses = array_map('strtoupper', $values);
			}
		}

		return $this->allowedStatuses;
	}

	protected function apply_filters($filters = array())
	{
		$status = strtoupper(trim((string)$this->array_get($filters, 'status', '')));
		$module = trim((string)$this->array_get($filters, 'module', ''));
		$provider = trim((string)$this->array_get($filters, 'provider', ''));
		$search = trim((string)$this->array_get($filters, 'search', ''));
		$dateFrom = trim((string)$this->array_get($filters, 'date_from', ''));
		$dateTo = trim((string)$this->array_get($filters, 'date_to', ''));

		if ($status !== '') {
			$this->db->where('Status_8', $this->normalize_status($status));
		}

		if ($module !== '') {
			$this->db->where('Module_1', $module);
		}

		if ($provider !== '') {
			$this->db->where('Provider_6', $provider);
		}

		if ($search !== '') {
			$this->db->group_start();
			$this->db->like('RecipientEmail_3', $search);
			$this->db->or_like('Reference_2', $search);
			$this->db->or_like('Subject_4', $search);
			$this->db->or_like('ProviderMessageId_7', $search);
			$this->db->or_like('NoteNumbers_15', $search);
			$this->db->group_end();
		}

		if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
			$this->db->where("DATE(COALESCE(CreatedAt_12, SentAt_11, UpdatedAt_13)) >=", $dateFrom, false);
		}

		if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
			$this->db->where("DATE(COALESCE(CreatedAt_12, SentAt_11, UpdatedAt_13)) <=", $dateTo, false);
		}
	}
}
