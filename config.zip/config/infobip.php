<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| Infobip configuration
| -------------------------------------------------------------------
| Configure your Infobip base URL and API key.
|
| Example baseUrl: https://xxxx.api.infobip.com
| API key: Infobip "App" API key
|
*/

$config['infobip'] = [
	'baseUrl' => 'https://x9v6e.api.infobip.com',
	'apiKey' => 'e617326d2cb7b579d25b4d4efdf51361-3ce9210d-fe20-4858-8368-99790ee6979d',
	'timeoutSeconds' => 180,
	'sslVerify' => false,

	// Email endpoints (paths are appended to baseUrl)
	'sendPath' => '/email/3/send',

	// Delivery reports are one-time fetch (returned only once).
	// Default based on Infobip Email API docs/blog examples.
	'reportsPath' => '/email/1/reports',

	// Default BCC (copie cachée) for Passport emails (aligned with old init_email_curl_passport()).
	'defaultBccSuccess' => [
		'Emmanuel.Nditukulu@equitybcdc.cd',
		'jose.mabuaka@equitybcdc.cd',
		'junior.baba@equitybcdc.cd',
		'Grace.Monzele@equitybcdc.cd',
		'tharcisse.mutombo@equitybcdc.cd',
		'olivier.muissa@equitybcdc.cd',
		'patrick.nkongolo@equitybcdc.cd',
		'support@ikwook.cd',
		'bruno.makembi@equitybcdc.cd',
		'bethy.mulanga@equitybcdc.cd',
		'niclette.kibundila@equitybcdc.cd',
	],
	'defaultBccError' => [
		'patrick.nkongolo@equitybcdc.cd',
	],
];
