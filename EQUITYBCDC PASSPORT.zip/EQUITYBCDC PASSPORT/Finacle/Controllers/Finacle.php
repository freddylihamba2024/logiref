<?php
        namespace Modules\Services\Finacle\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Finacle\Models\FinacleModel;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;

        class Finacle extends BaseController {

                public $finacleModel;
                public $comptabilisationModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->finacleModel = new FinacleModel();
                        $this->comptabilisationModel = new ComptabilisationModel();
                }

                public function account_info($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $data_to_send = array();
                        $failled = array();
                        $return = array();
                        $customerid = '';
                        $account_number = '';
                        $account_details = '';

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';
                        else
                        $result = str_replace('-', '', $data['Compte_33']);
                        $account = $result ;

                        if(count($failled) == 0)
                        {
                                /*
                                * --------------------------------------------
                                * Construction of data to send
                                * --------------------------------------------
                                */

                                ###### the request reference ###################
                                $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=> $requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'XferTrnAdd',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'RDC',
                                                        'LanguageId'=>'',
                                                );
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'GMT+05:00',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'CustAcctInquiry'
                                                                );

                                $custAcctInquiry_REQ = array(
                                                                'BankID'=>'43',
                                                                'AccountID'=>$account
                                                        );

                                $executeFinacleScript_CustomData['CustAcctInquiry_REQ'] = $custAcctInquiry_REQ;

                                $executeFinacleScriptReques['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;

                                $executeFinacleScriptReques['executeFinacleScript_CustomData']= $executeFinacleScript_CustomData;

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptReques;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;

                                //                        $response = $this->finacleModel->account_info($data_to_send);
                                $response['Header']['ResponseHeader']['HostTransaction']['Status']="SUCCESS";

                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        //                                $account = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['AccountName']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['AccountName'] : "";
                                        //                                $devise = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency'] : "";
                                        //                                $balance = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance'] : "";

                                        $account = "Dorcas Balako";
                                        $devise = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency'] : "CDF";
                                        $balance = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance'] : "56648960000";

                                        $data_to_return['code']="200";
                                        $data_to_return['account_name'] = $account;
                                        $data_to_return['currency'] = $devise;
                                        $data_to_return['balance'] = $balance;

                                        $return = $data_to_return;
                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "account_info");

                                return $return;
                        }
                }

                public function virement($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $data_to_update = array();
                        $request_to_save = array();
                        $instructions = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $return_update = "";
                        $i =1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */


                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        //if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";


                        if (!empty($failled))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Erreur des donnes invalides: " . json_encode($failled), "account");

                                return json_encode($data_to_return);
                        }


                        $type = $data['Type'] ?? '';

                        if ($data['Beneficaire_15'] === 'DGDA')
                        {
                                if ($type === 'prepayment')
                                {
                                        $this->finacleModel->update_payment_prepayment($data['Sydonia_49']);
                                }
                                elseif ($type !== 'first_transaction')
                                {
                                        $this->finacleModel->update_payment_sydonia($data['Sydonia_44']);
                                }
                        }

                        $return = match($data['Beneficaire_15'])
                        {
                                'DGDA' => ($type === 'prepayment')
                                        ? $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_49'], $data['Priority'])
                                        : $this->finacleModel->get_integrations_info_dgda(((($data['Mode'] ?? "") == "batch" ) ? $data['Paiementid_4'] : $data['Sydonia_44']), $data['Priority']),
                                'DGI'  => $this->finacleModel->get_integrations_info_dgi($data['Logirefid_4']),
                                'DGRAD'=> $this->finacleModel->get_integrations_info_dgrad($data['Logirefid_4']),

                                default => []
                        };


                        if (empty($return))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Missing integration data");
                                return json_encode($data_to_return);
                        }

                        $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        //$requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                        $requestuuid    = $data['Logirefid_4']."".$return[0]['Id_0'];
                        $exchange_rate  = $data['Taux_41'] ?? "";
                        $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                        $rate_code      = $infos['rate_code'] ?? "TTB";

                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                        $xferTrnDetail = [];

                        $i = 0;
                        foreach ($return as $row)
                        {
                                $compte1 = str_replace('-', '', $row["Compte_9"]);
                                $compte2 = str_replace('-', '', $row["Compte_13"]);

                                if ($row["Montant_10"] <= 0 || empty($compte1)) continue;

                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                $xferTrnDetail[] = [
                                        'AcctId'                => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg'        => 'D',
                                        'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'               => $date,
                                        'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                        'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                        'RateCode'              => $rate_code,
                                        'Rate'                  => $exchange_rate,
                                        'SerialNum'             => $i
                                ];

                                $xferTrnDetail[] = [
                                        'AcctId'                => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg'        => 'C',
                                        'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'               => $date,
                                        'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                        'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                        'RateCode'              => $rate_code,
                                        'Rate'                  => $exchange_rate,
                                        'SerialNum'             => $i+1
                                ];

                                $i++;
                        }

                        $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                        $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                        $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                        $data_to_send['Header'] = $requestHeader;
                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                        //$response = $this->finacleModel->payment_transfer($data_to_send);
                        $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                        $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = 'TRX'.rand(1000,9999);

                        $result = $this->handleCBSResponse($response, $data, $return, $type);
                        $data_to_return = $result['data_to_return'];
                        $data_to_save   = $result['data_to_save'];

                        if ($data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['Type']) && $data['Type'] == "prepayment")
                                {
                                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'], $data_to_save, $data['Sydonia_49']);
                                }
                                elseif(isset($data['Type']) && $data['Type'] == "others")
                                {
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                }
                                else
                                {
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                }
                        }
                        else
                        {
                                $this->finacleModel->save_cbs_return($data['Account_3'], $data_to_save, $data['Id_0']);
                        }

                        return json_encode($data_to_return);

                }
                public function virement_passport($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i = 1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */
                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";

                        if (!empty($failled))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Erreur des donnes invalides: " . json_encode($failled), "passport");

                                return json_encode($data_to_return);
                        }

                        $type = $data['Type'] ?? '';

                        $return = match($data['Beneficaire_15'])
                        {
                                'DGRAD' => $this->finacleModel->get_integrations_info_passport($data['Logirefid_4']),
                                default => []
                        };

                        if (empty($return))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Missing integration data for passport");
                                return json_encode($data_to_return);
                        }

                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        
                        $requestuuid = $data['Logirefid_4'] . "" . $return[0]['Id_0'];
                        $exchange_rate = $data['Taux_41'] ?? "";
                        $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                        $rate_code = $infos['rate_code'] ?? "TTB";

                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                        $xferTrnDetail = [];

                        $trans_type = $data['Trans'] ?? 'standard';
                        $i = 0;

                        foreach ($return as $idx => $row)
                        {
                                $compte1 = str_replace('-', '', $row["Compte_9"]);
                                $compte2 = str_replace('-', '', $row["Compte_13"]);

                                if ($row["Montant_10"] <= 0 || empty($compte1)) continue;

                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                // Traitement selon le type de transaction
                                if ($trans_type == "firstTrans")
                                {
                                        // Mode firstTrans: traiter seulement les 3 premiers items
                                        if ($i <= 3)
                                        {
                                                $xferTrnDetail[] = [
                                                        'AcctId' => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                                        'CreditDebitFlg' => 'D',
                                                        'TrnAmt' => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($row['Libelle_12'], 0, 50),
                                                        'PartTrnRmks' => substr($row['Libelle_12'], 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i
                                                ];

                                                $xferTrnDetail[] = [
                                                        'AcctId' => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                                        'CreditDebitFlg' => 'C',
                                                        'TrnAmt' => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($row['Libelle_12'], 0, 50),
                                                        'PartTrnRmks' => substr($row['Libelle_12'], 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i + 1
                                                ];
                                        }
                                }
                                else
                                {
                                        // Mode standard: appliquer logique spéciale premier item vs autres items
                                        if ($i == 0)
                                        {
                                                // Premier item: calculer la somme totale
                                                $amount_debit = array_sum(array_column($return, 'Montant_10'));

                                                $xferTrnDetail[] = [
                                                        'AcctId' => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                                        'CreditDebitFlg' => 'D',
                                                        'TrnAmt' => ['amountValue' => $amount_debit, 'currencyCode' => $row["Devise_11"]],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($row['Libelle_12'], 0, 50),
                                                        'PartTrnRmks' => substr($row['Libelle_12'], 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i
                                                ];

                                                $xferTrnDetail[] = [
                                                        'AcctId' => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                                        'CreditDebitFlg' => 'C',
                                                        'TrnAmt' => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($row['Libelle_12'], 0, 50),
                                                        'PartTrnRmks' => substr($row['Libelle_12'], 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i + 1
                                                ];
                                        }
                                        else
                                        {
                                                // Autres items: ajouter seulement le crédit
                                                $xferTrnDetail[] = [
                                                        'AcctId' => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                                        'CreditDebitFlg' => 'C',
                                                        'TrnAmt' => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($row['Libelle_12'], 0, 50),
                                                        'PartTrnRmks' => substr($row['Libelle_12'], 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i + 1
                                                ];
                                        }
                                }

                                $i++;
                        }

                        $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                        $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                        $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                        $data_to_send['Header'] = $requestHeader;
                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                        // Appel réel à l'API payment_transfer
                        
                        // $response = $this->finacleModel->payment_transfer($data_to_send);
                        $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                        $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = 'TRX'.rand(1000,9999);

                        // Gestion des retours via fonction dédiée
                        $result = $this->handlePassportResponse($response, $data, $return);
                        $data_to_return = $result['data_to_return'];
                        $data_to_save = $result['data_to_save'];

                        // Sauvegarde du retour CBS
                        $this->finacleModel->save_cbs_return($data['Account_3'], $data_to_save, $data['Id_0']);

                        return json_encode($data_to_return);
                }

                public function virement_immatriculation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $return = array();
                        $response = array();
                        $data_to_save = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i = 1;
                        $j = 0;
                        $expected_count = 0;
                        $integrated_count = 0;
                        $verify = false;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";
                        if (empty($data["Account_3"])) $failled[] = "The account is not defined";

                        if(count($failled) == 0)
                        {
                                $type = $data['Type'] ?? '';

                                $return = match($data['Beneficaire_15'])
                                {
                                        'DGI'  => $this->finacleModel->get_integrations_info_dgi($data['Logirefid_4']),
                                        default => []
                                };

                                if (empty($return))
                                {
                                        $data_to_return = [
                                                'code' => 405,
                                                'response' => 405,
                                                'message' => "Missing data in the request",
                                                'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                        ];

                                        $this->finacleModel->save_log("Missing integration data");
                                        return json_encode($data_to_return);
                                }

                                $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                $requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                $exchange_rate  = $data['Taux_41'] ?? "";
                                $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                                $rate_code      = $infos['rate_code'] ?? "TTB";

                                $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                $xferTrnDetail = [];

                                $i = 0;
                                foreach ($return as $row)
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);

                                        if ($row["Montant_10"] <= 0 || empty($compte1)) continue;

                                        $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                        $xferTrnDetail[] = [
                                                'AcctId'                => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                                'CreditDebitFlg'        => 'D',
                                                'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                'ValueDt'               => $date,
                                                'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                                'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                                'RateCode'              => $rate_code,
                                                'Rate'                  => $exchange_rate,
                                                'SerialNum'             => $i
                                        ];

                                        $xferTrnDetail[] = [
                                                'AcctId'                => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                                'CreditDebitFlg'        => 'C',
                                                'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                'ValueDt'               => $date,
                                                'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                                'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                                'RateCode'              => $rate_code,
                                                'Rate'                  => $exchange_rate,
                                                'SerialNum'             => $i+1
                                        ];

                                        $i++;
                                }

                                $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                                $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                                $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                                $data_to_send['Header'] = $requestHeader;
                                $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                                $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = "TY8339U492";

                                $result = $this->handleCBSResponse($response, $data, $return, $type);
                                $data_to_return = $result['data_to_return'];
                                $data_to_save   = $result['data_to_save'];

                                $this->finacleModel->save_cbs_return($data['Account_3'], $data_to_save, $data['Logirefid_4']);

                                return json_encode($data_to_return);
                        }
                        else
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Erreur des donnes invalides: " . json_encode($failled), "account");

                                return json_encode($data_to_return);
                        }
                }

                public function regularize_immatriculation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i = 1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";
                        if (empty($data["Id_0"])) $failled[] = 'Data Paiementid is empty';

                        if(count($failled) == 0)
                        {
                                $instructions = $this->finacleModel->get_integrations_dgi_immatriculation_by_id($data['Id_0']);
                                $cbd_returns = $this->finacleModel->get_cbs_returns_immatriculation_by_paiementid($data['Paiementid_4']);

                                if(!empty($instructions))
                                {
                                        $compte1 = explode('-', $instructions[0]["Compte_13"]);
                                        $compte2 = explode('-', $instructions[0]["Compte_9"]);

                                        $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                        $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                        $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                        $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                        if($agence1 == "") $failled[] = "Ligne : ".' agence1 is empty';
                                        if($agence2 == "") $failled[] = "Ligne : ".' agence2 is empty';
                                        if($account_src == "") $failled[] = "Ligne : ".' account_src is empty';
                                        if($account_dst == "") $failled[] = "Ligne: ".' account_dst is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne : ".' devise is empty';
                                        if($instructions[0]["Montant_10"] == "" || $instructions[0]["Montant_10"] == 0 ||  $instructions[0]["Montant_10"] < 0) $failled[] = "Ligne : ".' Montant is empty ou invalide';
                                        if($instructions[0]["Libelle_12"] == "") $failled[] = "Ligne : ".' Libelle_12 is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne: ".' Devise_11 is empty';

                                        if(count($failled) == 0)
                                        {

                                                if(count($compte1)>1 && count($compte2)>1)
                                                {
                                                        $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                                        $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                                        $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                                        $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                                        $libelle = $this->remove_all_special_characters($instructions[0]["Libelle_12"]);

                                                        $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                                        $requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                                        $exchange_rate  = $data['Taux_41'] ?? "";
                                                        $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                                                        $rate_code      = $infos['rate_code'] ?? "TTB";

                                                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                                        $xferTrnDetail = [];

                                                        $xferTrnDetail[] = [
                                                                'AcctId'                => ['AcctId' => $account_src, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                                'CreditDebitFlg'        => 'D',
                                                                'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                                'ValueDt'               => $date,
                                                                'TrnParticulars'        => substr($libelle, 0, 50),
                                                                'PartTrnRmks'           => substr($libelle, 15, 30),
                                                                'RateCode'              => $rate_code,
                                                                'Rate'                  => $exchange_rate,
                                                                'SerialNum'             => 0
                                                        ];

                                                        $xferTrnDetail[] = [
                                                                'AcctId'                => ['AcctId' => $account_dst, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                                'CreditDebitFlg'        => 'C',
                                                                'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                                'ValueDt'               => $date,
                                                                'TrnParticulars'        => substr($libelle, 0, 50),
                                                                'PartTrnRmks'           => substr($libelle, 15, 30),
                                                                'RateCode'              => $rate_code,
                                                                'Rate'                  => $exchange_rate,
                                                                'SerialNum'             => 1
                                                        ];

                                                        $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                                                        $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                                                        $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                                                        $data_to_send['Header'] = $requestHeader;
                                                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                                                        //$response = $this->finacleModel->payment_transfer($data_to_send);
                                                        $response['STATUS'] = '000';
                                                        $response['BNKREFNO'] = '223000467399';

                                                        if(isset($response['STATUS']) && $response['STATUS'] != NULL)
                                                        {
                                                                $event_number= "";

                                                                if($response['STATUS']=='000')
                                                                {
                                                                        $code = 200;
                                                                }
                                                                elseif($response['STATUS']=='196')
                                                                {
                                                                        $code = 300;
                                                                }

                                                                if(isset($response['BNKREFNO']) && $response['BNKREFNO'] !="")
                                                                {
                                                                        $event_number = substr($response['BNKREFNO'], -6);
                                                                }
                                                                else
                                                                {
                                                                        $code = 404;
                                                                }
                                                                $status[] = $code;

                                                                $data_to_save[$instructions[0]['Id_0']]['Num_evenement'] = $event_number;
                                                                $data_to_save[$instructions[0]['Id_0']]['code'] = $code;
                                                        }
                                                        else
                                                        {
                                                                # erreur CBS
                                                                $code = 411;
                                                                $status[] = $code;
                                                        }
                                                }

                                                if(isset($cbd_returns[0]['Result_6']) && $cbd_returns[0]['Result_6'] !="")
                                                {
                                                        $olddata = json_decode($cbd_returns[0]['Result_6'], true);

                                                        foreach($olddata as $key => $value):

                                                                if($key == $data['Id_0'] && $code =='200'):
                                                                        $newdata[$key]['Num_evenement'] = $event_number;
                                                                        $newdata[$key]['code'] = $code;
                                                                else:
                                                                        if(isset($value['Num_evenement']) && $value['Num_evenement'] !=""):
                                                                                if(isset($value['Num_evenement']))$newdata[$key]['Num_evenement'] = $value['Num_evenement'];
                                                                                if(isset($value['code'])) $newdata[$key]['code'] = $value['code'];
                                                                        endif;
                                                                endif;
                                                        endforeach;
                                                }

                                                if(isset($newdata))
                                                {
                                                        $pid = $this->finacleModel->update_return_immatriculation($newdata, $data['Paiementid_4'], $data['Beneficaire_15']);
                                                }

                                                if(in_array('404', $status))
                                                {
                                                        # compte fermé, chapitre non autorisé, sens du compte incorrect, saisie arrête BCC.
                                                        $newdata['response'] = 404;
                                                }
                                                elseif(in_array('300', $status))
                                                {
                                                        # solde insuffisant, désaccord commercial ou administratif.
                                                        $newdata['response'] = 300;
                                                }
                                                else
                                                {
                                                        $newdata['response'] = 200;
                                                }

                                                $result_to_save = json_encode($newdata);

                                                $this->finacleModel->save_log("Resultat final: ".$result_to_save, "virement");

                                                return $newdata;
                                        }
                                        else
                                        {
                                                $data_to_save['response'] = 405;
                                                $result_to_save = json_encode($data_to_save);

                                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                                return $data_to_save;
                                        }
                                }
                                else
                                {
                                        $data_to_save['response'] = 405;
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                        return $data_to_save;
                                }
                        }
                        else
                        {
                                $data_to_save['response'] = 405;
                                $result_to_save = json_encode($data_to_save);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                return $data_to_save;
                        }
                }

                public function extourne_immatriculation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */

                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i =1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";
                        if (empty($data["Id_0"])) $failled[] = 'Data Paiementid is empty';

                        if(count($failled) == 0)
                        {
                                $instructions = $this->finacleModel->get_integrations_dgi_immatriculation_by_id($data['Id_0']);

                                $cbd_returns = $this->finacleModel->get_cbs_returns_immatriculation_by_paiementid($data['Paiementid_4']);

                                if(!empty($instructions))
                                {
                                        $compte1 = explode('-', $instructions[0]["Compte_13"]);
                                        $compte2 = explode('-', $instructions[0]["Compte_9"]);

                                        $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                        $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                        $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                        $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                        if($agence1 == "") $failled[] = "Ligne : ".' agence1 is empty';
                                        if($agence2 == "") $failled[] = "Ligne : ".' agence2 is empty';
                                        if($account_src == "") $failled[] = "Ligne : ".' account_src is empty';
                                        if($account_dst == "") $failled[] = "Ligne: ".' account_dst is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne : ".' devise is empty';
                                        if($instructions[0]["Montant_10"] == "" || $instructions[0]["Montant_10"] == 0 ||  $instructions[0]["Montant_10"] < 0) $failled[] = "Ligne : ".' Montant is empty ou invalide';
                                        if($instructions[0]["Libelle_12"] == "") $failled[] = "Ligne : ".' Libelle_12 is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne: ".' Devise_11 is empty';

                                        if(count($failled) == 0)
                                        {

                                                if(count($compte1)>1 && count($compte2)>1)
                                                {
                                                        $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                                        $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                                        $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                                        $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                                        $libelle = $this->remove_all_special_characters($instructions[0]["Libelle_12"]);

                                                        $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                                        $requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                                        $exchange_rate  = $data['Taux_41'] ?? "";
                                                        $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                                                        $rate_code      = $infos['rate_code'] ?? "TTB";

                                                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                                        $xferTrnDetail = [];

                                                        $xferTrnDetail[] = [
                                                                'AcctId'                => ['AcctId' => $account_src, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                                'CreditDebitFlg'        => 'D',
                                                                'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                                'ValueDt'               => $date,
                                                                'TrnParticulars'        => substr($libelle, 0, 50),
                                                                'PartTrnRmks'           => substr($libelle, 15, 30),
                                                                'RateCode'              => $rate_code,
                                                                'Rate'                  => $exchange_rate,
                                                                'SerialNum'             => 0
                                                        ];

                                                        $xferTrnDetail[] = [
                                                                'AcctId'                => ['AcctId' => $account_dst, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                                'CreditDebitFlg'        => 'C',
                                                                'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                                'ValueDt'               => $date,
                                                                'TrnParticulars'        => substr($libelle, 0, 50),
                                                                'PartTrnRmks'           => substr($libelle, 15, 30),
                                                                'RateCode'              => $rate_code,
                                                                'Rate'                  => $exchange_rate,
                                                                'SerialNum'             => 1
                                                        ];

                                                        $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                                                        $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                                                        $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                                                        $data_to_send['Header'] = $requestHeader;
                                                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                                                        //$response = $this->finacleModel->payment_transfer($data_to_send);
                                                        $response['STATUS'] = '000';
                                                        $response['BNKREFNO'] = '223000467399';

                                                        if(isset($response['STATUS']) && $response['STATUS'] != NULL)
                                                        {
                                                                $event_number= "";

                                                                if($response['STATUS']=='000')
                                                                {
                                                                        $code = 200;
                                                                }
                                                                elseif($response['STATUS']=='196')
                                                                {
                                                                        $code = 300;
                                                                }

                                                                if(isset($response['BNKREFNO']) && $response['BNKREFNO'] !="")
                                                                {
                                                                        $event_number = substr($response['BNKREFNO'], -6);
                                                                }
                                                                else
                                                                {
                                                                        $code = 404;
                                                                }
                                                                $status[] = $code;

                                                                $data_to_save[$instructions[0]['Id_0']]['Num_evenement'] = $event_number;
                                                                $data_to_save[$instructions[0]['Id_0']]['code'] = $code;
                                                        }
                                                        else
                                                        {
                                                                # erreur CBS
                                                                $code = 411;
                                                                $status[] = $code;
                                                        }
                                                }

                                                if(isset($cbd_returns[0]['Result_6']) && $cbd_returns[0]['Result_6'] !="")
                                                {
                                                        $olddata = json_decode($cbd_returns[0]['Result_6'], true);

                                                        foreach($olddata as $key => $value):

                                                                if($key == $data['Id_0'] && $code =='200'):
                                                                        $newdata[$key]['Num_evenement'] = $event_number;
                                                                        $newdata[$key]['code'] = $code;
                                                                else:
                                                                        if(isset($value['Num_evenement']) && $value['Num_evenement'] !=""):
                                                                                if(isset($value['Num_evenement']))$newdata[$key]['Num_evenement'] = $value['Num_evenement'];
                                                                                if(isset($value['code'])) $newdata[$key]['code'] = $value['code'];
                                                                        endif;
                                                                endif;
                                                        endforeach;
                                                }

                                                $pid = $this->finacleModel->update_return_immatriculation($newdata, $data['Paiementid_4'], $data['Beneficaire_15']);

                                                if(in_array('404', $status))
                                                {
                                                        # compte fermé, chapitre non autorisé, sens du compte incorrect, saisie arrête BCC.
                                                        $newdata['response'] = 404;
                                                }
                                                elseif(in_array('300', $status))
                                                {
                                                        # solde insuffisant, désaccord commercial ou administratif.
                                                        $newdata['response'] = 300;
                                                }
                                                else
                                                {
                                                        $newdata['response'] = 200;
                                                }

                                                $result_to_save = json_encode($newdata);

                                                $this->finacleModel->save_log("Resultat final: ".$result_to_save, "virement");

                                                return $newdata;

                                        }
                                        else
                                        {
                                                $data_to_save['response'] = 405;
                                                $result_to_save = json_encode($data_to_save);

                                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                                return $data_to_save;
                                        }
                                }
                                else
                                {
                                        $data_to_save['response'] = 405;
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                        return $data_to_save;
                                }
                        }
                        else
                        {
                                $data_to_save['response'] = 405;
                                $result_to_save = json_encode($data_to_save);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                return $data_to_save;
                        }
                }

                public function check_transaction_immatriculation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */

                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i =1;
                        $j = 0;

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";
                        if (empty($data['Id_0'])) $failled[] = 'Data Paiementid is empty';
                        if (empty($data['Logirefid_4'])) $failled[] = 'Data Logirefid_4 is empty';

                        if(count($failled) == 0)
                        {
                                $instructions = $this->finacleModel->get_integrations_dgi_immatriculation_by_id($data['Id_0']);

                                $cbd_returns = $this->finacleModel->get_cbs_returns_immatriculation_by_paiementid($data['Paiementid_4']);

                                if(!empty($instructions))
                                {
                                        $compte1 = explode('-', $instructions[0]["Compte_9"]);
                                        $compte2 = explode('-', $instructions[0]["Compte_13"]);

                                        $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                        $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                        $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                        $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                        if($agence1 == "") $failled[] = "Ligne: ".' agence1 is empty';
                                        if($agence2 == "") $failled[] = "Ligne : ".' agence2 is empty';
                                        if($account_src == "") $failled[] = "Ligne: ".' account_src is empty';
                                        if($account_dst == "") $failled[] = "Ligne : ".' account_dst is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne : ".' devise is empty';
                                        if($instructions[0]["Montant_10"] == "" || $instructions[0]["Montant_10"] == 0 ||  $instructions[0]["Montant_10"] < 0) $failled[] = "Ligne : ".' Montant is empty or invalide';
                                        if($instructions[0]["Libelle_12"] == "") $failled[] = "Ligne : ".' Libelle_12 is empty';
                                        if($instructions[0]["Devise_11"] == "") $failled[] = "Ligne : ".' Devise_11 is empty';

                                        if(count($failled) == 0)
                                        {
                                                $agence1 = isset($compte1[0]) ? $compte1[0] : "";
                                                $agence2 = isset($compte2[0]) ? $compte2[0] : "";

                                                $account_src = isset($compte1[1]) ? $compte1[1] : "";
                                                $account_dst = isset($compte2[1]) ? $compte2[1] : "";

                                                $libelle = str_replace('\'','',$instructions[0]["Libelle_12"]);
                                                $libelle = str_replace('&','',$libelle);
                                                $libelle= str_replace('$','',$libelle);
                                                $libelle = str_replace('é','',$libelle);
                                                $libelle = str_replace('è','',$libelle);
                                                $libelle = str_replace('ê','',$libelle);
                                                $libelle = str_replace('î','',$libelle);
                                                $libelle = str_replace('ç','',$libelle);
                                                $libelle = str_replace('ù','',$libelle);
                                                $libelle = str_replace('û','',$libelle);

                                                $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                                $requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                                $exchange_rate  = $data['Taux_41'] ?? "";
                                                $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                                                $rate_code      = $infos['rate_code'] ?? "TTB";

                                                $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                                $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                                $xferTrnDetail = [];

                                                $xferTrnDetail[] = [
                                                        'AcctId'                => ['AcctId' => $account_src, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                        'CreditDebitFlg'        => 'D',
                                                        'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                        'ValueDt'               => $date,
                                                        'TrnParticulars'        => substr($libelle, 0, 50),
                                                        'PartTrnRmks'           => substr($libelle, 15, 30),
                                                        'RateCode'              => $rate_code,
                                                        'Rate'                  => $exchange_rate,
                                                        'SerialNum'             => 0
                                                ];

                                                $xferTrnDetail[] = [
                                                        'AcctId'                => ['AcctId' => $account_dst, 'AcctCurr' => $instructions[0]["Devise_11"]],
                                                        'CreditDebitFlg'        => 'C',
                                                        'TrnAmt'                => ['amountValue' => $instructions[0]["Montant_10"], 'currencyCode' => $instructions[0]["Devise_11"]],
                                                        'ValueDt'               => $date,
                                                        'TrnParticulars'        => substr($libelle, 0, 50),
                                                        'PartTrnRmks'           => substr($libelle, 15, 30),
                                                        'RateCode'              => $rate_code,
                                                        'Rate'                  => $exchange_rate,
                                                        'SerialNum'             => 1
                                                ];

                                                $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                                                $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                                                $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                                                //$response = $this->finacleModel->account_event($data_to_send);
                                                $response['STATUS'] = '000';
                                                $response['BNKREFNO'] = '';

                                                if(isset($response['STATUS']) && $response['STATUS'] != NULL)
                                                {
                                                        if($response['STATUS']=='000')
                                                        {
                                                                $code = 200;
                                                        }
                                                        elseif($response['STATUS']=='196')
                                                        {
                                                                $code = 300;
                                                        }
                                                }
                                                else
                                                {
                                                        $code = 411;
                                                }

                                                $data_to_save['response'] = $code;

                                                $result_to_save = json_encode($data_to_save);

                                                $this->finacleModel->save_log("Code retour de la verification de transaction: : ".$result_to_save, "verification");

                                                return $data_to_save;
                                        }
                                        else
                                        {
                                                $data_to_save['response'] = 405;
                                                $result_to_save = json_encode($data_to_save);

                                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "verification");

                                                return $data_to_save;
                                        }

                                }
                                else
                                {
                                        $data_to_save['response'] = 405;
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "verification");

                                        return $data_to_save;
                                }
                        }
                        else
                        {
                                $data_to_save['response'] = 405;
                                $result_to_save = json_encode($data_to_save);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "verification");

                                return $data_to_save;
                        }
                }

                public function regularize_payment_treatment($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $obj = isset($data['object']) ? $data['object'] : '';
                        $id = isset($data['transactionid']) ? $data['transactionid'] : '';
                        $logirefid = '';
                        $paiementid = '';

                        if($obj == "declaration")
                        {
                                $data = [];

                                $data['Id_0'] = $_POST['transactionid'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                                $data['Logirefid_4'] = $logirefid = $_POST['reference'].$id;
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = $_POST['regie'];

                                // Forcage de l'ecriture
                                if($_POST['action'] == "forcing")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->regularize($data);

                                        $succes = [];
                                        $return = [];
                                        $return['validate'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }

                                        echo json_encode($return);
                                        die;

                                }
                                elseif($_POST['action'] == "reverse")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->extourne($data);

                                        $succes = array();
                                        $return = array();
                                        $return['delete'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }

                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }

                                        echo json_encode($return);
                                        die;
                                }
                                elseif($_POST['action'] == "verify")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->check_transaction($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans amplitude veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }
                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }

                                        echo json_encode($return);
                                        die;
                                }

                        }
                        elseif($obj == "immatriculation")
                        {
                                $data = [];

                                $data['Id_0'] = $_POST['transactionid'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                                $data['Logirefid_4'] = $logirefid = $_POST['reference'].$id;
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = $_POST['regie'];

                                // Forcage de l'ecriture
                                if($_POST['action'] == "forcing")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->regularize_immatriculation($data);

                                        $succes = [];
                                        $return = [];
                                        $return['validate'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_immatriculation($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }

                                        echo json_encode($return);
                                        die;

                                }
                                elseif($_POST['action'] == "reverse")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->extourne_immatriculation($data);

                                        $succes = array();
                                        $return = array();
                                        $return['delete'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_immatriculation($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }

                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }

                                        echo json_encode($return);
                                        die;
                                }
                                elseif($_POST['action'] == "verify")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->check_transaction_immatriculation($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans amplitude veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_immatriculation($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }
                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }

                                        echo json_encode($return);
                                        die;
                                }

                        }
                        elseif($obj == "note")
                        {
                                $data = array();
                                $data['Id_0'] = $_POST['transactionid'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                                $data['Logirefid_4'] = $logirefid = $_POST['reference'].$id;
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = $_POST['regie'];

                                // Forcage de l'ecriture
                                if($_POST['action'] == "forcing")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->regularize($data);

                                        $succes = array();
                                        $return = array();
                                        $return['validate'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }
                                        echo json_encode($return);
                                        die;

                                }
                                elseif($_POST['action'] == "reverse")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->extourne($data);

                                        $succes = array();
                                        $return = array();
                                        $return['delete'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        if(!in_array('3', $succes) || !in_array('1', $succes) || !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }

                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }
                                        echo json_encode($return); die;
                                }
                                elseif($_POST['action'] == "verify")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->check_transaction($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans amplitude veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                                        {
                                                $return['validate'] = true;
                                        }
                                        if(!in_array('2', $succes))
                                        {
                                                $return['delete'] = true;
                                        }

                                        echo json_encode($return);
                                        die;
                                }
                        }
                        elseif($obj == "bulletin")
                        {
                                $data['Priority'] = 1;
                                $data['Id_0'] = $_POST['transactionid'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Logirefid_4'] = $_POST['reference'].$id;
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = $_POST['regie'];
                                $data['Sydonia_44'] = $paiementid = $_POST['paiementid'];

                                // Forcage de l'ecriture
                                if($_POST['action'] == "forcing")
                                {
                                        $this->historicize_regularisations($id, $_POST['action']);

                                        #Invocation of the api transfer
                                        $result = $this->regularize($data);

                                        $succes = array();
                                        $return = array();
                                        $return['validate'] = false;

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_instructions_dgda($paiementid);

                                        echo json_encode($return);
                                        die;

                                }
                                elseif($_POST['action'] == "reverse")
                                {
                                        $this->historicize_regularisations($id, $_POST['action']);

                                        #Invocation of the api transfer
                                        $result = $this->extourne($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                                $return['response'] = "E".$result['response'];

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; amplitude avec succ&egrave;s mais il y a eu aucun retour d\'amplitude, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        echo json_encode($return);
                                        die;
                                }
                                elseif($_POST['action'] == "verify")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->check_transaction($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E200';
                                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E300';
                                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans amplitude veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '404')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E404';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '411')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                                $return['response'] = 'E411';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        elseif($result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = 'E405';
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                                $return['response'] = "E".$result['response'];
                                                $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Amplitude n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                        }

                                        echo json_encode($return);
                                        die;
                                }
                        }
                        elseif($obj == "prepayment")
                        {
                                $data['Priority'] = 1;
                                $data['Id_0'] = $_POST['transactionid'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Logirefid_4'] = $_POST['reference'].$id;
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Beneficaire_15'] = $_POST['regie'];
                                $data['Sydonia_49'] = $paiementid = $_POST['paiementid'];
                                $data['Type'] = 'prepayment';

                                // Forcage de l'ecriture
                                if($_POST['action'] == "forcing")
                                {
                                        $this->save('regularisation', $id, $_POST['action']);

                                        $succes = array();
                                        $return = array();
                                        $return['validate'] = false;

                                        #Invocation of the api transfer
                                        $result = $this->regularize($data);

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E200";

                                        }
                                        elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }

                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_prepayment_instructions($paiementid);
                                        foreach($instructions as $value):
                                                $succes[] = $value->Status_2;
                                        endforeach;

                                        if(!in_array('3', $succes) && !in_array('1', $succes))
                                        {
                                                $return['validate'] = true;
                                        }
                                        echo json_encode($return);
                                        die;

                                }
                                elseif($_POST['action'] == "reverse")
                                {
                                        $this->save('regularisation', $id, $_POST['action']);

                                        #Invocation of the api transfer
                                        $result = $this->extourne($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E200";

                                        }
                                        elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }
                                        else
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }
                                        // check if all integrations  are integrated with success
                                        $instructions  = $this->comptabilisationModel->get_prepayment_instructions($paiementid);
                                        foreach($instructions as $value):
                                        $succes[] = $value->Status_2;
                                        endforeach;

                                        echo json_encode($return);
                                        die;
                                }
                                elseif($_POST['action'] == "verify")
                                {
                                        #Invocation of the api transfer
                                        $result = $this->check_transaction($data);

                                        $succes = array();
                                        $return = array();

                                        if($result['response'] == '200')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 2;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E200";
                                        }
                                        elseif($result['response'] == '300')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }
                                        elseif($result['response'] == '411' || $result['response'] == '405')
                                        {
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                                $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                                $return['response'] = "E".$result['response'];
                                        }
                                        echo json_encode($return);
                                        die;
                                }
                        }
                }

                public function check_transaction($data){}

                public function extourne($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */

                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $i =1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                        if(!isset($data["Designation_14"]) || $data["Designation_14"] == "") $failled [] = "The designation is not defined";
                        if(!isset($data["Id_0"]) || $data['Id_0'] == "") $failled[] = 'Data Paiementid is empty';
                        //if(!isset($data["Logirefid_4"]) || $data['Logirefid_4'] == "") $failled[] = 'Data Logirefid_4 is empty';

                        if(count($failled) == 0)
                        {
                                if(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA')
                                {

                                        if(isset($data['Type']) && $data['Type'] == "prepayment")
                                        {
                                                // Integration to regulate
                                                $instructions = $this->finacleModel->get_prepayment_integrations_by_id($data['Id_0']);

                                                // Old CBS returns to update
                                                $cbd_returns = $this->finacleModel->get_prepayment_cbs_returns_by_paiementid($data['Sydonia_49']);
                                        }
                                        else
                                        {
                                                // Integration to reverse
                                                $instructions = $this->finacleModel->get_integrations_dgda_by_id($data['Id_0']);

                                                // Old CBS returns to update
                                                $cbd_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Sydonia_44'], $data['Beneficaire_15']);
                                        }
                                }
                                elseif(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGI')
                                {
                                        // Integration to reverse
                                        $instructions = $this->finacleModel->get_integrations_dgi_by_id($data['Id_0']);

                                        // Old CBS returns to update
                                        $cbd_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);

                                }
                                elseif(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGRAD')
                                {
                                        // Integration to reverse
                                        $instructions = $this->finacleModel->get_integrations_dgrad_by_id($data['Id_0']);

                                        // Old CBS returns to update
                                        $cbd_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                                }

                                if(!empty($instructions))
                                {
                                        $type = $data['Type'] ?? '';
                                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                        $requestuuid = mt_rand(1, 99) . date('Hisjmy') . mt_rand(100, 999);

                                        $exchange_rate = $data['Taux_41'] ?? "";
                                        $rate_code = $infos['rate_code'] ?? "TTB";

                                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                        $xferTrnHdr = [
                                                'TrnType' => 'T',
                                                'TrnSubType' => 'CI'
                                        ];

                                        $xferTrnDetail = [];
                                        $i = 0;

                                        $failled = [];

                                        foreach ($return as $row)
                                        {
                                                $compte_src = str_replace('-', '', $row["Compte_9"] ?? "");
                                                $compte_dst = str_replace('-', '', $row["Compte_13"] ?? "");

                                                $montant = $row["Montant_10"] ?? 0;
                                                $devise  = $row["Devise_11"] ?? "";

                                                if (empty($compte_src)) $failled[] = "Compte source vide ligne $i";
                                                if (empty($compte_dst)) $failled[] = "Compte destination vide ligne $i";
                                                if ($montant <= 0) $failled[] = "Montant invalide ligne $i";
                                                if (empty($devise)) $failled[] = "Devise vide ligne $i";

                                                if ($montant <= 0 || empty($compte_src) || empty($compte_dst)) {
                                                        continue;
                                                }

                                                $libelle = $this->remove_all_special_characters($row["Libelle_12"] ?? "");

                                                // DEBIT
                                                $xferTrnDetail[] = [
                                                        'AcctId' => [
                                                                'AcctId' => $compte_src,
                                                                'AcctCurr' => $devise
                                                        ],
                                                        'CreditDebitFlg' => 'D',
                                                        'TrnAmt' => [
                                                                'amountValue' => $montant,
                                                                'currencyCode' => $devise
                                                        ],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($libelle, 0, 50),
                                                        'PartTrnRmks' => substr($libelle, 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i
                                                ];

                                                // CREDIT
                                                $xferTrnDetail[] = [
                                                        'AcctId' => [
                                                                'AcctId' => $compte_dst,
                                                                'AcctCurr' => $devise
                                                        ],
                                                        'CreditDebitFlg' => 'C',
                                                        'TrnAmt' => [
                                                                'amountValue' => $montant,
                                                                'currencyCode' => $devise
                                                        ],
                                                        'ValueDt' => $date,
                                                        'TrnParticulars' => substr($libelle, 0, 50),
                                                        'PartTrnRmks' => substr($libelle, 15, 30),
                                                        'RateCode' => $rate_code,
                                                        'Rate' => $exchange_rate,
                                                        'SerialNum' => $i + 1
                                                ];

                                                $i++;
                                        }

                                        if (count($failled) > 0)
                                        {
                                                $data_to_save = [
                                                        'response' => 405,
                                                        'errors' => $failled
                                                ];

                                                $this->finacleModel->save_log("Erreur validation: " . json_encode($data_to_save));

                                                return json_encode($data_to_save);
                                        }

                                        $xferTrnAddRq = [
                                                'XferTrnHdr' => $xferTrnHdr,
                                                'XferTrnDetail' => $xferTrnDetail
                                        ];

                                        $xferTrnAddRequest = [
                                                'XferTrnAddRq' => $xferTrnAddRq
                                        ];

                                        $data_to_send['Header'] = $requestHeader;
                                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                                        $this->finacleModel->save_log("Request CBS: " . json_encode($data_to_send));

                                        $response = $this->finacleModel->payment_transfer($data_to_send);

                                        $result = $this->handleCBSResponse($response, $data, $return, $type);

                                        $data_to_return = $result['data_to_return'];
                                        $data_to_save   = $result['data_to_save'];

                                        if ($data['Beneficaire_15'] == 'DGDA')
                                        {
                                                if (isset($data['Type']) && $data['Type'] == "prepayment")
                                                {
                                                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'],$data_to_save,$data['Sydonia_49']);
                                                }
                                                elseif (isset($data['Type']) && $data['Type'] == "others")
                                                {
                                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'],$data_to_save,$data['Sydonia_44']);
                                                }
                                                else
                                                {
                                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'],$data_to_save,$data['Sydonia_44']);
                                                }
                                        }
                                        else
                                        {
                                                $this->finacleModel->save_cbs_return($data['Account_3'],$data_to_save,$data['Id_0']);
                                        }

                                        return $data_to_return;
                                }
                                else
                                {
                                        $data_to_save['response'] = 405;
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                        return $data_to_save;
                                }
                        }
                        else
                        {
                                $data_to_save['response'] = 405;
                                $result_to_save = json_encode($data_to_save);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "cancel reservation");

                                return $data_to_save;
                        }
                }

                public function regularize($data)
                {
                        $failled = [];
                        $newdata = [];
                        $status = [];
                        $code = '';
                        $event_number = null;

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";

                        if (!empty($failled))
                        {
                                $response = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request"
                                ];

                                $this->finacleModel->save_log(json_encode($failled), "regularize");

                                return json_encode($response);
                        }

                        $type = $data['Type'] ?? '';

                        if ($data['Beneficaire_15'] == 'DGDA')
                        {
                                if ($type == "prepayment")
                                {
                                        $instructions = $this->finacleModel->get_prepayment_integrations_by_id($data['Id_0']);
                                        $cbs_returns = $this->finacleModel->get_prepayment_cbs_returns_by_paiementid($data['Sydonia_49']);
                                }
                                else
                                {
                                        $instructions = $this->finacleModel->get_integrations_dgda_by_id($data['Id_0']);
                                        $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                                }
                        }
                        elseif ($data['Beneficaire_15'] == 'DGI')
                        {
                                $instructions = $this->finacleModel->get_integrations_dgi_by_id($data['Id_0']);
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                        }
                        elseif ($data['Beneficaire_15'] == 'DGRAD')
                        {
                                $instructions = $this->finacleModel->get_integrations_dgrad_by_id($data['Id_0']);
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                        }

                        if (empty($instructions))
                        {
                                return json_encode([
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing integration data"
                                ]);
                        }

                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        $requestuuid = mt_rand(1, 99) . date('Hisjmy') . mt_rand(100, 999);

                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                        $xferTrnHdr = [
                                'TrnType' => 'T',
                                'TrnSubType' => 'CI'
                        ];

                        $xferTrnDetail = [];
                        $i = 0;

                        foreach ($instructions as $row)
                        {
                                if ($row['Montant_10'] <= 0) continue;

                                $compte1 = str_replace('-', '', $row["Compte_9"]);
                                $compte2 = str_replace('-', '', $row["Compte_13"]);

                                $libelle = $this->remove_all_special_characters($row["Libelle_12"]);

                                // DEBIT
                                $xferTrnDetail[] = [
                                        'AcctId' => [
                                                'AcctId' => $compte1,
                                                'AcctCurr' => $row["Devise_11"]
                                        ],
                                        'CreditDebitFlg' => 'D',
                                        'TrnAmt' => [
                                                'amountValue' => $row["Montant_10"],
                                                'currencyCode' => $row["Devise_11"]
                                        ],
                                        'ValueDt' => $date,
                                        'TrnParticulars' => substr($libelle, 0, 50),
                                        'PartTrnRmks' => substr($libelle, 15, 30),
                                        'SerialNum' => $i
                                ];

                                // CREDIT
                                $xferTrnDetail[] = [
                                        'AcctId' => [
                                                'AcctId' => $compte2,
                                                'AcctCurr' => $row["Devise_11"]
                                        ],
                                        'CreditDebitFlg' => 'C',
                                        'TrnAmt' => [
                                                'amountValue' => $row["Montant_10"],
                                                'currencyCode' => $row["Devise_11"]
                                        ],
                                        'ValueDt' => $date,
                                        'TrnParticulars' => substr($libelle, 0, 50),
                                        'PartTrnRmks' => substr($libelle, 15, 30),
                                        'SerialNum' => $i + 1
                                ];

                                $i++;
                        }

                        $xferTrnAddRq = [
                                'XferTrnHdr' => $xferTrnHdr,
                                'XferTrnDetail' => $xferTrnDetail
                        ];

                        $data_to_send = [
                                'Header' => $requestHeader,
                                'Body' => [
                                        'XferTrnAddRequest' => [
                                                'XferTrnAddRq' => $xferTrnAddRq
                                        ]
                                ]
                        ];

                        //$response = $this->finacleModel->payment_transfer($data_to_send);
                        $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                        $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = "REG123456";

                        $result = $this->handleCBSResponse($response, $data, $instructions, $type);

                        $data_to_return = $result['data_to_return'];
                        $data_to_save   = $result['data_to_save'];

                        if (isset($cbs_returns[0]['Result_6']) && $cbs_returns[0]['Result_6'] != "")
                        {
                                $olddata = json_decode($cbs_returns[0]['Result_6'], true);

                                foreach ($olddata as $key => $value)
                                {
                                        if ($key == $data['Id_0'] && $data_to_save['code'] == 200)
                                        {
                                                $newdata[$key]['Num_evenement'] = $data_to_save['Num_evenement'] ?? '';
                                                $newdata[$key]['code'] = 200;
                                        }
                                        else
                                        {
                                                $newdata[$key] = $value;
                                        }
                                }
                        }

                        if ($data['Beneficaire_15'] == 'DGDA')
                        {
                                if ($type == "prepayment")
                                {
                                        $this->finacleModel->update_prepayment_return($newdata, $data['Sydonia_49']);
                                }
                                else
                                {
                                        $this->finacleModel->update_return($newdata, $data['Paiementid_4'], $data['Beneficaire_15']);
                                }
                        }
                        else
                        {
                                $this->finacleModel->update_return($newdata, $data['Paiementid_4'], $data['Beneficaire_15']);
                        }

                        $this->finacleModel->save_log(json_encode($data_to_save), "regularize");

                        return json_encode($data_to_return);
                }

                public function save($obj, $id, $action)
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Action_1'] = $action;
                        $data['User_2'] = $this->session->userdata["user_id"];
                        $data['Date_3'] = date('Y-m-d H:i:s');
                        $data['Object_4'] = $obj;

                        if($obj == "regularisation")
                        {
                                return $this->comptabilisationModel->save_regularisation($data);
                        }
                }

                public function historicize_regularisations($instructionid, $action)
                {
                        $lines = $this->comptabilisationModel->get_instructions_dgda_by_id($instructionid);

                        if(!empty($lines))
                        {
                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                $data['Paiementid_4']=$lines->Paiementid_4;
                                $data['Agence_6']=$lines->Agence_6;
                                $data['Guichet_7']=$lines->Guichet_7;
                                $data['Operation_8']=$lines->Operation_8;
                                $data['Compte_9']=$lines->Compte_9;
                                $data['Montant_10']=$lines->Montant_10;
                                $data['Devise_11']=$lines->Devise_11;
                                $data['Libelle_12']=$lines->Libelle_12;
                                $data['Compte_13']=$lines->Compte_13;
                                $data['Reference_14']=$lines->Reference_14;
                                $data['Mode_15']=$lines->Mode_15;
                                $data['Makerid_16']=$lines->Makerid_16;
                                $data['Checkerid_17']=$lines->Checkerid_17;
                                $data['Validation_18']=$lines->Validation_18;
                                $data['Integration_20']= gmdate('Y-m-d H:i:s');
                                if($action == 'reverse') $data['Action_21']= 'Extourne'; else $data['Action_21'] = 'Regularisation';

                                $this->comptabilisationModel->save_regularisations($data, NULL);
                        }
                }

                private function prepareRequestHeader($requestuuid, $date)
                {
                        return [
                                'RequestHeader' => [
                                        'MessageKey' => [
                                                'RequestUUID' => $requestuuid,
                                                'ServiceRequestId' => 'XferTrnAdd',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'RDC',
                                                'LanguageId' => '',
                                        ],
                                        'RequestMessageInfo' => [
                                                'BankId' => '43',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                        ],
                                        'Security' => [
                                                'Token' => [
                                                        'PasswordToken' => [
                                                                'UserId' => '',
                                                                'Password' => ''
                                                        ],
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                ]
                                        ]
                                ]
                        ];
                }

                private function handleCBSResponse($response, $data, $return, $type)
                {
                        $data_to_save = [];
                        $data_to_return = [];

                        $status = $response['Header']['ResponseHeader']['HostTransaction']['Status'] ?? '';

                        if ($status === "SUCCESS" || $status === "DUP:SUCCESS") {
                                $code = 200;
                                foreach ($return as $row) 
                                {
                                        $data_to_save[$row['Id_0']] = [
                                                'Num_evenement' => $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] ?? "",
                                                'code' => $code
                                        ];

                                        if($data['Beneficaire_15'] == 'DGI')
                                        {
                                                $this->finacleModel->update_cbs_instructions_dgi($data['Logirefid_4']);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGRAD')
                                        {
                                                $this->finacleModel->update_cbs_instructions_dgrad($data['Logirefid_4']);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGDA' && $type != "prepayment")
                                        {
                                                $pid = (($data['Mode'] ?? "") == "batch") 
                                                        ? $data['Paiementid_4'] 
                                                        : $data['Sydonia_44'];
                                                $this->finacleModel->update_cbs_instructions_dgda($pid);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGDA' && $type == "prepayment")
                                        {
                                                $this->finacleModel->update_cbs_prepayments_instructions_dgda($data['Sydonia_49']);
                                        }
                                }
                                
                                // Mise à jour des instructions passport après les réponses collectées
                                if($data['Beneficaire_15'] == 'DGRAD_PASSPORT')
                                {
                                        $passport_status = ($code === 200) ? 2 : 5;
                                        $this->finacleModel->update_cbs_instructions_passport($data['Logirefid_4'], $passport_status);
                                }
                                
                                $data_to_return = [
                                        'response' => $code,
                                        'code' => $code,
                                        'message' => '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>',
                                        'msg' => '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];
                        }
                        else {
                                $error_code = $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"][0]["ErrorCode"] ?? 'E411';
                                
                                // Mise à jour des instructions passport avec statut 5 en cas d'erreur
                                if($data['Beneficaire_15'] == 'DGRAD_PASSPORT')
                                {
                                        $this->finacleModel->update_cbs_instructions_passport($data['Logirefid_4'], 5);
                                }
                                
                                $msg = '<div class="alert aDanger text-white">Une erreur est survenue: ' . $error_code . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $data_to_return = [
                                        'code' => $error_code,
                                        'response' => $error_code,
                                        'message' => $msg,
                                        'msg' => $msg
                                ];
                                $this->finacleModel->save_log("Erreur CBS: " . json_encode($response));
                        }

                        return [
                                'data_to_return' => $data_to_return,
                                'data_to_save'   => $data_to_save
                        ];
                }

                private function handlePassportResponse($response, $data, $return)
                {
                        $data_to_save = [];
                        $data_to_return = [];
                        $error_code = 'E411';

                        // Mapping des codes d'erreur avec leurs messages en français
                        $error_messages = [
                                'E162' => 'Le compte n\'existe pas',
                                'E463' => 'La transaction n\'est pas équilibrée',
                                'E3238' => 'Différence de devise',
                                'E397' => 'Les détails supplémentaires ne sont pas entrés',
                                'W0205' => 'Le montant du retrait ne peut pas dépasser le solde du compte',
                                'AD3' => 'Transaction non autorisée sur ce type de compte',
                                'E9999' => 'Erreur interne du système',
                                'ERR002' => 'Données invalides',
                                'ERR003' => 'Authentification échouée',
                                'P83' => 'Les transactions aux comptes de négociation ne sont pas autorisées',
                                'E411' => 'Erreur générale'
                        ];

                        $status = $response['Header']['ResponseHeader']['HostTransaction']['Status'] ?? '';

                        if ($status === "SUCCESS" || $status === "DUP:SUCCESS") 
                        {
                                $code = 200;

                                foreach ($return as $row)
                                {
                                        $data_to_save[$row['Id_0']] = [
                                                'Num_evenement' => $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] ?? "",
                                                'code' => $code,
                                                'response' => $code
                                        ];
                                }

                                // Mise à jour des instructions passport avec statut 2 pour SUCCESS
                                $passport_status = ($code === 200) ? 2 : 5;
                                $this->finacleModel->update_cbs_instructions_passport($data['Logirefid_4'], $passport_status,$data['Priority_27']);

                                $data_to_return = [
                                        'response' => $code,
                                        'code' => $code,
                                        'message' => 'Paiement validé avec succès.',
                                        'msg' => '<div class="alert aSuccess text-white">Bravo! paiement validé avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];
                        }
                        else
                        {
                                // Gestion détaillée des erreurs (format tableau)
                                if (isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"][0]))
                                {
                                        $error_detail = $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"][0]["ErrorCode"] ?? 'E411';

                                        if ($error_detail == '162') {
                                                $error_code = 'E162';
                                        } elseif ($error_detail == '463') {
                                                $error_code = 'E463';
                                        } elseif ($error_detail == 'E3238') {
                                                $error_code = 'E3238';
                                        } elseif ($error_detail == '397') {
                                                $error_code = 'E397';
                                        } elseif ($error_detail == 'W0205') {
                                                $error_code = 'W0205';
                                        } elseif ($error_detail == 'AD3') {
                                                $error_code = 'AD3';
                                        } elseif ($error_detail == '9999') {
                                                $error_code = 'E9999';
                                        } elseif ($error_detail == 'ERR002') {
                                                $error_code = 'ERR002';
                                        } elseif ($error_detail == 'ERR003') {
                                                $error_code = 'ERR003';
                                        } elseif ($error_detail == 'P83') {
                                                $error_code = 'P83';
                                        } elseif ($error_detail == 'AP3') {
                                                $error_code = 'AD3';
                                        }
                                }
                                // Gestion détaillée des erreurs (format objet)
                                elseif (isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]))
                                {
                                        $error_detail = $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"];

                                        if ($error_detail == '162') {
                                                $error_code = 'E162';
                                        } elseif ($error_detail == '463') {
                                                $error_code = 'E463';
                                        } elseif ($error_detail == 'E3238') {
                                                $error_code = 'E3238';
                                        } elseif ($error_detail == '397') {
                                                $error_code = 'E397';
                                        } elseif ($error_detail == 'W0205') {
                                                $error_code = 'W0205';
                                        } elseif ($error_detail == 'AD3') {
                                                $error_code = 'AD3';
                                        } elseif ($error_detail == '9999') {
                                                $error_code = 'E9999';
                                        } elseif ($error_detail == 'ERR002') {
                                                $error_code = 'ERR002';
                                        } elseif ($error_detail == 'ERR003') {
                                                $error_code = 'ERR003';
                                        } elseif ($error_detail == 'P83') {
                                                $error_code = 'P83';
                                        } elseif ($error_detail == 'AP3') {
                                                $error_code = 'AD3';
                                        }
                                }

                                $data_to_save['response'] = $error_code;
                                $data_to_save['message'] = $error_messages[$error_code] ?? $error_messages['E411'];

                                // Mise à jour des instructions passport avec statut 5 pour les erreurs
                                $this->finacleModel->update_cbs_instructions_passport($data['Logirefid_4'], 5,$data['Priority_27']);

                                $error_message = $error_messages[$error_code] ?? $error_messages['E411'];
                                $msg = '<div class="alert aDanger text-white">Une erreur est survenue: ' . $error_code . ' - ' . $error_message . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $data_to_return = [
                                        'code' => $error_code,
                                        'response' => $error_code,
                                        'message' => $error_message,
                                        'msg' => $msg
                                ];

                                $this->finacleModel->save_log("Erreur passport payment_transfer: " . json_encode($response), "passport");
                        }

                        return [
                                'data_to_return' => $data_to_return,
                                'data_to_save'   => $data_to_save
                        ];
                }

                public function reservation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Initialization
                        * ------------------------------------------------
                        */
                        $data_to_send = array();
                        $response = array();
                        $account_number = '';
                        $currency = '';
                        $amount = '';
                        $failled = array();

                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['compte'])) $failled[] = 'The account is not defined';
                        else  $account_number = $data['compte'];

                        if(!isset($data['montant'])) $failled[] = 'The amount is not defined';
                        else  $amount = $data['montant'];

                        if(!isset($data['devise'])) $failled[] = 'The currency is not defined';
                        else  $currency = $data['devise'];
                        
                        if(count($failled) == 0)
                        {
                                $account=str_replace("-","",$account_number);
                                /*
                                * ------------------------------------------------
                                * Construction of data to send to the CBS
                                * ------------------------------------------------
                                */

                                $requestuuid =  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                $messageKey = array(
                                'RequestUUID'=>$requestuuid,
                                'ServiceRequestId'=>'AcctLienAdd',
                                'ServiceRequestVersion'=>'10.2',
                                'ChannelId'=>'RDC',
                                'LanguageId'=>'',
                                );

                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;



                                $AcctLienAddRq = array(
                                                'AcctId'=>array(
                                                        'AcctId'=>$account
                                                ),
                                                'ModuleType'=>'ULIEN',
                                                'LienDtls'=> array(
                                                        'LienId'=>'ULIEN001',
                                                        'NewLienAmt'=>array(
                                                        'amountValue'=>$amount,
                                                        'currencyCode'=>$currency
                                                        ),
                                                        'LienDt'=>array(
                                                        'StartDt'=>$date,
                                                        'EndDt'=>$date
                                                        ),
                                                        'ReasonCode'=>'OTH',
                                                        'Rmks'=>'Lien Remarks'
                                                )
                                        );

                                $AcctLienAddRequest['AcctLienAddRq'] = $AcctLienAddRq;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['AcctLienAddRequest'] = $AcctLienAddRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                //$response = $this->finacleModel->add_lien_account($data_to_send);
                                $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";

                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS")
                                {
                                        $code = 200;
                                        //$lien = isset($response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"]) ? $response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"] : "";
                                        //$date = isset($response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime']) ? $response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime'] : "";
                                        $lien = "19921003";
                                        $date = "20260519";

                                        $data_to_save['code']=$code;
                                        $data_to_save['response'] = $code;
                                        $data_to_save['lien'] = $lien;
                                        $data_to_save['date'] = $date;
                                }
                                else
                                {
                                        
                                        $info = json_encode($response);
                                        $this->finacleModel->save_log("Erreur : ".$info);

                                        if(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='008')
                                        {
                                                //Record already exists
                                                $data_to_save['code'] = 'E008';
                                                $data_to_save['response'] = 'E008';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='E6580')
                                        {
                                                //wrong date of reservation
                                                $data_to_save['code'] = 'E6580';
                                                $data_to_save['response'] = 'E6580';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='162')
                                        {
                                                //The account does not exist.
                                                $data_to_save['code'] = 'E162';
                                                $data_to_save['response'] = 'E162';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='E4348')
                                        {
                                                //The lien can be placed only on accounts of SBA, CAA, CCA, ODA, BIA, FBA OR TDA.
                                                $data_to_save['code'] = 'E4348';
                                                $data_to_save['response'] = 'E4348';
                                        }
                                        else
                                        {
                                                return '411';
                                        }

                                }

                                $result_to_save = json_encode($data_to_save);
                                $this->finacleModel->save_log("Resultat final :".$result_to_save);
                                
                                return json_encode($data_to_save);
                        }
                        else
                        {
                                $return['code'] = 405;
                                $return['response'] = 405;
                                $return['message'] = "Missing data in the request";
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "reservation");

                                return json_encode($return);
                        }
                }

                /*public function cancel_reservation($data)
                {
                        $data_to_send = array();
                        $response = array();
                        $account_number = '';
                        $currency = '';
                        $amount = '';
                        $failled = array();
                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                        if(!isset($data['lien_id'])) $failled[] = 'The account is not defined';
                        else  $account_number = $data['lien_id'];

                        if(!isset($data['montant'])) $failled[] = 'The date of the lien is not defined';
                        else  $amount = $data['montant'];

                        if(!isset($data['devise'])) $failled[] = 'The currency is not defined';
                        else  $currency = $data['devise'];

                        if(count($failled) == 0)
                        {
                                $account=str_replace("-","",$account_number);

                                $requestuuid =  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                $messageKey = array(
                                'RequestUUID'=>$requestuuid,
                                'ServiceRequestId'=>'AcctLienAdd',
                                'ServiceRequestVersion'=>'10.2',
                                'ChannelId'=>'RDC',
                                'LanguageId'=>'',
                                );

                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;

                                $AcctLienAddRq = array(
                                                'AcctId'=>array(
                                                        'AcctId'=>$account
                                                ),
                                                'ModuleType'=>'ULIEN',
                                                'LienDtls'=> array(
                                                        'LienId'=>'ULIEN001',
                                                        'NewLienAmt'=>array(
                                                        'amountValue'=>$amount,
                                                        'currencyCode'=>$currency
                                                        ),
                                                        'LienDt'=>array(
                                                        'StartDt'=>$date,
                                                        'EndDt'=>$date
                                                        ),
                                                        'ReasonCode'=>'OTH',
                                                        'Rmks'=>'Lien Remarks'
                                                )
                                        );

                                $AcctLienAddRequest['AcctLienAddRq'] = $AcctLienAddRq;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['AcctLienAddRequest'] = $AcctLienAddRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                $response = $this->finacleModel->release_lien_account($data_to_send);

                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS")
                                {
                                        $code = 200;
                                        $lien = $response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"] ?? "";
                                        $date = $response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime'] ?? "";

                                        $data_to_save['code'] = $code;
                                        $data_to_save['response'] = $code;
                                        $data_to_save['lien'] = $lien;
                                        $data_to_save['date'] = $date;
                                }
                                else
                                {
                                        $info = json_encode($response);
                                        $this->finacleModel->save_log("Erreur : ".$info);

                                        if(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='008')
                                        {
                                                //Record already exists
                                                $data_to_save['code'] = 'E008';
                                                $data_to_save['response'] = 'E008';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='E6580')
                                        {
                                                //wrong date of reservation
                                                $data_to_save['code'] = 'E6580';
                                                $data_to_save['response'] = 'E6580';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='162')
                                        {
                                                //The account does not exist.
                                                $data_to_save['code'] = 'E162';
                                                $data_to_save['response'] = 'E162';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='E4348')
                                        {
                                                //The lien can be placed only on accounts of SBA, CAA, CCA, ODA, BIA, FBA OR TDA.
                                                $data_to_save['code'] = 'E4348';
                                                $data_to_save['response'] = 'E4348';
                                        }
                                        else
                                        {
                                                return '411'; 
                                        }

                                }

                                $result_to_save = json_encode($data_to_save);
                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                return json_encode($data_to_save);
                        }
                        else
                        {
                                $return['code'] = 405;
                                $return['response'] = 405;
                                $return['message'] = "Missing data in the request";
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "reservation");

                                return json_encode($return);
                        }
                }*/

                public function cancel_reservation($data)
                {
                        $data_to_send = [];
                        $response = [];
                        $failled = [];

                        $date = date("Y-m-d\TH:i:s.v", strtotime('+1 hour'));

                        $account_number = $data['account'] ?? null;
                        $lien_id        = $data['lien_id'] ?? null;
                        $currency       = $data['devise'] ?? null;

                        if (!$account_number) $failled[] = 'Account is required';
                        if (!$lien_id) $failled[] = 'Lien ID is required';
                        if (!$currency) $failled[] = 'Currency is required';

                        if (count($failled) > 0)
                        {
                                return json_encode([
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => 'Missing data in request',
                                        'errors' => $failled
                                ]);
                        }

                        $account = str_replace("-", "", $account_number);

                        $requestuuid = mt_rand(1, 99) . date('HisdmY') . mt_rand(100, 999);

                        $messageKey = [
                                'RequestUUID' => $requestuuid,
                                'ServiceRequestId' => 'AcctLienMod',
                                'ServiceRequestVersion' => '10.2',
                                'ChannelId' => 'RDC',
                                'LanguageId' => ''
                        ];

                        $requestMessageInfo = [
                                'BankId' => '43',
                                'TimeZone' => '',
                                'EntityId' => '',
                                'EntityType' => '',
                                'ArmCorrelationId' => '',
                                'MessageDateTime' => $date
                        ];

                        $security = [
                                'Token' => [
                                        'PasswordToken' => [
                                                'UserId' => '',
                                                'Password' => ''
                                        ]
                                ]
                        ];

                        $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                        $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                        $requestHeader['RequestHeader']['Security'] = $security;

                        $AcctLienModRq = [
                                'AcctId' => [
                                        'AcctId' => $account
                                ],
                                'ModuleType' => 'ULIEN',
                                'LienDtls' => [
                                        'LienId' => $lien_id,
                                        'NewLienAmt' => [
                                                'amountValue' => 0,
                                                'currencyCode' => $currency
                                        ]
                                ]
                        ];

                        $data_to_send['Header'] = $requestHeader;
                        $data_to_send['Body']['AcctLienModRequest']['AcctLienModRq'] = $AcctLienModRq;

                        $this->finacleModel->save_log("Request MOD Lien: " . json_encode($data_to_send));

                        //$response = $this->finacleModel->release_lien_account($data_to_send);
                        $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";

                        if (isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS")
                        {
                                $data_to_save = [
                                        'code' => 200,
                                        'response' => 200,
                                        //'lien' => $response["Body"]["AcctLienModResponse"]["AcctLienModRs"]["LienIdRec"]["LienId"] ?? '',
                                        //'date' => $response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime'] ?? ''
                                ];
                        }
                        else {
                                $data_to_save = [
                                        'code' => '411',
                                        'response' => 'FAILED'
                                ];
                        }

                        $this->finacleModel->save_log("Final Response: " . json_encode($data_to_save));

                        return json_encode($data_to_save);
                }

                public function get_exchange_rate($data)
                {
                        /*
                        * ------------------------------------------------
                        * Initialization
                        * ------------------------------------------------
                        */
                        $data_to_send = array();
                        $data_to_return = array();
                        $response = array();
                        $language = '';
                        $failled = array();
                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['from_currency'])) $failled[] = 'The value from_currency is not defined';
                        else  $from_currency = $data['from_currency'];

                        if(!isset($data['to_currency'])) $failled[] = 'The value to_currency is not defined';
                        else  $to_currency = $data['to_currency'];

                        if(!isset($data['type'])) $failled[] = 'The value type is not defined';
                        else  $type = $data['type'];

                        if(count($failled) == 0)
                        {
                                /*
                                * ------------------------------------------------
                                * Construction of data to send to the CBS
                                * ------------------------------------------------
                                */
                                $requestuuid =  rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $prefix_logs = isset($_POST['note_number']) ? $_POST['note_number'] : "";

                                $messageKey = array(
                                                        'RequestUUID'=>$requestuuid,
                                                        'ServiceRequestId'=>'getExchangeRateForRateCode',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'OMN',
                                                        'LanguageId'=>'',
                                                );
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'54301217289',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;

                                $exchangeRateForRateCodeInputVO = array(
                                                'fromCrncyCode'=>$from_currency,
                                                'rateCode'=>$type,
                                                'toCrncyCode'=>$to_currency
                                        );

                                $getExchangeRateForRateCodeRequest['ExchangeRateForRateCodeInputVO'] = $exchangeRateForRateCodeInputVO;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['getExchangeRateForRateCodeRequest'] = $getExchangeRateForRateCodeRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save, $prefix_logs);

                                //$response = $this->finacleModel->exchange_rate($data_to_send);

                                $response['Header']['ResponseHeader']['HostTransaction']['Status']= 'SUCCESS';
                                $response['Body']["getExchangeRateForRateCodeResponse"]['ExchangeRateForRateCodeOutputVO']['varCrncyUnits'] = 2234.17;

                                if($response['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                                $taux = isset($response['Body']["getExchangeRateForRateCodeResponse"]['ExchangeRateForRateCodeOutputVO']['varCrncyUnits']) ? $response['Body']["getExchangeRateForRateCodeResponse"]['ExchangeRateForRateCodeOutputVO']['varCrncyUnits'] : "";
                                                $return['exchange_rate'] = $taux;
                                                $return['code'] = 200;

                                                return json_encode($return);
                                }
                                else
                                {
                                                $return['code'] = 200;
                                                return json_encode($return);
                                }
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "exchange_rate");

                                return json_encode($return);
                        }
                }

                public function extract_customerid_from_account ($account)
                {
                        // Vérifier si le compte a au moins 16 caractères
                        if (strlen($account) >= 16) {
                        // Éliminer les 6 premiers caractères
                        $account = substr($account, 6);

                        // Extraire les 6 customerid
                        $customerid = substr($account, 0, 6);

                        return $customerid;
                        } else {
                        // Gérer le cas où la chaîne n'a pas la longueur requise
                        return false;
                        }
                }

                public function remove_all_special_characters($texte)
                {
                        // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                        $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                        // Remplacer les espaces par des traits d'union
                        $texte = str_replace('/', '-', $texte);
                        $texte = str_replace(' ', '-', $texte);

                        // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                        //$texte = preg_replace('/[^a-zA-Z0-9]/', '', $texte); // Supprimer les espaces aussi
                        $texte = preg_replace('/[^a-zA-Z0-9\-]/', '', $texte);

                        return $texte;
                }

                public function get_the_total_amount($instructions)
                {
                        $total_amount = 0;

                        foreach ($instructions as $row)
                        {
                                $total_amount = $total_amount + $row["Montant_10"];
                        }

                        return $total_amount;
                }

                public function validate_payment($data)
                {
                        return $this->virement($data);
                }

                /**
                 * Débite un bulletin client en mode **single** (traitement unitaire).
                 *
                 * - Délègue la logique métier à `bulletin_single_integration_treatment`.
                 *
                 * @param array $data Données du bulletin à débiter
                 * @return mixed Résultat du traitement du bulletin unitaire
                 */
                public function debit_customer_bulletin_single($data)
                {
                        $data['Type'] = "first_transaction";
                        return $this->virement($data);
                }

                /**
                 * Débite des bulletins clients en mode **batch** (traitement par lot).
                 *
                 * - Délègue la logique métier à `bulletin_batch_integration_treatment`.
                 *
                 * @param array $data Données des bulletins à débiter en lot
                 * @return mixed Résultat du traitement batch des bulletins
                 */
                public function debit_customer_bulletin_batch($data)
                {
                        $data['Type'] = "first_transaction";
                        $data['Mode'] = "batch";

                        return $this->virement($data);
                }

                public function reservation_prepayment($data)
                {
                        $data['Type'] = 'prepayment';

                        $priority = $data['Priority'] ?? 0;
                        $lot = $data['Sydonia_49'] ?? '';

                        $instructions = $this->finacleModel->get_prepayment_integrations_info($lot, $priority);
                        
                                if (empty($instructions) || !is_array($instructions))
                                {
                                        $this->finacleModel->save_log("Erreur reservation_prepayment: no instructions for lot=" . $lot, "prepayment_reservation");
                                        return ['code' => 405, 'response' => 405, 'lien' => '', 'date' => ''];
                                }

                        $compte = $instructions[0]['Compte_9'] ?? '';
                        $devise = $instructions[0]['Devise_11'] ?? '';
                        $montant = 0;
                        foreach ($instructions as $row)
                        {
                                $m = (float)($row['Montant_10'] ?? 0);
                                if ($m > 0) $montant += $m;
                        }

                        if ($compte === '' || $devise === '' || $montant <= 0)
                        {
                                $this->finacleModel->save_log("Erreur reservation_prepayment: missing compte/devise/montant (lot=" . $lot . ")", "prepayment_reservation");
                                return ['code' => 405, 'response' => 405, 'lien' => '', 'date' => ''];
                        }

                        $reservationResponse = $this->reservation([
                                'compte'  => $compte,
                                'montant' => $montant,
                                'devise'  => $devise,
                        ]);

                        if (is_string($reservationResponse))
                        {
                                $decoded = json_decode($reservationResponse, true);
                                if (is_array($decoded))
                                {
                                        $reservationResponse = $decoded;

                                        $code = $reservationResponse['code'] ?? ($reservationResponse['response'] ?? 405);
                                        $response = $reservationResponse['response'] ?? ($reservationResponse['code'] ?? 405);

                                        return [
                                                'code' => $code,
                                                'response' => $response,
                                                'lien' => $reservationResponse['lien'] ?? '',
                                                'date' => $reservationResponse['date'] ?? '',
                                        ];
                                }
                        }

                        if (is_array($reservationResponse))
                        {
                                $code = $reservationResponse['code'] ?? ($reservationResponse['response'] ?? 405);
                                $response = $reservationResponse['response'] ?? ($reservationResponse['code'] ?? 405);

                                return [
                                        'code' => $code,
                                        'response' => $response,
                                        'lien' => $reservationResponse['lien'] ?? '',
                                        'date' => $reservationResponse['date'] ?? '',
                                ];
                        }
                }

                public function debit_customer_prepayment($data)
                {
                        return $this->bulletin_prepayment_integration_treatment($data);
                }

                public function debit_customer_bulletin_prepayment_integration($data)
                {
                        $data_to_save = [];
                        $data_to_send = [];
                        $status = [];
                        $transaction_return = [];
                        $failled = [];
                        $i = 1;

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data["Designation_14"])) $failled[] = "The designation is not defined";
                        if (empty($data["Account_3"])) $failled[] = "The account is not defined";
                        if (empty($data["Sydonia_49"])) $failled[] = "The batch id is not defined";
                         
                        if (!empty($failled))
                        {
                                $data_to_save['response'] = 405;
                                $this->finacleModel->save_log("Erreur des donnes invalides: " . json_encode($failled), "prepayment");
                                return $data_to_save;
                        }

                        if (($data['Beneficaire_15'] ?? '') !== 'DGDA')
                        {
                                $data_to_save['response'] = 405;
                                $this->finacleModel->save_log("Erreur des donnes invalides: Beneficaire must be DGDA", "prepayment");
                                return $data_to_save;
                        }

                        $instructions = $this->finacleModel->get_integrations_info_dgda_prepayment($data['Sydonia_49'], $data['Priority'] ?? 0);
                        
                        if (empty($instructions))
                        {
                                $data_to_save['response'] = 405;
                                $this->finacleModel->save_log("Erreur des donnes invalides: no instructions", "prepayment");
                                return $data_to_save;
                        }

                        $date          = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        $exchange_rate = $data['Taux_41'] ?? "";
                        $infos         = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                        $rate_code     = $infos['rate_code'] ?? "TTB";

                        foreach ($instructions as $row)
                        {
                                $compte1 = str_replace('-', '', ($row["Compte_9"] ?? ""));
                                $compte2 = str_replace('-', '', ($row["Compte_13"] ?? ""));

                                if (($row["Montant_10"] ?? 0) <= 0 || empty($compte1) || empty($compte2))
                                {
                                        $i++;
                                        continue;
                                }

                                $libelle = $this->remove_all_special_characters($row["Libelle_12"] ?? "");

                                $requestuuid = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                $xferTrnDetail = [];

                                $xferTrnDetail[] = [
                                        'AcctId'         => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg' => 'D',
                                        'TrnAmt'         => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'        => $date,
                                        'TrnParticulars' => substr($libelle, 0, 50),
                                        'PartTrnRmks'    => substr($libelle, 15, 30),
                                        'RateCode'       => $rate_code,
                                        'Rate'           => $exchange_rate,
                                        'SerialNum'      => 0
                                ];

                                $xferTrnDetail[] = [
                                        'AcctId'         => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg' => 'C',
                                        'TrnAmt'         => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'        => $date,
                                        'TrnParticulars' => substr($libelle, 0, 50),
                                        'PartTrnRmks'    => substr($libelle, 15, 30),
                                        'RateCode'       => $rate_code,
                                        'Rate'           => $exchange_rate,
                                        'SerialNum'      => 1
                                ];

                                $data_to_send = [
                                        'Header' => $requestHeader,
                                        'Body' => [
                                                'XferTrnAddRequest' => [
                                                        'XferTrnAddRq' => [
                                                                'XferTrnHdr' => $xferTrnHdr,
                                                                'XferTrnDetail' => $xferTrnDetail
                                                        ]
                                                ]
                                        ]
                                ];

                                //$response = $this->finacleModel->payment_transfer($data_to_send);
                                $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = 'TRX'.rand(1000,9999);

                                $code_to_save = null;
                                $num_evenement = "";

                                $hostStatus = $response['Header']['ResponseHeader']['HostTransaction']['Status'] ?? null;
                                if ($hostStatus === "SUCCESS" || $hostStatus === "DUP:SUCCESS")
                                {
                                        $code_to_save = 200;
                                        $status[$i] = (string)$code_to_save;
                                        $transaction_return[(string)$code_to_save][$i] = $row['Id_0'];
                                }
                                elseif ($hostStatus === null)
                                {
                                        // No return from CBS
                                        $code_to_save = '411';
                                        $status[$i] = (string)(303 + $i); // 304/305/306
                                        $transaction_return[$code_to_save][$i] = $row['Id_0'];
                                }
                                else
                                {
                                        // Business / technical error
                                        $code_to_save = '300';
                                        $status[$i] = (string)(300 + $i); // 301/302/303
                                        $transaction_return[$code_to_save][$i] = $row['Id_0'];
                                        $data_to_save['transaction_id'] = $row['Id_0'];
                                }

                                $num_evenement = $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] ?? "";
                                $data_to_save[$row['Id_0']]['Num_evenement'] = $num_evenement;
                                $data_to_save[$row['Id_0']]['code'] = $code_to_save;

                                $i++;
                        }

                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'], $data_to_save, $data['Sydonia_49']);
                        $this->finacleModel->update_cbs_instructions_prepayment($transaction_return);

                        if (in_array('301', $status, true)) $data_to_save['response'] = 301;
                        elseif (in_array('302', $status, true)) $data_to_save['response'] = 302;
                        elseif (in_array('303', $status, true)) $data_to_save['response'] = 303;
                        elseif (in_array('304', $status, true)) $data_to_save['response'] = 304;
                        elseif (in_array('305', $status, true)) $data_to_save['response'] = 305;
                        elseif (in_array('306', $status, true)) $data_to_save['response'] = 306;
                        elseif (in_array('200', $status, true)) $data_to_save['response'] = 200;
                        else $data_to_save['response'] = 411;

                        $this->finacleModel->save_log("Resultat final: " . json_encode($data_to_save), "prepayment");
                        return $data_to_save;
                }

                public function bulletin_prepayment_integration_treatment($data)
                {
                        
                        $result = [];
                        $instructions = $this->finacleModel->get_integrations_info_dgda_prepayment($data['Sydonia_49'], $data['Priority']);
                       
                        if(isset($instructions[0]['Status_2']) && in_array($instructions[0]['Status_2'], ["4","5","2"], true))
                        {
                                $lines = [];
                                $i = 1;
                               
                                foreach($instructions as $row)
                                {
                                        $lines[$i]['status'] = $row['Status_2'];
                                        $lines[$i]['id'] = $row['Id_0'];
                                        $lines[$i]['reference'] = $row['Reference_14'];
                                        $i++;
                                }
                                
                                if(isset($lines[3]['status']) && $lines[1]['status']=="1" && $lines[2]['status']=="1" && $lines[3]['status']=="1")
                                {
                                        $return = $this->debit_customer_bulletin_prepayment_integration($data);
                                        
                                        if(($return['response'] ?? '')=='200')
                                        {
                                                $result['code'] = 'E200';
                                                $result['response'] = 'E200';
                                                $result['id'] = $data['Sydonia_44'];
                                                $result['reference'] = $data['Logirefid_4'] ?? $data['Sydonia_44'];
                                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else
                                        {
                                                $result['code'] = 'E' . ($return['response'] ?? '411');
                                                $result['response'] = 'E' . ($return['response'] ?? '411');
                                                $result['reference'] = $data['Logirefid_4'] ?? $data['Sydonia_44'];
                                                $result['id'] = $data['Sydonia_44'];
                                                if (isset($return['transaction_id'])) $result['transaction_id'] = $return['transaction_id'];
                                                $result['msg'] = '<div class="alert aWarning text-white">La réservation s\'est faite partiellement, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }

                                        return json_encode($result);
                                }
                                elseif(isset($lines[1]['status']) && in_array($lines[1]['status'], ["4","5"], true))
                                {
                                        $result['code'] = 'E501';
                                        $result['response'] = 'E501';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['transaction_id'] = $lines[1]['id'];
                                        $result['reference'] = $lines[1]['reference'];
                                        $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais le core banking n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif(isset($lines[2]['status']) && in_array($lines[2]['status'], ["4","5"], true))
                                {
                                        $result['code'] = 'E502';
                                        $result['response'] = 'E502';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['transaction_id'] = $lines[2]['id'];
                                        $result['reference'] = $lines[2]['reference'];
                                        $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais le core banking n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif(isset($lines[3]['status']) && in_array($lines[3]['status'], ["4","5"], true))
                                {
                                        $result['code'] = 'E503';
                                        $result['response'] = 'E503';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['transaction_id'] = $lines[3]['id'];
                                        $result['reference'] = $lines[3]['reference'];
                                        $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais le core banking n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif(isset($lines[3]['status']) && ($lines[1]['status']=="2" && $lines[2]['status']=="2" && $lines[3]['status']=="2"))
                                {
                                        $result['code'] = 'E500';
                                        $result['response'] = 'E500';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['reference'] = $lines[3]['reference'];
                                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }

                                return json_encode($result);
                        }
                    

                        $return = $this->debit_customer_bulletin_prepayment_integration($data);
                        
                        if(($return['response'] ?? '')=='200')
                        {
                                $result['code'] = 'E200';
                                $result['response'] = 'E200';
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        else
                        {
                                $result['code'] = 'E' . ($return['response'] ?? '411');
                                $result['response'] = 'E' . ($return['response'] ?? '411');
                                if (isset($return['transaction_id'])) $result['transaction_id'] = $return['transaction_id'];
                                $result['msg'] = '<div class="alert aWarning text-white">La réservation s\'est faite partiellement, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        return json_encode($result);
                }

                public function verify_transaction_prepayment($data)
                {
                        $data_to_save = [];
                        $data_to_send = [];
                        $status = [];
                        $transaction_return = [];
                        $failled = [];
                        $i = 1;

                        if (empty($data['Beneficaire_15'])) $failled [] = "The tax authority is not defined";
                        if (empty($data["Designation_14"])) $failled [] = "The designation is not defined";
                        if (empty($data["transaction_id"])) $failled[] = 'Data transaction_id is empty';
                        if (empty($data["Logirefid_4"])) $failled[] = 'Data Logirefid_4 is empty';

                        if (!empty($failled))
                        {
                                $data_to_save['response'] = 405;
                                $this->finacleModel->save_log("Erreur des donnes invalides: ".json_encode($failled), "prepayment_verification");
                                return $data_to_save;
                        }

                        $instructions = $this->finacleModel->get_prepayment_integrations_dgda_by_id($data['transaction_id']);

                        if (empty($instructions))
                        {
                                $data_to_save['response'] = 405;
                                $this->finacleModel->save_log("Erreur des donnes invalides: no instructions", "prepayment_verification");
                                return $data_to_save;
                        }

                        $date          = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        $exchange_rate = $data['Taux_41'] ?? "";
                        $infos         = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                        $rate_code     = $infos['rate_code'] ?? "TTB";

                        $cbs_data = $this->finacleModel->get_cbs_returns_by_prepayment_batchid($data['Sydonia_44'], $data['Beneficaire_15']);
                        if (isset($cbs_data[0]['Result_6']) && $cbs_data[0]['Result_6'] != "")
                        {
                                $old = json_decode($cbs_data[0]['Result_6'], true);
                                if (is_array($old)) $data_to_save = $old;
                        }

                        $instructions_regul = $this->finacleModel->get_integrations_info_dgda_prepayment_to_regularize($data['Sydonia_44'], $data['Priority'] ?? 0);
                        if (!empty($instructions_regul))
                        {
                                $transaction_return = [];
                                $i = 1;
                                foreach ($instructions_regul as $row)
                                {
                                        $compte1 = str_replace('-', '', ($row["Compte_9"] ?? ""));
                                        $compte2 = str_replace('-', '', ($row["Compte_13"] ?? ""));

                                        if (($row["Montant_10"] ?? 0) <= 0 || empty($compte1) || empty($compte2))
                                        {
                                                $i++;
                                                continue;
                                        }

                                        $libelle = $this->remove_all_special_characters($row["Libelle_12"] ?? "");
                                        $requestuuid = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                                        $xferTrnDetail = [];

                                        $xferTrnDetail[] = [
                                                'AcctId'         => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                                'CreditDebitFlg' => 'D',
                                                'TrnAmt'         => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                'ValueDt'        => $date,
                                                'TrnParticulars' => substr($libelle, 0, 50),
                                                'PartTrnRmks'    => substr($libelle, 15, 30),
                                                'RateCode'       => $rate_code,
                                                'Rate'           => $exchange_rate,
                                                'SerialNum'      => 0
                                        ];

                                        $xferTrnDetail[] = [
                                                'AcctId'         => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                                'CreditDebitFlg' => 'C',
                                                'TrnAmt'         => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                                'ValueDt'        => $date,
                                                'TrnParticulars' => substr($libelle, 0, 50),
                                                'PartTrnRmks'    => substr($libelle, 15, 30),
                                                'RateCode'       => $rate_code,
                                                'Rate'           => $exchange_rate,
                                                'SerialNum'      => 1
                                        ];

                                        $data_to_send = [
                                                'Header' => $requestHeader,
                                                'Body' => [
                                                        'XferTrnAddRequest' => [
                                                                'XferTrnAddRq' => [
                                                                        'XferTrnHdr' => $xferTrnHdr,
                                                                        'XferTrnDetail' => $xferTrnDetail
                                                                ]
                                                        ]
                                                ]
                                        ];

                                        //$response = $this->finacleModel->payment_transfer($data_to_send);
                                        $response['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                        $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] = 'TRX'.rand(1000,9999);

                                        $hostStatus = $response['Header']['ResponseHeader']['HostTransaction']['Status'] ?? null;
                                        if ($hostStatus === "SUCCESS" || $hostStatus === "DUP:SUCCESS")
                                        {
                                                $code = 200;
                                                $transaction_return[(string)$code][$i] = $row['Id_0'];
                                                $status[$i] = (string)$code;
                                        }
                                        elseif ($hostStatus === null)
                                        {
                                                $code = 411;
                                                $transaction_return[(string)$code][$i] = $row['Id_0'];
                                                $status[$i] = (string)$code;
                                        }
                                        else
                                        {
                                                $code = 300;
                                                $transaction_return[(string)$code][$i] = $row['Id_0'];
                                                $status[$i] = (string)$code;
                                        }

                                        $num_evenement = $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] ?? "";
                                        $data_to_save[$row['Id_0']]['Num_evenement'] = $num_evenement;
                                        $data_to_save[$row['Id_0']]['code'] = $code;

                                        $i++;
                                }

                                $this->finacleModel->update_prepayment_cbs_return($data_to_save, $data['Sydonia_44']);
                                $this->finacleModel->update_cbs_instructions_prepayment($transaction_return);

                                if(in_array('404', $status, true)) $data_to_save['response'] = 404;
                                elseif(in_array('411', $status, true)) $data_to_save['response'] = 411;
                                elseif(in_array('300', $status, true)) $data_to_save['response'] = 300;
                                else $data_to_save['response'] = 200;

                                $this->finacleModel->save_log("Resultat final: ".json_encode($data_to_save), "prepayment_verification");
                                return $data_to_save;
                        }

                        $data_to_save['response'] = 405;
                        $this->finacleModel->save_log("Erreur des donnes invalides: no regularization instructions", "prepayment_verification");
                        return $data_to_save;
                }

                public function bulletin_prepayment_verification_treatment($data)
                {
                        $result = [];
                        $return = $this->verify_transaction_prepayment($data);

                        if(($return['response'] ?? '')=='200')
                        {
                                $result['code'] = 'E200';
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! la reservation a été faite avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($return['response']) && in_array((string)$return['response'], ['300','404','405','411'], true))
                        {
                                if(($data['Error_code'] ?? '') == 'E501' || ($data['Error_code'] ?? '') == 'E301')
                                {
                                        $result['code'] = $data['Error_code'];
                                        $result['msg'] = '<div class="alert aWarning text-white">La reservation n\'a pas été faite. Il se pose un problème avec le compte du client, veuillez vérifier le problème dans le core banking.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $result['code'] = $data['Error_code'] ?? ('E' . $return['response']);
                                        $result['msg'] = '<div class="alert aWarning text-white">La réservation a été intégrée partiellement, veuillez refaire l\'opération s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }

                        return json_encode($result);
                }
	                
        }

	        /* End of file welcome.php */
	        /* Location: ./application/controllers/welcome.php */
