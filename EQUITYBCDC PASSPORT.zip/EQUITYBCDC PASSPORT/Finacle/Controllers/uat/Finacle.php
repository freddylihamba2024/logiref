<?php
        namespace Modules\Services\Finacle\Controllers;

        use App\Controllers\BaseController;
        use Modules\Services\Finacle\Models\FinacleModel;

        class Finacle extends BaseController {

                public $finacleModel;

                public function __construct()
                {
                parent::__construct();

                        $this->finacleModel = new FinacleModel();
                }

                public function account_info($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $data_to_send = array();
                        $failled = array();
                        $return = array();
                        $customerid = '';
                        $account_number = '';
                        $account_details = '';

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';

                        else
                        $result = str_replace('-', '', $data['Compte_33']);
                        $account = $result ;

                        if(count($failled) == 0)
                        {
                                /*
                                * --------------------------------------------
                                * Construction of data to send
                                * --------------------------------------------
                                */

                                ###### the request reference ###################
                                $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=> $requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'XferTrnAdd',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'RDC',
                                                        'LanguageId'=>'',
                                                );
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'GMT+05:00',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'CustAcctInquiry'
                                                                );

                                $custAcctInquiry_REQ = array(
                                                                'BankID'=>'43',
                                                                'AccountID'=>$account
                                                        );

                                $executeFinacleScript_CustomData['CustAcctInquiry_REQ'] = $custAcctInquiry_REQ;

                                $executeFinacleScriptReques['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;

                                $executeFinacleScriptReques['executeFinacleScript_CustomData']= $executeFinacleScript_CustomData;

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptReques;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;

                                $response = $this->finacleModel->account_info($data_to_send);

                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        $account = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['AccountName']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['AccountName'] : "";
                                        $devise = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['Currency'] : "";
                                        $balance = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['CustAcctInquiry_RES']['AcctDtls']['ClearBalance'] : "";

                                        $data_to_return['code']="200";
                                        $data_to_return['account_name'] = $account;
                                        $data_to_return['currency'] = $devise;
                                        $data_to_return['balance'] = $balance;

                                        $return = $data_to_return;
                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "account_info");

                                return $return;
                        }
                }

                public function account_internal_info($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $data_to_send = array();
                        $failled = array();
                        $return = array();
                        $customerid = '';
                        $account_number = '';
                        $account_details = '';

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';

                        else
                        $result = str_replace('-', '', $data['Compte_33']);
                        $account = $result ;

                        if(count($failled) == 0)
                        {

                                ###### the request reference ###################
                                $requestuuid = rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=> $requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'XferTrnAdd',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'RDC',
                                                        'LanguageId'=>'',
                                                );

                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'GMT+05:00',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );

                                $security = array(
                                                        'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                        'FICertToken'=>'',
                                                        'RealUserLoginSessionId'=>'',
                                                        'RealUser'=>'',
                                                        'RealUserPwd'=>'',
                                                        'SSOTransferToken'=>''
                                                )
                                        );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'checkacctDetails.scr'
                                                                );

                                $executeFinacleScript_CustomData = array(

                                                                'AccountID'=>$account
                                                        );

                                $executeFinacleScriptReques['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;

                                $executeFinacleScriptReques['executeFinacleScript_CustomData']= $executeFinacleScript_CustomData;

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptReques;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;

                                $response = $this->finacleModel->account_info($data_to_send);

                                if($response['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        $account = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['AcctName']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['AcctName']: "";
                                        $devise = isset($response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['Currency']) ? $response['Body'] ["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['Currency'] : "";

                                        $data_to_return['code']="200";
                                        $data_to_return['account_name'] = $account;
                                        $data_to_return['currency'] = $devise;
                                        $data_to_return['balance'] = "";

                                        $return = $data_to_return;

                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "account_info");

                                return $return;
                        }

                }

                public function tax_exempt($data)
                {

                        if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';

                        else
                        $result = str_replace('-', '', $data['Compte_33']);
                        $account = $result ;

                        if(count($failled) == 0)
                        {
                                $requestuuid =  rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=>$requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'RDC',
                                                        'LanguageId'=>'',
                                                );
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                        'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                        'FICertToken'=>'',
                                                        'RealUserLoginSessionId'=>'',
                                                        'RealUser'=>'',
                                                        'RealUserPwd'=>'',
                                                        'SSOTransferToken'=>''
                                                )
                                        );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'eTaxExempt.scr'
                                                                );
                                $executeFinacleScript_CustomData = array(
                                                                'AccountID'=>$account
                                                        );

                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;

                                $executeFinacleScriptRequest['executeFinacleScript_CustomData'] = $executeFinacleScript_CustomData;

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptRequest;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                $response = $this->finacleModel->tax_exempt($data_to_send);

                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] =="SUCCESS")
                                {
                                                if(isset($response['Body']["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['TaxFlg']) && $response['Body']["executeFinacleScriptResponse"]['executeFinacleScript_CustomData']['TaxFlg'] == 'Y')
                                                {
                                                                $return['code'] = 300;
                                                }
                                                else
                                                {
                                                                $return['code'] = 300;
                                                }
                                }
                                else
                                {
                                                $return['code'] = 404;
                                }

                                return $return;
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "tax_exempt");

                                return $return;
                        }
                }

                public function virement($data)
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $return = array();
                        $data_to_save = array();
                        $data_to_send = array();
                        $data_to_update = array();
                        $request_to_save = array();
                        $instructions = array();
                        $infos = array();
                        $status = array();
                        $transaction_return = array();
                        $failled = array();
                        $code = '';
                        $return_update = "";
                        $i =1;
                        $j = 0;

                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */

                        if (empty($data['Beneficaire_15'])) $failled[] = "The tax authority is not defined";
                        if (empty($data['Taux_41'])) $failled[] = "The exchange rate is not defined";

                        if (!empty($failled))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Erreur des donnes invalides: " . json_encode($failled), "account");

                                return json_encode($data_to_return);
                        }

                        $type = $data['Type'] ?? '';

                        if ($data['Beneficaire_15'] === 'DGDA')
                        {
                                if ($type === 'prepayment')
                                {
                                        $this->finacleModel->update_payment_prepayment($data['Sydonia_49']);
                                }
                                elseif ($type !== 'first_transaction')
                                {
                                        $this->finacleModel->update_payment_sydonia($data['Sydonia_44']);
                                }
                        }

                        $return = match($data['Beneficaire_15'])
                        {
                                'DGDA' => ($type === 'prepayment')
                                        ? $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_49'], $data['Priority'])
                                        : $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']),
                                'DGI'  => $this->finacleModel->get_integrations_info_dgi($data['Logirefid_4']),
                                'DGRAD'=> $this->finacleModel->get_integrations_info_dgrad($data['Logirefid_4']),

                                default => []
                        };

                        if (empty($return))
                        {
                                $data_to_return = [
                                        'code' => 405,
                                        'response' => 405,
                                        'message' => "Missing data in the request",
                                        'msg' => '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];

                                $this->finacleModel->save_log("Missing integration data");
                                return json_encode($data_to_return);
                        }

                        $date           = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        $requestuuid    = mt_rand(1, 99).date('Hisjmy').mt_rand(100, 999);
                        $exchange_rate  = $data['Taux_41'] ?? "";
                        $infos          = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : [];
                        $rate_code      = $infos['rate_code'] ?? "TTB";

                        $requestHeader = $this->prepareRequestHeader($requestuuid, $date);

                        $xferTrnHdr = ['TrnType' => 'T', 'TrnSubType' => 'CI'];
                        $xferTrnDetail = [];

                        $i = 0;
                        foreach ($return as $row)
                        {
                                $compte1 = str_replace('-', '', $row["Compte_9"]);
                                $compte2 = str_replace('-', '', $row["Compte_13"]);

                                if ($row["Montant_10"] <= 0 || empty($compte1)) continue;

                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                $xferTrnDetail[] = [
                                        'AcctId'                => ['AcctId' => $compte1, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg'        => 'D',
                                        'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'               => $date,
                                        'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                        'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                        'RateCode'              => $rate_code,
                                        'Rate'                  => $exchange_rate,
                                        'SerialNum'             => $i
                                ];

                                $xferTrnDetail[] = [
                                        'AcctId'                => ['AcctId' => $compte2, 'AcctCurr' => $row["Devise_11"]],
                                        'CreditDebitFlg'        => 'C',
                                        'TrnAmt'                => ['amountValue' => $row["Montant_10"], 'currencyCode' => $row["Devise_11"]],
                                        'ValueDt'               => $date,
                                        'TrnParticulars'        => substr($row['Libelle_12'], 0, 50),
                                        'PartTrnRmks'           => substr($row['Libelle_12'], 15, 30),
                                        'RateCode'              => $rate_code,
                                        'Rate'                  => $exchange_rate,
                                        'SerialNum'             => $i+1
                                ];

                                $i++;
                        }

                        $xferTrnAddRq['XferTrnHdr'] = $xferTrnHdr;
                        $xferTrnAddRq['XferTrnDetail'] = $xferTrnDetail;
                        $xferTrnAddRequest['XferTrnAddRq'] = $xferTrnAddRq;

                        $data_to_send['Header'] = $requestHeader;
                        $data_to_send['Body']['XferTrnAddRequest'] = $xferTrnAddRequest;

                        $response = $this->finacleModel->payment_transfer($data_to_send);

                        $result = $this->handleCBSResponse($response, $data, $return, $type);
                        $data_to_return = $result['data_to_return'];
                        $data_to_save   = $result['data_to_save'];

                        if ($data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['Type']) && $data['Type'] == "prepayment")
                                {
                                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'], $data_to_save, $data['Sydonia_49']);
                                }
                                elseif(isset($data['Type']) && $data['Type'] == "others")
                                {
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                }
                                else
                                {
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                }
                        }
                        else
                        {
                                $this->finacleModel->save_cbs_return($data['Account_3'], $data_to_save, $data['Id_0']);
                        }

                        return json_encode($data_to_return);

                }

                private function prepareRequestHeader($requestuuid, $date)
                {
                        return [
                                'RequestHeader' => [
                                        'MessageKey' => [
                                                'RequestUUID' => $requestuuid,
                                                'ServiceRequestId' => 'XferTrnAdd',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'RDC',
                                                'LanguageId' => '',
                                        ],
                                        'RequestMessageInfo' => [
                                                'BankId' => '43',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                        ],
                                        'Security' => [
                                                'Token' => [
                                                        'PasswordToken' => [
                                                                'UserId' => '',
                                                                'Password' => ''
                                                        ],
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                ]
                                        ]
                                ]
                        ];
                }

                private function handleCBSResponse($response, $data, $return, $type)
                {
                        $data_to_save = [];
                        $data_to_return = [];

                        $status = $response['Header']['ResponseHeader']['HostTransaction']['Status'] ?? '';

                        if ($status === "SUCCESS" || $status === "DUP:SUCCESS") {
                                $code = 200;
                                foreach ($return as $row) {
                                        $data_to_save[$row['Id_0']] = [
                                                'Num_evenement' => $response['Body']['XferTrnAddResponse']['XferTrnAddRs']['TrnIdentifier']['TrnId'] ?? "",
                                                'code' => $code,
                                                'ids' => $row['Id_0']
                                        ];

                                        if($data['Beneficaire_15'] == 'DGI')
                                        {
                                                $this->finacleModel->update_cbs_instructions_dgi($data['Logirefid_4']);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGRAD')
                                        {
                                                $this->finacleModel->update_cbs_instructions_dgrad($data['Logirefid_4']);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGDA' && $type != "prepayment")
                                        {
                                                $this->finacleModel->update_cbs_instructions_dgda($data['Sydonia_44']);
                                        }
                                        elseif($data['Beneficaire_15'] == 'DGDA' && $type == "prepayment")
                                        {
                                                $this->finacleModel->update_cbs_prepayments_instructions_dgda($data['Sydonia_49']);
                                        }
                                }
                                $data_to_return = [
                                        'response' => $code,
                                        'code' => $code,
                                        'message' => '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>',
                                        'msg' => '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                                ];
                        }
                        else {
                                $error_code = $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"][0]["ErrorCode"] ?? 'E411';
                                $msg = '<div class="alert aDanger text-white">Une erreur est survenue: ' . $error_code . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $data_to_return = [
                                        'code' => $error_code,
                                        'response' => $error_code,
                                        'message' => $msg,
                                        'msg' => $msg
                                ];
                                $this->finacleModel->save_log("Erreur CBS: " . json_encode($response));
                        }

                        return [
                                'data_to_return' => $data_to_return,
                                'data_to_save'   => $data_to_save
                        ];
                }

                public function reservation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Initialization
                        * ------------------------------------------------
                        */
                        $data_to_send = array();
                        $response = array();
                        $account_number = '';
                        $currency = '';
                        $amount = '';
                        $failled = array();

                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        /*
                        * --------------------------------------------
                        * Test all required data
                        * --------------------------------------------
                        */
                
                        if(!isset($data['compte'])) $failled[] = 'The account is not defined';
                        else  $account_number = $data['compte'];
                        
                        if(!isset($data['montant'])) $failled[] = 'The amount is not defined';
                        else  $amount = $data['montant'];
                        
                        if(!isset($data['devise'])) $failled[] = 'The currency is not defined';
                        else  $currency = $data['devise'];
                        
                        if(count($failled) == 0)
                        {
                                $account=str_replace("-","",$account_number);
                                /*
                                * ------------------------------------------------
                                * Construction of data to send to the CBS
                                * ------------------------------------------------
                                */
                        
                                $requestuuid =  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                $messageKey = array(
                                'RequestUUID'=>$requestuuid,
                                'ServiceRequestId'=>'AcctLienAdd',
                                'ServiceRequestVersion'=>'10.2',
                                'ChannelId'=>'RDC',
                                'LanguageId'=>'',
                                );
                                
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;



                                $AcctLienAddRq = array(
                                                'AcctId'=>array(
                                                        'AcctId'=>$account
                                                ),
                                                'ModuleType'=>'ULIEN',
                                                'LienDtls'=> array(
                                                        'LienId'=>'ULIEN001',
                                                        'NewLienAmt'=>array(
                                                        'amountValue'=>$amount,
                                                        'currencyCode'=>$currency
                                                        ),
                                                        'LienDt'=>array(
                                                        'StartDt'=>$date,
                                                        'EndDt'=>$date
                                                        ),
                                                        'ReasonCode'=>'OTH',
                                                        'Rmks'=>'Lien Remarks'
                                                )
                                        );

                                $AcctLienAddRequest['AcctLienAddRq'] = $AcctLienAddRq;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['AcctLienAddRequest'] = $AcctLienAddRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                $response = $this->finacleModel->add_lien_account($data_to_send);
                                
                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS")
                                {
                                        $code = 200;
                                        $lien = isset($response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"]) ? $response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"] : "";
                                        $date = isset($response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime']) ? $response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime'] : "";

                                        $data_to_save['code']=$code;
                                        $data_to_save['response'] = $code;
                                        $data_to_save['lien'] = $lien;
                                        $data_to_save['date'] = $date;
                                }
                                else
                                {
                                        $info = json_encode($response);
                                        $this->finacleModel->save_log("Erreur : ".$info);

                                        if(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='008')
                                        {
                                                //Record already exists
                                                $data_to_save['code'] = 'E008';
                                                $data_to_save['response'] = 'E008';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='E6580')
                                        {
                                                //wrong date of reservation
                                                $data_to_save['code'] = 'E6580';
                                                $data_to_save['response'] = 'E6580';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='162')
                                        {
                                                //The account does not exist.
                                                $data_to_save['code'] = 'E162';
                                                $data_to_save['response'] = 'E162';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='E4348')
                                        {
                                                //The lien can be placed only on accounts of SBA, CAA, CCA, ODA, BIA, FBA OR TDA.
                                                $data_to_save['code'] = 'E4348';
                                                $data_to_save['response'] = 'E4348';
                                        }
                                        else
                                        {
                                                return '411'; 
                                        }

                                }

                                $result_to_save = json_encode($data_to_save);
                                $this->finacleModel->save_log("Resultat final :".$result_to_save);
                                
                                return json_encode($data_to_save);
                        }
                        else
                        {
                                $return['code'] = 405;
                                $return['response'] = 405;
                                $return['message'] = "Missing data in the request";
                                $result_to_save = json_encode($failled);
                                
                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "reservation");

                                return json_encode($return);
                        }
                }
                
                public function cancel_reservation($data)
                {
                        /*
                        * ------------------------------------------------
                        * Initialization
                        * ------------------------------------------------
                        */
                        $data_to_send = array();
                        $response = array();
                        $account_number = '';
                        $currency = '';
                        $amount = '';
                        $failled = array();
                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        /*
                        * --------------------------------------------
                        * Test all required data 
                        * --------------------------------------------
                        */
                        
                        if(!isset($data['lien_id'])) $failled[] = 'The account is not defined';
                        else  $account_number = $data['compte'];
                        
                        if(!isset($data['date_lien'])) $failled[] = 'The date of the lien is not defined';
                        else  $amount = $data['date_lien'];
                        
                        if(!isset($data['devise'])) $failled[] = 'The currency is not defined';
                        else  $currency = $data['devise'];
                        
                        
                        if(count($failled) == 0)
                        {
                                /*
                                * ------------------------------------------------
                                * Construction of data to send to the CBS
                                * ------------------------------------------------
                                */

                                $account=str_replace("-","",$account_number);
                        
                                $requestuuid =  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                $messageKey = array(
                                'RequestUUID'=>$requestuuid,
                                'ServiceRequestId'=>'AcctLienAdd',
                                'ServiceRequestVersion'=>'10.2',
                                'ChannelId'=>'RDC',
                                'LanguageId'=>'',
                                );
                                
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;

                                
                                $AcctLienAddRq = array(
                                                'AcctId'=>array(
                                                        'AcctId'=>$account
                                                ),
                                                'ModuleType'=>'ULIEN',
                                                'LienDtls'=> array(
                                                        'LienId'=>'ULIEN001',
                                                        'NewLienAmt'=>array(
                                                        'amountValue'=>$amount,
                                                        'currencyCode'=>$currency
                                                        ),
                                                        'LienDt'=>array(
                                                        'StartDt'=>$date,
                                                        'EndDt'=>$date
                                                        ),
                                                        'ReasonCode'=>'OTH',
                                                        'Rmks'=>'Lien Remarks'
                                                )
                                        );

                                $AcctLienAddRequest['AcctLienAddRq'] = $AcctLienAddRq;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['AcctLienAddRequest'] = $AcctLienAddRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save);

                                $response = $this->finacleModel->add_lien_account($data_to_send);
                                
                                if(isset($response['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS")
                                {
                                        $code = 200;
                                        $lien = isset($response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"]) ? $response["Body"]["AcctLienAddResponse"]["AcctLienAddRs"]["LienIdRec"]["LienId"] : "";
                                        $date = isset($response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime']) ? $response['Header']['ResponseHeader']['ResponseMessageInfo']['MessageDateTime'] : "";

                                        $data_to_save['code'] = $code;
                                        $data_to_save['response'] = $code;
                                        $data_to_save['lien'] = $lien;
                                        $data_to_save['date'] = $date;
                                }
                                else
                                {
                                        $info = json_encode($response);
                                        $this->finacleModel->save_log("Erreur : ".$info);

                                        if(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='008')
                                        {
                                                //Record already exists
                                                $data_to_save['code'] = 'E008';
                                                $data_to_save['response'] = 'E008';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"] =='E6580')
                                        {
                                                //wrong date of reservation
                                                $data_to_save['code'] = 'E6580';
                                                $data_to_save['response'] = 'E6580';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='162')
                                        {
                                                //The account does not exist.
                                                $data_to_save['code'] = 'E162';
                                                $data_to_save['response'] = 'E162';
                                        }
                                        elseif(isset($response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]) && $response["Body"]["Error"]["FIBusinessException"]["ErrorDetail"]["ErrorCode"]=='E4348')
                                        {
                                                //The lien can be placed only on accounts of SBA, CAA, CCA, ODA, BIA, FBA OR TDA.
                                                $data_to_save['code'] = 'E4348';
                                                $data_to_save['response'] = 'E4348';
                                        }
                                        else
                                        {
                                                return '411'; 
                                        }

                                }

                                $result_to_save = json_encode($data_to_save);
                                $this->finacleModel->save_log("Resultat final :".$result_to_save);
                                
                                return json_encode($data_to_save);
                        }
                        else
                        {
                                $return['code'] = 405;
                                $return['response'] = 405;
                                $return['message'] = "Missing data in the request";
                                $result_to_save = json_encode($failled);
                                
                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "reservation");

                                return json_encode($return);
                        }
                }
                public function get_exchange_rate($data)
                {
                        /*
                        * ------------------------------------------------
                        * Initialization
                        * ------------------------------------------------
                        */
                        $data_to_send = array();
                        $data_to_return = array(); 
                        $response = array();
                        $language = '';
                        $failled = array();
                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                        /*
                        * --------------------------------------------
                        * Test all required data 
                        * --------------------------------------------
                        */
                        
                        if(!isset($data['from_currency'])) $failled[] = 'The value from_currency is not defined';
                        else  $from_currency = $data['from_currency'];
                        
                        if(!isset($data['to_currency'])) $failled[] = 'The value to_currency is not defined';
                        else  $to_currency = $data['to_currency'];

                        if(!isset($data['type'])) $failled[] = 'The value type is not defined';
                        else  $type = $data['type'];
                        
                        if(count($failled) == 0)
                        {
                                /*
                                * ------------------------------------------------
                                * Construction of data to send to the CBS
                                * ------------------------------------------------
                                */
                                $requestuuid =  rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $prefix_logs = isset($_POST['note_number']) ? $_POST['note_number'] : "";

                                $messageKey = array(
                                                        'RequestUUID'=>$requestuuid,
                                                        'ServiceRequestId'=>'getExchangeRateForRateCode',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'OMN',
                                                        'LanguageId'=>'',
                                                );
                                $requestMessageInfo = array(
                                                        'BankId'=>'43',
                                                        'TimeZone'=>'',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                );
                                $security = array(
                                                'Token'=>array(
                                                        'PasswordToken'=>array(
                                                                'UserId'=>'54301217289',
                                                                'Password'=>''
                                                        ),
                                                'FICertToken'=>'',
                                                'RealUserLoginSessionId'=>'',
                                                'RealUser'=>'',
                                                'RealUserPwd'=>'',
                                                'SSOTransferToken'=>''
                                                )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;

                                $exchangeRateForRateCodeInputVO = array(
                                                'fromCrncyCode'=>$from_currency,
                                                'rateCode'=>$type,
                                                'toCrncyCode'=>$to_currency
                                        );

                                $getExchangeRateForRateCodeRequest['ExchangeRateForRateCodeInputVO'] = $exchangeRateForRateCodeInputVO;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body']['getExchangeRateForRateCodeRequest'] = $getExchangeRateForRateCodeRequest;

                                $result_to_save = json_encode($data_to_send);

                                $this->finacleModel->save_log("Resultat final :".$result_to_save, $prefix_logs);

                                $response = $this->finacleModel->exchange_rate($data_to_send);

                                if($response['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                                $taux = isset($response['Body']["getExchangeRateForRateCodeResponse"]['ExchangeRateForRateCodeOutputVO']['varCrncyUnits']) ? $response['Body']["getExchangeRateForRateCodeResponse"]['ExchangeRateForRateCodeOutputVO']['varCrncyUnits'] : "";
                                                $return['exchange_rate'] = $taux;
                                                $return['code'] = 200;

                                                return json_encode($return);
                                }
                                else
                                {
                                                $return['code'] = 200;
                                                return json_encode($return);
                                }
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "exchange_rate");

                                return json_encode($return);
                        }
                }

                public function extract_customerid_from_account ($account)
                {
                        // Vérifier si le compte a au moins 16 caractères
                        if (strlen($account) >= 16) {
                        // Éliminer les 6 premiers caractères
                        $account = substr($account, 6);

                        // Extraire les 6 customerid
                        $customerid = substr($account, 0, 6);

                        return $customerid;
                        } else {
                        // Gérer le cas où la chaîne n'a pas la longueur requise
                        return false;
                        }
                }

                public function remove_all_special_characters($texte)
                {
                        // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                        $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                        // Remplacer les espaces par des traits d'union
                        $texte = str_replace('/', '-', $texte);
                        $texte = str_replace(' ', '-', $texte);

                        // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                        //$texte = preg_replace('/[^a-zA-Z0-9]/', '', $texte); // Supprimer les espaces aussi
                        $texte = preg_replace('/[^a-zA-Z0-9\-]/', '', $texte);

                        return $texte;
                }

                public function get_the_total_amount($instructions)
                {
                        $total_amount = 0;
                        
                        foreach ($instructions as $row)
                        {
                                $total_amount = $total_amount + $row["Montant_10"];
                        }
                        
                        return $total_amount;
                }
                
                public function validate_payment($data) 
                {   
                        return $this->virement($data);
                }
                
        }

        /* End of file welcome.php */
        /* Location: ./application/controllers/welcome.php */