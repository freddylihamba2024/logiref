<?php

namespace Modules\Services\Finacle\Standardbank\Models;

use App\Models\MY_Transaction;
use CodeIgniter\Model;
use Exception;

class FinacleStandardBankModel extends MY_Transaction
{
    
        function __construct()
        {
                parent::__construct();
	    }
        
        public function payment_transfer($data,$requestuuid,$date)
        {
                #### url du web service
                $url = 'https://uafrhttps.za.sbicdirectory.com:443/africa/services/cd/paymentscollections';


                // Construction du FIXML XML
                $fixmlXml = $this->buildFixmlXml($data);
                
                $fixmlXml = str_replace('<?xml version="1.0"?>', '', $fixmlXml);
                
                // Construction du SOAP Envelope
                $soapEnvelope = <<<XML
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:head="http://standardbank.com/africa/services/HeaderV1_0"
                xmlns:web="http://webservice.fiusb.ci.infosys.com">
                    <soapenv:Header>
                        <head:sourceSystem>MOM</head:sourceSystem>
                        <head:messageType>PAYEX:CI:PAYMENTSCOLLECTIONS</head:messageType>
                        <head:messageId>{$requestuuid}</head:messageId>
                        <head:timeStamp>{$date}</head:timeStamp>
                        <head:trackingId>{$requestuuid}</head:trackingId>
                        <head:dynamicVariable1>{$requestuuid}</head:dynamicVariable1>
                        <head:dynamicVariable2>{$requestuuid}</head:dynamicVariable2>
                        <head:dynamicVariable3>?</head:dynamicVariable3>
                        <head:dynamicVariable4>{$date}</head:dynamicVariable4>
                        <head:correlationId/>
                        <head:countryISO>CD</head:countryISO>
                        <head:version>0.1</head:version>
                    </soapenv:Header>
                    <soapenv:Body>
                        <web:executeService>
                            <arg_0_0><![CDATA[
                {$fixmlXml}
                            ]]></arg_0_0>
                        </web:executeService>
                    </soapenv:Body>
                </soapenv:Envelope>
                XML;  
                
                // Envoi via cURL
                $curl = curl_init();
                curl_setopt_array($curl, [
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $soapEnvelope,
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/xml',
                        'Content-Length: ' . strlen($soapEnvelope)
                    ],
                ]);
                
                try
                {
                        $response = curl_exec($curl);
                        

                        $this->save_log($fixmlXml, "virement");
                        $this->save_log($response, "virement");
                        
                        $conversionResult = $this->convertSoapXmlToArray($response);
                        

                        if(isset($conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn']))
                        {
                                $fixml = $conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn'];

                                $response_array = $this->convertSoapXmlToArray($fixml);
                            
                                return $response_array;
                        }
                        else
                        {
                                return '404';
                        }
                        
                        curl_close($curl);
                }
                catch(Exception $ex)
                {
                        return '406';
                }
        }
        
        public function add_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "reservation");
                        $this->save_log($return, "reservation");
                        $this->save_log($result, "reservation");
                        $this->save_log($result, "reservation");

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function inquiry_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml);
                        $this->save_log($return);
                        $this->save_log($result);
                        $this->save_log($result);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function release_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);
						
			//echo $return; die;

                        $response = json_decode($result, true);
                        $this->save_log($xml,  "cancel_reservation");
                        $this->save_log($return, "cancel_reservation");
                        $this->save_log($result, "cancel_reservation");
                        $this->save_log($result, "cancel_reservation");

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function exchange_rate($data, $prefix_logs = NULL)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "exchange_rate_".$prefix_logs);
                        $this->save_log($return, "exchange_rate_".$prefix_logs);
                        $this->save_log($result, "exchange_rate_".$prefix_logs);
                        $this->save_log($result, "exchange_rate_".$prefix_logs);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function tax_exempt($data)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
                        //echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml);
                        $this->save_log($return);
                        $this->save_log($result);
                        $this->save_log($result);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        public function account_info($data, $requestuuid, $date)
        {
                //header('Content-type:application/xml; charset=utf-8');
                // Construction du FIXML XML
                $fixmlXml = $this->buildFixmlXml($data);

                $fixmlXml = str_replace('<?xml version="1.0"?>', '', $fixmlXml);
                
                // Construction du SOAP Envelope
                $soapEnvelope = <<<XML
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:head="http://standardbank.com/africa/services/HeaderV1_0"
                xmlns:web="http://webservice.fiusb.ci.infosys.com">
                    <soapenv:Header>
                        <head:sourceSystem>MOM</head:sourceSystem>
                        <head:messageType>PAYEX:CI:PAYMENTSCOLLECTIONS</head:messageType>
                        <head:messageId>{$requestuuid}</head:messageId>
                        <head:timeStamp>{$date}</head:timeStamp>
                        <head:trackingId>{$requestuuid}</head:trackingId>
                        <head:dynamicVariable1>{$requestuuid}</head:dynamicVariable1>
                        <head:dynamicVariable2>{$requestuuid}</head:dynamicVariable2>
                        <head:dynamicVariable3>?</head:dynamicVariable3>
                        <head:dynamicVariable4>{$date}</head:dynamicVariable4>
                        <head:correlationId/>
                        <head:countryISO>CD</head:countryISO>
                        <head:version>0.1</head:version>
                    </soapenv:Header>
                    <soapenv:Body>
                        <web:executeService>
                            <arg_0_0><![CDATA[
                {$fixmlXml}
                            ]]></arg_0_0>
                        </web:executeService>
                    </soapenv:Body>
                </soapenv:Envelope>
                XML;  
                
                // Envoi via cURL
                $curl = curl_init();
                curl_setopt_array($curl, [
                    CURLOPT_URL => 'https://uafrhttps.za.sbicdirectory.com:443/africa/services/cd/ps_finacle_accountstatementv1',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $soapEnvelope,
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/xml',
                        'Content-Length: ' . strlen($soapEnvelope)
                    ],
                ]);
                
                try
                {
                        $response = curl_exec($curl);
                       

                        $this->save_log($fixmlXml, "account_info");
                        $this->save_log($response, "account_info");
                        
                        $conversionResult = $this->convertSoapXmlToArray($response);

                        if(isset($conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn']))
                        {
                                $fixml = $conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn'];

                                $response_array = $this->convertSoapXmlToArray($fixml);

                                return $response_array;
                        }
                        else
                        {
                                return '404';
                        }
                        
                        curl_close($curl);
                }
                catch(Exception $ex)
                {
                        return '406';
                }
                
        }
        public function account_info_archive($data)
        {
                #### url du web service
                $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();

                //echo $xml; die;

                // Étape 2 : Créer le SOAP XML complet avec le FIXML dans arg_0_0
                $soap_request = <<<XML
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                                xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                                xmlns:head="http://standardbank.com/africa/services/HeaderV1_0"
                                xmlns:web="http://webservice.fiusb.ci.infosys.com">
                <soapenv:Header>
                    <head:sourceSystem>MOM</head:sourceSystem>
                    <head:messageType>PAYEX:CI:PAYMENTSCOLLECTIONS</head:messageType>
                    <head:messageId>11008863043881</head:messageId>
                    <head:timeStamp>2025-03-04T16:08:06.304</head:timeStamp>
                    <head:trackingId>11008863043881</head:trackingId>
                    <head:dynamicVariable1>11008863043881</head:dynamicVariable1>
                    <head:dynamicVariable2>11008863043881</head:dynamicVariable2>
                    <head:dynamicVariable3>?</head:dynamicVariable3>
                    <head:dynamicVariable4>2025-03-04T16:08:06.304</head:dynamicVariable4>
                    <head:correlationId/>
                    <head:countryISO>CD</head:countryISO>
                    <head:version>0.1</head:version>
                </soapenv:Header>
                <soapenv:Body>
                    <web:executeService>
                    <arg_0_0>
                        <![CDATA[{$xml}]]>
                    </arg_0_0>
                    </web:executeService>
                </soapenv:Body>
                </soapenv:Envelope>
                XML;

                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $soap_request
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
		
			//echo $return; die;
			
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "account_info");
                        $this->save_log($return, "account_info");
                        $this->save_log($result, "account_info");
						
                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function bank_charge($data,$requestuuid,$date)
        {
                 #### url du web service
                $url = 'https://uafrhttps.za.sbicdirectory.com:443/africa/services/ps_finacle_collectchargev1';


                // Construction du FIXML XML
                $fixmlXml = $this->buildFixmlXml($data,true);

                
                
                $fixmlXml = str_replace('<?xml version="1.0"?>', '', $fixmlXml);
                
                // Construction du SOAP Envelope
                $soapEnvelope = <<<XML
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                xmlns:head="http://standardbank.com/africa/services/HeaderV1_0"
                xmlns:web="http://webservice.fiusb.ci.infosys.com">
                    <soapenv:Header>
                        <head:sourceSystem>MOM</head:sourceSystem>
                        <head:messageType>PAYEX:CI:COLLECTCHARGE</head:messageType>
                        <head:messageId>{$requestuuid}</head:messageId>
                        <head:timeStamp>{$date}</head:timeStamp>
                        <head:trackingId>{$requestuuid}</head:trackingId>
                        <head:dynamicVariable1>{$requestuuid}</head:dynamicVariable1>
                        <head:dynamicVariable2>{$requestuuid}</head:dynamicVariable2>
                        <head:dynamicVariable3>?</head:dynamicVariable3>
                        <head:dynamicVariable4>{$date}</head:dynamicVariable4>
                        <head:correlationId/>
                        <head:countryISO>CD</head:countryISO>
                        <head:version>0.1</head:version>
                    </soapenv:Header>
                    <soapenv:Body>
                        <web:executeService>
                            <arg_0_0><![CDATA[
                {$fixmlXml}
                            ]]></arg_0_0>
                        </web:executeService>
                    </soapenv:Body>
                </soapenv:Envelope>
                XML;  
                
                // Envoi via cURL
                $curl = curl_init();
                curl_setopt_array($curl, [
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $soapEnvelope,
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/xml',
                        'Content-Length: ' . strlen($soapEnvelope)
                    ],
                ]);
                
                try
                {
                        $response = curl_exec($curl);
                        
                        

                        $this->save_log($fixmlXml, "bank_charge");
                        $this->save_log($response, "bank_charge");
                        
                        $conversionResult = $this->convertSoapXmlToArray($response);
                        

                        if(isset($conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn']))
                        {
                                $fixml = $conversionResult['data']['soapenv:Body']['p594:executeServiceResponse']['executeServiceReturn'];

                                $response_array = $this->convertSoapXmlToArray($fixml);
                            

                                return $response_array;
                        }
                        else
                        {
                                return '404';
                        }
                        
                        curl_close($curl);
                }
                catch(Exception $ex)
                {
                        return '406';
                }
        }

        public function buildFixmlXml($data,$no_trancriteria=false)
        {
                $requestHeader = $data['Header']['RequestHeader'];
                $body = $data['Body']['executeFinacleScriptRequest'];
                $bodyCustomData=isset($data['Body']['executeFinacleScript_CustomData'])?$data['Body']['executeFinacleScript_CustomData']:"";
                $bodySimpleData=$data['Body']['executeFinacleScriptRequest'];

                $xml = new \SimpleXMLElement('<FIXML xmlns="http://www.finacle.com/fixml"></FIXML>');

                $header = $xml->addChild('Header');
                $reqHeaderXml = $header->addChild('RequestHeader');

                $msgKeyXml = $reqHeaderXml->addChild('MessageKey');
                foreach ($requestHeader['MessageKey'] as $key => $value) {
                    $msgKeyXml->addChild($key, $value);
                }

                $msgInfoXml = $reqHeaderXml->addChild('RequestMessageInfo');
                foreach ($requestHeader['RequestMessageInfo'] as $key => $value) {
                    $msgInfoXml->addChild($key, $value);
                }

                $securityXml = $reqHeaderXml->addChild('Security');
                $tokenXml = $securityXml->addChild('Token');
                $pwdTokenXml = $tokenXml->addChild('PasswordToken');
                foreach ($requestHeader['Security']['Token']['PasswordToken'] as $key => $value) {
                    $pwdTokenXml->addChild($key, $value);
                }

                $bodyXml = $xml->addChild('Body');
                $execReqXml = $bodyXml->addChild('executeFinacleScriptRequest');
                $execReqXml->addChild('ExecuteFinacleScriptInputVO')->addChild('requestId', $body['ExecuteFinacleScriptInputVO']['requestId']);

                $customDataXml = $execReqXml->addChild('executeFinacleScript_CustomData');
                $tranCriteriaXml = $customDataXml->addChild('TranCriteria');
                $tranReqXml= $customDataXml->addChild('Tran_REQ');


                if($no_trancriteria==true)
                {
                        foreach ($bodySimpleData['executeFinacleScript_CustomData'] as $key => $value) {
                                $customDataXml->addChild($key, $value);
                        } 
                }
                else
                {
                        if(isset($body['executeFinacleScript_CustomData']['TranCriteria']))
                        {
                                foreach ($body['executeFinacleScript_CustomData']['TranCriteria'] as $key => $value) {
                                        $tranCriteriaXml->addChild($key, $value);
                                }
                        }
                       
                        if(isset($bodyCustomData['Tran_REQ']))
                        {
                                
                                foreach ($bodyCustomData['Tran_REQ'] as $key => $value) {
                                        $tranReqXml->addChild($key, $value);
                                }
                        }
                }

                return $xml->asXML();
        }

        public function convertSoapXmlToArray($soapXml)
        {
                // Nettoyer les namespaces pour faciliter le parsing
                $cleanXml = preg_replace('/xmlns[^=]*="[^"]*"/i', '', $soapXml);

                // Charger le XML en SimpleXMLElement
                libxml_use_internal_errors(true);
                $xmlObject = simplexml_load_string($cleanXml, 'SimpleXMLElement', LIBXML_NOCDATA);

                if ($xmlObject === false) {
                        return ['code' => 500, 'message' => 'Erreur de parsing XML'];
                }

                // Convertir en JSON puis en tableau
                $json = json_encode($xmlObject);
                $array = json_decode($json, true);

                return ['code' => 200, 'data' => $array];
        }

        public function array_to_xml($data, &$xml_data ) {
            
            foreach( $data as $key => $value ) {
                if(is_array($value) ) {
                    if( is_numeric($key) ){
                        $key = 'PartTrnRec';
                    }
                    $subnode = $xml_data->addChild($key);
                    $this->array_to_xml($value, $subnode);
                } else {
                    $xml_data->addChild("$key",htmlspecialchars("$value"));
                }
            }
        }
        
        public function get_integrations_info_dgda($id, $priority)
        {
                $where = "Paiementid_4 = ".$id." AND Priority_24 = ".$priority." AND Status_2 != 2 AND Montant_10 > 0";
                $builder = $this->db->table("logiref_cbs_instructions_dgda")
                        ->select("logiref_cbs_instructions_dgda.*")
                        ->where($where)
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgi($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgi")
                        ->select("logiref_cbs_instructions_dgi.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1 AND (TypeCompte_25 != 'F' AND TypeCompte_25 != 'T' AND TypeCompte_25 != 'BC') AND Montant_10 > 0")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgi_bank_fees($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgi")
                        ->select("logiref_cbs_instructions_dgi.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1 AND Montant_10 > 0 AND (TypeCompte_25 = 'F' OR TypeCompte_25 = 'T') ")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgi_bank_fees_bcc($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgi")
                        ->select("logiref_cbs_instructions_dgi.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Montant_10 > 0 AND Status_2 = 1 AND TypeCompte_25 = 'BC' ")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        
        public function get_integrations_info_dgrad($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->select("logiref_cbs_instructions_dgrad.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1 AND (TypeCompte_25 != 'F' AND TypeCompte_25 != 'T' AND TypeCompte_25 != 'BC') AND Montant_10 > 0")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgrad_bank_fees($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->select("logiref_cbs_instructions_dgrad.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Montant_10 > 0 AND Status_2 = 1 AND (TypeCompte_25 = 'F' OR TypeCompte_25 = 'T') ")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgrad_bank_fees_bcc($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->select("logiref_cbs_instructions_dgrad.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Montant_10 > 0 AND Status_2 = 1 AND TypeCompte_25 = 'BC' ")
                        ->get();
                
                return $builder->getResultArray();
        }

        public function get_integrations_info_dgda_bank_fees($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgda")
                        ->select("logiref_cbs_instructions_dgda.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Montant_10 > 0 AND Status_2 = 1 AND (TypeCompte_29 = 'F' OR TypeCompte_29 = 'T') ")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgda_bank_fees_bcc($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgda")
                        ->select("logiref_cbs_instructions_dgda.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Montant_10 > 0 AND Status_2 = 1 AND TypeCompte_29 = 'BC' ")
                        ->get();
                
                return $builder->getResultArray();
        }
		
	public function get_prepayment_integrations_info($id, $priority)
        {
                $builder = $this->db->table("logiref_cbs_prepayments_instructions")
                        ->select("logiref_cbs_prepayments_instructions.*")
                        ->where("Paiementid_4 = ".$id." AND Status_2 = 1 AND Priority_24 = ".$priority."")
                        ->get();
                
                return $builder->getResultArray();
        }
		
	public function get_prepayment_gu_integrations_info($lot)
        {
                $builder = $this->db->table("logiref_cbs_prepayments_gu_instructions")
                        ->select("logiref_cbs_prepayments_gu_instructions.*")
                        ->where("Paiementid_4 = ".$lot." AND Status_2 = 1")
                        ->get();
                
                return $builder->getResult();
        }
        
        public function save_cbs_return_dgda($account, $response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => date('Y-m-d H:i:s'),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Sydonia_5" => $bl,
                                "Result_6" => json_encode($response)
                        ];

                        $this->db->table("logiref_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function save_cbs_return($account, $response, $id)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => date('Y-m-d H:i:s'),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Paiementid_4" => $id,
                                "Result_6" => json_encode($response)
                        ];
                        $this->db->table("logiref_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function update_cbs_return($response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Result_6" => json_encode($response)
                        ];

                        $id = $this->db->table("logiref_cbs_returns")
                                ->where("Sydonia_5 = ".$bl."")
                                ->update($data);
                        
                        return $id;
                }
        }
		
        public function save_prepayment_cbs_return($account, $response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => date('Y-m-d H:i:s'),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Sydonia_5" => $bl,
                                "Result_6" => json_encode($response)
                        ];
                        $this->db->table("logiref_prepayments_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function update_cbs_instructions_dgi($logirefid)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgi")
                        ->where("Reference_14",$logirefid)
                        ->update($data);
                        
                return $id;
                
        }
        
        public function update_cbs_instructions_dgi_by_id($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgi")
                        ->where("Id_0",$id)
                        ->update($data);
                        
                return $id;
                
        }
        
        public function update_cbs_instructions_dgrad($logirefid)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->where("Reference_14", $logirefid)
                        ->update($data);
                        
                return $id;
        }
        public function update_cbs_instructions_dgrad_by_id($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->where("Id_0", $id)
                        ->update($data);
                        
                return $id;
        }
        public function update_cbs_instructions_dgda($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgda")
                        ->where("Paiementid_4", $id)
                        ->update($data);
                        
                return $id;
        }
        
        public function update_cbs_instructions_dgda_by_id($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgda")
                        ->where("Id_0", $id)
                        ->update($data);
                        
                return $id;
        }
		
	public function update_cbs_prepayments_instructions_dgda($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                        
                $id = $this->db->table("logiref_cbs_prepayments_instructions")
                        ->where("Paiementid_4", $id)
                        ->update($data);
                        
                return $id;
        }
        
        public function update_payment_prepayment($paiementid)
        {
                if ($paiementid != "") 
                {
                        $data = [
                            'Status_2' => 5,
                        ];
                    
                        $this->db->table('logiref_sydonia_prepayments')
                                 ->where('Id_0', $paiementid)
                                 ->update($data);
                    
                        return $this->db->affectedRows();
                }
        }
        public function update_payment_sydonia($paiementid)
        {
                if($paiementid != "")
                {
                        $data = [
                                "Status_2" => 5
                        ];

                        $this->db->table("logiref_integration_sydonia")
                                ->where("Id_0",$paiementid)
                                ->update($data);

                        return $this->db->affectedRows();
                }
        }
        
        public function update_bulletins_batch_cbs_instructions($returns)
        {
                $id = "";
                
                if($returns != "")
                {
                        if(isset($returns['200']) && $returns['200'] !="")
                        {
                                $ids = implode(",", $returns['200']);
       
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;

                                $data['Status_2'] = 2;

                                $id = $this->db->table('logiref_cbs_instructions_dgda')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        if(isset($returns['300']) && $returns['300'] !="")
                        {
                                $ids = implode(",", $returns['300']);
       
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;

                                $data['Status_2'] = 5;

                                $id = $this->db->table('logiref_cbs_instructions_dgda')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        if(isset($returns['411']) && $returns['411'] !="")
                        {
                                $ids = implode(",", $returns['411']);
       
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;

                                $data['Status_2'] = 4;

                                $id = $this->db->table('logiref_cbs_instructions_dgda')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        if(isset($returns['404']) && $returns['404'] !="")
                        {
                                $ids = implode(",", $returns['404']);

                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;

                                $data['Status_2'] = 5;

                                $id = $this->db->table('logiref_cbs_instructions_dgda')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        
                        return $id;
                }
        }
        
        public function update_cbs_instructions_prepayment($returns)
        {
               $id = "";
                
                if($returns != "")
                {
                        if(isset($returns['200']) && $returns['200'] !="")
                        {
                                $ids = implode(",", $returns['200']);
                                
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;
  
                                $data['Status_2'] = 2;
                                
                                $id = $this->db->table('logiref_cbs_prepayments_instructions')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);

                        }
                        if(isset($returns['300']) && $returns['300'] !="")
                        {
                                $ids = implode(",", $returns['300']);
                                        
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;
  
                                $data['Status_2'] = 5;
                                
                                $id = $this->db->table('logiref_cbs_prepayments_instructions')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        if(isset($returns['411']) && $returns['411'] !="")
                        {
                                $ids = implode(",", $returns['411']);
                                
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;
  
                                $data['Status_2'] = 4;
                                
                                $id = $this->db->table('logiref_cbs_prepayments_instructions')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                        if(isset($returns['404']) && $returns['404'] !="")
                        {
                                $ids = implode(",", $returns['404']);
                                
                                if (strpos($ids, ',') !== false):
                                        $ids =  explode(",", $ids);
                                else:
                                        $ids = array($ids);
                                endif;
  
                                $data['Status_2'] = 5;
                                
                                $id = $this->db->table('logiref_cbs_prepayments_instructions')
                                        ->whereIn('Id_0', $ids)
                                        ->update($data);
                        }
                    
                        return $id;
                }
        }
		
	public function update_prepayment_gu_instructions($lot, $data)
        {
                if($lot != "")
                {
                        $response = isset($data['response']) ? $data['response'] : 411;
                        $num_evenement = isset($data['Num_evenement']) ? $data['Num_evenement'] : 0;
                        
                        if($response == '200')
                        {
                            
                                $data = [
                                        "Status_2" => 2,
                                        "Code_22" => $response,
                                        "Returnid_27" => $num_evenement
                                ];

                                $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                        ->where("Paiementid_4", $lot)
                                        ->update($data);

                                return $this->db->affectedRows();
                        }
                        else
                        {
                                $data = [
                                        "Status_2" => 3,
                                        "Code_22" => $response,
                                        "Returnid_27" => $num_evenement,
                                        "Paiementid_4" => $lot
                                ];

                                $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                        ->where("Paiementid_4", $lot)
                                        ->update($data);

                                return $this->db->affectedRows();
                        }
                       
                }
        }
	public function update_reference_cbs_instructions_prepayment($id, $reference)
        {
                $data = [
                        "Reference_14" => $reference
                ];

                $this->db->table("logiref_cbs_prepayments_instructions")
                        ->where("Paiementid_4", $id)
                        ->update($data);
        }
        public function update_cbs_bank_charge_instructions_by_id($bank_charge_ids,$beneficiary,$type=null)
        {
                if(!empty($bank_charge_ids))
                {
                        if($beneficiary=="DGI")
                        {
                                $builder=$this->db->table("logiref_cbs_instructions_dgi");
                                foreach ($bank_charge_ids as $id)
                                {
                                        $data = [
                                                "Status_2" => 2
                                        ];
                                        $builder->where("Id_0",$id['Id_0'])->update($data);
                                }
                        }
                        elseif($beneficiary=="DGRAD")
                        {
                                $builder=$this->db->table("logiref_cbs_instructions_dgrad");
                                foreach ($bank_charge_ids as $id)
                                {
                                        $data = [
                                                "Status_2" => 2
                                        ];
                                        $builder->where("Id_0",$id['Id_0'])->update($data);
                                }
                        }
                        elseif($beneficiary=="DGDA")
                        {
                                if($type=="prepayment")
                                {
                                        $builder=$this->db->table("logiref_cbs_prepayments_gu_instructions");
                                        foreach ($bank_charge_ids as $id)
                                        {
                                                $data = [
                                                        "Status_2" => 2
                                                ];
                                                $builder->where("Id_0",$id['Id_0'])->update($data);
                                        }
                                }
                                else
                                {
                                        $builder=$this->db->table("logiref_cbs_instructions_dgda");
                                        foreach ($bank_charge_ids as $id)
                                        {
                                                $data = [
                                                        "Status_2" => 2
                                                ];
                                                $builder->where("Id_0",$id['Id_0'])->update($data);
                                        }
                                }
                                
                        }
                }
        }
        //Save Log
        public function save_log($data, $prefix = NULL)
        {
                $name = gmdate('Y-m-d')."_".$prefix;

                $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file

                $path = $baseDir . "/drive/logs/services/Finacle_standardbank";

                // Normalize path slashes for Windows
                $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path);

                // // Ensure the directory exists
                // $dir = dirname($path);
                // if (!is_dir($dir)) {
                // mkdir($dir, 0777, true); // create folders if needed
                // }
                
                // $path = APPPATH . "Modules/Services/Logs/Finacle/Standardbank";
                // Ensure the directory exists
                $dir = dirname($path);
                if (is_dir($dir)==false)
                {
                        mkdir($dir,0777,true);
                }
                
                $path = $path."/".$name;
                
                $handle = fopen($path.".logs", 'a+');
                $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                fwrite($handle, $data."\n\n");   
                fclose($handle);
        }

}
