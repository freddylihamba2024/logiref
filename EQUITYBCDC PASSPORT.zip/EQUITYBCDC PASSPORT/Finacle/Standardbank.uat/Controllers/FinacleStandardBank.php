<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Finacle\Standardbank\Models\FinacleStandardBankModel;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;

class FinacleStandardBank extends BaseController
{
        private $finacleModel=null;
        public $comptabilisationModel;
        public function __construct()
        {
                $this->finacleModel=new FinacleStandardBankModel();
                $this->comptabilisationModel = new ComptabilisationModel();
        }
        public function account_info($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $data_to_send = array();
                $failled = array();
                $return = array();
                $customerid = '';
                $account_number = '';
//                $response = '';
                $account_details = '';
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                
                if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';
                else
                    $result = str_replace('-', '', $data['Compte_33']);
		            $account = $result ;
                    
//                    $account_number = $data['Compte_33'];
                
                if(count($failled) == 0)
                {
                        /*
                        * --------------------------------------------
                        * Construction of data to send 
                        * --------------------------------------------
                        */
                        
                        ###### the request reference ###################
                        $requestuuid = '18561375061369';
                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                        // Construction de la structure de base
                        $data_to_send = [
                        'Header' => [
                                'RequestHeader' => [
                                'MessageKey' => [
                                        'RequestUUID' => $requestuuid,
                                        'ServiceRequestId' => 'executeFinacleScript',
                                        'ServiceRequestVersion' => '10.2',
                                        'ChannelId' => 'MOM',
                                        'LanguageId' => ''
                                ],
                                'RequestMessageInfo' => [
                                        'BankId' => 'CD',
                                        'TimeZone' => '',
                                        'EntityId' => '',
                                        'EntityType' => '',
                                        'ArmCorrelationId' => '',
                                        'MessageDateTime' => $date
                                ],
                                'Security' => [
                                        'Token' => [
                                        'PasswordToken' => [
                                                'UserId' => '',
                                                'Password' => ''
                                        ]
                                        ],
                                        'FICertToken' => '',
                                        'RealUserLoginSessionId' => '',
                                        'RealUser' => '',
                                        'RealUserPwd' => '',
                                        'SSOTransferToken' => ''
                                ]
                                ]
                        ],
                        'Body' => [
                                'executeFinacleScriptRequest' => [
                                'ExecuteFinacleScriptInputVO' => [
                                        'requestId' => 'FullStmtwithVAT_mn001.scr'
                                ],
                                'executeFinacleScript_CustomData' => [
                                        'TranCriteria' => [
                                        'acctNum' => $account,
                                        'fromDate' => '01-10-2015',
                                        'toDate' => gmdate('d-m-Y'),
                                        'txnType' => 'C',
                                        'sortIn' => 'D'
                                        ]
                                ]
                                ]
                        ]
                        ];
                        
                        $response = $this->finacleModel->account_info($data_to_send, $requestuuid, $date);
                        // var_dump($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']);die;
                        //$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls'] = 'Success';
                        
                        if(isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']) && isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls']))
                        {
                                $account_name = isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls']['custDtls']['Name1']) ? $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls']['custDtls']['Name1'] : "";
                                $devise = isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['crncyCode']) ? $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['crncyCode'] : "";
                                $balance = isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['availBal']) ? $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['availBal'] : "";
                                
                                // $account_name = 'Dorcas Balako';
                                // $devise = 'CDF';
                                // $balance = 17280000000;
                                
                                $data_to_return['code']="200";
                                $data_to_return['account_name'] = $account_name;
                                $data_to_return['currency'] = $devise;
                                $data_to_return['balance'] = $balance;
                                
                                $return = $data_to_return;
                        }
                        else
                        {
                                $return['code'] = '404';
                        }
                                                
                        return $return;
                }
                else
                {
                        $return['code'] = 405;
                        $result_to_save = json_encode($failled);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "account_info");

                        return $return;
                }
        }
        public function virement($data)
        {
                /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $return = array();
                $data_to_save = array();
                $data_to_send = array();
                $data_to_update = array();
                $request_to_save = array();
                $instructions = array();
                $infos = array();
                $status = array();
                $transaction=array();
                $transaction_return = array();
                $failled = array();
                $code = '';
                $return_update = "";
                $i =0;
                $j = 0;
                $type='';
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */


                
                
                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data['Taux_41']) || $data['Taux_41'] == "") $failled [] = "The exchange rate is not defined";
                
                
                if(count($failled) == 0)
                {
                    
                        /*
                        * ------------------------------------------------
                        * Get instructions to send to the CBS from the BD
                        * ------------------------------------------------
                        */
                        
                        if(isset($data['Type']) && $data['Type'] != '')
                        {
                                $type = $data['Type'];
                        }

                        #update the payment status before sending the request
                        if(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['Type']) && $data['Type'] == 'prepayment')
                                {
                                        $this->finacleModel->update_payment_prepayment($data['Sydonia_49']);
                                }
                                else 
                                {
                                        if(isset($data['Type']) && $data['Type'] == 'first_transaction')
                                        {
                                                #No update to execute.
                                        }
                                        else
                                        {
                                                $this->finacleModel->update_payment_sydonia($data['Sydonia_44']);
                                        }
                                }
                        }

                        if (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA') 
                        {

                                if(isset($data['Type']) && $data['Type'] == 'prepayment')
                                {
                                        // get only prepayments integrations 
                                        $instructions = $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_49'], $data['Priority']);
                                }
                                else
                                {
                                        $instructions = $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                                }
                        } 
                   
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGI') 
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgi($data['Logirefid_4']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees($data['Logirefid_4']);
                                $fees_bcc_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees_bcc($data['Logirefid_4']);
                        } 
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGRAD') 
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgrad($data['Logirefid_4']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees($data['Logirefid_4']);
                                $fees_bcc_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees_bcc($data['Logirefid_4']);
                        }
                        
                        $exchange_rate = isset($data['Taux_41']) ? $data['Taux_41'] : "";
                        
                        if (!empty($instructions)) 
                        {
                                $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : ""; 
                                $rate_code = isset($infos['rate_code']) ? $infos['rate_code'] : "TTB";

                                foreach ($instructions as $row) 
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);

                                        
                                        ###### the transaction refernce ###################
                                        $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                        
                                        // $requestuuid = $requestuuid;
                                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                        if ($row["Montant_10"] > 0 && $compte1 !="")  
                                        {

                                                $messageKey = array(
                                                'RequestUUID' =>$data['Logirefid_4'],

                                                'ServiceRequestId' => 'executeFinacleScript',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'MOM',
                                                'LanguageId' => '',
                                                );
                                                $requestMessageInfo = array(
                                                'BankId' => 'CD',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                                );
                                                $security = array(
                                                'Token' => array(
                                                        'PasswordToken' => array(
                                                        'UserId' => '',
                                                        'Password' => ''
                                                        ),
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                )
                                                );
                                                
                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                $executeFinacleScriptInputVO = array(
                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                        );
                                                
                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;
                                

                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                $tranREQ = array(
                                                    'channelId'=>'MOM',
                                                    'ChannelRefNum'=>$requestuuid,
                                                    'ReversalFlag'=>'N',
                                                    'TranAmount'=>$row["Montant_10"],
                                                    'TranCrncy'=>$row["Devise_11"],
                                                    'RateCode'=>'NOR',
                                                    'DrAcctNo'=>$compte1,
                                                    'DrValueDate'=>date("Y-m-d"),
                                                    'DrForcePostFlag'=>'N',
                                                    'DrTranParticulars'=>$row["Libelle_12"],
                                                    'CrAcctNo'=>$compte2,
                                                    'CrValueDate'=>date("Y-m-d"),
                                                    'CrForcePostFlag'=>'N',
                                                    'CrTranParticulars'=>substr($row['Libelle_12'], 0, 100),
                                                    'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 100),
                                                    'TranParticularsCodeCr'=>'COLL',
                                                );
                                                

                                               

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                
                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                                // var_dump($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']);die;
                                        
                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                                
                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                {
                                                        //Simulation
                                                        //$responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                                        //$responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] = 'FAILUREINTF1021';
                                                        
                                                        //if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        $responseBody = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];

                                                        if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        {
                                                                $code = 200;
                                                                // var_dump($row['Id_0']);
                                                                $transaction[$i]=$code;
                                                                
                                                                array_push($transaction_return,$transaction);
                                                               
                                                                $data_to_save['Num_evenement'] = isset($responseBody['Tran_RES']['TransactionId']) ? $responseBody['Tran_RES']['TransactionId'] : "";
                                                                $data_to_save['code'] = $code;
                                                                $data_to_save['response'] = $code;
                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                if($data['Beneficaire_15'] == 'DGI')
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgi_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGRAD')
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgrad_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGDA' && $type != "prepayment")
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgda_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGDA' && $type == "prepayment")
                                                                {
                                                                        $this->finacleModel->update_cbs_prepayments_instructions_dgda($row['Sydonia_49']);
                                                                }
                                                               
                                                                $return = $data_to_save;
                                                                $i++;
                                                        }
                                                        else
                                                        {
                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                {
                                                                        
                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                        {
                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                $data_to_save['code'] = 'E1021';
                                                                                $data_to_save['response'] = 'E1021';
                                                                        } 
                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                        {
                                                                                //Insufficient Balance in Account for Debit    
                                                                                $data_to_save['code'] = 'E1023';
                                                                                $data_to_save['response'] = 'E1023';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1024';
                                                                                $data_to_save['response'] = 'E1024';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1026';
                                                                                $data_to_save['response'] = 'E1026';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                        {
                                                                                //Error in Transaction Creations                
                                                                                $data_to_save['code'] = 'E1027';
                                                                                $data_to_save['response'] = 'E1027';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                        {
                                                                                //Invalid Currency Code                        
                                                                                $data_to_save['code'] = 'E1030';
                                                                                $data_to_save['response'] = 'E1030';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                        {
                                                                                //Currency Code is Null                         
                                                                                $data_to_save['code'] = 'E1031';
                                                                                $data_to_save['response'] = 'E1031';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                        {
                                                                                //Benificiary account number is NULL            
                                                                                $data_to_save['code'] = 'E1032';
                                                                                $data_to_save['response'] = 'E1032';
                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                        {
                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                $data_to_save['code'] = 'E1034';
                                                                                $data_to_save['response'] = 'E1034';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                        {
                                                                                //Payee Account Number is Closed               
                                                                                $data_to_save['code'] = 'E1035';
                                                                                $data_to_save['response'] = 'E1035';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                        {
                                                                                //Error in feedback generation for file         
                                                                                $data_to_save['code'] = 'E1041';
                                                                                $data_to_save['response'] = 'E1041';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                        {
                                                                                //InValid Value Date                           
                                                                                $data_to_save['code'] = 'E1042';
                                                                                $data_to_save['response'] = 'E1042';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                        {
                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                $data_to_save['code'] = 'E1044';
                                                                                $data_to_save['response'] = 'E1044';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                        {
                                                                                //Reroute Placeholder Not Found                
                                                                                $data_to_save['code'] = 'E1045';
                                                                                $data_to_save['response'] = 'E1045';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                        {
                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                $data_to_save['code'] = 'E1046';
                                                                                $data_to_save['response'] = 'E1046';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                        {
                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                $data_to_save['code'] = 'E1047';
                                                                                $data_to_save['response'] = 'E1047';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                        {
                                                                                //Beneficiary Account is Null                   
                                                                                $data_to_save['code'] = 'E1048';
                                                                                $data_to_save['response'] = 'E1048';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                        {
                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                $data_to_save['code'] = 'E1049';
                                                                                $data_to_save['response'] = 'E1049';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                        {
                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                $data_to_save['code'] = 'E1050';
                                                                                $data_to_save['response'] = 'E1050';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                        {
                                                                                //Beneficiary Sortcode is Null                  
                                                                                $data_to_save['code'] = 'E1051';
                                                                                $data_to_save['response'] = 'E1051';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                        {
                                                                                //DEBIT BALANCE LIMIT
                                                                                $data_to_save['code'] = 'E4324';
                                                                                $data_to_save['response'] = 'E4324';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                        {
                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                $data_to_save['code'] = 'E4326';
                                                                                $data_to_save['response'] = 'E4326';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                        {
                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                $data_to_save['code'] = 'E5542';
                                                                                $data_to_save['response'] = 'E5542';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $data_to_save['code'] = 'E000';
                                                                        $data_to_save['response'] = 'E000'; 
                                                                }
                                                        }
                                                        
                                                } 
                                                else 
                                                {

                                                        //Finacle system Error
                                                        $info = json_encode($response);
                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                        $data_to_save['code'] = 'E411';
                                                        $data_to_save['response'] = 'E411';
                                                
                                                       
                                                }


                                        }
                                        
                                        if ($data['Beneficaire_15'] == 'DGDA') 
                                        {
                                                if(isset($data['Type']) && $data['Type'] == "prepayment")
                                                {
                                                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'], $data_to_save, $data['Sydonia_49']);
                                                }
                                                elseif(isset($data['Type']) && $data['Type'] == "others")
                                                {
                                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                                }
                                                else 
                                                {
                                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                                }
                                        } 
                                        else 
                                        {
                                                $this->finacleModel->save_cbs_return($data['Account_3'], $data_to_save, $data['Id_0']);
                                        }
//                                 
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }
                               
                                if(count($transaction_return)==count($instructions))
                                {

                                //         # Bank fees integration
                                        if(!empty($fees_instructions) || !empty($fees_bcc_instructions))
                                        {
                                                $return_bank_charge=$this->virement_bank_charge($data, $fees_instructions);
                                                $code_bank_charge=0;
                                                $code_bcc_bank_charge=0;
                                                
                                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                                {
                                                        $code_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                       
                                                $return_bcc_bank_charge=$this->virement_bcc_bank_charge($data, $fees_bcc_instructions);
                                                
                                                if(isset($return_bcc_bank_charge['code']) && $return_bcc_bank_charge['code']==200)
                                                {
                                                        $code_bcc_bank_charge=200;
                                                        $bank_charges=$return_bcc_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                                
                                                if($code_bank_charge==200 || $code_bcc_bank_charge==200)
                                                {
                                                        $data_to_save['code'] = 200;
                                                        $data_to_save['response'] = 200;
                                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }
                                                else
                                                {
                                                        $data_to_save['code'] = 300;
                                                        $data_to_save['response'] = 300;
                                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }  
                                                
                                        }
                                }
                                elseif(count($transaction_return)<=0)
                                {
                                        
                                        $data_to_save['code'] = 400;
                                        $data_to_save['response'] = 400;
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Désolé ! la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                       
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = 300;
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                $response=$data_to_save;
                                return json_encode($response);
                                    
                        }
                }
                else
                {
                        $response['code'] = 405;
                        $response['response'] = 405;
                        $response['message'] = "Missing data in the request";
                        $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        
                        $result_to_save = json_encode($failled);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

                        return json_encode($response);
                }
        }
        public function reservation($data)
        {

        }
        public function cancel_reservation($data)
        {

        }
        public function get_exchange_rate($data)
        {

        }
        public function virement_bank_charge($data, $fees_instructions)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $data_to_send = array();
                $failled = array();
                $return = array();
                $customerid = '';
                $account_number = '';
//                $response = '';
                $account_details = '';
                $bank_charges=array();
                $type="";
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                
                if(!isset($data['Logirefid_4'])) $failled[] = 'The account is not defined';
                else
                    $logirefid = str_replace('-', '', $data['Logirefid_4']);
                
                if(count($failled) == 0)
                {
                        /*
                        * --------------------------------------------
                        * Construction of data to send 
                        * --------------------------------------------
                        */
                        if(isset($data['Type']) && $data['Type'] != '')
                        {
                                $type = $data['Type'];
                        }
                        
                        if(!empty($fees_instructions))
                        {
                                 ###### the request reference ###################
                                $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                
                                //$requestuuid = $data['Logirefid_4']."-".$fees_instructions[0]['Id_0'];  
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=> $requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'MOM',
                                                        'LanguageId'=>'',
                                                    );
                                $requestMessageInfo = array(
                                                        'BankId'=>'CD',
                                                        'TimeZone'=>'GMT+01:00',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                    );
                                $security = array(
                                                    'Token'=>array(
                                                            'PasswordToken'=>array(
                                                                    'UserId'=>'',
                                                                    'Password'=>''
                                                            ),
                                                    'FICertToken'=>'',
                                                    'RealUserLoginSessionId'=>'',
                                                    'RealUser'=>'',
                                                    'RealUserPwd'=>'',
                                                    'SSOTransferToken'=>''
                                                    )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'collectChargeOnlinemn001.scr'
                                                                );

                                
                                $libelle_bank_fees = $this->remove_all_special_characters($fees_instructions[0]["Libelle_12"]);
                                $libelle_vat = $this->remove_all_special_characters($fees_instructions[1]["Libelle_12"]);
                                
                                $executeFinacleScript_CustomData = array(
                                        "eventType"=>"CDCI",
                                        "eventId"=>"MoMo Collection",
                                        "channelRefNum"=>$requestuuid,
                                        "acctNum"=>$fees_instructions[0]['Compte_13'],
                                        "isConsolidatedFlg"=>"N",
                                        "isProxyReqdFlg"=>"N",
                                        "chrgAcct"=>$fees_instructions[0]['Compte_13'],
                                        "valueDate"=>date("d-m-Y"),
                                        "chrgAmt"=>$fees_instructions[0]['Montant_10'],
                                        "chrgCcy"=>$fees_instructions[0]['Devise_11'],
                                        "drChrgTrnParticulars"=>$libelle_bank_fees,
                                        "vatAmt"=>$fees_instructions[1]['Montant_10'],
                                        "vatCcy"=>$fees_instructions[1]['Devise_11'],
                                        "drVATTrnParticulars"=>$libelle_vat,
                                        "crVATTrnParticulars"=>$libelle_vat,
                                );
                           

                                $executeFinacleScriptReques['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;
                                
                                
                                
                                $executeFinacleScriptReques['executeFinacleScript_CustomData']= $executeFinacleScript_CustomData;

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptReques;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;
                                
                                $response = $this->finacleModel->bank_charge($data_to_send,$requestuuid,$date);
                                
                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                
                                

                                if(isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['data']['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        $tranStatus=isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus']:"";
                                        $channelRefNum= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum']:"";
                                        $chrgTranId= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId']:"";
                                        $chrgTranDate= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate']:"";

                                        //SIMULATION
                                        // $tranStatus="S";
                                        // $channelRefNum= "87648";
                                        // $chrgTranId= "787974898";
                                        // $chrgTranDate= "2023-10-01T12:00:00.000+01:00";

                                        if($tranStatus=="S")
                                        {
                                                array_push($bank_charges,$fees_instructions[0]);
                                                array_push($bank_charges,$fees_instructions[1]);
                                                
                                                $data_to_return['code']="200";
                                                $data_to_return['tranStatus']=$tranStatus;
                                                $data_to_return['channelRefNum'] = $channelRefNum;
                                                $data_to_return['chrgTranId'] = $chrgTranId;
                                                $data_to_return['chrgTranDate'] = $chrgTranDate;
                                                $data_to_return['bankCharges'] = $bank_charges;
                                        
                                                $return = $data_to_return;
                                        }
                                        else
                                        {
                                               $error=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Error'];
                                               if(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF1128")
                                               {
                                                        //Duplicate request
                                                        $data_to_return['code']="E1128";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;    
                                               }
                                               elseif(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF2985")
                                               {
                                                        //Cross currency request not allowed Or Failed to create Debit Part Tran
                                                        $data_to_return['code']="E2985";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;  
                                               }
                                               elseif(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF2982")
                                               {
                                                        //VAT and Charge currency must be same
                                                        $data_to_return['code']="E2982";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;  
                                               }
                                               else
                                               {
                                                        //Other errors
                                                        $data_to_return['code']="E400";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;   
                                               }
                                        }

                                        
                                        
                                        $result_to_save = json_encode($return);
                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;

                        }
                        else
                        {
                                $response['code'] = 405;
                                $response['response'] = 405;
                                $response['message'] = "Missing data in the request";
                                $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                                return $response;
                        }
                        
                }
                else
                {
                        $return['code'] = 405;
                        $result_to_save = json_encode($failled);
       
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                        return $return;
                }
        }
        public function virement_bcc_bank_charge($data, $fees_instructions)
        {
                  /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $data_to_send = array();
                $failled = array();
                $return = array();
                $customerid = '';
                $account_number = '';
//                $response = '';
                $account_details = '';
                $bank_charges=array();
                $type="";
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                
                if(!isset($data['Compte_33'])) $failled[] = 'The account is not defined';
                else
                    $result = str_replace('-', '', $data['Compte_33']);
                    $account = $result ;
                            
//                if(!isset($data['Paiementid_4']) && $data['Paiementid_4']=="") $failled[] = 'The paiement id is not defined';
//                
//                if(!isset($data['Beneficaire_15']) && $data['Beneficaire_15']=="") $failled[] = 'The beneficiary id is not defined';
                
                    
//                    $account_number = $data['Compte_33'];
                
                if(count($failled) == 0)
                {
                        /*
                        * --------------------------------------------
                        * Construction of data to send 
                        * --------------------------------------------
                        */
                        if(isset($data['Type']) && $data['Type'] != '')
                        {
                                $type = $data['Type'];
                        }
                        
                        
                        if(!empty($fees_instructions))
                        {
                                 ###### the request reference ###################
                                $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                //$requestuuid = $requestuuid=$data['Logirefid_4']."-".$fees_instructions[0]['Id_0'];
                                $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));

                                $messageKey = array(
                                                        'RequestUUID'=> $requestuuid,
                                                        'ServiceRequestId'=>'executeFinacleScript',
                                                        'ServiceRequestVersion'=>'',
                                                        'ServiceRequestVersion'=>'10.2',
                                                        'ChannelId'=>'MOM',
                                                        'LanguageId'=>'',
                                                    );
                                $requestMessageInfo = array(
                                                        'BankId'=>'CD',
                                                        'TimeZone'=>'GMT+05:00',
                                                        'EntityId'=>'',
                                                        'EntityType'=>'',
                                                        'ArmCorrelationId'=>'',
                                                        'MessageDateTime'=>$date
                                                    );
                                $security = array(
                                                    'Token'=>array(
                                                            'PasswordToken'=>array(
                                                                    'UserId'=>'',
                                                                    'Password'=>''
                                                            ),
                                                    'FICertToken'=>'',
                                                    'RealUserLoginSessionId'=>'',
                                                    'RealUser'=>'',
                                                    'RealUserPwd'=>'',
                                                    'SSOTransferToken'=>''
                                                    )
                                                );

                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                $requestHeader['RequestHeader']['Security'] = $security;


                                $executeFinacleScriptInputVO = array(
                                                                        'requestId'=>'collectChargeOnlinemn001.scr'
                                                                );

                                $executeFinacleScriptReques['ExecuteFinacleScriptInputVO'] = $executeFinacleScriptInputVO;
                                
                                $libelle_bank_fees = $this->remove_all_special_characters($fees_instructions[0]["Libelle_12"]);
                                
                                $executeFinacleScriptReques['executeFinacleScript_CustomData']= array(
                                    "eventType"=>"CDCI",
                                    "eventId"=>"MoMo Collection",
                                    "channelRefNum"=>$requestuuid,
                                    "acctNum"=>$account,
                                    "isConsolidatedFlg"=>"N",
                                    "isProxyReqdFlg"=>"N",
                                    "chrgAcct"=>$fees_instructions[0]['Compte_13'],
                                    "valueDate"=>date("d-m-Y"),
                                    "chrgAmt"=>$fees_instructions[0]['Montant_10'],
                                    "chrgCcy"=>$fees_instructions[0]['Devise_11'],
                                    "drChrgTrnParticulars"=>$libelle_bank_fees,
                                    "vatAmt"=>'',
                                    "vatCcy"=>'',
                                    "drVATTrnParticulars"=>'',
                                    "crVATTrnParticulars"=>'',
                                );

                                $body['executeFinacleScriptRequest']= $executeFinacleScriptReques;

                                $data_to_send['Header']= $requestHeader;
                                $data_to_send['Body'] = $body;
                                
                                $response = $this->finacleModel->bank_charge($data_to_send,$requestuuid,$date);
                       
                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status']="SUCCESS";

                                if(isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['data']['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        $tranStatus=isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus']:"";
                                        $channelRefNum= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum']:"";
                                        $chrgTranId= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId']:"";
                                        $chrgTranDate= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate']:"";

                                        //SIMULATION
                                        // $tranStatus="S";
                                        // $channelRefNum= "87648";
                                        // $chrgTranId= "787974898";
                                        // $chrgTranDate= "2023-10-01T12:00:00.000+01:00";
                                        
                                        if($tranStatus=="S")
                                        {
                                                array_push($bank_charges,$fees_instructions[0]);
                                                
                                                $data_to_return['code']="200";
                                                $data_to_return['tranStatus']=$tranStatus;
                                                $data_to_return['channelRefNum'] = $channelRefNum;
                                                $data_to_return['chrgTranId'] = $chrgTranId;
                                                $data_to_return['chrgTranDate'] = $chrgTranDate;
                                                $data_to_return['bankCharges'] = $bank_charges;
                                        
                                                $return = $data_to_return;
                                        }
                                        else
                                        {
                                               $error=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Error'];
                                               if(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF1128")
                                               {
                                                        //Duplicate request
                                                        $data_to_return['code']="E1128";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;    
                                               }
                                               elseif(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF2985")
                                               {
                                                        //Cross currency request not allowed Or Failed to create Debit Part Tran
                                                        $data_to_return['code']="E2985";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;  
                                               }
                                               elseif(isset($error['FIBusinessException']['ErrorDetail']) && $error['FIBusinessException']['ErrorDetail']['ErrorCode']=="INTF2982")
                                               {
                                                        //VAT and Charge currency must be same
                                                        $data_to_return['code']="E2982";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;  
                                               }
                                               else
                                               {
                                                        //Other errors
                                                        $data_to_return['code']="E400";
                                                        $data_to_return['tranStatus']=$tranStatus;
                                                        $data_to_return['channelRefNum'] = $channelRefNum;
                                                
                                                        $return = $data_to_return;   
                                               }
                                        }

                                        $result_to_save = json_encode($return);
                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;

                        }
                        else
                        {
                                $response['code'] = 405;
                                $response['response'] = 405;
                                $response['message'] = "Missing data in the request";
                                $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                                return $response;
                        }
                        
                }
                else
                {
                        $return['code'] = 405;
                        $result_to_save = json_encode($failled);
       
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                        return $return;
                }
        }
        
        public function debit_customer_bulletin_single($data)
        {
                # First call the treatment function
                return $this->bulletin_single_integration_treatment($data);
        }

        public function debit_customer_bulletin_batch($data)
        {
                # First call the treatment function
                return $this->bulletin_batch_integration_treatment($data);
        }

        public function debit_customer_prepayment($data)
        {
                # First call the treatment function
                return $this->bulletin_prepayment_integration_treatment($data);
        }

        public function regularize_payment($data)
        {
                # First call the treatment function
                return $this->regularize_payment_treatment($data);
        }
        
        public function debit_customer_bulletin_single_integration($data)
        {
                /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $return = array();
                $data_to_save = array();
                $data_to_send = array();
                $infos = array();
                $status = array();
                $transaction_return = array();
                $failled = array();
                $code = '';
                $type = '';
                $i =1;
                $j = 0;

                /*
                * --------------------------------------------
                * Test all required data
                * --------------------------------------------
                */
            
                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data["Designation_14"]) || $data["Designation_14"] == "") $failled [] = "The designation is not defined";
                
                if(count($failled) == 0)
                {
                        $instructions = $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                        $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($data['Logirefid_4']);

                        ###### the transaction refernce ###################
                     
                        $exchange_rate = isset($data['Taux_41']) ? $data['Taux_41'] : "";
                        
                        if (!empty($instructions)) 
                        {
                                foreach ($instructions as $row) 
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);
                                        
                                        //$requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                        $requestuuid=$data['Logirefid_4']."-".$row['Id_0'];
                                        $date = date("Y-m-d\TH:i:s.000");
                                        

                                        if ($row["Montant_10"] > 0) 
                                        {
                                                $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : ""; 
                                                $rate_code = isset($infos['rate_code']) ? $infos['rate_code'] : "TTB";

                                                $messageKey = array(
                                                'RequestUUID' =>$requestuuid,

                                                'ServiceRequestId' => 'executeFinacleScript',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'MOM',
                                                'LanguageId' => '',
                                                );
                                                $requestMessageInfo = array(
                                                'BankId' => 'CD',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                                );
                                                $security = array(
                                                'Token' => array(
                                                        'PasswordToken' => array(
                                                        'UserId' => '',
                                                        'Password' => ''
                                                        ),
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                )
                                                );
                                                
                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                $executeFinacleScriptInputVO = array(
                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                        );
                                                
                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;
                                

                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                $tranREQ = array(
                                                    'channelId'=>'MOM',
                                                    'ChannelRefNum'=>$requestuuid,
                                                    'ReversalFlag'=>'N',
                                                    'TranAmount'=>str_replace(' ','',$row["Montant_10"]),
                                                    'TranCrncy'=>$row["Devise_11"],
                                                    'RateCode'=>'NOR',
                                                    'DrAcctNo'=>$compte1,
                                                    'DrValueDate'=>date("Y-m-d"),
                                                    'DrForcePostFlag'=>'N',
                                                    'DrTranParticulars'=>$row["Libelle_12"],
                                                    'CrAcctNo'=>$compte2,
                                                    'CrValueDate'=>date("Y-m-d"),
                                                    'CrForcePostFlag'=>'N',
                                                    'CrTranParticulars'=>substr($row['Libelle_12'], 0, 50),
                                                    'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 50),
                                                    'TranParticularsCodeCr'=>'COLL',
                                                );

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                
                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                     
                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                {

                                                        $responseBody=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];

                                                        //Simulation
                                                       // $responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                                        //$responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] = 'FAILUREINTF1021';

                                                        //$responseBody['Tran_RES']['RespCode']="SUCCESSINTF0001";
                                                        
                                                        if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        {
                                                                $code = 200;

                                                                $transaction[$code][$i]=$code;

                                                                array_push($transaction_return,$transaction);

                                                                $data_to_save['Num_evenement'] = isset($response['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['OffUsRefNum']) ? $response['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['OffUsRefNum'] : "";
                                                                $data_to_save['code'] = $code;
                                                                $data_to_save['response'] = $code;
                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                
                                                                $this->finacleModel->update_cbs_instructions_dgda_by_id($row['Id_0']);

                                                                $i++;
                                                        }
                                                        else
                                                        {
                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                {
                                                                        
                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                        {
                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                $data_to_save['code'] = 'E1021';
                                                                                $data_to_save['response'] = 'E1021';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                        {
                                                                                //Insufficient Balance in Account for Debit    
                                                                                $data_to_save['code'] = 'E1023';
                                                                                $data_to_save['response'] = 'E1023';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1024';
                                                                                $data_to_save['response'] = 'E1024';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1026';
                                                                                $data_to_save['response'] = 'E1026';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                        {
                                                                                //Error in Transaction Creations                
                                                                                $data_to_save['code'] = 'E1027';
                                                                                $data_to_save['response'] = 'E1027';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                        {
                                                                                //Invalid Currency Code                        
                                                                                $data_to_save['code'] = 'E1030';
                                                                                $data_to_save['response'] = 'E1030';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                        {
                                                                                //Currency Code is Null                         
                                                                                $data_to_save['code'] = 'E1031';
                                                                                $data_to_save['response'] = 'E1031';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                        {
                                                                                //Benificiary account number is NULL            
                                                                                $data_to_save['code'] = 'E1032';
                                                                                $data_to_save['response'] = 'E1032';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                        {
                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                $data_to_save['code'] = 'E1034';
                                                                                $data_to_save['response'] = 'E1034';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                        {
                                                                                //Payee Account Number is Closed               
                                                                                $data_to_save['code'] = 'E1035';
                                                                                $data_to_save['response'] = 'E1035';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                        {
                                                                                //Error in feedback generation for file         
                                                                                $data_to_save['code'] = 'E1041';
                                                                                $data_to_save['response'] = 'E1041';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                        {
                                                                                //InValid Value Date                           
                                                                                $data_to_save['code'] = 'E1042';
                                                                                $data_to_save['response'] = 'E1042';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                        {
                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                $data_to_save['code'] = 'E1044';
                                                                                $data_to_save['response'] = 'E1044';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                        {
                                                                                //Reroute Placeholder Not Found                
                                                                                $data_to_save['code'] = 'E1045';
                                                                                $data_to_save['response'] = 'E1045';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                        {
                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                $data_to_save['code'] = 'E1046';
                                                                                $data_to_save['response'] = 'E1046';
                                                                                $data_to_save['msg'] ='<div class="alert aDanger text-white">'. $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                        {
                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                $data_to_save['code'] = 'E1047';
                                                                                $data_to_save['response'] = 'E1047';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                        {
                                                                                //Beneficiary Account is Null                   
                                                                                $data_to_save['code'] = 'E1048';
                                                                                $data_to_save['response'] = 'E1048';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                        {
                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                $data_to_save['code'] = 'E1049';
                                                                                $data_to_save['response'] = 'E1049';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                        {
                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                $data_to_save['code'] = 'E1050';
                                                                                $data_to_save['response'] = 'E1050';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                        {
                                                                                //Beneficiary Sortcode is Null                  
                                                                                $data_to_save['code'] = 'E1051';
                                                                                $data_to_save['response'] = 'E1051';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                        {
                                                                                //DEBIT BALANCE LIMIT
                                                                                $data_to_save['code'] = 'E4324';
                                                                                $data_to_save['response'] = 'E4324';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                        {
                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                $data_to_save['code'] = 'E4326';
                                                                                $data_to_save['response'] = 'E4326';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                        {
                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                $data_to_save['code'] = 'E5542';
                                                                                $data_to_save['response'] = 'E5542';
                                                                        }
                                                                        
                                                                        
                                                                }
                                                                else
                                                                {
                                                                        $data_to_save['code'] = 'E000';
                                                                        $data_to_save['response'] = 'E000'; 
                                                                }
                                                                
                                                        }
                                                        
                                                } 
                                                else 
                                                {

                                                        //Finacle system Error
                                                        $info = json_encode($response);
                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                        $data_to_save['code'] = 'E411';
                                                        $data_to_save['response'] = 'E411';
                                                
                                                       
                                                }
                                        }
                                        
                                        $return= $data_to_save;
                                         
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $data_to_save, $data['Sydonia_44']);
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }
                                
                                if(count($transaction_return)==count($instructions))
                                {
                                        # Bank fees integration
                                        if(!empty($fees_instructions))
                                        {
                                                $return_bank_charge=$this->virement_bank_charge($data, $fees_instructions);
                                                $code_bank_charge=0;
                                                
                                                // $return_bank_charge['code']=200;

                                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                                {
                                                        $code_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                                
                                                if($code_bank_charge==200)
                                                {
                                                        $data_to_save['code'] = 200;
                                                        $data_to_save['response'] = 200;
                                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }
                                                else
                                                {
                                                        $data_to_save['code'] = 300;
                                                        $data_to_save['response'] = 300;
                                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }  
                                                
                                        }
                                }
                                elseif(count($transaction_return)<=0)
                                {
                                        $data_to_save['code'] = 400;
                                        $data_to_save['response'] = isset($return['response']) ? $return['response'] : "400";
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Désolé ! la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = isset($return['response']) ? $return['response'] : "400";
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                
                                $response=$data_to_save;
//                                
                                return $response;
                                    
                        }
                }
                else
                {
                        $response['code'] = 405;
                        $response['response'] = 405;
                        $response['message'] = "Missing data in the request";
                        $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        
                        $result_to_save = json_encode($response);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

//                        return json_encode($response);
                        return $response;
                }
        }

        public function debit_customer_bulletin_batch_integration($data)
        {
                /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $return = array();
                $data_to_save = array();
                $data_to_send = array();
                $infos = array();
                $status = array();
                $transaction_return = array();
                $failled = array();
                $code = '';
                $i =1;
                $j = 0;
                $type='';

                /*
                * --------------------------------------------
                * Test all required data
                * --------------------------------------------
                */

                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data["Designation_14"]) || $data["Designation_14"] == "") $failled [] = "The designation is not defined";

                if(count($failled) == 0)
                {
                        $instructions = $this->finacleModel->get_bulletins_batch_integrations_info($data['Sydonia_44'], $data['Priority']);
                        $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($data['Logirefid_4']);

                        $exchange_rate = isset($data['Taux_41']) ? $data['Taux_41'] : "";
                        
                        if (!empty($instructions)) 
                        {
                                $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : ""; 
                                $rate_code = isset($infos['rate_code']) ? $infos['rate_code'] : "TTB";

                                foreach ($instructions as $row) 
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);
                                        
                                        ###### the transaction refernce ###################
                                        // $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                        $requestuuid=$data['Logirefid_4']."-".$row['Id_0'];
                                        $date = date("Y-m-d\TH:i:s.000");

                                        if ($row["Montant_10"] > 0 && $compte1 !="")  
                                        {

                                                $messageKey = array(
                                                'RequestUUID' =>$requestuuid,

                                                'ServiceRequestId' => 'executeFinacleScript',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'MOM',
                                                'LanguageId' => '',
                                                );
                                                $requestMessageInfo = array(
                                                'BankId' => 'CD',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                                );
                                                $security = array(
                                                'Token' => array(
                                                        'PasswordToken' => array(
                                                        'UserId' => '',
                                                        'Password' => ''
                                                        ),
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                )
                                                );
                                                
                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                $executeFinacleScriptInputVO = array(
                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                        );
                                                
                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;
                                

                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                $tranREQ = array(
                                                    'channelId'=>'MOM',
                                                    'ChannelRefNum'=>$requestuuid,
                                                    'ReversalFlag'=>'N',
                                                    'TranAmount'=>$row["Montant_10"],
                                                    'TranCrncy'=>$row["Devise_11"],
                                                    'RateCode'=>'NOR',
                                                    'DrAcctNo'=>$compte1,
                                                    'DrValueDate'=>date("Y-m-d"),
                                                    'DrForcePostFlag'=>'N',
                                                    'DrTranParticulars'=>$row["Libelle_12"],
                                                    'CrAcctNo'=>$compte2,
                                                    'CrValueDate'=>date("Y-m-d"),
                                                    'CrForcePostFlag'=>'N',
                                                    'CrTranParticulars'=>substr($row['Libelle_12'], 0, 50),
                                                    'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 50),
                                                    'TranParticularsCodeCr'=>'COLL',
                                                );
                                                

                                               

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                
                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                           
                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                                
                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                {

                                                        $responseBody=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];

                                                        //Simulation
                                                        //$responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                                        
                                                        if(isset($responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode']) && $responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        {
                                                                $code = 200;

                                                                $transaction[$code][$i]=$code;

                                                                array_push($transaction_return,$transaction);

                                                                $data_to_save['Num_evenement'] = isset($response['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['OffUsRefNum']) ? $response['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['OffUsRefNum'] : "";
                                                                $data_to_save['code'] = $code;
                                                                $data_to_save['response'] = $code;
                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                $this->finacleModel->update_cbs_instructions_dgda_by_id($row['Sydonia_44']);

                                                                $return = $data_to_save;
                                                                $i++;
                                                        }
                                                        else
                                                        {
                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                {
                                                                        
                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                        {
                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                $data_to_save['code'] = 'E1021';
                                                                                $data_to_save['response'] = 'E1021';
                                                                        } 
                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                        {
                                                                                //Insufficient Balance in Account for Debit    
                                                                                $data_to_save['code'] = 'E1023';
                                                                                $data_to_save['response'] = 'E1023';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1024';
                                                                                $data_to_save['response'] = 'E1024';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1026';
                                                                                $data_to_save['response'] = 'E1026';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                        {
                                                                                //Error in Transaction Creations                
                                                                                $data_to_save['code'] = 'E1027';
                                                                                $data_to_save['response'] = 'E1027';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                        {
                                                                                //Invalid Currency Code                        
                                                                                $data_to_save['code'] = 'E1030';
                                                                                $data_to_save['response'] = 'E1030';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                        {
                                                                                //Currency Code is Null                         
                                                                                $data_to_save['code'] = 'E1031';
                                                                                $data_to_save['response'] = 'E1031';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                        {
                                                                                //Benificiary account number is NULL            
                                                                                $data_to_save['code'] = 'E1032';
                                                                                $data_to_save['response'] = 'E1032';
                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                        {
                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                $data_to_save['code'] = 'E1034';
                                                                                $data_to_save['response'] = 'E1034';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                        {
                                                                                //Payee Account Number is Closed               
                                                                                $data_to_save['code'] = 'E1035';
                                                                                $data_to_save['response'] = 'E1035';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                        {
                                                                                //Error in feedback generation for file         
                                                                                $data_to_save['code'] = 'E1041';
                                                                                $data_to_save['response'] = 'E1041';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                        {
                                                                                //InValid Value Date                           
                                                                                $data_to_save['code'] = 'E1042';
                                                                                $data_to_save['response'] = 'E1042';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                        {
                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                $data_to_save['code'] = 'E1044';
                                                                                $data_to_save['response'] = 'E1044';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                        {
                                                                                //Reroute Placeholder Not Found                
                                                                                $data_to_save['code'] = 'E1045';
                                                                                $data_to_save['response'] = 'E1045';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                        {
                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                $data_to_save['code'] = 'E1046';
                                                                                $data_to_save['response'] = 'E1046';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                        {
                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                $data_to_save['code'] = 'E1047';
                                                                                $data_to_save['response'] = 'E1047';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                        {
                                                                                //Beneficiary Account is Null                   
                                                                                $data_to_save['code'] = 'E1048';
                                                                                $data_to_save['response'] = 'E1048';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                        {
                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                $data_to_save['code'] = 'E1049';
                                                                                $data_to_save['response'] = 'E1049';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                        {
                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                $data_to_save['code'] = 'E1050';
                                                                                $data_to_save['response'] = 'E1050';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                        {
                                                                                //Beneficiary Sortcode is Null                  
                                                                                $data_to_save['code'] = 'E1051';
                                                                                $data_to_save['response'] = 'E1051';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                        {
                                                                                //DEBIT BALANCE LIMIT
                                                                                $data_to_save['code'] = 'E4324';
                                                                                $data_to_save['response'] = 'E4324';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                        {
                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                $data_to_save['code'] = 'E4326';
                                                                                $data_to_save['response'] = 'E4326';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                        {
                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                $data_to_save['code'] = 'E5542';
                                                                                $data_to_save['response'] = 'E5542';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $data_to_save['code'] = 'E000';
                                                                        $data_to_save['response'] = 'E000'; 
                                                                }
                                                        }
                                                        
                                                } 
                                                else 
                                                {

                                                        //Finacle system Error
                                                        $info = json_encode($response);
                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                        $data_to_save['code'] = 'E411';
                                                        $data_to_save['response'] = 'E411';
                                                
                                                       
                                                }


                                        }
                                         
                                        $this->finacleModel->save_bulletins_batch_cbs_return($data_to_save, $data['Sydonia_44']);
                                        $this->finacleModel->update_bulletins_batch_cbs_instructions($transaction_return);
                                        
                                        $result_to_save = json_encode($data_to_save);

                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }

                                if(count($transaction_return)==count($instructions))
                                {
                                    
                                        # Bank fees integration
                                        if(!empty($fees_instructions))
                                        {
                                                $return_bank_charge=$this->virement_bank_charge($data, $fees_instructions);
                                                $code_bank_charge=0;
                                                
                                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                                {
                                                        $code_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                                
                                                if($code_bank_charge==200)
                                                {
                                                        $data_to_save['code'] = 200;
                                                        $data_to_save['response'] = 200;
                                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }
                                                else
                                                {
                                                        $data_to_save['code'] = 300;
                                                        $data_to_save['response'] = 300;
                                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }  
                                                
                                        }
                                    
                                       
                                }
                                elseif(count($transaction_return)<=0)
                                {
                                        $data_to_save['code'] = 400;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Désolé ! la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                $response=$data_to_save;
//                                return json_encode($response);
                                return $response;
                                    
                        }
                }
                else
                {
                        $response['code'] = 405;
                        $response['response'] = 405;
                        $response['message'] = "Missing data in the request";
                        $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        
                        $result_to_save = json_encode($response);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

                        return $response;
                }
        }
        
        public function debit_customer_bulletin_prepayment_integration($data)
        {
                 /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $return = array();
                $data_to_save = array();
                $data_to_send = array();
                $infos = array();
                $status = array();
                $transaction_return = array();
                $failled = array();
                $code = '';
                $i =1;
                $j = 0;
                $type = '';

                /*
                * --------------------------------------------
                * Test all required data
                * --------------------------------------------
                */

                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data["Designation_14"]) || $data["Designation_14"] == "") $failled [] = "The designation is not defined";

                if(count($failled) == 0)
                {
                        if(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA')
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgda_prepayment($data['Sydonia_44'], $data['Priority']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($data['Logirefid_4']);
                        }
                         
                        $exchange_rate = isset($data['Taux_41']) ? $data['Taux_41'] : "";
                        
                        if (!empty($instructions)) 
                        {
                                $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : ""; 
                                $rate_code = isset($infos['rate_code']) ? $infos['rate_code'] : "TTB";
                                

                                foreach ($instructions as $row) 
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);

                                        if ($row["Montant_10"] > 0 && $compte1 !="")  
                                        {
                                                
                                                 ###### the transaction refernce ###################
                                                // $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                                $requestuuid=$data['Logirefid_4']."-".$row['Id_0'];     
                                                $date = date("Y-m-d\TH:i:s.000");

                                                $messageKey = array(
                                                'RequestUUID' =>$requestuuid,

                                                'ServiceRequestId' => 'executeFinacleScript',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'MOM',
                                                'LanguageId' => '',
                                                );
                                                $requestMessageInfo = array(
                                                'BankId' => 'CD',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                                );
                                                $security = array(
                                                'Token' => array(
                                                        'PasswordToken' => array(
                                                        'UserId' => '',
                                                        'Password' => ''
                                                        ),
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                )
                                                );
                                                
                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                $executeFinacleScriptInputVO = array(
                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                        );
                                                
                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;
                                

                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                $tranREQ = array(
                                                    'channelId'=>'MOM',
                                                    'ChannelRefNum'=>$requestuuid,
                                                    'ReversalFlag'=>'N',
                                                    'TranAmount'=>$row["Montant_10"],
                                                    'TranCrncy'=>$row["Devise_11"],
                                                    'RateCode'=>'NOR',
                                                    'DrAcctNo'=>$compte1,
                                                    'DrValueDate'=>date("Y-m-d"),
                                                    'DrForcePostFlag'=>'N',
                                                    'DrTranParticulars'=>$row["Libelle_12"],
                                                    'CrAcctNo'=>$compte2,
                                                    'CrValueDate'=>date("Y-m-d"),
                                                    'CrForcePostFlag'=>'N',
                                                    'CrTranParticulars'=>substr($row['Libelle_12'], 0, 50),
                                                    'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 50),
                                                    'TranParticularsCodeCr'=>'COLL',
                                                );
                                                

                                               

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                
                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                           
                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                                
                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                {

                                                        $responseBody=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];
                                                        //Simulation
                                                        // $responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                                        
                                                        if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        {
                                                                $code = 200;

                                                                $transaction[$code][$i]=$code;

                                                                array_push($transaction_return,$transaction);

                                                                $data_to_save['Num_evenement'] = isset($responseBody['Tran_RES']['OffUsRefNum']) ? $responseBody['Tran_RES']['OffUsRefNum'] : "";
                                                                $data_to_save['code'] = $code;
                                                                $data_to_save['response'] = $code;
                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                $this->finacleModel->update_cbs_instructions_dgda_by_id($row['Sydonia_44']);

                                                                $return = $data_to_save;
                                                                $i++;
                                                        }
                                                        else
                                                        {
                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                {
                                                                        
                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                        {
                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                $data_to_save['code'] = 'E1021';
                                                                                $data_to_save['response'] = 'E1021';
                                                                        } 
                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                        {
                                                                                //Insufficient Balance in Account for Debit    
                                                                                $data_to_save['code'] = 'E1023';
                                                                                $data_to_save['response'] = 'E1023';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1024';
                                                                                $data_to_save['response'] = 'E1024';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1026';
                                                                                $data_to_save['response'] = 'E1026';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                        {
                                                                                //Error in Transaction Creations                
                                                                                $data_to_save['code'] = 'E1027';
                                                                                $data_to_save['response'] = 'E1027';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                        {
                                                                                //Invalid Currency Code                        
                                                                                $data_to_save['code'] = 'E1030';
                                                                                $data_to_save['response'] = 'E1030';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                        {
                                                                                //Currency Code is Null                         
                                                                                $data_to_save['code'] = 'E1031';
                                                                                $data_to_save['response'] = 'E1031';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                        {
                                                                                //Benificiary account number is NULL            
                                                                                $data_to_save['code'] = 'E1032';
                                                                                $data_to_save['response'] = 'E1032';
                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                        {
                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                $data_to_save['code'] = 'E1034';
                                                                                $data_to_save['response'] = 'E1034';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                        {
                                                                                //Payee Account Number is Closed               
                                                                                $data_to_save['code'] = 'E1035';
                                                                                $data_to_save['response'] = 'E1035';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                        {
                                                                                //Error in feedback generation for file         
                                                                                $data_to_save['code'] = 'E1041';
                                                                                $data_to_save['response'] = 'E1041';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                        {
                                                                                //InValid Value Date                           
                                                                                $data_to_save['code'] = 'E1042';
                                                                                $data_to_save['response'] = 'E1042';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                        {
                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                $data_to_save['code'] = 'E1044';
                                                                                $data_to_save['response'] = 'E1044';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                        {
                                                                                //Reroute Placeholder Not Found                
                                                                                $data_to_save['code'] = 'E1045';
                                                                                $data_to_save['response'] = 'E1045';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                        {
                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                $data_to_save['code'] = 'E1046';
                                                                                $data_to_save['response'] = 'E1046';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                        {
                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                $data_to_save['code'] = 'E1047';
                                                                                $data_to_save['response'] = 'E1047';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                        {
                                                                                //Beneficiary Account is Null                   
                                                                                $data_to_save['code'] = 'E1048';
                                                                                $data_to_save['response'] = 'E1048';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                        {
                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                $data_to_save['code'] = 'E1049';
                                                                                $data_to_save['response'] = 'E1049';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                        {
                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                $data_to_save['code'] = 'E1050';
                                                                                $data_to_save['response'] = 'E1050';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                        {
                                                                                //Beneficiary Sortcode is Null                  
                                                                                $data_to_save['code'] = 'E1051';
                                                                                $data_to_save['response'] = 'E1051';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                        {
                                                                                //DEBIT BALANCE LIMIT
                                                                                $data_to_save['code'] = 'E4324';
                                                                                $data_to_save['response'] = 'E4324';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                        {
                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                $data_to_save['code'] = 'E4326';
                                                                                $data_to_save['response'] = 'E4326';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                        {
                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                $data_to_save['code'] = 'E5542';
                                                                                $data_to_save['response'] = 'E5542';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $data_to_save['code'] = 'E000';
                                                                        $data_to_save['response'] = 'E000'; 
                                                                }
                                                        }
                                                        
                                                } 
                                                else 
                                                {

                                                        //Finacle system Error
                                                        $info = json_encode($response);
                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                        $data_to_save['code'] = 'E411';
                                                        $data_to_save['response'] = 'E411';
                                                
                                                       
                                                }

                                        }
                                        
                                         $result_to_save = json_encode($data_to_save);
                                         
                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'], $result_to_save, $data['Sydonia_44']);
                                        $this->finacleModel->update_cbs_instructions_prepayment($transaction_return);
                                        
                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }

                                if(count($transaction_return)==count($instructions))
                                {
                                    
                                        # Bank fees integration
                                        if(!empty($fees_instructions))
                                        {
                                                $return_bank_charge=$this->virement_bank_charge($data, $fees_instructions);
                                                $code_bank_charge=0;
                                                
                                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                                {
                                                        $code_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }

                                                
                                                if($code_bank_charge==200)
                                                {
                                                        $data_to_save['code'] = 200;
                                                        $data_to_save['response'] = 200;
                                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }
                                                else
                                                {
                                                        $data_to_save['code'] = 300;
                                                        $data_to_save['response'] = 300;
                                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }  
                                                
                                        }
                                    
                                       
                                }
                                elseif(count($transaction_return)<=0)
                                {
                                        $data_to_save['code'] = 400;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Désolé ! la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                $response=$data_to_save;
//                                return json_encode($response);
                                return $response;
                                    
                        }
                }
                else
                {
                        $response['code'] = 405;
                        $response['response'] = 405;
                        $response['message'] = "Missing data in the request";
                        $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        
                        $result_to_save = json_encode($response);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

//                        return json_encode($response);
                        return $response;
                }
        }
        
        public function bulletin_single_integration_treatment($data)
        {
                $instructions = $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                        
                if(isset($instructions[0]['Status_2']) && ($instructions[0]['Status_2'] =="4" || $instructions[0]['Status_2'] =="5" || $instructions[0]['Status_2'] =="2"))
                {
                        $lines = array();
                        $i = 1;

                        foreach($instructions as $row)
                        {
                                $lines[$i]['status'] = $row['Status_2'];
                                $lines[$i]['id'] = $row['Id_0'];
                                $lines[$i]['reference'] = $row['Reference_14'];

                                $i++;
                        }

                        if(isset($lines[3]['status']) && $lines[1]['status'] =="1" && $lines[2]['status'] =="1" && $lines[3]['status'] =="1")
                        {
                                $return = $this->debit_customer_bulletin_single_integration($data);

                                if($return['response']=='200')
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1021') 
                                {
                                        //Payer Account Number is Debit/Total Frozen.  
                                        $result['code'] = 'E1021';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1023') 
                                {
                                        //Insufficient Balance in Account for Debit    
                                        $result['code'] = 'E1023';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1024') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1024';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1026') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1026';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1027') 
                                {
                                        //Error in Transaction Creations                
                                        $result['code'] = 'E1027';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1030') 
                                {
                                        //Invalid Currency Code                        
                                        $result['code'] = 'E1030';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1031') 
                                {
                                        //Currency Code is Null                         
                                        $result['code'] = 'E1031';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1032') 
                                {
                                        //Benificiary account number is NULL            
                                        $result['code'] = 'E1032';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1034') 
                                {
                                        //Payee Account Number is Credit/Total Frozen  
                                        $result['code'] = 'E1034';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1035') 
                                {
                                        //Payee Account Number is Closed               
                                        $result['code'] = 'E1035';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1041') 
                                {
                                        //Error in feedback generation for file         
                                        $result['code'] = 'E1041';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1042') 
                                {
                                        //InValid Value Date                           
                                        $result['code'] = 'E1042';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1044') 
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $result['code'] = 'E1044';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1045') 
                                {
                                        //Reroute Placeholder Not Found                
                                        $result['code'] = 'E1045';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1046') 
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $result['code'] = 'E1046';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1047') 
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $result['code'] = 'E1047';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1048') 
                                {
                                        //Beneficiary Account is Null                   
                                        $result['code'] = 'E1048';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1049') 
                                {
                                        //BIC is not found for Beneficiary Bank/Branch  
                                        $result['code'] = 'E1049';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1050') 
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $result['code'] = 'E1050';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1051') 
                                {
                                        //Beneficiary Sortcode is Null                  
                                        $result['code'] = 'E1051';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response']=='300')
                                {
                                        $result['code'] = 'E300';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $result['code'] = 'E411';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur inconnue, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        elseif(isset($lines[1]['status']) && ($lines[1]['status'] =="4" || $lines[1]['status'] =="5"))
                        {
                                $result['code'] = 'E501';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[1]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;

                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais finacle n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[2]['status']) && ($lines[2]['status'] =="4" || $lines[2]['status'] =="5"))
                        {
                                $result['code'] = 'E502';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[2]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && ($lines[3]['status'] =="4" || $lines[3]['status'] =="5"))
                        {
                                $result['code'] = 'E503';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[3]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && $lines[1]['status'] =="2" || $lines[2]['status'] =="2" && $lines[3]['status'] =="2")
                        {
                                # the reservation was successfull.
                                $result['code'] = 'E500';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        return json_encode($result);
                }
                else
                {
                        $return = $this->debit_customer_bulletin_single_integration($data);
                 
                        if($return['response']=='200')
                        {
                                $result['code'] = 'E200';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1021') 
                        {
                                //Payer Account Number is Debit/Total Frozen.  
                                $result['code'] = 'E1021';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1023') 
                        {
                                //Insufficient Balance in Account for Debit    
                                $result['code'] = 'E1023';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1024') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1024';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1026') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1026';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1027') 
                        {
                                //Error in Transaction Creations                
                                $result['code'] = 'E1027';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1030') 
                        {
                                //Invalid Currency Code                        
                                $result['code'] = 'E1030';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1031') 
                        {
                                //Currency Code is Null                         
                                $result['code'] = 'E1031';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1032') 
                        {
                                //Benificiary account number is NULL            
                                $result['code'] = 'E1032';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1034') 
                        {
                                //Payee Account Number is Credit/Total Frozen  
                                $result['code'] = 'E1034';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1035') 
                        {
                                //Payee Account Number is Closed               
                                $result['code'] = 'E1035';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1041') 
                        {
                                //Error in feedback generation for file         
                                $result['code'] = 'E1041';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1042') 
                        {
                                //InValid Value Date                           
                                $result['code'] = 'E1042';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1044') 
                        {
                                //Settlement Outward Credit placeholder Not Found
                                $result['code'] = 'E1044';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1045') 
                        {
                                //Reroute Placeholder Not Found                
                                $result['code'] = 'E1045';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1046') 
                        {
                                //BIC is not found for Correspondence Bank/Branch
                                $result['code'] = 'E1046';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1047') 
                        {
                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                $result['code'] = 'E1047';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1048') 
                        {
                                //Beneficiary Account is Null                   
                                $result['code'] = 'E1048';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1049') 
                        {
                                //BIC is not found for Beneficiary Bank/Branch  
                                $result['code'] = 'E1049';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1050') 
                        {
                                //Bank Code & Branch Code not found for Sortcode
                                $result['code'] = 'E1050';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1051') 
                        {
                                //Beneficiary Sortcode is Null                  
                                $result['code'] = 'E1051';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response']=='300')
                        {
                                $result['code'] = 'E300';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        else
                        {
                                $result['code'] = 'E411';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        $result['logirefid'] = $data['Logirefid_4'];
                        $result['id'] = $data['Sydonia_44'];

                        return json_encode($result);
                }
        }
        
        public function bulletin_batch_integration_treatment($data)
        {
            
                $instructions = $this->finacleModel->get_bulletins_batch_integrations_info($data['Sydonia_44'], $data['Priority']);
                        
                if(isset($instructions[0]['Status_2']) && ($instructions[0]['Status_2'] =="4" || $instructions[0]['Status_2'] =="5" || $instructions[0]['Status_2'] =="2"))
                {
                        $lines = array();
                        $i = 1;

                        foreach($instructions as $row)
                        {
                                $lines[$i]['status'] = $row['Status_2'];
                                $lines[$i]['id'] = $row['Id_0'];
                                $lines[$i]['reference'] = $row['Reference_14'];

                                $i++;
                        }

                        if(isset($lines[3]['status']) && $lines[1]['status'] =="1" && $lines[2]['status'] =="1" && $lines[3]['status'] =="1")
                        {
                                $return = $this->debit_customer_bulletin_batch_integration($data);

                                if($return['response']=='200')
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1021') 
                                {
                                        //Payer Account Number is Debit/Total Frozen.  
                                        $result['code'] = 'E1021';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1023') 
                                {
                                        //Insufficient Balance in Account for Debit    
                                        $result['code'] = 'E1023';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1024') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1024';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1026') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1026';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1027') 
                                {
                                        //Error in Transaction Creations                
                                        $result['code'] = 'E1027';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1030') 
                                {
                                        //Invalid Currency Code                        
                                        $result['code'] = 'E1030';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1031') 
                                {
                                        //Currency Code is Null                         
                                        $result['code'] = 'E1031';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1032') 
                                {
                                        //Benificiary account number is NULL            
                                        $result['code'] = 'E1032';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1034') 
                                {
                                        //Payee Account Number is Credit/Total Frozen  
                                        $result['code'] = 'E1034';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1035') 
                                {
                                        //Payee Account Number is Closed               
                                        $result['code'] = 'E1035';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1041') 
                                {
                                        //Error in feedback generation for file         
                                        $result['code'] = 'E1041';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1042') 
                                {
                                        //InValid Value Date                           
                                        $result['code'] = 'E1042';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1044') 
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $result['code'] = 'E1044';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1045') 
                                {
                                        //Reroute Placeholder Not Found                
                                        $result['code'] = 'E1045';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1046') 
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $result['code'] = 'E1046';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1047') 
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $result['code'] = 'E1047';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1048') 
                                {
                                        //Beneficiary Account is Null                   
                                        $result['code'] = 'E1048';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1049') 
                                {
                                        //BIC is not found for Beneficiary Bank/Branch  
                                        $result['code'] = 'E1049';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1050') 
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $result['code'] = 'E1050';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1051') 
                                {
                                        //Beneficiary Sortcode is Null                  
                                        $result['code'] = 'E1051';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response']=='300')
                                {
                                        $result['code'] = 'E300';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $result['code'] = 'E411';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        elseif(isset($lines[1]['status']) && ($lines[1]['status'] =="4" || $lines[1]['status'] =="5"))
                        {
                                $result['code'] = 'E501';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[1]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;

                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais finacle n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[2]['status']) && ($lines[2]['status'] =="4" || $lines[2]['status'] =="5"))
                        {
                                $result['code'] = 'E502';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[2]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && ($lines[3]['status'] =="4" || $lines[3]['status'] =="5"))
                        {
                                $result['code'] = 'E503';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[3]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && $lines[1]['status'] =="2" || $lines[2]['status'] =="2" && $lines[3]['status'] =="2")
                        {
                                # the reservation was successfull.
                                $result['code'] = 'E500';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        return json_encode($result);
                }
                else
                {
                        $return = $this->debit_customer_bulletin_batch_integration($data);

                        if($return['response']=='200')
                        {
                                $result['code'] = 'E200';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1021') 
                        {
                                //Payer Account Number is Debit/Total Frozen.  
                                $result['code'] = 'E1021';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1023') 
                        {
                                //Insufficient Balance in Account for Debit    
                                $result['code'] = 'E1023';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1024') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1024';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1026') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1026';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1027') 
                        {
                                //Error in Transaction Creations                
                                $result['code'] = 'E1027';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1030') 
                        {
                                //Invalid Currency Code                        
                                $result['code'] = 'E1030';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1031') 
                        {
                                //Currency Code is Null                         
                                $result['code'] = 'E1031';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1032') 
                        {
                                //Benificiary account number is NULL            
                                $result['code'] = 'E1032';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1034') 
                        {
                                //Payee Account Number is Credit/Total Frozen  
                                $result['code'] = 'E1034';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1035') 
                        {
                                //Payee Account Number is Closed               
                                $result['code'] = 'E1035';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1041') 
                        {
                                //Error in feedback generation for file         
                                $result['code'] = 'E1041';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1042') 
                        {
                                //InValid Value Date                           
                                $result['code'] = 'E1042';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1044') 
                        {
                                //Settlement Outward Credit placeholder Not Found
                                $result['code'] = 'E1044';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1045') 
                        {
                                //Reroute Placeholder Not Found                
                                $result['code'] = 'E1045';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1046') 
                        {
                                //BIC is not found for Correspondence Bank/Branch
                                $result['code'] = 'E1046';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1047') 
                        {
                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                $result['code'] = 'E1047';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1048') 
                        {
                                //Beneficiary Account is Null                   
                                $result['code'] = 'E1048';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1049') 
                        {
                                //BIC is not found for Beneficiary Bank/Branch  
                                $result['code'] = 'E1049';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1050') 
                        {
                                //Bank Code & Branch Code not found for Sortcode
                                $result['code'] = 'E1050';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1051') 
                        {
                                //Beneficiary Sortcode is Null                  
                                $result['code'] = 'E1051';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response']=='300')
                        {
                                $result['code'] = 'E300';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        else
                        {
                                $result['code'] = 'E411';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        $result['logirefid'] = $data['Logirefid_4'];
                        $result['id'] = $data['Sydonia_44'];

                        return json_encode($result);
                }
            
        }
        public function bulletin_prepayment_integration_treatment($data)
        {
                 $instructions = $this->finacleModel->get_integrations_info_dgda_prepayment($data['Sydonia_44'], $data['Priority']);
                        
                if(isset($instructions[0]['Status_2']) && ($instructions[0]['Status_2'] =="4" || $instructions[0]['Status_2'] =="5" || $instructions[0]['Status_2'] =="2"))
                {
                        $lines = array();
                        $i = 1;

                        foreach($instructions as $row)
                        {
                                $lines[$i]['status'] = $row['Status_2'];
                                $lines[$i]['id'] = $row['Id_0'];
                                $lines[$i]['reference'] = $row['Reference_14'];

                                $i++;
                        }

                        if(isset($lines[3]['status']) && $lines[1]['status'] =="1" && $lines[2]['status'] =="1" && $lines[3]['status'] =="1")
                        {
                                $return = $this->debit_customer_bulletin_prepayment_integration($data);

                                if($return['response']=='200')
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1021') 
                                {
                                        //Payer Account Number is Debit/Total Frozen.  
                                        $result['code'] = 'E1021';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1023') 
                                {
                                        //Insufficient Balance in Account for Debit    
                                        $result['code'] = 'E1023';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1024') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1024';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1026') 
                                {
                                        //Invalid Amount                               
                                        $result['code'] = 'E1026';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1027') 
                                {
                                        //Error in Transaction Creations                
                                        $result['code'] = 'E1027';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1030') 
                                {
                                        //Invalid Currency Code                        
                                        $result['code'] = 'E1030';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1031') 
                                {
                                        //Currency Code is Null                         
                                        $result['code'] = 'E1031';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1032') 
                                {
                                        //Benificiary account number is NULL            
                                        $result['code'] = 'E1032';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1034') 
                                {
                                        //Payee Account Number is Credit/Total Frozen  
                                        $result['code'] = 'E1034';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1035') 
                                {
                                        //Payee Account Number is Closed               
                                        $result['code'] = 'E1035';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1041') 
                                {
                                        //Error in feedback generation for file         
                                        $result['code'] = 'E1041';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1042') 
                                {
                                        //InValid Value Date                           
                                        $result['code'] = 'E1042';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1044') 
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $result['code'] = 'E1044';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1045') 
                                {
                                        //Reroute Placeholder Not Found                
                                        $result['code'] = 'E1045';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1046') 
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $result['code'] = 'E1046';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1047') 
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $result['code'] = 'E1047';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1048') 
                                {
                                        //Beneficiary Account is Null                   
                                        $result['code'] = 'E1048';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1049') 
                                {
                                        //BIC is not found for Beneficiary Bank/Branch  
                                        $result['code'] = 'E1049';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($return['response'] == 'E1050') 
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $result['code'] = 'E1050';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response'] == 'E1051') 
                                {
                                        //Beneficiary Sortcode is Null                  
                                        $result['code'] = 'E1051';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($return['response']=='300')
                                {
                                        $result['code'] = 'E300';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $result['code'] = 'E411';
                                        $result['id'] = $data['Sydonia_44'];
                                        $result['logirefid'] = $data['Logirefid_4'];
                                        $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
         
                        }
                        elseif(isset($lines[1]['status']) && ($lines[1]['status'] =="4" || $lines[1]['status'] =="5"))
                        {
                                $result['code'] = 'E501';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[1]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;

                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez déjà fait une réservation pour ce bulletin mais finacle n\'avait pas retourné une réponse, veuillez cliquer sur le bouton [vérifier] pour confirmer la réservation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[2]['status']) && ($lines[2]['status'] =="4" || $lines[2]['status'] =="5"))
                        {
                                $result['code'] = 'E502';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[2]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];;
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && ($lines[3]['status'] =="4" || $lines[3]['status'] =="5"))
                        {
                                $result['code'] = 'E503';
                                $result['id'] = $data['Sydonia_44'];
                                $result['transaction_id'] = $lines[3]['id'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais finacle n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif(isset($lines[3]['status']) && $lines[1]['status'] =="2" || $lines[2]['status'] =="2" && $lines[3]['status'] =="2")
                        {
                                # the reservation was successfull.
                                $result['code'] = 'E500';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        return json_encode($result);
                }
                else
                {
                        $return = $this->debit_customer_bulletin_prepayment_integration($data);

                        if($return['response']=='200')
                        {
                                $result['code'] = 'E200';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! le débit du compte du compte du client est fait avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1021') 
                        {
                                //Payer Account Number is Debit/Total Frozen.  
                                $result['code'] = 'E1021';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1023') 
                        {
                                //Insufficient Balance in Account for Debit    
                                $result['code'] = 'E1023';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1024') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1024';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1026') 
                        {
                                //Invalid Amount                               
                                $result['code'] = 'E1026';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1027') 
                        {
                                //Error in Transaction Creations                
                                $result['code'] = 'E1027';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1030') 
                        {
                                //Invalid Currency Code                        
                                $result['code'] = 'E1030';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1031') 
                        {
                                //Currency Code is Null                         
                                $result['code'] = 'E1031';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1032') 
                        {
                                //Benificiary account number is NULL            
                                $result['code'] = 'E1032';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1034') 
                        {
                                //Payee Account Number is Credit/Total Frozen  
                                $result['code'] = 'E1034';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1035') 
                        {
                                //Payee Account Number is Closed               
                                $result['code'] = 'E1035';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1041') 
                        {
                                //Error in feedback generation for file         
                                $result['code'] = 'E1041';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1042') 
                        {
                                //InValid Value Date                           
                                $result['code'] = 'E1042';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1044') 
                        {
                                //Settlement Outward Credit placeholder Not Found
                                $result['code'] = 'E1044';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1045') 
                        {
                                //Reroute Placeholder Not Found                
                                $result['code'] = 'E1045';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1046') 
                        {
                                //BIC is not found for Correspondence Bank/Branch
                                $result['code'] = 'E1046';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1047') 
                        {
                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                $result['code'] = 'E1047';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1048') 
                        {
                                //Beneficiary Account is Null                   
                                $result['code'] = 'E1048';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1049') 
                        {
                                //BIC is not found for Beneficiary Bank/Branch  
                                $result['code'] = 'E1049';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif ($return['response'] == 'E1050') 
                        {
                                //Bank Code & Branch Code not found for Sortcode
                                $result['code'] = 'E1050';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response'] == 'E1051') 
                        {
                                //Beneficiary Sortcode is Null                  
                                $result['code'] = 'E1051';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($return['response']=='300')
                        {
                                $result['code'] = 'E300';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        else
                        {
                                $result['code'] = 'E411';
                                $result['id'] = $data['Sydonia_44'];
                                $result['logirefid'] = $data['Logirefid_4'];
                                $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        $result['logirefid'] = $data['Logirefid_4'];
                        $result['id'] = $data['Sydonia_44'];

                        return json_encode($result);
                }
        }
        
        public function validate_payment_treatment($data)
        {
                # First update the payment status to a pending status
                $data_to_update['Status_2'] = 5;
                $this->finacleModel->update_payment_tresor($data_to_update, $data['Id_0']);

                $return = $this->virement($data);

                if(isset($return['response']) && $return['response'] == '200')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1021')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le compte débiteur est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1023')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le solde du compte débiteur est insuffisant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1024')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1026')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le montant est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1027')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la création de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1030')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1031')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la devise est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1032')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1034')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est gelé ou totallement gelé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1035')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le numéro de compte du bénéficiaire est fermé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1041')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Erreur dans la génération du retour du fichier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1042')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Date de valeur invalide.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1044')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de crédit sortant n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1045')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le placeholder de redirection n\'a pas été trouvé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1046')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1047')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1048')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le compte du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1049')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1050')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E1051')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aDanger text-white">Le code de tri du bénéficiaire est nul.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                elseif(isset($return['response']) && $return['response'] == 'E300')
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aWarning text-white">L\'intégration est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }
                else
                {
                        $result['code'] = 'E411';
                        $result['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $result['id'] = $data['Id_0'];
                }

                return json_encode($result);
        }
   
        public function regularize($data)
        {
            
                /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $return = array();
                $data_to_save = array();
                $data_to_send = array();
                $infos = array();
                $status = array();
                $newdata=array();
                $transaction_return = array();
                $failled = array();
                $event_number=null;
                $code = '';
                $i =1;
                $j = 0;
                $type='';


                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */

                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data["Designation_14"]) || $data["Designation_14"] == "") $failled [] = "The designation is not defined";
                if(!isset($data["Id_0"]) || $data['Id_0'] == "") $failled[] = 'Data Paiementid is empty';


                if(count($failled) == 0)
                {
                        if(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['Type']) && $data['Type'] == "prepayment")
                                {
                                        $type='prepayment';
                                        // Integration to regulate
                                        $instructions = $this->finacleModel->get_prepayment_integrations_by_id($data['Id_0']);
                                        
                                        // Old CBS returns to update
                                        $cbs_returns = $this->finacleModel->get_prepayment_cbs_returns_by_paiementid($data['Sydonia_49']);
                                }
                                else
                                {
                                        // Integration to reverse
                                        $instructions = $this->finacleModel->get_integrations_dgda_by_id($data['Id_0']);

                                // Old CBS returns to update
                                        $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Sydonia_44'], $data['Beneficaire_15']);
                                }
                        }
                        elseif(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGI') 
                        {
                                // Integration to reverse
                                $instructions = $this->finacleModel->get_integrations_dgi_by_id($data['Id_0']);

                                // Old CBS returns to update
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                        }
                        elseif(isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGRAD') 
                        {
                                // Integration to reverse
                                $instructions = $this->finacleModel->get_integrations_dgrad_by_id($data['Id_0']);
                                // Old CBS returns to update
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], $data['Beneficaire_15']);
                        }
                        
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGI') 
                        {
//                                $instructions = $this->finacleModel->get_integrations_info_dgi($data['Logirefid_4']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees($data['Logirefid_4']);
                                $fees_bcc_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees_bcc($data['Logirefid_4']);
                        } 
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGRAD') 
                        {
//                                $instructions = $this->finacleModel->get_integrations_info_dgrad($data['Logirefid_4']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees($data['Logirefid_4']);
                                $fees_bcc_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees_bcc($data['Logirefid_4']);
                        }

                        

                        if (!empty($instructions)) 
                        {
                                $infos = isset($data['Notereference_30']) ? json_decode($data['Notereference_30'], true) : ""; 
                                $rate_code = isset($infos['rate_code']) ? $infos['rate_code'] : "TTB";

                                foreach ($instructions as $row) 
                                {
                                        $compte1 = str_replace('-', '', $row["Compte_9"]);
                                        $compte2 = str_replace('-', '', $row["Compte_13"]);

                                        if ($row["Montant_10"] > 0 && $compte1 !="")  
                                        {

                                                // $requestuuid = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                                $requestuuid=$data['Logirefid_4']."-".$row['Id_0'];
                                                $date = date("Y-m-d H:i:s");

                                                $messageKey = array(
                                                'RequestUUID' =>$requestuuid,

                                                'ServiceRequestId' => 'executeFinacleScript',
                                                'ServiceRequestVersion' => '10.2',
                                                'ChannelId' => 'MOM',
                                                'LanguageId' => '',
                                                );
                                                $requestMessageInfo = array(
                                                'BankId' => 'CD',
                                                'TimeZone' => '',
                                                'EntityId' => '',
                                                'EntityType' => '',
                                                'ArmCorrelationId' => '',
                                                'MessageDateTime' => $date
                                                );
                                                $security = array(
                                                'Token' => array(
                                                        'PasswordToken' => array(
                                                        'UserId' => '',
                                                        'Password' => ''
                                                        ),
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                )
                                                );
                                                
                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                $executeFinacleScriptInputVO = array(
                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                        );
                                                
                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;
                                

                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                $tranREQ = array(
                                                    'channelId'=>'MOM',
                                                    'ChannelRefNum'=>$requestuuid,
                                                    'ReversalFlag'=>'N',
                                                    'TranAmount'=>$row["Montant_10"],
                                                    'TranCrncy'=>$row["Devise_11"],
                                                    'RateCode'=>'NOR',
                                                    'DrAcctNo'=>$compte1,
                                                    'DrValueDate'=>date("Y-m-d"),
                                                    'DrForcePostFlag'=>'N',
                                                    'DrTranParticulars'=>$row["Libelle_12"],
                                                    'CrAcctNo'=>$compte2,
                                                    'CrValueDate'=>date("Y-m-d"),
                                                    'CrForcePostFlag'=>'N',
                                                    'CrTranParticulars'=>substr($row['Libelle_12'], 0, 50),
                                                    'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 50),
                                                    'TranParticularsCodeCr'=>'COLL',
                                                );
                                                

                                               

                                                $data_to_send['Header'] = $requestHeader;
                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                
                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                           
                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                                
                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                {

                                                        $responseBody=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];
                                                        //Simulation
                                                        //$responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                                        
                                                        if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                        {
                                                                $code = 200;
                                                                // var_dump($row['Id_0']);
                                                                $transaction[$i]=$code;
                                                                
                                                                array_push($transaction_return,$transaction);
                                                                
                                                                $data_to_save['Num_evenement'] = isset($responseBody['Tran_RES']['TransactionId']) ? $responseBody['Tran_RES']['TransactionId'] : "";
                                                                $data_to_save['code'] = $code;
                                                                $data_to_save['response'] = $code;
                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                if($data['Beneficaire_15'] == 'DGI')
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgi_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGRAD')
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgrad_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGDA' && $type != "prepayment")
                                                                {
                                                                        $this->finacleModel->update_cbs_instructions_dgda_by_id($row['Id_0']);
                                                                }
                                                                elseif($data['Beneficaire_15'] == 'DGDA' && $type == "prepayment")
                                                                {
                                                                        $this->finacleModel->update_cbs_prepayments_instructions_dgda($row['Sydonia_49']);
                                                                }
                                                                $return = $data_to_save;
                                                                $i++;
                                                        }
                                                        else
                                                        {
                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                {
                                                                        
                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                        {
                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                $data_to_save['code'] = 'E1021';
                                                                                $data_to_save['response'] = 'E1021';
                                                                        } 
                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                        {
                                                                                //Insufficient Balance in Account for Debit    
                                                                                $data_to_save['code'] = 'E1023';
                                                                                $data_to_save['response'] = 'E1023';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1024';
                                                                                $data_to_save['response'] = 'E1024';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                        {
                                                                                //Invalid Amount                               
                                                                                $data_to_save['code'] = 'E1026';
                                                                                $data_to_save['response'] = 'E1026';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                        {
                                                                                //Error in Transaction Creations                
                                                                                $data_to_save['code'] = 'E1027';
                                                                                $data_to_save['response'] = 'E1027';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                        {
                                                                                //Invalid Currency Code                        
                                                                                $data_to_save['code'] = 'E1030';
                                                                                $data_to_save['response'] = 'E1030';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                        {
                                                                                //Currency Code is Null                         
                                                                                $data_to_save['code'] = 'E1031';
                                                                                $data_to_save['response'] = 'E1031';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                        {
                                                                                //Benificiary account number is NULL            
                                                                                $data_to_save['code'] = 'E1032';
                                                                                $data_to_save['response'] = 'E1032';
                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                        {
                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                $data_to_save['code'] = 'E1034';
                                                                                $data_to_save['response'] = 'E1034';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                        {
                                                                                //Payee Account Number is Closed               
                                                                                $data_to_save['code'] = 'E1035';
                                                                                $data_to_save['response'] = 'E1035';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                        {
                                                                                //Error in feedback generation for file         
                                                                                $data_to_save['code'] = 'E1041';
                                                                                $data_to_save['response'] = 'E1041';
                                                                        } 
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                        {
                                                                                //InValid Value Date                           
                                                                                $data_to_save['code'] = 'E1042';
                                                                                $data_to_save['response'] = 'E1042';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                        {
                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                $data_to_save['code'] = 'E1044';
                                                                                $data_to_save['response'] = 'E1044';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                        {
                                                                                //Reroute Placeholder Not Found                
                                                                                $data_to_save['code'] = 'E1045';
                                                                                $data_to_save['response'] = 'E1045';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                        {
                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                $data_to_save['code'] = 'E1046';
                                                                                $data_to_save['response'] = 'E1046';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                        {
                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                $data_to_save['code'] = 'E1047';
                                                                                $data_to_save['response'] = 'E1047';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                        {
                                                                                //Beneficiary Account is Null                   
                                                                                $data_to_save['code'] = 'E1048';
                                                                                $data_to_save['response'] = 'E1048';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                        {
                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                $data_to_save['code'] = 'E1049';
                                                                                $data_to_save['response'] = 'E1049';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                        {
                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                $data_to_save['code'] = 'E1050';
                                                                                $data_to_save['response'] = 'E1050';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                        {
                                                                                //Beneficiary Sortcode is Null                  
                                                                                $data_to_save['code'] = 'E1051';
                                                                                $data_to_save['response'] = 'E1051';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                        {
                                                                                //DEBIT BALANCE LIMIT
                                                                                $data_to_save['code'] = 'E4324';
                                                                                $data_to_save['response'] = 'E4324';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                        {
                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                $data_to_save['code'] = 'E4326';
                                                                                $data_to_save['response'] = 'E4326';
                                                                        }
                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                        {
                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                $data_to_save['code'] = 'E5542';
                                                                                $data_to_save['response'] = 'E5542';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $data_to_save['code'] = 'E000';
                                                                        $data_to_save['response'] = 'E000'; 
                                                                }
                                                        }
                                                        
                                                } 
                                                else 
                                                {

                                                        //Finacle system Error
                                                        $info = json_encode($response);
                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                        $data_to_save['code'] = 'E411';
                                                        $data_to_save['response'] = 'E411';
                                                
                                                       
                                                }


                                        }
                                        
                                }

                                if(count($transaction_return)==count($instructions))
                                {
                                    
                                        # Bank fees integration
                                        if(!empty($fees_instructions))
                                        {
                                                $return_bank_charge=$this->virement_bank_charge($data, $fees_instructions);
                                                $code_bank_charge=0;
                                                $code_bcc_bank_charge=0;
                                                
                                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                                {
                                                        $code_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                       
                                                $return_bcc_bank_charge=$this->virement_bcc_bank_charge($data, $fees_bcc_instructions);
                                                
                                                if(isset($return_bcc_bank_charge['code']) && $return_bcc_bank_charge['code']==200)
                                                {
                                                        $code_bcc_bank_charge=200;
                                                        $bank_charges=$return_bank_charge['bankCharges'];
                                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                                }
                                                
                                                if($code_bank_charge==200 && $code_bcc_bank_charge==200)
                                                {
                                                        $data_to_save['code'] = 200;
                                                        $data_to_save['response'] = 200;
                                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }
                                                else
                                                {
                                                        $data_to_save['code'] = 300;
                                                        $data_to_save['response'] = 300;
                                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                }  
                                                
                                        }
                                    
                                       
                                }
                                elseif(count($transaction_return)<=0)
                                {
                                        $data_to_save['code'] = 400;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Désolé ! la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = $return['response'];
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                
                                if(isset($cbs_returns[0]['Result_6']) && $cbs_returns[0]['Result_6'] !="")
                                {
                                        $olddata = json_decode($cbs_returns[0]['Result_6'], true);

                                        foreach($olddata as $key => $value):

                                                if($key == $data['Id_0'] && $code =='200'):
                                                        $newdata[$key]['Num_evenement'] = $event_number;
                                                        $newdata[$key]['code'] = $code;
                                                else:
                                                        if(isset($value['Num_evenement']) && $value['Num_evenement'] !=""):
                                                                if(isset($value['Num_evenement']))$newdata[$key]['Num_evenement'] = $value['Num_evenement'];
                                                                if(isset($value['code'])) $newdata[$key]['code'] = $value['code'];
                                                        endif;
                                                endif;
                                        endforeach;
                                }

                                if($data['Beneficaire_15']=='DGDA')
                                {
                                        if(isset($newdata))
                                        {
                                                if(isset($data['Type']) && $data['Type'] == "prepayment"):
                                                        $pid = $this->finacleModel->update_prepayment_return($newdata, $data['Sydonia_49']);
                                                else:
                                                        $pid = $this->finacleModel->update_return($newdata, $data['Sydonia_44'], $data['Beneficaire_15']);
                                                endif;
                                        }
                                }
                                else
                                {
                                        if(isset($newdata))
                                        {
                                                $pid = $this->finacleModel->update_return($newdata, $data['Paiementid_4'], $data['Beneficaire_15']);
                                        }
                                }

                                $result_to_save = json_encode($newdata);

                                $this->finacleModel->save_log("Resultat final: ".$result_to_save, "virement");

                                return $newdata;
                                    
                        }
                        else
                        {
                                $return['code'] = 405;
                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "regularisation");

                                return $return;
                        }  
                }
                else
                {
                        $data_to_save['response'] = 405;
                        $result_to_save = json_encode($data_to_save);

                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

                        return $data_to_save;
                }
        }
        
        public function regularize_payment_treatment($data)
        {
                /*
                 * ------------------------------------------------
                 * Variable initialization
                 * ------------------------------------------------
                 */
                 $obj = isset($data['object']) ? $data['object'] : '';
                 $id = isset($data['transactionid']) ? $data['transactionid'] : '';
                 $logirefid = '';
                 $paiementid = '';

                 if($obj == "declaration")
                 {
                         $data = [];

                         $data['Id_0'] = $_POST['transactionid'];
                         $data['Account_3'] = $this->session->userdata['account_id'];
                         $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                         $data['Logirefid_4'] = $logirefid = $_POST['reference'].$id;
                         $data['Designation_14'] = $_POST['designation'];
                         $data['Beneficaire_15'] = $_POST['regie'];

                         // Forcage de l'ecriture
                         if($_POST['action'] == "forcing")
                         {
                                #Invocation of the api transfer
                                $result = $this->regularize($data);

                                $succes = [];
                                $return = [];
                                $return['validate'] = false;

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $return['response'] = 'E200';
                                        $return['msg'] = '<div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($result['response']=='E1021')
                                {
                                        //Payer Account Number is Debit/Total Frozen.
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte débiteur est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1023')
                                {
                                        //Insufficient Balance in Account for Debit
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le solde du compte débiteur est insuffisant<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1024')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1026')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1027')
                                {
                                        //Error in Transaction Creations
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la création de la transaction<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1030')
                                {
                                        //Invalid Currency Code
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1031')
                                {
                                        //Currency Code is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1032')
                                {
                                        //Benificiary account number is NULL
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1034')
                                {
                                        //Payee Account Number is Credit/Total Frozen
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1035')
                                {
                                        //Payee Account Number is Closed
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est fermé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1041')
                                {
                                        //Error in feedback generation for file
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la génération du retour du fichier<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1042')
                                {
                                        //InValid Value Date
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">La date de valeur est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1044')
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de crédit sortant n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1045')
                                {
                                        //Reroute Placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de redirection n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1046')
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1047')
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1048')
                                {
                                        //Beneficiary Account is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1049')
                                {
                                        //BIC is not found for Beneficiary Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1050')
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1051')
                                {
                                        //Beneficiary Sortcode is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de tri du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E300')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">L\'écriture n\'est pas intégrée d&ucirc; à un problème de connexion, veuillez cliquer sur le bouton vérifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $return['response'] = "E".$result['response'];
                                        $return['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }

                                 
                                 // check if all integrations  are integrated with success
                                 $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                 foreach($instructions as $value):
                                 $succes[] = $value->Status_2; 
                                 endforeach;

                                 if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                 {
                                         $return['validate'] = true;
                                 }

                                 echo json_encode($return);
                                 die;

                         }  
                         elseif($_POST['action'] == "reverse")
                         {
                                 #Invocation of the api transfer
                                //  $result = $this->extourne($data);

                                //  $succes = array();
                                //  $return = array();
                                //  $return['delete'] = false;

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 1;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }

                                //  // check if all integrations  are integrated with success
                                //  $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                //  foreach($instructions as $value):
                                //  $succes[] = $value->Status_2; 
                                //  endforeach;

                                //  if(in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes))  
                                //  {
                                //          $return['validate'] = true;
                                //  }

                                //  if(!in_array('2', $succes)) 
                                //  {
                                //          $return['delete'] = true;
                                //  }

                                //  echo json_encode($return);
                                //  die;
                         }
                         elseif($_POST['action'] == "verify")
                         {    
                                //  #Invocation of the api transfer
                                //  $result = $this->check_transaction($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 2;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 4;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans finacle veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 4;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 4;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 4;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 4;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }

                                //  if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                //  {
                                //          $return['validate'] = true;
                                //  }
                                //  if(!in_array('2', $succes)) 
                                //  {
                                //          $return['delete'] = true;
                                //  }

                                //  echo json_encode($return);
                                //  die;
                         }

                 }
                 elseif($obj == "note")
                 {
                         $data = array();
                         $data['Id_0'] = $_POST['transactionid'];
                         $data['Account_3'] = $this->session->userdata['account_id'];
                         $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                         $data['Logirefid_4'] = $logirefid = $_POST['reference'].$id;
                         $data['Designation_14'] = $_POST['designation'];
                         $data['Beneficaire_15'] = $_POST['regie'];

                         // Forcage de l'ecriture
                         if($_POST['action'] == "forcing")
                         {
                                #Invocation of the api transfer
                                $result = $this->regularize($data);

                                $succes = array();
                                $return = array();
                                $return['validate'] = false;

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $return['response'] = 'E200';
                                        $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                }
                                elseif($result['response']=='E1021')
                                {
                                        //Payer Account Number is Debit/Total Frozen.
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte débiteur est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1023')
                                {
                                        //Insufficient Balance in Account for Debit
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le solde du compte débiteur est insuffisant<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1024')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1026')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1027')
                                {
                                        //Error in Transaction Creations
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la création de la transaction<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1030')
                                {
                                        //Invalid Currency Code
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1031')
                                {
                                        //Currency Code is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1032')
                                {
                                        //Benificiary account number is NULL
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1034')
                                {
                                        //Payee Account Number is Credit/Total Frozen
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1035')
                                {
                                        //Payee Account Number is Closed
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est fermé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1041')
                                {
                                        //Error in feedback generation for file
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la génération du retour du fichier<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1042')
                                {
                                        //InValid Value Date
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">La date de valeur est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1044')
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de crédit sortant n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1045')
                                {
                                        //Reroute Placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de redirection n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1046')
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1047')
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1048')
                                {
                                        //Beneficiary Account is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1049')
                                {
                                        //BIC is not found for Beneficiary Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1050')
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1051')
                                {
                                        //Beneficiary Sortcode is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de tri du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E300')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">L\'écriture n\'est pas intégrée d&ucirc; à un problème de connexion, veuillez cliquer sur le bouton vérifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $return['response'] = "E".$result['response'];
                                        $return['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }


                                 // check if all integrations  are integrated with success
                                 $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                 foreach($instructions as $value):
                                 $succes[] = $value->Status_2; 
                                 endforeach;

                                 if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                 {
                                         $return['validate'] = true;
                                 }
                                 echo json_encode($return);
                                 die;

                         }  
                         elseif($_POST['action'] == "reverse")
                         {
                                //  #Invocation of the api transfer
                                //  $result = $this->extourne($data);

                                //  $succes = array();
                                //  $return = array();
                                //  $return['delete'] = false;

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 1;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  // check if all integrations  are integrated with success
                                //  $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                //  foreach($instructions as $value):
                                //  $succes[] = $value->Status_2; 
                                //  endforeach;

                                //  if(!in_array('3', $succes) || !in_array('1', $succes) || !in_array('4', $succes))  
                                //  {
                                //          $return['validate'] = true;
                                //  }

                                //  if(!in_array('2', $succes)) 
                                //  {
                                //          $return['delete'] = true;
                                //  }
                                //  echo json_encode($return); die;
                         }
                         elseif($_POST['action'] == "verify")
                         {       
                                //  #Invocation of the api transfer
                                //  $result = $this->check_transaction($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 2;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans finacle veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }

                                //  if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                //  {
                                //          $return['validate'] = true;
                                //  }
                                //  if(!in_array('2', $succes)) 
                                //  {
                                //          $return['delete'] = true;
                                //  }

                                //  echo json_encode($return);
                                //  die;
                         }
                 }
                 elseif($obj == "bulletin")
                 {
                         $data['Priority'] = 1;
                         $data['Id_0'] = $_POST['transactionid'];
                         $data['Account_3'] = $this->session->userdata['account_id'];
                         $data['Logirefid_4'] = $_POST['reference'].$id;
                         $data['Designation_14'] = $_POST['designation'];
                         $data['Beneficaire_15'] = $_POST['regie'];
                         $data['Sydonia_44'] = $paiementid = $_POST['paiementid'];

                         // Forcage de l'ecriture
                         if($_POST['action'] == "forcing")
                         {
                                 $this->historicize_regularisations($id, $_POST['action']);

                                 #Invocation of the api transfer
                                 $result = $this->regularize($data);

                                 $succes = array();
                                 $return = array();
                                 $return['validate'] = false;

                                 if($result['response'] == '200')
                                 {
                                         $data = array();
                                         $data['Status_2'] = 2;
                                         $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                         $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                         $return['response'] = 'E200';
                                         $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                 }
                                 elseif($result['response']=='E1021')
                                {
                                        //Payer Account Number is Debit/Total Frozen.
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte débiteur est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1023')
                                {
                                        //Insufficient Balance in Account for Debit
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le solde du compte débiteur est insuffisant<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1024')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1026')
                                {
                                        //Invalid Amount
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le montant de l\'écriture est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1027')
                                {
                                        //Error in Transaction Creations
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la création de la transaction<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1030')
                                {
                                        //Invalid Currency Code
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1031')
                                {
                                        //Currency Code is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la devise est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1032')
                                {
                                        //Benificiary account number is NULL
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1034')
                                {
                                        //Payee Account Number is Credit/Total Frozen
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est gelé ou total gelé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1035')
                                {
                                        //Payee Account Number is Closed
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le numéro de compte du bénéficiaire est fermé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1041')
                                {
                                        //Error in feedback generation for file
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Erreur dans la génération du retour du fichier<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1042')
                                {
                                        //InValid Value Date
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">La date de valeur est invalide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1044')
                                {
                                        //Settlement Outward Credit placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de crédit sortant n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1045')
                                {
                                        //Reroute Placeholder Not Found
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le placeholder de redirection n\'a pas été trouvé<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1046')
                                {
                                        //BIC is not found for Correspondence Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche de correspondance<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1047')
                                {
                                        //Default Correspondence Bank/Branch details is not maintained for Currency
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1048')
                                {
                                        //Beneficiary Account is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le compte du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1049')
                                {
                                        //BIC is not found for Beneficiary Bank/Branch
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le BIC n\'a pas été trouvé pour la banque/branche du bénéficiaire<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1050')
                                {
                                        //Bank Code & Branch Code not found for Sortcode
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de la banque et le code de la branche n\'ont pas été trouvés pour le code de tri<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E1051')
                                {
                                        //Beneficiary Sortcode is Null
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">Le code de tri du bénéficiaire est vide<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                elseif($result['response']=='E300')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $return['response'] = "E".$result['response'];

                                        $return['msg'] = '<div class="alert aWarning text-white">L\'écriture n\'est pas intégrée d&ucirc; à un problème de connexion, veuillez cliquer sur le bouton vérifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                        $return['response'] = "E".$result['response'];
                                        $return['msg'] = '<div class="alert aDanger text-white">Problème de connexion avec Finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgda($paiementid);

                                foreach($instructions as $value):
                                $succes[] = $value->Status_2; 
                                endforeach;

                                if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                {
                                        $return['validate'] = true;
                                }
                                echo json_encode($return);
                                die;

                         }  
                         elseif($_POST['action'] == "reverse")
                         {
                                //  $this->historicize_regularisations($id, $_POST['action']);

                                //  #Invocation of the api transfer
                                //  $result = $this->extourne($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 1;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                //          $return['response'] = "E".$result['response'];

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; finacle avec succ&egrave;s mais il y a eu aucun retour d\'finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }

                                //  echo json_encode($return);
                                //  die;
                         }
                         elseif($_POST['action'] == "verify")
                         {   
                                //  #Invocation of the api transfer
                                //  $result = $this->check_transaction($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 2;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E200';
                                //          $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E300';
                                //          $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n\'est pas int&eacute;gr&eacute;e dans finacle veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '404')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E404';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '411')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                //          $return['response'] = 'E411';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  elseif($result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = 'E405';
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //          $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                                //  }

                                //  echo json_encode($return);
                                //  die;
                         }
                 }
                 elseif($obj == "prepayment")
                 {
                         $data['Priority'] = 1;
                         $data['Id_0'] = $_POST['transactionid'];
                         $data['Account_3'] = $this->session->userdata['account_id'];
                         $data['Logirefid_4'] = $_POST['reference'].$id;
                         $data['Designation_14'] = $_POST['designation'];
                         $data['Beneficaire_15'] = $_POST['regie'];
                         $data['Sydonia_49'] = $paiementid = $_POST['paiementid'];
                         $data['Type'] = 'prepayment';

                         // Forcage de l'ecriture
                         if($_POST['action'] == "forcing")
                         {
                                 $this->save('regularisation', $id, $_POST['action']);

                                 $succes = array();
                                 $return = array();
                                 $return['validate'] = false;

                                 #Invocation of the api transfer
                                 $result = $this->regularize($data);

                                 if($result['response'] == '200')
                                 {
                                         $data = array();
                                         $data['Status_2'] = 2;
                                         $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                         $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                         $return['response'] = "E200";

                                 }
                                 elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                 {
                                         $data = array();
                                         $data['Status_2'] = 5;
                                         $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                         $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                         $return['response'] = "E".$result['response'];
                                 }
                                 else 
                                 {
                                         $data = array();
                                         $data['Status_2'] = 5;
                                         $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                         $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                         $return['response'] = "E".$result['response'];
                                 }

                                 // check if all integrations  are integrated with success
                                 $instructions  = $this->comptabilisationModel->get_prepayment_instructions($paiementid);
                                 foreach($instructions as $value):
                                         $succes[] = $value->Status_2; 
                                 endforeach;

                                 if(!in_array('3', $succes) && !in_array('1', $succes))  
                                 {
                                         $return['validate'] = true;
                                 }
                                 echo json_encode($return);
                                 die;

                         }  
                         elseif($_POST['action'] == "reverse")
                         {
                                //  $this->save('regularisation', $id, $_POST['action']);

                                //  #Invocation of the api transfer
                                //  $result = $this->extourne($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 1;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E200";

                                //  }
                                //  elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //  }
                                //  else
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //  }
                                //  // check if all integrations  are integrated with success
                                //  $instructions  = $this->comptabilisationModel->get_prepayment_instructions($paiementid);
                                //  foreach($instructions as $value):
                                //  $succes[] = $value->Status_2; 
                                //  endforeach;

                                //  echo json_encode($return);
                                //  die;
                         }
                         elseif($_POST['action'] == "verify")
                         {       
                                //  #Invocation of the api transfer
                                //  $result = $this->check_transaction($data);

                                //  $succes = array();
                                //  $return = array();

                                //  if($result['response'] == '200')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 2;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E200";
                                //  }
                                //  elseif($result['response'] == '300')
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 3;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //  }
                                //  elseif($result['response'] == '411' || $result['response'] == '405') 
                                //  {
                                //          $data = array();
                                //          $data['Status_2'] = 5;
                                //          $data['Checkerid_17'] = $this->session->userdata["user_id"];
                                //          $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                //          $return['response'] = "E".$result['response'];
                                //  }
                                //  echo json_encode($return);
                                //  die;
                         }
                 }
        }

        public function verify_transaction_bulletin($data)
        {

                $status = array();
                $transaction_return = array();
                $failled = array();
                $code = '';
                $i =1;

                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data['Logirefid_4']) || $data['Logirefid_4'] == "") $failled [] = "The logiref id is not defined";
                if(!isset($data['Compte_33']) || $data['Compte_33'] == "") $failled [] = "The designation is not defined";

                if(count($failled)==0)
                {

                        if($data['Beneficaire_15'] == "DGDA")
                        {
                                if(isset($data['Type']) && $data['Type'] == 'prepayment')
                                {
                                        // get only prepayments integrations 
                                        $instructions = $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_49'], $data['Priority']);
                                }
                                else
                                {
                                        $instructions = $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                                }
                        }
                        $account = $data['Compte_33'];

                        if(!empty($instructions))
                        {
                               foreach($instructions as $row)
                                {
                                        $id = $row->Id_0;

                                        $date = date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
                                        $transaction_ref=$data['Logirefid_4']."-".$id;

                                        // Construction de la structure de base
                                        $data_to_send = [
                                        'Header' => [
                                                'RequestHeader' => [
                                                'MessageKey' => [
                                                        'RequestUUID' => $transaction_ref,
                                                        'ServiceRequestId' => 'executeFinacleScript',
                                                        'ServiceRequestVersion' => '10.2',
                                                        'ChannelId' => 'MOM',
                                                        'LanguageId' => ''
                                                ],
                                                'RequestMessageInfo' => [
                                                        'BankId' => 'CD',
                                                        'TimeZone' => '',
                                                        'EntityId' => '',
                                                        'EntityType' => '',
                                                        'ArmCorrelationId' => '',
                                                        'MessageDateTime' => $date
                                                ],
                                                'Security' => [
                                                        'Token' => [
                                                        'PasswordToken' => [
                                                                'UserId' => '',
                                                                'Password' => ''
                                                        ]
                                                        ],
                                                        'FICertToken' => '',
                                                        'RealUserLoginSessionId' => '',
                                                        'RealUser' => '',
                                                        'RealUserPwd' => '',
                                                        'SSOTransferToken' => ''
                                                ]
                                                ]
                                        ],
                                        'Body' => [
                                                'executeFinacleScriptRequest' => [
                                                'ExecuteFinacleScriptInputVO' => [
                                                        'requestId' => 'FullStmtwithVAT_mn001.scr'
                                                ],
                                                'executeFinacleScript_CustomData' => [
                                                        'TranCriteria' => [
                                                        'acctNum' => $account,
                                                        'fromDate' => '01-10-2015',
                                                        'toDate' => gmdate('d-m-Y'),
                                                        'txnType' => 'C',
                                                        'sortIn' => 'D'
                                                        ]
                                                ]
                                                ]
                                        ]
                                        ];
                                        
                                        $response = $this->finacleModel->account_info($data_to_send, $transaction_ref, $date);


                                        if(isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']) && isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls']))
                                        {
                                                // $transaction = array_search($transaction_ref,$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['tranDtls']['txnId']) ;
                                                
                                                $transaction=true;

                                                if($transaction !== false)
                                                {
                                                        $code = 200;
                                                        $transaction_return[$code][$i] = $instructions[0]["Id_0"];
                                                }
                                                else
                                                {
                                                        $code = 300;
                                                        $transaction_return[$code][$i] = $instructions[0]["Id_0"];
                                                }

                                                if($code == 200)
                                                {
                                                        # update the status of the transaction
                                                        $this->finacleModel->update_cbs_instructions_dgda($transaction_return);
                                                }

                                                $i++;

                                                $instructions_regul = $this->finacleModel->get_integrations_info_dgda_to_regularize($data['Sydonia_44'], $data['Priority']);
                                                $cbs_data = $this->finacleModel->get_cbs_returns_by_paiementid($data['Sydonia_44'], $data['Beneficaire_15']); 

                                                if(isset($cbs_data[0]['Result_6']) && $cbs_data[0]['Result_6'] != "")
                                                {
                                                        $cbs_data = json_decode($cbs_data[0]['Result_6'], true);
                                                        $data_to_save = $cbs_data;
                                                }

                                                if(!empty($instructions_regul))
                                        {
                                                # Initialize the array $transaction_return
                                                $transaction_return = array();

                                                foreach ($instructions_regul as $row)
                                                {
                                                        if($row['Montant_10'] > 0)
                                                        {
                                                                $row['Libelle_12']= $this->remove_all_special_characters($row['Libelle_12']);

                                                                $requestuuid = $row['Logirefid_4']."-".$row['Id_0'];
                                                                
                                                                $compte1 = $row['Compte_9'];
                                                                $compte2 = $row['Compte_13'];
                                                                
                                                                $messageKey = array(
                                                                'RequestUUID' =>$requestuuid,
                                                                'ServiceRequestId' => 'executeFinacleScript',
                                                                'ServiceRequestVersion' => '10.2',
                                                                'ChannelId' => 'MOM',
                                                                'LanguageId' => '',
                                                                );
                                                                $requestMessageInfo = array(
                                                                'BankId' => 'CD',
                                                                'TimeZone' => '',
                                                                'EntityId' => '',
                                                                'EntityType' => '',
                                                                'ArmCorrelationId' => '',
                                                                'MessageDateTime' => $date
                                                                );
                                                                $security = array(
                                                                        'Token' => array(
                                                                                'PasswordToken' => array(
                                                                                'UserId' => '',
                                                                                'Password' => ''
                                                                                ),
                                                                                'FICertToken' => '',
                                                                                'RealUserLoginSessionId' => '',
                                                                                'RealUser' => '',
                                                                                'RealUserPwd' => '',
                                                                                'SSOTransferToken' => ''
                                                                        )
                                                                );
                                                                
                                                                $requestHeader['RequestHeader']['MessageKey'] = $messageKey;
                                                                $requestHeader['RequestHeader']['RequestMessageInfo'] = $requestMessageInfo;
                                                                $requestHeader['RequestHeader']['Security'] = $security;

                                                                $executeFinacleScriptInputVO = array(
                                                                                                'requestId'=>'PaymentCollectionOnline_mn001.scr'
                                                                                        );
                                                                
                                                                $executeFinacleScriptRequest['ExecuteFinacleScriptInputVO']=$executeFinacleScriptInputVO;

                                                                $row["Libelle_12"] = $this->remove_all_special_characters($row["Libelle_12"]);

                                                                $tranREQ = array(
                                                                'channelId'=>'MOM',
                                                                'ChannelRefNum'=>$requestuuid,
                                                                'ReversalFlag'=>'N',
                                                                'TranAmount'=>$row["Montant_10"],
                                                                'TranCrncy'=>$row["Devise_11"],
                                                                'RateCode'=>'NOR',
                                                                'DrAcctNo'=>$compte1,
                                                                'DrValueDate'=>date("Y-m-d"),
                                                                'DrForcePostFlag'=>'N',
                                                                'DrTranParticulars'=>$row["Libelle_12"],
                                                                'CrAcctNo'=>$compte2,
                                                                'CrValueDate'=>date("Y-m-d"),
                                                                'CrForcePostFlag'=>'N',
                                                                'CrTranParticulars'=>substr($row['Libelle_12'], 0, 100),
                                                                'CrTranRemarks1'=>substr($row['Libelle_12'], 0, 100),
                                                                'TranParticularsCodeCr'=>'COLL',
                                                                );

                                                                $data_to_send['Header'] = $requestHeader;
                                                                $data_to_send['Body']['executeFinacleScriptRequest'] = $executeFinacleScriptRequest;
                                                                $data_to_send['Body']['executeFinacleScript_CustomData']['Tran_REQ'] = $tranREQ;
                                                                
                                                                $response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);
                                                        
                                                                //$response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                                                                
                                                                if (isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "SUCCESS" || $response['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")) 
                                                                {

                                                                        $responseBody=$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'];
                                                                        
                                                                        //Simulation
                                                                        //$responseBody['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";

                                                                        if(isset($responseBody['Tran_RES']['RespCode']) && $responseBody['Tran_RES']['RespCode']=="SUCCESSINTF0001")
                                                                        {
                                                                                $code = 200;
                                                                                // var_dump($row['Id_0']);
                                                                                $transaction_return[$code][$i] = $row['Id_0'];
                                                                                
                                                                                $data_to_save['Num_evenement'] = isset($responseBody['Tran_RES']['TransactionId']) ? $responseBody['Tran_RES']['TransactionId'] : "";
                                                                                $data_to_save['code'] = $code;
                                                                                $data_to_save['response'] = $code;
                                                                                $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                                                $return = $data_to_save;
                                                                                $i++;
                                                                        }
                                                                        else
                                                                        {
                                                                                if(isset($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']))
                                                                                {
                                                                                        
                                                                                        if($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1021') 
                                                                                        {
                                                                                                //Payer Account Number is Debit/Total Frozen.  
                                                                                                $data_to_save['code'] = 'E1021';
                                                                                                $data_to_save['response'] = 'E1021';
                                                                                        } 
                                                                                        elseif($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1023') 
                                                                                        {
                                                                                                //Insufficient Balance in Account for Debit    
                                                                                                $data_to_save['code'] = 'E1023';
                                                                                                $data_to_save['response'] = 'E1023';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1024')
                                                                                        {
                                                                                                //Invalid Amount                               
                                                                                                $data_to_save['code'] = 'E1024';
                                                                                                $data_to_save['response'] = 'E1024';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1026') 
                                                                                        {
                                                                                                //Invalid Amount                               
                                                                                                $data_to_save['code'] = 'E1026';
                                                                                                $data_to_save['response'] = 'E1026';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1027') 
                                                                                        {
                                                                                                //Error in Transaction Creations                
                                                                                                $data_to_save['code'] = 'E1027';
                                                                                                $data_to_save['response'] = 'E1027';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1030') 
                                                                                        {
                                                                                                //Invalid Currency Code                        
                                                                                                $data_to_save['code'] = 'E1030';
                                                                                                $data_to_save['response'] = 'E1030';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1031') 
                                                                                        {
                                                                                                //Currency Code is Null                         
                                                                                                $data_to_save['code'] = 'E1031';
                                                                                                $data_to_save['response'] = 'E1031';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1032') 
                                                                                        {
                                                                                                //Benificiary account number is NULL            
                                                                                                $data_to_save['code'] = 'E1032';
                                                                                                $data_to_save['response'] = 'E1032';
                                                                                        } elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1034') 
                                                                                        {
                                                                                                //Payee Account Number is Credit/Total Frozen  
                                                                                                $data_to_save['code'] = 'E1034';
                                                                                                $data_to_save['response'] = 'E1034';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1035') 
                                                                                        {
                                                                                                //Payee Account Number is Closed               
                                                                                                $data_to_save['code'] = 'E1035';
                                                                                                $data_to_save['response'] = 'E1035';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1041') 
                                                                                        {
                                                                                                //Error in feedback generation for file         
                                                                                                $data_to_save['code'] = 'E1041';
                                                                                                $data_to_save['response'] = 'E1041';
                                                                                        } 
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1042') 
                                                                                        {
                                                                                                //InValid Value Date                           
                                                                                                $data_to_save['code'] = 'E1042';
                                                                                                $data_to_save['response'] = 'E1042';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1044') 
                                                                                        {
                                                                                                //Settlement Outward Credit placeholder Not Found
                                                                                                $data_to_save['code'] = 'E1044';
                                                                                                $data_to_save['response'] = 'E1044';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1045') 
                                                                                        {
                                                                                                //Reroute Placeholder Not Found                
                                                                                                $data_to_save['code'] = 'E1045';
                                                                                                $data_to_save['response'] = 'E1045';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1046') 
                                                                                        {
                                                                                                //BIC is not found for Correspondence Bank/Branch
                                                                                                $data_to_save['code'] = 'E1046';
                                                                                                $data_to_save['response'] = 'E1046';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1047') 
                                                                                        {
                                                                                                //Default Correspondence Bank/Branch details is not maintained for Currency
                                                                                                $data_to_save['code'] = 'E1047';
                                                                                                $data_to_save['response'] = 'E1047';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1048') 
                                                                                        {
                                                                                                //Beneficiary Account is Null                   
                                                                                                $data_to_save['code'] = 'E1048';
                                                                                                $data_to_save['response'] = 'E1048';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1049') 
                                                                                        {
                                                                                                //BIC is not found for Beneficiary Bank/Branch  
                                                                                                $data_to_save['code'] = 'E1049';
                                                                                                $data_to_save['response'] = 'E1049';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1050') 
                                                                                        {
                                                                                                //Bank Code & Branch Code not found for Sortcode
                                                                                                $data_to_save['code'] = 'E1050';
                                                                                                $data_to_save['response'] = 'E1050';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF1051') 
                                                                                        {
                                                                                                //Beneficiary Sortcode is Null                  
                                                                                                $data_to_save['code'] = 'E1051';
                                                                                                $data_to_save['response'] = 'E1051';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4324') 
                                                                                        {
                                                                                                //DEBIT BALANCE LIMIT
                                                                                                $data_to_save['code'] = 'E4324';
                                                                                                $data_to_save['response'] = 'E4324';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF4326') 
                                                                                        {
                                                                                                //The withdrawal amount cannot exceed the account balance
                                                                                                $data_to_save['code'] = 'E4326';
                                                                                                $data_to_save['response'] = 'E4326';
                                                                                        }
                                                                                        elseif ($responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] == 'FAILUREINTF5542') 
                                                                                        {
                                                                                                //Invalid character in DrAcctNo or DrAcctName or DrTranParticulars
                                                                                                $data_to_save['code'] = 'E5542';
                                                                                                $data_to_save['response'] = 'E5542';
                                                                                        }
                                                                                }
                                                                                else
                                                                                {
                                                                                        $data_to_save['code'] = 'E000';
                                                                                        $data_to_save['response'] = 'E000'; 
                                                                                }
                                                                        }
                                                                        
                                                                } 
                                                                else 
                                                                {

                                                                        //Finacle system Error
                                                                        $info = json_encode($response);
                                                                        $this->finacleModel->save_log("Erreur : " . $info);

                                                                        $data_to_save['code'] = 'E411';
                                                                        $data_to_save['response'] = 'E411';
                                                                
                                                                
                                                                }
                                                                

                                                                $status[$i] = $code;

                                                                $data_to_save[$row['Id_0']]['Num_evenement'] = $data_to_save['Num_evenement'];
                                                                $data_to_save[$row['Id_0']]['code'] = $code;
                                                                $data_to_save['ids'][$i] = $row['Id_0'];

                                                                $return['code'] = $code;
                                                                $return['response'] = $code;
                                                                $return['Num_evenement'] =$data_to_save['Num_evenement'];
                                                                $return['result'] = json_encode($data_to_save);

                                                                $i++;
                                                        }
                                                }           
                                        
                                                $this->finacleModel->update_cbs_return($data_to_save, $data['Sydonia_44']);
                                                $this->finacleModel->update_cbs_instructions_dgda($transaction_return);

                                                if(in_array('E1021',$data_to_save['code']))
                                                {
                                                        # compte fermé, chapitre non autorisé, sens du compte incorrect, saisie arrête BCC.
                                                        $data_to_save['response'] = 'E1021';
                                                }
                                                elseif(in_array('E1023',$data_to_save['code']))
                                                {
                                                        # Solde insuffisant
                                                        $data_to_save['response'] = 'E1023';
                                                }
                                                elseif(in_array('E1024',$data_to_save['code']))
                                                {
                                                        # Montant invalide
                                                        $data_to_save['response'] = 'E1024';
                                                }
                                                elseif(in_array('E1026',$data_to_save['code']))
                                                {
                                                        # Montant invalide
                                                        $data_to_save['response'] = 'E1026';
                                                }
                                                elseif(in_array('E1027',$data_to_save['code']))
                                                {
                                                        # Erreur dans la création de la transaction
                                                        $data_to_save['response'] = 'E1027';
                                                }
                                                elseif(in_array('E1030',$data_to_save['code']))
                                                {
                                                        # Code de devise invalide
                                                        $data_to_save['response'] = 'E1030';
                                                }
                                                elseif(in_array('E1031',$data_to_save['code']))
                                                {
                                                        # Code de devise nul
                                                        $data_to_save['response'] = 'E1031';
                                                }
                                                elseif(in_array('E1032',$data_to_save['code']))
                                                {
                                                        # Numéro de compte bénéficiaire nul
                                                        $data_to_save['response'] = 'E1032';
                                                }
                                                elseif(in_array('E1034',$data_to_save['code']))
                                                {
                                                        # Numéro de compte payeur gelé
                                                        $data_to_save['response'] = 'E1034';
                                                }
                                                elseif(in_array('E1035',$data_to_save['code']))
                                                {
                                                        # Numéro de compte payeur fermé
                                                        $data_to_save['response'] = 'E1035';
                                                }
                                                elseif(in_array('E1041',$data_to_save['code']))
                                                {
                                                        # Erreur dans la génération de feedback pour le fichier
                                                        $data_to_save['response'] = 'E1041';
                                                }
                                                elseif(in_array('E1042',$data_to_save['code']))
                                                {
                                                        # Date de valeur invalide
                                                        $data_to_save['response'] = 'E1042';
                                                }
                                                elseif(in_array('E1044',$data_to_save['code']))
                                                {
                                                        # Le placeholder de crédit sortant du règlement n'a pas été trouvé
                                                        $data_to_save['response'] = 'E1044';
                                                }
                                                elseif(in_array('E1045',$data_to_save['code']))
                                                {
                                                        # Le placeholder de réacheminement n'a pas été trouvé
                                                        $data_to_save['response'] = 'E1045';
                                                }
                                                elseif(in_array('E1046',$data_to_save['code']))
                                                {
                                                        # BIC introuvable pour la banque/branche de correspondance
                                                        $data_to_save['response'] = 'E1046';
                                                }
                                                elseif(in_array('E1047',$data_to_save['code']))
                                                {
                                                        # Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise
                                                        $data_to_save['response'] = 'E1047';
                                                }
                                                elseif(in_array('E1048',$data_to_save['code']))
                                                {
                                                        # Le compte bénéficiaire est nul
                                                        $data_to_save['response'] = 'E1048';
                                                }
                                                elseif(in_array('E1049',$data_to_save['code']))
                                                {
                                                        # BIC introuvable pour la banque/branche du bénéficiaire
                                                        $data_to_save['response'] = 'E1049';
                                                }
                                                elseif(in_array('E1050',$data_to_save['code']))
                                                {
                                                        # Le code de la banque et le code de la branche n'ont pas été trouvés
                                                        $data_to_save['response'] = 'E1050';
                                                }
                                                elseif(in_array('E1051',$data_to_save['code']))
                                                {
                                                        # Le code de tri du bénéficiaire est nul
                                                        $data_to_save['response'] = 'E1051';
                                                }
                                                elseif(in_array('E4324',$data_to_save['code']))
                                                {
                                                        # LIMITE DE SOLDE DEBIT
                                                        $data_to_save['response'] = 'E4324';
                                                }
                                                elseif(in_array('E4326',$data_to_save['code']))
                                                {
                                                        # Le montant de retrait ne peut pas dépasser le solde du compte
                                                        $data_to_save['response'] = 'E4326';
                                                }
                                                elseif(in_array('E5542',$data_to_save['code']))
                                                {
                                                        # Caractère invalide dans DrAcctNo ou DrAcctName ou DrTranParticulars
                                                        $data_to_save['response'] = 'E5542';
                                                }
                                                elseif(in_array('E000',$data_to_save['code']))
                                                {
                                                        # Erreur inconnue
                                                        $data_to_save['response'] = 'E000';
                                                }
                                                elseif(in_array('E411',$data_to_save['code']))
                                                {
                                                        # Erreur système Finacle
                                                        $data_to_save['response'] = 'E411';
                                                }
                                                else
                                                {
                                                        $data_to_save['response'] = 200;
                                                }
                                                
                                                $result_to_save = json_encode($data_to_save);

                                                $this->finacleModel->save_log("Resultat final: ".$result_to_save);

                                                return $data_to_save;
                                        }


                                        }
                                        else
                                        {
                                                $return['code'] = '404';
                                        }

                                        
                                } 
                        }
                        else
                        {
                                $return['response'] = 'E405';
                                return $return; 
                        }

                }
                else
                {
                        $return['response'] = 'E405';
                        $return['msg'] = '<div class="alert aDanger text-white">'.implode(', ', $failled).'<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>';
                        return $return;
                }
        }

        public function bulletin_single_verification_treatment($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $result = array();
                $response = array();
                $return = array();
                
                $return = $this->verify_transaction_bulletin($data);

                if($return['response']=='200')
                {
                        $result['code'] = 'E200';
                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! la reservation a été faite avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                elseif(isset($return['response']) && ($return['response'] != '200'))
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aWarning text-white">La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                
                return json_encode($result);
        }

        public function bulletin_batch_verification_treatment($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $result = array();
                $response = array();
                $return = array();
                
                $return = $this->verify_transaction_bulletin($data);

                if($return['response']=='200')
                {
                        $result['code'] = 'E200';
                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! la reservation a été faite avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                elseif(isset($return['response']) && ($return['response'] != '200'))
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aWarning text-white">La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                
                return json_encode($result);
        }

        public function bulletin_prepayment_verification_treatment($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $result = array();
                $response = array();
                $return = array();
                
                $return = $this->verify_transaction_bulletin($data);

                if($return['response']=='200')
                {
                        $result['code'] = 'E200';
                        $result['msg'] = '<div class="alert aSuccess text-white">Bravo ! la reservation a été faite avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                elseif(isset($return['response']) && ($return['response'] != '200'))
                {
                        $result['code'] = $return['response'];
                        $result['msg'] = '<div class="alert aWarning text-white">La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
                
                return json_encode($result);
        }

        public function historicize_regularisations($instructionid, $action)
        {
                $lines = $this->comptabilisationModel->get_instructions_dgda_by_id($instructionid);

                if(!empty($lines))
                {
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        $data['Paiementid_4']=$lines->Paiementid_4;
                        $data['Agence_6']=$lines->Agence_6;
                        $data['Guichet_7']=$lines->Guichet_7;
                        $data['Operation_8']=$lines->Operation_8;
                        $data['Compte_9']=$lines->Compte_9;
                        $data['Montant_10']=$lines->Montant_10;
                        $data['Devise_11']=$lines->Devise_11;
                        $data['Libelle_12']=$lines->Libelle_12;
                        $data['Compte_13']=$lines->Compte_13;
                        $data['Reference_14']=$lines->Reference_14;
                        $data['Mode_15']=$lines->Mode_15;
                        $data['Makerid_16']=$lines->Makerid_16;
                        $data['Checkerid_17']=$lines->Checkerid_17;
                        $data['Validation_18']=$lines->Validation_18;
                        $data['Integration_20']= gmdate('Y-m-d H:i:s');
                        if($action == 'reverse') $data['Action_21']= 'Extourne'; else $data['Action_21'] = 'Regularisation';

                        $this->comptabilisationModel->save_regularisations($data, NULL);
                }
        }

        public function save($obj, $id, $action)
        {
                $data = array();
                $data['Id_0'] = $id;
                $data['Action_1'] = $action;
                $data['User_2'] = $this->session->userdata["user_id"];
                $data['Date_3'] = date('Y-m-d H:i:s');
                $data['Object_4'] = $obj;

                if($obj == "regularisation")
                {
                        return $this->comptabilisationModel->save_regularisation($data);
                }
        }

        public function remove_all_special_characters($texte) 
        {
                // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                $texte = preg_replace('/[^a-zA-Z0-9]/', '', $texte);

                return $texte;
        }
        
        public function get_the_total_amount($instructions)
        {
                $total_amount = 0;
                
                foreach ($instructions as $row)
                {
                        $total_amount = $total_amount + $row["Montant_10"];
                }
                
                return $total_amount;
        }
        
        public function validate_payment($data) 
        {   
                return $this->virement($data);
        }
}
