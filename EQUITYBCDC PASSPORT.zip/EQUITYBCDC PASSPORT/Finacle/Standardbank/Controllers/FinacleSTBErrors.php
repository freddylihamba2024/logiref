<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;

class FinacleSTBErrors extends BaseController
{
        /** @var object|null Référence au contrôleur parent si nécessaire */
        protected $parentController;

        /**
         * Map globale des codes Finacle -> codes internes
         * (regroupe transferts et erreurs génériques; les cas fees peuvent réutiliser une sous-partie)
         *
         * @var array
         */
        protected $finacleToInternalMap = [
                // Transfer / general
                'FAILUREINTF1021' => 'E1021',
                'FAILUREINTF1023' => 'E1023',
                'FAILUREINTF1024' => 'E1024',
                'FAILUREINTF1026' => 'E1026',
                'FAILUREINTF1027' => 'E1027',
                'FAILUREINTF1030' => 'E1030',
                'FAILUREINTF1031' => 'E1031',
                'FAILUREINTF1032' => 'E1032',
                'FAILUREINTF1034' => 'E1034',
                'FAILUREINTF1035' => 'E1035',
                'FAILUREINTF1041' => 'E1041',
                'FAILUREINTF1042' => 'E1042',
                'FAILUREINTF1044' => 'E1044',
                'FAILUREINTF1045' => 'E1045',
                'FAILUREINTF1046' => 'E1046',
                'FAILUREINTF1047' => 'E1047',
                'FAILUREINTF1048' => 'E1048',
                'FAILUREINTF1049' => 'E1049',
                'FAILUREINTF1050' => 'E1050',
                'FAILUREINTF1051' => 'E1051',
                'FAILUREINTF1058' => 'E1058',
                'FAILUREINTF1059' => 'E1059',
                'FAILUREINTF4324' => 'E4324',
                'FAILUREINTF4326' => 'E4326',
                'FAILUREINTF5542' => 'E5542',
                'FAILUREINTF1124' => 'E1124',
                'FAILUREINTF1128' => 'E1128',
                'FAILUREINTF2985' => 'E2985',
                'FAILUREINTF2982' => 'E2982',
                'FAILUREINTF400'  => 'E400',
                'FAILUREINTF411'  => 'E411',
                'FAILUREINTF405'  => 'E405',
        ];

        /**
         * Messages utilisateurs pour les codes internes Finacle (Exxxx)
         *
         * @var array
         */
        protected $internalErrorMessages = [
                'E1021' => "Le compte débiteur est gelé ou total gelé",
                'E1023' => "Le solde du compte débiteur est insuffisant",
                'E1024' => "Le montant de l'écriture est invalide",
                'E1026' => "Le montant de l'écriture est invalide",
                'E1027' => "Erreur dans la création de la transaction",
                'E1030' => "Le code de la devise est invalide",
                'E1031' => "Le code de la devise est vide",
                'E1032' => "Le numéro de compte du bénéficiaire est vide",
                'E1034' => "Le numéro de compte du bénéficiaire est gelé ou total gelé",
                'E1035' => "Le numéro de compte du bénéficiaire est fermé",
                'E1041' => "Erreur dans la génération du retour du fichier",
                'E1042' => "La date de valeur est invalide",
                'E1044' => "Le placeholder de crédit sortant n'a pas été trouvé",
                'E1045' => "Le placeholder de redirection n'a pas été trouvé",
                'E1046' => "Le BIC n'a pas été trouvé pour la banque/branche de correspondance",
                'E1047' => "Les détails de la banque/branche de correspondance par défaut ne sont pas maintenus pour la devise",
                'E1048' => "Le compte du bénéficiaire est vide",
                'E1049' => "Le BIC n'a pas été trouvé pour la banque/branche du bénéficiaire",
                'E1050' => "Le code de la banque et le code de la branche n'ont pas été trouvés pour le code de tri",
                'E1051' => "Le code de tri du bénéficiaire est vide",
                'E1058' => "Le compte n'est pas actif",
                'E1059' => "Le compte est dormant",
                'E4324' => "Limite de solde débiteur atteinte",
                'E4326' => "Le montant du retrait dépasse le solde du compte",
                'E5542' => "Caractère invalide dans le numéro de compte ou libellé",
                'E1128' => "Requête en double",
                'E2985' => "Cross currency non autorisé / échec création débit",
                'E2982' => "La devise TVA et frais doivent être identiques",
                'E1124' => "Fin de définition MTT échouée. Veuillez contacter l’administrateur du système Finacle",
                'E400'  => "Erreur générique",
                'E411'  => "Erreur système Finacle",
                'E405'  => "Données invalides ou non valides",
                'E300'  => "L'écriture n'est pas intégrée dû à un problème de connexion, veuillez cliquer sur le bouton vérifier en fermant ce message !",
        ];

        /**
         * Messages d'erreurs d'interface (codes applicatifs plus généraux)
         *
         * @var array
         */
        protected $userFacingErrors = [
                '300' => "L'&eacute;criture n'&eacute;st pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !",
                '301' => "L'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; Finacle avec succ&egrave;s mais il y a eu aucun retour Finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !",
                '305' => "Le format de compte est invalide, le compte doit &ecirc;tre au format agence-compte !",
                '405' => "Données invalides ou non valides",
                '411' => "L'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave; Finacle avec succ&egrave;s mais il y a eu aucun retour Finacle, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !",
        ];

        /**
         * Constructeur
         *
         * @param object|null $parentController
         */
        public function __construct($parentController = null)
        {
                parent::__construct();

                $this->parentController = $parentController;
        }

        /**
         * Mapping des erreurs Finacle pour les transferts.
         * Retourne le code interne correspondant (Exxxx) ou E000 si inconnu.
         *
         * @param string $code Code Finacle (ex. FAILUREINTF1021)
         * @return string Code interne (Exxxx)
         */
        public function handle_transfer_finacle_error_code(string $code): string
        {
                return $this->map_finacle_code($code);
        }

        /**
         * Mapping des erreurs Finacle pour les frais bancaires (fees).
         * Retourne le code interne correspondant (Exxxx) ou E000 si inconnu.
         *
         * @param string $code Code Finacle
         * @return string Code interne
         */
        public function handle_fees_finacle_error_code(string $code): string
        {
                // Pour les fees on peut restreindre la map si nécessaire,
                // ici on réutilise la map globale (les codes spécifiques fees existent déjà)
                return $this->map_finacle_code($code);
        }

        /**
         * Méthode utilitaire qui mappe un code Finacle vers un code interne.
         *
         * @param string $code
         * @return string
         */
        protected function map_finacle_code(string $code): string
        {
                return $this->finacleToInternalMap[$code] ?? 'E000';
        }

        /**
         * Retourne le message d'erreur associé à un code interne Finacle (Exxxx).
         *
         * @param string $error_code Code interne (Exxxx)
         * @return string Message utilisateur
         */
        public function get_finacle_error_message(string $error_code): string
        {
                return $this->internalErrorMessages[$error_code] ?? "Erreur inconnue";
        }

        /**
         * Retourne le message d'erreur utilisateur pour les codes applicatifs (300, 301, 305, ...)
         *
         * @param string $error_code
         * @return string
         */
        public function get_errors_messages(string $error_code): string
        {
                return $this->userFacingErrors[$error_code] ?? "Erreur inconnue";
        }

        /**
         * Optionnel : méthode utilitaire pour construire un message HTML standardisé
         * à partir d'un code interne (Exxxx). Utile pour renvoyer directement la vue.
         *
         * @param string $internalCode
         * @return string HTML
         */
        public function build_error_alert_html(string $internalCode): string
        {
                $message = $this->get_finacle_error_message($internalCode);
                
                return '<div class="alert aWarning text-white">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
                        . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        }

        /**
         * Construit la réponse standardisée pour un code donné.
         *
         * @param string      $code          Code interne de résultat (ex. E200, E501).
         * @param array       $data          Données du bulletin (Sydonia_44, Logirefid_4).
         * @param string|null $transactionId Identifiant de transaction si disponible.
         * @return array Tableau structuré avec code, id, logirefid, transaction_id et message HTML.
         */
        public function build_result(string $code, array $data, ?string $transactionId = null): array
        {
                $messages = [
                        'E200' => ['msg' => 'Bravo ! le débit du compte du client est fait avec succès.', 'success' => true],
                        'E300' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E301' => ['msg' => 'Problème de connexion au corebanking, veuillez cliquer sur [Vérifier] pour confirmer la réservation.'],
                        'E302' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E303' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E304' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E305' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E306' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E400' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E500' => ['msg' => 'Bravo ! le débit du compte du client est fait avec succès.', 'success' => true],
                        'E501' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E502' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                        'E503' => ['msg' => 'La réservation a été effectuée partiellement. Veuillez cliquer sur « Vérifier » pour finaliser le traitement.'],
                ];

                // sécurité : valeurs par défaut si clés manquantes
                $id        = $data['Sydonia_44'] ?? null;
                $logirefid = $data['Logirefid_4'] ?? null;

                $isSuccess   = ($messages[$code]['success'] ?? false);
                $alert_class = $isSuccess ? 'aSuccess' : 'aWarning';
                $text        = $messages[$code]['msg'] ?? 'Message inconnu';

                $msg = sprintf(
                        '<div class="alert %s text-white">%s<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>',
                        $alert_class,
                        $text
                );

                return [
                        'code'           => $code,
                        'id'             => $id,
                        'logirefid'      => $logirefid,
                        'transaction_id' => $transactionId,
                        'msg'            => $msg,
                ];
        }

}
