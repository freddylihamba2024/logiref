<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Models\FinacleStandardBankModel;

class FinacleStandardBank extends BaseController
{
        private $finacleModel=null;
        public $comptabilisationModel;
        public $bulletins;
        public $regularize;
        public $payload;
        public $errors;
        public $invoices;

        // Parent (FinacleStandard ou contrôleur principal) 
        public function __construct() 
        { 
                $this->finacleModel = new FinacleStandardBankModel(); 
                $this->comptabilisationModel = new ComptabilisationModel(); 
                
                // créer l'instance errors en premier 
                $this->errors = new FinacleSTBErrors($this); 
                
                // puis créer les sous-services en leur passant $this 
                $this->payload = new FinacleSTBPayload($this); 
                $this->bulletins = new FinacleSTBBulletins($this); 
                $this->invoices = new FinacleSTBInvoices($this); 
                $this->regularize = new FinacleSTBRegularize($this); 
        }

        /**
         * Récupère les informations d’un compte via CBS.
         *
         * - Valide la donnée d’entrée (Compte_33).
         * - Construit le payload via build_account_info_payload.
         * - Parse la réponse et retourne code + infos compte.
         *
         * @param array $data Données du bulletin (doit contenir Compte_33)
         * @return array Résultat (code, account_name, currency, balance)
         */
        public function account_info(array $data): array
        {
                #Validation
                if (empty($data['Compte_33'])) 
                {
                        $this->finacleModel->save_log("Erreur des données invalides: Compte_33 manquant", "account_info");
                        return ['code' => 405];
                }

                # Nettoyage du numéro de compte
                $account = str_replace('-', '', $data['Compte_33']);

                # Génération du payload via helper
                $requestuuid = uniqid(); // ou générateur UUID

                list($data_to_send, $requestuuid, $date) = $this->payload->build_account_info_payload($account, $requestuuid);

                # Appel CBS
                //$response = $this->finacleModel->account_info($data_to_send, $requestuuid, $date);

                // simulation WS
                $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls'] = 'Success';

                if (
                        isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']) &&
                        isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls'])
                ) 
                {
                        $acctStmnt = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt'];

                        $account_name = $acctStmnt['genDtls']['custDtls']['Name1'] ?? 'Franklin Saint';
                        $currency     = $acctStmnt['crncyCode'] ?? 'CDF';
                        $balance      = $acctStmnt['availBal'] ?? 1985459398;

                        return [
                                'code'         => '200',
                                'account_name' => $account_name,
                                'currency'     => $currency,
                                'balance'      => $balance,
                        ];
                }

                # Pas de données CBS
                return ['code' => '404'];
        }

        public function validate_payment($data) 
        {   
                return $this->virement($data);
        }

        public function reservation_seguce_invoice($data)
        {
                return $this->virement($data);
        }

        /**
         * Traite un virement de bout en bout en orchestrant les helpers.
         *
         *
         * @param array $data Données minimales : Id_0, Beneficaire_15, Taux_41, etc.
         * @return string     Résultat JSON encodé (code, message, données CBS)
         */
        public function virement(array $data): string
        {
                $data_to_save = []; 

                #1. Validation
                $validation = $this->validate_virement_input($data);
                
                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: " . json_encode($validation), "virement");
                        return json_encode($validation);
                }

                #2. Préparation du contexte (instructions, seed CBS, return_update, type, fees)
                [$instructions, $data_to_save, $return_update, $type, $fees_instructions, $fees_attestation_instructions] = $this->prepare_virement_instructions($data);  

                # Log instructions
                $this->finacleModel->save_log("Instructions préparées: " . json_encode($instructions), "virement");

                if (empty($instructions)) 
                {
                        $data_to_save['code']     = 404;
                        $data_to_save['response'] = 404;
                        $data_to_save['msg']      = '<div class="alert aDanger text-white">Instruction introuvable. Ce paiement est placé dans le menu <strong>Régularisation</strong> pour que vous puissiez le régulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                        return json_encode($data_to_save);
                }

                #3. Filtrer instructions
                $instructions = $this->filter_payable_instructions($instructions);

                #4. Traitement instructions 
                $response = $this->handle_cbs_instruction($instructions, $data);

                #5. Vérification du résultat et traitement des frais bancaires/attestation 
                $response = $this->verify_result_and_handle_fees($data, $response, $instructions, $fees_instructions, $fees_attestation_instructions, $type);

                #6. Sauvegarde CBS
                $this->save_cbs_return($data, $response['data_to_save']);

                #7. Détermination du code final
                $final = $this->determine_final_response($response['data_to_save']);

                # Log final 
                $this->finacleModel->save_log("Résultat final virement: " . json_encode($response['data_to_save']), "virement");

                return json_encode($final);
        }

        /**
         * Valide les données minimales nécessaires pour un virement.
         *
         * @param array $data Données du virement
         * @return array|null Retourne un tableau d’erreur formaté ou null si tout est valide
         */
        public function validate_virement_input(array $data): ?array
        {
                $failled  = [];
                $response = [];

                if(empty($data['Beneficaire_15'])) $failled[] = "L'autorité fiscale n'est pas définie";
                if(empty($data['Designation_14']))  $failled [] = "The designation is not defined";
                //if (empty($data['Taux_41']))        $failled[] = "Le taux de change n'est pas défini";
                //if (empty($data['Id_0']))           $failled[] = "L'identifiant du paiement est manquant";

                if ($failled) 
                {
                        $response['code']     = 405;
                        $response['response'] = 405;
                        $response['message']  = "Missing data in the request";
                        $response['msg']      = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $response['errors']   = $failled;

                        return $response;
                }

                return null;
        }

        /**
         * Prépare le contexte du virement : mise à jour du statut paiement et récupération des instructions.
         *
         * @param array $data Données du virement
         * @return array [instructions, data_to_save, return_update, type, fees_instructions, fees_attestation_instructions]
         */
        public function prepare_virement_instructions(array $data): array
        {
                $instructions   = [];
                $data_to_save   = [];
                $return_update  = null;
                $type           = $data['Type'] ?? '';
                $fees_instructions = [];
                $fees_attestation_instructions = [];

                switch ($data['Beneficaire_15']) 
                {
                        case 'DGDA':
                                switch ($type) 
                                {
                                        case 'prepayment':
                                                $update['Status_2'] = 5;
                                                $return_update = $this->finacleModel->update_payment_prepayment($update, $data['Sydonia_49']);
                                                
                                                if ($return_update) 
                                                        $instructions = $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_49'], $data['Priority']);
                                                break;

                                        case 'first_transaction':

                                                switch ($data['mode'])
                                                {
                                                        case 'single':
                                                                $instructions = $this->finacleModel->get_first_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                                                                $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($data['Sydonia_44']);
                                                                break;
                                                        case 'batch':
                                                                $instructions = $this->finacleModel->get_first_integrations_info_dgda($data['Paiementid_4'], $data['Priority']);
                                                                $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($data['Paiementid_4']);
                                                                break;
                                                        case 'prepayment':
                                                                $instructions = $this->finacleModel->get_first_integrations_info_prepayment($data['Sydonia_44'], $data['Priority']);
                                                                $fees_instructions = $this->finacleModel->get_integrations_info_prepayment_bank_fees($data['Sydonia_44']);
                                                                break;
                                                        default:
                                                                $instructions = [];
                                                                $fees_instructions = [];
                                                                break;
                                                }
                                                
                                                break;
                                        default:
                                                $update['Status_2'] = 5;
                                                $return_update = $this->finacleModel->update_payment_sydonia($update, $data['Sydonia_44']);
                                                $cbs_data = $this->finacleModel->get_cbs_returns_by_paiementid($data['Sydonia_44'], $data['Beneficaire_15']);
                                                
                                                if (!empty($cbs_data[0]['Result_6'])) 
                                                        $data_to_save = json_decode($cbs_data[0]['Result_6'], true);

                                                if ($return_update)
                                                        $instructions = $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);
                                                        //$fees_attestation_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees_attestation($data['Sydonia_44']);

                                                break;
                                }
                                break;

                        case 'DGI':
                                $update['Status_2'] = 5;
                                $this->finacleModel->update_payment_tresor($update, $data['Id_0']);
                                
                                $instructions = $this->finacleModel->get_integrations_info_dgi($data['Id_0']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees($data['Id_0']);
                                $fees_attestation_instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees_attestation($data['Id_0']);
                                
                                break;

                        case 'DGRAD':
                                $update['Status_2'] = 5;

                                if (($data['Mode'] ?? "") == "Batch")
                                {
                                        $this->finacleModel->update_payment_batch_tresor($update, $data['Id_0']);
                                        $paiementid = $data['Logirefid_4'];
                                }
                                else
                                {
                                        $paiementid = $data['Id_0'];
                                        $this->finacleModel->update_payment_tresor($update, $data['Id_0']);
                                }

                                $instructions = $this->finacleModel->get_integrations_info_dgrad($paiementid);
                                $fees_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees($paiementid);
                                $fees_attestation_instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees_attestation($paiementid);

                                break;
                        case 'SEGUCE':
                                if ($data['Priority'] == 1):
                                        $update['Status_2'] = 5;
                                        $this->finacleModel->update_payment_seguce($update, $data['Id_0']);
                                endif;
                                
                                $instructions = $this->finacleModel->get_integrations_info_seguce($data['Id_0'], $data['Priority']);
                                $fees_instructions = $this->finacleModel->get_integrations_info_seguce_bank_fees($data['Id_0'], $data['Priority']);
                                
                                break;

                }

                return [$instructions, $data_to_save, $return_update, $type, $fees_instructions, $fees_attestation_instructions];
        }

        /**
         * Filtre les instructions pour ne garder que celles avec un montant positif.
         *
         * @param array $instructions Liste brute des instructions
         * @return array Instructions filtrées
         */
        public function filter_payable_instructions(array $instructions): array
        {
                return array_filter($instructions, fn($row) => $row["Montant_10"] > 0);
        }

        /**
         * Traite les instructions CBS (payload + appel Finacle + parsing).
         *
         * @param array $instructions Liste des instructions à traiter
         * @param array $data Données du virement
         * @return array [status, transaction_return, data_to_save]
         */
        public function handle_cbs_instruction (array $instructions, array $data): array
        {
                $data_to_save       = [];
                $status             = [];
                $transaction_return = [];
                $i                  = 1;

                foreach ($instructions as $row) 
                {
                        $requestuuid = !isset($data['attempts']) 
                                        ? $data['Logirefid_4']."".$row['Id_0']
                                        : $data['Logirefid_4']."".$row['Id_0'].$data['attempts'];

                        //[$data_to_send, $requestuuid, $date] = $this->payload->build_finacle_transfer_payload($data, $row, $requestuuid );
                        list($data_to_send, $requestuuid, $date) = $this->payload->build_finacle_transfer_payload($data, $row, $requestuuid);

                        //$response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid,$date);

                        // Simulation WS
                        $response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";

                        //Success
                        $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                        $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['TransactionId'] = 'TRX'.rand(1000,9999);
                        
                        // Failed
                        //$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] = 'FAILUREINTF1021';

                        if (
                                isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && 
                                ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] === "SUCCESS" ||
                                $response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] == "DUP:SUCCESS")
                        ) 
                        {
                                $respCode = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['RespCode'] ?? "";

                                if ($respCode === "SUCCESSINTF0001") 
                                {
                                        $code = 200;
                                        $status[$i] = $code;
                                        $transaction_return[$code][$i] = $row['Id_0'];

                                        $data['code'] = $code;

                                        # Update des instructions 
                                        //$this->update_cbs_instructions($data, $row['Id_0']);

                                        $data_to_save[$row['Id_0']]['Num_evenement'] = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Tran_RES']['TransactionId'];
                                        $data_to_save[$row['Id_0']]['code'] = $code;
                                        $data_to_save['ids'][$i] = $row['Id_0'];
                                } 
                                else 
                                {
                                        $Error = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['FP_RES']['Error'] ?? "";

                                        if(isset($Error['FIBusinessException']['ErrorDetail']))
                                        {
                                                $code = 300;

                                                # Gestion des erreurs via mapping
                                                $errorCode = $Error['FIBusinessException']['ErrorDetail']['ErrorCode'] ?? '';

                                                $mappedCode = $this->errors->handle_transfer_finacle_error_code($errorCode);
                                                $message = $this->errors->get_finacle_error_message($mappedCode);

                                                $status[$i] = $code;
                                                //$transaction_return[$mappedCode][$i] = $row['Id_0'];
                                                $transaction_return[$code][$i] = $row['Id_0'];
                                                
                                                $data_to_save['code'] = $mappedCode;
                                                $data_to_save['response'] = $mappedCode;
                                                $data_to_save['msg'] = '<div class="alert aDanger text-white">Erreur '.$mappedCode.' : '.$message.'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                        }
                                        else
                                        {
                                                $data_to_save['code'] = 'E000';
                                                $data_to_save['response'] = 'E000'; 
                                                $data_to_save['msg'] = '<div class="alert aDanger text-white">Erreur E000: Erreur inconnue lors du traitement de la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }

                                        $data['code'] = '300';
                                }

                                # Update des instructions 
                                $this->update_cbs_instructions($data, $row['Id_0']);
                        } 
                        else 
                        {
                                $code = 411;
                                $status[$i] = $code;
                                $transaction_return[$code][$i] = $row['Id_0'];
                                $data_to_save['transaction_id'] = $row['Id_0'];
                        }
                        
                        $i++;
                }

                return [
                        'status'             => $status,
                        'transaction_return' => $transaction_return,
                        'data_to_save'       => $data_to_save,
                ];
        }

        /**
         * Vérifie l’existence des transactions CBS pour chaque instruction.
         *
         * - Construit le payload account_info pour chaque instruction.
         * - Appelle Finacle et vérifie la présence d’AcctStmnt/genDtls.
         * - Met à jour CBS une seule fois après la boucle si nécessaire.
         *
         * @param array $instructions Liste des instructions CBS
         * @param array $data Données du bulletin
         * @return array Résultats de la vérification (id, code, requestuuid, paiementid, typecompte, priority, attempts)
         */
        public function handle_verify_cbs_instruction(array $instructions, array $data): array
        {
                $data_to_return     = [];
                $transaction_return = [];
                $i                  = 1;


                # Vérification transactions existantes pour chaque instruction
                foreach ($instructions as $row) 
                {
                        if (($data['Beneficaire_15'] ?? "") == "SEGUCE"):
                                $requestuuid = ($row['Attempts_31'] == 0) 
                                        ? $data['Logirefid_4'] . "" . $row['Id_0']
                                        : $data['Logirefid_4'] . "" . $row['Id_0']."".$row['Attempts_31'];
                        else:
                                $requestuuid = ($row['Attempts_32'] == 0) 
                                                ? $data['Logirefid_4'] . "" . $row['Id_0']
                                                : $data['Logirefid_4'] . "" . $row['Id_0']."".$row['Attempts_32'];
                        endif;


                        list($data_to_send, $requestuuid, $date) = $this->payload->build_account_info_payload($row['Compte_9'], $requestuuid);
                        
                        //$response = $this->finacleModel->account_info($data_to_send, $requestuuid, $date);

                        //$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']= "SUCEESS";
                        //$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls']= "SUCEESS";

                        if (
                                isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']) &&
                                isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['genDtls'])
                        ) 
                        {
                                $code = $this->check_transaction_exists($response, $requestuuid);
                                $transaction_return[$code][$i] = $row['Id_0'];
                        } 
                        else 
                        {
                                $code = 300;
                                $transaction_return[$code][$i] = $row['Id_0'];
                        }

                        $data_to_return[] = [
                                'id'          => $row['Id_0'],
                                'code'        => $code,
                                'type'        => $data['Type'] ?? '',
                                'requestuuid' => $requestuuid,
                                'paiementid'  => $row['Paiementid_4'],
                                'typecompte'  => (($data['Beneficaire_15'] ?? "") == "SEGUCE") ?  $row['TypeCompte_30'] : $row['TypeCompte_29'],
                                'priority'    => $row['Priority_24'],
                                'attempts'    => (($data['Beneficaire_15'] ?? "") == "SEGUCE") ? $row['Attempts_31'] + 1 : $row['Attempts_32'] + 1 ,
                        ];

                        $i++;
                }

                # Mise à jour CBS après la boucle
                if (!empty($transaction_return[200])) 
                {
                        $this->finacleModel->update_cbs_instructions_dgda($transaction_return);
                }
                
                return $data_to_return;
        }

        /**
         * Vérifie le résultat des instructions et traite les frais bancaires/attestation.
         *
         * @param array  $data                          Données du virement (context)
         * @param array  $response                      Résultat partiel: ['status', 'transaction_return', 'data_to_save']
         * @param array  $instructions                  Instructions principales (filtrées Montant_10 > 0)
         * @param array  $fees_instructions             Instructions frais bancaires
         * @param array  $fees_attestation_instructions Instructions frais attestation
         * @param string $type                          Type du virement (DGDA: prepayment/others/…)
         * @return array Response mis à jour (inclut data_to_save avec code/msg)
         */
        public function verify_result_and_handle_fees(array $data,array $response,array $instructions, array $fees_instructions,array $fees_attestation_instructions,string $type): array 
        {
                //$processed_count   = count($response['transaction_return'] ?? []);
                #Compter le nombre total d’éléments tous niveaux confondus (On soustrait le niveau parent pour ne garder que les éléments finaux)
                $processed_count = count($response['transaction_return'] , COUNT_RECURSIVE) - count($response['transaction_return'] );
                $instruction_count = count($instructions);
            
                # Cas: aucune instruction traitée
                if ($processed_count <= 0 && (!isset($data['attempts']))) 
                {
                        $response['data_to_save']['response'] = 400;
                        $response['data_to_save']['code']     = 400;
                        $response['data_to_save']['msg']      = isset($response["msg"]) ? 
                         '<div class="alert aWarning text-white">Désolé !'.$response["msg"].' . Ce paiement est placé dans le menu <strong>Régularisation</strong>.</div>' :
                         '<div class="alert aWarning text-white">Désolé ! la validation n\'a pas abouti. Ce paiement est placé dans le menu <strong>Régularisation</strong>.</div>';
                        
                         return $response;
                }

                # Cas: toutes les instructions traitées
                if ($processed_count === $instruction_count) 
                {
                        # Sinon, on détermine succès/partiel via les statuts principaux
                        $status = $response['status'] ?? [];

                        # Si on a des frais à traiter, on délègue au helper dédié
                        if (
                                ((count(array_unique($status)) === 1 && reset($status) === 200) &&  
                                (!empty($fees_instructions) || !empty($fees_attestation_instructions))) || 
                                (empty($status) && $data['attempts'] && (!empty($fees_instructions) || !empty($fees_attestation_instructions)))
                        ) 
                        {
                                # Nettoyage avant frais (on ne conserve pas les IDs d’instructions principales)
                                unset($response['status'], $response['transaction_return'], $response['data_to_save']['ids']);

                                return $this->process_bank_fees($data,$response,$fees_instructions,$fees_attestation_instructions,$type);
                        }

                        if (!empty($status) && count(array_unique($status)) === 1 && reset($status) === 200) 
                        {
                                $response['data_to_save']['response'] = 200;
                                $response['data_to_save']['code']     = 200;
                                $response['data_to_save']['message']  = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.</div>';
                                $response['data_to_save']['msg']      = $response['data_to_save']['message'];
                        } 
                        else 
                        {
                                $response['data_to_save']['response'] = 300;
                                $response['data_to_save']['code']     = 300;
                                $response['data_to_save']['message']  = '<div class="alert aWarning text-white">L\'envoi des &eacute;critures au corebanking a partiellement &eacute;chou&eacute;, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.</div>';
                                $response['data_to_save']['msg']      = $response['data_to_save']['message'];
                        }
                }

                return $response;
        }

        /**
         * Traite les frais bancaires et attestation liés au virement.
         *
         * @param array  $data Données du virement
         * @param array  $response Résultat partiel (status, transaction_return, data_to_save)
         * @param array  $fees_instructions Instructions frais bancaires
         * @param array  $fees_attestation_instructions Instructions frais attestation
         * @param string $type Type de virement
         * @return array Résultat enrichi avec frais
         */
        private function process_bank_fees(array $data, array $response, array $fees_instructions, array $fees_attestation_instructions, string $type): array
        {
                $evenements = $response['data_to_save'] ?? [];
                $code_bank_charge = 0;
                $code_attest_bank_charge = 0;

                if (!empty($fees_instructions)) 
                {
                        $return_bank_charge = $this->virement_bank_charge($data, $fees_instructions);

                        if (isset($return_bank_charge['evenements']) && is_array($return_bank_charge['evenements']))
                        {
                                foreach ($return_bank_charge['evenements'] as $key => $event)
                                {
                                        $evenements[$key] = $event;
                                }
                        }

                        if (($return_bank_charge['code'] ?? null) == 200) 
                        {
                                $code_bank_charge = 200;
                                $bank_charges = $return_bank_charge['bankCharges'];

                                if(isset($data['Type']) && $data['Type'] == 'first_transaction' && $data['Beneficaire_15'] == 'DGDA')
                                        $type = (isset($data['mode']) && $data['mode'] == 'prepayment') ? 'prepayment' : $type;

                                $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'], $type);
                        }
                }

                if (!empty($fees_attestation_instructions)) 
                {
                        $return_attestation = $this->virement_bank_charge($data, $fees_attestation_instructions);

                        
                        if (isset($return_attestation['evenements']) && is_array($return_attestation['evenements']))
                        {
                                foreach ($return_attestation['evenements'] as $key => $event)
                                {
                                        $evenements[$key] = $event;
                                }
                        }

                        if (($return_attestation['code'] ?? null) == 200) 
                        {
                                $code_attest_bank_charge = 200;
                                $bank_charges = $return_attestation['bankCharges'];

                                if(isset($data['Type']) && $data['Type'] == 'first_transaction' && $data['Beneficaire_15'] == 'DGDA')
                                        $type = (isset($data['mode']) && $data['mode'] == 'prepayment') ? 'prepayment' : $type;
                                
                                $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'], $type);
                        }
                }

                if ($code_bank_charge === 200 || $code_attest_bank_charge === 200) 
                {
                        $response['data_to_save']['code']     = 200;
                        $response['data_to_save']['response'] = 200;
                        $response['data_to_save']['msg']      = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                } 
                else 
                {
                        $response['data_to_save']['code']  = 300;
                        $response['data_to_save']['response']  = 300;
                        $response['data_to_save']['msg']  = '<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; au corebanking fait avec succ&egrave;s, mais cependant l\'intégration de quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }

                $response['data_to_save'] = $evenements + $response['data_to_save'];

                return $response;
        }

        /**
         * Met à jour le statut CBS d’une instruction selon le type d’objet.
         *
         * @param string $obj     Type d’objet : declaration | note | bulletin | prepayment
         * @param string $id      Identifiant de la transaction
         * @param array  $update  Données de mise à jour (Status_2, Checkerid_17, etc.)
         *
         * @return void
         */
        private function update_cbs_instructions(array $data, string $id): void
        {
                $code         = $data['code'] ?? null;
                $beneficiaire = $data['Beneficaire_15'] ?? '';

                // Helper interne pour éviter la duplication
                $apply_update = function (callable $method) use ($code, $id) {
                        if ($code == '200')
                                $method($id);
                        else
                                $method($id, $code);
                
                };

                switch ($beneficiaire) 
                {
                        case 'DGI':
                                $apply_update([$this->finacleModel, 'update_cbs_instructions_dgi_by_id']);
                                break;

                        case 'DGRAD':
                                $apply_update([$this->finacleModel, 'update_cbs_instructions_dgrad_by_id']);
                                break;

                        case 'DGDA':
                                if (
                                        ($data['Type'] ?? '') == 'prepayment' ||
                                        (($data['Type'] ?? '') == 'first_transaction' && ($data['mode'] ?? '') == 'prepayment')) 
                                {
                                        $apply_update([$this->finacleModel, 'update_cbs_prepayments_instructions_dgda_by_id']);
                                } 
                                else 
                                {
                                        $apply_update([$this->finacleModel, 'update_cbs_instructions_dgda_by_id']);
                                }
                                break;
                        case 'SEGUCE':
                                $apply_update([$this->finacleModel, 'update_cbs_instructions_seguce_by_id']);
                                break;

                        default:
                                // Bénéficiaire non géré
                                $this->finacleModel->save_log("Beneficiaire inconnu pour update_cbs_instructions: " . json_encode($data),"bulletin");
                                break;
                }
        }


        /**
         * Sauvegarde les retours CBS selon régie/type (version fidèle au code original).
         *
         * @param array $data Données du virement
         * @param array $data_to_save Données CBS à persister
         * @return void
         */
        public function save_cbs_return(array $data, array $data_to_save): void
        {
                switch ($data['Beneficaire_15']) 
                {
                        case 'DGDA':
                                switch ($data['Type'] ?? '') 
                                {
                                        case 'prepayment':
                                                $data['Sydonia_49'] = intval($data['Sydonia_49']);
                                                $this->finacleModel->save_prepayment_cbs_return( $data['Account_3'],$data_to_save, $data['Sydonia_49']);
                                                break;
                                        case 'others':
                                        case 'first_transaction':
                                                if (isset($data['mode']) && $data['mode'] == 'prepayment')
                                                        $this->finacleModel->save_prepayment_cbs_return($data['Account_3'],$data_to_save,$data['Sydonia_44']);
                                                else 
                                                        $this->finacleModel->save_cbs_return_dgda($data['Account_3'],$data_to_save,$data['Sydonia_44']);
                                                break;
                                        case 'batch':
                                                $this->finacleModel->save_bulletins_batch_cbs_return($data['Account_3'],$data_to_save,$data['Sydonia_44']);
                                                break;
                                        default:
                                                $this->finacleModel->update_cbs_return($data_to_save,$data['Sydonia_44']);
                                                break;
                                }
                                break;

                        // DGI, DGRAD, ou autre
                        case 'DGI': 
                        case 'DGRAD':
                                $paiementid = (($data['Mode'] ?? '') == "Batch") 
                                        ? $data['Logirefid_4'] 
                                        : $data['Id_0'];

                                $this->finacleModel->save_cbs_return($data['Account_3'],$data_to_save,$paiementid);
                                break;
                        case 'SEGUCE':
                                $paiementid = $data['Id_0'];

                                $this->finacleModel->save_cbs_return_seguce($data['Account_3'],$data_to_save,$paiementid);
                                break;
                }
        }

        /**
         * Détermine le code final du virement et construit le message standardisé.
         *
         * Règles :
         * - 200 : toutes les instructions ont un code 200
         * - 300 : certaines instructions ont un code différent
         * - 400 : aucune instruction traitée
         * - 404 : aucune instruction trouvée
         *
         * @param array $data_to_save Données CBS accumulées (évènements + code global)
         * @return array Données enrichies avec code final et message HTML
         */
        public function determine_final_response(array $data_to_save): array
        {
                # Messages standardisés
                $successHtml  = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                $warningHtml  = '<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; au corebanking fait avec succ&egrave;s, mais cependant l\'intégration de quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                $warningHtml2 = '<div class="alert aWarning text-white">L\'envoi des &eacute;critures au corebanking a partiellement &eacute;chou&eacute;, veuillez régulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                $errorHtml    = '<div class="alert aDanger text-white">Instruction introuvable ou erreur syst&egrave;me.</div>';

                $data_to_return = [];

                # Décision principale via switch sur code global si présent
                switch ($data_to_save['code'] ?? null) 
                {
                        case 404:
                                $data_to_return['response'] = 404;
                                $data_to_return['code']     = 404;
                                $data_to_return['message']  = $errorHtml;
                                $data_to_return['msg']      = $errorHtml;

                                return $data_to_return;

                        case 300:
                                $data_to_return['response'] = 300;
                                $data_to_return['code']     = 300;
                                $data_to_return['message']  = $warningHtml;
                                $data_to_return['msg']      = $warningHtml;

                                return $data_to_return;
                }

                # Extraire les codes des sous-éléments (évènements)
                $event_codes = [];
                foreach ($data_to_save as $key => $value) 
                {
                        if (is_array($value) && isset($value['code'])) 
                                $event_codes[] = (int)$value['code'];
                }

                # Switch secondaire basé sur l'analyse des évènements
                switch (true) 
                {
                        case empty($event_codes):
                                $data_to_return['response'] = 400;
                                $data_to_return['code']     = 400;
                                $data_to_return['message']  = $warningHtml2;
                                $data_to_return['msg']      = $warningHtml2;

                                break;

                        case (count(array_unique($event_codes)) === 1 && reset($event_codes) === 200):
                                $data_to_return['response'] = 200;
                                $data_to_return['code']     = 200;
                                $data_to_return['message']  = $successHtml;
                                $data_to_return['msg']      = $successHtml;

                                break;

                        default:
                                $data_to_return['response'] = 300;
                                $data_to_return['code']     = 300;
                                $data_to_return['message']  = $warningHtml;
                                $data_to_return['msg']      = $warningHtml;

                                break;
                }

                return $data_to_return;
        }

        public function virement_bank_charge_exception($data) 
        {  
                /*
                * ------------------------------------------------
                * Variable initialization
                * ------------------------------------------------
                */
                $data_to_save = array();
                $instructions = array();
                $return_bank_charge = array();
                $failled = array();
                $type='';

                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                
                if(!isset($data['Beneficaire_15']) || $data['Beneficaire_15'] == "") $failled [] = "The tax authority is not defined";
                if(!isset($data['Taux_41']) || $data['Taux_41'] == "") $failled [] = "The exchange rate is not defined";

                if(count($failled) == 0)
                {
                        if (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGI') 
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgi_bank_fees_attestation($data['Id_0']);
                        } 
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGRAD') 
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgrad_bank_fees_attestation($data['Id_0']);
                        }
                        elseif (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] == 'DGDA') 
                        {
                                $instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees_attestation($data['Id_0']);
                        }

                        if (!empty($instructions))
                        {
                                $code_bank_charge   = 0;

                                $return_bank_charge=$this->virement_bank_charge($data, $instructions);
                               

                                if(isset($return_bank_charge['code']) && $return_bank_charge['code']==200)
                                {
                                        $code_bank_charge=200;
                                        $bank_charges=$return_bank_charge['bankCharges'];
                                        $this->finacleModel->update_cbs_bank_charge_instructions_by_id($bank_charges, $data['Beneficaire_15'],$type);
                                }

                                if($code_bank_charge==200)
                                {
                                        $data_to_save['code'] = 200;
                                        $data_to_save['response'] = 200;
                                        $data_to_save['msg'] = '<div class="alert aSuccess text-white">Bravo ! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $data_to_save['code'] = 300;
                                        $data_to_save['response'] = 300;
                                        $data_to_save['msg'] = '<div class="alert aWarning text-white">Ouf ! la validation est effectuée partiellement, veuillez régulariser ce paiement dans le menu régularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 

                                $response = $data_to_save;
                                
                                return json_encode($response);
                        }
                        else
                        {
                                $response['code'] = 405;
                                $response['response'] = 405;
                                $response['message'] = "Missing data in the request";
                                $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                
                                $result_to_save = json_encode($instructions);
                                
                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement");

                                return json_encode($response);
                        }
                }
                else
                {
                        $response['code'] = 405;
                        $response['response'] = 405;
                        $response['message'] = "Missing data in the request";
                        $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        
                        $result_to_save = json_encode($failled);
                        
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge_exception");

                        return json_encode($response);
                }
        }

        public function virement_bank_charge($data, $instructions)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $data_to_send = array();
                $failled = array();
                $return = array();
                $response = '';
                $bank_charges=array();
                $type="";
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                if(!isset($data['Logirefid_4'])) $failled[] = 'The account is not defined';
                else
                    $logirefid = str_replace('-', '', $data['Logirefid_4']);
         
                if(count($failled) == 0)
                {
                        /*
                        * --------------------------------------------
                        * Construction of data to send 
                        * --------------------------------------------
                        */
                        if(isset($data['Type']) && $data['Type'] != '')
                        {
                                $type = $data['Type'];
                        }
                       
                        if(!empty($instructions))
                        {
                                ###### the request reference ###################
                                $requestuuid = $data['Logirefid_4']."".$instructions[0]['Id_0'];

                                # Construction du payload via la fonction factorisée
                                list($data_to_send, $requestuuid, $date) = $this->payload->build_finacle_fees_payload($requestuuid, $instructions);

                                //$response = $this->finacleModel->bank_charge($data_to_send,$requestuuid,$date);
                                $response =array();
                                $response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";

                                if(isset($response['data']['Header']['ResponseHeader']['HostTransaction']['Status']) && $response['data']['Header']['ResponseHeader']['HostTransaction']['Status']=="SUCCESS")
                                {
                                        // $tranStatus=isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['tranStatus']:"";
                                        // $channelRefNum= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['channelRefNum']:"";
                                        // $chrgTranId= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranId']:"";
                                        // $chrgTranDate= isset($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate'])?$response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['chrgTranDate']:"";

                                        //SIMULATION
                                        $tranStatus="S";
                                        $channelRefNum= rand(100,999);
                                        $chrgTranId= date('YmdHis').rand(100,999);
                                        $chrgTranDate= "2023-10-01T12:00:00.000+01:00";

                                        if($tranStatus=="S")
                                        {
                                                array_push($bank_charges,$instructions[0]);
                                                array_push($bank_charges,$instructions[1]);

                                                $data_to_return['evenements'][$instructions[0]['Id_0']]['Num_evenement'] = isset($chrgTranId) ? $chrgTranId : date('YmdHis').rand(100,999);
                                                $data_to_return['evenements'][$instructions[1]['Id_0']]['Num_evenement'] = isset($chrgTranId) ? $chrgTranId : date('YmdHis').rand(100,999);
                                                $data_to_return['evenements'][$instructions[0]['Id_0']]['code'] = "200";
                                                $data_to_return['evenements'][$instructions[1]['Id_0']]['code'] = "200";
                                                
                                                $data_to_return['code']="200";
                                                $data_to_return['tranStatus']=$tranStatus;
                                                $data_to_return['channelRefNum'] = $channelRefNum;
                                                $data_to_return['chrgTranId'] = $chrgTranId;
                                                $data_to_return['chrgTranDate'] = $chrgTranDate;
                                                $data_to_return['bankCharges'] = $bank_charges;
                                        }
                                        else
                                        {
                                                $error = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Error'] ?? [];

                                                # Gestion des erreurs via mapping
                                                $errorCode = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] ?? 'FAILUREINTF1128';
                                                $mappedCode = $this->errors->handle_fees_finacle_error_code($errorCode);
                                                
                                                $data_to_return['code'] = $mappedCode;
                                                $data_to_return['response'] = $mappedCode;
                                                $data_to_return['tranStatus'] = $tranStatus;
                                                $data_to_return['channelRefNum'] = $channelRefNum;

                                                # Optionnel : ajouter un message générique si pas déjà défini
                                                if($mappedCode === 'E000') 
                                                        $data_to_return['msg'] = '<div class="alert aDanger text-white">Erreur inconnue Finacle: '.$errorCode.'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                if($mappedCode === 'E400') 
                                                        $data_to_return['msg'] = '<div class="alert aDanger text-white">'.$error['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                # Update des instructions 
                                                $data['code'] = '300';
                                                $this->update_cbs_instructions($data, $instructions[0]['Id_0']);
                                                $this->update_cbs_instructions($data, $instructions[1]['Id_0']);

                                        }
                                        
                                        $return = $data_to_return; 
                                        
                                        $result_to_save = json_encode($return);
                                        $this->finacleModel->save_log("Resultat final :" . $result_to_save);
                                }
                                else
                                {
                                        $return['code'] = '404';
                                }

                                return $return;
                        }
                        else
                        {
                                $response['code'] = 405;
                                $response['response'] = 405;
                                $response['message'] = "Missing data in the request";
                                $response['msg'] = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                $result_to_save = json_encode($failled);

                                $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                                return $response;
                        }
                        
                }
                else
                {
                        $return['code'] = 405;
                        $result_to_save = json_encode($failled);
       
                        $this->finacleModel->save_log("Erreur des donnes invalides: ".$result_to_save, "virement_bank_charge");

                        return $return;
                }
        } 

        /**
         * Régularise un paiement en appelant la fonction de traitement dédiée.
         *
         * - Délègue la logique métier à `regularize_payment_treatment`.
         * - Utilisé pour exécuter la régularisation d’un paiement (ex. correction ou ajustement).
         *
         * @param array $data Données du paiement à régulariser
         * @return mixed Résultat du traitement de régularisation
         */
        public function regularize_payment($data)
        {
                return $this->regularize->regularize_payment_treatment($data);
        }

        /**
         * Débite un bulletin client en mode **single** (traitement unitaire).
         *
         * - Délègue la logique métier à `bulletin_single_integration_treatment`.
         *
         * @param array $data Données du bulletin à débiter
         * @return mixed Résultat du traitement du bulletin unitaire
         */
        public function debit_customer_bulletin_single($data)
        {
                return $this->bulletins->bulletin_single_integration_treatment($data);
        }

        /**
         * Débite des bulletins clients en mode **batch** (traitement par lot).
         *
         * - Délègue la logique métier à `bulletin_batch_integration_treatment`.
         *
         * @param array $data Données des bulletins à débiter en lot
         * @return mixed Résultat du traitement batch des bulletins
         */
        public function debit_customer_bulletin_batch($data)
        {
                return $this->bulletins->bulletin_batch_integration_treatment($data);
        }

        /**
         * Débite des bulletins clients en mode **Prépaiement**.
         *
         * - Délègue la logique métier à `bulletin_prepayment_integration_treatment`.
         *
         * @param array $data Données des bulletins à débiter en lot
         * @return mixed Résultat du traitement batch des bulletins
         */

        public function debit_customer_prepayment($data)
        {
                # First call the treatment function
                return $this->bulletins->bulletin_prepayment_integration_treatment($data);
        }

        /**
         * Vérification d’un bulletin client en mode **single**.
         *
         * @param array $data Données du bulletin
         * @return string JSON résultat
         */
        public function bulletin_single_verification_treatment($data): string
        {
                $return = $this->bulletins->verify_transaction_bulletin($data);

                return $this->build_verification_result($return);
        }

        /**
         * Vérification d’un bulletin client en mode **batch**.
         *
         * @param array $data Données du bulletin
         * @return string JSON résultat
         */
        public function bulletin_batch_verification_treatment($data): string
        {
                $return =  $this->bulletins->verify_transaction_bulletin($data);

                return $this->build_verification_result($return);
        }

        /**
         * Vérifie un bulletin client en mode **prepayment**.
         *
         * @param array $data Données du bulletin à vérifier
         * @return string JSON contenant le code et le message de résultat
         */
        public function bulletin_prepayment_verification_treatment($data): string
        {
                $return =  $this->bulletins->verify_transaction_bulletin($data);
                
                return $this->build_verification_result($return);
        }

        /**
         * Construit le résultat JSON d’une vérification de bulletin.
         *
         * @param array $return Résultat brut de verify_transaction_bulletin
         * @return string JSON contenant le code et le message
         */
        private function build_verification_result(array $return): string
        {
                $result = [];

                if (isset($return['response']) && $return['response'] == '200') 
                {
                        $result['code'] = 'E200';
                        $result['msg']  = '<div class="alert aSuccess text-white">Bravo ! la réservation a été faite avec succès.'
                                        . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                } 
                else 
                {
                        $result['code'] = $return['response'] ?? 'E000';
                        $result['msg']  = '<div class="alert aWarning text-white">La réservation est partielle. '
                                        . 'L\'envoi au core banking a réussi, mais certaines écritures n\'ont pas été intégrées. '
                                        . 'Veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" '
                                        . 'data-dismiss="alert" aria-hidden="true">x</button></div>';
                }

                return json_encode($result);
        }

        /**
         * Vérifie si une transaction existe dans la réponse CBS.
         *
         * @param array  $response      Réponse Finacle
         * @param string $transaction_ref Référence transaction
         * @return int   Code (200 si trouvé, 300 sinon)
         */
        private function check_transaction_exists(array $response, string $requestuuid): int
        {
                $exists = array_search($requestuuid, ($response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData']['AcctStmnt']['tranDtls']['txnId'] ?? [])) ;

                return $exists ? 200 : 300;
        }


        /**
         * Vérification d’une facture **.
         *
         * @param array $data Données du bulletin
         * @return string JSON résultat
         */
        public function invoice_guice_verification_treatment($data): string
        {
                $return = $this->invoices->verify_transaction_invoice($data);

                return $this->build_verification_result($return);
        }
}
