<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Models\FinacleStandardBankModel;

class FinacleSTBInvoices extends BaseController {

        public $finacleModel;
        public $comptabilisationModel;
        protected $parentController;

        /** @var FinacleSTBErrors */ 
        protected $errors;

        public function __construct($parentController = null)
	{
                parent::__construct(); 
                $this->parentController = $parentController; 
                
                // Réutiliser l'instance fournie par le parent si disponible 
                $this->errors = $this->parentController->errors ?? new FinacleSTBErrors($this); 
                
                // Optionnel : réutiliser aussi les modèles du parent 
                $this->finacleModel = $this->parentController->finacleModel ?? new FinacleStandardBankModel(); 
                $this->comptabilisationModel = $this->parentController->comptabilisationModel ?? new ComptabilisationModel(); 
	}

        /**
         * Vérifie et régularise un bulletin côté CBS.
         *
         * - Valide les données d’entrée, Récupère les instructions CBS.
         * - Vérifie l’existence des transactions dans Finacle. Régularise les instructions.
         *
         * @param array $data Données du bulletin (Beneficaire_15, Logirefid_4, Compte_33, Sydonia_xx, Priority).
         * @return array Résultat final agrégé (code final + contexte de vérification et mises à jour).
         */
        public function verify_transaction_invoice($data)
        {
                $data_to_save       = [];
                $instructions_regul = [];
                $fees_instructions  = [];
                $fees_attestation   = [];
                
                $type = $data['Type'] ?? '';

                # Validation
                $validation = $this->parentController->validate_virement_input($data);
                
                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: " . json_encode($validation), "verify_transaction");
                        return json_encode($validation);
                }

                # Récupération instructions
                $instructions = $this->get_cbs_instructions_for_verification($data);

                if (empty($instructions)) 
                {
                        $data_to_save['response'] = 405;
                        $this->finacleModel->save_log("Erreur des données invalides: " . json_encode($data_to_save), "verify_transaction");
                        return $data_to_save;
                }

                # Vérification transactions existantes
                $results = $this->parentController->handle_verify_cbs_instruction($instructions, $data);

                # Préparer le pipeline de régularisation
                [$instructions_regul, $fees_instructions] = $this->get_cbs_instructions_for_regularization($results);
                
                $data['attempts'] = $results[0]['attempts'];

                # Traitement CBS pour les instructions régularisées
                $response = $this->parentController->handle_cbs_instruction($instructions_regul, $data);
                $response = $this->parentController->verify_result_and_handle_fees($data, $response, $instructions_regul, $fees_instructions, $fees_attestation, $type);

                # Sauvegarde CBS
                $this->parentController->save_cbs_return($data, $response['data_to_save']);

                # Détermination du code final
                $final = $this->parentController->determine_final_response($response['data_to_save']);

                $this->finacleModel->save_log("Résultat final verification (agrégé): " . json_encode($final), "verify_transaction");

                return $final;
        }

        /**
         * Récupère les instructions CBS selon bénéficiaire/type.
         *
         * - Vérifie que le bénéficiaire est DGDA.
         * - Filtre les instructions pour exclure celles de type 'T'.
         *
         * @param array $data Données du bulletin
         * @return array Liste des instructions CBS filtrées
         */
        private function get_cbs_instructions_for_verification(array $data): array
        {
                if (($data['Beneficaire_15'] ?? '') !== 'SEGUCE')
                        return [];

                # Récupération des instructions CBS
                $instructions = $this->finacleModel->get_integrations_info_invoices($data['Seguce_53'], $data['Priority']);

                if (empty($instructions) || !is_array($instructions))
                        return [];

                return $instructions;
        }

        /**
         * Prépare les instructions à régulariser en fonction des résultats de vérification.
         *
         * - Si code 200 → pas de régularisation (on laisse inchangé).
         * - Si code 300 → on récupère les instructions CBS correspondantes :
         *   • Compte principal (P) → get_first_integrations_info_dgda
         *   • Frais (F ou T) → get_integrations_info_dgda_bank_fees
         *
         * @param array $results Résultats de la vérification CBS
         * @return array [instructions, fees_instructions]
         */
        public function get_cbs_instructions_for_regularization(array $results): array
        {
                $instructions      = [];
                $fees_instructions = [];

                $paiementid  = $results[0]['paiementid'];
                $data['Attempts_31'] = $results[0]['attempts'];

                $this->finacleModel->update_cbs_instructions_seguce_attemps($data, $paiementid);

                foreach ($results as $row) 
                {
                        switch ($row['code']) 
                        {
                                case '200':
                                        # Rien à régulariser, on laisse inchangé
                                        break;

                                case '300':

                                        switch ($row['type'] ?? '') 
                                        {
                                            case 'GUICE':
                                                if ($row['typecompte'] === "P")
                                                        $instructions = $this->finacleModel->get_first_integrations_info_seguce($row['paiementid'], $row['priority']);
                                                
                                                if ($row['typecompte'] === "F" || $row['typecompte'] === "T") 
                                                        $fees_instructions = $this->finacleModel->get_verify_integrations_info_seguce_bank_fees($row['paiementid'], $row['priority']);

                                                break;
                                            
                                            default:
                                                break;
                                        }
                                default:
                                        break;
                        }
                }
                
                return [$instructions, $fees_instructions];
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */