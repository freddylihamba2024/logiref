<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Models\FinacleStandardBankModel;

class FinacleSTBBulletins extends BaseController {

        public $finacleModel;
        public $comptabilisationModel;
        protected $parentController;

        /** @var FinacleSTBErrors */ 
        protected $errors;

        public function __construct($parentController = null)
	{
                parent::__construct(); 
                $this->parentController = $parentController; 
                
                // Réutiliser l'instance fournie par le parent si disponible 
                $this->errors = $this->parentController->errors ?? new FinacleSTBErrors($this); 
                
                // Optionnel : réutiliser aussi les modèles du parent 
                $this->finacleModel = $this->parentController->finacleModel ?? new FinacleStandardBankModel(); 
                $this->comptabilisationModel = $this->parentController->comptabilisationModel ?? new ComptabilisationModel(); 
	}

        /**
         * Traite l'intégration d'un bulletin Single pour débit client.
         *
         * @param array $data Données du bulletin (Sydonia_44, Priority, Logirefid_4).
         * @return string JSON contenant code, id, logirefid, transaction_id et message HTML.
         */
        public function bulletin_single_integration_treatment($data)
        {
                return $this->process_bulletin_integration($data, 'single');
        }

        /**
         * Traite l'intégration d'un lot du bulletin pour débit client.
         *
         *
         * @param array $data
         * @return string JSON
         */
        public function bulletin_batch_integration_treatment($data)
        {
                return $this->process_bulletin_integration($data, 'batch');
        }

        /**
         * Traite l'intégration d'un prépaiement du bulletin pour débit client.
         *
         *
         * @param array $data
         * @return string JSON
         */
        public function bulletin_prepayment_integration_treatment($data)
        {
                return $this->process_bulletin_integration($data, 'prepayment');
        }

        /**
         * Traite l’intégration d’un bulletin (single ou batch).
         * 
         * - Récupère les instructions DGDA associées au bulletin.
         * - Analyse les statuts des lignes (1, 2, 3) pour déterminer le scénario :
         *   • Toutes les lignes en statut "1" → lancer le débit via `debit_customer_bulletin`.
         *   • Réservation déjà faite (ligne en statut "1", "4" ou "5") → retourne code E501/E502/E503.
         *   • Toutes les lignes en statut "2" → réservation réussie, retourne code E500.
         *
         * @param array  $data Données du bulletin
         * @param string $mode 'single' ou 'batch'
         * @return string JSON résultat
         */
        private function process_bulletin_integration($data, string $mode): string
        {
                $instructions = ($mode === 'prepayment') 
                        ? $this->finacleModel->get_integrations_info_dgda_prepayment($data['Sydonia_44'], $data['Priority'])
                        :(($mode === 'single')
                        ? $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority'])
                        : $this->finacleModel->get_bulletins_batch_integrations_info($data['Paiementid_4'], $data['Priority']));

                if (isset($instructions[0]['Status_2']) && in_array($instructions[0]['Status_2'], ["2","4","5"])) 
                {
                        $lines = [];
                        foreach ($instructions as $i => $row) 
                        {
                                $lines[$i+1] = [
                                        'status'    => $row['Status_2'],
                                        'id'        => $row['Id_0'],
                                        'reference' => $row['Reference_14']
                                ];
                        }

                        if (isset($lines[3]['status']) && $lines[1]['status']=="1" && $lines[2]['status']=="1" && $lines[3]['status']=="1") 
                        {
                                $return = $this->debit_customer_bulletin($data, $mode);
                                $result = $this->errors->build_result('E'.$return['response'], $data, $return['transaction_id'] ?? null);
                        } 
                        elseif (isset($lines[1]['status']) && in_array($lines[1]['status'], ["1","4","5"])) 
                        {
                                $result = $this->errors->build_result('E501', $data, $lines[1]['id']);
                        } 
                        elseif (isset($lines[2]['status']) && in_array($lines[2]['status'], ["1","4","5"])) 
                        {
                                $result = $this->errors->build_result('E502', $data, $lines[2]['id']);
                        } 
                        elseif (isset($lines[3]['status']) && in_array($lines[3]['status'], ["1","4","5"])) 
                        {
                                $result = $this->errors->build_result('E503', $data, $lines[3]['id']);
                        } 
                        elseif (isset($lines[3]['status']) && $lines[1]['status']=="2" && $lines[2]['status']=="2" && $lines[3]['status']=="2") 
                        {
                                $result = $this->errors->build_result('E500', $data);
                        }

                        return json_encode($result);
                } 
                else 
                {
                        # Cas sans instructions valides
                        $return = $this->debit_customer_bulletin($data, $mode);
                        $result = $this->errors->build_result('E'.$return['response'], $data, $return['transaction_id'] ?? null);
                        
                        return json_encode($result);
                }
        }

        /**
         * Exécute un débit client via bulletin (single ou batch).
         *
         * @param array  $data Données du bulletin
         * @param string $mode 'single' ou 'batch'
         * @return array Résultat global du traitement
         */
        private function debit_customer_bulletin(array $data, string $mode): array
        {
                $data_to_save = [];
                //$data['Type'] = ($mode === 'prepayment') ? $mode : (($mode === 'single') ? 'first_transaction' : 'batch');

                $data['Type'] = "first_transaction";
                $data['mode'] = $mode;

                # Préparation du contexte (instructions, seed CBS, return_update, type, fees)
                [$instructions, $data_to_save, $return_update, $type, $fees_instructions, $fees_attestation_instructions] =
                        $this->parentController->prepare_virement_instructions($data);

                if (empty($instructions)) 
                {
                        $data_to_save['response'] = 405;
                        $this->finacleModel->save_log("Erreur des données invalides: " . json_encode($data_to_save), "bulletin_$mode");
                        return $data_to_save;
                }

                $instructions = $this->parentController->filter_payable_instructions($instructions);
                $response     = $this->parentController->handle_cbs_instruction($instructions, $data);
                $response     = $this->parentController->verify_result_and_handle_fees($data, $response, $instructions, $fees_instructions, $fees_attestation_instructions, $type);

                $this->parentController->save_cbs_return($data, $response['data_to_save']);

                # Détermination du code final
                $final = $this->parentController->determine_final_response($response['data_to_save']);

                $this->finacleModel->save_log("Résultat final virement ($mode): " . json_encode($response['data_to_save']), "bulletin_$mode");

                return $final;
        }

        /**
         * Vérifie et régularise un bulletin côté CBS.
         *
         * - Valide les données d’entrée, Récupère les instructions CBS.
         * - Vérifie l’existence des transactions dans Finacle. Régularise les instructions.
         *
         * @param array $data Données du bulletin (Beneficaire_15, Logirefid_4, Compte_33, Sydonia_xx, Priority).
         * @return array Résultat final agrégé (code final + contexte de vérification et mises à jour).
         */
        public function verify_transaction_bulletin($data)
        {
                $data_to_save       = [];
                $instructions_regul = [];
                $fees_instructions  = [];
                $fees_attestation   = [];
                
                $type = $data['Type'] ?? '';

                # Validation
                $validation = $this->parentController->validate_virement_input($data);
                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: " . json_encode($validation), "verify_transaction");
                        return json_encode($validation);
                }

                # Récupération instructions
                $instructions = $this->get_cbs_instructions_for_verification($data);

                if (empty($instructions)) 
                {
                        $data_to_save['response'] = 405;
                        $this->finacleModel->save_log("Erreur des données invalides: " . json_encode($data_to_save), "verify_transaction");
                        return $data_to_save;
                }

                # Vérification transactions existantes
                $results = $this->parentController->handle_verify_cbs_instruction($instructions, $data);

                # Préparer le pipeline de régularisation
                [$instructions_regul, $fees_instructions] = $this->get_cbs_instructions_for_regularization($results);
                
                $data['attempts'] = $results[0]['attempts'];

                # Traitement CBS pour les instructions régularisées
                $response = $this->parentController->handle_cbs_instruction($instructions_regul, $data);
                $response = $this->parentController->verify_result_and_handle_fees($data, $response, $instructions_regul, $fees_instructions, $fees_attestation, $type);

                if (($data['Type'] ?? '') === 'prepayment'):
                        $data['Type'] = 'first_transaction';
                        $data['mode'] = 'prepayment';
                endif;

                # Sauvegarde CBS
                $this->parentController->save_cbs_return($data, $response['data_to_save']);

                # Détermination du code final
                $final = $this->parentController->determine_final_response($response['data_to_save']);

                $this->finacleModel->save_log("Résultat final verification (agrégé): " . json_encode($final), "verify_transaction");

                return $final;
        }

        /**
         * Récupère les instructions CBS selon bénéficiaire/type.
         *
         * - Vérifie que le bénéficiaire est DGDA.
         * - Filtre les instructions pour exclure celles de type 'T'.
         *
         * @param array $data Données du bulletin
         * @return array Liste des instructions CBS filtrées
         */
        private function get_cbs_instructions_for_verification(array $data): array
        {
                if (($data['Beneficaire_15'] ?? '') !== 'DGDA')
                        return [];

                # Récupération des instructions CBS
                $instructions = (($data['Type'] ?? '') === 'prepayment')
                        ? $this->finacleModel->get_prepayment_integrations_info($data['Sydonia_44'], $data['Priority'])
                        : $this->finacleModel->get_integrations_info_dgda($data['Sydonia_44'], $data['Priority']);

                if (empty($instructions) || !is_array($instructions))
                        return [];

                # Suppression des lignes TypeCompte = 'T'
                return array_values(array_filter($instructions, function ($row) {
                        return isset($row['TypeCompte_29']) && $row['TypeCompte_29'] !== 'T';
                }));
        }

        /**
         * Prépare les instructions à régulariser en fonction des résultats de vérification.
         *
         * - Si code 200 → pas de régularisation (on laisse inchangé).
         * - Si code 300 → on récupère les instructions CBS correspondantes :
         *   • Compte principal (P) → get_first_integrations_info_dgda
         *   • Frais (F ou T) → get_integrations_info_dgda_bank_fees
         *
         * @param array $results Résultats de la vérification CBS
         * @return array [instructions, fees_instructions]
         */
        public function get_cbs_instructions_for_regularization(array $results): array
        {
                $instructions      = [];
                $fees_instructions = [];

                $paiementid  = $results[0]['paiementid'];
                $data['Attempts_32'] = $results[0]['attempts'];

                if (($results[0]['type'] ?? '' ) === 'prepayment') 
                        $this->finacleModel->update_cbs_prepayments_instructions_dgda_attemps($data, $paiementid);
                else
                        $this->finacleModel->update_cbs_instructions_dgda_attemps($data, $paiementid);

                foreach ($results as $row) 
                {
                        switch ($row['code']) 
                        {
                                case '200':
                                        # Rien à régulariser, on laisse inchangé
                                        break;

                                case '300':

                                        switch ($row['type'] ?? '') 
                                        {
                                            case 'prepayment':

                                                if ($row['typecompte'] === "P")
                                                        $instructions = $this->finacleModel->get_first_integrations_info_prepayment($row['paiementid'], $row['priority']);
                                                
                                                if ($row['typecompte'] === "F" || $row['typecompte'] === "T") 
                                                        $fees_instructions = $this->finacleModel->get_integrations_info_prepayment_bank_fees($row['paiementid']);

                                                break;
                                            
                                            default:
                                                if ($row['typecompte'] === "P")
                                                        $instructions = $this->finacleModel->get_first_integrations_info_dgda($row['paiementid'], $row['priority']);
                                                
                                                if ($row['typecompte'] === "F" || $row['typecompte'] === "T") 
                                                        $fees_instructions = $this->finacleModel->get_integrations_info_dgda_bank_fees($row['paiementid']);
                                                break;

                                        }

                                default:
                                        break;
                        }
                }
                
                return [$instructions, $fees_instructions];
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */