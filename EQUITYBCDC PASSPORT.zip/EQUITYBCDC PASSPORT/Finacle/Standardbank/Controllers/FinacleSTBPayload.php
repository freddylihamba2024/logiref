<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use InvalidArgumentException;
use App\Controllers\BaseController;

class FinacleSTBPayload extends BaseController
{
        /** @var object|null Référence au contrôleur parent si nécessaire */
        protected $parentController;

        /**
         * FinacleSTBPayload constructor.
         *
         * @param object|null $parentController Référence optionnelle au contrôleur parent
         */
        public function __construct($parentController = null)
        {
                parent::__construct();

                $this->parentController = $parentController;
        }

        /**
         * Construit le payload Finacle pour un transfert de paiement.
         * Retourne [data_to_send, requestuuid, date]
         *
         * @param array  $data        Contexte global (ex. Beneficaire_15, Type, action, object, mode)
         * @param array  $row         Ligne d'instruction (Compte_9, Compte_13, Montant_10, Devise_11, etc.)
         * @param string $requestuuid Référence unique
         * @return array [data_to_send, requestuuid, date]
         */
        public function build_finacle_transfer_payload(array $data, array $row, string $requestuuid): array
        {
                $is_reverse = !empty($data['object']) && (($data['action'] ?? '') == 'reverse');
                
                $account_src = str_replace('-', '', $is_reverse ? ($row['Compte_13']) : ($row['Compte_9']));
                $account_dst = str_replace('-', '', $is_reverse ? ($row['Compte_9']) : ($row['Compte_13']));

                $date = $this->build_finacle_date();

                # Nettoyage libellé
                $libelle = $this->remove_all_special_characters($row['Libelle_12'] ?? '');
                $libelle = $is_reverse ? "Extourne_{$libelle}" : $libelle;

                # Détermination montant/devise
                [$montant, $devise] = $this->resolve_amount_currency($data, $row, $is_reverse);

                # Header
                $requestHeader = $this->build_finacle_header($requestuuid, $date);

                # Input VO
                $executeFinacleScriptInputVO = [
                        'requestId' => 'PaymentCollectionOnline_mn001.scr'
                ];

                # Tran_REQ
                $tranREQ = [
                        'channelId'             => 'MOM',
                        'ChannelRefNum'         => $requestuuid,
                        'ReversalFlag'          => 'N',
                        'TranAmount'            => $montant,
                        'TranCrncy'             => $devise,
                        'RateCode'              => 'NOR',
                        'DrAcctNo'              => $account_src,
                        'DrValueDate'           => date('Y-m-d'),
                        'DrForcePostFlag'       => 'N',
                        'DrTranParticulars'     => $libelle,
                        'CrAcctNo'              => $account_dst,
                        'CrValueDate'           => date('Y-m-d'),
                        'CrForcePostFlag'       => 'N',
                        'CrTranParticulars'     => substr($libelle, 0, 100),
                        'CrTranRemarks1'        => substr($libelle, 0, 100),
                        'TranParticularsCodeCr' => 'COLL',
                ];

                $data_to_send = [
                        'Header' => $requestHeader,
                        'Body'   => [
                                'executeFinacleScriptRequest' => [
                                        'ExecuteFinacleScriptInputVO' => $executeFinacleScriptInputVO
                                ],
                                'executeFinacleScript_CustomData' => [
                                        'Tran_REQ' => $tranREQ
                                ]
                        ]
                ];

                # Retourne les 3 éléments
                return [$data_to_send, $requestuuid, $date];
        }

        /**
         * Construit le payload Finacle pour les frais bancaires (fees).
         * Retourne [data_to_send, requestuuid, date]
         *
         * @param string $requestuuid
         * @param array  $instructions Tableau d'instructions (au moins 2 : frais + VAT)
         * @return array
         */
        public function build_finacle_fees_payload(string $requestuuid, array $instructions): array
        {
                if (count($instructions) < 2) 
                {
                        throw new InvalidArgumentException('Au moins 2 instructions (fees + VAT) sont requises.');
                }

                $date          = $this->build_finacle_date();
                $requestHeader = $this->build_finacle_header($requestuuid, $date);

                # Input VO
                $executeFinacleScriptInputVO = [
                        'requestId' => 'collectChargeOnlinemn001.scr'
                ];

                # Nettoyage des libellés
                $libelle_fees = $this->remove_all_special_characters($instructions[0]['Libelle_12'] ?? '');
                $libelle_vat  = $this->remove_all_special_characters($instructions[1]['Libelle_12'] ?? '');

                $executeFinacleScript_CustomData = [
                        'eventType'             => 'CDCI',
                        'eventId'               => 'MoMo Collection',
                        'channelRefNum'         => $requestuuid,
                        'acctNum'               => $instructions[0]['Compte_9'] ?? '',
                        'isConsolidatedFlg'     => 'N',
                        'isProxyReqdFlg'        => 'N',
                        'chrgAcct'              => $instructions[0]['Compte_13'] ?? '',
                        'valueDate'             => date('d-m-Y'),
                        //'valueDate'             => '15-01-2026',
                        'chrgAmt'               => $instructions[0]['Montant_10'] ?? 0,
                        'chrgCcy'               => $instructions[0]['Devise_11'] ?? '',
                        'drChrgTrnParticulars'  => $libelle_fees,
                        'vatAmt'                => $instructions[1]['Montant_10'] ?? 0,
                        'vatCcy'                => $instructions[1]['Devise_11'] ?? '',
                        'drVATTrnParticulars'   => $libelle_vat,
                        'crVATTrnParticulars'   => $libelle_vat,
                ];

                $data_to_send = [
                        'Header' => $requestHeader,
                        'Body'   => [
                                'executeFinacleScriptRequest' => [
                                        'ExecuteFinacleScriptInputVO'     => $executeFinacleScriptInputVO,
                                        'executeFinacleScript_CustomData' => $executeFinacleScript_CustomData
                                ]
                                
                        ]
                ];

                # Retourne les 3 éléments
                return [$data_to_send, $requestuuid, $date];
        }

        /**
         * Construit le payload Finacle pour la consultation d’un compte (account_info).
         * Retourne [data_to_send, requestuuid, date]
         *
         * @param string $account
         * @param string $requestuuid
         * @return array
         */
        public function build_account_info_payload(string $account, string $requestuuid): array
        {
                $date          = $this->build_finacle_date();
                $requestHeader = $this->build_finacle_header($requestuuid, $date);

                # Input VO
                $executeFinacleScriptInputVO = [
                        'requestId' => 'FullStmtwithVAT_mn001.scr'
                ];

                # Custom Data
                $executeFinacleScript_CustomData = [
                        'TranCriteria' => [
                                'acctNum'  => $account,
                                'fromDate' => '01-10-2015',
                                'toDate'   => gmdate('d-m-Y'),
                                'txnType'  => 'C',
                                'sortIn'   => 'D'
                        ]
                ];

                $data_to_send = [
                        'Header' => $requestHeader,
                        'Body'   => [
                                'executeFinacleScriptRequest' => [
                                        'ExecuteFinacleScriptInputVO'   => $executeFinacleScriptInputVO,
                                        'executeFinacleScript_CustomData' => $executeFinacleScript_CustomData
                                ]
                        ]
                ];

                return [$data_to_send, $requestuuid, $date];
        }

        /**
         * Génère la date formatée pour Finacle (+1h).
         *
         * @return string
         */
        private function build_finacle_date(): string
        {
                return date("Y-m-d\TH:i:s.000", strtotime('+1 hour'));
        }

        /**
         * Construit le header Finacle standard.
         *
         * @param string $requestuuid
         * @param string $date
         * @return array
         */
        private function build_finacle_header(string $requestuuid, string $date): array
        {
                return [
                        'RequestHeader' => [
                                'MessageKey' => [
                                        'RequestUUID'           => $requestuuid,
                                        'ServiceRequestId'      => 'executeFinacleScript',
                                        'ServiceRequestVersion' => '10.2',
                                        'ChannelId'             => 'MOM',
                                        'LanguageId'            => '',
                                ],
                                'RequestMessageInfo' => [
                                        'BankId'          => 'CD',
                                        'TimeZone'        => 'GMT+01:00',
                                        'EntityId'        => '',
                                        'EntityType'      => '',
                                        'ArmCorrelationId'=> '',
                                        'MessageDateTime' => $date,
                                ],
                                'Security' => [
                                        'Token' => [
                                                'PasswordToken' => [
                                                        'UserId'   => '',
                                                        'Password' => ''
                                                ]
                                        ],
                                        'FICertToken'            => '',
                                        'RealUserLoginSessionId' => '',
                                        'RealUser'               => '',
                                        'RealUserPwd'            => '',
                                        'SSOTransferToken'       => ''
                                ]
                        ]
                ];
        }

        /**
         * Résout le montant et la devise en fonction du bénéficiaire et du mode reverse.
         *
         * @param array $data
         * @param array $row
         * @param bool  $is_reverse
         * @return array [montant, devise]
         */
        private function resolve_amount_currency(array $data, array $row, bool $is_reverse): array
        {
                $montant = $row['Montant_10'] ?? 0;
                $devise  = $row['Devise_11'] ?? '';

                # Si reverse → permutation des montants
                if ($is_reverse) 
                {
                        if (($data['Beneficaire_15'] ?? '') === 'DGDA'):
                                $montant = $row['Montant_30'] ?? $montant;
                                $devise  = $row['Devise_31'] ?? $devise;
                        else:
                                $montant = $row['Montant_26'] ?? $montant;
                                $devise  = $row['Devise_27'] ?? $devise;
                        endif;
                }

                if (($data['Beneficaire_15'] ?? '') === 'DGDA' || (($data['Type'] ?? '') === 'prepayment')) 
                {
                        if (!empty($row['Devise_31']) && ($row['Devise_11'] ?? '') !== $row['Devise_31']) 
                        {
                                if ($is_reverse)
                                {
                                        $montant = $row['Montant_10'] ?? $montant;
                                        $devise  = $row['Devise_11'] ?? $devise;
                                } 
                                else 
                                {
                                        $montant = $row['Montant_30'] ?? $montant;
                                        $devise  = $row['Devise_31'] ?? $devise;
                                }
                        }
                } 
                else 
                {
                        if (!empty($row['Devise_27']) && ($row['Devise_11'] ?? '') !== $row['Devise_27']) 
                        {
                                if ($is_reverse) 
                                {
                                        $montant = $row['Montant_10'] ?? $montant;
                                        $devise  = $row['Devise_11'] ?? $devise;
                                } 
                                else 
                                {
                                        $montant = $row['Montant_26'] ?? $montant;
                                        $devise  = $row['Devise_27'] ?? $devise;
                                }
                        }
                }

                return [$montant, $devise];
        }

        /**
         * Nettoie une chaîne en supprimant caractères spéciaux non désirés.
         * Si ta classe parente fournit déjà cette méthode, tu peux la retirer d'ici.
         *
         * @param string $text
         * @return string
         */
        public function remove_all_special_characters($texte) 
        {
                // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                // Remplacer les espaces par des traits d'union
		$texte = str_replace('/', ' ', $texte);

                // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                //$texte = preg_replace('/[^a-zA-Z0-9]/', '', $texte); // Supprimer les espaces aussi
                $texte = preg_replace('/[^a-zA-Z0-9\/ ]/', '', $texte);

                return $texte;
        }
}
