<?php

namespace Modules\Services\Finacle\Standardbank\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Models\FinacleStandardBankModel;

class FinacleSTBRegularize extends BaseController {

        /** @var FinacleStandardBankModel */ 
        public $finacleModel; 
        
        /** @var ComptabilisationModel */ 
        public $comptabilisationModel; 
        
        /** @var object|null */ 
        protected $parentController; 
        
        /** @var FinacleSTBErrors */ 
        protected $errors;
        public $payload;

        public function __construct($parentController = null) 
        { 
                parent::__construct(); 
                $this->parentController = $parentController; 
                
                // Réutiliser l'instance fournie par le parent si disponible 
                $this->errors = $this->parentController->errors ?? new FinacleSTBErrors($this); 
                $this->payload = $this->parentController->payload ?? new FinacleSTBPayload($this); 
                
                // Optionnel : réutiliser aussi les modèles du parent 
                $this->finacleModel = $this->parentController->finacleModel ?? new FinacleStandardBankModel(); 
                $this->comptabilisationModel = $this->parentController->comptabilisationModel ?? new ComptabilisationModel(); 
        }

        /**
         * Traite la régularisation d’un paiement.
         *
         * Gère l’intégration, l’extourne ou la vérification d’une écriture
         * selon l’objet (DGI, DGRAD, DGDA) et l’action demandée
         *
         * @param array $data  Données contenant au minimum : object, transactionid
         * @return void        Réponse JSON puis arrêt du script.
         */
        public function regularize_payment_treatment($data)
        {
                $obj     = $data['object'] ?? '';
                $id      = $data['transactionid'] ?? '';
                $action  = $_POST['action'] ?? '';
                $return  = [];
                $succes  = [];

                # Préparer les données
                $data = $this->prepare_payment_data($obj);

                # Exécuter l’action
                switch ($action) 
                {
                        case 'forcing':
                                $result = $this->regularize($data);
                                break;

                        case 'reverse':
                                $result = $this->extourne($data);
                                break;

                        case 'verify':
                                return $this->verify($data);
                        default:
                                return $this->parentController->build_result('E405', $data);
                }

                # Mise à jour CBS selon résultat
                if ($result['response'] == '200') 
                {
                        $status = ($action === 'reverse') ? 1 : 2;
                        
                        $update['Status_2'] = $status;
                        $update['Checkerid_17'] = $_SESSION['userdata']["user_id"];

                        $this->update_instructions_cbs($obj, $id, $update);
                        
                        $return['response'] = 'E200';
                        $return['msg']      = $this->build_success_message($action);
                } 
                else 
                {
                        $errors             = $this->handle_regularize_errors($id, $result, $data);
                        $return['response'] = $errors['response'];
                        $return['msg']      = $this->build_error_message($errors['msg']);
                }

                # Vérification intégration
                $instructions = $this->check_integration($obj, $id, $data);
                foreach ($instructions as $value) 
                {
                        $succes[] = $value->Status_2;
                }

                $return['validate'] = in_array('2', $succes);
                
                if ($action === 'reverse' && !in_array('2', $succes)) 
                {
                        $return['delete'] = true;
                }

                echo json_encode($return);
                die;
        }

        /**
         * Prépare les données nécessaires à la régularisation/extourne
         * en fonction du type d’objet (declaration, note, bulletin, prepayment).
         *
         * @param string $obj  Type d’objet : declaration | note | bulletin | prepayment
         * @param string $id   Identifiant de la transaction
         * @return array       Tableau $data prêt à être transmis aux fonctions métier
         */
        private function prepare_payment_data(string $obj): array
        {
                $data['Id_0']           = $_POST['transactionid'];
                $data['Account_3']      = $_SESSION["userdata"]["account_id"];
                $data['Logirefid_4']    = $_POST['reference'];
                $data['Designation_14'] = $_POST['designation'];
                $data['Beneficaire_15'] = $_POST['regie'];
                $data['action']         = $_POST['action'];
                $data['object']         = $obj;

                switch ($obj) 
                {
                        case 'declaration':
                        case 'invoice':
                        case 'note':
                                $data['Paiementid_4'] = (($_POST['mode'] ?? '') == "batch") 
                                        ? $_POST['reference'] 
                                        : $_POST['paiementid'];
                                break;
                        case 'bulletin':
                                $data['Paiementid_4'] = $_POST['paiementid'];
                                $data['Sydonia_44']   = $_POST['paiementid'];
                                break;
                        case 'prepayment':
                                $data['Sydonia_49']   = $_POST['paiementid'];
                                $data['Type']         = 'prepayment';
                                break;
                }

                return $data;
        }

       /**
         * Lance une régularisation de paiement complète.
         * - Délègue le traitement à la fonction générique `process_payment_operation`
         *   en mode "regularize".
         *
         * @param array $data Données minimales du paiement (Id_0, Beneficaire_15, Designation_14, etc.)
         * @return array      Résultat final normalisé (code, statut, données CBS)
         */
        public function regularize(array $data): array
        {
                return $this->process_payment_operation($data, 'regularize');
        }

        /**
         * Lance une extourne de paiement complète.
         * - Délègue le traitement à la fonction générique `process_payment_operation`
         *   en mode "extourne".
         * - Contrairement à `regularize`, ce mode ne traite pas les frais bancaires/attestation.
         *
         * @param array $data Données minimales du paiement (Id_0, Beneficaire_15, Taux_41, etc.)
         * @return array      Résultat final normalisé (code, statut, données CBS)
         */
        public function extourne(array $data): array
        {
                return $this->process_payment_operation($data, 'extourne');
        }
        
        /**
         * Vérifie auprès de la BD si une transaction (status) existe bien.
         *
         * @param array $data
         * @return array ['response' => 200|300] ou ['code' => 405]
         */
        public function verify(array $data)
        {
                $return = [];

                # Validation des données d’entrée
                $validation = $this->parentController->validate_virement_input($data);
                
                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: " . json_encode($validation), "verify_event");

                        return $validation;
                        //return json_encode($validation);
                }

                # check if all integrations  are integrated with success
                $instructions  = $this->check_cbs_instructions($data['object'], $data['Id_0']);

                if (!empty($instructions))
                {
                        $status = $instructions->Status_2 ?? "";

                        if ($status == '2')
                        {
                                $return['response'] = 'E200';
                                $return['msg'] = '<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans finacle !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                        }
                        else
                        {
                                $return['response'] = 'E300';
                                $return['msg'] = '<td colspan=8><div class="alert aWarning text-white">La transaction n’est pas intégrée. Veuillez vérifier dans le corebanking, puis réessayer l’intégration après avoir fermé ce message.<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                        }
                }
                else
                {
                        $return['response'] = 'E405';
                        $return['msg'] = '<td colspan=8><div class="alert aDanger text-white">finacle n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
                }

                echo json_encode($return);
                die;
        }

        /**
         * Traite une opération de paiement (régularisation ou extourne).
         *
         * @param array  $data Données minimales
         * @param string $mode 'regularize' ou 'extourne'
         * @return array Résultat final (code, statut, données CBS)
         */
        private function process_payment_operation(array $data, string $mode): array
        {
                $data_to_save = [];
 
                # Validation des données d’entrée
                $validation = $this->parentController->validate_virement_input($data);

                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: " . json_encode($validation), $mode);

                        return $validation;
                        //return json_encode($validation);
                }

                # Récupération du contexte (instructions, anciens CBS)
                $ctx = $this->get_cbs_operation_context($data);

                $instructions      = $ctx['instructions'];
                $fees_instructions = $ctx['fees_instructions'] ?? [];
                $fees_attestation  = $ctx['fees_attestation_instructions'] ?? [];
                $old_cbs           = $ctx['cbs_returns'];

                # Traitement instructions
                if (!empty($instructions))
                        $data_to_save = $this->regularize_payment_transfer($instructions, $data);

                # Traitement frais (uniquement en mode régularisation)
                if ($mode === 'regularize' && (!empty($fees_instructions) || !empty($fees_attestation))) 
                        $data_to_save = $this->regularize_payment_fees($fees_instructions ?: $fees_attestation, $data);

                if (isset($data_to_save['code']) && $data_to_save['code'] != '200')
                        return $data_to_save;

                #  Fusion avec anciens CBS returns (logique existante conservée)
                $merged = $this->merge_old_and_new_cbs_returns($old_cbs, $data_to_save, $data['Id_0']);

                # Mise à jour du retour CBS au niveau paiement
                $this->update_payment_cbs_return($data, $merged);

                # Détermination du code final
                $final = $this->parentController->determine_final_response($merged);

                $this->finacleModel->save_log("Résultat final $mode: " . json_encode($final), $mode);

                return $final;
        }

        /**
         * - Met aussi à jour la référence CBS pour l’instruction cible.
         *
         * @param array  $data      Contexte de régularisation.
         * @param string $reference Nouvelle référence CBS à appliquer.
         * @return array {
         *     @type bool  'error'        true si aucune transaction trouvée.
         *     @type array 'instructions' Liste des instructions à régulariser.
         *     @type array 'cbd_returns'  Ancien retour CBS du paiement.
         * }
         */
        private function get_cbs_operation_context(array $data): array
        {
                $instructions = [];
                $fees_attestation_instructions = [];
                $fees_instructions = [];

                switch ($data['Beneficaire_15']) 
                {
                        case 'DGDA':
                                if (($data['Type'] ?? '') === "prepayment") 
                                {
                                        $instructions = $this->finacleModel->get_prepayment_integrations_by_id($data['Id_0']);
                                        $cbs_returns = $this->finacleModel->get_prepayment_cbs_returns_by_paiementid($data['Sydonia_49']);
                                        $type = 'prepayment';
                                } 
                                else 
                                {
                                        $instructions = $this->finacleModel->get_integrations_dgda_by_id($data['Id_0']);
                                        $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Sydonia_44'], 'DGDA');
                                }
                                
                                break;

                        case 'DGI':
                                $instructions = $this->finacleModel->get_integrations_dgi_by_id($data['Id_0']);
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], 'DGI');
                                
                                break;

                        case 'DGRAD':
                                $instructions = $this->finacleModel->get_integrations_dgrad_by_id($data['Id_0']);
                                $cbs_returns = $this->finacleModel->get_cbs_returns_by_paiementid($data['Paiementid_4'], 'DGRAD');
                                
                                break;
                        case 'SEGUCE':
                                $instructions = $this->finacleModel->get_integrations_seguce_by_id($data['Id_0']);
                                $cbs_returns = $this->finacleModel->get_seguce_cbs_returns_by_paiementid($data['Paiementid_4']);
                                
                                break;
                }
                
                $is_forcing = !empty($data['object']) && ($data['action'] ?? '') == 'forcing';

                # Cas frais pour DGI/DGRAD
                if (in_array($data['Beneficaire_15'], ['DGI', 'DGRAD']) && !empty($instructions) && $is_forcing) 
                {
                        if (in_array($instructions[0]['TypeCompte_25'], ['F', 'T'])) 
                        {
                                $fees_instructions = $data['Beneficaire_15'] == 'DGI'
                                        ? $this->finacleModel->get_integrations_info_dgi_bank_fees_logirefid($data['Logirefid_4'])
                                        : $this->finacleModel->get_integrations_info_dgrad_bank_fees_logirefid($data['Logirefid_4']);
                                $instructions = [];
                        } 
                        elseif (in_array($instructions[0]['TypeCompte_25'], ['FA', 'TA'])) 
                        {
                                $fees_attestation_instructions = $data['Beneficaire_15'] == 'DGI'
                                        ? $this->finacleModel->get_integrations_info_dgi_bank_fees_attestation_logirefid($data['Logirefid_4'])
                                        : $this->finacleModel->get_integrations_info_dgrad_bank_fees_attestation_logirefid($data['Logirefid_4']);
                                $instructions = [];
                        }
                }

                return [
                        'instructions' => $instructions,
                        'fees_instructions' => $fees_instructions,
                        'fees_attestation_instructions' => $fees_attestation_instructions,
                        'cbs_returns'  => $cbs_returns,
                        'type'         => $type ?? ''
                ];
        }

        /**
         * - Délègue le traitement au helper générique `process_regularize_operation`
         *   en mode "transfer".
         *
         * @param array $instructions Instructions CBS à traiter (au moins une ligne)
         * @param array $data         Données du virement (Id_0, Beneficaire_15, Logirefid_4, etc.)
         * @return array              Résultat final (code, statut, évènements CBS)
         */
        private function regularize_payment_transfer($instructions, $data)
        {
                return $this->process_regularize_operation($instructions, $data, 'transfer');
        }

        /**
         * - Délègue le traitement au helper générique `process_regularize_operation`
         *   en mode "fees".
         *
         * @param array $instructions Instructions CBS à traiter (souvent deux lignes pour frais)
         * @param array $data         Données du virement (Id_0, Beneficaire_15, Logirefid_4, etc.)
         * @return array              Résultat final (code, statut, évènements CBS)
         */
        private function regularize_payment_fees($instructions, $data)
        {
                return $this->process_regularize_operation($instructions, $data, 'fees');
        }

        /**
         * Traite une opération de régularisation (transfert ou frais).
         *
         * @param array  $instructions Instructions CBS
         * @param array  $data         Données du virement
         * @param string $mode         'transfer' ou 'fees'
         * @return array Résultat CBS normalisé
         */
        private function process_regularize_operation(array $instructions, array $data, string $mode): array
        {
                # Validation
                $validation = $this->validate_regularize_input($instructions);
                
                if ($validation !== null) 
                {
                        $this->finacleModel->save_log("Erreur données invalides: ".json_encode($validation), "regularization_$mode");
                        
                        return $validation;
                }

                # Construction du requestuuid
                $requestuuid = $this->build_request_uuid($data, $instructions);

                #Payload selon mode
                if ($mode === 'transfer') 
                {
                        [$data_to_send, $requestuuid, $date] = $this->payload->build_finacle_transfer_payload($data, $instructions[0], $requestuuid);
                        //$response = $this->finacleModel->payment_transfer($data_to_send, $requestuuid, $date);
                } 
                else 
                {
                        [$data_to_send, $requestuuid, $date] = $this->payload->build_finacle_fees_payload($requestuuid, $instructions);
                        //$response = $this->finacleModel->bank_charge($data_to_send, $requestuuid, $date); 
                }

                $data_to_return = [];

                # Simulation réponse
                $response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] = "SUCCESS";
                if ($response['data']['Header']['ResponseHeader']['HostTransaction']['Status'] === "SUCCESS") 
                {
                        $responseBody = $response['data']['Body']['executeFinacleScriptResponse']['executeFinacleScript_CustomData'] ?? []; 

                        if ($mode === 'transfer') 
                        {
                                $responseBody['Tran_RES']['RespCode'] = "SUCCESSINTF0001";
                                if($responseBody['Tran_RES']['RespCode'] == "SUCCESSINTF0001")
                                        $this->update_cbs_instructions_regularize($data, $instructions, $mode);
                        } 
                        else 
                        { 
                                $responseBody['tranStatus'] = "S"; 
                                if ($responseBody['tranStatus'] == "S")
                                        $this->update_cbs_instructions_regularize($data, $instructions, $mode);
                        }

                        $data_to_return = ($mode === 'transfer') 
                                ? $this->parse_transfer_response($instructions, $responseBody) 
                                : $this->parse_fees_response($instructions, $responseBody);

                        $this->finacleModel->save_log("Résultat final $mode: " . json_encode($data_to_return), "regularize_$mode");
                        
                        return $data_to_return;
                }

                #Erreur système
                $this->finacleModel->save_log("Erreur Finacle : " . json_encode($response), "regularize_$mode");
                return ['code' => 'E411', 'response' => 'E411'];
        }

        /**
         * Valide les données minimales nécessaires pour un virement.
         *
         * @param array $data Données du virement
         * @return array|null Retourne un tableau d’erreur formaté ou null si tout est valide
         */
        private function validate_regularize_input(array $instructions): ?array
        {
                $failled  = [];
                $response = [];

                $account_src = isset($instructions[0]["Compte_9"]) ? str_replace('-', '', $instructions[0]["Compte_9"]) : '';
                $account_dst = isset($instructions[0]["Compte_13"]) ? str_replace('-', '', $instructions[0]["Compte_13"]): '';

                if(empty($account_src))                   $failled[] = "Ligne : ".' account_src is empty';
                if(empty($account_dst))                   $failled[] = "Ligne: ".' account_dst is empty';
                if(empty($instructions[0]["Devise_11"]))  $failled[] = "Ligne : ".' devise is empty';
                if(empty($instructions[0]["Libelle_12"])) $failled[] = "Ligne : ".' Libelle_12 is empty';
                if(
                        empty($instructions[0]["Montant_10"]) ||
                        $instructions[0]["Montant_10"] == 0 ||  
                        $instructions[0]["Montant_10"] < 0
                ) 
                        $failled[] = "Ligne : ".' Montant is empty or invalide';

                if ($failled) 
                {
                        $response['code']     = 405;
                        $response['response'] = 405;
                        $response['message']  = "Missing data in the request";
                        $response['msg']      = '<div class="alert aDanger text-white">Missing data in the request<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        $response['errors']   = $failled;

                        $this->finacleModel->save_log("Erreur des données invalides: ".json_encode($failled), "regularization_transfer");

                        return $response;
                }

                return null;
        }

        /**
         * Construit le requestuuid en fonction du bénéficiaire.
         *
         * @param array $data Données du virement (inclut Logirefid_4 et Beneficaire_15)
         * @param array $instructions Liste des instructions (on prend la première)
         * @return string Request UUID construit
         */
        private function build_request_uuid(array $data, array $instructions): string
        {
                # Sécuriser l'accès au premier élément
                $first_instruction = $instructions[0] ?? [];

                # Choix du champ Attempts selon le bénéficiaire
                switch ($data['Beneficaire_15']) 
                {
                        case "DGDA":
                                $attempts_field = $first_instruction['Attempts_32'] ?? '';
                                break;

                        case "SEGUCE":
                                $attempts_field = $first_instruction['Attempts_31'] ?? '';
                                break;

                        default:
                                $attempts_field = $first_instruction['Attempts_30'] ?? '';
                                break;
                }

                # Construction du requestuuid
                return ($data['Logirefid_4'] ?? '')
                        . ($first_instruction['Id_0'] ?? '')
                        . $attempts_field;
        }

        /**
         * Parse la réponse Finacle pour une opération de transfert.
         *
         * @param array $instructions Instructions CBS (au moins une ligne)
         * @param array $responseBody Corps de réponse Finacle (simulation ou réel)
         * @return array Résultat normalisé (évènements, code, message)
         */
        private function parse_transfer_response(array $instructions, array $responseBody): array
        {
                $data_to_return = [];

                // Simulation
                $responseBody['Tran_RES']['RespCode']= "SUCCESSINTF0001";

                if (($responseBody['Tran_RES']['RespCode'] ?? '') == "SUCCESSINTF0001") 
                {
                        $code = 200;

                        $data_to_return[$instructions[0]['Id_0']]['Num_evenement'] = $responseBody['Tran_RES']['TransactionId'] ?? "TRX".rand(1000,9999);
                        $data_to_return[$instructions[0]['Id_0']]['code'] = $code;
                        $data_to_return['code'] = $code;
                        $data_to_return['response'] = $code;
                        $data_to_return['msg'] = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.</div>';
                } 
                else 
                {
                        $error = $responseBody['Error'] ?? [];

                        $errorCode  = $responseBody['FP_RES']['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] ?? 'FAILUREINTF1058';
                        //$mappedCode = $this->parentController->handle_transfer_finacle_error_code($errorCode);
                        $mappedCode = $this->errors->handle_transfer_finacle_error_code($errorCode);
                        
                        $data_to_return['code'] = $mappedCode;
                        $data_to_return['response'] = $mappedCode;

                        # Optionnel : ajouter un message générique si pas déjà défini
                        if($mappedCode === 'E000') 
                                $data_to_return['msg'] = '<div class="alert aDanger text-white">Erreur inconnue Finacle: '.$errorCode.'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        if($mappedCode === 'E400') 
                                $data_to_return['msg'] = '<div class="alert aDanger text-white">'.$error['FIBusinessException']['ErrorDetail']['ErrorDesc'].'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }

                return $data_to_return;
        }

        /**
         * Parse la réponse Finacle pour une opération de frais bancaires/attestation.
         *
         * @param array $instructions Instructions CBS (souvent deux lignes pour frais)
         * @param array $responseBody Corps de réponse Finacle (simulation ou réel)
         * @return array Résultat normalisé (évènements, code, message)
         */
        private function parse_fees_response(array $instructions, array $responseBody): array
        {
                $data_to_return = [];

                $tranStatus   = $responseBody['tranStatus'] ?? "S";
                $channelRefNum= $responseBody['channelRefNum'] ?? "87648";
                $chrgTranId   = $responseBody['chrgTranId'] ?? "TRX".rand(1000,9999);
                $chrgTranDate = $responseBody['chrgTranDate'] ?? "2023-10-01T12:00:00.000+01:00";

                if ($tranStatus == "S") 
                {
                        foreach ($instructions as $row) 
                        {
                                $data_to_return[$row['Id_0']]['Num_evenement'] = $chrgTranId;
                                $data_to_return[$row['Id_0']]['code'] = 200;
                        }

                        $data_to_return['code'] = 200;
                        $data_to_return['response'] = 200;

                        // $data_to_return['tranStatus']=$tranStatus;
                        // $data_to_return['channelRefNum'] = $channelRefNum;
                        // $data_to_return['chrgTranDate'] = $chrgTranDate;
                } 
                else 
                {
                        $errorCode = $responseBody['Error']['FIBusinessException']['ErrorDetail']['ErrorCode'] ?? 'FAILUREINTF1128';
                        //$mappedCode = $this->parentController->handle_fees_finacle_error_code($errorCode);
                        $mappedCode = $this->errors->handle_fees_finacle_error_code($errorCode);

                        $data_to_return['code'] = $mappedCode;
                        $data_to_return['response'] = $mappedCode;
                }

                return $data_to_return;
        }

        /**
         * Fusionne les anciens et nouveaux retours CBS pour une écriture donnée.
         *
         * @param array $old  Ancien retour CBS (tableau contenant Result_6 en JSON)
         * @param array $new  Nouveau retour CBS généré par Flexcube
         * @param string|int $id  Identifiant de l’écriture à mettre à jour
         *
         * @return array  Tableau fusionné prêt à être enregistré en base
         */    
        private function merge_old_and_new_cbs_returns(array $old, array $new)
        {
                $merged = [];

                /** 1. Charger l'ancien CBS */
                if (!empty($old[0]['Result_6'])) 
                {
                        $oldData = json_decode($old[0]['Result_6'], true);

                        if (is_array($oldData)) 
                        {
                                foreach ($oldData as $key => $value) 
                                {
                                        # Garder uniquement les instructions (clé numérique)
                                        if (is_numeric($key)) 
                                        {
                                                $merged[$key] = [
                                                        'Num_evenement' => $value['Num_evenement'] ?? 0,
                                                        'code'          => $value['code'] ?? 0
                                                ];
                                        }
                                }
                        }
                }

                /** 2. Fusionner / écraser avec les nouvelles instructions */
                foreach ($new as $key => $value) 
                {
                        if (is_numeric($key)) 
                        {
                                $merged[$key] = [
                                        'Num_evenement' => $value['Num_evenement'] ?? 0,
                                        'code'          => $value['code'] ?? 0
                                ];
                        }
                }

                return $merged;
        }

        /**
         * Met à jour le retour CBS en base selon la régie et le type d’opération.
         *
         * @param array $data    Données de l’écriture (régie, type, identifiants)
         * @param array $merged  Retour CBS fusionné à enregistrer
         *
         * @return bool  Indique si la mise à jour a réussi
         */
        private function update_payment_cbs_return($data, $merged)
        {
                switch ($data['Beneficaire_15']) 
                {
                        case 'DGDA':
                                if (!empty($data['Type']) && $data['Type'] == "prepayment") 
                                        return $this->finacleModel->update_prepayment_return($merged, $data['Sydonia_49']);

                                return $this->finacleModel->update_return($merged, $data['Sydonia_44'], 'DGDA');

                        case 'SEGUCE':
                                return $this->finacleModel->update_return_seguce($merged, $data['Paiementid_4']);

                        # DGI | DGRAD
                        default:
                                return $this->finacleModel->update_return($merged, $data['Paiementid_4'], $data['Beneficaire_15']);
                }
        }

        /**
         * Met à jour les instructions CBS selon le bénéficiaire et le type.
         */
        private function update_cbs_instructions_regularize(array $data, array $instructions, string $type): void
        {
                $beneficiary  = $data['Beneficaire_15'] ?? null;
                $isPrepayment = ($data['Type'] ?? '') === "prepayment";

                switch ($beneficiary) 
                {
                        case 'DGI':
                                $this->finacleModel->update_cbs_instructions_dgi_by_id($instructions[0]['Id_0']);
                                if ($type === "fees" && isset($instructions[1]['Id_0']))
                                        $this->finacleModel->update_cbs_instructions_dgi_by_id($instructions[1]['Id_0']);
                                break;

                        case 'DGRAD':
                                $this->finacleModel->update_cbs_instructions_dgrad_by_id($instructions[0]['Id_0']);
                                if ($type === "fees" && isset($instructions[1]['Id_0'])) 
                                        $this->finacleModel->update_cbs_instructions_dgrad_by_id($instructions[1]['Id_0']);
                                
                                break;

                        case 'DGDA':
                                if ($isPrepayment) 
                                {
                                        $this->finacleModel->update_cbs_prepayments_instructions_dgda($instructions[0]['Sydonia_49']);
                                        if ($type === "fees" && isset($instructions[1]['Sydonia_49']))
                                                $this->finacleModel->update_cbs_prepayments_instructions_dgda($instructions[1]['Sydonia_49']);
                                        
                                } 
                                else 
                                {
                                        $this->finacleModel->update_cbs_instructions_dgda_by_id($instructions[0]['Id_0']);
                                        if ($type === "fees" && isset($instructions[1]['Id_0'])) 
                                                $this->finacleModel->update_cbs_instructions_dgda_by_id($instructions[1]['Id_0']);
                                }

                                break;
                        case 'SEGUCE':
                                $this->finacleModel->update_cbs_instructions_seguce_by_id($instructions[0]['Id_0']);
                                if ($type === "fees" && isset($instructions[1]['Id_0'])) 
                                        $this->finacleModel->update_cbs_instructions_seguce_by_id($instructions[1]['Id_0']);
                                
                                break;

                        default:
                                // Optionnel : log ou gestion d'un bénéficiaire inconnu
                                $this->finacleModel->save_log("Beneficiaire inconnu: ".json_encode($data), "updateCbsInstructions");
                                break;
                }
        }

        /**
         * Met à jour le statut CBS d’une instruction selon le type d’objet.
         *
         * @param string $obj     Type d’objet : declaration | note | bulletin | prepayment
         * @param string $id      Identifiant de la transaction
         * @param array  $update  Données de mise à jour (Status_2, Checkerid_17, etc.)
         *
         * @return void
         */
        private function update_instructions_cbs(string $obj, string $id, array $update)
        {
                switch ($obj) 
                {
                        case 'declaration':
                                $this->comptabilisationModel->update_instructions_cbs_dgi($id, $update);
                                break;
                        case 'note':
                                $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $update);
                                break;
                        case 'bulletin':
                                $this->comptabilisationModel->update_instructions_cbs_dgda($id, $update);
                                break;
                        case 'prepayment':
                                $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $update);
                                break;
                }
        }

        /**
         * Récupère les instructions CBS en fonction du type d’objet métier.
         * - Selon la nature de l’objet (déclaration, note, bulletin, prépaiement),
         *
         * @param string $obj Type d’objet 
         * @param string $id  Identifiant de la transaction (paiementid, sydonia, etc.)
         * @return array      Tableau d’instructions CBS (vide si non trouvé ou non implémenté)
         */
        private function check_cbs_instructions(string $obj, string $id)
        {
                switch ($obj) 
                {
                        case 'declaration':
                                return $this->comptabilisationModel->get_instructions_dgi_by_id($id);
                        case 'note':
                                return $this->comptabilisationModel->get_instructions_dgrad_by_id($id);
                        case 'bulletin':
                                return $this->comptabilisationModel->get_instructions_dgda_by_id($id);
                        case 'invoice':
                                return $this->comptabilisationModel->get_instructions_seguce_by_id($id);
                        case 'prepayment':
                                // return $this->comptabilisationModel->get_instructions_dgda_by_id($id);
                }
        }

        /**
         * Vérifie l’intégration des instructions CBS selon le type d’objet.
         *
         * @param string $obj   Type d’objet : declaration | note | bulletin | prepayment
         * @param string $id    Identifiant de la transaction
         * @param array  $data  Données associées (Logirefid, Paiementid, etc.)
         *
         * @return array|object Liste ou objet contenant les instructions CBS
         */
        private function check_integration(string $obj, string $id, array $data)
        {
                switch ($obj) 
                {
                        case 'declaration':
                                return $this->comptabilisationModel->get_instructions_dgi($data['Logirefid_4']);
                        case 'note':
                                return $this->comptabilisationModel->get_instructions_dgrad($data['Logirefid_4']);
                        case 'bulletin':
                                return $this->comptabilisationModel->get_instructions_dgda($data['Paiementid_4']);
                        case 'invoice':
                                return $this->comptabilisationModel->get_instructions_seguce($data['Paiementid_4']);
                        case 'prepayment':
                                return $this->comptabilisationModel->get_instructions_dgda($data['Sydonia_49']);
                }
        }
        
        /**
         * Construit un message HTML de succès standardisé selon l’action.
         *
         * @param string $action  Action exécutée: forcing | reverse | verify
         * @return string         HTML prêt pour l’interface
         */
        private function build_success_message(string $action): string
        {
                switch ($action) 
                {
                        case 'forcing':
                                return '<div class="alert aSuccess text-white">Bravo, écriture intégrée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                        case 'reverse':
                                return '<div class="alert aSuccess text-white">Extourne exécutée avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                        case 'verify':
                                return '<td colspan=8><div class="alert aSuccess text-white">L\'écriture est déjà intégrée dans Flexcube !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';

                        default:
                                return '<div class="alert aSuccess text-white">Opération réalisée avec succès.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
        }

        /**
         * Construit un message HTML d’erreur/alerte standardisé.
         *
         * @param string $type    Type: warning | danger
         * @param string $message Message lisible à afficher
         * @return string         HTML prêt pour l’interface
         */
        private function build_error_message(string $message, string $type = 'warning'): string
        {
                $class = $type === 'danger' ? 'aDanger' : 'aWarning';

                return '<td colspan=8><div class="alert '.$class.' text-white">'.$message.'<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>';
        }

        /**
         * Capture et traite les erreurs Finacle selon la régie.
         *
         * @param string $id       Identifiant de l'instruction CBS
         * @param array  $result   Résultat contenant la clé 'response'
         * @param string $regie    Régie (DGI, DGDA, DGRAD)
         * @return array           Retourne ['response' => code, 'msg' => message HTML]
         */
        private function handle_regularize_errors(string $id, array $result, array $data): array
        {
                # Déterminer le nombre de tentatives selon la régie
                switch ($data['Beneficaire_15']) 
                {
                        case 'DGI':
                                $last_attempts  = $this->comptabilisationModel->get_last_attempts_dgi($id);
                                $update_method  = 'update_instructions_cbs_dgi';
                                break;
                        case 'DGDA':

                                if (isset($data['Type']) && $data['Type'] === 'prepayment') 
                                {
                                        $last_attempts  = $this->comptabilisationModel->get_last_attempts_prepayment($id);
                                        $update_method  = 'update_prepayments_instructions_cbs';
                                        break;
                                }
                                
                                $last_attempts  = $this->comptabilisationModel->get_last_attempts_dgda($id);
                                $update_method  = 'update_instructions_cbs_dgda';
                                break;
                        case 'DGRAD':
                                $last_attempts  = $this->comptabilisationModel->get_last_attempts_dgrad($id);
                                $update_method  = 'update_instructions_cbs_dgrad';
                                break;
                        default:
                                $last_attempts  = 0;
                                $update_method  = null;
                                break;
                }

                $last_attempts = !empty($last_attempts) ? $last_attempts + 1 : 1;

                # Mise à jour CBS avec tentative échouée
                $data_to_update = [];
                $data_to_update['Status_2']       = (isset($data['action']) && $data['action']=="reverse") ? 2 : 5;
                $data_to_update['Checkerid_17']   = $_SESSION['userdata']["user_id"] ?? null;


                if ($data['Beneficaire_15']=='DGDA')
                        $data_to_update['Attempts_32'] = $last_attempts;
                else
                        $data_to_update['Attempts_30'] = $last_attempts;

                if ($update_method) 
                        $this->comptabilisationModel->$update_method($id, $data_to_update);

                $code = $result['response'];

                # Messages des erreurs
                //$msg_error = $this->parentController->get_finacle_error_message($code);
                $msg_error = $this->errors->get_finacle_error_message($code);
                $msg  = $msg_error ?? "Problème de connexion avec Finacle !";

                # Choisir style d'alerte
                $alertClass = isset($msg_error) ? "aWarning" : "aDanger";

                return [
                        'response' => $code,
                        'msg'      => '<div class="alert '.$alertClass.' text-white">'.$msg.'<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div>'
                ];
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */