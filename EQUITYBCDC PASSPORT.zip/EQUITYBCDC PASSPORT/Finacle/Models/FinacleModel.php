<?php
        /**
         * Description of LogirefClass
         * Contains all Model Methodes
         * @author Glodi
         */
        namespace Modules\Services\Finacle\Models;

        use App\Models\MY_Transaction;

        class FinacleModel extends MY_Transaction{

                function __construct()
                {
                        parent::__construct();
                }

                public function payment_transfer($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';

                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        $this->save_log($xml);
                        //echo $xml; die;

                        $response = "";

                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                                        
                                //echo $return; die;
                                                        
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml, "virement");
                                $this->save_log($return, "virement");

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }

                public function add_lien_account($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                        
                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        
                        //echo $xml; die;
                        
                        $response = "";
                        
                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                                        
                                //echo $return; die;
                                                        
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml, "reservation");
                                $this->save_log($return, "reservation");
                                $this->save_log($result, "reservation");
                                $this->save_log($result, "reservation");

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }

                public function inquiry_lien_account($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                        
                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        
                        //echo $xml; die;
                        
                        $response = "";
                        
                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                                        
                                //echo $return; die;
                                                        
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml);
                                $this->save_log($return);
                                $this->save_log($result);
                                $this->save_log($result);

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }

                /*public function release_lien_account($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';

                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();

                        //echo $xml; die;

                        $response = "";

                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        );
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                //echo $return; die;

                                $response = json_decode($result, true);
                                $this->save_log($xml,  "cancel_reservation");
                                $this->save_log($return, "cancel_reservation");
                                $this->save_log($result, "cancel_reservation");
                                $this->save_log($result, "cancel_reservation");

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }*/

                public function release_lien_account($data)
                {
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';

                        $xml_data = new \SimpleXMLElement(
                                '<?xml version="1.0" encoding="UTF-8"?><FIXML xmlns="http://www.finacle.com/fixml"></FIXML>'
                        );

                        $this->array_to_xml($data, $xml_data);

                        $xml = $xml_data->asXML();

                        $options = [
                                'http' => [
                                        'method'  => 'POST',
                                        'timeout' => 120,
                                        'header'  => "Content-Type: application/xml",
                                        'content' => $xml
                                ],
                                'ssl' => [
                                        'verify_peer' => false,
                                        'verify_peer_name' => false
                                ]
                        ];

                        try {
                                $context = stream_context_create($options);
                                $return = file_get_contents($url, false, $context);

                                if ($return === false) {
                                        return '406';
                                }

                                $xml_string = simplexml_load_string($return);

                                if ($xml_string === false) {
                                        return '407';
                                }

                                $result = json_decode(json_encode($xml_string), true);

                                $this->save_log($xml, "AcctLienMod_request");
                                $this->save_log($return, "AcctLienMod_response");

                                return $result;

                        }
                        catch (\Exception $ex) {
                                $this->save_log($ex->getMessage(), "AcctLienMod_error");
                                return '406';
                        }
                }

                public function exchange_rate($data, $prefix_logs = NULL)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                        
                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        
                        //echo $xml; die;
                        
                        $response = "";
                        
                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                                        
                                //echo $return; die;
                                                        
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml, "exchange_rate_".$prefix_logs);
                                $this->save_log($return, "exchange_rate_".$prefix_logs);
                                $this->save_log($result, "exchange_rate_".$prefix_logs);
                                $this->save_log($result, "exchange_rate_".$prefix_logs);

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }
                
                public function tax_exempt($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                        
                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        
                        //echo $xml; die;
                        
                        $response = "";
                        
                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                                                        
                                //echo $return; die;
                                                        
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml);
                                $this->save_log($return);
                                $this->save_log($result);
                                $this->save_log($result);

                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }
                public function account_info($data)
                {
                        #### url du web service
                        $url = 'https://finacleprod1.ebsafrica.com:20500/FISERVLET/fihttp';
                        
                        $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                        $this->array_to_xml($data,$xml_data);
                        $xml = $xml_data->asXML();
                        
                        //echo $xml; die;
                        
                        $response = "";
                        
                        $options = array(
                                'http' => array(
                                        'method'  =>  'POST',
                                        'timeout'=>120,
                                        'header' => 'Content-Type: application/xml',
                                        'content' => $xml
                                ),
                                'ssl'=>array(
                                'verify_peer'=>false,
                                'verify_peer_name'=>false,
                                'ciphers'=>'DEFAULT:!DH'
                                                                
                                )

                        ); 
                        try
                        {
                                $context  = stream_context_create( $options );
                                $return = file_get_contents( $url, false, $context );
                        
                                //echo $return; die;
                                
                                $xml_string = simplexml_load_string($return);
                                $result = json_encode($xml_string);

                                $response = json_decode($result, true);
                                $this->save_log($xml, "account_info");
                                $this->save_log($return, "account_info");
                                $this->save_log($result, "account_info");
                                                        
                                return $response;
                        }
                        catch (\Exception $ex)
                        {
                                return '406';
                        }
                }
                
                public function array_to_xml( $data, &$xml_data ) {
                
                foreach( $data as $key => $value ) {
                        if( is_array($value) ) {
                        if( is_numeric($key) ){
                                $key = 'PartTrnRec';
                        }
                        $subnode = $xml_data->addChild($key);
                        $this->array_to_xml($value, $subnode);
                        } else {
                        $xml_data->addChild("$key",htmlspecialchars("$value"));
                        }
                }
                }
                
                public function get_integrations_info_dgda($id, $priority)
                {
                        $where = "Paiementid_4 ='".$id."' AND Priority_24 = ".$priority." AND Status_2 != 2 ";
                        $builder = $this->db->table("logiref_cbs_instructions_dgda")
                                ->select("logiref_cbs_instructions_dgda.*")
                                ->where($where)
                                ->get();
                        
                        return $builder->getResultArray();
                }
                
                public function get_integrations_info_dgi($ref)
                {
                        $builder = $this->db->table("logiref_cbs_instructions_dgi")
                                ->select("logiref_cbs_instructions_dgi.*")
                                ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1")
                                ->get();
                        
                        return $builder->getResultArray();
                }
                
                public function get_integrations_info_dgrad($ref)
                {
                        $builder = $this->db->table("logiref_cbs_instructions_dgrad")
                                ->select("logiref_cbs_instructions_dgrad.*")
                                ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1")
                                ->get();
                        
                        return $builder->getResultArray();
                }

                public function get_integrations_info_passport($ref)
                {
                        $builder = $this->db->table("logiref_cbs_instructions_passeport")
                                ->select("logiref_cbs_instructions_passeport.*")
                                ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1")
                                ->get();
                      
                        return $builder->getResultArray();
                }
                        
	                public function get_prepayment_integrations_info($id, $priority)
	                {
	                        return $this->db->table("logiref_cbs_prepayments_instructions")
	                                ->select("logiref_cbs_prepayments_instructions.*")
	                                ->where([
	                                        "Paiementid_4" => $id,
	                                        "Status_2" => 1,
	                                        "Priority_24" => $priority
	                                ])
	                                ->get()
	                                ->getResultArray();
	                }
	                        
                        public function get_prepayment_gu_integrations_info($lot)
                        {
                                return $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                        ->select("logiref_cbs_prepayments_gu_instructions.*")
                                        ->where([
                                                "Paiementid_4" => $lot,
                                                "Status_2" => 1
                                        ])
                                        ->get()
                                        ->getResultArray();
                        }

	                public function get_integrations_info_dgda_prepayment($id, $priority)
	                {
	                        $account = $this->session->userdata['account_id'];
	                        $where = "Account_3  = ".$account." AND Paiementid_4='".$id."' AND Priority_24 ='".$priority."' ";

	                        $builder = $this->db->table('logiref_cbs_prepayments_instructions')
	                                ->select('logiref_cbs_prepayments_instructions.*')
	                                ->where($where)
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function get_integrations_info_dgda_prepayment_to_regularize($id, $priority)
	                {
	                        $account = $this->session->userdata['account_id'];
	                        $where = "Account_3  = ".$account." AND Paiementid_4='".$id."' AND Priority_24 ='".$priority."' AND Status_2 !=2 ";

	                        $builder = $this->db->table('logiref_cbs_prepayments_instructions')
	                                ->select('logiref_cbs_prepayments_instructions.*')
	                                ->where($where)
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function get_prepayment_integrations_dgda_by_id($id)
	                {
	                        $where = " Id_0='".$id."'";
	                        $builder = $this->db->table('logiref_cbs_prepayments_instructions')
	                                ->select('logiref_cbs_prepayments_instructions.*')
	                                ->where($where)
	                                ->orderBy('Id_0', 'DESC')
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function get_cbs_returns_by_prepayment_batchid($paiementid, $regie)
	                {
	                        $account = $this->session->userdata['account_id'];
	                        $where = " Account_3  ='" . $account . "' AND Sydonia_5 = '" . $paiementid . "' ";

	                        $builder = $this->db->table('logiref_prepayments_cbs_returns')
	                                ->select('logiref_prepayments_cbs_returns.*')
	                                ->where($where)
	                                ->orderBy('Id_0', 'DESC')
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function get_cbs_prepayment_returns_by_paiementid($paiementid, $regie)
	                {
	                        $account = $this->session->userdata['account_id'];

	                        $where = ($regie == "DGDA") ? "Sydonia_5 = '" . $paiementid . "'" : "Paiementid_4 = '" . $paiementid . "'";
	                        $where .= " AND Account_3  ='" . $account . "'";

	                        $builder = $this->db->table('logiref_prepayments_cbs_returns')
	                                ->select('logiref_prepayments_cbs_returns.*')
	                                ->where($where)
	                                ->orderBy('Id_0', 'DESC')
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function update_prepayment_cbs_return($response, $bl)
	                {
	                        if($response != "")
	                        {
	                                $data = [
	                                        "Result_6" => json_encode($response)
	                                ];

	                                return $this->db->table('logiref_prepayments_cbs_returns')
	                                        ->where('Sydonia_5', $bl)
	                                        ->update($data);
	                        }
	                }

	                public function update_prepayment_return($response, $paiementid)
	                {
	                        if($response != "")
	                        {
	                                $data = [
	                                        "Result_6" => json_encode($response)
	                                ];

	                                return $this->db->table('logiref_prepayments_cbs_returns')
	                                        ->where('Sydonia_5', $paiementid)
	                                        ->update($data);
	                        }
	                }

	                public function update_cbs_instructions_prepayment($returns)
	                {
	                        $id = "";

	                        if($returns != "")
	                        {
	                                if(isset($returns['200']) && $returns['200'] != "")
	                                {
	                                        $ids = implode(",", $returns['200']);

	                                        if (strpos($ids, ',') !== false):
	                                                $ids =  explode(",", $ids);
	                                        else:
	                                                $ids = array($ids);
	                                        endif;

	                                        $data['Status_2'] = 2;

	                                        $id = $this->db->table('logiref_cbs_prepayments_instructions')
	                                                ->whereIn('Id_0', $ids)
	                                                ->update($data);
	                                }
	                                if(isset($returns['300']) && $returns['300'] != "")
	                                {
	                                        $ids = implode(",", $returns['300']);

	                                        if (strpos($ids, ',') !== false):
	                                                $ids =  explode(",", $ids);
	                                        else:
	                                                $ids = array($ids);
	                                        endif;

	                                        $data['Status_2'] = 5;

	                                        $id = $this->db->table('logiref_cbs_prepayments_instructions')
	                                                ->whereIn('Id_0', $ids)
	                                                ->update($data);
	                                }
	                                if(isset($returns['411']) && $returns['411'] != "")
	                                {
	                                        $ids = implode(",", $returns['411']);

	                                        if (strpos($ids, ',') !== false):
	                                                $ids =  explode(",", $ids);
	                                        else:
	                                                $ids = array($ids);
	                                        endif;

	                                        $data['Status_2'] = 4;

	                                        $id = $this->db->table('logiref_cbs_prepayments_instructions')
	                                                ->whereIn('Id_0', $ids)
	                                                ->update($data);
	                                }
	                                if(isset($returns['404']) && $returns['404'] != "")
	                                {
	                                        $ids = implode(",", $returns['404']);

	                                        if (strpos($ids, ',') !== false):
	                                                $ids =  explode(",", $ids);
	                                        else:
	                                                $ids = array($ids);
	                                        endif;

	                                        $data['Status_2'] = 5;

	                                        $id = $this->db->table('logiref_cbs_prepayments_instructions')
	                                                ->whereIn('Id_0', $ids)
	                                                ->update($data);
	                                }

	                                return $id;
	                        }
	                }

	                public function get_prepayment_integrations_by_id($id)
	                {
	                        $where = " Id_0='".$id."'";
	                        $builder = $this->db->table('logiref_cbs_prepayments_instructions')
	                                ->select('logiref_cbs_prepayments_instructions.*')
	                                ->where($where)
	                                ->orderBy('Id_0', 'DESC')
	                                ->get();

	                        return $builder->getResultArray();
	                }

	                public function get_prepayment_cbs_returns_by_paiementid($paiementid)
	                {
	                        $where = " Sydonia_5='".$paiementid."'";
	                        $builder = $this->db->table('logiref_prepayments_cbs_returns')
	                                ->select('logiref_prepayments_cbs_returns.*')
	                                ->where($where)
	                                ->orderBy('Id_0', 'DESC')
	                                ->get();

	                        return $builder->getResultArray();
	                }
	                
	                public function save_cbs_return_dgda($account, $response, $bl)
	                {
	                        if($response != "")
	                        {
                                $data = [
                                        "Date_1" => date('Y-m-d H:i:s'),
                                        "Status_2" => 1,
                                        "Account_3" => $account,
                                        "Sydonia_5" => $bl,
                                        "Result_6" => json_encode($response)
                                ];

                                $this->db->table("logiref_cbs_returns")
                                        ->insert($data);

                                $id = $this->db->insertID();

                                return $id;
                        }
                }
                
                public function save_cbs_return($account, $response, $id)
                {
                        if($response != "")
                        {
                                $data = [
                                        "Date_1" => date('Y-m-d H:i:s'),
                                        "Status_2" => 1,
                                        "Account_3" => $account,
                                        "Paiementid_4" => $id,
                                        "Result_6" => json_encode($response)
                                ];
                                $this->db->table("logiref_cbs_returns")
                                        ->insert($data);

                                $id = $this->db->insertID();

                                return $id;
                        }
                }
                
                public function update_cbs_return($response, $bl)
                {
                        if($response != "")
                        {
                                $data = [
                                        "Result_6" => json_encode($response)
                                ];

                                $id = $this->db->table("logiref_cbs_returns")
                                        ->where("Sydonia_5 = ".$bl."")
                                        ->update($data);
                                
                                return $id;
                        }
                }
                        
                public function save_prepayment_cbs_return($account, $response, $bl)
                {
                        if($response != "")
                        {
                                $data = [
                                        "Date_1" => date('Y-m-d H:i:s'),
                                        "Status_2" => 1,
                                        "Account_3" => $account,
                                        "Sydonia_5" => $bl,
                                        "Result_6" => json_encode($response)
                                ];
                                $this->db->table("logiref_prepayments_cbs_returns")
                                        ->insert($data);

                                $id = $this->db->insertID();

                                return $id;
                        }
                }
                
                public function update_cbs_instructions_dgi($logirefid)
                {
                        $data = [
                                "Status_2" => 2
                        ];
                        
                        $id = $this->db->table("logiref_cbs_instructions_dgi")
                                ->where("Reference_14",$logirefid)
                                ->update($data);
                                
                        return $id;
                        
                }
                public function update_cbs_instructions_dgrad($logirefid)
                {
                        $data = [
                                "Status_2" => 2
                        ];
                        
                        $id = $this->db->table("logiref_cbs_instructions_dgrad")
                                ->where("Reference_14", $logirefid)
                                ->update($data);
                                
                        return $id;
                }
                public function update_cbs_instructions_dgda($id)
                {
                        $data = [
                                "Status_2" => 2
                        ];
                        
                        $id = $this->db->table("logiref_cbs_instructions_dgda")
                                ->where("Paiementid_4", $id)
                                ->update($data);
                                
                        return $id;
                }

                public function update_cbs_instructions_passport($logirefid,$status,$priority=0)
                {
                        $data = [
                                "Status_2" => $status
                        ];
                        
                        $id = $this->db->table("logiref_cbs_instructions_passeport")
                                ->where("Reference_14", $logirefid)
                                ->where("Priority_27",$priority)
                                ->update($data);
                                
                        return $id;
                }
                        
                public function update_cbs_prepayments_instructions_dgda($id)
                {
                        $data = [
                                "Status_2" => 2
                        ];
                                
                        $id = $this->db->table("logiref_cbs_prepayments_instructions")
                                ->where("Paiementid_4", $id)
                                ->update($data);
                                
                        return $id;
                }
                
                public function update_payment_prepayment($paiementid)
                {
                        if ($paiementid != "") 
                        {
                                $data = [
                                'Status_2' => 5,
                                ];
                        
                                $this->db->table('logiref_sydonia_prepayments')
                                        ->where('Id_0', $paiementid)
                                        ->update($data);
                        
                                return $this->db->affectedRows();
                        }
                }
                public function update_payment_sydonia($paiementid)
                {
                        if($paiementid != "")
                        {
                                $data = [
                                        "Status_2" => 5
                                ];

                                $this->db->table("logiref_integration_sydonia")
                                        ->where("Id_0",$paiementid)
                                        ->update($data);

                                return $this->db->affectedRows();
                        }
                }
                        
                public function update_prepayment_gu_instructions($lot, $data)
                {
                        if($lot != "")
                        {
                                $response = isset($data['response']) ? $data['response'] : 411;
                                $num_evenement = isset($data['Num_evenement']) ? $data['Num_evenement'] : 0;
                                
                                if($response == '200')
                                {
                                
                                        $data = [
                                                "Status_2" => 2,
                                                "Code_22" => $response,
                                                "Returnid_27" => $num_evenement
                                        ];

                                        $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                                ->where("Paiementid_4", $lot)
                                                ->update($data);

                                        return $this->db->affectedRows();
                                }
                                else
                                {
                                        $data = [
                                                "Status_2" => 3,
                                                "Code_22" => $response,
                                                "Returnid_27" => $num_evenement,
                                                "Paiementid_4" => $lot
                                        ];

                                        $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                                ->where("Paiementid_4", $lot)
                                                ->update($data);

                                        return $this->db->affectedRows();
                                }
                        }
                }

                public function update_reference_cbs_instructions_prepayment($id, $reference)
                {
                        $data = [
                                "Reference_14" => $reference
                        ];

                        $this->db->table("logiref_cbs_prepayments_instructions")
                                ->where("Paiementid_4", $id)
                                ->update($data);
                }

                public function get_integrations_dgi_immatriculation_by_id($id)
                {
                        $st = " Id_0='".$id."'";
                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        $result = $query->getResultArray();

                        return $result;
                }

                public function get_cbs_returns_immatriculation_by_paiementid($paiementid)
                {
                        $account = $this->session->userdata['account_id'];

                        $st = "Paiementid_4 = '" . $paiementid . "'";
                        $st .= " AND Account_3  ='" . $account . "'";

                        $query = $this->db->table('logiref_cbs_returns_immatriculation')
                                ->select('logiref_cbs_returns_immatriculation.*')
                                ->where($st)
                                ->get();

                        return $query->getResultArray();
                }

                public function get_integrations_info_immatriculation_online($ref)
                {
                        $st = "Status_2=1  AND  Paiementid_4 ='".$ref."'";

                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();

                        $result = $query->getResultArray();

                        return $result;
                }

                public function get_integrations_info_immatriculation_agence($ref)
                {
                        $st = "Status_2=1  AND  Paiementid_4 ='".$ref."'";

                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();

                        $result = $query->getResultArray();

                        return $result;
                }

                public function get_integrations_info_immatriculation($ref,$priority=null,$status=null)
                {
                        $st = " Paiementid_4 ='".$ref."'";

                        if(isset($priority))
                        {
                                $st.=" AND Priority_27='".$priority."'";
                        }

                        if($status!=NULL)
                        {
                                $st.=" AND Status_2='".$status."'";
                        }

                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();

                        $result = $query->getResultArray();

                        return $result;
                }

                public function get_integrations_info_immatriculation_to_regularize($ref,$priority=null)
                {
                        $st = " Paiementid_4 ='".$ref."' AND Status_2 IN('1','5','3')";

                        if(isset($priority))
                        {
                                $st.=" AND Priority_27='".$priority."'";
                        }

                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        $result = $query->getResultArray();

                        return $result;
                }

                public function save_cbs_return_immatriculation($data, $id)
                {
                        $this->set_table('logiref_cbs_returns_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function update_cbs_return_immatriculation($response, $bl)
                {
                        if($response != "")
                        {
                                $data['Result_6'] = json_encode($response);

                                $id = $this->db->table('logiref_cbs_returns_immatriculation')
                                        ->where('Sydonia_5', $bl)
                                        ->update($data);

                                return $id;
                        }
                }

                public function update_cbs_instructions_dgi_immatriculation($returns)
                {
                        $id = "";

                        if($returns != "")
                        {
                                if(isset($returns['200']) && $returns['200'] !="")
                                {
                                        $ids = implode(",", $returns['200']);

                                        if (strpos($ids, ',') !== false):
                                                $ids =  explode(",", $ids);
                                        else:
                                                $ids = array($ids);
                                        endif;

                                        $data['Status_2'] = 2;

                                        $id = $this->db->table('logiref_cbs_instructions_immatriculation')
                                                ->whereIn('Id_0', $ids)
                                                ->update($data);
                                }
                                if(isset($returns['300']) && $returns['300'] !="")
                                {
                                        $ids = implode(",", $returns['300']);

                                        if (strpos($ids, ',') !== false):
                                                $ids =  explode(",", $ids);
                                        else:
                                                $ids = array($ids);
                                        endif;

                                        $data['Status_2'] = 5;

                                        $id = $this->db->table('logiref_cbs_instructions_immatriculation')
                                                ->whereIn('Id_0', $ids)
                                                ->update($data);
                                }
                                if(isset($returns['411']) && $returns['411'] !="")
                                {
                                        $ids = implode(",", $returns['411']);

                                        if (strpos($ids, ',') !== false):
                                                $ids =  explode(",", $ids);
                                        else:
                                                $ids = array($ids);
                                        endif;

                                        $data['Status_2'] = 4;

                                        $id = $this->db->table('logiref_cbs_instructions_immatriculation')
                                                ->whereIn('Id_0', $ids)
                                                ->update($data);
                                }
                                if(isset($returns['404']) && $returns['404'] !="")
                                {
                                        $ids = implode(",", $returns['404']);

                                        if (strpos($ids, ',') !== false):
                                                $ids =  explode(",", $ids);
                                        else:
                                                $ids = array($ids);
                                        endif;

                                        $data['Status_2'] = 5;

                                        $id = $this->db->table('logiref_cbs_instructions_immatriculation')
                                                ->whereIn('Id_0', $ids)
                                                ->update($data);
                                }

                                return $id;
                        }
                }

                //Save Log
                public function save_log($data, $prefix = NULL)
                {
                        $name = gmdate('Y-m-d')."_".$prefix;

                        $path = ROOTPATH . 'drive/logs/services/Finacle';

                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }

                        $path = $path."/".$name;

                        $handle = fopen($path.".logs", 'a+');
                        $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                        fwrite($handle, $data."\n\n");
                        fclose($handle);
                }
        }
