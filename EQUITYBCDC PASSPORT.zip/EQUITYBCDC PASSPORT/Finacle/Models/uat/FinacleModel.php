<?php 
/**
 * Description of LogirefClass
 * Contains all Model Methodes
 * @author Glodi
 */
namespace Modules\Services\Finacle\Models;

use App\Models\MY_Transaction;

class FinacleModel extends MY_Transaction{
        
	function __construct()
        {
                parent::__construct();
	}
        
        public function payment_transfer($data)
        {
                #### url du web service
                $url = "https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp";
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                $this->save_log($xml);
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "virement");
                        $this->save_log($return, "virement");

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function add_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "reservation");
                        $this->save_log($return, "reservation");
                        $this->save_log($result, "reservation");
                        $this->save_log($result, "reservation");

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function inquiry_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml);
                        $this->save_log($return);
                        $this->save_log($result);
                        $this->save_log($result);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function release_lien_account($data)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);
						
			//echo $return; die;

                        $response = json_decode($result, true);
                        $this->save_log($xml,  "cancel_reservation");
                        $this->save_log($return, "cancel_reservation");
                        $this->save_log($result, "cancel_reservation");
                        $this->save_log($result, "cancel_reservation");

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function exchange_rate($data, $prefix_logs = NULL)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
			//echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "exchange_rate_".$prefix_logs);
                        $this->save_log($return, "exchange_rate_".$prefix_logs);
                        $this->save_log($result, "exchange_rate_".$prefix_logs);
                        $this->save_log($result, "exchange_rate_".$prefix_logs);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function tax_exempt($data)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
						
                        //echo $return; die;
						
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml);
                        $this->save_log($return);
                        $this->save_log($result);
                        $this->save_log($result);

                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        public function account_info($data)
        {
                #### url du web service
                $url = 'https://finacledevdrc.ebsafrica.com:11500/FISERVLET/fihttp';
                
                $xml_data = new \SimpleXMLElement('<?xml version="1.0"?><FIXML xmnls="http://www.finacle.com/fixml"></FIXML>');
                $this->array_to_xml($data,$xml_data);
                $xml = $xml_data->asXML();
                
                //echo $xml; die;
                
                $response = "";
                
                $options = array(
                        'http' => array(
                                'method'  =>  'POST',
                                'timeout'=>120,
                                'header' => 'Content-Type: application/xml',
                                'content' => $xml
                        ),
                        'ssl'=>array(
                            'verify_peer'=>false,
                            'verify_peer_name'=>false,
                            'ciphers'=>'DEFAULT:!DH'
							
                        )

                ); 
                try
                {
                        $context  = stream_context_create( $options );
                        $return = file_get_contents( $url, false, $context );
		
			//echo $return; die;
			
                        $xml_string = simplexml_load_string($return);
                        $result = json_encode($xml_string);

                        $response = json_decode($result, true);
                        $this->save_log($xml, "account_info");
                        $this->save_log($return, "account_info");
                        $this->save_log($result, "account_info");
						
                        return $response;
                }
                catch (\Exception $ex)
                {
                        return '406';
                }
        }
        
        public function array_to_xml( $data, &$xml_data ) {
            
            foreach( $data as $key => $value ) {
                if( is_array($value) ) {
                    if( is_numeric($key) ){
                        $key = 'PartTrnRec';
                    }
                    $subnode = $xml_data->addChild($key);
                    $this->array_to_xml($value, $subnode);
                } else {
                    $xml_data->addChild("$key",htmlspecialchars("$value"));
                }
            }
        }
        
        public function get_integrations_info_dgda($id, $priority)
        {
                $where = "Paiementid_4 = ".$id." AND Priority_24 = ".$priority." AND Status_2 != 2 ";
                $builder = $this->db->table("logiref_cbs_instructions_dgda")
                        ->select("logiref_cbs_instructions_dgda.*")
                        ->where($where)
                        ->get();
                
                return $builder->getResult();
        }
        
        public function get_integrations_info_dgi($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgi")
                        ->select("logiref_cbs_instructions_dgi.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1")
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function get_integrations_info_dgrad($ref)
        {
                $builder = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->select("logiref_cbs_instructions_dgrad.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1")
                        ->get();
                
                return $builder->getResult();
        }

        public function get_integrations_info_passport($ref,$priority=0)
        {
                $builder = $this->db->table("logiref_cbs_instructions_passeport")
                        ->select("logiref_cbs_instructions_passeport.*")
                        ->where("Reference_14 LIKE '%".$ref."%' AND Status_2 = 1 AND Priority_27 = ".$priority."")
                        ->get();
                return $builder->getResultArray();
        }
		
	public function get_prepayment_integrations_info($id, $priority)
        {
                $builder = $this->db->table("logiref_cbs_prepayments_instructions")
                        ->select("logiref_cbs_prepayments_instructions.*")
                        ->where("Paiementid_4 = ".$id." AND Status_2 = 1 AND Priority_24 = ".$priority."")
                        ->get();
                
                return $builder->getResult();
        }
		
	public function get_prepayment_gu_integrations_info($lot)
        {
                $builder = $this->db->table("logiref_cbs_prepayments_gu_instructions")
                        ->select("logiref_cbs_prepayments_gu_instructions.*")
                        ->where("Paiementid_4 = ".$lot." AND Status_2 = 1")
                        ->get();
                
                return $builder->getResult();
        }
        
        public function save_cbs_return_dgda($account, $response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => NOW(),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Sydonia_5" => $bl,
                                "Result_6" => json_encode($response)
                        ];

                        $this->db->table("logiref_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function save_cbs_return($account, $response, $id)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => date('Y-m-d H:i:s'),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Paiementid_4" => $id,
                                "Result_6" => json_encode($response)
                        ];
                        $this->db->table("logiref_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function update_cbs_return($response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Result_6" => json_encode($response)
                        ];

                        $id = $this->db->table("logiref_cbs_returns")
                                ->where("Sydonia_5 = ".$bl."")
                                ->update($data);
                        
                        return $id;
                }
        }
		
        public function save_prepayment_cbs_return($account, $response, $bl)
        {
                if($response != "")
                {
                        $data = [
                                "Date_1" => NOW(),
                                "Status_2" => 1,
                                "Account_3" => $account,
                                "Sydonia_5" => $bl,
                                "Result_6" => json_encode($response)
                        ];
                        $this->db->table("logiref_prepayments_cbs_returns")
                                ->insert($data);

                        $id = $this->db->insertID();

                        return $id;
                }
        }
        
        public function update_cbs_instructions_dgi($logirefid)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgi")
                        ->where("Reference_14",$logirefid)
                        ->update($data);
                        
                return $id;
                
        }
        public function update_cbs_instructions_dgrad($logirefid)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgrad")
                        ->where("Reference_14", $logirefid)
                        ->update($data);
                        
                return $id;
        }

        public function update_cbs_instructions_passport($logirefid)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_passeport")
                        ->where("Reference_14", $logirefid)
                        ->update($data);
                        
                return $id;
        }
        public function update_cbs_instructions_dgda($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                
                $id = $this->db->table("logiref_cbs_instructions_dgda")
                        ->where("Paiementid_4", $id)
                        ->update($data);
                        
                return $id;
        }
		
	public function update_cbs_prepayments_instructions_dgda($id)
        {
                $data = [
                        "Status_2" => 2
                ];
                        
                $id = $this->db->table("logiref_cbs_prepayments_instructions")
                        ->where("Paiementid_4", $id)
                        ->update($data);
                        
                return $id;
        }
        
        public function update_payment_prepayment($paiementid)
        {
                if ($paiementid != "") 
                {
                        $data = [
                            'Status_2' => 5,
                        ];
                    
                        $this->db->table('logiref_sydonia_prepayments')
                                 ->where('Id_0', $paiementid)
                                 ->update($data);
                    
                        return $this->db->affectedRows();
                }
        }
        public function update_payment_sydonia($paiementid)
        {
                if($paiementid != "")
                {
                        $data = [
                                "Status_2" => 5
                        ];

                        $this->db->table("logiref_integration_sydonia")
                                ->where("Id_0",$paiementid)
                                ->update($data);

                        return $this->db->affectedRows();
                }
        }
		
	public function update_prepayment_gu_instructions($lot, $data)
        {
                if($lot != "")
                {
                        $response = isset($data['response']) ? $data['response'] : 411;
                        $num_evenement = isset($data['Num_evenement']) ? $data['Num_evenement'] : 0;
                        
                        if($response == '200')
                        {
                            
                                $data = [
                                        "Status_2" => 2,
                                        "Code_22" => $response,
                                        "Returnid_27" => $num_evenement
                                ];

                                $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                        ->where("Paiementid_4", $lot)
                                        ->update($data);

                                return $this->db->affectedRows();
                        }
                        else
                        {
                                $data = [
                                        "Status_2" => 3,
                                        "Code_22" => $response,
                                        "Returnid_27" => $num_evenement,
                                        "Paiementid_4" => $lot
                                ];

                                $this->db->table("logiref_cbs_prepayments_gu_instructions")
                                        ->where("Paiementid_4", $lot)
                                        ->update($data);

                                return $this->db->affectedRows();
                        }
                       
                }
        }
	public function update_reference_cbs_instructions_prepayment($id, $reference)
        {
                $data = [
                        "Reference_14" => $reference
                ];

                $this->db->table("logiref_cbs_prepayments_instructions")
                        ->where("Paiementid_4", $id)
                        ->update($data);
        }
        //Save Log
        public function save_log($data, $prefix = NULL)
        {
                $name = gmdate('Y-m-d')."_".$prefix;

                $path = ROOTPATH . 'drive/logs/services/Finacle';

                if (is_dir($path)==false)
                {
                        mkdir($path,0777,true);
                }

                $path = $path."/".$name;

                $handle = fopen($path.".logs", 'a+');
                $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                fwrite($handle, $data."\n\n");
                fclose($handle);
        }
}