<?php 
namespace Modules\Services\Comptabilisation\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;


class ComptabilisationSeguce extends BaseController {
        
        public $comptabilisationModel;
        public $logirefModel;
        public $accountModel;
        public $branchModel;
        public $bank;
        public $account;
        public $options;

        const TYPE_PRINCIPAL = 'P';
        const TYPE_FRAIS     = 'F';
        const TYPE_TVA       = 'T';
        
        
        public function __construct()
	{
		parent::__construct();
                
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->logirefModel = new LogirefModel();
                $this->accountModel = new AccountModel();
                $this->branchModel = new BranchModel();
                
                $this->account = isset($this->session->userdata['account_id'])?$this->session->userdata['account_id']:"";
                $this->bank = isset($this->session->userdata["account_pageid"])?$this->session->userdata["account_pageid"]:"";
                
                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank = ucfirst($this->bank);
                }
                
                # Retrieve options configured based on the bank connected
                if(isset($_SESSION['userdata']['options']))
                {
                        $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->options = array();
                }
	}

        /**
         * Génère toutes les instructions comptables pour une opération SEGUCE.
         *
         * @param array $data Données de l’opération (comptes, devises, montants).
         * @return array Liste des instructions comptables.
         */
        public function get_instructions_seguce($data)
        {
                $instructions = [];
                $agence       = $_SESSION['Logiref_guichet'] ?? $data['Logiref_guichet'] ?? null;
                $bank         = !empty($this->bank )? $this->bank : $data['bank'] ?? null;
                $beneficiary  = "'$bank'";

                # Récupération des comptes nécessaires pour l'opération générale.
                $comptes = $this->get_comptes_array("'CSC','CSG','CFG','CTS'", $beneficiary, $agence, $data);
     
                # Conversion du montant principal
                $return = $this->get_amount_converted($data, 'montant_principal');
                $montant_debit  = $return['montant_debit'] ?? '';
                $montant_credit = $return['montant_credit'] ?? '';

                # Définir libellé principal
                $libelle = $this->get_transactions_libelle('CSG', $data, 'DGDA');

                # Déterminer devises (débit, crédit) pour le principal
                list($debit_currency, $credit_currency) = $this->resolve_currencies($data, true);

                # Instruction principale (compte client -> compte CSG)
                $instructions[] = [
                        'Operation_8'   => 'V',
                        'Compte_9'      => $data['Compte_33'],
                        'Libelle_12'    => $libelle,
                        'Montant_10'    => $montant_debit,
                        //'Devise_11'     => $data['Devise_34'],
                        'Devise_11'     => "CDF",
                        'Montant_26'    => $montant_credit,
                        'Devise_27'     => $data['Devise_34'],
                        'Compte_13'     => $comptes['CSG'],
                        'Priority_24'   => 0,
                        'TypeCompte_30' => self::TYPE_PRINCIPAL
                ];

                # Ajouter instructions frais
                $instructions = array_merge($instructions, $this->get_fees_instructions($data, $comptes, $debit_currency, $credit_currency));

                # Ajouter instructions TVA
                $instructions = array_merge($instructions, $this->get_fees_tva_instructions($data, $comptes, $debit_currency, $credit_currency));

                # Ajouter instructions SEGUCE
                $instructions = array_merge($instructions, $this->get_seguce_instructions($data, $agence));

                return $instructions;
        }

        /**
         * Génère les instructions liées aux frais de commission.
         *
         * @param array $data Données de l’opération.
         * @param array $comptes Tableau des comptes disponibles.
         * @param string $debit_currency Devise du débit.
         * @param string $credit_currency Devise du crédit.
         * @return array Instructions de frais (peut être vide).
         */
        private function get_fees_instructions($data, $comptes, $debit_currency, $credit_currency)
        {
                $instructions = [];

                $return = $this->get_amount_converted($data, 'commission');
                $montant_debit_frais  = $return['montant_debit'] ?? 0;
                $montant_credit_frais = $return['montant_credit'] ?? 0;

                if ($montant_debit_frais > 0) 
                {
                        $libelle = $this->get_transactions_libelle('CFG', $data, null);

                        $instructions[] = [
                                'Operation_8' => 'V',
                                'Compte_9'    => $data['Compte_33'],
                                'Libelle_12'  => $libelle,
                                'Montant_10'  => $montant_debit_frais,
                                'Devise_11'   => $debit_currency,
                                'Montant_26'  => $montant_credit_frais,
                                'Devise_27'   => $credit_currency,
                                'Compte_13'   => $comptes['CFG'] ?? null,
                                'Priority_24'   => 0,
                                'TypeCompte_30' => self::TYPE_FRAIS
                        ];
                }

                return $instructions;
        }

        /**
         * Génère les instructions liées à la TVA sur les frais.
         *
         * @param array $data Données de l’opération.
         * @param array $comptes Tableau des comptes disponibles.
         * @param string $debit_currency Devise du débit.
         * @param string $credit_currency Devise du crédit.
         * @return array Instructions TVA (peut être vide).
         */
        private function get_fees_tva_instructions($data, $comptes, $debit_currency, $credit_currency)
        {
                $instructions = [];

                $return = $this->get_amount_converted($data, 'CTS');
                $montant_debit_tva  = $return['montant_debit'] ?? 0;
                $montant_credit_tva = $return['montant_credit'] ?? 0;

                if ($montant_debit_tva > 0) 
                {
                        $libelle = $this->get_transactions_libelle('CTS', $data, null);

                        $instructions[] = [
                                'Operation_8' => 'V',
                                'Compte_9'    => $data['Compte_33'],
                                'Libelle_12'  => $libelle,
                                'Montant_10'  => $montant_debit_tva,
                                'Devise_11'   => $debit_currency,
                                'Montant_26'  => $montant_credit_tva,
                                'Devise_27'   => $credit_currency,
                                'Compte_13'   => $comptes['CTS'] ?? null,
                                'Priority_24'   => 0,
                                'TypeCompte_30 ' => self::TYPE_TVA
                        ];
                }

                return $instructions;
        }

        /**
         * Génère les instructions spécifiques SEGUCE.
         *
         * @param array $data Données de l’opération.
         * @param string $agence Code agence.
         * @return array Instructions SEGUCE (peut être vide).
         */
        private function get_seguce_instructions($data, $agence)
        {
                $instructions = [];
                $bank         = !empty($this->bank )? $this->bank : $data['bank'] ?? null;
                $beneficiary  = "'SEGUCE', '$bank'";

                # Récupération des comptes spécifiques SEGUCE
                $comptes = $this->get_comptes_array("'CSC','CSG','CFG','CTS'", $beneficiary, $agence, $data);

                $compte_src = $comptes['CSG'] ?? null;
                $compte_dst = $comptes['CSC'] ?? null;

                # Conversion montant principal
                $return = $this->get_amount_converted($data, 'montant_principal');
                $montant_debit  = $return['montant_debit'] ?? 0;
                $montant_credit = $return['montant_credit'] ?? 0;

                # Définir libellé SEGUCE
                $libelle = $this->get_transactions_libelle('CSC', $data, 'SEGUCE');

                if ($compte_src && $compte_dst && ($montant_debit > 0 || $montant_credit > 0)) 
                {
                        $instructions[] = [
                                'Operation_8' => 'V',
                                'Compte_9'    => $compte_src,
                                'Libelle_12'  => $libelle,
                                'Montant_10'  => $montant_debit,
                                'Devise_11'   => 'CDF',
                                'Compte_13'   => $compte_dst,
                                'Montant_26'  => $montant_credit,
                                'Devise_27'   => 'CDF',
                                'Priority_24'   => 1,
                                'TypeCompte_30' => self::TYPE_PRINCIPAL
                        ];
                }

                return $instructions;
        }

        /**
         * Résout les devises utilisées pour une opération.
         *
         * @param array $data Données de l’opération.
         * @param bool $is_principal Indique si l’opération concerne le montant principal.
         * @return array [debit_currency, credit_currency]
         */
        private function resolve_currencies($data, $is_principal = false)
        {
                if (isset($this->options['ALL']['cross-currency-exception'])) 
                {
                        if ($is_principal && ($data['Devise_34'] ?? '') === 'USD' && ($data['Devise_12'] ?? '') === 'CDF') 
                        {
                                return [$data['Devise_12'], $data['Devise_12']];
                        }

                        return [$data['Devise_34'] ?? null, $data['Devise_34'] ?? null];
                }

                return [
                        $data['Devise_34'] ?? null,
                        $is_principal ? ($data['Devise_12'] ?? null) : ($data['Devise_24'] ?? null)
                ];
        }

        /**
         * Récupère et structure les comptes nécessaires à une opération SEGUCE.
         *
         * Cette fonction interroge le modèle `accountModel` pour obtenir les comptes
         * disponibles en fonction d’une liste de codes, d’un bénéficiaire et d’une agence.
         *
         * @param string $liste        Liste des codes de comptes (ex: "'CGU','CSG','CFG','CTS','FBC','CTA','CTR'").
         * @param string $beneficiary  Bénéficiaire ou contexte du paiement.
         * @param string $agence       Code agence.
         * @param array  $data         Données de l’opération (incluant les devises).
         *
         * @return array Tableau associatif des comptes structurés [] :
         */
        public function get_comptes_array($liste, $beneficiary, $agence, $data) 
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
            
                $account_line_csc = array();
                $account_line_cfb = array();
                $account_line_tva = array();
                $account_line_csg = array();
                $account_cfb = "";
                $account_tva = "";
                $account_csg = "";
          
                $tab_comptes = $this->accountModel->get_comptes_seguce($liste, $beneficiary, $agence, NULL, $data['Account'] ?? ""); 
                
                if(!empty($tab_comptes))
                {
                        # Recuperer le compte CPT
                        foreach ($tab_comptes as $row) 
                        {
                                if(isset($row['Type_4']) && $row['Type_4'] == 'CSG')
                                {
                                        $account_line_csg = $row;
                                }
                        }
                        
                        $account_csg = $this->get_the_account_structured($account_line_csg, $data['bank'] ?? "");
                        
                        # Recuperer le compte CSC
                        foreach ($tab_comptes as $row) 
                        {
                                if(isset($row['Type_4']) && $row['Type_4'] == 'CSC')
                                {
                                        $account_line_csc = $row;
                                }
                        }
                        
                        $account_csc = $this->get_the_account_structured($account_line_csc, $data['bank'] ?? "");

                        # Recuperer le compte CFB, TVA, FBC
                        foreach ($tab_comptes as $row) 
                        {
                                if(isset($this->options['ALL']['cross-currency-exception']))
                                {
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CFG' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_cfb = $row;
                                        }

                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CTS' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_tva = $row;
                                        }
                                }
                                else
                                {
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CFG')
                                        {
                                                $account_line_cfb = $row;
                                        }
         
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CTS')
                                        {
                                                $account_line_tva = $row;
                                        }
                                }
                        }

                        $account_cfb = $this->get_the_account_structured($account_line_cfb, $data['bank'] ?? "");
                        $account_tva = $this->get_the_account_structured($account_line_tva, $data['bank'] ?? "");
                        $account_csg = $this->get_the_account_structured($account_line_csg, $data['bank'] ?? "");

                        $account_array = array(
                                            'CSC'=>$account_csc,
                                            'CFG'=>$account_cfb,
                                            'CTS'=>$account_tva,
                                            'CSG'=>$account_csg
                                        );
                }
                else
                {
                        $account_array = array(
                                            'CSC'=>'000000000000000000000000',
                                            'CFG'=>'000000000000000000000000',
                                            'CTS'=>'000000000000000000000000',
                                            'CSG'=>'000000000000000000000000'
                                        );
                }
                
                return $account_array;
        }

        /**
         * Construit la représentation structurée d’un compte bancaire.
         *
         * Cette fonction assemble les différentes parties d’un compte (Agence, Compte,
         * Clé, Code numérique) pour produire une chaîne unique. Elle adapte le format
         * selon la banque (Sofibanque, Boa, Standardbank) et gère le cas où les données
         * sont manquantes.
         *
         * @param array  $account_array Tableau contenant les informations du compte
         *                              (Agenceid_15, Compte_6, Clef_7, Numericcode_19).
         * @param string|null $bank     Nom de la banque (optionnel, par défaut $this->bank).
         *
         * @return string Compte structuré sous forme de chaîne (ex: "AGENCE-COMPTE-CLEF-CODE").
         *                Retourne une valeur par défaut "000000000000000000000000" si vide.
         */
        public function get_the_account_structured($account_array, $bank = NULL)
        {
                $account = "";

                if(!empty($account_array))
                {
                        if($account_array['Agenceid_15'] !="" && $account_array['Numericcode_19'] !="" && $account_array['Clef_7'] !="")
                        {
                                $account = $account_array['Agenceid_15']."-".$account_array['Compte_6']."-".$account_array['Clef_7']."-".$account_array['Numericcode_19'];
                        }
                        elseif($account_array['Agenceid_15'] !="" && $account_array['Clef_7'] !="")
                        {
                                $account = $account_array['Agenceid_15']."-".$account_array['Compte_6']."-".$account_array['Clef_7'];
                        }
                        elseif($account_array['Agenceid_15'] !="")
                        {
                                $account = $account_array['Agenceid_15']."-".$account_array['Compte_6'];
                        }
                        else
                        {
                                $account = $account_array['Compte_6'];
                        }

                        if($bank == 'Sofibanque')
                        {
                                $account = $account_array['Compte_6'];
                        }

                        if($bank == 'Boa')
                        {
                                $account = $account_array['Compte_6'];
                        }

                        if($bank == 'Standardbank')
                        {
                                $account = $account_array['Compte_6'];
                        }
                }
                else
                {
                        $account = '000000000000000000000000';
                }

                return $account;
        }

        /**
         * Convertit les montants d’une opération en fonction du type (principal, commission, TVA),
         * des devises impliquées et des règles spécifiques à la banque.
         * Les montants débit et crédit sont arrondis à deux décimales.
         *
         * @param array  $data   Données de l’opération (Montant_11, Commission_23, Taux_41, Devise_12, Devise_24, Devise_34, etc.).
         * @param string $type   Type de montant à convertir ('montant_principal', 'commission', 'CTS').
         * @param float|null $amount Montant optionnel à utiliser (par défaut NULL, utilise les champs de $data).
         *
         * @return array Tableau associatif contenant :
         *          
         */
        public function get_amount_converted($data, $type, $amount = NULl)
        {
                $montant_debit = '';
                $montant_credit = '';
                
                if($type == 'montant_principal')
                {
                        if($this->bank == 'Boa')
                        {
                                if($data['Devise_12'] == 'CDF' && $data['Devise_34'] == 'USD')
                                {
                                        $montant_debit = $data['Montant_11']/($data['Taux_41'] - (($data['Taux_41']*2.5)/100));
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == 'CDF' && $data['Devise_34'] == 'EUR')
                                {
                                        $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == 'USD' && $data['Devise_34'] == 'CDF') 
                                {
                                        $montant_debit = $data['Montant_11']*($data['Taux_41'] + ($data['Taux_41']*2.5/100));
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == 'USD' && $data['Devise_34'] == 'EUR') 
                                {
                                        $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == $data['Devise_34']) 
                                {
                                        $montant_debit = $montant_credit = $data['Montant_11'];
                                }
                        }
                        else
                        {
                                # Montant de la note
                                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                                {
                                        $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                                {
                                        $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                                        $montant_credit = $data['Montant_11'];
                                }
                                elseif($data['Devise_12'] == $data['Devise_34']) 
                                {
                                        $montant_debit = $montant_credit = $data['Montant_11'];
                                }
                        }

                        if(isset($this->options['ALL']['cross-currency-exception']))
                        {
                                if(isset($data['transit_account_currency']))
                                {
                                        if($data['Devise_34'] =='CDF' && $data['Devise_12']=='CDF')
                                        {
                                                $montant_debit = $data['Montant_11'];
                                                $montant_credit = $data['Montant_11'];
                                        }
                                        elseif((isset($data['cpt_currency']) && $data['cpt_currency']=='CDF') && $data['Devise_34']=='CDF')
                                        {
                                                $montant_debit = $data['Montant_11'];
                                                $montant_credit = $data['Montant_11']*$data['Taux_41'];
                                        }
                                        elseif((isset($data['cpt_currency']) && $data['cpt_currency']=='CDF') && $data['Devise_34']=='USD')
                                        {
                                                $montant_debit = $data['Montant_11'];
                                                $montant_credit = $data['Montant_11'];
                                        }
                                        else
                                        {
                                                $montant_debit = $data['Montant_11'];
                                                $montant_credit = $data['Montant_11'];
                                        }
                                        
                                }
                                else
                                {
                                        if($data['Devise_34'] =='USD' && $data['Devise_12']=='CDF')
                                        {
                                                $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                                                $montant_credit = $data['Montant_11'];
                                        }
                                        elseif($data['Devise_34'] =='CDF' && $data['Devise_12']=='USD')
                                        {
                                                $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                                                $montant_credit = $data['Montant_11'];
                                        }
                                        else 
                                        {
                                                $montant_debit = $montant_credit = $data['Montant_11'];
                                        }
                                }
                                
                                
                                
                        }
                }
                elseif($type == 'commission')
                {
                        if($this->bank == 'Boa')
                        {
                                if($data['Devise_24'] == 'CDF' && $data['Devise_34'] == 'USD')
                                {
                                        $montant_debit = $data['Commission_23']/($data['Taux_41'] - ($data['Taux_41']*2.5/100));
                                        $montant_credit = $data['Commission_23'];
                                }
                                elseif($data['Devise_24'] == 'CDF' && $data['Devise_34'] == 'EUR')
                                {
                                        $montant_debit = $data['Commission_23'] / $data['Taux_41'];
                                        $montant_credit = $data['Commission_23'];
                                }
                                elseif($data['Devise_24'] == 'USD' && $data['Devise_34'] == 'CDF') 
                                {
                                        $montant_debit = $data['Commission_23']*($data['Taux_41'] + ($data['Taux_41']*2.5/100));
                                        $montant_credit = $data['Commission_23'];
                                }
                                elseif($data['Devise_24'] == 'USD' && $data['Devise_34'] == 'EUR') 
                                {
                                        $montant_debit = $data['Commission_23'] * $data['Taux_41'];
                                        $montant_credit = $data['Commission_23'];
                                }
                                elseif($data['Devise_24'] == $data['Devise_34']) 
                                {
                                        $montant_debit = $montant_credit = $data['Commission_23'];
                                }
                        }
                        else
                        {
                                if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                                {
                                        $montant_debit = $data['Commission_23'] / $data['Taux_41'];
                                        $montant_credit = $data['Commission_23'];
                                }
                                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                {
                                        $montant_debit = $data['Commission_23'] * $data['Taux_41'];
                                        $montant_credit = $data['Commission_23'];
                                }
                                else 
                                {
                                        $montant_debit = $montant_credit = $data['Commission_23'];
                                }
                        }
                        
                        if($data['Devise_12']!=$data['Devise_34'])
                        {
                                //This option get correspondent amounts or fees based on client account
                                if(isset($this->options['ALL']['cross-currency-exception']))
                                {
                                        if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                                        {
                                                $montant_debit = $data['Commission_23'] / $data['Taux_41'];
                                                $montant_credit = $data['Commission_23']/$data['Taux_41'];
                                        }
                                        elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                        {
                                                $montant_debit = $data['Commission_23']  * $data['Taux_41'];
                                                $montant_credit = $data['Commission_23'] * $data['Taux_41'];
                                        }
                                        else 
                                        {
                                                $montant_debit = $montant_credit = $data['Commission_23'];
                                        }
                                }
                        }
                }
                elseif($type == 'CTS')
                {
                        if($this->bank == 'Boa')
                        {
                                $montant_tva = $data['Commission_23'] * 0.16;

                                if($data['Devise_24'] == 'CDF' && $data['Devise_34'] == 'USD')
                                {
                                        $montant_debit = $montant_tva /($data['Taux_41'] - ($data['Taux_41']*2.5/100));
                                        $montant_credit = $montant_tva;
                                }
                                elseif($data['Devise_24'] == 'CDF' && $data['Devise_34'] == 'EUR')
                                {
                                        $montant_debit = $montant_tva / $data['Taux_41'];
                                        $montant_credit = $montant_tva;
                                }
                                elseif($data['Devise_24'] == 'USD' && $data['Devise_34'] == 'CDF') 
                                {
                                        $montant_debit = $montant_tva * ($data['Taux_41'] + ($data['Taux_41']*2.5/100));
                                        $montant_credit = $montant_tva;
                                }
                                elseif($data['Devise_24'] == 'USD' && $data['Devise_34'] == 'EUR') 
                                {
                                        $montant_debit = $montant_tva * $data['Taux_41'];
                                        $montant_credit = $montant_tva;
                                }
                                elseif($data['Devise_24'] == $data['Devise_34']) 
                                {
                                        $montant_debit = $montant_credit = $montant_tva;
                                }
                        }
                        else
                        {
                                if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                                {
                                        $montant = $data['Commission_23']*0.16;

                                        $montant_debit = $montant / $data['Taux_41'];

                                        $montant_credit = $montant;
                                }
                                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                {
                                        $montant = $data['Commission_23']*0.16;

                                        $montant_debit = $montant * $data['Taux_41'];

                                        $montant_credit = $montant;
                                }
                                else 
                                {
                                        $montant = $data['Commission_23']*0.16;
                                        $montant_debit = $montant_credit = $montant;
                                }
                        }
                        
                        if($data['Devise_12']!=$data['Devise_34'])
                        {
                                //This option get correspondent amounts or fees based on client account
                                if(isset($this->options['ALL']['cross-currency-exception']))
                                {
                                        if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                                        {
                                                $montant = $data['Commission_23']*0.16;
                                                
                                                $montant_debit = $montant / $data['Taux_41'];
                                                $montant_credit = $montant / $data['Taux_41'];
                                        }
                                        elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                        {
                                                $montant = $data['Commission_23']*0.16;

                                                $montant_debit = $montant * $data['Taux_41'];

                                                $montant_credit = $montant * $data['Taux_41'];
                                        }
                                        else 
                                        {
                                                $montant = $data['Commission_23']*0.16;
                                                $montant_debit = $montant_credit = $montant;
                                        }
                                }
                        }
                }
                
                # arrondissement des montantS deux rangs apres la virgiule
                
                if($montant_debit > 0 && $montant_credit > 0)
                {
                        $montant_debit = round($montant_debit, 2);
                        $montant_credit = round($montant_credit, 2);
                }
                
                $arr = array(
                            'montant_debit'=>$montant_debit, 
                            'montant_credit'=>$montant_credit
                        );
                
                return $arr;
        }

        /**
         * Génère le libellé (intitulé) d’une transaction comptable en fonction du type,
         * des données de l’opération et de la banque concernée.
         *
         *
         * @param string $type         Type de transaction ('CSG', 'CFG', 'CTS', 'CSC').
         * @param array  $data         Données de l’opération (reference, Designation_14, Beneficaire_15, Typerecette_17, Noteid_26, Nif_13).
         * @param string $regie        Régie ou contexte de l’opération.
         * @param string|null $beneficiaire Bénéficiaire optionnel.
         * @param string|null $services     Services optionnels.
         * @param string|null $refinss      Référence INSS optionnelle.
         * @param string|null $print        Indicateur d’impression optionnel.
         *
         * @return string Libellé formaté de la transaction.
         *                // ou "Recette Designation" (autres banques)
         */

        public function get_transactions_libelle($type, $data, $regie, $beneficiaire = NULL, $services= NULL, $refinss = NULL, $print = NULL)
        {
                $periode = '';
                $libelle = "";

                if($type == 'CSG')
                {
                        if($this->bank=="Standardbank")
                        {
                                $ref_op = $_POST['reference'] ?? "";

                                $libelle = "PYT ". $ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                        }
                        else
                        {
                                $libelle = $data['Typerecette_17'].' '.$data['Designation_14'];
                        }
                }
                elseif($type == 'CFG')
                {
                        
                        if($this->bank=="Standardbank")
                        {
                                $ref_op = $_POST['reference'] ?? "";
                                $libelle = 'COMM ' .$ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                        }
                        else
                        {
                                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'];
                        }
                }
                elseif($type == 'CTS')
                {
                        if($this->bank=="Standardbank")
                        {
                                $ref_op =$_POST['reference'] ?? "";
                                $libelle = 'VAT  '.$ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                        }
                        else
                        {
                                $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'];
                        }
                }
                elseif($type == 'CSC')
                {
                        if($this->bank=="Standardbank")
                        {
                                $ref_op = $_POST['reference'] ?? "";
                                $libelle = "STB " . strtoupper(substr(($_SESSION["Logiref_ville"]?? ""), 0, 3)).' '.$data['Beneficaire_15'];
                        }
                        else
                        {
                                $libelle =  $data['Noteid_26'].' - '.$data['Typerecette_17'].'-'.$data['Designation_14'].' - '.$data['Nif_13'];
                        }
                }
                
                return $libelle;
        }
}
