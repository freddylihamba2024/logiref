<?php
        namespace Modules\Services\Comptabilisation\Controllers;

        use App\Controllers\BaseController;
        use Modules\Services\Comptabilisation\Models\PasseportComptabilisationModel;

        class Comptabilisation extends BaseController
        {
                public function __construct()
                {
                        parent::__construct();
                }

                public function get_transactions_libelle($type, $data, $regie, $beneficiaire = NULL, $services= NULL, $refinss = NULL, $print = NULL)
                {

                }

                public function get_instructions_mad($data)
                {

                }

                public function get_instructions_sequestre($data)
                {

                }

                public function get_comptes_array_passport($liste, $agence, $data)
                {

                }

                public function get_the_account_structured($account_array, $bank = NULL)
                {

                }

                public function get_exception_instructions($comptes, $data, $regie)
                {

                }

                public function get_amount_converted($data, $type, $amount = NULl)
                {

                }
        }