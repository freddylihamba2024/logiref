<?php
        namespace Modules\Services\Comptabilisation\Controllers;

        use App\Controllers\BaseController;
        use Modules\Logiref\Models\InvLogirefModel;
        use Modules\Services\Comptabilisation\Models\InvComptabilisationModel;


        class InvComptabilisation extends BaseController {

                public $invComptabilisationModel;
                public $invlogirefModel;
                public $bank;
                public $account;
                public $options;

                public function __construct()
                {
                        parent::__construct();

                        $this->invComptabilisationModel = new InvComptabilisationModel();
                        $this->invlogirefModel = new InvLogirefModel();

                        $this->account = isset($this->session->userdata['account_id'])?$this->session->userdata['account_id']:"";
                        $this->bank = isset($this->session->userdata["account_pageid"])?$this->session->userdata["account_pageid"]:"";

                        if($this->bank != "")
                        {
                                # Enlever @ dans le pageid
                                # Tranformer la premiere lettre en majuscule
                                $this->bank = substr($this->bank, 1);
                                $this->bank = ucfirst($this->bank);
                        }

                        # Retrieve options configured based on the bank connected
                        if(isset($_SESSION['userdata']['options']))
                        {
                                $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->options = array();
                        }
                }

                public function get_first_instructions_immatriculation($data)
                {
                        $infos = json_decode($data["Notereference_30"], true);

                        $instructions = array();

                        $agence = $data['Guichet_21'];
                        $montant_debit_cpl=0;
                        $montant_credit_cpl=0;

                        $montant_debit_cfb=0;
                        $montant_credit_cfb=0;

                        $montant_debit_tva=0;
                        $montant_credit_tva=0;

                        # Recuperation du taux de change
                        if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                        {
                                $data['Taux_41'] = $taux = $data['Taux_41'];
                        }
                        elseif(!empty($_SESSION['Bank_rates']))
                        {
                                $result = json_decode($_SESSION['Bank_rates'], true);
                                $data['Taux_41'] = $taux = $result['Dollar_4'];
                        }

                        # Recuperer la categorie en fonction du service
                        $service_type =$this->invlogirefModel->get_dropdown("type_services");
                        $category = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
                        $data['Category'] = $category;

                        # Recuperer les compte en fonction du contexte du paiement

                        $comptes = $this->get_comptes_array_dgi_immatric("'CPL','CTR','CPT', 'CFB', 'TVA', 'FBC', 'CTA','CTP'","Rawbank", $agence, $data);

                        $compte_dst = $comptes['CPL'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('CPT', $data, 'DGI', $category);
                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'];

                        $debit_currency = $credit_currency = $data['Devise_34'];

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_cpl = $montant_credit_cpl = $data['Montant_11'] * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_cpl = $montant_credit_cpl = $data['Montant_11'];
                        }

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Montant_10'=>$montant_debit_cpl,
                                'Devise_11'=>$debit_currency,
                                'Libelle_12'=>$libelle,
                                'Compte_13'=>$compte_dst,
                                'Montant_25'=>$montant_credit_cpl,
                                'Devise_26'=>$credit_currency
                        );

                        $instructions[] = $instruction;

                        # Montant frais bancaire

                        $montant_frais = $data['Commission_23'];

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_cfb = $montant_credit_cfb = $montant_frais * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_cfb = $montant_credit_cfb = $montant_frais;
                        }

                        $compte_cfb = $comptes['CFB'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('CFB', $data, 'DGI');
                        $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Libelle_12'=>$libelle,
                                'Montant_10'=>$montant_debit_cfb,
                                'Devise_11'=>$data['Devise_34'],
                                'Montant_25'=>$montant_credit_cfb,
                                'Devise_26'=>$credit_currency,
                                'Compte_13'=>$compte_cfb
                        );

                        $instructions[] = $instruction;

                        # Montant tva

                        $montant_tva = $data['Commission_23']*0.16;

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_tva = $montant_credit_tva = $montant_tva * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_tva = $montant_credit_tva = $montant_tva;
                        }

                        $compte_tva = $comptes['TVA'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('TVA', $data, 'DGI');
                        $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Libelle_12'=>$libelle,
                                'Montant_10'=>$montant_debit_tva,
                                'Devise_11'=>$data['Devise_34'],
                                'Montant_25'=>$montant_credit_tva,
                                'Devise_26'=>$credit_currency,
                                'Compte_13'=>$compte_tva
                        );

                        $instructions[] = $instruction;

                        return $instructions;
                }

                public function get_first_instructions_immatriculation_online($data)
                {
                        $infos = json_decode($data["Notereference_30"], true);

                        $instructions = array();

                        $agence = $data['Guichet_21'];
                        $montant_debit_cpl=0;
                        $montant_credit_cpl=0;

                        $montant_debit_cfb=0;
                        $montant_credit_cfb=0;

                        $montant_debit_tva=0;
                        $montant_credit_tva=0;

                        # Recuperation du taux de change
                        if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                        {
                                $data['Taux_41'] = $taux = $data['Taux_41'];
                        }
                        elseif(!empty($_SESSION['Bank_rates']))
                        {
                                $result = json_decode($_SESSION['Bank_rates'], true);
                                $data['Taux_41'] = $taux = $result['Dollar_4'];
                        }

                        # Recuperer la categorie en fonction du service
                        $service_type =$this->invlogirefModel->get_dropdown("type_services");
                        $category = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
                        $data['Category'] = $category;

                        # Recuperer les compte en fonction du contexte du paiement

                        $comptes = $this->get_comptes_array_dgi_immatric("'CPL','CTR','CPT', 'CFB', 'TVA', 'FBC', 'CTA','CTP'", "Rawbank", $agence, $data);

                        $compte_dst = $comptes['CPL'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('CPT', $data, 'DGI', $category);
                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'];

                        $debit_currency = $credit_currency = $data['Devise_34'];

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_cpl = $montant_credit_cpl = $data['Montant_11'] * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_cpl = $montant_credit_cpl = $data['Montant_11'];
                        }

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Montant_10'=>$montant_debit_cpl,
                                'Devise_11'=>$debit_currency,
                                'Libelle_12'=>$libelle,
                                'Compte_13'=>$compte_dst,
                                'Montant_25'=>$montant_credit_cpl,
                                'Devise_26'=>$credit_currency
                        );

                        $instructions[] = $instruction;

                        # Montant frais bancaire

                        $montant_frais = $data['Commission_23'];

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_cfb = $montant_credit_cfb = $montant_frais * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_cfb = $montant_credit_cfb = $montant_frais;
                        }

                        $compte_cfb = $comptes['CFB'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('CFB', $data, 'DGI');
                        $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Libelle_12'=>$libelle,
                                'Montant_10'=>$montant_debit_cfb,
                                'Devise_11'=>$data['Devise_34'],
                                'Montant_25'=>$montant_credit_cfb,
                                'Devise_26'=>$credit_currency,
                                'Compte_13'=>$compte_cfb
                        );

                        $instructions[] = $instruction;

                        # Montant tva

                        $montant_tva = $data['Commission_23']*0.16;

                        if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                        {
                                $montant_debit_tva = $montant_credit_tva = $montant_tva * $data['Taux_41'];
                        }
                        else
                        {
                                $montant_debit_tva = $montant_credit_tva = $montant_tva;
                        }

                        $compte_tva = $comptes['TVA'] ?? "0000000000000000000000000";

                        # Definir le libelle de la transaction
                        //$libelle = $this->get_transactions_libelle('TVA', $data, 'DGI');
                        $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                        $instruction = array(
                                'Operation_8'=>'V',
                                'Compte_9'=>$data['Compte_33'],
                                'Libelle_12'=>$libelle,
                                'Montant_10'=>$montant_debit_tva,
                                'Devise_11'=>$data['Devise_34'],
                                'Montant_25'=> $montant_credit_tva,
                                'Devise_26'=>$credit_currency,
                                'Compte_13'=>$compte_tva
                        );

                        $instructions[] = $instruction;

                        return $instructions;
                }

                public function get_instructions_immatriculation_sequestre($data)
                {
                        $infos = json_decode($data["Notereference_30"], true);

                        $beneficiaries = $infos['beneficiaries'];

                        $instructions = array();

                        $agence = $data['Guichet_21'];

                        # Recuperer la categorie en fonction du service
                        $service_type =$this->invlogirefModel->get_dropdown("type_services");
                        $category = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
                        $data['Category'] = $category;

                        # Recuperer les compte en fonction du contexte du paiement
                        $comptes = $this->get_comptes_array_dgi_immatric("'CPL','CTR','CPT', 'CFB', 'TVA', 'FBC', 'CTA','CTP'","Rawbank", $agence, $data);
                        $comptes2 = $this->get_comptes_array_immatriculation("'CPT','CFE','CGU','CPI','FBC','CSO','MAD','CSI','CFB','CFP','TVA'", $agence, $data);

                        $compte_src = $comptes['CPL'] ?? "0000000000000000000000000";

                        foreach($beneficiaries as $beneficiary)
                        {
                                $libelle = $beneficiary['beneficiary_code'].' '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                                $compte_beneficiaire = isset($comptes2[$beneficiary['beneficiary_code']]['CPI'][$data['Devise_34']])?$comptes2[$beneficiary['beneficiary_code']]['CPI'][$data['Devise_34']]:"0000000000000000000000000";


                                if($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']=='CDF')
                                {
                                        $montant_debit = $montant_credit = $beneficiary['amount'] * $data['Taux_41'];
                                }
                                else
                                {
                                        $montant_debit = $montant_credit = $beneficiary['amount'];
                                }

                                $instruction = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$compte_src,
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=>$montant_debit,
                                        'Devise_11'=> $data['Devise_34'],
                                        'Compte_13'=> $compte_beneficiaire,
                                        'Montant_25'=>$montant_credit,
                                        'Devise_26' => $data['Devise_34']
                                );

                                $instructions[] = $instruction;
                        }

                        return $instructions;
                }

                public function get_transactions_libelle($type, $data, $regie, $beneficiaire = NULL, $services= NULL, $refinss = NULL, $print = NULL)
                {
                        $account = (!empty($this->session->userdata['account_id']))?$this->session->userdata['account_id']:$data["Account_3"];
                        if($services == NULL) $services = isset($data['Service_16']) ? $data['Service_16'] : "";

                        if(isset($data['Notereference_30']))
                        {
                                if(isset($data['Notereference_30']['taxesPaid']) && $data['Notereference_30']['taxesPaid'] != "")
                                {
                                        $notereference = $data['Notereference_30'];
                                }
                                else
                                {
                                        $notereference = json_decode($data['Notereference_30'], true);
                                }
                        }

                        if(isset($notereference['standard']) && $notereference['standard'] !='')
                        {
                                if($this->bank == 'Equitybcdc')
                                {
                                        $periode = isset($notereference['standard']) ? $notereference['standard'] : "";
                                        $periode = str_replace("-", "", $periode);
                                }
                                else{
                                        $standard = explode('-', $notereference['standard']);
                                        $periode = isset($standard[0]) ? $standard[0] : "00";

                                        $months = $this->invComptabilisationModel->months;
                                        $periode = isset($months[$periode]) ? $months[$periode] : '';
                                }
                        }
                        else
                        {
                                $periode = '';
                        }

                        $libelle = "";

                        if($type == 'CPT')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == 'DGI')
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $standard = explode('-', $notereference['standard']);

                                                $libelle = $data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == 'DGRAD')
                                        {
                                                $libelle = $data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                                        }
                                        elseif($regie == 'DGDA')
                                        {
                                                $libelle = $data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $data['Notedate_27'] = isset($data['Notedate_27']) ? $data['Notedate_27'] : gmdate('Y-m-d');
                                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = $data['Beneficaire_15'].'_'.$services.'_'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        if($data['Typerecette_17']=='TVA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        elseif($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                if($regie == 'DGRAD')
                                                {
                                                        $libelle = 'PMT DGRAD '. $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                                else
                                                {
                                                        $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                        }
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                ? ($data['Reference_32']?? "")
                                                : ($data['refOp'] ?? "" );
                                        $libelle = "PYT ". $ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                                }
                        }
                        elseif($type == 'CPL')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == 'DGI')
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $standard = explode('-', $notereference['standard']);

                                                $libelle = $data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == 'DGRAD')
                                        {
                                                $libelle = $data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                                        }
                                        elseif($regie == 'DGDA')
                                        {
                                                $libelle = $data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $data['Notedate_27'] = isset($data['Notedate_27']) ? $data['Notedate_27'] : gmdate('Y-m-d');
                                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = $data['Beneficaire_15'].'_'.$services.'_'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        if($data['Typerecette_17']=='TVA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        elseif($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                if($regie == 'DGRAD')
                                                {
                                                        $libelle = 'PMT DGRAD '. $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                                else
                                                {
                                                        $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                        }
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                ? ($data['Reference_32']?? "")
                                                : ($data['refOp'] ?? "" );
                                        $libelle = "PYT ". $ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                                }
                        }
                        elseif($type == 'CTG')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == 'DGI')
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $standard = explode('-', $notereference['standard']);

                                                $libelle = $data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == 'DGRAD')
                                        {
                                                $libelle = $data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                                        }
                                        elseif($regie == 'DGDA')
                                        {
                                                $libelle = $data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $data['Notedate_27'] = isset($data['Notedate_27']) ? $data['Notedate_27'] : gmdate('Y-m-d');
                                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = $data['Beneficaire_15'].'_'.$services.'_'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.'-'.$data['Typerecette_17'].'-'.$periode.'-'.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        if($data['Typerecette_17']=='AMRA')
                                        {
                                                $libelle = $services.' '.$data['Typerecette_17'].' '.$data['Noteid_26'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                if($regie == 'DGRAD')
                                                {
                                                        $libelle = 'PMT DGRAD '. $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                                else
                                                {
                                                        $libelle = $services.' '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                                }
                                        }
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $ville = $_SESSION["Logiref_ville"] ?? "";
                                        //$ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA") ? ($data['Reference_32']??"OP...") : (isset($_POST['reference']) ? $_POST['reference'] : $data['Reference_32']);
                                        $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                ? ($data['Reference_32']??"OP...")
                                                : $data['refOp'] ?? "";

                                        $libelle = "STB ". strtoupper(substr(($_SESSION["Logiref_ville"]?? ""), 0, 3)).' '.$data['Beneficaire_15'];
                                }
                        }
                        elseif($type == 'CFB')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == "DGI")
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $libelle = 'Frais bancaire '.$data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == "DGRAD")
                                        {
                                                $libelle = 'Frais bancaire '.$data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                                        }
                                        elseif($regie == "DGDA")
                                        {
                                                $libelle = 'Frais bancaire '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.''.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        if($regie == 'DGRAD')
                                        {
                                                $libelle = 'Frais bancaire PMT DGRAD'.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        if (isset($data['Type_fees']))
                                        {
                                                if($data['Type_fees']=="FIA")  $label_fees =  " ";
                                                elseif($data['Type_fees']=="FDA")  $label_fees =  " ";
                                                else $label_fees = "";

                                                $libelle = 'PYT ATT. ' .$data['Reference_32'] ?? "OP...";
                                        }
                                        else
                                        {
                                                //$ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA") ? ($data['Reference_32']??"OP..." ): (isset($_POST['reference']) ? $_POST['reference'] : $data['Reference_32']);
                                                $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                        ? ($data['Reference_32'] ?? "")
                                                        : ($data['refOp'] ?? "" );
                                                $libelle = 'COMM ' .$ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                                        }
                                }
                        }
                        elseif($type == 'TVA')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == 'DGI')
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $libelle = 'TVA '.$data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == 'DGRAD')
                                        {
                                                $libelle = 'TVA '.$data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                                        }
                                        elseif($regie == 'DGDA')
                                        {
                                                $libelle = 'TVA '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        if(isset($data['Typerecette_17']))
                                        {
                                                $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = 'TVA '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        if(isset($data['Typerecette_17']))
                                        {
                                                $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = 'TVA '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        if(isset($data['Typerecette_17']))
                                        {
                                                $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                $libelle = 'TVA '.$periode.' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        if(isset($data['Typerecette_17']))
                                        {
                                                $libelle = 'TVA '.$data['Typerecette_17'].' '.$periode.' '.$data['Designation_14'];
                                        }
                                        else
                                        {
                                                if($regie == 'DGRAD')
                                                {
                                                        $libelle = 'TVA PMT DGRAD'.$periode.' '.$data['Designation_14'];
                                                }
                                                else
                                                {
                                                        $libelle = 'TVA'.$periode.' '.$data['Designation_14'];
                                                }
                                        }
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        if (isset($data['Type_fees']))
                                        {
                                                if($data['Type_fees']=="FIA")  $label_fees =  " impression des attestations";
                                                elseif($data['Type_fees']=="FDA")  $label_fees =  " impression duplicata des attestations ";
                                                else $label_fees = "";

                                                //$libelle = 'VAT ATT. STDB ' .$data['Reference_32'] ?? "".'/'.$data['Beneficaire_15'];
                                                $libelle = 'VAT ATT. ' .$data['Reference_32']??'OP...';
                                        }
                                        else
                                        {
                                                //$ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA") ? ($data['Reference_32']??"OP...") : (isset($_POST['reference']) ? $_POST['reference'] : $data['Reference_32']);
                                                $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                        ? ($data['Reference_32'] ?? "")
                                                        : ($data['refOp'] ?? "" );
                                                $libelle = 'VAT  '.$ref_op.'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                                        }

                                        //$libelle = 'VAT  '.$data['Reference_32'].'/'.$data['Designation_14'].'/'.$data['Beneficaire_15'];
                                }
                        }
                        elseif($type == 'FBC')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Rawbank')
                                {

                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        //$ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA") ? $data['Reference_32'] : (isset($_POST['reference']) ? $_POST['reference'] : $data['Reference_32']);
                                        $ref_op = (isset($data['Beneficaire_15']) && $data['Beneficaire_15'] != "DGDA")
                                                ? ($data['Reference_32']??"")
                                                :  $data['refOp'] ?? "";
                                        if (!empty($data['RFPROPD'])):
                                                $libelle = 'FRS MT202  '. ($data['Noteid_26'] ?? '') .'/'.$ref_op.'/'.$data['Designation_14'];
                                        else:
                                                $libelle = 'FRS ATS  '. ($data['Noteid_26'] ?? '') .'/' .$ref_op.'/'.$data['Designation_14'];
                                        endif;
                                }
                        }
                        elseif($type == 'FCD')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Rawbank')
                                {

                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        $libelle = 'Frais de correspondance '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank=="Standardbank")
                                {

                                }

                        }
                        elseif($type == 'GU-DGI')
                        {
                                if($refinss!="")
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$refinss;
                                }
                                else
                                {
                                        if($this->bank == 'Solidairebanque')
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($this->bank == 'Rawbank')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                        }
                                        elseif($this->bank == 'Tmb')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                        }
                                        elseif($this->bank == 'Equitybcdc')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                        }
                                        elseif($this->bank == 'Firstbank')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                        }
                                        elseif($this->bank == 'Boa')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                        }
                                        elseif($this->bank == 'Sofibanque')
                                        {
                                                $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];

                                                if(isset($this->options['DGI']['credit-iprier-total-amount-to-transit-for-institutions']))
                                                {
                                                        $notereference = json_decode($data['Notereference_30'], true);

                                                        if (isset($data['Label-total-amount']))
                                                        {
                                                                $standard = explode('-', $notereference['standard']);

                                                                $libelle = 'PMT GU-DGI '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode. ' ' .$standard[1]  ;
                                                        }
                                                }
                                        }
                                        elseif($this->bank=="Standardbank")
                                        {
                                                //$libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Designation_14'];
                                                $libelle = 'PYT  '. $beneficiaire. ' '.$data['Reference_32'].'/'.$data['Designation_14'].'/GU/'.$periode. ' '.$standard[1];
                                        }
                                }
                        }
                        elseif($type == 'GU-PLAQUE')
                        {

                                if($this->bank == 'Solidairebanque')
                                {
                                        $notereference = json_decode($data['Notereference_30'], true);
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$notereference['Motif'];
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $libelle = $beneficiaire.' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }

                        }
                        elseif($type == 'GU-DGDA')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        $notereference = json_decode($data['Notereference_30'], true);
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $libelle = $data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'];
                                }
                        }
                        elseif($type == 'CTA')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        if($regie == "DGI")
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $libelle = 'Arrondis '.$data['Designation_14'].' '.$notereference['Motif'];
                                        }
                                        elseif($regie == "DGRAD")
                                        {
                                                $notereference = json_decode($data['Notereference_30'], true);
                                                $libelle = 'Arrondis '.$data['Noteid_26'].' '.$data['Notedate_27'].' '.$data['Typerecette_17'].' '.$data['Designation_14'];
                                        }
                                        elseif($regie == "DGDA")
                                        {
                                                $libelle = 'Frais bancaire '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                                        }
                                }
                                elseif($this->bank == 'Rawbank')
                                {

                                }
                                elseif($this->bank == 'Tmb')
                                {

                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                                elseif($this->bank == 'Boa')
                                {

                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                }
                        }
                        elseif($type == 'AMR')
                        {
                                if($this->bank == 'Solidairebanque')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Rawbank')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Tmb')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Equitybcdc')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Firstbank')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Boa')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank == 'Sofibanque')
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                                elseif($this->bank=="Standardbank")
                                {
                                        $libelle = 'AMR-B '.$notereference['reference_amr_b'].' '.$data['Designation_14'].' '.$periode;
                                }
                        }

                        return $libelle;
                }

                public function get_comptes_array_dgi_immatric($liste, $beneficiary, $agence, $data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $account = $data['Account_3'];
                        $account_line_cpl = array();
                        $account_line_cpt = array();
                        $account_line_cfb = array();
                        $account_line_fbc = array();
                        $account_line_tva = array();
                        $account_line_cta = array();
                        $account_line_ctr = array();
                        $account_cpl = "";
                        $account_cpt = "";
                        $account_cfb = "";
                        $account_fbc = "";
                        $account_tva = "";
                        $account_cta = "";
                        $return = "";

                        $service = isset($data['Service_16']) ? $data['Service_16'] : "";
                        $category = isset($data['Category']) ? $data['Category'] : "";
                        $recette = isset($data['Typerecette_17']) ? $data['Typerecette_17'] : "";

                        $devise = isset($data['Devise_34']) ? $data['Devise_34'] : "";

                        # Recuperer les comptes en fonction du code agence et/ou l'agence principale
                        if(isset($this->options['ALL']['get-bank-fees-account-based-on-branch-code']))
                        {

                                $code_agence = substr($data['Compte_33'], 0, 5);

                                if(isset($this->options['ALL']['get-tax-authority-account-based-on-main-branch']))
                                {
                                        $main_branch = $_SESSION['main_branch'];

                                        $guichets = $this->invlogirefModel->get_dropdown('guichets');

                                        # Verifier si l'agence principal existe
                                        $agence = isset($guichets[$main_branch]) ? $main_branch : $_SESSION['Logiref_guichet'];
                                }
                                else
                                {
                                        $agence = $_SESSION['Logiref_guichet'];
                                }

                                $tab_comptes_cpt = $tab_comptes_cpl = $this->invlogirefModel->get_comptes_dgi_immatric($liste, $beneficiary, $agence, $data["Account_3"]);

                                $tab_comptes_produits = $this->invlogirefModel->get_comptes_dgi_immatric($liste, $beneficiary, NULL, $code_agence, $data["Account_3"]);
                        }
                        else
                        {
                                $tab_comptes_cpt = $tab_comptes_cpl = $tab_comptes_produits = $this->invlogirefModel->get_comptes_dgi_immatric($liste, $beneficiary, $agence, $data["Account_3"]);
                        }

                        if(!empty($tab_comptes_cpt) || !empty($tab_comptes_cpl) || !empty($tab_comptes_produits))
                        {
                                # Recuperer le compte CPT
                                foreach ($tab_comptes_cpt as $row)
                                {
                                        if($row['Type_4'] == 'CPT')
                                        {
                                                if ($row['Category_22'] == $category && $row['Serviceid_16'] == $service && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                {
                                                        $account_line_cpt = $row;
                                                        break;
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if ($row['Category_22'] == $category  && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if ($row['Serviceid_16'] == $service  && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if($row['Category_22'] == $category && $row['Serviceid_16'] == $service && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if($row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if($row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if ($row['Category_22'] == $category && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if (($row['Serviceid_16'] === '' || $row['Serviceid_16'] === NULL)   && ($row['Recette_13'] === '' || $row['Recette_13'] === NULL) && $row['Devise_8'] == $devise)   
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpt))
                                {
                                        foreach ($tab_comptes_cpt as $row)
                                        {
                                                if($row['Type_4'] == 'CPT')
                                                {
                                                        if ($row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpt = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                $account_cpt = $this->get_the_account_structured($account_line_cpt);

                                # Recuperer le compte CPL
                                foreach ($tab_comptes_cpl as $row)
                                {
                                        if($row['Type_4'] == 'CPL')
                                        {
                                                if ($row['Category_22'] == $category && $row['Serviceid_16'] == $service && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                {
                                                        $account_line_cpl = $row;
                                                        break;
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if ($row['Category_22'] == $category  && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if ($row['Serviceid_16'] == $service  && $row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if($row['Category_22'] == $category && $row['Serviceid_16'] == $service && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if($row['Recette_13'] == $recette && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if($row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if ($row['Category_22'] == $category && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if (($row['Serviceid_16'] === '' || $row['Serviceid_16'] === NULL)   && ($row['Recette_13'] === '' || $row['Recette_13'] === NULL) && $row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                if(empty($account_line_cpl))
                                {
                                        foreach ($tab_comptes_cpl as $row)
                                        {
                                                if($row['Type_4'] == 'CPL')
                                                {
                                                        if ($row['Devise_8'] == $devise)
                                                        {
                                                                $account_line_cpl = $row;
                                                                break;
                                                        }
                                                }
                                        }
                                }

                                $account_cpl = $this->get_the_account_structured($account_line_cpl);

                                # Recuperer le compte CFB, TVA, FBC
                                foreach ($tab_comptes_produits as $row)
                                {
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CTR')
                                        {
                                                $account_line_ctr = $row;
                                        }

                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CFB' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_cfb = $row;
                                        }
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'FBC' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_fbc = $row;
                                        }
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'TVA' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_tva = $row;
                                        }
                                        if(isset($row['Type_4']) && $row['Type_4'] == 'CTA' && $row['Devise_8'] == $data['Devise_34'])
                                        {
                                                $account_line_cta = $row;
                                        }
                                }

                                $account_cfb = $this->get_the_account_structured($account_line_cfb);
                                $account_fbc = $this->get_the_account_structured($account_line_fbc);
                                $account_tva = $this->get_the_account_structured($account_line_tva);
                                $account_cta = $this->get_the_account_structured($account_line_cta);
                                $account_ctr = $this->get_the_account_structured($account_line_ctr);


                                $account_array = array(
                                                        'CPL'=>$account_cpl,
                                                        'CPT'=>$account_cpt,
                                                        'CFB'=>$account_cfb,
                                                        'TVA'=>$account_tva,
                                                        'FBC'=>$account_fbc,
                                                        'CTA'=>$account_cta,
                                                        'CTR'=>$account_ctr,
                                                );
                        }
                        else
                        {
                                $account_array = array(
                                                        'CPL'=>'000000000000000000000000',
                                                        'CPT'=>'000000000000000000000000',
                                                        'CFB'=>'000000000000000000000000',
                                                        'TVA'=>'000000000000000000000000',
                                                        'FBC'=>'000000000000000000000000',
                                                        'CTA'=>'000000000000000000000000',
                                                        'CTR'=>'000000000000000000000000',
                                                );
                        }

                        return $account_array;
                }

                public function get_comptes_array_immatriculation($liste, $agence, $data, $branch_code=null)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $return = $this->invlogirefModel->get_comptes_immatriculation($liste, $data['Account_3']);

                        $comptes = array();

                        if(!empty($return))
                        {
                                foreach ($return as $row)
                                {
                                        if($row['Type_4'] != "" && ($row['Type_4'] == 'CPT' || $row['Type_4'] == 'CPL' || $row['Type_4'] == 'CTP' || $row['Type_4'] == 'CFE' || $row['Type_4'] == 'CGU' || $row['Type_4'] == 'CPI'))
                                        {

                                                if($row['Recette_13']=="27022470" || $row['Recette_13']=="27022450" || $row['Recette_13']=="27421600")
                                                {
                                                        if($row['Agenceid_15'] !="")
                                                        {
                                                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                                if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                        }
                                                        else
                                                        {
                                                                $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                                        }
                                                }
                                                elseif($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] == $data['Service_16'] && $row['Recette_13'] =="TVA" && $row['Devise_8'] =="CDF")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =="")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                else
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }

                                        }
                                        if($row['Type_4'] != "" && ($row['Type_4'] == 'FBC' || $row['Type_4'] == 'CSO'  || $row['Type_4'] == 'MAD' || $row['Type_4'] == 'CSI'))
                                        {
                                                if($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] !="" && $data['Service_16'] =="TVA" && $row['Devise_8'] =="CDF")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] !="" && $row['Recette_13'] =='')
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                else
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                        }
                                        elseif($row['Agence_12'] != "" && $row['Agence_12'] == $agence && ($row['Type_4'] =='CFB' || $row['Type_4'] =='CFP' || $row['Type_4'] =='TVA' ))
                                        {
                                                if($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] !="" && $data['Typerecette_17'] =="TVA" && $row['Devise_8'] =="CDF")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="" && $data['Service_16'] !="" && $row['Serviceid_16'] !="")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Serviceid_16']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                elseif($row['Agenceid_15']!="")
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                                else
                                                {
                                                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                                }
                                        }

                                }

                        }

                        return $comptes;
                }

                public function get_the_account_structured($account_array, $bank = NULL)
                {
                        $bank = $this->bank;
                        $account = "";

                        if(!empty($account_array))
                        {
                                if($account_array['Agenceid_15'] !="" && $account_array['Numericcode_19'] !="" && $account_array['Clef_7'] !="")
                                {
                                        $account = $account_array['Agenceid_15']."-".$account_array['Compte_6']."-".$account_array['Clef_7']."-".$account_array['Numericcode_19'];
                                }
                                elseif($account_array['Agenceid_15'] !="" && $account_array['Clef_7'] !="")
                                {
                                        $account = $account_array['Agenceid_15']."-".$account_array['Compte_6']."-".$account_array['Clef_7'];
                                }
                                elseif($account_array['Agenceid_15'] !="")
                                {
                                        $account = $account_array['Agenceid_15']."-".$account_array['Compte_6'];
                                }
                                else
                                {
                                        $account = $account_array['Compte_6'];
                                }

                                if($bank == 'Sofibanque')
                                {
                                        $account = $account_array['Compte_6'];
                                }

                                if($bank == 'Boa')
                                {
                                        $account = $account_array['Compte_6'];
                                }

                                if($bank == 'Standardbank')
                                {
                                        $account = $account_array['Compte_6'];
                                }
                        }
                        else
                        {
                                $account = '000000000000000000000000';
                        }

                        return $account;
                }
        }