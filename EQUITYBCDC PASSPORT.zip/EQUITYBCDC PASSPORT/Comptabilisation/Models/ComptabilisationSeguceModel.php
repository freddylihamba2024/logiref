<?php 
namespace Modules\Services\Comptabilisation\Models;
use App\Models\MY_Transaction;



class ComptabilisationSeguceModel extends MY_Transaction{
    
        /* Presentation: 
         * Last update
         * By Glodi on the 24.01.2024
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * P.S: Ajoutez vos variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public $banks = array(
                            ''=>'',
                            '36' => 'Standardbank', 
                            '44' => 'Rawbank', 
                            '45' => 'Tmb',
                            '46' => 'Ebcdc',
                            '9082'=> 'Boa',
                            '9083' => 'Solidaire',
                            '9084' => 'Sofibank'
                        );
        public $months = array
                        (
                            '00' => '',
                            '01' => 'Janvier',
                            '02' => 'Fevrier',
                            '03' => 'Mars',
                            '04' => 'Avril',
                            '05' => 'Mai',
                            '06' => 'Juin',
                            '07' => 'Juillet',
                            '08' => 'Aout',
                            '09' => 'Septembre',
                            '10' => 'Octobre',
                            '11' => 'Novembre',
                            '12' => 'Decembre'
                        );
        
        public $months_abrv = array
                        (
                            '00' => '',
                            '01' => 'Jan',
                            '02' => 'Feb',
                            '03' => 'Mar',
                            '04' => 'Apr',
                            '05' => 'May',
                            '06' => 'Ju',
                            '07' => 'Jly',
                            '08' => 'Aug',
                            '09' => 'Sep',
                            '10' => 'Oct',
                            '11' => 'Nov',
                            '12' => 'Dec'
                        );
        
        public function __construct()
	{
		parent::__construct();
                
	}

        public function get_first_instructions_invoice($id, $account_id = NULL)
        {
                $account =  $_SESSION['userdata']['account_id'] ?? $account_id ?? "";
                $st = "Status_2 !=0 AND  Account_3='" . $account . "' AND Paiementid_4 ='" . $id . "' AND Priority_24='0'";
                
                $query = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_seguce_by_priority($id,$priority=null) 
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 AND Montant_10 > 0 AND Priority_24='".$priority."'";

                $builder = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_seguce.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
       
        public function save_seguce_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;

                                $data['Id_0']           = '';
                                $data['Date_1']         = gmdate('Y-m-d H:i:s');
                                $data['Status_2']       = 1;
                                $data['Account_3']      = $_SESSION['userdata']['account_id'] ?? $paiement['Account'] ?? "";
                                $data['Paiementid_4']   = $pid;
                                $data['Banqueid_5']     = $_SESSION['userdata']['account_id'] ?? $paiement['Account'] ?? ""; //TBD
                                $data['Agence_6']       = $paiement['Agence_20'];
                                $data['Guichet_7']      = $paiement['Guichet_21'];
                                $data['Mode_15']        = $paiement['Mode_19'];
                                $data['Makerid_16']     = $_SESSION['userdata']['user_id'] ?? $paiement['Userid'] ?? "";
                                //$data['Priority_24']=$priority;
                                if(!isset($data['Reference_14']))
                                {
                                        $data['Reference_14'] =  $logirefid;
                                }

                                $this->set_table('logiref_cbs_instructions_seguce', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
}
