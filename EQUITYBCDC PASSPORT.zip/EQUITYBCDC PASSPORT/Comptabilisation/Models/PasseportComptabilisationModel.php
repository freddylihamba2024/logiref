<?php
        namespace Modules\Services\Comptabilisation\Models;
        use App\Models\MY_Transaction;

        class PasseportComptabilisationModel extends MY_Transaction
        {

                public function __construct()
                {
                        parent::__construct();
                }

                public function get_dropdown($item)
                {

                }

                public function save_instructions($pid, $paiement, $instructions, $logirefid, $priority=0)
                {

                }

                public function update_instructions($ids, $data)
                {

                }

                public function delete_instructions($id)
                {

                }

        }