<?php

        namespace Modules\Services\Comptabilisation\Models;
        use App\Models\MY_Transaction;

        class ComptabilisationModel extends MY_Transaction
        {

                /* Presentation:
                * Last update
                * By Glodi on the 24.01.2024
                *  *************************************************************************************************************************SECTION 1
                */

                /*
                * Protected and public variables
                * P.S: Ajoutez vos variables ci-dessous, si necessaire!!
                * *************************************************************************************************************************SCETION 2
                */
                public $banks = array(
                                ''=>'',
                                '36' => 'Standardbank',
                                '44' => 'Rawbank',
                                '45' => 'Tmb',
                                '46' => 'Ebcdc',
                                '9082'=> 'Boa',
                                '9083' => 'Solidaire',
                                '9084' => 'Sofibank'
                        );
                public $months = array(
                                '00' => '',
                                '01' => 'Janvier',
                                '02' => 'Fevrier',
                                '03' => 'Mars',
                                '04' => 'Avril',
                                '05' => 'Mai',
                                '06' => 'Juin',
                                '07' => 'Juillet',
                                '08' => 'Aout',
                                '09' => 'Septembre',
                                '10' => 'Octobre',
                                '11' => 'Novembre',
                                '12' => 'Decembre'
                        );

                public $months_abrv = array(
                                '00' => '',
                                '01' => 'Jan',
                                '02' => 'Feb',
                                '03' => 'Mar',
                                '04' => 'Apr',
                                '05' => 'May',
                                '06' => 'Ju',
                                '07' => 'Jly',
                                '08' => 'Aug',
                                '09' => 'Sep',
                                '10' => 'Oct',
                                '11' => 'Nov',
                                '12' => 'Dec'
                        );

                public function __construct()
                {
                        parent::__construct();
                }

                public function get_dropdown($item)
                {
                        $account_id = $this->session->userdata['account_id'];

                        if($item=="beneficiary_tax_others_banks")
                        {
                                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Nivellement_20 = '1' ";

                                $query = $this->db->table('logiref_comptes')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';

                                foreach ($query->getResultArray() as $row) {
                                        $ddmenu[$row['Recette_13']]['Agence_12'] = $row['Bank_21'];
                                }
                                return $ddmenu;
                        }
                }

                /*
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * P.S: Identification du scenario ou cas de comptabalisation
                * *************************************************************************************************************************SCETION 2
                */

                public function get_instructions_dgda($bl)
                {
                        $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_first_instructions_dgda($bl)
                {
                        $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 AND Montant_10 > 0 AND Priority_24 = 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function  get_instructions_dgda_by_id($id)
                {
                        $this->set_table('logiref_cbs_instructions_dgda d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $id), TRUE);

                        return $lines;
                }

                public function  get_instructions_seguce_by_id($id)
                {
                        $this->set_table('logiref_cbs_instructions_seguce  d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $id), TRUE);

                        return $lines;
                }

                public function  get_instructions_dgi_by_id($id)
                {
                        $this->set_table('logiref_cbs_instructions_dgi d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $id), TRUE);

                        return $lines;
                }

                public function  get_instructions_dgrad_by_id($id)
                {
                        $this->set_table('logiref_cbs_instructions_dgrad d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $id), TRUE);

                        return $lines;
                }

                public function get_comptant_batch_instructions($bl)
                {
                        $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();

                        return $query->getResult();
                }

                public function get_prepayment_instructions($bl)
                {
                        $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_prepayments_instructions')
                                ->select('logiref_cbs_prepayments_instructions.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_gu_prepayment_instructions($lot)
                {
                        $st = " Paiementid_4='" . $lot . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_prepayments_instructions')
                                ->select('logiref_cbs_prepayments_instructions.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_instructions_dgi($ref)
                {
                        $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_dgi')
                                ->select('logiref_cbs_instructions_dgi.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_instructions_immatriculation($ref)
                {
                        $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('logiref_cbs_instructions_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_instructions_dgrad($ref)
                {
                        $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_dgrad')
                                ->select('logiref_cbs_instructions_dgrad.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_instructions_seguce($ref)
                {
                        $st = " Paiementid_4='" . $ref . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_seguce')
                                ->select('logiref_cbs_instructions_seguce.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_instructions_others_taxes()
                {
                        $date = gmdate('Y-m-d');
                        $st = " Date_1 LIKE '%" . $date . "%' AND Nivellement_27 = 1";

                        $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_filtre_others($type=NULL, $data=NULL)
                {
                        $this->_table_name = '';
                        $user = $this->session->userdata['user_id'];
                        $guichet =$_SESSION['Logiref_guichet'];
                        $date = gmdate('Y-m-d');

                        $st = " Status_2 = '1' AND Nivellement_27 = 1";

                        #Filtre d'affichage
                        if(isset($_POST['Recette']) && $_POST['Recette']!='') $st .= " AND Codetaxe_28='".$_POST['Recette']."' ";
                        if((isset($_POST['start']) && $_POST['start']!='') && (isset($_POST['end']) && $_POST['end']!='')) $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";

                        #Query
                        $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();
                        return $query->getResult();
                }

                public function get_instructions_others_banks($compte_src, $comptes, $data)
                {
                        $instructions = array();
                        $regie = 'DGDA';

                        $notereference = json_decode($data['Notereference_30'], true);

                        $tax_amount = $data['Montant_11'] / 1.001;
                        $frais_bcc_amount = $tax_amount * 0.001;

                        $compte_dst = isset($comptes[$data['Typerecette_17']]['CNP']) ? $comptes[$data['Typerecette_17']]['CNP'] : '00000000000000000000000';
                        $libelle = 'Frais de nivel B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];

                        $instruction = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$compte_src,
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=>$tax_amount,
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst,
                                        'Nivellement_27'=>1,
                                        'Codetaxe_28'=>$data['Typerecette_17']
                                        );

                        $instructions[] = $instruction;

                        $compte_dst = isset($comptes[$data['Typerecette_17']]['FBC']) ? $comptes[$data['Typerecette_17']]['FBC'] : '00000000000000000000000';
                        $libelle = 'Frais BCC B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];

                        $instruction = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$compte_src,
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=>$frais_bcc_amount,
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst,
                                        'Codetaxe_28'=>$data['Typerecette_17']
                                        );

                        $instructions[] = $instruction;

                        return $instructions;
                }

                public function get_instructions_for_roundings($data, $comptes, $amount)
                {
                        $instructions = array();
                        $bank_code = 'Solidaire';

                        $compte_dst = isset($comptes[$bank_code]['CTA'][$data['Devise_12']]) ? $comptes[$bank_code]['CTA'][$data['Devise_12']] : '000000000000000000000000';

                        if($data['Beneficaire_15'] == "DGDA")
                        {
                                $libelle = 'Arrondis '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                        }
                        elseif($data['Beneficaire_15'] == "DGI")
                        {
                                $notereference = json_decode($data['Notereference_30'], true);

                                //$libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                                $libelle = 'Arrondis '.$data['Designation_14'].' '.$notereference['Motif'];
                        }
                        elseif($data['Beneficaire_15'] == "DGRAD")
                        {
                                $libelle = 'Arrondis '.$data['Noteid_26'].' '.$data['Notedate_27'].' '.$data['Typerecette_17'].' '.$data['Designation_14'];
                        }

                        $instruction = array(
                                                'Operation_8'=>'V',
                                                'Compte_9'=>$data['Compte_33'],
                                                'Libelle_12'=>$libelle,
                                                'Montant_10'=>$amount,
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                        );

                        return $instruction;
                }

                public function save_objects_name($data, $id)
                {
                        $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                        ($id >0) || $this->db->where('Id_0', $id);
                        return $this->save($data, $id);
                }

                public function update_instructions($data, $id)
                {
                        $this->set_table('logiref_cbs_instructions', 'Reference_14', 'Reference_14 DESC');
                        return $this->saveData($data, $id);
                }


                public function get_last_attempts_dgi($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgi');

                        $data = $builder
                                ->where('Id_0', $id)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        if (! empty($data))
                                return $data->Attempts_30;

                        return 0;
                }

                public function get_last_attempts_dgrad($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgrad');

                        $data = $builder
                                ->where('Id_0', $id)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        if (! empty($data))
                                return $data->Attempts_30;

                        return 0;
                }

                public function get_last_attempts_dgda($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgda');

                        $data = $builder
                                ->where('Id_0', $id)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        if (! empty($data))
                                return $data->Attempts_32;

                        return 0;
                }

                public function get_cbs_instructions_passport_attempts($id = NULL,$priority = NULL)
                {
                        $this->set_table('logiref_cbs_instructions_passeport I', 'I.Id_0', 'I.Id_0 DESC');
                        $data= $this->get_by(array('Paiementid_4' => $id,'Priority_27'=>$priority), TRUE);
                        if(!empty($data))
                        {
                                return $data->Attempts_29;
                        }
                        else
                        {
                                return 0;
                        }
                }
                
                public function update_cbs_instructions_passport_attempts($paiement_id, $priority)
                {
                        $attempts = $this->get_cbs_instructions_passport_attempts($paiement_id, $priority);
                        $data = array(
                                'Attempts_29' => $attempts + 1,
                        );
                        $builder = $this->db->table('logiref_cbs_instructions_passeport');
                        $builder->where("logiref_cbs_instructions_passeport.Paiementid_4 ='".$paiement_id."' AND Priority_27 = '".$priority."'");
                        return $builder->update($data);
                }

                public function get_instructions_sftp_payroll($file_id)
                {
                        $st = " Paiementid_4='" . $file_id . "' AND Status_2 <> 0 ";
                        $query = $this->db->table('logiref_cbs_instructions_payroll')
                                ->select('logiref_cbs_instructions_payroll.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->limit('500')
                                ->get();

                        return $query->getResult();
                }

                public function get_last_attempts_prepayment($id)
                {
                        $builder = $this->db->table('logiref_cbs_prepayments_instructions');

                        $data = $builder
                                ->where('Id_0', $id)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        if (! empty($data))
                                return $data->Attempts_32;

                        return 0;
                }

                public function save_prepayments_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Priority_24']=$priority;
                                        $data['Reference_14']=$logirefid;

                                        $this->set_table('logiref_cbs_prepayments_instructions', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                public function save_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        //$data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');

                                        if($type=='others') $data['Status_2']=2;
                                        else $data['Status_2']=1;

                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Priority_24']=$priority;

                                        $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                public function save_first_instructions_dgda($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Reference_14']= $logirefid;
                                        $data['Priority_24']=$priority;

                                        $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                public function save_comptant_batch_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');

                                        if($type=='others') $data['Status_2']=2;
                                        else $data['Status_2']=1;

                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Priority_24']=$priority;

                                        //$this->set_table('logiref_comptant_batch_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                        $this->set_table('logiref_cbs_instructions_dgda ', 'Id_0', 'Id_0 DESC');

                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                public function save_instructions_dgi($pid, $paiement, $instructions, $logirefid, $plate=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {

                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid; //TBD
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];

                                        if (isset($plate)) $data['Plaque_25']=$plate;

                                        $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }

                        return TRUE;
                }

                public function save_instructions_dgrad($pid, $paiement, $instructions, $logirefid)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid; //TBD
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];

                                        $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                ##################### RBO Methos ######################################

                public function save_rbo_instructions_dgda($pid, $paiement, $instruction, $logirefid=NULL, $priority=NULL, $type=NULL)
                {
                        //Save instructions
                        if(!empty($instruction))
                        {
                                $data = array();
                                $data =(array) current($instruction);
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');

                                if($type=='others') $data['Status_2']=2;
                                else $data['Status_2']=1;

                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']= $paiement['Makerid_16'];
                                $data['Reference_14']=$logirefid;
                                $data['Priority_24']=$priority;

                                #$data['Type_25']= $paiement['DataType'];

                                $this->set_table('logiref_rbo_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                        return TRUE;
                }

                public function save_rbo_instructions_dgi($pid, $paiement, $instruction, $logirefid)
                {
                        //Save instructions
                        if(!empty($instruction))
                        {

                                $data = array();
                                //$instruction['Id_0'] = '';
                                $data =(array) current($instruction);
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$paiement['Makerid_16'];

                                $this->set_table('logiref_rbo_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }

                        return TRUE;
                }

                public function save_rbo_instructions_dgrad($pid, $paiement, $instruction, $logirefid)
                {
                        //Save instructions
                        if(!empty($instruction))
                        {
                                $data = array();
                                $data =(array) current($instruction);
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5'];
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$paiement['Makerid_16'];

                                $this->set_table('logiref_rbo_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                        return TRUE;
                }

                public function save_rbo_comptatbilisation_dgda($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');

                                        $data['Status_2']=1;

                                        $data['Account_3']= $paiement['Account_3'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']= $paiement['Makerid_16'];
                                        $data['Reference_14']=$logirefid;
                                        //$data['Priority_24']=$priority;

                                        #$data['Type_25']= $paiement['DataType'];

                                        $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }

                        return TRUE;
                }

                public function save_rbo_comptatbilisation_dgi($pid, $paiement, $instructions, $logirefid)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {

                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $paiement['Account_3'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid; //TBD
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$paiement['Makerid_16'];

                                        $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }

                        return true;

                }

                public function save_rbo_comptatbilisation_dgrad($pid, $paiement, $instructions, $logirefid)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $paiement['Account_3'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $paiement['Banqueid_5'];
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid; //TBD
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$paiement['Makerid_16'];

                                        $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }


                public function save_instructions_sftp_payroll($file,$instructions)
                {
                                if(!empty($instructions))
                                {
                                        foreach($instructions as $instruction)
                                        {
                                                $data=array();
                                                $data=$instruction;

                                                $data['Id_0']='';
                                                $data['Date_1']=gmdate('Y-m-d h:i:s');
                                                $data['Status_2']=1;
                                                $data['Account_3']=$this->session->userdata['account_id'];
                                                $data['Paiementid_4']=$file['Id_0'];
                                                $data['Banqueid_5']=$this->session->userdata['account_id'];
                                                $data['Agence_6']='';
                                                $data['Guichet_7']='';
                                                $data['Makerid_15']=$file['Makerid_4'];
                                                $data['Checkerid_16']=$file['Checkerid_5'];
                                                $data['Branch_code_18']="";

                                                $this->set_table('logiref_cbs_instructions_payroll', 'Id_0', 'Id_0 DESC');
                                                $this->saveData($data, NULL);
                                        }
                                }
                                return TRUE;
                }

                public function save_instructions_permis($pid, $paiement, $instructions, $logirefid, $priority=null)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id'];
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Environment_24'] = 'L';
                                        $data['Priority_29'] = $priority;

                                        $this->set_table('logiref_cbs_instructions_permis', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }
                        return TRUE;
                }

                public function save_instructions_passeport($pid, $paiement, $instructions, $logirefid, $priority=0)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $this->session->userdata['account_id'];
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$this->session->userdata['user_id'];
                                        $data['Priority_27']= $priority;

                                        $this->set_table('logiref_cbs_instructions_passeport', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }

                        return TRUE;
                }

                public function save_instructions_immatriculation($pid, $paiement, $instructions, $logirefid, $priority=0)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $paiement['Account_3'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $paiement['Account_3'];
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$paiement['Makerid_9'];
                                        $data['Priority_27']= $priority;

                                        $this->set_table('logiref_cbs_instructions_immatriculation', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);
                                }
                        }

                        return TRUE;
                }

                public function save_instructions_immatriculation_online($pid, $paiement, $instructions, $logirefid, $priority=0)
                {
                        //Save instructions
                        if(!empty($instructions))
                        {
                                $i = 1;
                                foreach($instructions as $instruction)
                                {
                                        $data = array();
                                        $data = $instruction;
                                        //Variable d'integration
                                        $data['Id_0'] = '';
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']= $paiement['Account_3'];
                                        $data['Paiementid_4']= $pid;
                                        $data['Banqueid_5']= $paiement['Account_3'];
                                        $data['Agence_6']=$paiement['Agence_20'];
                                        $data['Guichet_7']=$paiement['Guichet_21'];
                                        $data['Reference_14']=$logirefid;
                                        $data['Mode_15']=$paiement['Mode_19'];
                                        $data['Makerid_16']=$paiement['Makerid_9'];
                                        $data['Priority_27']= ($i == 1)?$priority:1;

                                        $this->set_table('logiref_cbs_instructions_immatriculation', 'Id_0', 'Id_0 DESC');
                                        $this->saveData($data, NULL);

                                        $i++;
                                }
                        }

                        return TRUE;
                }

                public function delete_instructions_dgi($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgi');
                        $condition = ['Reference_14' => $id];

                        $builder->where($condition);
                        $builder->delete();

                        return $builder;
                }

                public function delete_instructions_dgrad($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgrad');
                        $condition = ['Reference_14' => $id];

                        $builder->where($condition);
                        $builder->delete();

                        return $builder;
                }

                public function delete_instructions_dgda($id)
                {
                        $builder = $this->db->table('logiref_cbs_instructions_dgda');
                        $condition = ['Paiementid_4' => $id];

                        $builder->where($condition);
                        $builder->delete();

                        return $builder;
                }

                public function update_instructions_cbs_dgi($ids, $data)
                {
                        if (strpos($ids, ',') !== false):
                                $ids =  explode(",", $ids);
                        else:
                                $ids = array($ids);
                        endif;

                        $id = $this->db->table('logiref_cbs_instructions_dgi')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $id;
                }

                public function update_instructions_cbs_immatriculation($ids, $data)
                {
                        if (strpos($ids, ',') !== false):
                                $ids =  explode(",", $ids);
                        else:
                                $ids = array($ids);
                        endif;

                        $id = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $id;
                }

                public function update_instructions_cbs_dgrad($ids, $data)
                {
                        if (strpos($ids, ',') !== false):
                                $ids =  explode(",", $ids);
                        else:
                                $ids = array($ids);
                        endif;

                        $id = $this->db->table('logiref_cbs_instructions_dgrad')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $id;
                }

                public function update_instructions_cbs_dgda($ids, $data)
                {
                        if (strpos($ids, ',') !== false):
                                $ids =  explode(",", $ids);
                        else:
                                $ids = array($ids);
                        endif;

                        $id = $this->db->table('logiref_cbs_instructions_dgda')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $id;
                }

                public function update_prepayments_instructions_cbs($ids, $data)
                {
                        if (strpos($ids, ',') !== false):
                                $ids =  explode(",", $ids);
                        else:
                                $ids = array($ids);
                        endif;

                        $id = $this->db->table('logiref_cbs_prepayments_instructions')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $id;
                }

                public function save_regularisations($data, $id)
                {
                        $this->set_table('logiref_cbs_regularisations', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
        }