<?php

namespace Modules\Branch\Models;

use stdClass;
use App\Models\MY_Transaction;

class EncaissementModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Glodi  on the 05.10.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $documents = array(
                            '1' => 'NOTE DE PERCEPTION', 
                            '2' => 'QUITTANCE',
                            '3' => 'BULLETIN DE LIQUIDATION', 
                            '4' => 'NOTE DE VERSEMENT', 
                            '5' => 'DECLARATION'
                        );
	public $devises = array(
                            ''=>'', 
                            'CDF' => 'CDF', 
                            'USD' => 'USD', 
//                            'EUR' => 'EUR', 
//                            'ZAF' => 'ZAF'
                        );
        public $modes = array(
                            ''=>'', 
                            '5' => 'ESPECE', 
                            '7' => 'OP', 
                            '8' => 'OV',
                            '9' => 'CQ',
                            '10' => 'CM'
                        );
        public $reversementStatus = array(
                                        '1' => 'Reverser', 
                                        '2' => 'Regler', 
                                        '3' => 'Niveller'
                                    );
        public $infos = array(
                            'type' => '', 
                            'agence' => '', 
                            'reference' => '', 
                            'moyen' => '', 
                            'standard' => '',
                            'QuotasINPP' => '', 
                            'QuotasINSS' => '', 
                            'QuotasONEM' => '', 
                            'RefINSS' => '', 
                            'RefINPP' => '', 
                            'RefONEM' => '', 
                        ); 
        public $moyens = array(
                            '' => '', 
                            '10' => 'Especes',
                            '20' => 'Cheque', 
                            '21' => 'Lettre bancaire',
                            '22' => 'Lettre bancaire certifiee', 
                            '23' => 'Cheque bancaire (issu par banque ou etablissement financier simil.)', 
                            '24' => 'Cheque particulier signe par la banque',
                            '50' => 'Ordre', 
                            '80' => 'Paiement partiel', 
                            '90' => 'Consentement mutuel',
                        );
	public $order_status = array(
            
                '1'=>"En cours",
                '2'=>"Valid&eacute; (pay&eacute;)",
                '3'=>"Finalis&eacute; (rejet&eacute;)",
                '4'=>"Expir&eacute;",
                ''=>""
        );
        public $color_orders = array(
                '1'=>'label-upcoming',
                '2'=>'label-ongoing',
                '3'=>'label-cancelled',
                '4'=>'label-ongoing',
        );
	
        public $options;
        
	public function __construct()
	{
		parent::__construct();

                $options = $_SESSION['userdata']['options'] ?? null;
                $decodedOptions = is_string($options) ? json_decode($options, true) : null;
                $this->options = is_array($decodedOptions) ? $decodedOptions : array();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_paiement_tresor_by_logirefid($logirefid)
        {
                $this->set_table('logiref_paiements_tresor t', 't.Id_0', 't.Id_0 DESC');
                return $this->get_by(array('Logirefid_4' => $logirefid), TRUE);
        }
        
        public function get_paiement_tresor_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Logirefid_4 = $this->generate_unique_reference();
			$obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];

                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0'; 
                        $obj->Customercode_51 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }

        public function get_paiement_batch_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
			$obj->Changes_5 = ''; 
                        $obj->Changer_6 = '';
                        $obj->Beneficaire_7 = '';
                        $obj->Service_8 = '';
                        $obj-> Recette_9 = '';

                        $obj->Artbudgetaire_10 = '';
                        $obj->Nif_11 = '';
                        $obj->Designation_12 = '';
                        $obj->Montant_13 = '';
                        $obj->Devise_14 = '';
                        $obj->Commission_15 = '';
                        $obj->Devise_16 = '';
                        $obj->Mode_17 = '';
                        $obj->Refop_18 = '';
                        $obj->Compte_19 = '';
                        $obj->Devise_20 = '';
                        $obj->Intitule_21 = ''; 
                        $obj->Taux_22= '';
                        $obj->Paiements_23= '';
                        $obj->Lot_24 = $this->generate_unique_reference();;
                        $obj->Guichet_25 = $_SESSION['Logiref_guichet'];
                        $obj->Nombrepaiements_26 = '';
                        $obj->Montanttotal_27 = '';
                        $obj->Tauxflag_28 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements_tresor_batchs p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }

        public function get_paiement_tresor_permis_info($oid = NULL) 
        {
                if ($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Logirefid_4 = $this->generate_unique_reference();
			$obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];

                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0'; 
                        $obj->Customercode_51 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_paiements_tresor_permis p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }

        public function get_order_info($id = NULL)
        {
                if($id == NULL)
                {
                        $order = new stdClass();
                        $order->Id_0 = '';
                        $order->Date_1 ='';
                        $order->Status_2='';
                        $order->Account_3 ='';
                        $order->Creator_4 ='';
                        $order->Changes_5 ='';
                        $order->Changer_6 ='';
                        $order->Regie_7 ='';
                        $order->Service_8 ='';
                        $order->Bank_9 ='';
                        $order->Account_10 ='';
                        $order->Currency_11 ='';
                        $order->Amount_12 ='';
                        $order->Object_13 ='';
                        $order->Nif_14 ='';
                        return $order;
                }
                else
                {
                        $this->set_table('logiref_payment_orders o', 'o.Id_0', 'o.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_paiement_propre_info($oid = NULL)
        {
                if ($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Logirefid_4 = $this->generate_unique_reference();
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];

                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = '';
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';
                        $obj->Missmatch_46 = '';
                        $obj->Isyserrors_47 = '';
                        $obj->Isysvalidation_48 = '';
                        $obj->Sydonia_49 = '';
                        $obj->Paiementkey_50 = '';
                        $obj->Customercode_51 = '';
                        $obj->Notefile_52 ='';
                        $obj->Seguice_53 = '';
                        $obj->Invoice_54 = '';
                        //$obj->Environment_55 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }

        public function get_paiement_info($oid = NULL)
        {
                if ($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Logirefid_4 = $this->generate_unique_reference();
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = $_SESSION['Logiref_agence'];

                        $obj->Guichet_21 = $_SESSION['Logiref_guichet'];
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';
                        $obj->Missmatch_46 = '';
                        $obj->Isyserrors_47 = '';
                        $obj->Isysvalidation_48 = '';
                        $obj->Sydonia_49 = '';
                        $obj->Paiementkey_50 = '';
                        $obj->Customercode_51 = '';
                        $obj->Notefile_52 ='';
                        $obj->Seguice_53 = '';
                        $obj->Invoice_54 = '';
                        //$obj->Environment_55 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_paiements_tresor p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function check_paiement(){
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                if(isset($_POST['Montant'])) $st .= " AND Montant_11 ='".$_POST['Montant']."'";
                if(isset($_POST['Devise']))   $st .= " AND Devise_12 ='".$_POST['Devise']."'";
                if(isset($_POST['Noteid']))    $st .= " AND Noteid_26 ='".$_POST['Noteid']."'";
                if(isset($_POST['Nif'])) $st .= " AND Nif_13 ='".$_POST['Nif']."'";
                if(isset($_POST['Service'])) $st .= " AND Service_16 ='".$_POST['Service']."'";
                if(isset($_POST['Recette'])) $st .= " AND Typerecette_17 ='".$_POST['Recette']."'";
                if(isset($_POST['Notedate'])) $st .= " AND Notedate_27 ='".$_POST['Notedate']."'";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }
        public function  check_bulletin_tresor($pkey)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Paiementkey_50 IN ($pkey)";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }
        public function  check_bulletin_propres($pkey)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Paiementkey_50 IN ($pkey)";
                
                $query = $this->db->table('logiref_paiements_propres')
                        ->select('logiref_paiements_propres.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }
        public function  check_prepayment_tresor($id, $code_taxe, $noteid)
        {
                $this->set_table('logiref_paiements_tresor t', 't.Id_0', 't.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id, 'Typerecette_17' => $code_taxe, 'Noteid_26' => $noteid), TRUE);
        }
        public function  check_prepayment_propres($id, $code_taxe, $noteid)
        {
                $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id, 'Typerecette_17' => $code_taxe, 'Noteid_26' => $noteid), TRUE);
        }
        public function  check_prepayment_propres_by_note($note)
        {
                $this->set_table('logiref_paiements_propres p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Noteid_26' => $note), TRUE);
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="regies")
                {
                        $ddmenu['Regies'] = array(''=>'', 'DGI'=>'DGI', 'DGRAD'=>'DGRAD', 'DGDA'=>'DGDA');
                        return $ddmenu;
                }
        }
        
        public function get_payement_regie_agence($guichet=NULL, $regie=NULL, $devise=NULL)
        {
            $day = date('Y-m-d');
            if($regie == "DGRAD"){
                $query = $this->db->table("logiref_paiements_tresor")
                   ->select("SUM(Montant_11) as Montant, count(Devise_12) as Total, Devise_12")
                   ->where("Devise_12 = '".$devise."' AND Checkerid_10 <> 0 AND Date_1 LIKE '%".$day."%' AND Sydonia_44 = 0 AND Sydonia_49 = 0 AND Status_2 = 1 AND Account_3 = ".$this->session->userdata['account_id']." AND Guichet_21 = ".$guichet." AND Beneficaire_15 = '".$regie."' Group by Devise_12")
                   ->get();
                return $query->getRowArray();
            }
            elseif($regie == "DGI")
            {
                $query = $this->db->table("logiref_paiements_tresor")
                   ->select("SUM(Montant_11) as Montant, count(Devise_12) as Total, Devise_12")
                   ->where("Devise_12 = '".$devise."' AND Checkerid_10 <> 0 AND Date_1 LIKE '%".$day."%' AND Sydonia_44 = 0 AND Sydonia_49 = 0 AND Status_2 = 1 AND Account_3 = ".$this->session->userdata['account_id']." AND Guichet_21 = ".$guichet." AND Beneficaire_15 = '".$regie."' Group by Devise_12")
                   ->get();
                return $query->getRowArray();
            }
            else{
                $query = $this->db->table("logiref_integration_sydonia")
                    ->select("SUM(Amount_25) as Montant, count(Devise_29) as Total, Devise_29")
                    ->where("Devise_29 = '".$devise."' AND Date_1 LIKE '%".$day."%' AND Status_2 > 2 AND Account_3 = ".$this->session->userdata['account_id']." AND Agence_32 = ".$guichet." Group by Devise_29")
                    ->get();
                return $query->getRowArray();
            }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_stats($type=NULL)
        {
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_4'];
                        $eur = $bank['Euro_5'];
                        $rand = $bank['Rand_6'];
                        $pound = $bank['Pound_7'];
                }
                if($type=="dash_stats"){

                        $stats = [
                                "commission_DGI" => 0,
                                "paiement_DGI" => 0,
                                "tva_DGI" => 0,

                                "commission_DGRAD" => 0,
                                "paiement_DGRAD" => 0,
                                "tva_DGRAD" => 0,

                                "commission_DGDA" => 0,
                                "paiement_DGDA" => 0,
                                "tva_DGDA" => 0,
                        ];

                        $session = $this->session->userdata;
                        $guichet = $_SESSION['Logiref_guichet'] ?? null;
                        $usd = 1;

                        $whereCondition = [
                                'Status_2' => '1',
                                'Account_3' => $session['account_id'],
                                'Guichet_21' => $guichet
                        ];

                        $whereConditionDGDA = [
                                'Status_2' => '1',
                                'Account_3' => $session['account_id'],
                                'Agence_32' => $guichet
                        ];

                        $builder = $this->db->table('logiref_paiements_tresor')
                                ->select('*')
                                ->where($whereCondition)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();

                        foreach ($builder->getResultArray() as $row)
                        {
                                if ($row['Datevaleur_31'] == gmdate('Y-m-d'))
                                {
                                        $multiplier = ($row['Devise_24'] == 'USD') ? $usd : 1;

                                        if ($row['Beneficaire_15'] == "DGI")
                                        {
                                                $stats['commission_DGI'] += $row['Commission_23'] * $multiplier;
                                                $stats['paiement_DGI'] += $row['Montant_11'] * $multiplier;
                                                $stats['tva_DGI'] += (($row['Commission_23'] * $multiplier) * 16) / 100;
                                        }
                                        elseif ($row['Beneficaire_15'] == "DGRAD")
                                        {
                                                $stats['commission_DGRAD'] += $row['Commission_23'] * $multiplier;
                                                $stats['paiement_DGRAD'] += $row['Montant_11'] * $multiplier;
                                                $stats['tva_DGRAD'] += (($row['Commission_23'] * $multiplier) * 16) / 100;
                                        }
                                }
                        }

                        $builderDGDA = $this->db->table('logiref_integration_sydonia')
                                ->select('*')
                                ->where($whereConditionDGDA)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();

                        foreach ($builderDGDA->getResultArray() as $row) {

                                if ($row['Dateliquidation_40'] == gmdate('Y-m-d'))
                                {
                                        $multiplier = ($row['Devise_27'] == 'USD') ? $usd : 1;

                                        $stats['commission_DGDA'] += $row['Commission_26'] * $multiplier;
                                        $stats['paiement_DGDA'] += $row['Amount_12'] * $multiplier;
                                        $stats['tva_DGDA'] += (($row['Commission_23'] * $multiplier) * 16) / 100;
                                }
                        }

                        return $stats;

                }
                elseif($type=='dash_operators')
                {

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21 = '" . $_SESSION['Logiref_guichet'] . "' ";

                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('DISTINCT(Makerid_9) as Marker')
                                ->where($st)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();

                        $operators = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                if (!isset($operators[$row['Marker']])) {

                                        $value = array(
                                                "guichets" => "",
                                                "date" => "",
                                                "paiements" => '0',
                                                "commissions" => '0',
                                                "tva" => '0'
                                        );

                                        $builder1 = $this->db->table('logiref_paiements_tresor')
                                                ->select('*')
                                                ->where("Makerid_9", $row['Marker'])
                                                ->like('Date_1', gmdate('Y-m-d'))
                                                ->get();

                                        foreach ($builder1->getResultArray() as $rows) {
                                                $value['guichets'] = $rows['Guichet_21'];
                                                $value['date'] = $rows['Date_1'];

                                                if ($rows['Datevaleur_31'] == gmdate('Y-m-d'))
                                                {
                                                        if ($rows['Devise_24'] == 'USD')
                                                        {
                                                                $value['commissions'] += $rows['Commission_23'] * $usd;
                                                                $value['paiements'] += $rows['Montant_11'] * $usd;
                                                                $value['tva'] += (($rows['Commission_23'] * $usd) * 16) / 100;
                                                        }
                                                        elseif ($rows['Devise_24'] == 'CDF')
                                                        {
                                                                $value['commissions'] += $rows['Commission_23'];
                                                                $value['paiements'] += $rows['Montant_11'];
                                                                $value['tva'] += ($rows['Commission_23'] * 16) / 100;
                                                        }
                                                }
                                        }

                                        $builder2 = $this->db->table('logiref_integration_sydonia')
                                                ->select('*')
                                                ->where("Maker_36", $row['Marker'])
                                                ->like('Date_1', gmdate('Y-m-d'))
                                                ->get();

                                        foreach ($builder2->getResultArray() as $rows)
                                        {
                                                $value['guichets'] = $rows['Agence_32'];
                                                $value['date'] = $rows['Date_1'];

                                                if ($rows['Dateliquidation_40'] == gmdate('Y-m-d'))
                                                {
                                                        if ($rows['Devise_27'] == 'USD')
                                                        {
                                                                $value['commissions'] += $rows['Commission_26'] * $usd;
                                                                $value['paiements'] += $rows['Amount_12'] * $usd;
                                                                $value['tva'] += (($rows['Commission_26'] * $usd) * 16) / 100;
                                                        }
                                                        elseif ($rows['Devise_27'] == 'CDF')
                                                        {
                                                                $value['commissions'] += $rows['Commission_26'];
                                                                $value['paiements'] += $rows['Amount_12'];
                                                                $value['tva'] += ($rows['Commission_26'] * 16) / 100;
                                                        }
                                                }
                                        }

                                        $operators[$row['Marker']] = $value;
                                }
                        }


                        return $operators;

                }
                elseif($type=='commission')
                {
                        $stats = array(

                                "1" => '0', //'Commission de l'annee,
                                "2" => '0', //'Commission du mois,
                                "3" => '0', //'Commission de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_20 = '" . $_SESSION['Logiref_agence'] . "' ";

                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where($st)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();

                        foreach ($query->getResultArray() as $row)
                        {
                                $dateString = $row['Datevaleur_31'];
                                list($year, $month, $day) = explode('-', $dateString);

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Commission_23'];
                                        } 
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Commission_23'];
                                        }
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Commission_23'];
                                        }
                                }

                        }

                        return $stats;
                }
                elseif($type=='paiement')
                {

                        $stats = array(

                                "1" => '0', //'Paiement de l'annee,
                                "2" => '0', //'Paiement du mois,
                                "3" => '0', //'Paiement de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Account_3='" . $_SESSION['Logiref_agence'] . "'";
                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where($st)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();

                        $result = $query->getResultArray();

                        foreach ($result as $row)
                        {

                                $dateString = $row['Datevaleur_31'];
                                list($year, $month, $day) = explode('-', $dateString);

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Montant_11'];
                                        }
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Montant_11'];
                                        } 
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Montant_11'];
                                        } 
                                }

                        }

                        return $stats;
                }
                elseif($type=='paiement_guichet')
                {

                        $stats = array(

                                "1" => '0', //'Paiement de la journee,
                        );

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Account_3='" . $_SESSION['Logiref_agence'] . "'";

                        if(!empty($data))
                        {
                                if(isset($data['agence']) && !empty($data['agence']))
                                {
                                        $st .= " AND Guichet_21 ='".$data['agence']."'";
                                }

                                if((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end'])))
                                {
                                        $st .= " AND (Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."')";
                                }

                                $query = $this->db->table('logiref_paiements_tresor')
                                        ->select('logiref_paiements_tresor.*')
                                        ->where($st)
                                        ->like('Date_1', gmdate('Y-m-d'))
                                        ->get();

                                foreach ($query->getResult() as $row)
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Montant_11'];
                                        }
                                }
                        }

                        return $stats;

                }
                elseif($type=='paiement_situation_cdf')
                {
                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21 = '" . $_SESSION['Logiref_guichet'] . "' ";

                        $query = $this->db->table('logiref_paiements_tresor')
                                        ->select('logiref_paiements_tresor.*')
                                        ->where($st)
                                        ->like('Date_1', gmdate('Y-m-d'))
                                        ->get();

                        foreach ($query->getResult() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='CDF')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }

                        return $stats;
                }
                elseif($type=='paiement_situation_usd')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );
                        
                        
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21 = '" . $_SESSION['Logiref_guichet'] . "' ";
                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        
                        foreach ($query->getResult() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='USD')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='USD')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='USD')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }
                        
                        return $stats;
                }
                elseif($type=='paiement_situation_regie')
                {
                        $this->_table_name = '';

                        $stats = array(

                                "dgi_unvalidated" => '0',
                                "dgi_unvalidated_number" => '0',
                                "dgi_validated" => '0',
                                "dgi_validated_number" => '0',
                                "dgda_unvalidated" => '0',
                                "dgda_unvalidated_number" => '0',
                                "dgda_validated" => '0',
                                "dgda_validated_number" => '0',
                                "dgrad_unvalidated" => '0',
                                "dgrad_unvalidated_number" => '0',
                                "dgrad_validated" => '0',
                                "dgrad_validated_number" => '0',
                        );
                        
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21 = '" . $_SESSION['Logiref_guichet'] . "' ";
                        $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();
                        
                        foreach ($query->getResult() as $row)
                        {
                                if($row['Checkerid_10']==0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + $row['Montant_11'];
                                                        }
                                                        $stats['dgi_unvalidated_number'] = $stats['dgi_unvalidated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Sydonia_44'] !='0' && $row['Status_2'] !='1')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgda_unvalidated_number'] = $stats['dgda_unvalidated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgrad_unvalidated_number'] = $stats['dgrad_unvalidated_number'] +1;
                                                }
                                        }
                                }
                                elseif($row['Checkerid_10']>0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgi_validated'] = $stats['dgi_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgi_validated'] = $stats['dgi_validated'] + $row['Montant_11'];
                                                        }
                                                        $stats['dgi_validated_number'] = $stats['dgi_validated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Sydonia_44'] !='0' && $row['Status_2'] =='1')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgda_validated'] = $stats['dgda_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgda_validated'] = $stats['dgda_validated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgda_validated_number'] = $stats['dgda_validated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgrad_validated'] = $stats['dgrad_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgrad_validated'] = $stats['dgrad_validated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgrad_validated_number'] = $stats['dgrad_validated_number'] +1;
                                                }
                                        }
                                }
                        }
                        
                        return $stats;
                }
        }
        
        public function get_paiements_stats($type=NULL, $id=NULL)
        {     
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_4'];
                        $eur = $bank['Euro_5'];
                        $rand = $bank['Rand_6'];
                        $pound = $bank['Pound_7'];
                }
                else
                {
                    $usd = 1;
                }
                
                
                if($type=='guichet_filter')
                {
                        $this->_table_name = '';

                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        
                        $paiement_total = 0;
                        $commission_total = 0;
                        $commission_contreval = 0;
                        $commission_cdf = 0;
                        $nombre=0;
                        $paiement_contreval = 0;
                        $paiement_cdf = 0;
                        
                        
                        $st = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata['account_id'] . "'";
                        
                        /*if(isset($_POST['agence']) && !empty($_POST['agence']))
                        {
                                $st .= " AND g.Id_0 ='".$_POST['agence']."'";
                                
                                if(isset($_POST['start']) && !empty($_POST['start']))
                                {
                                        $st .= " AND (p.Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."')";
                                }
                        }*/
                        if((isset($_POST['start']) && !empty($_POST['start'])) && (isset($_POST['end']) && !empty($_POST['end'])))
                        {
                                $st .= " AND (p.Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."')";
                        }
                        
                        $query = $this->db->table('logiref_paiements_tresor as p')
                                ->select('*', 'logiref_paiements_tresor.Id_0 DESC')
                                //->join('logiref_guichets as g', 'p.Guichet_21 = g.Id_0')
                                ->where($st,NULL, FALSE)
                                ->like('p.Date_1', gmdate('Y-m-d'))
                                ->get();
                        $result = $query->getResultArray();
                        
                        
                        
                        foreach ($result as $row)
                        {
                                if($row['Devise_12']=='USD')
                                {
                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                                }
                                
                                $nombre++;
                        }
                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        $commission_total = $commission_contreval + $commission_cdf;
                        $data['paiement'] = $paiement_total;
                        $data['nombre'] = $nombre;
                        $data['commission'] = $commission_total;
                        
                        if(empty($result))
                        {
                               $data = array(); 
                        }
                        
                        return $data;
                }
                elseif($type=='guichet')
                {
                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        //                        $paiement_total = 0;
                        //                        $commission_total = 0;
                        //                        $commission_contreval = 0;
                        //                        $commission_cdf = 0;
                        //                        $nombre=0;
                        //                        $paiement_contreval = 0;
                        //                        $paiement_cdf = 0;
                        //                        
                        //                        //$st = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata['account_id'] . "' AND g.Id_0='".$id."' AND p.Agence_20='" . $_SESSION['Logiref_agence'] . "'";
                        //                        
                        //                        $query = $this->db->table('logiref_paiements_tresor')
                        //                                ->join('logiref_guichets ', 'logiref_paiements_tresor.Guichet_21 = logiref_guichets.Id_0')
                        //                                ->where('logiref_paiements_tresor.Account_3', $this->session->userdata['account_id'])
                        //                                ->orderBy('Id_0', 'ASC')
                        //                                ->get();
                        //                        //return $query->getResult();
                        //                        $rr =  $query->getResult();
                        //                        
                        //                        var_dump($rr); die;
                        //                        
                        //
                        //                        foreach ($query->result_array() as $row)
                        //                        {
                        //                                if($row['Devise_12']=='USD')
                        //                                {
                        //                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                        //                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                        //                                }
                        //                                elseif($row['Devise_12']=='CDF')
                        //                                {
                        //                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                        //                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                        //                                }
                        //                                
                        //                                $nombre++;
                        //                        }
                        //                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        //                        $commission_total = $commission_contreval + $commission_cdf;
                        //                        $data['paiement'] = $paiement_total;
                        //                        $data['nombre'] = $nombre;
                        //                        $data['commission'] = $commission_total;
                        
                        return $data;
                }
                elseif($type=='agence')
                {
                        $this->_table_name = '';

                        $data = array(
                                    "paiement" => '0',
                                    "commission" => '0',
                                    "nombre" => '0'
                                );
                        $paiement_total = 0;
                        $commission_total = 0;
                        $commission_contreval = 0;
                        $commission_cdf = 0;
                        $nombre=0;
                        $paiement_contreval = 0;
                        $paiement_cdf = 0;
                        $st0 = " p.Status_2 != 0 AND p.Account_3='" . $this->session->userdata['account_id'] . "' AND g.Id_0='".$id."' ";
                        $query = $this->db->select('*', 'logiref_paiements_tresor.Id_0 DESC')
                                ->from('logiref_paiements_tresor as p')
                                ->join('logiref_agences as g', 'p.Agence_20 = g.Id_0')
                                ->like('p.Date_1', gmdate('Y-m-d'))
                                ->where($st0,NULL, FALSE)
                                ->get();

                        foreach ($query->result_array() as $row)
                        {
                                if($row['Devise_12']=='USD')
                                {
                                        $paiement_contreval = $paiement_contreval + ($row['Montant_11']*$usd);
                                        $commission_contreval = $commission_contreval + ($row['Commission_23']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $paiement_cdf = $paiement_cdf + $row['Montant_11'];
                                        $commission_cdf = $commission_cdf + $row['Commission_23'];
                                }
                                
                                $nombre++;
                        }
                        $paiement_total = $paiement_contreval + $paiement_cdf;
                        $commission_total = $commission_contreval + $commission_cdf;
                        $data['paiement'] = $paiement_total;
                        $data['nombre'] = $nombre;
                        $data['commission'] = $commission_total;
                        return $data;
                }
        }
        
        public function get_id_by_reference($ref) 
        {
                $st = " Logirefid_4='" . $ref . "'";
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $result = $query->getResultArray();
               
                if(!empty($result))
                {
                        foreach ($result as $row) 
                        {
                                $id = $row['Id_0'];
                        }
                }
                else
                {   
                        $id = "";   
                }
                
                return $id;
        }
        
        public function get_regle_penalites()
        {
                $st = " Status_2='1' AND Checkerid_15 <> 0 ";
                $query = $this->db->table('logiref_penalites')
                        ->select('logiref_penalites.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $result = $query->getResult();
                
                return $result;
        }
        
        public function get_paiement_tresor_bl($id)
        {
                $this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
        }
        
        public function get_prepaiement_tresor_bl($id)
        {
                $this->set_table('logiref_paiements_tresor I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id), TRUE);
        }
        
        public function get_paiement_propres_bl($id)
        {
                $this->set_table('logiref_paiements_propres I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_44' => $id), TRUE);
        }
        
        public function get_prepaiement_propres_bl($id)
        {
                $this->set_table('logiref_paiements_propres I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_49' => $id), TRUE);
        }
        
        public function get_paiements($type=NULL) 
        {
                
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0 ";
                
                #Filtre d'affichage
                if($type=='attente') $st .= " AND Checkerid_10='0'";
                elseif($type=='urgents') $st .= " AND Checkerid_10='0' AND Datevaleur_31<'".gmdate('Y-m-d')."'";
                elseif($type=='validated') $st .= " AND Status_2 = '2'";
                elseif($type=='nvalidated') $st .= " AND Status_2 = '1' AND Checkerid_10 = 0";
                elseif($type=='transferred') $st .= " AND Status_2 = '4'";
                elseif($type=='virement') $st .= " AND Mode_19 = '7'";
                elseif($type=='penalities') $st .= " AND Status_2 = '1' AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1";
                #Restriction
                if($_SESSION['Logiref_role'] ==4 || $_SESSION['Logiref_role'] ==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role'] ==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
        }

        public function get_paiements_immatriculation($type=NULL) 
        {
                
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0 ";
                
                #Filtre d'affichage
                if($type=='attente') $st .= " AND Checkerid_10='0'";
                elseif($type=='urgents') $st .= " AND Checkerid_10='0' AND Datevaleur_31<'".gmdate('Y-m-d')."'";
                elseif($type=='validated') $st .= " AND Status_2 = '2'";
                elseif($type=='nvalidated') $st .= " AND Status_2 = '1' AND Checkerid_10 = 0";
                elseif($type=='transferred') $st .= " AND Status_2 = '4'";
                elseif($type=='virement') $st .= " AND Mode_19 = '7'";
                elseif($type=='penalities') $st .= " AND Status_2 = '1' AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1";
                #Restriction
                if($_SESSION['Logiref_role'] ==4 || $_SESSION['Logiref_role'] ==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role'] ==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_paiements_tresor_immatriculation')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
        }
        
        public function get_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        
        public function get_nvalidated_to_integrate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
        {
                //$st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=7 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10 > '0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
        }
        
        
        public function filter_nvalidated_paiements($regie)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND Beneficaire_15='$regie' AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_filterd_paiements($data, $type=NULL) 
        {
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0 ";
                if(isset($data['operator']) && $data['operator'] != '') $st .=" AND Makerid_9 ='".$data['operator']."'";
                if(isset($data['start']) && isset($data['end']) && ($data['start'] != '' && $data['end'] != '')) $st .="AND (Datevaleur_31 BETWEEN '".$data['start']."' AND '".$data['end']."')";
                
                #Restriction
                if($_SESSION['Logiref_role']==3) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
        }
        
        
        public function get_ordres($obj=NULL, $param=NULL, $data=NULL)
        {
            
                    if($obj=='regie')
                    {
                            $regie = $_SESSION['Logiref_regies'];
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Regie_7 = '" .$regie."'";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                        
                    }
                    elseif($obj=='bank')
                    {
                            $bank = $param;
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Bank_9 ='".$bank."'";
                            if($data =="new") $st= "Bank_9 ='".$bank."' AND Status_2 = 1 "; else $st = "Bank_9 ='".$bank."' AND Status_2 > 1";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                    }
                    else
                    {
                            $this->_table_name = '';
                            $this->db->select('logiref_payment_orders.*', 'logiref_payment_orders.Id_0 ASC');
                            $this->db->from('logiref_payment_orders');
                            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                            $this->db->where($st, NULL, FALSE);
                            $this->db->order_by('Id_0 DESC');
                            return $this->get_all();
                    }
        }
        
        public function get_montant_total($data=NULL) 
        {
                $total_montant = "";
                
                if(!empty($data))
                {
                        $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','',$data['Commission_23']);
                        
                        $tva = $data['Commission_23']*0.16;
                        
                        $tva = round($tva, 2);
                        
                        $total_montant = $data['Montant_11'] + $data['Commission_23'] + $tva;
                }
                return  $total_montant;
        }
        
        public function get_code_agence_client($data=NULL) 
        {
                $compte_client = $data['Compte_33'];
                $compte = explode("-", $compte_client);
                $code_agence = $compte[0];

                return $code_agence;
        }

        public function get_last_paiement_id()
        {
                $query = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->orderBy('Id_0', 'DESC')
                        ->limit(1)
                        ->get();

                $return = $query->getResult();

                if(isset($return[0]->Id_0)) $lastid = $return[0]->Id_0;
                else $lastid = 0;

                return $lastid;
        }

        public function get_paiement_by_transactionid($ref)
        {
		$st = " Date_1 LIKE '%" . gmdate('Y-m-d') . "%' AND Status_2 <> 0  AND Mode_19 ='5' AND Reference_32='".$ref."'";
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('logiref_paiements_tresor.Id_0','DESC')
                        ->get();

                return $builder->getResult();
        }

        public function get_paiement_permis_by_transactionid($ref)
        {
		$st = " Date_1 LIKE '%" . gmdate('Y-m-d') . "%' AND Status_2 <> 0  AND Mode_19 ='5' AND Reference_32='".$ref."'";
                $builder = $this->db->table('logiref_paiements_tresor_permis')
                        ->select('logiref_paiements_tresor_permis.*')
                        ->where($st)
                        ->orderBy('logiref_paiements_tresor_permis.Id_0','DESC')
                        ->get();

                return $builder->getResult();
        }

        public function get_paiement_passeport_by_transactionid($ref)
        {
		$st = " Date_1 LIKE '%" . gmdate('Y-m-d') . "%' AND Status_2 <> 0  AND Mode_19 ='5' AND Reference_32='".$ref."'";
                $builder = $this->db->table('logiref_paiements_tresor_permis')
                        ->select('logiref_paiements_tresor_passeport.*')
                        ->where($st)
                        ->orderBy('logiref_paiements_tresor_passeport.Id_0','DESC')
                        ->get();

                return $builder->getResult();
        }

        /*
        * Save Information: insert or update an array
        * Use: batch processing (notes update)
        * Description: ce bloc gère le traitement en lot des mises à jour des notes
        * P.S: Ajoutez vos méthodes ci-dessous !!
        * ************************************************************************************************************************* SECTION 5
        */

        public function validate_batch_data(): array
        {
                $data_amounts = [
                        'Montant_note'   => $this->normalize_amount($_POST['Montant_note'] ?? 0),
                        'Total_topaid'   => $this->normalize_amount($_POST['Total_topaid'] ?? 0),
                        //'Total_com'      => $this->normalize_amount($_POST['Total_com'] ?? 0),
                        //'Commission_lot' => $this->normalize_amount($_POST['Commission_lot'] ?? 0),
                ];

                # Vérification montants
                $amount_check = $this->validate_positive_amount_array($data_amounts);
                if ($amount_check['code'] !== 200) return $amount_check;

                # Vérification champs requis
                $required_check = $this->validate_required_fields();
                if ($required_check['code'] !== 200) return $required_check;

                return [
                        'code'    => 200,
                        'message' => 'Les données du lot sont valides.',
                        'data'    => []
                ];
        }

        public function validate_required_fields(): array
        {
                $required = [
                        'Beneficaire'    => "Nom de la régie",
                        'Service'        => "Service recouvrement",
                        //'Recette'        => "Nature paiement",
                        'Designation'    => "Désignation de la note",
                        'Compte'         => "Compte du client",
                        'Devise_compte'  => "Devise du client",
                        'Mode'           => "Mode de paiement",
                        'Montant_note'    => "Montant du lot",
                        'Devise_note'    => "Devise de la note",
                        'Total_topaid'   => "Montant total du lot",
                ];

                foreach ($required as $key => $label) 
                {
                        $value = $_POST[$key] ?? '';

                        if ($value === null || trim($value) === '') 
                        {
                                return [
                                        'code'    => 400,
                                        'message' => "Une information obligatoire « {$label} » est manquante ou vide.",
                                        'data'    => ['field' => $key]
                                ];
                        }
                }

                return [
                        'code'    => 200,
                        'message' => 'Tous les champs obligatoires sont renseignés.',
                        'data'    => []
                ];
        }

        public function validate_positive_amount_array(array $amounts): array
        {
                foreach ($amounts as $key => $amount) 
                {
                        if (!is_numeric($amount) || $amount <= 0) 
                        {
                                return [
                                        'code'    => 403,
                                        'message' => "Le montant « {$key} » doit être supérieur à zéro.",
                                        'data'    => ['field' => $key, 'value' => $amount]
                                ];
                        }
                }

                return [
                        'code'    => 200,
                        'message' => 'Tous les montants sont valides.',
                        'data'    => []
                ];
        }

        public function build_notes_batch_data($data = NULL)
        {                
                $notes = [ 
                        'recettes'   => $_POST['recettes'] ?? [], 
                        'references' => $_POST['references'] ?? [], 
                        'devises'    => $_POST['devises'] ?? [], 
                        'amounts'    => $_POST['amounts'] ?? [] 
                ];

                $amounts = 0; $i=1;
                for($i=1; $i<=count($notes['amounts']); $i++) 
                {
                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                        $amount = str_replace(',','.', $amount);

                        $amounts += $amount;
                }

                //$total_amount     = $this->normalize_amount($_POST['Montant_note'] ?? 0);
                //$total_to_paid    = $this->normalize_amount($_POST['Total_topaid'] ?? 0);
                $total_amount     = $this->normalize_amount($amounts ?? 0);
                $total_commission = $this->normalize_amount($_POST['Total_com'] ?? 0);
                $taux             = $this->normalize_amount($_POST['Taux'] ?? 1);

                $frais_bcc = 0;
                if(isset($this->options['ALL']['bcc-fees-deduction']) && ($_POST['Devise_note'] ?? '') == 'CDF')
                        $frais_bcc = ($total_amount * 0.5) / 1000;

                $frais_bcc      = $this->normalize_amount($frais_bcc ?? 0);
                $total_to_paid  = $total_amount + $total_commission + ($total_commission * 0.16) + $frais_bcc;
                $total_to_paid  = $this->normalize_amount($total_to_paid ?? 0);

                $note_reference = [
                        'commision_note'        => $_POST["Commission_lot"] ?? 0,
                        'comm_attestation'      => $_POST['Com_attestation'] ?? 0 ,
                        'devise_comm'           => $_POST['Devise_com'] ?? '',
                        'paid_attestation'      => $_POST['PaidATTESTATION']  ?? '',
                ];

                return [
                        'Date_1'              => gmdate('Y-m-d H:i:s'),
                        'Status_2'            => 1,
                        'Account_3'           => $_SESSION['userdata']['account_id'] ?? '',
                        'Creator_4'           => $_SESSION['userdata']['user_id'] ?? '',
                        'Changes_5'           => '',
                        'Changer_6'           => '',
                        'Beneficaire_7'       => $_POST['Beneficaire'] ?? '',
                        'Service_8'           => $_POST['Service'] ?? '',
                        'Recette_9'           => json_encode($notes['recettes'], JSON_UNESCAPED_UNICODE),
                        'Artbudgetaire_10'    => json_encode($notes['recettes'], JSON_UNESCAPED_UNICODE),
                        'Nif_11'              => $_POST['Nif'] ?? '',
                        'Designation_12'      => $_POST['Designation'] ?? '',
                        'Montant_13'          => $total_amount,
                        'Devise_14'           => $_POST['Devise_note'] ?? '',
                        'Commission_15'       => $total_commission ?? '',
                        'Devise_16'           => $_POST['Devise_com'] ?? '',
                        'Mode_17'             => $_POST['Mode'] ?? '',
                        'Refop_18'            => $_POST['RefOp'] ?? '',
                        'Compte_19'           => $_POST['Compte'] ?? '',
                        'Devise_20'           => $_POST['Devise_compte'] ?? '',
                        'Intitule_21'         => $_POST['Account_name'] ?? '',
                        'Taux_22'             => $taux,
                        'Paiements_23'        => json_encode($notes, JSON_UNESCAPED_UNICODE),
                        'Lot_24'              => $this->generate_unique_reference(),
                        'Guichet_25'          => $_SESSION['Logiref_guichet'] ?? "",
                        'Nombrepaiements_26'  => $_POST['Total_line'] ?? '',
                        'Montanttotal_27'     => $total_to_paid,
                        'Tauxflag_28'         => $_POST['Tauxflag'] ?? 0,
                        'Makerid_32'          => $_SESSION['userdata']['user_id'] ?? '',
                        'Notereference_34'    => json_encode($note_reference,  JSON_UNESCAPED_UNICODE),
                ];
        }

        public function build_notes_batch_data_updated()
        {                
                $notes = [ 
                        'recettes'   => $_POST['recettes'] ?? [], 
                        'references' => $_POST['references'] ?? [], 
                        'devises'    => $_POST['devises'] ?? [], 
                        'amounts'    => $_POST['amounts'] ?? [] 
                ];

                $amounts = 0; $i=1;
                for($i=1; $i<=count($notes['amounts']); $i++) 
                {
                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                        $amount = str_replace(',','.', $amount);

                        $amounts += $amount;
                }

                $total_amount     = $this->normalize_amount($amounts ?? 0);
                $total_commission = $this->normalize_amount($_POST['Total_com'] ?? 0);

                $frais_bcc = 0;
                if(isset($this->options['ALL']['bcc-fees-deduction']) && ($_POST['Devise_note'] ?? '') == 'CDF')
                        $frais_bcc = ($total_amount * 0.5) / 1000;

                $frais_bcc      = $this->normalize_amount($frais_bcc ?? 0);
                $total_to_paid  = $total_amount + $total_commission + ($total_commission * 0.16) + $frais_bcc;
                $total_to_paid  = $this->normalize_amount($total_to_paid ?? 0);

                return [
                        'Changes_5'           => gmdate('Y-m-d H:i:s'),
                        'Changer_6'           => $_SESSION['userdata']['user_id'] ?? '',
                        'Service_8'           => $_POST['Service'] ?? '',
                        'Recette_9'           => json_encode($notes['recettes'], JSON_UNESCAPED_UNICODE),
                        'Artbudgetaire_10'    => json_encode($notes['recettes'], JSON_UNESCAPED_UNICODE),
                        'Nif_11'              => $_POST['Nif'] ?? '',
                        'Designation_12'      => $_POST['Designation'] ?? '',
                        'Montant_13'          => $total_amount,
                        'Devise_14'           => $_POST['Devise_note'] ?? '',
                        'Commission_15'       => $total_commission ?? '',
                        'Devise_16'           => $_POST['Devise_com'] ?? '',
                        'Mode_17'             => $_POST['Mode'] ?? '',
                        'Refop_18'            => $_POST['RefOp'] ?? '',
                        'Compte_19'           => $_POST['Compte'] ?? '',
                        'Devise_20'           => $_POST['Devise_compte'] ?? '',
                        'Intitule_21'         => $_POST['Account_name'] ?? '',
                        'Paiements_23'        => json_encode($notes, JSON_UNESCAPED_UNICODE),
                        'Guichet_25'          => $_SESSION['Logiref_guichet'] ?? "",
                        'Nombrepaiements_26'  => $_POST['Total_line'] ?? '',
                        'Montanttotal_27'     => $total_to_paid,
                        'Tauxflag_28'         => $_POST['Tauxflag'] ?? 0,
                        'Makerid_32'          => $_SESSION['userdata']['user_id'] ?? '',
                ];
        }

        public function build_payment_data(array $line, array $data_to_batch): array
        {
                $total_amount     = $this->normalize_amount($line["montant"] ?? 0);
                $amount           = $this->normalize_amount($line["montant"] ?? 0);

                $bank = json_decode($_SESSION['Bank_rates'], true);
                $taux = $bank['Dollar_4'] ?? 1;
                $taux = $this->normalize_amount($taux ?? 1);

                $note_reference = [
                        'Branch_code'           => '',
                        'standard'              => $line["recette"] ?? '',
                        'totalMontant'          => $total_amount ,
                        'totalDevise'           => $line['devise']  ?? '',
                        'accountname'           => $_POST['Account_name'] ?? '',
                        'accountType'           => $_POST['accountType'] ?? '',
                        'paiementType'          => 'Batch'
                ];

                if (($_POST['PaidATTESTATION'] ?? '') == "FIA")
                {
                        $note_reference['PaidATTESTATION'] = $_POST['PaidATTESTATION'];
                        $note_reference['CommissionAttestation'] = $_POST['Com_attestation'] ?? '';
                } 

                if (isset($_POST['PaidDUPLICATA'])) $note_reference['PaidAttestDup'] = "1";

                $contrevaleur = ($line['devise'] != 'CDF') ? $amount * ($taux) : $amount;
              
                return [
                        'Date_1'                => gmdate('Y-m-d H:i:s'),
                        'Status_2'              => 1,
                        'Account_3'             => $_SESSION['userdata']['account_id'] ?? '',
                        'Logirefid_4'           => $data_to_batch['Lot_24'] ?? '',
                        'Makerid_9'             => $data_to_batch['Makerid_32'] ?? '',
                        'Montant_11'            => $amount,
                        'Devise_12'             => $line['devise'] ?? '',
                        'Nif_13'                => $data_to_batch['Nif_11'] ?? '',
                        'Designation_14'        => $data_to_batch['Designation_12'] ?? '',
                        'Beneficaire_15'        => $data_to_batch['Beneficaire_7'] ?? '',
                        'Service_16'            => $data_to_batch['Service_8'] ?? '',
                        'Typerecette_17'        => $line["recette"] ?? '',
                        'Artbudgetaire_18'      => $line["recette"] ?? '',
                        'Mode_19'               => $data_to_batch['Mode_17'] ?? '',
                        'Agence_20'             => $_SESSION['Logiref_agence'] ?? '',
                        'Guichet_21'            => $_SESSION['Logiref_guichet'] ?? '',
                        'Contrevaleur_22'       => $contrevaleur,
                        'Commission_23'         => $_POST['Commission'] ?? 0,
                        'Devise_24'             => $data_to_batch['Devise_16'] ?? '',
                        'Notetype_25'           => '1',
                        'Noteid_26'             => $line["numero"] ?? '',

                        'Notedate_27'           => $_POST["Notedate"] ?? '',
                        'Notemontant_28'        => $amount ,

                        'Notedate_27'           => date('Y-m-d', strtotime($_POST["Notedate"] ?? '')),
                        'Notemontant_28'        => $amount,
                        'Notedevise_29'         => $line["devise"] ?? '',
                        'Notereference_30'      => json_encode($note_reference,  JSON_UNESCAPED_UNICODE),
                        'Datevaleur_31'         => gmdate('Y-m-d H:i:s'),
                        'Reference_32'          => $data_to_batch['Refop_18'] ?? '',
                        'Compte_33'             => $data_to_batch['Compte_19'] ?? '',
                        'Devise_34'             => $data_to_batch['Devise_20'] ?? '',
                        'Taux_41'               => $taux,
                        'Devise_42'             => $line['devise'],
                        'Paiementkey_50'        => rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').$this->session->userdata['user_id'],
                        'IsBatchflag_59'        => '1'
                ];
        }

        public function normalize_amount($value)
        {
                # Supprimer espaces et convertir la virgule en point
                $value = str_replace([' ', ','], ['', '.'], $value);

                return is_numeric($value) ? floatval($value) : 0;
        }

        public function get_paiements_batch_by_logirefid($logirefid)
        {
                $this->set_table('logiref_paiements_tresor_batchs  p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Lot_24' => $logirefid), TRUE);
        }

        public function save_payment_tresor_batch($data, $id) 
        {
                $this->set_table('logiref_paiements_tresor_batchs', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_payment_propres_dgda($data, $id) {
                $query = $this->db->table('logiref_paiements_propres');
                $result = $query->insertBatch($data);
                
                return $result ? true : false;
        }
        
        public function save_payment_tresor_dgda($data, $id) {
                
                $query = $this->db->table('logiref_paiements_tresor');
                $result = $query->insertBatch($data);
                
                return $result ? true : false;

        }
		
	public function save_payment_propres($data, $id) {
                $this->set_table('logiref_paiements_propres', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_payment_tresor($data, $id) {

                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_payment_tresor($data, $id) {
                $this->set_table('logiref_paiements_tresor', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_payment_tresor_permis($data, $id) {
                $this->set_table('logiref_paiements_tresor_permis', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_payment_tresor_passeport($data, $id) {
                $this->set_table('logiref_paiements_tresor_passeport', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
         public function update_payment_tresor_immatriculation($data, $id) {
                $this->set_table('logiref_paiements_tresor_immatriculation', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_payment_tresor_by_ref($data, $ref) {
                $this->set_table('logiref_paiements_tresor', 'Logirefid_4', 'Logirefid_4 DESC');
                return $this->saveData($data, $ref);
        }

        public function update_payment_propres($data, $ref) {
                $this->set_table('logiref_paiements_propres', 'Logirefid_4', 'Logirefid_4 DESC');
                return $this->saveData($data, $ref);
        }

        public function update_payment_tresor_dgda($data, $ref) {
                $this->set_table('logiref_paiements_tresor', 'Sydonia_44', 'Sydonia_44 DESC');
                return $this->saveData($data, $ref);
        }
        
        public function update_prepayment_tresor_dgda($data, $ref) {
                $this->set_table('logiref_paiements_tresor', 'Sydonia_49', 'Sydonia_49 DESC');
                return $this->saveData($data, $ref);
        }
        
        public function update_payment_propres_dgda($data, $ref) {
                $this->set_table('logiref_paiements_propres', 'Sydonia_44', 'Sydonia_44 DESC');
                return $this->saveData($data, $ref);               
        }
        
        public function update_prepayment_propres_dgda($data, $ref) {
                $this->set_table('logiref_paiements_propres', 'Sydonia_49', 'Sydonia_49 DESC');
                return $this->saveData($data, $ref);
        }
        
        public function delete_paiement_propre($id)
	{
                $builder = $this->db->table('logiref_paiements_propres');
                $condition = ['Logirefid_4' => $id];

                // Récupérer l'enregistrement avant de le supprimer
                $record = $builder->select('Logirefid_4')->where($condition)->get()->getRow();

                if ($record) 
                {
                        $builder->where($condition)->delete();

                        return $record->Logirefid_4;
                }

                return null;
	}
        
        public function delete_paiement_tresor($id)
	{
                $builder = $this->db->table('logiref_paiements_tresor');
                $condition = ['Logirefid_4' => $id];

                // Récupérer l'enregistrement avant de le supprimer
                $record = $builder->select('Logirefid_4')->where($condition)->get()->getRow();

                if ($record) 
                {
                        $builder->where($condition)->delete();

                        return $record->Logirefid_4;
                }

                return null; 

	}
        
        public function delete_paiement_tresor_dgda($id)
	{
                $builder = $this->db->table('logiref_paiements_tresor');
                $condition = ['Sydonia_44' => $id];

                // Récupérer l'enregistrement avant de le supprimer
                $record = $builder->select('Sydonia_44')->where($condition)->get()->getRow();

                if ($record) 
                {
                        $builder->where($condition)->delete();

                        return $record->Logirefid_4;
                }

                return null; 
	}
        
        public function delete_paiement_propre_dgda($id)
	{
                $builder = $this->db->table('logiref_paiements_propres');
                $condition = ['Sydonia_44' => $id];

                // Récupérer l'enregistrement avant de le supprimer
                $record = $builder->select('Sydonia_44')->where($condition)->get()->getRow();

                if ($record) 
                {
                        $builder->where($condition)->delete();

                        return $record->Logirefid_4;
                }

                return null;
	}
        
        public function delete_paiement_tresor_dgda_for_other_bl_type($id)
	{
                $builder = $this->db->table('logiref_paiements_tresor');
                $condition = ['Sydonia_44' => $id];
                
                $deletedId = $id;
                
                $builder->where($condition);
                $builder->delete();
                
                return $deletedId;
	}
        
        public function delete_paiement_propre_dgda_for_other_bl_type($id)
	{
                $builder = $this->db->table('logiref_paiements_propres');
                $condition = ['Sydonia_44' => $id];
                
                $deletedId = $id;
                
                $builder->where($condition);
                $builder->delete();
                
                return $deletedId;
	}
        
        // function generate_unique_reference() 
        // {
        //         $datetimePart = date('Hisdmy');
        //         $random_part = substr(bin2hex(random_bytes(2)), 0, 4);
        //         $unique_reference = $datetimePart . $random_part;

        //         return $unique_reference;
        // }   

        // function generate_unique_reference()
        // {
        //         # Partie date : Heure (2) + Minute (2) + Seconde (2) = 6 caractères
        //         $datetimePart = date('His'); // ex: 192530

        //         # Partie aléatoire : 8 caractères hexadécimaux
        //         $random_part = substr(bin2hex(random_bytes(4)), 0, 7);

        //         # Concaténation : 6 + 7 = 13 caractères
        //         $unique_reference = $datetimePart . $random_part;

        //         # Contrôle : tronquer ou compléter pour obtenir exactement 13 caractères
        //         $unique_reference = substr($unique_reference, 0, 13);


        //         return $unique_reference;
        // }

        function generate_unique_reference()
        {
                # Temps avec microsecondes (10 caractères)
                $micro = microtime(true);
                $time_part = substr(str_replace('.', '', $micro), 0, 10);

                # Random hex (3 caractères)
                $random_part = substr(bin2hex(random_bytes(2)), 0, 3);

                # Concaténation : 6 + 7 = 13 caractères
                $unique_reference = $time_part . $random_part;

                # Contrôle : tronquer ou compléter pour obtenir exactement 13 caractères
                $unique_reference = substr($unique_reference, 0, 13);

                # Total = 13 caractères
                return $unique_reference;
        }

}
