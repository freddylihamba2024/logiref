<div class="row">
    <div class="col-md-12">
        <div id="loader1"></div>
    </div>

    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-content">
                <div class="d-flex justify-content-between border-bottom">
                    <div>
                        <h2 class="text-dark"><b>Gestion des commissions</b></h2>
                        <p class=""><span class="text-gray">Trouvez ici la liste de toutes les commissions bancaires.</span></p>
                    </div>
                    <a id="add" href="#"><span class="fa fa-fw fa-plus-circle fa-5x text-success"></span></a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
        <?php if (!empty($regles)) : ?>
            <table id="table" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-blue">
                        <th>#</th>
                        <th>Priorit&eacute;</th>
                        <th>B&eacute;n&eacute;ficiaire</th>
                        <th>Indice</th>
                        <th>Service</th>
                        <th>Recette</th>
                        <th>Guichet</th>
                        <th>Min</th>
                        <th>Max</th>
                        <th>Validation</th>
                        <th><span class="fa fa-fw fa-edit f14"></span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($regles as $row): ?>
                        <tr>
                            <td width="5"><?php echo $row->Id_0; ?></td>
                            <td class="<?php if ($row->Priorite_4 == 1) {echo 'bg-gray';} elseif ($row->Priorite_4 == 2) {echo 'bg-green';} elseif ($row->Priorite_4 == 3) {echo 'bg-blue';} elseif ($row->Priorite_4 == 4) {echo 'bg-orange';} elseif ($row->Priorite_4 == 5) {echo 'bg-yellow';} elseif ($row->Priorite_4 == 6) {echo 'bg-red';} ?> " align="center">
                                <b>P<?php  echo $row->Priorite_4; ?></b>
                            </td>
                            <td>
                                <?php 
                                
                                    if ($row->Beneficiaire_5 == '' || $row->Beneficiaire_5 == '0')  echo 'TOUS';
                                    else echo ' ' . $row->Beneficiaire_5;
                                ?>
                            </td>
                            <td class="bleu"><b><?php  echo $row->Value_9 . ' ' . $row->Unite_10; ?></b></td></td>
                            <td>
                                <?php 
                                
                                   //if ($row->Service_6 == '') echo 'TOUS';
                                    //else echo ' ' . $services[$row->Beneficiaire_5][$row->Service_6]; 
                                ?>
                            </td>
                            <td>
                                <?php 
                               
                                    if ($row->Recette_7 == '') echo 'TOUTES';
                                    else echo ' ' . $row->Recette_7; 
                                ?>
                            </td>
                            <td>
                                <?php 
                                    if ($row->Guichet_8 == '') echo 'TOUS';
                                    else echo isset($guichets[$row->Guichet_8]) ? $guichets[$row->Guichet_8] : ''; 
                                ?>
                            </td>
                            <td class="bleu"><?php echo $row->Devise_13 . ' ' . number_format($row->Min_11, 2, ",", " "); ?>
                            <td class="bleu"><?php echo $row->Devise_13 . ' ' . number_format($row->Max_12, 2, ",", " "); ?></td>
                            <td>
                                <?php if ($row->Checkerid_15 == 0): ?>
                                    <span class="text-red"> En attente </span>
                                <?php else: ?>
                                    <?php echo $row->Validation_16; ?>
                                <?php endif; ?>
                            </td>
                            <td width="25" align="right">
                                <?php if ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2): ?>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                <?php else: ?>
                                    <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                <span class="d-block f14 text-black p-2">Le r&egrave;gle  est vide!</span>        
            </section>
        <?php endif; ?>
        <?php $chtml->box_body_closing(); ?>
    </div>
</div>
<br><br>
<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    $("#add").click(function() {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        $("#loader1").html('<div class="alert alert-warning ">D&eacute;sol&eacute! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    });

    function view(id) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxfees/display/regle'); ?>/' + id + '/<?php echo $from ?>';
        $.get(url, function(data, status) {
            $("#loader1").html('');
            $("#container").html(data);
        });
    }
</script>