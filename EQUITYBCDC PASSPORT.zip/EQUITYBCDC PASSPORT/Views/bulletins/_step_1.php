<?php 

//$codeBank = isset($_SESSION['Guichet_code'])? substr($_SESSION['Guichet_code'],1) :''; 
$codeBank='5101';
?> 
<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  center pull-right">1</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left f12 text-black">V&eacute;rification du Bulletin<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  center pull-right">2</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left f12 text-black">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  center pull-right">3</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left f12 text-black">Validation<br/></div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
               <div id="loader"></div><br/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12" id="success_message"></div>
        </div>
        <div id="pager" class="mb-5">
            <?php $chtml->box_body_opening('', false);?>
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <div class="row margin">
                <div class="col-md-8 bRight">
                    <input type="hidden" name="Account" value="<?php echo $accountid; ?>">
                    <input type="hidden" name="User" value="<?php echo $userid ; ?>">
                    <input type="hidden" id="compte_mad" value="<?php echo isset($compte_mad['account']) ? $compte_mad['account'] : ""; ?>" />
                    <input type="hidden" id="compte_mad_currency" value="<?php echo isset($compte_mad['currency']) ? $compte_mad['currency'] : ""; ?>" />

                    <div class="box-body">
                        <div class="row">
                           <div class="col-md-12">
                                <h2 class="f20 w100 w-300 page-header text-black"><b>V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</b></h2>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label for="Service_16" class="f12 text-black"><b>Bureau (ou service)</b></label> 
                                    <?php echo form_dropdown('Office',$services['DGDA'],'501B', 'class="form-control select2" id="Service_16" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="year" class="f12 text-black"><b>Ann&eacute;e</b></label> 
                                    <?php echo form_input('Year','2025', 'class="form-control" id="year" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="year" class="f12 text-black"><b>Banque</b></label> 
                                    <?php echo form_input('Bank',$codeBank, 'class="form-control bg-gray" id="year" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="company" class="f12 text-black"><b>Num&eacute;ro d'imp&ocirc;t</b></label> 
                                    <?php echo form_input('Nif','', 'class="form-control" id="company" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                   <label for="declarant" class="f12 text-black"><b>Num&eacute;ro du d&eacute;clarant</b></label> 
                                    <?php echo form_input('Agent','0000', 'class="form-control" id="declarant" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="assessment_serial" class="f12 text-black"><b>S&eacute;rie</b></label>
                                    <?php echo form_input('Series','L', 'class="form-control" id="assessment_serial" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="assessment_number" class="f12 text-black"><b>Num&eacute;ro du bulletin</b></label>
                                    <?php echo form_input('Number','', 'class="form-control" id="assessment_number" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="Montant_11" class="f12 text-black"><b>Montant</b></label>
                                    <?php echo form_input('Amount','', 'class="form-control" id="Montant_11" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="devise" class="f12 text-black"><b>Devise</b></label>
                                    <?php echo form_dropdown('devise', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                    <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" id="devise" >
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="Mode" class="f12 text-black"><b>Mode</b></label> 
                                    <?php echo form_dropdown('Mode', $modes, "", 'class="form-control" required="required" id="modeId"'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="assessment_number" class="f12 text-black"><b>Date liquidation</b></label>
                                    <?php echo form_input('DateL','', 'class="form-control" id="datepicker1" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="customerNumber" class="f12 text-black"><b><span  id="labelNumber">N° du client</span></b></label>
                                        <?php echo form_input('', set_value('Customernumber', ''), 'class="form-control" id="customerNumber" maxlength="7" placeholder="123456" required="required" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="Account" id="accountname" class="f12 text-black"><b>Compte du client &agrave; d&eacute;biter</b></label>
                                        <?php echo form_input('bank_account','', 'class="form-control" id="bank_account" placeholder="Compte bancaire du client" required="required" '); ?>
                                        <input type="hidden" name="account_name" value="" id="account_name">
                                        <input type="hidden" name="account_currency" value="" id="account_currency">
                                        <input type="hidden" name="account_balance" value="" id="account_balance">
                                        <input type="hidden" name="Infos[accountType]" value="" id="account_type">
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="Account" id="accountname" class="f12 text-black"><b>Compte du client &agrave; d&eacute;biter</b></label>
                                        <?php echo form_input('bank_account','', 'class="form-control" id="bank_account" placeholder="Compte bancaire du client" required="required" '); ?>
                                        <input type="hidden" name="account_name" value="" id="account_name">
                                        <input type="hidden" name="account_currency" value="" id="account_currency">
                                        <input type="hidden" name="account_balance" value="" id="account_balance">
                                        <input type="hidden" name="Infos[accountType]" value="" id="account_type">
                                        <input type="hidden" name="branch_code" value="" id="branch_code">
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="Devise_account" class="f12 text-black"><b>Devise de ce compte</b></label>
                                    <?php echo form_dropdown('Devise_account', $devises, "", 'class="form-control" id="account_devise" required="required"'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div id="details" class="col-md-12"></div>
                    </div></br></br></br></br>
                    <div class="box-footer clearfix ">

                        <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                            <div class="col-md-12 p-0">
                                <button type="submit" id="reserve" class="btn btn-primary" disabled="disabled"><i class="fa fa-archive"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="submit" id="treat"   class="btn btn-success"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="submit" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;

                                <input type="hidden" name="action" value="" id="action">
                                <input type="hidden" name="logirefid" value="" id="logirefid">
                                <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                                <input type="hidden" name="lien_id" value="" id="lien_id">
                                <input type="hidden" name="date_lien" value="" id="date_lien">
                            </div>
                        <?php else : ?>
                            <div class="col-md-12 p-0">
                                <button type="submit" id="reserve" class="btn btn-success" disabled="disabled"><i class="fa fa-archive " ></i>&nbsp;&nbsp;R&eacute;server&nbsp;&nbsp;</button>&nbsp;
                                <button type="submit" id="verify" class="btn btn-danger d-none"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;
                                <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="submit" id="extourne" class="btn btn-primary d-none" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;</button>&nbsp;

                                <input type="hidden" name="action" value="" id="action">
                                <input type="hidden" name="logirefid" value="" id="logirefid">
                                <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                                <input type="hidden" name="transaction_id" value="" id="transaction_id">
                                <input type="hidden" name="error_code" value="" id="error_code">
                                <a id="cancel" class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4 no-padding " id="treatment">

                </div>
            </div>
            <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>
</div>

<script type="text/javascript">
    
$(".select2").select2();

$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});

var bank = '<?php echo $bank; ?>';

$('#Montant_11').on("keyup", function() {
    let value = this.value.replace(/[^0-9]/g, "");
    this.value = value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#pager").on("change", "#coms", function(){
    this.value = this.value.replace(/[^0-9]/g, "");
    this.value = value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});

$("#confirm").click(function(){
    $("#action").val('confirmer');
});

$("#treat").click(function(){
    $("#action").val('traiter');
});

$("#reserve").click(function(){
    $("#action").val('reserve');
});

$("#verify").click(function(){
    $("#action").val('verify');
});

$("#extourne").click(function(){
    $("#action").val('extourne');
});

$("#recover").click(function(){
    $("#action").val('recover');
});

$("#pager").on("change", "#coms", function(){
    $("#confirm").prop('disabled', true);
});

$("#pager").on("change", "#total", function(){
    $("#confirm").prop('disabled', true);
});

   
$("#pager").on("submit", "#mainform", function(event){
    
    event.preventDefault();
    var data = $(this).serialize();
    
    var action = $('#action').val();

    if(action == 'traiter')
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/verification'); ?>';
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result)
            {
                if(result.code === "E500")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info text-white"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button> Ce bulletin est d&eacute;j&agrave; saisi, et se trouve en attente de validation. Veuillez contacter le validateur pour la validation.</div>');
                }
                else if(result.code === "E34")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E13" || result.code === "E003")
                {
                    $("#loader-sub-menu").html(result.message);
                }
                else if(result.code === "E22")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Aucune declaration trouv&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E11")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E404")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E405")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E406")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E000")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E15")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E18")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E21")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E411")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking, survenu lors de la recup&eacute;ration de la balance du compte du client<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result.code === "E43")
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Le Montant n\'est pas correct;. Veuillez renseigner le montant exacte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if (result.code === "OK")
                {
                    get_details(data);
                }
                else 
                {
                    // Nouveau message pour code inconnu
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code d\'erreur inconnu. Veuillez vérifier vos informations ou les ressaisir.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error)
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    else if(action == 'reserve')
    {
        <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
            get_reservation(data);
        <?php else :  ?>
            create_bulletin_and_debit_the_customer(data);
        <?php endif;  ?>
    }
    else if(action == 'verify')
    {
        verify(data);
    }
    else if(action == 'confirmer')
    {
        next_step(data);
    }
    else if(action == 'extourne')
    {
        cancel_reservation(data);
    }
    else if(action == 'recover')
    {
        single_recover(data);
    }
});


$("#cancel").click(function(){
        location.reload(true);
});
   
$("#close").click(function(){
        location.reload(true);
});


$("#bank_account").change(function(){
    get_accountname(); 
    get_account_exemption();
});

$("#account_devise").change(function(){
    get_accountname(); 
    get_account_exemption();
});

$('#modeId').change(function() {

    $("#loader-sub-menu").html('');
    
    var chtml = '<b>Compte du client &agrave; d&eacute;biter</b>';
    var mode = $('#modeId option:selected').val();

    if(mode == '5')
    {
        '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
            get_accountinternal();
        '<?php endif; ?>';
    }
    else
    {
        '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
            $("#customerNumber").prop("required", false);
        '<?php endif; ?>';

        $("#accountname").removeClass('text-green');
        $("#accountname").addClass('text-black');
        $("#bank_account").val(''); 
        $("#account_devise").val('');
        $("#accountname").html(chtml);
    }
});

'<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
    $("#customerNumber").change(function(){
        var customer_number = $(this).val();

        if (customer_number.length <= '7') 
        {
            get_customeraccounts()
        }
    });
'<?php endif; ?>';

$(document).on('change', '#bank_account', function () {
        
    $("#accountname").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    const selected = $(this).find(':selected');
    const name = selected.data('name');
    const currency_code = selected.data('currency');
    const balance = selected.data('balance');
    const type = selected.data('type');

    if (!selected.val()) {
        $('#accountname').html('');
        $('#account_name, #account_currency, #account_balance, #account_type').val('');
        $('#compteDevise').val('').trigger('change');
        return;
    }

    const mapped_currency = {
        '976': 'CDF',
        '840': 'USD'
    };

    const currency = mapped_currency[currency_code];

    // Ajoute un délai avant d'afficher les infos
    setTimeout(function () {
        $('#accountname').removeClass().addClass('text-green').html(name);
        $('#account_name').val(name);
        $('#account_currency').val(currency);
        $('#account_balance').val(balance);
        $('#account_type').val(type);

        if (currency) {
            $('#account_devise').val(currency);
            $('#account_devise').prop('disabled', true);

            // Supprime tout champ hidden existant pour éviter les doublons
            $('input[name="Devise_account"]').remove();

            // Ajoute un input hidden pour l'envoi correct de la valeur
            $('<input>').attr({
                type: 'hidden',
                name: 'Devise_account',
                value: currency
            }).appendTo('form');
        }
    }, 2500);
});

function next_step(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $('#confirm').prop("disabled", true);
    var button = $('#envoyer').html();
    $('#envoyer').html('<span>Chargement...</span>');
    var url = '<?php echo base_url($module.'/taxbulletin/display/confirmation'); ?>';
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            $("#loader-sub-menu").html('');
            $('#envoyer').html(button);
            $("#reserve").prop('disabled', true);
            
            if(result.code === "E34")
            {
                // var data = $('#mainform').serialize();
                // single_recover(data);
                $("#loader-sub-menu").html('<div class="alert alert-info text-black">Alerte: Problème de connéxion à Sydonia, allez dans le menu [Editer un encaissement] pour poursuivre le traitement de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result.code === "E22")
            {
               $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Aucune declaration trouv&eacute;e. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#manuel").prop('disabled', '');
               $("#manuel").removeClass('btn-default');
               $("#manuel").addClass('btn-success');

               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E13" || result.code === "E003")
            {
               $("#loader-sub-menu").html(result.message);
               $("#manuel").prop('disabled', '');
               $("#manuel").removeClass('btn-default');
               $("#manuel").addClass('btn-success');

               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E11")
            {
               $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E15")
            {
               $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E18")
            {
               $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E21")
            {
               $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E002")
            {
               $('#envoyer').prop("disabled", false);
               $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement du bulletin n\'a pas abouti. Veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E000")
            {
               $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E404")
            {
                var data = $('#mainform').serialize();
                single_recover(data);
            }
            else if(result.code === "E405")
            {
               $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               $("#extourne").removeClass('d-none');
            }
            else if(result.code === "E406")
            {
                var data = $('#mainform').serialize();
                single_recover(data);
            }
            else if(result === "E444")
            {
                var data = $('#mainform').serialize();
                single_recover(data);
            }
            else if(result.code === "OK")
            {
               $("#step-1").removeClass('bg-green-active');
               $("#step-1").addClass('bg-gray');
               $("#step-2").removeClass('bg-gray');
               $("#step-2").addClass('bg-green-active');

               var url = '<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/' + result.id;
               var reference = $("#reference").val();
               $.get(url, {refOp:reference}, function(data, status){
                   $("#loader-sub-menu").html('');
                   $("#pager").html(data);
                   $('#loader-sub-menu').html('<div class=" alert alert-info text-black">Bulletin confirm&eacute; dans sydonia avec succ&egrave;s, veuillez cliquer sur le bouton enregistrer ci-dessous, puis contacter votre validateur urgement pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               })
            }
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            $('#envoyer').prop("disabled", false);
            $('#envoyer').html(button);
        }
    });
                       
}

function get_details(data)
{
    var url ="<?php echo base_url($module.'/taxbulletin/display/step_1_details'); ?>";

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result){

            if(result == 'E411')
            {
                $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion &agrave; corebanking, survenu lors de la recup&eacute;ration de la balance du compte du client.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result == 'E418')
            {
                $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: ce bureau de douane n\'est pas configuré, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else
            {
                $("#loader-sub-menu").html('');
                $("#reserve").prop('disabled', false);
                $('#treatment').html(result);
            }
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function get_accountname()
{
    var chtml = $("#accountname").html();
    var compte = $('#bank_account').val();
    var devise = $('#account_devise option:selected').val();
    var csrf = $('input[name="csrf_name"]').val();

    var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname'); ?>';

    if (compte !== '' && devise !== '') {
        $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                compte: compte,
                devise: devise,
                csrf_name:csrf
            },
            dataType: 'json',
            encode: true,
            success: function(reponse) {

                if(reponse.code == '404')
                {
                    $("#accountname").removeClass('text-black');
                    $("#accountname").removeClass('text-green');
                    $("#accountname").addClass('text-red');
                    $("#accountname").html('Ce compte n&apos;existe pas');
                }
                else if(reponse.code  == '406')
                {

                    $("#accountname").removeClass('text-black');
                    $("#accountname").removeClass('text-green');
                    $("#accountname").addClass('text-red');
                    $("#accountname").html('Le format du compte n\'est pas valide !');
                }
                else if(reponse.code  == '405')
                {
                    $("#accountname").removeClass('text-black');
                    $("#accountname").removeClass('text-green');
                    $("#accountname").addClass('text-red');
                    $("#accountname").html('Le format de compte n\'est pas valide');
                }
                else if(reponse.currency == null && reponse.account_name == null)
                {
                    $("#accountname").removeClass('text-black');
                    $("#accountname").removeClass('text-green');
                    $("#accountname").addClass('text-red');
                    $("#accountname").html('Probl&egrave;me de connexion &agrave; au corebanking');
                }
                else if(reponse.currency != devise)
                {
                    $("#accountname").removeClass('text-green');
                    $("#accountname").removeClass('text-black');
                    $("#accountname").addClass('text-red');
                    $("#accountname").html('Devise du compte incorrecte');
                }
                else
                {
                    $("#accountname").removeClass('text-black');
                    $("#accountname").addClass('text-green');
                    $("#accountname").html(reponse.account_name);
                    $("#account_name").val(reponse.account_name);
                    $("#account_currency").val(reponse.currency);
                    $("#account_balance").val(reponse.balance);

                    // Vérifier si branch_code existe avant de l'utiliser
                    if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                        $("#branch_code").val(reponse.branch_code);
                    }
                }
            },
            error: function(error) {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Un problème est survenu lors de la récupération des informations du compte.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    } else {
        $("#accountname").html('');
    } 
}

function get_account_exemption(callback)
{
    var compte = $('#bank_account').val();
    var devise = $('#account_devise option:selected').val();
    var csrf = $('input[name="csrf_name"]').val();
    var url = '<?php echo base_url('branch/taxaccounts/data/get_account_exemption'); ?>';

    if (compte === '' || devise === '') {
        if (typeof callback === 'function') callback(null);
        return;
    }

    $.ajax({
        type: 'POST',
        url: url,
        data: { compte: compte, devise: devise, csrf_name: csrf },
        dataType: 'json',
        success: function(reponse) {

            if (reponse.code == '200') 
            {
                const formattedCommission = Number(reponse.comm).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Commission',
                    value: formattedCommission
                }).appendTo('form');

                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_commission',
                    value: devise
                }).appendTo('form');
            } 

        },
        error: function() {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            if (typeof callback === 'function') callback(null);
        }
    });
}

function get_accountinternal() 
{

    var mode = $('#modeId option:selected').val();
    var devise = $('#devise').val();
    var regie = 'DGDA';
    var csrf = $('input[name="csrf_name"]').val();

    var url = '<?php echo base_url('branch/taxaccounts/data/get_accountinternal'); ?>';

    if (devise !== '' && mode !== '') {
        $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                devise: devise,
                regie: regie,
                csrf_name:csrf
            },
            dataType: 'json',
            encode: true,
            success: function(reponse) {

                $("#loader-sub-menu").html('');

                const input_html = '<input type="text" name="bank_account" value="" class="form-control" placeholder="Compte bancaire du client" required="required" id="bank_account">';
                $('#bank_account').replaceWith(input_html);

                if(reponse.code  == '405')
                {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").removeClass('text-green');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Le compte n&apos;existe pas');
                }
                else
                {
                        $("#customerNumber").prop("required", false);

                        if (reponse.account ===  '000000000000000000000000')
                        {
                                $("#accountname").removeClass('text-black');
                                $("#accountname").removeClass('text-green');
                                $("#accountname").addClass('text-yellow');
                                $("#accountname").html("Le compte interne n’a pas été paramétré pour cette agence");

                                $("#bank_account").val(reponse.account).css("color", "red");

                                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le compte interne n’a pas été paramétré pour cette agence<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $("#accountname").removeClass('text-black');
                                $("#accountname").removeClass('text-yellow');
                                $("#accountname").addClass('text-green');
                                $("#accountname").html("Compte interne");
                                $("#account_name").val("Compte interne");
                                $("#account_type").val("MAD");
                                $("#account_currency").val(reponse.currency);

                                $("#account_balance").val("no-verification-balance");

                                $("#bank_account").val(reponse.account);
                                $("#account_devise").val(reponse.currency);
                        }
                }
            },
            error: function(error) {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    } else {
        $("#accountname").html('');
    }
}

function get_customeraccounts()
{
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            //$("#labelNumber").html('');
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        //$("#labelNumber, #accountname").html(loader_img);
        $("#accountname").html(loader_img);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200")
                {
                    const mapped_currency = {
                        '976': 'CDF',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'bank_account',
                        name: 'bank_account',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#bank_account').prop('tagName') === 'SELECT') {
                        $('#bank_account').replaceWith(select);
                    } else {
                        $('#bank_account').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $('#accountname').removeClass().addClass('text-black').html('Compte &agrave; d&eacute;biter');

                } else{

                    const input_html = '<input type="text" name="bank_account" value="" class="form-control" placeholder="Compte bancaire du client" required="required" id="bank_account">';

                    $('#bank_account').replaceWith(input_html);

                    $('#accountname').removeClass().addClass('text-black').html('Compte &agrave; d&eacute;biter');
                    $("#labelNumber").html('N° du client');

                    if (reponse.code === '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code === '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code === '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
}

function get_reservation(data)
{
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var montant = $('#Montant_11').val();
        var Office = $('#Service_16').val();
        var Number = $('#assessment_number').val();
        var Series = $('#assessment_serial').val();
        var Nif = $('#company').val();
        var Year = $('#year').val();
        var object = "single";
        var csrf = $('input[name="csrf_name"]').val();
        
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxaccounts/data/get_reservation'); ?>';
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : { compte : compte, devise : devise, montant : montant, Office: Office, Year: Year, Number: Number, Nif:Nif, Series: Series, object: object, csrf_name:csrf}, 
            dataType    : 'json',  
            encode          : true,
            success: function(response)
            {	
                if(response.code == '200')
                {
                    $("#lien_id").val(response.lien_id);
                    $("#date_lien").val(response.date_lien);
                    create_bulletin_and_reserve_the_fund(data, "reservation");
                }
                else if(response.code =='E500')
                {
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#mainform').serialize();

                    $("#loader-sub-menu").html('');

                    $("#loader-sub-menu").html('<div class="alert alert-info text-black"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce paiement, veuillez contacter le validateur pour la validation de ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '404')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">La r&eacute;servation n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '405')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">La r&eacute;servation n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '406')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Probl&egrave;me de connexion survenu entre logiref et synergies, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '407')
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Désolé, la fonctionnalité de reservation de fonds n\'est pas configurée pour ce compte logiref, veuillez contacter votre administrateur à cet effet<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code != '')
                {
                    $("#loader-sub-menu").html(response.error_message);
                }
                else
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error)
            {
                $('#message').html('<div class="alert aWarning text-white">Alerte: Probl&eacute;me de connexion &agrave; synergies. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
}

function get_reservation_debit_account(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin/display/debit_client'); ?>';

    $("#reserve").prop('disabled', true);
    $("#treat").prop('disabled', true);

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){

            if(result.code=='E407')
            {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#reserve').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else
            {
                if(result.code == 'E200' || result.code == 'E500')
                {
                    next_step(data);
                }
                else
                {
                    $("#loader-sub-menu").html(result.msg);
                    $('#verify').removeClass('d-none');
                    //$("#reserve").prop('disabled',true);

                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                    $('#logirefid').val(result.logirefid);
                }
            } 

        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning">La r&eacute;servation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function create_bulletin_and_debit_the_customer(data, type=null)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                
    //$('#reserve').prop("disabled", true);
    var button = $('#reserve').html();
    $('#reserve').html('<span>Chargement...</span>');
   
    scrollUP();

    var url = '<?php echo base_url($module.'/taxbulletin/display/create_bulletin'); ?>/'+type;

    $.ajax({
           type        : 'POST', 
           url         : url, 
           data        : data, 
           dataType    : 'json', 
           encode      : true,
           success: function(result){
                $('#reserve').html(button);
                $("#loader-sub-menu").html(result);

                if(result.code == 'E200')
                {   
                    $('#logirefid').val(result.logirefid);
                    $('#bulletin_id').val(result.id);
                    var data = $('#mainform').serialize();

                    get_reservation_debit_account(data);    
                } 
                else 
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
           },
           error:function(error){
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement a pris beaucoup de temps, veuillez réessayer, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#envoyer').html(button);
           }
    });
}

function create_bulletin_and_reserve_the_fund(data, type=null)
{
    data = $('#mainform').serialize();

    var bank = '<?php echo $bank ?>';

    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin/display/create_bulletin'); ?>/'+type;

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json',  
        encode          : true,
        success: function(response)
        {	
            if(response.id > 0)
            {
                '<?php if(isset($options['DGDA']['funds-reservation-with-instructions'])): ?>';
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#mainform').serialize();
                    
                    initiate_transaction(data);
                    
                '<?php else: ?>'
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#mainform').serialize();

                    $("#loader-sub-menu").html('<div class="alert aSuccess text-white"> L\'enregistrement fait avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#reserve").prop('disabled', true);
                    $("#treat").prop('disabled', true);
                '<?php endif; ?>'
            }
            else
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error:function(error)
        {
            $('#message').html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }  
    });
}

function verify(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/verify_transaction_single';

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            $("#loader-sub-menu").html('');

            if(result.code =='E407')
            {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#repartition').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else if(result.code =='E200')
            {
                $("#verify").prop('disabled',true);
                next_step(data);
            }
            else
            {
                $('#loader-sub-menu').html(result.msg);
            }
        },
        error:function(error)
        {
            $('#loader-sub-menu').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function cancel_reservation(data)
{
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/cancel_reservation'); ?>';
        
        $("#extourne").prop('disabled', true);
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){
                $("#loader-sub-menu").html('');

                if(result.code =='E407')
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option d\'annulation de réservation n\'est pas paramétrée pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#repartition').prop("disabled",true);
                    $('#valider').prop("disabled",true);
                }
                else if(result =='E200')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info text-black"> L\'extourne a &eacute;t&eacute; faite avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result =='E411')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

            },
            error:function(error)
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'extourne a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
}

function single_recover(data)
{
    $('#recover').prop("disabled", true);
    $('#buttonCloseModal').prop("disabled", true);
    $("#envoyer").addClass('hidden');
    var button = $('#recover').html();
    $('#recover').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

    var url = '<?php echo base_url($module.'/taxbulletin/display/single_recover'); ?>';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result)
        {
            $("#loader-sub-menu").html('');

            if(result =="OK")
            {
                single_recover(data);
            }
            else if(result === "E000")
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E404")
            {
                scrollUP();
                $('#recover').prop("disabled", false);
                $('#recover').html(button);
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA indisponible pour l\'instant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E002")
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Ce bulletin est d&eacute;j&agrave; pay&eacute; mais l\'enregistrement n\'a pas abouti, veuillez saisir ce bulletin manuellement dans le menu <<autres paiements>> s\il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E18")
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Code banque non trouv&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E21")
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Code bureau non  trouv&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E15")
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Code compagnie erron&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else
            {
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active');

                var url = '<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/' + result;
                $.get(url, function(data, status){
                    $("#loader-sub-menu").html('');
                    $("#pager").html(data);
                    $('#success_message').html('<div class="alert alert-info text-black">Bulletin confirm&eacute; dans sydonia avec succ&egrave;s, veuillez cliquer sur le bouton enregistrer ci-dessous, puis contacter votre validateur urgement pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                });
            }
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La confirmation a pris beaucoup de temps, veuillez refaire l\'op&eacute;ration s\'l vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function initiate_transaction(data)
{  
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin/display/initiate_transaction'); ?>';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(response){
            
            $("#loader-sub-menu").html('');
            $("#loader-sub-menu").html(response);

            $("#reserve").prop('disabled', true);
            $("#treat").prop('disabled', true);
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement du paiement a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function scrollUP() 
{
    $('html, body').animate({
        scrollTop: $("#loader-sub-menu").offset().top
    }, 20);
}

</script>
