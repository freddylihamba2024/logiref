<?php 

$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");



?>

<?php $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid'];?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class="row">
    <div  class="col-md-12">
        <div id="message"></div>
        <?php $chtml->box_body_opening('', true);?>
            <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
                <div class="box-body">
                    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />

                    <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                    <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                    <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                    <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                    <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                    <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                    <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                    <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                    <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                    <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                    <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                    <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                    <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                    <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                    <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                    <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                    <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />

                    <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                    <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                    <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                    <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                    <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />

                    <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
                    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />

                    <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                    <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                    <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                    <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                    <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                    <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                    <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                    <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                    <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                    <input type="hidden" name="Infos[Branch_code]" value='<?= isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>' />
                    <input type="hidden" name="bulletin_id" id="bulletin_id" value='<?php echo $bulletin->Id_0; ?>' />

                    <div class="row">
                        <div class="col-md-12 no-padding">
                            <div class="row">
                                <div class="col-md-12">
                                    <br/><br/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Bureaux</label>
                                            </div>
                                            <div class="col-md-8">
                                                <b>:</b> <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">D&eacute;clarant</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo $bulletin->Agent_10; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">D&eacute;signation</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo $encaissement->Designation_14.' / '.$encaissement->Nif_13; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Mode de paiement</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php  echo $modes[$encaissement->Mode_19]; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Intitul&eacute; du compte</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Num&eacute;ro du bulletin</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo $bulletin->Serie_7.' '.$bulletin->Number_8; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Ann&eacute;e du bulletin</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo $bulletin->Year_5; ?>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Montant total(BL)</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo $encaissement->Montant_11.' CDF '; ?>
                                               <input name="amount_value" value="<?= $encaissement->Montant_11; ?>" id="amount_value" type="hidden" disabled="disabled" />
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Commission</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo number_format($encaissement->Commission_23,2,","," ").' '.$encaissement->Devise_24;?>
                                               <input name="commission_value" value="0" id="commission_value" type="hidden" disabled="disabled" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Total &agrave; payer</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?php echo number_format($encaissement->Total,2,","," ").' CDF'; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Compte client(&agrave; d&eacute;biter)</label>

                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Devise du compte</label>
                                            </div>
                                            <div class="col-md-8">
                                               <b>:</b> <?= isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Taux appliqu&eacute;</label>
                                            </div>
                                            <div class="col-md-8">
                                              <b>:</b> <?= isset($encaissement->Taux_41 ) ? $encaissement->Taux_41 : ""; ?> CDF
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office">Compte Guichet Unique</label>
                                            </div>
                                            <div class="col-md-8">
                                              <b>:</b>  <span class="<?php if($encaissement->CGU=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $encaissement->CGU; ?></span>
                                              <input name="account_value" value="<?= $encaissement->CGU; ?>" type="hidden" id="account_value" disabled="disabled" />
                                              <input name="account_devise" value="CDF" type="hidden" id="account_devise" disabled="disabled" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 bTop">
                            <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                        </div>
                    </div>
                    <div class="col-md-12"><br></div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table" class="table table-hover table-striped">
                                <thead >
                                    <tr class="bg-blue">
                                        <th width="250px">Libell&eacute;</th>
                                        <th width="100px">Op&eacute;ration</th>
                                        <th width="200px">Source</th>
                                        <th width="200px">D&eacute;stination</th>
                                        <th width="100px"></th>
                                        <th class="right" width="">Montant</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                    <?php foreach($integrations as $row) :?>
                                        <?php if($row->Operation_8 == 'C'):?>
                                        <tr>
                                            <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                            <td  width="100px"><?php echo $row->Operation_8;?></td>
                                            <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                            <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                            <td width="100px" class="text-red"><?php echo $row->Details_23; ?></td>
                                            <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                        </tr>
                                        <?php else:?>
                                        <tr>
                                            <?php $code_taxe = isset($row->Codetaxe_28) ? $row->Codetaxe_28 : 'none'; ?>
                                            
                                            <?php if(!isset($tax_others_banks[$code_taxe])) :?>
                                                <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                                <td  width="100px"><?php echo $row->Operation_8;?></td>
                                                <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                                <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                                <td width="100px" class="text-red"><b><?php echo $row->Details_23; ?></b></td>
                                                <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endif;?>
                                    <?php endforeach;?>
                                        
                                    <?php foreach($others_banks_instructions as $key=>$row) :?>
                                        <tr class="bg-gray">
                                            <td colspan="6" class="bold">
                                                <span class="f15"><b><?php echo isset($key) ? "Nivellement de la taxe ".$key : ""; ?></b></span>
                                            </td>
                                        </tr>
                                        <?php foreach($row as $value) :?>
                                        <tr>
                                            <td  width="250px"><?php echo $value->Libelle_12;?></td>
                                            <td  width="100px"><?php echo $value->Operation_8;?></td>
                                            <td  class="<?php if(isset($value->Compte_9) && $value->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($value->Compte_9)? $value->Compte_9:'-'; ?></td>
                                            <td  class="<?php if(isset($value->Compte_13) && $value->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($value->Compte_13)? $value->Compte_13:'-'; ?></td>
                                            <td width="100px" class="text-red"><b><?php echo $value->Details_23; ?></b></td>
                                            <td ><?php echo $value->Devise_11.' '.number_format($value->Montant_10,2,","," ");?></td>
                                        </tr>
                                        <?php endforeach;?>
                                    <?php endforeach;?>
                                </tbody>    
                            </table>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                        <div class="col-md-12" id="Comptabilisation" class="tScroll"></div>
                    </div>

                    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                    <div class="row">
                        <div class="col-md-12"><br/><label class="page-header">Partie additionnelle : Frais liés aux attestations</label><br /></div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-check abc-checkbox abc-checkbox-success">
                                <input class="form-check-input" id="checked_attestation" <?= isset($bulletin->Printattestation_47) && $bulletin->Printattestation_47 >=1 ? "disabled": "" ?>  type="checkbox"  name="Infos[PaidATTESTATION]" value="FIA" >
                                <label class="form-check-label text-blue font-bold" for="checked_attestation">
                                    Frais liés à l’impression de l'attestations
                                </label>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-check abc-checkbox">
                                <input class="form-check-input" id="checked_duplication" type="checkbox" <?= isset($bulletin->Printattestation_47) && $bulletin->Printattestation_47 >=1 ? "": "disabled" ?>  name="Infos[PaidDUPLICATA]" value="FDA">
                                <label class="form-check-label text-blue font-bold" for="checked_duplication">
                                    Frais de duplicata d’attestation
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php endif ?>
                </div>
                <div class="box-footer clearfix">
                    <div class="row">
                        <div id="createPaiement" class="col-md-12">
                            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <button type="button" id="paid_attestation" disabled class="btn btn-success d-none"><i class="fa fa-save"></i>&nbsp;&nbsp;Debiter le client&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="treat" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif; ?>

                            <?php if($role == '3' || $role == '2' || $role =='4'):?>
                                <button id="validate" <?php if(($bulletin->Status_2 == 2 && $role =='4') || $bulletin->Status_2 == 3) echo 'disabled'; else echo '' ?> type="submit" class="btn  <?php if($bulletin->Status_2 == 2 || $bulletin->Status_2 == 1) echo 'btn-success'; else echo 'btn-default'; ?>" ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($role == '3' || $role == '2') echo "Valider"; else echo "Enregistrer"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif;?>
                            <button type="button" id="schema" <?php if($bulletin->Status_2  > 0) echo ''; else echo 'disabled' ?>  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                            
                            <?php if(isset($_SESSION['userdata']['options']['DGDA']['payment-attestation-printing']) || isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <button type="button" id="print_attestation" <?= isset($options['ALL']['bank-charges-attestation-printing']) ? 'disabled': '' ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos;attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif; ?>
                            
                            <?php if($role =='4' || $role =='3'):?>
                               <button type="button" id="quittance" <?php echo($bulletin->Status_2 > 1)? '' : 'disabled'; ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif;?>
                            <?php if($role =='5'):?>
                                <button type="button" id="quittance" <?php echo($bulletin->Pdfcontent_18 != '')? '' : 'disabled'; ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif;?>
                            <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                        </div>
                    </div>
                </div>
            <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 
    </div>
</div>

<script type="text/javascript"  charset="utf-8">
    
var controller ='<?php echo $controller;?>';
var view = '<?php echo $view;?>';

$("#contenter").on("click", "#close_form", function(){
        
        close_form();
});

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
    event.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    //scrollUP();
    var data = $(this).serialize();
    //Verifier le solde
    scrollUP();

    validate(data);
});

<?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
    handle_checkbox_value("#checked_attestation", "FIA");
    handle_checkbox_value("#checked_duplication", "FDA");

    function handle_checkbox_value(selector, valueIfChecked) {
        $(selector).on("change", function () {
            const isChecked = $(this).is(':checked');
            $(this).val(isChecked ? valueIfChecked : "");

            //$("#commission").val('');
            //commission(valueIfChecked);

            if(isChecked) {
                $("#treat").removeClass("d-none");
                $("#confirm").prop("disabled", true);
                $("#Comptabilisation").removeClass('d-none');
            } else {
                $("#treat").addClass("d-none");
                $("#confirm").prop("disabled", true);
                $("#Comptabilisation").addClass('d-none');

            }
        });
    }

    $("#treat").click(function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/instructions_attestation'); ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        var data = $("#confirmform").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                $("#Comptabilisation").html(result);

                if(result.code =='200'){
                        $('#message').html('');

                        $("#treat").removeClass('d-none');
                        $("#treat").prop("disabled", true);

                        <?php if (isset($bulletin->Status_2) && $bulletin->Status_2 == '3') :?>
                        $("#paid_attestation").removeClass('d-none');
                        $("#paid_attestation").prop("disabled", false);
                        <?php endif; ?>

                        $("#Comptabilisation").html(result.html);

                        $('#message').html('<div class="alert alert-info text-black"> Le traitement a été effectué avec succès. Veuillez valider les frais afin de pouvoir imprimer l\'attestation.!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
                else if (result.code == "E405") {
                        $("#treat").prop("disabled", true);

                        $('#message').html('<div class="alert alert-info text-black"> Attention : des écritures liées aux frais d’impression sont en attente. Veuillez les valider pour pouvoir imprimer l’attestation<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $("#paid_attestation").prop("disabled", true);
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le traitement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#paid_attestation").click(function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP();

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/save/paid_attestation'); ?>';
        var data = $("#confirmform").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                    alert(result.code )

                    if(result.code =='E407')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#paid_attestation').prop("disabled", false);
                    }
                    else if(result.code =='E408')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#paid_attestation').prop("disabled", false);
                    }
                    else if(result.code =='E409')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true); 
                        $('#paid_attestation').prop("disabled", false);  
                    }
                    else if(result.code =='200')
                    {
                        $('#message').html(result.msg);

                        $("#paid_attestation").prop("disabled", true);
                        $("#print_attestation").prop("disabled", false);
                        $('#print').prop("disabled",false); 
                        //comptabilisation('<?php //echo $encaissement->Sydonia_44; ?>');
                    }
                    else 
                    {
                        $("#loader-sub-menu").html('');
						$('#message').html(result.msg);
                        $('#paid_attestation').prop("disabled", false);
                        $("#print_attestation").prop("disabled", false);
                        //$("#message").html('<div class="alert aDanger text-white"> L\'envoi des &eacute;critures &agrave; au corebanking fait avec succ&egrave;s, mais cependant l\'intégration de quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });
    
<?php endif; ?>;

    $("#print_attestation").click(function(){
        // Désactiver le bouton print pour éviter les doubles clics
        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
        $("#print_attestation").prop("disabled", true);
        <?php endif; ?>

        var bl = '<?php echo $encaissement->Sydonia_44; ?>';
        var url = '<?php echo base_url($module.'/taximpression/display/attestationbl'); ?>/' + bl;

        var w = window.open(url, "_blank");

        if (w) {
            // Vérifier que la fenêtre s'est bien ouverte
            $(w).on("load", function () {
                try {
                    // Lancer l'impression automatiquement
                    w.print();

                    $('#message').html('<div class="alert aSuccess text-white">Bravo! Attestation générée et impression lancée...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                } catch (e) {
                    // Si une erreur survient, on réactive le bouton
                    $("#print").prop("disabled", false);

                    $('#message').html('<div class="alert aDanger text-white"> Error : Erreur lors de la génération du PDF. Veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });

            // Gestion du cas où la fenêtre est fermée trop tôt
            var checkClosed = setInterval(function () {
                if (w.closed) {
                    clearInterval(checkClosed);
                    $("#print").prop("disabled", false);
                }
            }, 1000);

        } else {
            // Si le popup a été bloqué
            $("#print").prop("disabled", false);
            $("#enregistrer").prop("disabled", false);
            
            $('#message').html('<div class="alert aWarning text-white"> Information : Le navigateur a bloqué la génération de l’attestation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });


$("#schema").click(function(){

    var bl = '<?php echo $encaissement->Sydonia_44; ?>';

    var url = '<?php echo base_url($module.'/taximpression/display/schemabl'); ?>/' + bl;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);

    $(w).ready(function(){
        w.print();
    });
});

$("#cancel").click(function(){
    <?php if($_SESSION['Logiref_role'] == 4){ ?>

            close_form();

    <?php }else{ ?>

        location.reload(); 

    <?php } ?>
});

$("#quittance").click(function(){
    
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    var button = $(this).html();

    $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
    var paiementid = '<?= isset($idBL) ? $idBL : "" ?>';
	var data = $('#confirmform').serialize();
    var url = '<?php echo base_url($module.'/taxbulletin/display/getquittance'); ?>/' + paiementid;

    $.ajax({    
        type        : 'POST', 
        url         : url, 
		data        : data,
        dataType    : 'html', 
        encode      : true,
        success: function(result){

            $(this).prop("disabled", false);
            $('#quittance').html(button);
            $("#loader").html('');

            if(result === "E003")
            {
                $("#loader").html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E34")
            {
                $("#loader").html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E22")
            {
                $("#loader").html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E11")
            {
                $("#loader").html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E002")
            {
                $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E001")
            {
                $("#loader").html('<div class="alert aWarning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E003")
            {
                $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E005")
            {
                $("#loader").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E000")
            {
                $("#loader").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E404" || result ==="E41")
            {
                $("#loader").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result === "E406")
            {
                $("#loader").html('<div class="alert aDanger text-white">La quittance n\'a pas &eacute;t&eacute; g&eacute;n&eacute;r&eacute;e, une erreur est survenue lors de la r�cup�ration. Veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else 
            {
                printQuittance(result);
            }

        },
        error:function(error){
            alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
            $('#envoyer').prop("disabled", false);
            $('#envoyer').html(button);
        }
    });
    
});

$("#closePanel").click(function(){
   
    closeView(controller,view);
    
});

function validate(data){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin/save/validate_single_bl'); ?>';

    scrollUP();
	$('#validate').prop("disabled",true);
    $('#message').html('');

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json',
        encode          : true,
        success: function(result){

            if(result.code=='E407')
            {
                $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#loader').prop("disabled",true);
            }
            else if(result.code=='E408')
            {
                $('#loader').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#loader').prop("disabled",true);
            }
            else if(result.code=='E409')
            {
                $('#loader').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#loader').prop("disabled",true);
            }
            else
            {
                $("#loader").html(result.msg);

                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                    var checked_attest = $("#checked_attestation").val();
                    var checked_dup = $("#checked_duplication").val();

                    if (checked_attest != "" || checked_dup != "") {
                        $("#print_attestation").prop("disabled", false);
                    } else {
                        $("#print_attestation").prop("disabled", true);
                    }
                <?php else: ?>
                    $("#print_attestation").prop("disabled", false);
                <?php endif; ?>
            }
        },
        error:function(error){
            $("#loader").html('');
            $("#loader").html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures au corebanking fait avec succ&egrave;s. Le d&eacute;lai de temps de r&eacute;ponse est d&eacute;pass&eacute;, veuillez v&eacute;rifier l\'int&eacute;gration de chaque &eacute;criture dans le sch&eacute;ma comptable s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function cancel_reservation(data)
{
    var bulletin_id = $('#bulletin_id').val();

    var url = '<?php echo base_url($module.'/taxaccounts/data/cancel_reservation'); ?>';

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : { bulletin_id : bulletin_id}, 
        dataType    : 'json',  
        encode          : true,
        success: function(response)
        {
            $("#loader").html('');
            
            if(response.code == '200')
            {
                submiter(data);
            }
            else if(response.code == '404')
            {
                $("#loader").html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(response.code == '405')
            {
                $("#loader").html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(response.code == '406')
            {
                $("#loader").html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(response.code != '')
            {
                $("#loader").html(response.error_message);
            }
            else
            {
                $("#loader").html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error:function(error)
        {
            $("#loader").html('<div class="alert alert-danger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }  
    });
}

function comptabilisation(ref){

    $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxcomptabilisation/display/get_details_dgda'); ?>/' + ref;
    $.get(url, function(data, status){
        $("#Comptabilisation").html(data);
    });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#message").offset().top
    }, 20);
}

function printQuittance(file)
{
    
    var url = '<?php echo base_url('drive/sydonia'); ?>/' + file;
    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
    // window.print();
    var w = window.open(url);
        
}

function closeView(controller, display)
{
    if(controller != '' && display != '')
    {
        $.get("<?php echo base_url($module.'/'.$controller.'/display/'.$view); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        location.reload();   
    }
}

function close_form()
{
    <?php if(isset($previous_menu) && $previous_menu != ""){ ?>

        $.get("<?php echo base_url($module.'/taxreports/display/'.$previous_menu); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');

            $("#close").removeClass('hidden');
            $("#close_form").addClass('hidden');

        });

    <?php }else{ ?>

        location.reload(); 

    <?php } ?>
        
}

</script>
