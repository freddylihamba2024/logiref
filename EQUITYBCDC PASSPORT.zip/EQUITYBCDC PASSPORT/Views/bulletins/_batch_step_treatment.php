<div id="batch-container">
<?php
    if(isset($compte_guichet_unique) && $compte_guichet_unique == '00000000000000000000000')
    {
            $disabled = 'disabled';
            $error_message = '<div class="alert aWarning">Le compte guichet unique n\'est pas paramétré, veuillez contacter votre administrateur à cet effet.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
    }
    else
    {
            $disabled = '';
            $error_message = '';
    }

    $batch_disabled = (isset($batch->Status_2) && $batch->Status_2 == 4)
                        ? 'disabled'
                        : ((isset($batch->Status_2) && $batch->Status_2 == 5) ? '' : 'disabled');
?>

<div class="row">
    <!-- <?php //if (empty($failds)) : ?> -->
    <div class="col-md-12" id="msg"><br/>
        <?php if (isset($batch->Status_2) && $batch->Status_2 == 4): ?>
            <div class="alert alert-info text-black">
                Le lot de bulletins est <b>en cours de traitement</b>.  
                La quittance n’est pas encore disponible.  
                Cliquez sur le bouton <b>[Actualiser]</b> pour suivre l’évolution.
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                <button type="button" class="btn btn-sm btn-primary float-right" id="btn-refresh">
                    <i class="fa fa-refresh"></i> Actualiser
                </button>
            </div>
        <?php elseif (isset($batch->Status_2) && $batch->Status_2 == 5): ?>
            <div class="alert alert-success text-black">
                Le traitement a été effectué avec succès. Votre quittance est maintenant disponible.
                Cliquez sur le bouton <b>[Enregistrer]</b> pour finaliser l’opération et générer la quittance.
            </div>
        <?php else: ?>
            <div class="alert alert-warning text-black">
                Une réservation de fonds a déjà été effectuée pour ce paiement. 
                Veuillez vous connecter au core banking pour vérifier s’il a bien été comptabilisé.
                Cliquez sur le bouton <b>[Actualiser]</b> pour suivre l’évolution.

                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button type="button" class="btn btn-sm btn-primary float-right" id="btn-refresh">
                    <i class="fa fa-refresh"></i> Actualiser
                </button>
            </div>
        <?php endif; ?>
    </div> 
    <?php //else: ?>
        <!-- <div id="msg">
            <div class="alert alert-info text-black"> 
                Une réservation de fonds a déjà été effectuée pour ce paiement. 
                Veuillez vous connecter au core banking pour vérifier s’il a bien été comptabilisé. Si c’est le cas, cliquez sur le bouton <b>[Émargement]</b> pour poursuivre le processus.
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button type="button" class="btn btn-sm btn-primary float-right" id="btn-refresh">
                    <i class="fa fa-refresh"></i> Actualiser
                </button>
                <-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button> --
            </div>
        </div> -->
    <?php //endif; ?>

</div>

<div id="message"></div>
<div id="loader"><?php echo $error_message; ?></div>
<?php echo form_open('', array('id' => 'main_form', 'class' => '')); ?>

<?php $chtml->box_body_opening('', true); ?>
    <div class="col-md-12">
        <input type="hidden" name="Office" value="<?php echo isset($batch->Office_7) ?$batch->Office_7 : ""; ?>" />
        <input type="hidden" name="Agent" value="<?php echo isset($batch->Agent_9) ? $batch->Agent_9:""; ?>" />
        <input type="hidden" name="Nif" value="<?php echo isset($batch->Nif_8) ? $batch->Nif_8:"" ?>" />
        <input type="hidden" name="designation" value="<?php echo isset($batch->Designation_15)?$batch->Designation_15:""; ?>" />
        <input type="hidden" name="account_name" value="<?php echo isset($batch->Accountholder_18)?$batch->Accountholder_18:""; ?>" />
        <input type="hidden" name="account" value="<?php echo isset($batch->Account_16)?$batch->Account_16:""; ?>" id="account" />
        <input type="hidden" name="mode" value="<?php echo isset($batch->Mode_19)?$batch->Mode_19:""; ?>" />
        <input type="hidden" name="total_amount" value="<?php echo isset($batch->Total_23)? $batch->Total_23:""; ?>" />
        <input type="hidden" name="Commission" value="<?php echo isset($batch->Commission_20)? $batch->Commission_20:""; ?>" />
        <?php $com = str_replace(' ','',$batch->Commission_20); $com = str_replace(',','.',$com);
        ?>
        <input type="hidden" name="tva" value="<?php echo $com * 0.16; ?>" />
        <input type="hidden" name="total_topaid" value="<?php echo isset($batch->Total_23)?$batch->Total_23:""; ?>" id="total_topaid" />
        <input type="hidden" name="taux" value="<?php echo isset($batch->Taux_26)?$batch->Taux_26:""; ?>" />
        <input type="hidden" name="Bank" value="<?php echo isset($batch->Bank_10)?$batch->Bank_10:""; ?>" />
        <input type="hidden" name="refOp" value="<?php echo isset($batch->Refop_25)?$batch->Refop_25:""; ?>" id="refOp" />
        <input type="hidden" name="devise_commision" value="<?php echo 'CDF'; ?>" />
        <input type="hidden" name="cGuichet" value="<?php echo isset($cGuichet)?$cGuichet:""; ?>" />
        <input type="hidden" name="cdevise" value="<?php echo isset($batch->Devise_17)?$batch->Devise_17:""; ?>" id="cdevise" />

        <input type="hidden" name="logirefid" id="logirefid" value="<?php echo $batch->Lot_14 ?>" />
        <input type="hidden" name="batchid" id="batchid" value="<?php echo $batch->Lot_14 ?>" />
        <input type="hidden" name="bulletin_id" value="<?= isset($batch->Id_0) ? $batch->Id_0:"" ?>" id="bulletin_id">
        
        <input type="hidden" name="batch_reference" value="<?php echo $batch->Lot_14 ?>" id="batch_reference">
        <input type="hidden" name="batch_id" value="<?php echo isset($batch->Id_0) ? $batch->Id_0:"" ?>" id="batch_id">

        <div class="col-md-12 p-0">
            <div class="row">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des bulletins  en lot</h2>
                    <br/>
                </div>

                <div class="col-12">
                    <div class="col-12">
                        <br><br>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Bureau</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $services['DGDA'][$batch->Office_7]; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>D&eacute;clarant</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Agent_9; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Numéro impôt</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Nif_8; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Désignation</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Designation_15; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>intitulé du compte</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Accountholder_18; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Compte</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Account_16 . ' ' . $batch->Devise_17; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Mode de paiement</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $modes[$batch->Mode_19];; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Montant total du lot</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Amount_11; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Commission</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Commission_20; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>TVA</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo isset($tva)?$tva:0; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Total à payer</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $batch->Total_23; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black"><b>Compte CGU</b></label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                            <b>:</b> <?php echo $cGuichet; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="footpage" class="clearfix"></div>
                <div class="col-12 border-bottom">
                    <br><br>
                </div>
            </div>
        </div>

        <div class="p-0 border-top">
            <div class="box-body">

                <?php if (!empty($failds)) : ?>
                    <table class="table no-margin table-striped table-bordered">
                        <thead class='bg-blue'>
                            <tr>
                                <th width="10px">#</th>
                                <th width="80px">Ann&eacute;e</th>
                                <th width="80px">S&eacute;rie</th>
                                <th width="80px">Num&eacute;ro</th>
                                <th width="50px">Devise</th>
                                <th width="200px">Montant</th>
                                <th>Retour de SYDONIA</th>
                                <th align="center" width="90px">V&eacute;rification</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; foreach ($failds as $bl): ?>
                                <tr id="line<?php echo $i ?>">
                                    <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                    <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year; ?>" name="years[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->serial . ' ' . ((isset($bl->number)||$bl->number!=null)?$bl->number:""); ?>" name="serials[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td><input type="text" value="<?php echo $bl->number; ?>"  name="numbers[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span class="form-control">CDF</span></td>
                                    <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount, 2, ",", " "); ?>" name="amounts[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-green bold'>Bulletin valide!</span></td>
                                    <td align="center" id='btn<?php echo $i; ?>'>
                                    <span class="fa fa-fw text-green fa-check f20"> </span>
                                    </td>
                                </tr>
                            <?php $i++; endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <div class="col-12 border-bottom">
                    <br>
                </div>

                <?php if (empty($failds)) : ?>
                    <?php if (!empty($bulletins)) : ?>
                        <table id="tableREN1" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-secondary text-white">
                                    <th width="5px">#</th>
                                    <th width="50px">Quittance</th>
                                    <th width="50px">Bulletin</th>
                                    <th width="50px">Année</th>
                                    <th>Montant</th>
                                    <th width="10px" style="text-align:center;"><i class="fa fa-tasks f20"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $i = 1; foreach ($bulletins as $obj) : ?>
                                    <tr id="line<?php echo $obj->Id_0; ?>">
                                        <td><?php echo $i; ?></td>
                                        <td id="result<?php echo $obj->Id_0; ?>">
                                            <?php $BL = json_decode($obj->Results_13); echo $BL->receiptSerial . ' ' . $BL->receiptNumber; ?>
                                        </td>
                                        <td><?php echo $obj->Serie_7 . ' ' . $obj->Number_8; ?></td>
                                        <td width=""><?php echo $obj->Year_5; ?></td>
                                        <td><?php echo number_format($obj->Amount_12, 2, ".", ","); ?></td>
                                        <td align="center" width="" id="pq<?php echo $obj->Id_0; ?>">
                                            <a style="cursor: pointer" onclick="view('<?php echo $obj->Id_0; ?>')">
                                                <i class="fa fa-fw fa-file-text f20"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php $i++; endforeach; ?>
                            </tbody>
                        </table>

                        <input type="hidden" name="Logirefid" id="Logirefid" value="<?php echo $batch->Lot_14 ?>" />
                    <?php else : ?>
                        <section>
                            <div class="row fontawesome-icon-list f14 text-center" style="min-height: 50vh; padding-top: 20%;">
                                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br />
                                <h4 class="text-center"><b>Les bulletins sont confirmés et la quittance est disponible mais SYDONIA n'a pas retourné les informations des bulletins, utilisez le menu récupération des paiements DGDA.</b></h4>
                                <br />
                            </div>
                        </section>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="box-footer clearfix">
                <br/>
                <?php
                    $isEmpty = empty($failds);
                    $hasIntegration = array_intersect($integration_status, ['1', '3', '4', '5']);
                    $hasStatus2 = in_array('2', $integration_status);
                ?>

                <?php if ($isEmpty): ?>
                    <button id="save" type="submit" class="btn btn-success float-left <?= $batch_disabled ?>">
                        <i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;
                    </button>&nbsp;&nbsp;
                    <button type="button" id="quittance" class="btn btn-primary <?= ((($batch->Status_2 ?? "") == 5) ? '' : 'disabled') ?>">
                        <i class="fa fa-print"></i>&nbsp;&nbsp;Générer la quittance&nbsp;&nbsp;
                    </button>&nbsp;&nbsp;
                    <a href="" class="btn btn-warning">
                        <i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;
                    </a>&nbsp;&nbsp;
                <?php else: ?>
                    <?php if (!empty($hasIntegration)): ?>
                        <button type="submit" id="regul" class="btn btn-success">
                            <i class="fa fa-archive"></i>&nbsp;&nbsp;Reserver&nbsp;&nbsp;
                        </button>&nbsp;&nbsp;
                    <?php endif; ?>

                    <button type="submit" id="verify" class="btn btn-primary d-none">
                        <i class="fa fa-repeat"></i>&nbsp;&nbsp;Vérifier&nbsp;&nbsp;
                    </button>&nbsp;

                    <button type="submit" id="emargement" class="btn btn-success"
                            <?= (in_array(($batch->Status_2 ?? ""), ['4', '5'])) ? 'disabled' : '' ?>>
                        <i class="fa fa-folder"></i>&nbsp;&nbsp;Émargement&nbsp;&nbsp;
                    </button>&nbsp;&nbsp;

                    <button type="submit" id="extourne"
                            class="btn btn-primary d-none"
                            <?= $hasStatus2 ? '' : 'disabled' ?>>
                        <i class="fa fa-repeat"></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;
                    </button>&nbsp;

                    <button type="button" id="delete" class="btn btn-danger" disabled>
                        <i class="fa fa-trash-o"></i>&nbsp;&nbsp;Supprimer&nbsp;
                    </button>&nbsp;&nbsp;

                    <a id="cancel" class="btn btn-warning" href="">
                        &nbsp;Quitter&nbsp;
                    </a>
                <?php endif; ?>


                <input type="hidden" name="lien_id" value="" id="lien_id">
                <input type="hidden" name="date_lien" value="" id="date_lien">
                <input type="hidden" name="transaction_id" value="" id="transaction_id">
                <input type="hidden" name="error_code" value="" id="error_code">
                <input type="hidden" name="action" value="" id="action">
            </div>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>

<div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="width: 75%; max-width: 1000px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title">D&eacute;tail des bulletins</h4>
            </div>
            <div class="modal-body" id="modal-pager"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
            </div>
        </div>
    </div>
</div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>

<script type="text/javascript">

    var logirefid = '';
    var ref = '';

    $("#save").click(function(){
        $("#action").val('save');
    });

    $('#reserve').click(function(){
        $('#action').val('reserver');
    });

    $("#regul").click(function(){
        $("#action").val('regul');
    });

    $('#emargement').click(function(){
        $('#action').val('emargement');
    });

    $(document).ready(function() {
        $(document).on('click', '#btn-refresh', function() {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

            var id = <?=  $batch->Id_0 ?>;
            var url = "<?php echo base_url($module . '/taxbulletin/display/batch_treatments_current'); ?>/" + id;

            $.ajax({
                url: url,
                type: 'GET',
                success: function(data){
                    $("#loader").html('');
                    // Remplace toute la view par la nouvelle version
                    $('#batch-container').html(data);
                },
                error: function(){
                    alert("Erreur lors de l'actualisation du traitement.");
                }
            });
        });
    });

    $('#main_form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        scrollUP();
        var data = $(this).serialize();
        var action = $('#action').val();

        if(action == 'save')
        {
                // Verifier le BL dans Sydonia
                submiter(data);
        }
        else if(action == 'emargement')
        {
                emargement(data);
        }

    });

    $("#quittance").click(function() {

        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var button = $(this).html();
        
        var data = $('#main_form').serialize();

        $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
        var paiementid = '<?= isset($bulletins[0]->Id_0) ? $bulletins[0]->Id_0 : ""; ?>'

        var url = '<?php echo base_url($module . '/taxbulletin/display/getquittance'); ?>/' + paiementid+'/batch';

        $.ajax({
            type: 'POST',
            url: url,
            data: data, 
            dataType: 'html',
            encode: true,
            
            success: function(result) {

                $(this).prop("disabled", false);
                $('#quittance').html(button);
                $("#loader").html('');

                if (result === "E003") {
                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E34") {
                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E22") {
                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E11") {
                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E002") {
                    $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E001") {
                    $("#loader").html('<div class="alert aWarning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E003") {
                    $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E000") {
                    $("#loader").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E005") {
                    $("#loader").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E404" || result === "E41") {
                    $("#loader").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    printQuittance(result);
                }

            },
            error: function(error) {
                $("#loader").html('<div class="alert aWarning text-white">L\'impression de la quittance a pris beaucoup de temps, veuillez checker votre connexion puis réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
            }
        });

    });

    function submiter(data) 
    {
        var url = '<?php echo base_url($module . '/taxbulletin/save/save_batch'); ?>';
        scrollUP();
        $('#save').prop("disabled", true);
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $("#msg").html('');
        
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
      
                if (result == 'E500') {
                    $("#loader").html('<div class="alert alert-info text-black">Le lot de paiement existe d&eacute;j&agrave;, veuillez v&eacute;rifier le paiement de ce lot dans la liste de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (isNaN(result) == true) {
                    $("#loader").html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result > 0) {
                    $("#loader").html('<div class="alert aSuccess text-white">Bravo! le lot des bulletins encaiss&eacute;s avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $('#save').prop("disabled", false);
                    $("#loader").html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $("#loader").html('<div class="alert aDanger text-white">Une erreur est survenue lors de l\'enregistrement, veuillez v&eacute;rifier la liste de bulletins de ce lot dans les paiements non valid&eacute;s s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function emargement(data) 
    {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $('#envoyer').prop("disabled", true);
            var button = $('#envoyer').html();
            $('#envoyer').html('<span>Chargement...</span>');
            var url = '<?php echo base_url($module . '/taxbulletin/display/batch_confirmation_from_operator'); ?>';
            $("#loader2").html('');
            $.ajax({
                    type: 'POST',
                    url: url,
                    data: data,
                    dataType: 'html',
                    encode: true,
                    success: function(result) {
                            $('#envoyer').prop("disabled", false);
                            $('#envoyer').html(button);
                            $("#loader").html('');
                            $("#msg").html('');
                            
                            if(result == "E200") {
                                    $('#emargement').prop("disabled", true);
                                    refresh()
                            }
                            else if (result === "E34") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E22") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E21") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E18") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E4") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            } else if (result === "E11") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E13") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aDanger text-white">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E002") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E003") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E000") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else if (result === "E404") {
                                    batch_recover(data);
                            } else if (result === "E405") {
                                    batch_recover(data);
                            } else if (result === "E406") {
                                    batch_recover(data);
                            } else if (result === "E444") {
                                    batch_recover(data);
                            } else if (result === "E411") {
                                    batch_recover(data);
                            } else if (result === "E501") {
                                    scrollUP();
                                    $("#loader").html('<div class="alert aWarning text-white">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#envoyer').prop("disabled", true);
                                    $('#extourne').removeClass('d-none');
                                    $('#reserve').addClass('hidden');
                            } else {
                                    $('#envoyer').prop("disabled", false);
                                    $('#envoyer').html(button);

                                    // $("#step-2").removeClass('bg-green-active');
                                    // $("#step-2").addClass('bg-gray');
                                    // $("#step-3").removeClass('bg-gray');
                                    // $("#step-3").addClass('bg-green-active');

                                    $("#pager").html(result);
                            }
                    },
                    error: function(error) {
                            scrollUP();
                            $('#envoyer').prop("disabled", false);
                            $('#envoyer').html(button);
                            $("#loader").html('<div class="alert aWarning text-white">L\'emargement a pris beaucoup de temps, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function refresh()
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var id = <?=  $batch->Id_0 ?>;
        var url = "<?php echo base_url($module . '/taxbulletin/display/batch_treatments_current'); ?>/" + id;

        $.ajax({
            url: url,
            type: 'GET',
            success: function(data){
                $("#loader").html('');
                // Remplace toute la view par la nouvelle version
                $('#batch-container').html(data);
            },
            error: function(){
                alert("Erreur lors de l'actualisation du traitement.");
            }
        });
    }

    function view(bId) 
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxbulletin/display/_batch_2'); ?>/' + bId;
        $.get(url, function(data, status) {
            $("#loader").html('');
            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }

    function printQuittance(file) {
        var url = '<?php echo base_url('drive/sydonia'); ?>/' + file;
        var w = window.open(url);

    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader").offset()
        }, 20);
    }
</script>