<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if($disabled == 'disabled')
{
        $disabled = 'readOnly';
        $total_amount = "";
}

?>


<br/>  
<div class="row margin">
    <div class="col-md-12 margin">
        <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="designation" class="f12 text-black"><b>Designation</b></label> 
                        <?php echo form_input('designation',set_value('designation', $designation), 'class="form-control" id="designation" required = "required"'); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-7">
                    <input type="hidden" name="concat" value="<?= $compte_guichet ?>" >
                    <div class="form-group">
                        <label for="company" class="f12 text-black"><b>Compte guichet unique</b></label> 
                        <?php echo form_input('Compte_guichet',set_value('Compte_guichet', $compte_guichet), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
                        <input type="hidden" name="Compte_guichet" value="<?= $compte_guichet ?>" >
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="devise" class="f12 text-black"><b>Devise</b></label>
                        <?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                        <input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="form-group">
                        <label for="company" class="f12 text-black"><b>Commission</b></label> 
                        <input type="text" name="Commission" value="<?php echo $commission; ?>" id="coms" class="form-control" required >
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="devise" class="f12 text-black"><b>Devise</b></label>
                        <?php echo form_dropdown('Devise_commission', $devises, isset($commission_devise) ? $commission_devise : "CDF", 'class="form-control"  required="required" id="recetteDevise" '); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="form-group">
                        <label for="company" class="f12 text-black"><b>Montant total</b></label> 
                        <input type="text" name="Total_amount" value="<?php echo $total_amount; ?>" class="form-control" id="total" required = "required">
                    </div>  
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="devise" class="f12 text-black"><b>Devise</b></label>
                        <?php echo form_dropdown('Devise_amount', $devises, "CDF", 'class="form-control"  required="required" '); ?>
                        <input type="hidden" name="Devise_amount" value="<?= $devises['CDF'] ?>" >
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="form-group">
                        <label for="reference" class="f12 text-black"><b>R&eacute;f&eacute;rence de l&apos;OP</b></label>
                        <?php echo form_input('reference',set_value('reference', $referenceOP), 'class="form-control form-control-lg" id="reference" required="required" '.$disabled.' '); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="company" class="f12 text-black"><b>Taux</b></label> 
                        <?php echo form_input('Taux',set_value('Taux', set_value('Taux', isset($bank_rate_applied) ? $bank_rate_applied : $taux)), 'class="form-control" '); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="company"class="f12 text-black"><b>Balance compte du client</b></label> 
                        <?php echo form_input('balance',set_value('balance', $account_balance), 'class="form-control" id="balance" disabled="disabled"'); ?>
                    </div>
                </div>
            </div>

    </div>
</div>

    


<script type="text/javascript">
   
'<?php if($balance =="ok"){ ?>'

$("#balance").css('background-color','#00cc33');
$("#balance").css('color','white');

'<?php }else{ ?>'

$("#balance").css('background-color','red');
$("#balance").css('color','white');
$("#confirm").prop('disabled', true);

'<?php } ?>'
    
</script>