<?php  $codeBank = isset($_SESSION['Guichet_code']) ? substr($_SESSION['Guichet_code'], 1) : '51';   ?>
<div class="row">
    <div class="col-md-12 p-0">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-1">
                    <div id="step-1" title="" class="bRound <?php if ($step == 0) {echo 'bg-green-active';} else {echo 'bg-gray';} ?>  f18 center pull-right">1</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left">Extraction<br /></div>
                </div>
                <div class="col-md-1">
                    <div id="step-2" title="" class="bRound <?php if ($step == 2 || $step == 1) {echo 'bg-green-active';} else {echo 'bg-gray';} ?> f18 center pull-right">2</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left">Enregistrement<br /></div>
                </div>
                <div class="col-md-1">
                    <div id="step-3" title="" class="bRound <?php if ($step == 3) {echo 'bg-green-active';} else {echo 'bg-gray';} ?> f18 center pull-right">3</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left">Rapport<br /></div>
                </div>
            </div>
           
        </div>
        <div class="col-md-12"><br />
            <div id="loader"></div>
        </div>
        <div id="pager">
            <?php if ($step == 1 || $step == 2) : ?>
                <?php $this->load->view('_batch_recover_step_1'); ?>
            <?php elseif ($step == 3) : ?>
                <?php $this->load->view('_batch_recover_step_1'); ?>
            <?php else : ?>
                <div class="col-md-12">
                    <?php $chtml->box_body_opening('', true); ?>
                    <div class="row">
                    <div class="col-md-4 no-padding">
                        <div class="col-md-12 center">
                            <p class="page-header">
                                <br /><br />Cette section vous permet de recuperer les paiements dans SYDONIA, suivant les informations demand&eacute;es sur le formulaire
                            </p><br />
                        </div>
                    </div>
                    <div class="col-md-8 bLeft">
                        <?php echo form_open('', array('id' => 'extractform1', 'class' => 'innovate')); ?>
                        <div class="row">
                            <div id="details" class="col-md-12"></div>
                        </div>
                        
                        <input type="hidden" name="Account" value="<?php echo $accountid; ?>">
                        <input type="hidden" name="User" value="<?php echo $userid; ?>">
                        <div class="box-body">
                            <div class="col-md-12 no-padding no-margin">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Service_16">Bureau (ou service)</label>
                                            <?php echo form_dropdown('Office', $services['DGDA'], '', 'class="form-control select2" id="Service_16" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="guichet">Agence</label>
                                            <?php echo form_input('guichet', $codeBank, 'class="form-control" id="guichet" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="company">Num&eacute;ro d'imp&ocirc;t</label>
                                            <?php echo form_input('Nif', '', 'class="form-control" id="company"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="designation">Designation</label>
                                            <?php echo form_input('designation', '', 'class="form-control" id="designation" required = "required"'); ?>
                                        </div>
                                    </div>

                                </div>
                               
                            </div>
                            <div class="col-md-12">
                                <br>
                            </div>
                            <div class="col-md-12 no-padding no-margin">
                                <p class="page-header">
                                    P&eacute;riode de la quittance
                                </p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="qserie">S&eacute;rie de la quittance</label>
                                            <?php echo form_input('qserie', 'Q', 'class="form-control" id="qserie" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="qnumber">Num&eacute;ro de la quittance</label>
                                            <?php echo form_input('qnumber', '', 'class="form-control" id="qnumber" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dateDebut">Date d&eacute;but</label>
                                            <?php echo form_input('dateDebut', '', 'class="form-control" id="dateDebut"  required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dateFin">Date fin</label>
                                            <?php echo form_input('dateFin', '', 'class="form-control" id="dateFin"  required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if(isset($options['ALL']['bcc-fees-deduction-new-taxes']) || isset($options['ALL']['bcc-fees-deduction-on-funds-taxes']) || isset($options['DGDA']['bcc-fees-deduction-fonds-propres'])): ?>
                                <div class="col-md-12">
                                    <br>
                                </div>
                                <div class="col-md-12 no-padding no-margin">
                                    <p class="page-header text-blue">
                                       <b>Compte à débiter pour les frais de la BCC</b>
                                    </p>
                                    <div class="row">
                                        <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="customerNumber"><span  id="labelNumber">Code client</span></label>
                                                    <?php echo form_input('', set_value('Customernumber', ''), 'class="form-control" id="customerNumber" maxlength="7" placeholder="151693" '); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="Account" id="accountname">Compte du client &agrave; d&eacute;biter</label>
                                                    <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control form-control-md" placeholder="E.g: 020101534430013300000" id="compteId" maxlength="26"'); ?>
                                                    <input type="hidden" name="account_name" value="" id="account_name">
                                                    <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                                                    <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
                                                    <input type="hidden" name="account_type" value="" id="account_type">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="Devise_account">Devise de ce compte</label>
                                                    <?php echo form_dropdown('Devise_34', $devises, "", 'class="form-control"  id="compteDevise"'); ?>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="Account" id="accountname">Compte du client &agrave; d&eacute;biter</label>
                                                    <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control form-control-md" placeholder="E.g: 020101534430013300000" id="compteId" maxlength="26"'); ?>
                                                    <input type="hidden" name="account_name" value="" id="account_name">
                                                    <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                                                    <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
                                                    <input type="hidden" name="account_type" value="" id="account_type">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="Devise_account">Devise de ce compte</label>
                                                    <?php echo form_dropdown('Devise_34', $devises, "", 'class="form-control"  id="compteDevise"'); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="row">
                                <div class="col-md-12">
                                    <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-download"></i>&nbsp;&nbsp;Extraire&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Annuler </button>
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>

                    </div>
                    
                    <?php $chtml->box_body_closing(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/datapicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/select2/select2.full.min.js'); ?>"></script>

<script type="text/javascript">
    
    $(".select2").select2();
    
    $('#dateDebut').datepicker({
        format: 'yyyy-mm-dd'
    });

    $('#dateFin').datepicker({
        format: 'yyyy-mm-dd'
    });

    $("#extractform1").submit(function(event) {
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
    });

    '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
        $("#customerNumber").change(function(){
            var customer_number = $(this).val();

            if (customer_number.length <= '7') 
            {
                get_customeraccounts()
            }
        });
    '<?php endif ?>';

    $("#compteDevise").change(function() {
        get_accountname();
    });

    $("#compteId").change(function() {
        get_accountname();
    });

    $(document).on('change', '#compteId', function () {
        
        $("#accountname").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $(this).find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#accountname').html('Compte du client &agrave; d&eacute;biter');
            $('#account_name, #account_currency, #account_balance, #account_type').val('');
            $('#compteDevise').val('').trigger('change');
            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        // Ajoute un délai avant d'afficher les infos
        setTimeout(function () {
            $('#accountname').removeClass().addClass('text-green').html(name);
            $('#account_name').val(name);
            $('#account_currency').val(currency);
            $('#account_balance').val(balance);
            $('#account_type').val(type);

            if (currency) {
                $('#compteDevise').val(currency);
                $('#compteDevise').prop('disabled', true);

                // Supprime tout champ hidden existant pour éviter les doublons
                $('input[name="Devise_34"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_34',
                    value: currency
                }).appendTo('form');
            }
        }, 2000);
    });

    function get_accountname() 
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
		
	    var core_banking = '<?php echo $core_banking; ?>';
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_customeraccounts() 
    {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#labelNumber").html(loader_img);

        $('#compteDevise').prop('disabled', false);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200")
                {
                    const mapped_currency = {
                        '976': 'CDF',
                        '978': 'EUR',
                        '840': 'USD',
                    };

                    let select = $('<select>', {
                        id: 'compteId',
                        name: 'Compte_33',
                        class: 'form-control form-control-md',
                        required: false
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#compteId').prop('tagName') === 'SELECT') {
                        $('#compteId').replaceWith(select);
                    } else {
                        $('#compteId').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $("#labelNumber").html('Code client');
                    $('#accountname').html('Compte du client &agrave; d&eacute;biter');

                } else{

                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
        
                    $('#compteId').replaceWith(input_html);

                    $("#labelNumber").html('');

                    if (reponse.code == '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code == '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code == '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function next_step(data) {

        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //$('#sub').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>T&eacute;l&eacute;chargement...</span>');
        var url = '<?php echo base_url($module . '/taxbulletin/display/extractbls'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
                $("#loader-sub-menu").html('');


                if (result === "E404") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA est temporairement indisponible. Veuillez r&eacute;essayer dans 30 secondes...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E405") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA a pris beaucoup pour repondre. R&eacute;essayez dans 30.secondes..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E406") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA n&apos;a donn&eacute; aucun retour. R&eacute;essayez dans 30.secondes..!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E36") {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Mot de passe incorrect !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E37") {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Date d&eacute;but incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E38") {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Date fin incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E39") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucun pr&eacute;paiement trouv&eacute!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E44") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucune d&eacute;claration disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E501") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucune quittance disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E502") {
                    $("#loader-sub-menu").html('<div class="alert alert-info">Ces bulletins ont d&eacute;j&agrave; &eacute;t&eacute; recup&eacute;r&eacute;s. consultez le menu paiements non valid&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E514") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucune r&eacute;ponse de SYDONIA ressayez plutard!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E43") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: Votre code banque n\'est pas autoris&eacute;, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E13") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: SYDONIA Server Exception. Veuillez contacter votre administrateur !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E000") {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else {

                    $("#pager").html(result);

                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');
                }
            },
            error: function(error) {
                
                $("#loader-sub-menu").html('<div class="alert alert-info text-black">Ces bulletins ont d&eacute;j&agrave; &eacute;t&eacute; recup&eacute;r&eacute;s. consultez le menu paiements non valid&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
                $('#buttonCloseModal').prop("disabled", '');
            }
        });

    }


</script>