<div id="loader"></div>
<?php echo form_open('', array('id' => 'mainform2', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    <div class="col-md-12">
        <div class="row">
            <div class="container mt-5 mb-5">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
                        <h4 class="card-title">Opération réussie</h4>
                        
                        <?php if($action == 'traiter'): ?>
                            <p class="card-text">Le débit du compte client et la génération du fichier fait avec succès, veuillez cliquer sur le bouton [envoyer] pour envoyer le fichier d'intégration.</p>
                        <?php else : ?>
                            <p class="card-text">La génération du fichier a été fait avec succès, veuillez cliquer sur le bouton [envoyer] pour envoyer le fichier d'intégration.</p>
                        <?php endif; ?>
                            
                        <button type="button" id="send_file" class="btn btn-success">Envoyer le fichier</button>&nbsp;&nbsp;
                        <button type="button" id="download" class="btn btn-primary" disabled>Télécharger le fichier</button>&nbsp;&nbsp;
                        <button type="button" id="quittance" class="btn btn-primary" disabled>Générer la quittance</button><br/><br/><br/><br/>
                        <input type="hidden" name="integrationid" value="<?= isset($integration->Id_0) ? $integration->Id_0 : '' ?>" >
                        <input type="hidden" name="path" value="<?= isset($integration->Path_12) ? $integration->Path_12 : '' ?>" >
                        <input type="hidden" name="lot_id" value="<?php echo $logirefid ?>" >
                       
                        <?php foreach($batch_reference as $row){ ?>
                            <input name="batch_reference[]" type="hidden" value="<?php echo $row; ?>">
                        <?php } ?>
                    </div>
                    <br/><br/><br/><br/>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script type="text/javascript">
    
$("#send_file").click(function(){
    send_file();
});

$("#download").click(function(){
    var path = '<?= isset($integration->Path_12) ? $integration->Path_12 : '' ?>';
    
    if(path != '')
    {
        download_file(path);
    }
    else
    {
        $('#loader1').html('<div class="alert alert-warning">Echec du téléchargement du fichier, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
});

$("#quittance").click(function() {

    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    var button = $(this).html();

    $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
    var paiementid = '<?= $bulletin_id ?>';

    var url = '<?php echo base_url($module . '/taxbulletin/display/getquittance'); ?>/' + paiementid;

    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        encode: true,
        success: function(result) {

            $(this).prop("disabled", false);
            $('#quittance').html(button);
            $('#loader1').html('');

            if (result === "E003") {
                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E34") {
                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E22") {
                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E11") {
                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E002") {
                $('#loader1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E001") {
                $('#loader1').html('<div class="alert aWarning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E003") {
                $('#loader1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E000") {
                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E005") {
                $('#loader1').html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else if (result === "E404" || result === "E41") {
                $("#loader1").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            } else {
                printQuittance(result);
            }
        },
        error: function(error) {
            $("#loader1").html('<div class="alert aWarning text-white">L\'impression de la quittance a pris beaucoup de temps, veuillez checker votre connexion puis réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            $('#envoyer').prop("disabled", false);
            $('#envoyer').html(button);
        }
    });

});

function send_file()
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    
    var data = $("#mainform2").serialize();
    var url = '<?php echo base_url($module.'/taxbulletin'); ?>/data/send_file_bl_batch';
    
    $("#send_file").prop('disabled', true);
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode          : true,
        success: function(result){

            $("#loader1").html(result.msg);
            
            if(result.code == '200')
            {
                $("#download").prop('disabled', false);
            }
        },
        error:function(error){
            $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'est pas envoyé, veuillez réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}
    
function download_file(buffer) {
    var link = document.createElement('a');
    link.href = '<?php echo base_url()?>' + buffer;
    link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}     
    
</script>