<?php
    if(!empty($instructions))
    {
            $instructions_integrated = true;

            foreach($instructions as $row)
            {
                    if($row->Status_2 != 2)
                    {
                            $instructions_integrated = false;
                    }
            }
    }
    else
    {
            $instructions_integrated = false;
    }

    if($compte_guichet_unique == '00000000000000000000000')
    {
            $disabled = 'disabled';
            $error_message = '<div class="alert aWarning">Le compte guichet unique n\'est pas paramétré, veuillez contacter votre administrateur à cet effet.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
    }
    else
    {
            $disabled = '';
            $error_message = '';
    }

?>

<div id="pager">
    <div class="col-md-12 p-0">
        <div id="loader1"><?php echo $error_message; ?></div>
        <?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
        <?php $chtml->box_body_opening('', true);?>
        <div class="col-md-12">
            <input type="hidden" name="Office" value="<?php echo isset($office) ?$office : ""; ?>" />
            <input type="hidden" name="Agent" value="<?php echo $agent; ?>" />
            <input type="hidden" name="Nif" value="<?php echo $nif ?>" />
            <input type="hidden" name="designation" value="<?php echo $designation; ?>" />
            <input type="hidden" name="account_name" value="<?php echo $account_name; ?>" />
            <input type="hidden" name="account" value="<?php echo $account; ?>" id="account" />
            <input type="hidden" name="branch_code" value="<?php echo $branch_code; ?>" id="branch_code" />
            <input type="hidden" name="mode" value="<?php echo $mode; ?>" />
            <input type="hidden" name="total_amount" value="<?php echo $total; ?>" />
            <input type="hidden" name="Commission" value="<?php echo $commission; ?>" />
            <input type="hidden" name="tva" value="<?php echo $commission * 0.16; ?>" />
            <input type="hidden" name="total_topaid" value="<?php echo $total_to_paid; ?>" id="total_topaid" />
            <input type="hidden" name="taux" value="<?php echo $taux; ?>" />
            <input type="hidden" name="total_amount" value="<?php echo $total; ?>" />
            <input type="hidden" name="total_amount" value="<?php echo $total; ?>" />
            <input type="hidden" name="Bank" value="<?php echo $bank; ?>" />
            <input type="hidden" name="refOp" value="<?php echo $refOp; ?>" id="refOp" />
            <input type="hidden" name="devise_commision" value="<?php echo 'CDF'; ?>" />
            <input type="hidden" name="cdevise" value="<?php echo $cdevise; ?>" id="cdevise" />
            <input type="hidden" name="account_type" value ="<?php echo isset($account_type)? $account_type:""; ?>"/>
            <input type="hidden" name="logirefid" id="logirefid" value="<?php echo isset($batch_bulletin[0]->Lot_14) ? $batch_bulletin[0]->Lot_14 : '' ?>" />
            <input type="hidden" name="batchid" id="batchid" value="<?php echo isset($batch_bulletin[0]->Lot_14) ? $batch_bulletin[0]->Lot_14 : '' ?>" />
            <input type="hidden" name="batch_reference" value="<?php echo isset($batch_lines[0]->Lot_14) ? $batch_lines[0]->Lot_14 : "" ?>" id="batch_reference">
            <input type="hidden" name="batch_id" value="<?php echo isset($batch_lines[0]->Id_0) ? $batch_lines[0]->Id_0 : "" ?>" id="batch_id">

            <div class="box-body">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des bulletins  en lot</h2>
                    <br/>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Bureau</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo isset($services['DGDA'][$office]) ?$services['DGDA'][$office] : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;clarant</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $agent; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Num&eacute;ro imp&ocirc;t</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $nif; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;signation</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $designation; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Intitul&eacute; du compte</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <span id="cCompte"><?php echo $account_name; ?></span>
                                <input type="hidden" value="<?php echo $account_name; ?>" id="account_name" name="account_name"/>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte &agrave; d&eacute;biter</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $account ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 bLeft">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total du lot</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo number_format($total,2,","," ");?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Commission totale du lot</label>
                            </div>
                            <div class="col-md-8">
                               <?php echo form_input('Commission', set_value('Commission', number_format($commission,2,","," ")), 'id="coms" required class="form-control"'); ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">TVA</label>
                            </div>
                            <div class="col-md-8">
                                <?php $tva = $commission * 0.16; ?>
                                <?php echo form_input('tva', set_value('tva', number_format($tva,2,","," ")), 'id="tva" required class="form-control"'); ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo number_format($total_to_paid, 2, ",", " ") ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b>  <?php echo number_format($taux, 2, ",", " "); ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte guichet unique</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <span class="<?php if($disabled == 'disabled') echo 'text-red' ?>"><?php echo $compte_guichet_unique ?></span>
                                <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
            <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table class="table no-margin table-striped table-bordered">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="10px">#</th>
                            <th width="80px">Ann&eacute;e</th>
                             <th width="80px">S&eacute;rie</th>
                            <th width="80px">Num&eacute;ro</th>
                            <th width="50px">Devise</th>
                            <th width="200px">Montant</th>
                            <th>Retour de SYDONIA</th>
                            <th align="center" width="90px">V&eacute;rification</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($bulletins as $bl): ?>
                            <tr id="line<?php echo $i ?>">
                                <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year; ?>" name="years[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->serial; ?>"  name="serials[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                <td><input type="text" value="<?php echo $bl->number; ?>"  name="numbers[<?php echo $i;?>]"   class="form-control itemgrid" required="required" /></td>
                                <td align="center"><span class="form-control">CDF</span></td>
                                <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount, 2, ",", " "); ?>" name="amounts[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-green bold'>Bulletin valide!</span></td>
                                <td align="center" id='btn<?php echo $i; ?>'>
                                   <span class="fa fa-fw text-green fa-check f20"> </span>
                                </td>
                            </tr>
                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-12"></div>
        <div class="col-md-12">
            <div class="box-footer clearfix">
                <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                    <button type="submit" id="reserve" <?php echo $disabled ?> class="btn btn-success"><i class="fa fa-archive "></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <a id="cancel" class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>

                    <input type="hidden" name="lien_id" value="" id="lien_id">
                    <input type="hidden" name="date_lien" value="" id="date_lien">
                    <input type="hidden" name="bulletin_id" value="" disabled="disabled" id="bulletin_id">
                    <input type="hidden" value="" id="action">
                <?php else : ?>
                    <button type="submit" id="reserve" <?php echo $disabled ?> class="btn btn-primary" <?php if($instructions_integrated) echo 'disabled' ?> ><i class="fa fa-archive"></i>&nbsp;&nbsp;Reserver&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="verify" <?php echo $disabled ?> class="btn btn-danger d-none" <?php if($instructions_integrated) echo 'disabled' ?> ><i class="fa fa-history"></i>&nbsp;&nbsp;Vérifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="emargement" <?php echo $disabled ?> class="btn btn-success" <?php if(!$instructions_integrated) echo 'disabled' ?>><i class="fa fa-folder"></i>&nbsp;&nbsp;Emarger&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="extourne" class="btn btn-primary d-none" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;</button>&nbsp;
                    <button type="submit" id="save" <?php echo $disabled ?> class="btn btn-success d-none" disabled=""><i class="fa fa-archive "></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <a id="cancel" class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>

                    <input type="hidden" name="lien_id" value="" id="lien_id">
                    <input type="hidden" name="date_lien" value="" id="date_lien">
                    <input type="hidden" name="bulletin_id" value="" disabled="disabled" id="bulletin_id">
                    <input type="hidden" name="transaction_id" value="" id="transaction_id">
                    <input type="hidden" name="error_code" value="" id="error_code">
                    <input type="hidden" value="" id="action">
                <?php endif; ?>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
        <?php echo form_close(); ?>
    </div>
</div>

<script type="text/javascript">

        $('#verify').click(function(){
            $('#action').val('verify');
        });

        $('#reserve').click(function(){
            $('#action').val('reserver');
        });

        $('#emargement').click(function(){

            $('#action').val('emargement');
        });

        $("#extourne").click(function(){
            $("#action").val('extourne');
        });

        $("#form").submit(function(event) {

            event.preventDefault();

            var data = $(this).serialize();

            var action = $('#action').val();

            console.log(data); // Debug: vérifier les données envoyées

            if (action == 'reserver')
            {
                <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>

                    get_reservation(data);

                <?php else : ?>

                    create_batch_bulletin_and_debit_the_customer(data);

                <?php endif; ?>
            }
            else if(action == 'save')
            {
                get_reservation(data);
            }
            else if(action == 'verify')
            {
                verify(data);
            }
            else if(action == 'emargement')
            {
                emargement(data);
            }
            else if(action == 'extourne')
            {
                cancel_reservation(data);
            }

        });

        $("#buttonCloseModal").click(function() {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#pager").html(data);
                $("#pager").addClass('content');
                $("#close").removeClass('d-none');
                $("#cancel").addClass('d-none');
                $("#col").removeClass('col-md-2');
                $("#col").addClass('col-md-1');
                $("#content").removeClass('col-md-8');
                $("#content").addClass('col-md-10');
                $("#close").removeClass('col-md-2');
                $("#close").addClass('col-md-1');
            });
        });

        /* ----- batch_create_bulletin ----- */
        function create_batch_bulletin_and_debit_the_customer(data, type=null)
        {
            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

            $('#save').prop("disabled", true);
            var button = $('#reserve').html();
            $('#save').html('<span>Chargement...</span>');

            scrollUP();

            var url = '<?php echo base_url($module.'/taxbulletin/display/batch_create_bulletin'); ?>/'+type;

            $.ajax({
                   type        : 'POST',
                   url         : url,
                   data        : data,
                   dataType    : 'json',
                   encode      : true,
                   success: function(result){
                        $('#save').html(button);
                        $("#loader-sub-menu").html('');

                        //if(result.code == 'E200' || result.code == 'E500')
                        if(result.code == 'E200')
                        {
                            $('#logirefid').val(result.logirefid);
                            $('#batchid').val(result.batchid);
                            $("#batch_id").val(result.batchid);
                            $("#batch_reference").val(result.logirefid);
                            var data = $('#form').serialize();

                            debit_customer(data);
                        }
                        else if (result.code == 'E500')
                        {
                            $("#loader-sub-menu").html('<div class="alert aWarning text-black">Vous avez r&eacute;utilis&eacute; une r&eacute;f&eacute;rence de l\'OP d&eacute;j&agrave; utilis&eacute;e. Veuillez changer de r&eacute;f&eacute;rence sil vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                   },
                   error:function(error){
                        $("#loader-sub-menu").html('<div class="alert aWarning">L\'enregistrement a pris beaucoup de temps, veuillez réessayer, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#envoyer').html(button);
                   }
            });
        }

        function debit_customer(data)
        {
            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/debit_client_batch';
            //$('#reserve').prop("disabled",true);
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'json',
                    encode          : true,
                    success: function(result){

                        $("#loader-sub-menu").html('');

                        if(result.code=='E407')
                        {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            //$('#reserve').prop("disabled",true);
                            $('#valider').prop("disabled",true);
                        }
                        else
                        {
                            if(result.code == 'E200' || result.code == 'E500')
                            {
                                $("#loader-sub-menu").html(result.msg);

                                $("#batch_id").val(result.id);
                                $("#batch_reference").val(result.logirefid);
                                $("#emargement").prop('disabled',false);
                            }
                            else
                            {
                                $("#loader-sub-menu").html(result.msg);
                                $('#verify').removeClass('d-none');
                                $("#reserve").prop('disabled',true);

                                $('#error_code').val(result.code);
                                $('#transaction_id').val(result.transaction_id);
                            }
                        }
                    },
                    error:function(error){
                        $('#loader-sub-menu').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse du corebanking est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }

        function verify(data)
        {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/verify_transaction_batch';

            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                    $("#loader-sub-menu").html('');

                    if(result.code =='E407')
                    {
                        $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de verification n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#repartition').prop("disabled",true);
                        $('#valider').prop("disabled",true);
                    }
                    else if(result.code =='E200')
                    {
                        $("#loader-sub-menu").html(result.msg);
                        $("#emargement").prop('disabled',false);
                        $("#verify").prop('disabled',true);
                    }
                    else
                    {
                        $('#loader-sub-menu').html(result.msg);
                    }
                },
                error:function(error)
                {
                    $('#loader-sub-menu').html('<div class="alert aWarning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }

        function get_reservation(data)
        {
            var compte = $('#account').val();
            var devise = $('#cdevise').val();
            var montant = $('#total_topaid').val();
            var refop = $('#refOp').val();
            var object = "batch";
            var csrf = $('input[name="csrf_name"]').val();

            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxaccounts/data/get_reservation'); ?>';

            $.ajax({
                type        : 'POST',
                url         : url,
                data        : { compte : compte, devise : devise, montant : montant, refOp: refop, object: object, csrf_name:csrf},
                dataType    : 'json',
                encode          : true,
                success: function(response)
                {
                    if(response.code == '200')
                    {
                        $("#lien_id").val(response.lien_id);
                        $("#date_lien").val(response.date_lien);

                        <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>

                            create_batch_bulletin_and_reserve_the_fund(data, "reservation");

                        <?php else: ?>

                            $("#loader-sub-menu").html('<div class="alert alert-info text-white"> Paiement enregistr&eacute; avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#save").prop("disabled", true);

                            submitter(data, "reservation");

                        <?php endif; ?>
                    }
                    else if(response.code =='E500')
                    {
                        $("#loader-sub-menu").html('<div class="alert aWarning text-white"> Vous avez r&eacute;utilis&eacute; une r&eacute;f&eacute;rence de l\'OP d&eacute;j&agrave; utilis&eacute;e. Veuillez changer de r&eacute;f&eacute;rence sil vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $("#releaseLien").removeClass('d-none');

                        $("#bulletin_id").val(response.id);

                        <?php if(!isset($options['DGDA']['funds-reservation']) && !isset($options['DGDA']['funds-reservation-with-instructions'])): ?>

                            $("#save").prop('disabled', false);

                        <?php endif ?>
                    }
                    else if(response.code == 'E008')
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Il y a d&eacute;j&agrave; une reservation de fonds sur ce compte, veuillez contacter le gestionnaire du compte <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code == 'E162')
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Ce compte n\'existe pas.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code == 'E4348')
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">La r&eacute;servation de fonds n\'est pas autoris&eacute; pour ce compte.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                },
                error:function(error)
                {
                    $('#message').html('<div class="alert aWarning text-white">La réservation a pris beaucoup de temps, veuillez reprendre s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }

        function create_batch_bulletin_and_reserve_the_fund(data, type=null)
        {
            var formData = form_to_payload("#form");

            var bank = '<?php echo $bank ?>';

            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin/display/batch_create_bulletin'); ?>/'+type;

            $.ajax({
                type        : 'POST',
                url         : url,
                data        : formData,
                dataType    : 'json',
                // encode          : true,
                success: function(response)
                {
                    if(response.batchid > 0)
                    {
                        '<?php if(isset($options['DGDA']['funds-reservation-with-instructions'])): ?>';
                            $('#batchid').val(response.batchid);
                            $('#logirefid').val(response.logirefid);

                            var data = $('#form').serialize();

                            initiate_transaction(data);

                        '<?php else: ?>'
                            $('#batchid').val(response.batchid);
                            $('#logirefid').val(response.logirefid);

                            var data = $('#form').serialize();

                            $("#loader-sub-menu").html('<div class="alert aSuccess text-white"> Paiement enregistr&eacute; avec succ&egrave;s, veuillez contacter le validateur pour la confirmation de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                        '<?php endif; ?>'
                    }
                    else
                    {
                        $("#loader-sub-menu").html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                },
                error:function(error)
                {
                    $('#message').html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }

        function submitter(data, type=null)
        {
                $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

                $('#save').prop("disabled", true);
                var button = $('#reserve').html();
                $('#save').html('<span>Chargement...</span>');

                scrollUP();

                var url = '<?php echo base_url($module.'/taxbulletin/display/batch_create_bulletin'); ?>/'+type;

                $.ajax({
                       type        : 'POST',
                       url         : url,
                       data        : data,
                       dataType    : 'json',
                       encode      : true,
                       success: function(result){
                                $('#save').html(button);
                                $("#loader-sub-menu").html('');

                                if(result.code == 'E200')
                                {
                                        $("#loader-sub-menu").html('<div class="alert aSuccess text-white">Paiement enregistr&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');

                                }
                                else if (result.code == 'E500')
                                {
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-black">Vous avez r&eacute;utilis&eacute; une r&eacute;f&eacute;rence de l\'OP d&eacute;j&agrave; utilis&eacute;e. Veuillez changer de r&eacute;f&eacute;rence sil vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else
                                {
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }

                       },
                       error:function(error){
                            $("#loader-sub-menu").html('<div class="alert aWarning">L\'enregistrement a pris beaucoup de temps, veuillez réessayer, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                           $('#envoyer').html(button);
                       }
               });
        }

        function emargement(data) 
        {
                $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                $('#emargement').prop("disabled", true);
                var button = $('#emargement').html();
                $('#emargement').html('<span>Chargement...</span>');
                var url = '<?php echo base_url($module . '/taxbulletin/display/batch_confirmation_from_operator'); ?>';
                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        timeout: 300000,
                        success: function(result) {
                                //$('#emargement').prop("disabled", false);
                                $('#emargement').html(button);
                                $("#loader-sub-menu").html('');

                                // Trim pour enlever espaces/retours de ligne
                                result = $.trim(result);

                                if(result == "E200")
                                {
                                        $('#reserve').prop("disabled", true);
                                        $('#loader-sub-menu').html('<div class="alert alert-info">Votre paiement est en cours de traitement. Vous pouvez suivre l’évolution de vos bulletins dans le menu <strong>« Bulletins en traitement »</strong> pour suivre le statut de vos paiements.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reject").addClass('hidden');
                                }
                                else if (result === "E34") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E22") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E21") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E18") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E4") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E11") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E13") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E002") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E003") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E000") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                } else if (result === "E404") {
                                        batch_recover(data);
                                } else if (result === "E405") {
                                        batch_recover(data);
                                } else if (result === "E406") {
                                        batch_recover(data);
                                } else if (result === "E444") {
                                        batch_recover(data);
                                } else if (result === "E411") {
                                        batch_recover(data);
                                } else if (result === "E501") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#envoyer').prop("disabled", true);
                                        $('#extourne').removeClass('d-none');
                                        $('#reserve').addClass('d-none');
                                }  else {
                                        $('#envoyer').prop("disabled", false);
                                        $('#envoyer').html(button);
                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');
                                        $("#panel").html(result);
                                }
                        },
                        error: function(error) {
                                scrollUP();
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'emargement a pris beaucoup de temps, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }

        function batch_recover(data) 
        {
                $('#recover').prop("disabled", true);
                $('#buttonCloseModal').prop("disabled", true);
                $("#envoyer").addClass('d-none');
                var button = $('#recover').html();
                $('#recover').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
                $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var url = '<?php echo base_url($module . '/taxbulletin/display/batch_recover'); ?>/';
                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $("#loader-sub-menu").html('');
                                if (result === "E000") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E404") {
                                        scrollUP();
                                        $('#recover').prop("disabled", false);
                                        $('#recover').html(button);
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E002") {
                                        scrollUP();
                                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else {
                                        $('#envoyer').prop("disabled", false);
                                        $('#envoyer').html(button);
                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');
                                        $("#panel").html(result);
                                }
                        },
                        error: function(error) {
                                scrollUP();
                                $('#recover').prop("disabled", false);
                                $('#recover').html(button);
                                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }

        function initiate_transaction(data)
        {
            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin/display/initiate_transaction_batch'); ?>';

            $.ajax({
                type        : 'POST',
                url         : url,
                data        : data,
                dataType    : 'html',
                encode      : true,
                success: function(response){

                    $("#loader-sub-menu").html('');
                    $("#loader-sub-menu").html(response);

                    $("#reserve").prop('disabled', true);
                },
                error:function(error)
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement du paiement a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }

        function cancel_reservation(data)
        {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin/display/cancel_reservation_for_bl_batch'); ?>';

            $("#extourne").prop('disabled', true);
            $("#emargement").prop('disabled', true);

            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                    $("#loader-sub-menu").html('');

                    if(result.code =='E407')
                    {
                        $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option d\'annulation de réservation n\'est pas paramétrée pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#repartition').prop("disabled",true);
                        $('#valider').prop("disabled",true);
                    }
                    else if(result =='E200')
                    {
                        $("#loader-sub-menu").html('<div class="alert alert-info text-black"> L\'extourne a &eacute;t&eacute; faite avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result =='E411')
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }

                },
                error:function(error)
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'extourne a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }

        function scrollUP() {
                $('html, body').animate({
                        scrollTop: $("#loader1").offset().top
                }, 20);
        }

        function form_to_payload(formSelector) 
        {
            var formArray = $(formSelector).serializeArray();
            var payload = {};

            var csrfName = '<?= csrf_token() ?>';
            var csrfValue = '<?= csrf_hash() ?>';

            $.each(formArray, function(index, field) {
                var name = field.name;
                var value = field.value;

                // Ne pas mettre le csrf dans le payload JSON
                if (name === csrfName) {
                    csrfValue = value;
                    return;
                }

                var match = name.match(/^([a-zA-Z0-9_]+)\[([0-9]+)\]$/);

                if (match) {
                    var key = match[1];
                    var itemIndex = match[2];

                    if (!payload[key]) {
                        payload[key] = {};
                    }

                    payload[key][itemIndex] = value;
                } else {
                    payload[name] = value;
                }
            });

            var data = {};
            data[csrfName] = csrfValue; // CSRF reste comme champ POST normal
            data['payload'] = JSON.stringify(payload);

            return data;
        }
</script>