<?php 
    if (isset($_SESSION['Bank_rates'])) :
        $taux = json_decode($_SESSION['Bank_rates'], true);
        $taux_usd = $taux['Dollar_4'];
    else :
        $taux['Dollar_4'] = $taux_usd = 00;
        $taux['Euro_5']  = 00;
        $taux['Rand_6']  = 00;
    endif;
?>

<div id="pager">
    <div class="col-md-12">
        <div id="loader1"></div>
        
        <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="col-md-12">
                
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6 p-0">
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Bureau</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <?php echo isset($services['DGDA'][$paiement->Office_6]) ? $services['DGDA'][$paiement->Office_6] : "-"; ?>
                                        <input type='hidden' name='office' value='<?php echo isset($paiement->Office_6) ? $paiement->Office_6 : ""; ?>'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Compte Guichet Unique</label>
                                    </div>
                                    <div class="col-md-8">
                                      <b>:</b>  <?php echo $compte_guichet_unique; ?>
                                      <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                                      <input name="account_value" value="<?= ""; ?>" type="hidden" id="account_value" disabled="disabled" />
                                      <input name="account_devise" value="CDF" type="hidden" id="account_devise" disabled="disabled" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 p-0">
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Montant total</label>
                                    </div>
                                    <div class="col-md-8">
                                       <b>:</b> <?php echo number_format($total_amount,2,","," ").' CDF '; ?>
                                       <input type='hidden' name='total_amount' value='<?php echo $total_amount ?>'>
                                    </div>
                                </div> 
                            </div>

                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Total commission</label>
                                    </div>
                                    <div class="col-md-8">
                                       <b>:</b> <?php echo number_format($total_commission,2,","," ").' CDF';?>
                                       <input name="commission" value='<?php echo $total_commission ?>' id="commission" type="hidden" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <div class="col-md-12 p-0">
                        <br/>
                        <button type="submit" id="create_file" class="btn btn-primary" ><i class="fa fa-save"></i>&nbsp;&nbsp;Cr&eacute;er le fichier&nbsp;&nbsp;</button>&nbsp;
                        <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                        <input type="hidden" name="action" value="" id="action">
                        <input type="hidden" name="type" value="single" id="">
                    </div>
                </div>
            
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
                <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table class="table no-margin table-bordered" id="table">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="5px" class="center">#</th>
                            <th width="150px" class="center">Bureau</th>
                            <th width="20px" class="center">Designation</th>
                            <th width="100px" class="center">Nbre des bulletins</th>
                            <th width="150px" class="center">Montant total</th>
                            <th width="50px" class="center">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach($bulletins as $row): ?>
                        <tr>
                            <td class="center"width=""><?php echo $i; ?></td>
                            <td class="center" width=""><?php echo isset($services['DGDA'][$row->Office_7]) ? $services['DGDA'][$row->Office_7] : ''; ?></td>
                            <td class="center" width=""><?php echo $row->Designation_15; ?></td>
                            
                            <?php 

                                $bl_list = json_decode($row->Bulletins_22, true); 
                                
                                $total_bl = isset($bl_list['years']) ? count($bl_list['years']) : '';
                                
                            ?>
                            
                            <?php for ($i = 1; $i <= count($bl_list["years"]); $i++): ?>
                                
                                <input type="hidden" value="<?php echo $bl_list["years"][$i]; ?>" name="years[<?php echo $i; ?>]" />
                                <input type="hidden" value="<?php echo $bl_list["serials"][$i]; ?>" name="serials[<?php echo $i; ?>]" />
                                <input type="hidden" value="<?php echo $bl_list["amounts"][$i]; ?>" name="amounts[<?php echo $i; ?>]" />
                                
                            <?php endfor; ?>
                            
                            <td class="center" width=""><?php echo $total_bl; ?></td>
                            <td class="center" width=""><?php echo $row->Devise_12. ' '.number_format($row->Amount_11,2,","," "); ?></td>
                            <td class="center" width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));  ?></td>
                        </tr>
                        <?php $i++; endforeach;?>
                    </tbody>

                </table>
            </div>
        </div>
        <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 
    </div>
    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-custom-width">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  de liquidation</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">

    $("#contenter").on("click", "#close_form", function(){
        close_form();
    });

    get_accountname();
    
    $("#treat").click(function(){
       $("#action").val('traiter');
    });

    $("#emargement").click(function(){
       $("#action").val('emargement');
    });
    
    $("#save").click(function(){
       $("#action").val('save');
    });
    
    $("#portail").click(function(){

           $("#emargement").prop('disabled', false);
           $("#treat").prop('disabled', true);
           $("#action").val('save');
    });
    $("#virmul").click(function(){

           $("#treat").prop('disabled', false);
           $("#emargement").prop('disabled', true);
           $("#action").val('traiter');
    });
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'traiter')
        {   
            debit_customer(data);
        }
        else if(action == 'emargement')
        {
            emargement(data);
        }
        else if(action == 'save')
        {
            submiter(data);
        }
    });
    
    $("#close").click(function(){
           close_form();
    });
    
    
    function debit_customer(data)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin'); ?>/save/debit_client';
        $('#validerExtract').prop("disabled",true);
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        
                    if(result.code=='E407')
                    {
                        $('#loader1').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#emargement').prop("disabled",true);
                        $('#treat').prop("disabled",true);
                    }
                    else if(result.code == "E162")
                    {
                        $("#loader1").html('');
                        $('#loader').html('<div class="alert aDanger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "E463")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "E411")
                    {
                        $("#loader1").html('');
                        $('#approbation').removeClass('hidden');
                        $('#loader').html('<div class="alert aDanger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "E3238")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDangerr text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "W0205")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "E397")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "AD3")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "E9999")
                    {
                        $("#loader1").html('');
                        $('#approbation').removeClass('hidden');
                        $('#loader1').html('<div class="alert aDanger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "ERR002")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "ERR003")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "P83")
                    {
                        $("#loader1").html('');
                        $('#loader1').html('<div class="alert aDanger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code == "200")
                    {
                        $('#emargement').prop("disabled", false);
                        $('#treat').prop("disabled", true);

                        $('#loader1').html('<div class="alert aSuccess text-white"> Le débit du compte du client a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger le bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {   
                        $("#loader1").html('');
                        $('#approbation').removeClass('hidden');
                        $('#loader1').html('<div class="alert aDanger text-white"> Il y a eu un time out pendant la validation de la transaction, veuillez vous connecter dans Finacle pour v&eacute;rifier si la transaction est pass&eacute;e ou pas. Si la transaction est d&eacute;j&agrave; pass&eacute;e, cochez la case [proc&eacute;c&eacute;der &agrave; l\'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                },
                error:function(error){
                    $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse Finacle est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
    }
    
    function emargement(data) 
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $('#emargement').prop("disabled", true);
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        
        var url = '<?php echo base_url('branch/taxbulletin/display/batch_confirmation_export_file'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
                $('#loader1').html('');
                
                if (result == "E34") 
                {
                    scrollUP();
                    $('#loader1').html('<div class="alert aDanger">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E22") 
                {
                    scrollUP();
                    $('#loader1').html('<div class="alert aDanger">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E21") 
                {
                    $('#loader1').html('<div class="alert aDanger">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                }
                else if (result == "E18") 
                {
                    $('#loader1').html('<div class="alert aDanger">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E4") 
                {
                    $('#loader1').html('<div class="alert aDanger">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
                else if (result == "E11") 
                {
                    $('#loader1').html('<div class="alert aDanger">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } else if (result == "E13") 
                {
                    $('#loader1').html('<div class="alert aDanger">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E002") 
                {
                    $('#loader1').html('<div class="alert aWarning">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E003") 
                {
                    $('#loader1').html('<div class="alert aWarning">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E000") 
                {
                    $('#loader1').html('<div class="alert aWarning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else if (result == "E404") 
                {
                    batch_recover(data);
                } 
                else if (result == "E405")
                {
                    batch_recover(data);
                } 
                else if (result == "E406") 
                {
                    batch_recover(data);
                } 
                else if (result == "E444") 
                {
                    batch_recover(data);
                } 
                else if (result == "E411") 
                {
                    batch_recover(data);
                } 
                else if (result == "E501") 
                {
                    $('#loader1').html('<div class="alert aWarning">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#envoyer').prop("disabled", true);
                    $('#extourne').removeClass('hidden');
                    $('#reserve').addClass('hidden');
                } 
                else 
                {
                    $('#loader1').html('<div class="alert aSuccess text-white">Lot de bulletins confirmés avec succès, veuillez cliquer sur le bouton [Enregistrer] pour enregistrer les paiements.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#bulletin_id').val(result);
                    $('#save').prop("disabled", false);
                }
            },
            error: function(error) {
                scrollUP();
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
                $('#loader1').html('<div class="alert aWarning">La confirmation a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function submiter(data) {

        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/save/save_batch'); ?>';
        //$('#save').prop("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {

                $('#loader1').html(result);
                if (result == 'E500') 
                {
                    $('#loader1').html('<div class="alert alert-info text-black">Le lot de paiement existe d&eacute;j&agrave;, veuillez v&eacute;rifier le paiement de ce lot dans la liste de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
                else if (isNaN(result) == true)
                {
                    $("#loader1").html('');
                    $('#loader1').html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
                else if (result > 0) 
                {
                    create_file(result);
                }
                else 
                {
                    $('#loader1').html('');
                    $('#save').prop("disabled", false);
                    $('#loader1').html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) 
            {
                $('#loader1').html('<div class="alert aDanger text-white">Une erreur est survenue lors de l\'enregistrement, veuillez v&eacute;rifier la liste de bulletins de ce lot dans les paiements non valid&eacute;s s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function create_file(ref)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = $("#mainform").serialize();
        var url = '<?php echo base_url($module.'/taxbulletin'); ?>/data/create_file_sftp/'+ref;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){

                $("#loader1").html('');
                
                if(isNaN(result)==true)
                {
                        $('#loader1').html('<div class="alert aWarning">L\'enregsitrement des écritures à intégrer dans le fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result > 0)
                {
                    result_treatment(result)
                }
                else if(result == '404')
                {
                    $('#loader1').html('<div class="alert alert-warning">Alerte: Echec! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == 'E202')
                {
                    $('#loader1').html('<div class="alert alert-danger">Alerte: Probl&egrave;me de connexion au serveur FTP.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == 'E444')
                {
                    $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi du fichier! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == 'E300')
                {
                    $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi... fichier non trouv&eacute;! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error){
                $('#loader1').html('<div class="alert aWarning text-white">Une erreur est survenu lors de l\'enregistrement des écritures à inclure dans le fichier, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    

    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '<?php echo $paiement->Account_16; ?>';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function result_treatment(instructionid)
    {
        var data = $('#mainform').serialize();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/result_with_export_file'); ?>/'+instructionid;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-2").removeClass('bg-green-active');
                $("#step-2").addClass('bg-gray');
                $("#step-3").removeClass('bg-gray');
                $("#step-3").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    

    function view_bulletin(lot) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/_bulletins_by_lot'); ?>/'+lot;
        $.get(url, function (data, status) {
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
    }
    
    
    
    function close_form()
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module.'/taxreports/display/prepayments'); ?>", function (data, status) {
           $("#loader1").html('');
           $("#pager").html(data);
           $("#pager").addClass('content');

           $("#close").removeClass('hidden');
           $("#close_form").addClass('hidden');

        });
    }

</script>
