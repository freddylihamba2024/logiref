<?php echo '<pre>'; var_dump($results); die; ?>
<?php $chtml->box_body_opening('', false); ?>
<?php echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>




    <style>label {min-width: 150px !important; }</style>
    <div class="box-body">
        <div class="row margin">
            <div class="col-md-6">
                <div class="col-md-12  small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="site">Bureau</label>
                        </span>
                        <?php echo form_dropdown('Office', $services['DGDA'], $office, 'required class="form-control chosen-select"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif">Num&eacute;ro imp&ocirc;t</label>
                        </span>
                        <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                    </div>
                </div>

                <input type="hidden" name="Agent" value="<?= $agent ?>">
                <input type="hidden" name="designation" value="<?= $designation ?>">
                <input type="hidden" name="account_name" value="<?= $account_name ?>">
                <input type="hidden" name="account" value="<?= $account ?>">

                <div class="col-md-12 small-box">
                    <div class="input-group no-padding">
                        <span class="input-group-addon">
                            <label for="account_name">Intitul&eacute; du compte</label>
                        </span>
                        <?php echo form_input('account_name', set_value('account_name', $account_name), ' class="form-control" required '); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group no-padding">
                        <span class="input-group-addon">
                            <label for="account">Compte &agrave; d&eacute;biter</label>
                        </span>
                        <?php echo form_input('account', set_value('account', $account), ' class="form-control" required '); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group <?php echo isset($reuseRef) ? "" : "d-none" ?>">
                        
                        <label>D&eacute;biter le client <input type="checkbox" name="debit" value="1" id="debit"></label>
                       
                        <?php if (isset($reuseRef)) : ?>
                            <input type="hidden" name="reuseRef" value="1" id="reuseRef">
                        <?php else : ?>
                           <input type="hidden" name="reuseRef" value="0" id="reuseRef" disabled="disabled">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6 bLeft">
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="site">Mode de paiement</label>
                        </span>
                        <?php echo form_dropdown('mode', $modes, $mode, 'required class="form-control"'); ?>
                    </div>
                </div>
                
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="total_amount">Montant total du lot</label>
                        </span>
                        <?php echo form_input('total_amount', set_value('total_amount', number_format($total, 2, ",", " ")), 'id="total_amount" required class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="coms">Commission totale du lot</label>
                        </span>
                        <?php echo form_input('Commission', set_value('Commission', number_format($commission, 2, ",", " ")), 'id="coms" required class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <?php $tva = $commission * 0.16; ?>
                        <span class="input-group-addon">
                            <label for="tva">TVA</label>
                        </span>
                        <?php echo form_input('tva', set_value('tva', number_format($tva, 2, ",", " ")), 'id="tva" class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group col-md-12">
                        <span class="input-group-addon">
                            <label for="total_topaid">Total &agrave; payer</label>
                        </span>
                        <?php echo form_input('total_topaid', set_value('total_topaid', number_format($total_to_paid, 2, ",", " ")), 'id="total_topaid" class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="taux">Taux appliqu&eacute;</label>
                        </span>
                        <?php echo form_input('taux', set_value('taux', number_format($taux, 2, ",", " ")), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group <?php echo isset($reuseRef) ? "" : "d-none" ?>">
                        <label>Ne pas d&eacute;biter le client <input type="checkbox" name="no_debit" value="1" id="no_debit"></label>
                    </div>
                </div>
            </div>
        </div>
        <div id="footpage" class="box-footer clearfix"></div>
    </div>
    <div class="box-body box-solid no-padding">
        <div class="box-body">
            <input type="hidden" name="Bank" value="<?php echo $bank; ?>" />
            <input type="hidden" name="refOp" value="<?php echo $refOp; ?>" />
            <input type="hidden" name="devise_commision" value="<?php echo 'CDF'; ?>" />
            <input type="hidden" name="cdevise" value="<?php echo $cdevise; ?>" />

            <div class="table-responsive">
                <table class="table no-margin table-striped table-bordered">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="10px">#</th>
                            <th width="80px">Ann&eacute;e</th>
                            <th width="80px">Bulletin</th>
                            <th width="50px">Devise</th>
                            <th width="200px">Montant</th>
                            <th>Retour de SYDONIA</th>
                            <th align="center" width="90px">V&eacute;rification</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($bulletins as $bl): ?>
                            <tr id="line<?php echo $i ?>">
                                    <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                    <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year; ?>" name="years[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->number; ?>" name="serials[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span class="form-control">CDF</span></td>
                                    <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount, 2, ",", " "); ?>" name="amounts[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Bulletin non v&eacute;rifi&eacute;</span></td>
                                    <td align="center" id='btn<?php echo $i; ?>'>
                                            <span class="fa fa-fw text-gray fa-question f20"> </span>
                                    </td>
                            </tr>
                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="box-footer clearfix">
            <button type="button" id="treat" class="btn btn-primary"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="extourne" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="reserve" class="btn btn-success" disabled><i class="fa fa-archive "></i>&nbsp;&nbsp;R&eacute;server&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="verify" class="btn btn-success d-none"><i class="fa fa-external-link "></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button id="envoyer" type="submit" style="margin-left:0px;" name="submit" class="btn btn-success" disabled="disabled"><i class="fa fa-check"></i> &nbsp;Confirmer dans sydonia&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="recover" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;esayer&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <input type="hidden" name="logirefid" value="" id="logirefid">
            <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
            <input type="hidden" name="transaction_id" value="" id="transaction_id">
            <input type="hidden" name="error_code" value="" id="error_code">
            <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Annuler &nbsp;</button>
        </div>
    </div>
<?php echo form_close(); ?>
<?php $chtml->box_body_closing(); ?>