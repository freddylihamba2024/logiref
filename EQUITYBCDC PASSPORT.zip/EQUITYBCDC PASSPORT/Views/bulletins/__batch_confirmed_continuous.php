<?php 
    if (isset($_SESSION['Bank_rates'])) :
        $taux = json_decode($_SESSION['Bank_rates'], true);
        $taux_usd = $taux['Dollar_4'];
    else :
        $taux['Dollar_4'] = $taux_usd = 00;
        $taux['Euro_5']  = 00;
        $taux['Rand_6']  = 00;
    endif;
?>

<div id="pager">
    <div class="col-md-12">
        <div id="loader1"></div>
        
        <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="col-md-12">
                
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6 p-0">
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Nbre de bulletins</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <?php echo $data['total_bl']; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Compte Guichet Unique</label>
                                    </div>
                                    <div class="col-md-8">
                                      <b>:</b>  <?php echo $compte_guichet_unique; ?>
                                      <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                                      <input name="account_value" value="<?= ""; ?>" type="hidden" id="account_value" disabled="disabled" />
                                      <input name="account_devise" value="CDF" type="hidden" id="account_devise" disabled="disabled" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 p-0">
                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Montant total</label>
                                    </div>
                                    <div class="col-md-8">
                                       <b>:</b> <?php echo number_format($data['total_amount'],2,","," ").' CDF '; ?>
                                       <input type='hidden' name='total_amount' value='<?php echo $data['total_amount']; ?>'>
                                    </div>
                                </div> 
                            </div>

                            <div class="row">
                                <div class="input-group col-md-12">
                                    <div class="col-md-4">
                                        <label for="office">Total commission</label>
                                    </div>
                                    <div class="col-md-8">
                                       <b>:</b> <?php echo number_format($data['total_commission'],2,","," ").' CDF';?>
                                       <input name="commission" value="<?= $data['total_commission']; ?>" id="Commission" type="hidden" />
                                    </div>
                                </div>
                            </div>
                            
<!--                            <input type='hidden' name='lot_id' value='<?php //echo $paiement->Lot_14 ?>'>
                            <input type='hidden' name='batch_id' value='<?php //echo $paiement->Id_0 ?>'>
                            <input type='hidden' name='mode' value='7'>
                            <?php //$tva = $paiement->Commission_20 * 0.16; ?>
                            <input type='hidden' name='tva' value='<?php //echo $tva; ?>'>
                            <input type='hidden' name='taux' value='<?php //echo $taux_usd; ?>'>
                            <input type='hidden' name='Nif' value='<?php //echo $paiement->Nif_8; ?>'>
                            <input type='hidden' name='Bank' value='<?php //echo $paiement->Bank_10; ?>'>
                            <input type='hidden' name='Agent' value='<?php //echo $paiement->Agent_9; ?>'>
                            <input type="hidden" name="refOp" value="<?php //echo $paiement->Refop_25; ?>" />
                            <input type="hidden" name="logirefid" value="<?php //echo $paiement->Lot_14; ?>" />
                            <input type="hidden" name="devise_commision" value="CDF" />
                            <input type="hidden" name="cdevise" value="<?php //echo $paiement->Devise_17; ?>" />-->
                            <input type="hidden" name="bulletin_id" id="bulletin_id" value="">
                        </div>
                    </div>
                </div>
                <div class="col-md-12 p-0 d-none">
                    <br/>
                    &nbsp;&nbsp;&nbsp;<input type="radio" name="choice" value="2" id="virmul" style="background-color: green !important" checked> Débiter le compte du client.<br>
                    &nbsp;&nbsp;&nbsp;<input type="radio" name="choice" value="1" id="portail" style="background-color: green !important"> Inclure les instructions du débit du compte client dans le fichier.<br>
                </div>
                <div class="box-footer clearfix">
                    <div class="col-md-12 p-0">
                        <br/>
                        <button type="submit" id="emargement" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Emargement&nbsp;&nbsp;</button>&nbsp;  
                        <button type="submit" id="create_file" class="btn btn-primary" ><i class="fa fa-save"></i>&nbsp;&nbsp;Cr&eacute;er le fichier&nbsp;&nbsp;</button>&nbsp;
                        <input type="hidden" name="action" value="" id="action">
                        <input type="hidden" name="type" value="batch" id="">
                        <input type="hidden" name="Logirefid" value="<?php //echo $paiement->Lot_14; ?>" />
                        <input type="hidden" name="batchid" value="<?php //echo $paiement->Id_0; ?>" />
                    </div>
                </div>
            
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
                <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <?php if(!empty($bulletins)): ?>
                <table id="dataTable" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th width="5">#</th>
                            <th width="20">Quittance</th>
                            <th width="10">Ann&eacute;e</th>
                            <th width="50">Bulletin</th>
                            <th width="20">Devise</th>
                            <th width="200">Montant</th>
                            <th width="80" class="text-center">Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; foreach ($bulletins as $obj) : ?>
                        <tr>
                            <td><span><b><?php echo $i; ?></b></span></td>
                            <td id="result<?php echo $obj->Id_0; ?>"><?php $BL = json_decode($obj->Results_13);
                            echo $BL->receiptSerial . ' ' . $BL->receiptNumber; ?></td>
                            <td width=""><?php echo $obj->Year_5; ?></td>
                            <td><?php echo $obj->Serie_7 . ' ' . $obj->Number_8; ?></td>
                            <td><?php echo 'CDF'; ?></td>
                            <td><?php echo number_format($obj->Amount_12, 2, ".", ","); ?></td>
                            <td class="text-center"><span id="corebanking_result<?php echo $obj->Id_0; ?>" class="fa fa-fw text-gray fa-question f20"></span></td>
                        </tr>
                        <input type='hidden' name='bulletin_ids[]' value='<?php echo $obj->Id_0 ?>'>
                    <?php $i++; endforeach; ?>
                    </tbody>  
                </table>
                <?php else:?>
                    <section id="cat_list" class="text-center ">
                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                        <span class="d-block f14 text-black p-2"><b>Aucun bulletin trouv&eacute;!</b></span>        
                    </section>
                <?php endif; ?>
            </div>
            <?php foreach($batch_reference as $row){ ?>
                <input name="batch_reference[]" type="hidden" value="<?php echo $row; ?>">
            <?php } ?>
        </div>
        <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 
    </div>
    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-custom-width">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
</div>

    
<script type="text/javascript">

    $("#contenter").on("click", "#close_form", function(){
        close_form();
    });

    get_accountname();
    
    $("#treat").click(function(){
       $("#action").val('traiter');
    });

    $("#emargement").click(function(){
       $("#action").val('emargement');
    });
    
    $("#create_file").click(function(){
       $("#action").val('create_file');
    });
    
    $("#portail").click(function(){

           $("#emargement").prop('disabled', false);
           $("#treat").prop('disabled', true);
           $("#action").val('save');
    });
    $("#virmul").click(function(){

           $("#treat").prop('disabled', false);
           $("#emargement").prop('disabled', true);
           $("#action").val('traiter');
    });
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'create_file')
        {
            save_integration_sftp(data);
        }
    });
    
    $("#close").click(function(){
           close_form();
    });
    
    function save_integration_sftp(data)
    {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/save/integration_sftp';
            //$("#save").prop('disabled', true)
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                        $("#loader1").html('');
                        
                        if(result === "E407")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, le type d\'intégration n\'est pas défini !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(isNaN(result)==true)
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result > 0) 
                        {
                                create_file(result);
                        }
                        else
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }

                    },
                    error:function(error){
                        $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }
    
    function create_file(id)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = $("#mainform").serialize();
        var url = '<?php echo base_url($module.'/taxbulletin'); ?>/data/create_file_xml/'+id;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){

                $("#loader1").html('');
                
                if(result == '200')
                {
                    result_treatment(id)
                }
                else if(isNaN(result)==true)
                {
                    $('#loader1').html('<div class="alert aWarning">La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '405' || result == '406')
                {
                    $('#loader1').html('<div class="alert alert-warning">Alerte: La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '500')
                {
                    $('#loader1').html('<div class="alert alert-danger">Alerte: Le formatage du fichier créé n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '501')
                {
                    $('#loader1').html('<div class="alert alert-danger">Alerte: L\'enregistrement du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error){
                $('#loader1').html('<div class="alert aWarning">La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    

    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '<?php //echo $paiement->Account_16; ?>';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function result_treatment(instructionid)
    {
        var data = $('#mainform').serialize();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/result_with_export_file'); ?>/'+instructionid;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-2").removeClass('bg-green-active');
                $("#step-2").addClass('bg-gray');
                $("#step-3").removeClass('bg-gray');
                $("#step-3").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    

    function view_bulletin(lot) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/_bulletins_by_lot'); ?>/'+lot;
        $.get(url, function (data, status) {
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
    }
    
    
    
    function close_form()
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module.'/taxreports/display/prepayments'); ?>", function (data, status) {
           $("#loader1").html('');
           $("#pager").html(data);
           $("#pager").addClass('content');

           $("#close").removeClass('hidden');
           $("#close_form").addClass('hidden');

        });
    }

</script>
