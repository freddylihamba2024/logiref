<div class="col-md-12 mb-5">
    <div class="col-md-12 no-padding">
        <h1 class="f30 text-blue">Bulletins en lot</h1>
        <p class="page-header">Traitement  des bulletins en lot</p>     
    </div>
    <div id="loader1"></div>
    <div id="pager">
        <div class="row">
            <div class="col-md-12 mt-3 mb-3">
                <div class="row">
                    <div class="col-md-1">
                        <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">1</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left f12 text-black">Lots à traiter<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">2</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left f12 text-black">Lots sélectionnés<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">3</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left f12 text-black">Résultat<br/></div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div id="list">

                <?php if(!empty($bulletins)): ?>
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <?php $chtml->box_body_opening('', false);?>
                        <div class="box-body box-solid no-padding">
                            <div class="col-md-12 no-padding">
                                <div class="box-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped" id="table">
                                            <thead class='bg-gray'>
                                                <tr>
                                                    <th width="5px" class="center">#</th>
                                                    <th width="150px" class="center">Bureau</th>
                                                    <th width="20px" class="center">Designation</th>
                                                    <th width="100px" class="center">Nbre des bulletins</th>
                                                    <th width="150px" class="center">Montant total</th>
                                                    <th width="50px" class="center">Date</th>

                                                    <!-------------------------  Verification of integration mode  ------------------------------>
                                                    <!-------------------------  Web service validation or SFTP    ------------------------------>
                                                    <?php if(isset($options['DGDA']['breakdown-accounting-by-web-service-validation'])){ ?>
                                                        <th width="10px" class="align-middle"  style="text-align:center;"><i class="fa fa-list f20"></i></th>
                                                    <?php }if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){ ?>
                                                        <th width="10px" class="center"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check d-none f16"></i></th>
                                                    <?php } ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1; foreach($bulletins as $row): ?>
                                                <tr>
                                                    <td class="center"width=""><?php echo $i; ?></td>
                                                    <td class="center" width=""><?php echo isset($services['DGDA'][$row->Office_7]) ? $services['DGDA'][$row->Office_7] : ''; ?></td>
                                                    <td class="center" width=""><?php echo $row->Designation_15; ?></td>

                                                    <?php 

                                                        $bl_list = json_decode($row->Bulletins_22, true); 
                                                        $total_bl = isset($bl_list['years']) ? count($bl_list['years']) : 0;
                                                    ?>

                                                    <td class="center" width=""><?php echo $total_bl; ?></td>
                                                    <td class="center" width=""><?php echo $row->Devise_12. ' '.number_format($row->Amount_11,2,","," "); ?></td>
                                                    <td class="center" width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));  ?></td>

                                                    <!-------------------------  Verification of integration mode  ------------------------------>
                                                    <!-------------------------  Web service validation or SFTP    ------------------------------>
                                                    <?php if(isset($options['DGDA']['breakdown-accounting-by-web-service-validation'])){ ?>
                                                        <td style="text-align:center;">
                                                            <a style="cursor: pointer" onclick="edit('<?php echo $row->Id_0; ?>', '<?php echo $row->Status_2; ?>', '<?php echo $row->Lot_14; ?>')"> 
                                                                <i class="fa fa-list text-blue f20"></i>
                                                            </a>
                                                        </td>
                                                    <?php } if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){ ?>
                                                        <td style="text-align:center;">
                                                            <input type="checkbox" class="text-blue" id='' onclick="select_payments()" value="<?php echo $row->Lot_14; ?>" name="batch_reference[]" required/>
                                                        </td>
                                                    <?php } ?>
                                                </tr>
                                                <?php $i++; endforeach;?>
                                            </tbody>

                                        </table>
                                        <div class="col-md-12 no-padding">
                                            <button type="button" id="suivant" disabled="" class="btn btn-primary mt-3 pull-right"><i class="fa fa-arrow-circle-right"></i> Suivant <span id="index"></span>&nbsp;&nbsp;</button>
                                       </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php $chtml->box_body_closing(); ?>
                <?php echo form_close(); ?>
                </div>
                <?php else: ?>
                    <?php $chtml->box_body_opening(); ?> 
                        <section id="cat_list" class="mt-5 mb-5 text-center "><br/><br/><br/><br/><br/><br/>
                           <span class="d-block"><i class="fa fa-flask text-gray mystyle4" ></i></span>
                           <span class="d-block f14 text-black p-2">Aucun bulletin à traiter pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                        </section>
                    <?php $chtml->box_body_closing(); ?> 
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">

    $('#dateDebut').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#dateFin').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#extractform").submit(function(event){
            event.preventDefault();
            var data = $(this).serialize();
            next_step(data);
    });
    
    $("#cancel").click(function() {
        location.reload(true);
    });
    
    $('#checkall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', 'checked');
        $('.check').removeClass("hidden");
        $('#checkall').addClass("d-none");
        $('#uncheckall').removeClass("d-none");

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;
        $("#suivant").prop("disabled",false);


        $("#submit").removeClass("disabled");
        $("#submit").prop("disabled",false);
        $("#index").html('('+ index+')');
    });

    $('#uncheckall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', '');
        $('.check').addClass("hidden");
        $('#checkall').removeClass("d-none");
        $('#uncheckall').addClass("d-none");

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;
        $("#suivant").prop("disabled",true);

        $("#submit").removeClass("btn-primary");
        $("#submit").addClass("btn-success");
        $("#submit").prop("disabled",true);
        $("#index").html('');

    });

    function edit(id, status, lot_id)
    {
        if(status == '1')
        {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin/display/batch'); ?>/' + id;

            $.ajax({
                type        : 'GET',
                url         : url,
                dataType    : 'html',
                encode      : true,
                success: function(reponse)
                {
                    $("#loader1").html('');
                    $('#list').html(reponse);

                },
                error:function(error)
                {
                    $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
        else if(status == '2')
        {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin/display/batch_confirmed_continuous'); ?>/' + lot_id;

            $.ajax({
                type        : 'GET',
                url         : url,
                dataType    : 'html',
                encode      : true,
                success: function(reponse)
                {
                    $("#loader1").html('');
                    $('#list').html(reponse);
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');

                },
                error:function(error)
                {
                    $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }

    $("#suivant").click(function() {

        var data = $('#mainform').serialize();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/__batch'); ?>';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });   
    });
    
    function action(which) 
    {
        $("#alert").html('');
  
        $("#loader1").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        $.get("<?php echo base_url($module . '/taxbulletin/display/'); ?>/" +which, function(data, status) {
            $("#loader1").html('');
            $("#list").html(data);
        });
    }
    
    function select_payments()
    {
            var $checedInputs = $('#table').find("input:checked");
            var index = $checedInputs.length;

            if(index > 0)
            {
                $("#suivant").prop("disabled",false);
                $("#index").html('('+ index+')');
            }
            else if(index <= 0)
            {
                $('#checkall').removeClass("hidden");
                $('#uncheckall').addClass("hidden");

                $("#suivant").prop("disabled",true);
                $("#index").html('');
            }
    }
    

</script>