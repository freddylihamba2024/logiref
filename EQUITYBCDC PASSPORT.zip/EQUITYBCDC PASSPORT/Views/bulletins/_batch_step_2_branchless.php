<?php 

if($batch->Lock_33 == $userid)
{
        $view = "";
        $disabled_treat = 'disabled="disabled"';
        $disabled_confirm = '';
}
else
{
        $view = "view";
        $disabled_treat = '';
        $disabled_confirm = 'disabled="disabled"';
}

if($compte_guichet_unique == '00000000000000000000000')
{
        $disabled = 'disabled';
        $error_message = '<div class="alert aWarning text-white">Le compte guichet unique n\'est pas paramétré, veuillez contacter votre administrateur à cet effet.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
}
else
{
        $disabled = '';
        $error_message = '';
}
    
?>

<div class="col-md-12">
    <div id="loader"><?php echo $error_message; ?></div>
    <?php $chtml->box_body_opening('', true);?>
    <?php  echo form_open('', array('id' => 'form_batch', 'class' => 'innovate '.$view)); ?>
        <div class="col-md-12">
            <div class="box-body">
                <div class="col-md-12 p-0">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Bureau</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($services['DGDA'][$office]) ?$services['DGDA'][$office] : ""; ?>
                                    <input type="hidden" name="Office" value ="<?php echo $office; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;clarant</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $agent; ?>
                                    <input type="hidden" name="Agent" value ="<?php echo $agent; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Num&eacute;ro imp&ocirc;t</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $nif; ?>
                                    <input type="hidden" name="Nif" value ="<?php echo $nif; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;signation</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $designation; ?>
                                    <input type="hidden" name="designation" value ="<?php echo $designation; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Intitul&eacute; du compte</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="cCompte"><?php echo $account_name; ?></span>
                                    <input type="hidden" value="<?php echo $account_name; ?>" id="account_name" name="account_name"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte &agrave; d&eacute;biter</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $account ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 bLeft">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Montant total du lot</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $total; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Commission totale du lot</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b>  <?php echo number_format($commission,2,","," ")  ?>  CDF
                                   <input type="hidden" name="Commission" value ="<?php echo $commission; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">TVA</label>
                                </div>
                                <div class="col-md-8">
                                    <?php $tva = $commission * 0.16; ?>
                                   <b>:</b> <?php echo number_format($tva, 2, ",", " ") ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Total &agrave; payer</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo number_format($total_to_paid, 2, ",", " ") ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Taux appliqu&eacute;</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b>  <?php echo number_format($taux, 2, ",", " "); ?>
                                    <input type="hidden" name="taux" value ="<?php echo $taux; ?>"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte guichet unique</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span class="<?php if($disabled == 'disabled') echo 'text-red' ?>"><?php echo $compte_guichet_unique ?></span>
                                    <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
                <div id="footpage" class="box-footer clearfix"></div>
            </div>
            <div class="box-body box-solid no-padding">
                <div class="box-body">
                    <input type="hidden" name="mode" value ="7"/>
                    <input type="hidden" name="Bank" value ="<?php echo $bank; ?>"/>
                    <input type="hidden" name="refOp" value ="<?php echo $refOp; ?>"/>
                    <input type="hidden" name="devise_commision" value ="<?php echo 'CDF'; ?>"/>
                    <input type="hidden" name="cdevise" value ="<?php echo $cdevise; ?>"/>
                   
                    <div class="table-responsive">
                        <table class="table no-margin table-striped table-bordered">
                            <thead class='bg-blue'>
                                <tr>
                                    <th width="10px">#</th>
                                    <th width="80px">Ann&eacute;e</th>
                                    <th width="80px">Bulletin</th>
                                    <th width="50px">Devise</th>
                                    <th width="200px">Montant</th>
                                    <th>Retour de SYDONIA</th>
                                    <th align="center" width="90px">V&eacute;rification</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1;  foreach($bulletins as $bl){ ?>
                                    <tr id="line<?php echo $i?>">
                                        <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                        <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year;?>" name="years[<?php echo $i; ?>]"   class="form-control itemgrid" required="required" readonly="" /></td>
                                        <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->number; ?>"  name="serials[<?php echo $i; ?>]"   class="form-control itemgrid" required="required" readonly="" /></td>
                                        <td align="center"><span class="form-control">CDF</span></td>
                                        <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount,2,","," ");?>" name="amounts[<?php echo $i;?>]"   class="form-control itemgrid" required="required" readonly="" /></td>
                                        <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Bulletin non v&eacute;rifi&eacute;</span></td>
                                        <td align="center" id='btn<?php echo $i; ?>'>
                                           <span class="fa fa-fw text-gray fa-question f20"> </span>
                                        </td>
                                    </tr>
                                <?php $i++;  } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button type="button" id="open_treatment" class="<?php if($disabled_treat !="") echo "btn btn-default"; else echo "btn btn-success"; ?>" <?php echo $disabled_treat; ?> ><i class="fa fa-archive " ></i>&nbsp;&nbsp;Ouvrir pour traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button id="envoyer" type="submit" style="margin-left:0px;" name="submit" class="btn btn-success" <?php echo $disabled_confirm; ?> ><i class="fa fa-check"></i> &nbsp;Confirmer dans sydonia&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="recover" class="btn btn-primary d-none" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;esayer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <input type="hidden" name="logirefid" value="<?php echo isset($logirefid) ? $logirefid : "" ?>" id="logirefid">
                    <input type="hidden" name="batchid" value="<?php echo isset($batch->Id_0) ? $batch->Id_0 : "" ?>" id="batchid">
                    <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                    <input type="hidden" name="transaction_id" value="" id="transaction_id">
                    <input type="hidden" name="customercode" value="<?php echo isset($customercode) ? $customercode : "" ?>" id="customercode">
                    <input type="hidden" name="maker" value="<?php echo isset($maker) ? $maker : "" ?>" id="maker">
                    <input type="hidden" name="error_code" value="" id="error_code">
                    <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Annuler &nbsp;</button>
                </div>
            </div>
        </div>
        <?php echo form_close(); ?> 
    <?php $chtml->box_body_closing(); ?> 
</div>

<div class="col-md-12">
   
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$("#form_batch").submit(function(event){
    event.preventDefault();
    var data = $(this).serialize();
    next_step(data);
});

$("#open_treatment").click(function(){
        open_treatment();
});


$("#buttonCloseModal").click(function(){
        location.reload();
});

function next_step(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var button = $('#envoyer').html();
        
        $('#envoyer').html('<span>Chargement...</span>');
        
        var url = '<?php echo base_url($module.'/taxbulletin/display/batch_confirmation_branchless'); ?>';
        $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                   
                        $('#envoyer').prop("disabled", false);
                        $('#envoyer').html(button);
                        $('#loader').html('');
                       
                        if(result === "E34")
                        {
                                batch_recover(data);
                        }
                        else if(result === "E22")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E21")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E18")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E4")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E11")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E13")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-danger text-white">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E002")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E000")
                        {
                               scrollUP();
                               $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                batch_recover(data);
                        }
                        else if(result === "E444")
                        {
                                batch_recover(data);
                        }
                        else if(result === "E411")
                        {
                                batch_recover(data);
                        }
                        else if(result === "E501")
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#envoyer').prop("disabled", true);
                                $('#extourne').removeClass('hidden');
                                $('#reserve').addClass('hidden');
                        }
                        else 
                        {
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $("#pager").html(result);
                        }
               },
               error:function(error){
                   scrollUP();
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                    $('#loader').html('<div class="alert alert-warning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
               }
       });
}

function batch_recover(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var url = '<?php echo base_url($module.'/taxbulletin/display/batch_recover_branchless'); ?>';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result)
                    {      
                            $('#loader').html(result);
                            if(result === "E000")
                            {
                                    scrollUP();
                                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E404")
                            {
                                    scrollUP();
                                    $('#recover').prop("disabled", false);
                                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E002" || result === "E022")
                            {
                                    scrollUP();
                                    $('#loader').html('<div class="alert alert-info text-white">Ces bulletins ont d&eacute;j&agrave; &eacute;t&eacute; recup&eacute;r&eacute;s. consultez le menu paiements non valid&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $('#envoyer').prop("disabled", false);
                                    $("#step-2").removeClass('bg-green-active');
                                    $("#step-2").addClass('bg-gray');
                                    $("#step-3").removeClass('bg-gray');
                                    $("#step-3").addClass('bg-green-active');
                                    $("#pager").html(result);
                            }
                    },
                    error:function(error)
                    {
                            scrollUP();
                            $('#recover').prop("disabled", false);
                            $('#loader').html('<div class="alert alert-warning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
}

function open_treatment(data)
{
    var bacth_id = '<?php echo isset($batch->Id_0) ? $batch->Id_0 : "" ?>'
    
    var url ="<?php echo base_url($module.'/taxbulletin/save/lock_batch_paiement'); ?>/" + bacth_id;
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#loader").html(data);
        $('#extractform').removeClass('view');
        $('#open_treatment').removeClass('btn-success');
        $('#open_treatment').prop('disabled', true);
        $('#envoyer').prop('disabled', false);
    });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>



