<?php

    $codeBank = isset($_SESSION['Guichet_code']) ? substr($_SESSION['Guichet_code'], 1)  : '51';

    if (isset($_SESSION['Bank_rates'])) :
        $taux = json_decode($_SESSION['Bank_rates'], true);
    else :
        $taux['Dollar_4']  = 00;
        $taux['Euro_5']  = 00;
        $taux['Rand_6']  = 00;
    endif;

?>

<div class="row" id="pager">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if ($step == 0) {echo 'bg-green-active';} else {echo 'bg-light';} ?> f14 center pull-right">1</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left">Saisie</div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if ($step == 1) {echo 'bg-primary';} else {echo 'bg-light';} ?> f14 center pull-right">2</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left">Traitement</div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if ($step == 2) {echo 'bg-primary';} else {echo 'bg-light';} ?> f14 center pull-right">3</div>
            </div>
            <div class="col-md-3 pt-2">
                <div class="pull-left">Enregistrement</div>
            </div>
        </div>

        <div id="panel">
            <?php $chtml->box_body_opening('', false);  ?>
            <?php echo form_open_multipart('', array('id' => 'form', 'class' => 'innovate')); ?>
            <div class="box-body">
                <div class="row margin">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                   <label for="office">Bureau</label>
                                    <?php echo form_dropdown('Office', $services['DGDA'], '', 'class="form-control select2" id="office" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="agent">Num&eacute;ro du d&eacute;clarant</label>
                                    <?php echo form_input('Agent', '0000', 'class="form-control" id="agent" required = "required"'); ?>
                                </div>
                                <div class="form-group">
                                    <label for="agent">Banque</label>
                                    <?php echo form_input('Bank', $codeBank, 'class="form-control" id="bank" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Nif">Num&eacute;ro d'imp&ocirc;t</label>
                                    <?php echo form_input('Nif', '', 'class="form-control" id="Nif" placeholder="A0700395N" required = "required"'); ?>
                                </div>
                                <div class="form-group">
                                    <div class="" data-provides="fileinput">
                                        <label for="Nif">Lot des bulletins</label>
                                        <input type="file" name="attachement"  class="input-document form-control"  />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 bLeft">
                        <div class="row">
                            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mode">Mode de paiement</label>
                                        <?php echo form_dropdown('mode', $modes, '', 'class="form-control" id="mode" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="customerNumber" class=""><span  id="labelNumber">N° du client</span></label>
                                        <?php echo form_input('', set_value('Customernumber', ''), 'class="form-control" id="customerNumber" maxlength="7" placeholder="123456" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="Taux">Taux</label>
                                        <?php echo form_input('Taux', set_value('Taux', $taux['Dollar_4']), 'class="form-control" '); ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label for="mode">Mode de paiement</label>
                                        <?php echo form_dropdown('mode', $modes, '', 'class="form-control" id="mode" required = "required"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="Taux">Taux</label>
                                        <?php echo form_input('Taux', set_value('Taux', $taux['Dollar_4']), 'class="form-control" '); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="account" id="accountname">Compte &agrave; d&eacute;biter</label>
                                    <?php echo form_input('account', set_value('', ''), 'class="form-control" id="account" required = "required" '); ?>
                                    <input type="hidden" value="" name="account_name" id="account_name"  />
                                    <input type="hidden" value="" name="account_type" id="account_type"  />
                                    <input type="hidden" value="" name="account_balance" id="account_balance" />
                                    <input type="hidden" name="Infos[accountType]" value="" id="accounttype">
                                    <input type="hidden" name="branch_code" value="" id="branch_code">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cdevise">Devise</label>
                                    <?php echo form_dropdown('cdevise', $devises, 'CDF', 'class="form-control" id="cdevise" required = "required"'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ref" id="ref">R&eacute;f&eacute;rence de l'OP / EV</label>
                                    <?php echo form_input('ref', set_value('', ''), 'class="form-control" id="ref" required = "required" '); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="designation" >D&eacute;signation</label>
                                    <?php echo form_input('designation', set_value('', ''), 'class="form-control" id="designation" required = "required" '); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div class="col-md-12">
                   <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-arrow-circle-right"></i>&nbsp;&nbsp;Continuer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <!--  <button type="button" id="treat" class="btn btn-primary"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;-->
                    <a id="cancel" class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                </div>
            </div>

            <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>
</div>
<script type="text/javascript">

    $(".select2").select2();
    $("#form").submit(function(event) {
        event.preventDefault();
        var data = new FormData(this);
        next_step(data);
    });

    var bank = '<?php echo $bank; ?>';

    $("#buttonCloseModal").click(function() {
        location.reload(true);
    });

    $('#mode').change(function() {
        $("#loader-sub-menu").html('');
    
        var chtml = '<b>Compte du client &agrave; d&eacute;biter</b>';
        var mode = $('#mode option:selected').val();

        if(mode == '5')
        {
            get_accountinternal();
        }
    });

    $("#account").change(function() {
        $("#loader-sub-menu").html('');
        
        var mode = $('#mode option:selected').val();

        if(mode == '5')
        {
            get_accountinternal();
        }
        else
        {
            get_accountname();
        }
    });

    $("#ref").change(function() {

        var refOp = $("#ref").val();
        refOp = Number(refOp.replace(/[^\d]/g, ""));
        var btn = 'R&eacute;f&eacute;rence de l&apos;OP / EV';
        if (refOp == "") {
            $("#refLabel").html('Saisissez la r&eacute;f&eacute;rence de l&apos;OP ou le num&eacute;ro EV');
            $("#refLabel").css('color', 'red');
            $("#ref").val('');
        } else {
            $("#refLabel").html(btn);
            $("#refLabel").css('color', '#333');
        }

    });

    $("#cdevise").change(function() {

        $("#loader-sub-menu").html('');

        var mode = $('#mode option:selected').val();

        if(mode == '5')
        {
            '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
                get_accountinternal();
            '<?php endif; ?>';
        }
        else
        {
            get_accountname();
        }
    });

    $(".input-document").change(function() {

        var f = (this).files[0];
        var name = (this).files[0].name;
        var ext = (this).files[0].type;
        console.log(ext);
        if (f.size > 1388608 || f.fileSize > 1388608) {
            //show an alert to the user
            $(".fileinput-filename").html("<span class='text-danger'><i class='fa fa-times'></i> La taille du fichier doit &ecirc;tre inf&eacute;rieur &agrave; 1 m&eacute;ga </span>");

            //reset file upload control
            this.value = null;
        } else {
            if (ext == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || ext == "vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
                $(".fileinput-filename").html("<span class='text-success'>" + name + " <i class='glyphicon glyphicon-ok'></i></span>");
            } else {
                $(".fileinput-filename").html("<span class='text-danger'><i class='fa fa-times'></i> Format du fichier invalide, format autoris&eacute;: pdf, jpeg ou png </span>");
                this.value = null;
            }
        }

    });

    $('#Nif').on('blur', function()
    {
        var nifValue = $(this).val();
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url('branch/taxbulletin/data/get_nif'); ?>';

        if (nifValue)
        {
            $.ajax({
                url: url,
                type: 'POST',
                data: { nif: nifValue, csrf_name: csrf},
                success: function(response) {
                    $('#designation').val(response);
                },
                error: function() {
                    $('#designation').val('');
                }
            });
        }
        else
        {
            $('#designation').val('');
        }
    });

    '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
        $("#customerNumber").change(function(){
            var customer_number = $(this).val();

            if (customer_number.length <= '7')
            {
                get_customeraccounts()
            }
        });
    '<?php endif; ?>';

    $(document).on('change', '#account', function () {

        $("#accountname").html('<img align="middle" style="height:15px;margin-left:-13px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $(this).find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#accountname').html('');
            $('#account_name, #account_currency, #account_balance, #account_type').val('');
            $('#compteDevise').val('').trigger('change');
            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        // Ajoute un délai avant d'afficher les infos
        setTimeout(function () {
            $('#accountname').removeClass().addClass('text-green').html(name);
            $('#account_name').val(name);
            $('#account_currency').val(currency);
            $('#account_balance').val(balance);
            $('#account_type').val(type);

            if (currency) {
                $('#cdevise').val(currency);
                $('#cdevise').prop('disabled', true);

                // Supprime tout champ hidden existant pour éviter les doublons
                $('input[name="cdevise"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'cdevise',
                    value: currency
                }).appendTo('form');
            }
        }, 2500);
    });

    function next_step(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //$('#sub').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>Chargement...</span>');
        var url = '<?php echo base_url('branch/taxbulletin/display/batch_step_2'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            contentType: false,
            cache: false,
            processData: false,
            success: function(result) {
                $("#loader-sub-menu").html('');
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
                $("#loader-sub-menu").html('');
                if (result === "E003") {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E34") {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E22") {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E11") {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E002") {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E003") {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E200") {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Aucun fichier trouv&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E202") {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le format du fichier n&apos;est pas valide!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {

                    //var resultat = JSON.parse(result);
                    var results = JSON.parse(result);

                    if (results.response === "E000") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E404") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E405") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E406") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: serveur SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E003") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: Fatal error...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E18") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "E15") {
                            scrollUP();
                            $("#loader-sub-menu").html('<div class="alert aWarning">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#reserve").prop('disabled', true);
                    } else if (results.response === "OK") {

                            // Teste si la balance est suffisante et que tous les bulletins sont valides
                            if (results.balance === "OK" && results.error === false) {

                                    $("#step-1").removeClass('bg-green-active');
                                    $("#step-1").addClass('bg-gray');
                                    $("#step-2").removeClass('bg-gray');
                                    $("#step-2").addClass('bg-green-active');
                                    $("#panel").html(results.page);

                                    scrollUP();

                            } else if ((results.balance === "OK" && results.error === true) || results.error === true) {

                                    $("#panel").html(results.page);

                            } else if (results.balance === "KO") {

                                    scrollUP();
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#sub").prop('disabled', true);

                            } else if (results.balance == "E411") {

                                    scrollUP();
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#sub").prop('disabled', true);
                            }
                            else
                            {
                                    $("#sub").prop('disabled', true);
                            }
                    } else if (results.response === "batchvalide") {

                            // Teste si la balance est suffisante et que tous les bulletins sont valides
                            if (results.balance === "OK" && results.error === false) {

                                    $("#step-1").removeClass('bg-green-active');
                                    $("#step-1").addClass('bg-gray');
                                    $("#step-2").removeClass('bg-gray');
                                    $("#step-2").addClass('bg-green-active');
                                    $("#panel").html(results.page);

                            } else if (results.balance === "KO") {
                                    scrollUP();
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    //$("#sub").prop('disabled', true);
                            } else if (results.balance === "E411") {
                                    scrollUP();
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white" >Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    //$("#sub").prop('disabled', true);
                            }
                            else
                            {
                                    $("#sub").prop('disabled', true);
                            }
                    }
                }
            },
            error: function(error) {
                $("#loader-sub-menu").html('<div class="alert aDanger text-white" >Le traitement de ce lot de bulletin a pris beaucoup de temps, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
            }
        });
    }

    function get_accountname() 
    {

        var core_banking = '<?php echo $core_banking; ?>';

        var compte = $('#account').val();
        var devise = $('#cdevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" style="height:15px;margin-left:-13px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {

                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);

                            // Vérifier si branch_code existe avant de l'utiliser
                            if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                                $("#branch_code").val(reponse.branch_code);
                            }
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function get_accountinternal() 
    {

        var mode = $('#modeId option:selected').val();
        var devise = 'CDF';
        var regie = 'DGDA';
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountinternal'); ?>';

        if (devise !== '' && mode !== '') {
            $("#accountname").html('<img  align="middle" style="height:15px;margin-left:-13px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    devise: devise,
                    regie: regie,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    $("#loader-sub-menu").html('');

                    const input_html = '<input type="text" name="account" value="" class="form-control" placeholder="Compte bancaire du client" required="required" id="account">';
                    $('#account').replaceWith(input_html);

                    if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le compte n&apos;existe pas');
                    }
                    else
                    {
                            $("#customerNumber").prop("required", false);

                            if (reponse.account ===  '000000000000000000000000')
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-green');
                                    $("#accountname").addClass('text-yellow');
                                    $("#accountname").html("Le compte interne n’a pas été paramétré pour cette agence");
                                    
                                    $("#account").val(reponse.account).css("color", "red");

                                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le compte interne n’a pas été paramétré pour cette agence<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-yellow');
                                    $("#accountname").addClass('text-green');
                                    $("#accountname").html("Compte interne");
                                    $("#account_name").val("Compte interne");
                                    $("#accounttype").val("MAD");
                                    
                                    $("#account_balance").val("no-verification-balance");
                                    
                                    $("#account").val(reponse.account);
                                    $("#cdevise").val(reponse.currency);
                            }
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_customeraccounts()
    {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" style="height:15px;margin-left:-13px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#accountname").html(loader_img);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200")
                {
                    const mapped_currency = {
                        '976': 'CDF',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'account',
                        name: 'account',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#account').prop('tagName') === 'SELECT') {
                        $('#account').replaceWith(select);
                    } else {
                        $('#account').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $('#accountname').removeClass().addClass('text-black').html('Compte &agrave; d&eacute;biter');

                } else{
                    const input_html = '<input type="text" name="account" value="" class="form-control" placeholder="Compte bancaire du client" required="required" id="account">';
        
                    $('#account').replaceWith(input_html);

                    $('#accountname').removeClass().addClass('text-black').html('Compte &agrave; d&eacute;biter');

                    $("#labelNumber").html('N° du client');

                    if (reponse.code === '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code === '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code === '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader-sub-menu").offset().top
        }, 20);
    }

</script>