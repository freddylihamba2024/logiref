<div id="pager">
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'view')); ?>
    <div class="col-md-12">
        <div id="loader1"><?php echo ""; ?></div>
        
        <style>label {min-width: 150px !important; padding-top: 5px !important; }</style>
        <?php $chtml->box_body_opening('', true);?>
        <div class="col-md-12">
            <div class="box-body">
                <input type="hidden" name="designation" value="<?php echo $designation; ?>" />
                <input type="hidden" name="account_name" value="<?php echo $account_name; ?>" />
                <input type="hidden" name="account" value="<?php echo $account ?>" />
                <input type="hidden" name="bank" value="<?php echo $bank; ?>" />
                <input type="hidden" name="ref" value="<?php echo $refOp; ?>" />
                <input type="hidden" name="devise_commision" value="<?php echo 'CDF'; ?>" />
                <input type="hidden" name="cdevise" value="<?php echo $cdevise; ?>" />
                <input type="hidden" name="mode" value="<?php echo $mode; ?>" />
                <input type="hidden" value='<?php echo htmlspecialchars(json_encode($bulletins), ENT_QUOTES, 'UTF-8'); ?>' name="bulletins"/>
                <input type="hidden" value='<?php echo json_encode($response_bls); ?>' name="treatment_result"/>

                <div class="col-md-12">
                    <h2 class="f20">Bulletins en situation délicate</h2>
                    <h5 class="page-header"><span class="text-gray">les bulletins nécessitant une révision</span></h5>
                    <br/>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="office" class="form-label">Bureau</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                                <?php echo form_dropdown('office', $services['DGDA'], $office, 'required class="form-control select2"'); ?>
                            </div>
                        </div>
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="agent" class="form-label">Declarant</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                               <?php echo form_input('agent', set_value('Agent', $agent), ' class="form-control" required '); ?>
                            </div>
                        </div>
                        
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="Nif" class="form-label">Num&eacute;ro imp&ocirc;t</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                               <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                            </div>
                        </div>
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="taux" class="form-label">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                                <?php echo form_input('Taux', set_value('Taux', $taux), 'class="form-control"'); ?>
                                <input type="hidden" name="Taux" value="<?php echo $taux; ?>" />
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="total_amount" class="form-label">Montant total du lot</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                                <?php echo form_input('total_amount', set_value('total_amount', number_format(floatval($total),2,","," ")), 'id="total_amount" required class="form-control"'); ?>
                                
                            </div>
                        </div>
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="coms" class="form-label">Commission du lot</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                               <?php echo form_input('Commission', set_value('Commission', number_format(floatval($commission),2,","," ")), 'id="coms" required class="form-control"'); ?>
                                
                            </div>
                        </div>
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="tva" class="form-label">TVA</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                                <?php $tva = floatval($commission) * 0.16; ?>
                                <?php echo form_input('tva', set_value('tva', number_format(floatval($tva),2,","," ")), 'id="tva" required class="form-control"'); ?>
                                
                            </div>
                        </div>
                        <div class="row align-items-center input-group  no-padding">
                            <div class="col-md-4">
                                <label for="total_topaid" class="form-label">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-1 text-center">
                                <b>:</b>
                            </div>
                            <div class="col-md-7">
                                <?php echo form_input('total_topaid', set_value('total_topaid', $total_to_paid), 'id="total_topaid" class="form-control"'); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
            <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead class='bg-gray'>
                        <tr>
                            <th width="10px" class="center">#</th>
                            <th width="80px" class="center">Ann&eacute;e</th>
                            <th width="80px" class="center">Bulletin</th>
                            <th width="50px" class="center">Devise</th>
                            <th width="180px" class="center">Montant</th>
                            <th width="" class="center">Retour de SYDONIA</th>
                            <th width="" class="center" width="90px">V&eacute;rification</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($response_bls as $bl):
                            
                            if($bl['code'] != 'OK'){
                        ?>
                        <tr id="line<?php echo $i ?>">
                            <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                            <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl['year']; ?>" name="years[<?php echo $i; ?>]" class="form-control " required="required" /></td>
                            <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl['number']; ?>" name="serials[<?php echo $i; ?>]" class="form-control " required="required" /></td>
                            <td class="center"><span class="form-control">CDF</span></td>
                            <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl['amount'], 2, ",", " "); ?>" name="amounts[<?php echo $i; ?>]" class="form-control" required="required" /></td>
                            <td class="center">
                                <?php if($bl['code']== "E13"): ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Server execption!</span>
                                <?php elseif($bl['code'] == "E15") : ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Num&eacute;ro imp&ocirc;t non r&eacute;connu!</span>
                                <?php elseif($bl['code'] == "E34") : ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-red bold'>Bulletin d&eacute;j&agrave; pay&eacute;!</span>
                                <?php elseif($bl['code'] == "E22") : ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-red bold'>Bulletin non reconnu!</span>
                                <?php elseif($bl['code'] == "E11") : ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Montant du bulletin est incorrect!</span>
                                <?php else : ?>
                                    <span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>L'une des informations de ce bulletin pas correcte !</span>
                                <?php endif; ?>
                            </td>
                            <td class="center" id='btn<?php echo $i; ?>'>
                                <?php if($bl['code']== "E13" || $bl['code']== "E15" || $bl['code']== "E34" || $bl['code']== "E22" || $bl['code']== "E11"): ?>
                                    <span class="fa fa-fw text-yellow fa-warning f20"> </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php  
                        
                            }
                        $i++;endforeach; 
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-12">
            <div class="box-footer clearfix">
                <button type="submit" id="treat" class="btn btn-primary"><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;esayer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?> 
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">

    
    $(document).on('submit', '#mainform', function(event) {
        event.preventDefault();
        var data = $("#mainform").serialize();
        batch_traitement(data);
    });
    
    $("#buttonCloseModal").click(function() {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
            $("#loader1").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');
            $("#close").removeClass('hidden');
            $("#cancel").addClass('hidden');
            $("#col").removeClass('col-md-2');
            $("#col").addClass('col-md-1');
            $("#content").removeClass('col-md-8');
            $("#content").addClass('col-md-10');
            $("#close").removeClass('col-md-2');
            $("#close").addClass('col-md-1');
        });
    });
    
    
    function batch_traitement(data) {

        //$('#treat').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#treat').html();
        $('#treat').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        
        var url = '<?php echo base_url('branch/taxbulletin/display/batch_step_2_process'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $('#treat').prop("disabled", false);
                $('#buttonCloseModal').prop("disabled", false);
                $('#treat').html(button);
                $('#loader-sub-menu').html('');
                $('#pager').html(result);
            },
            error: function(error) {
                
                $('#treat').html(button);
                $('#loader-sub-menu').html('<div class="alert alert-warning">La vérification a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }


</script>