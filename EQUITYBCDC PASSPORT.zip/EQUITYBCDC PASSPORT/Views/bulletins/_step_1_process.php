<?php

$bank = substr($bank, 1);

if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(!isset($balance))
{
        $balance = "";
}

if(!isset($balance))
{
        $balance = "";
}

$date = json_decode($bulletin->Paiementinfo_44);

$date = isset($date->DateL) ? $date->DateL : "";

$lien_details = json_decode($bulletin->Reservation_43, true);

if(($integrations[0]->Status_2 ?? "") != 1 || $_SESSION['Logiref_role']==4)
{
        $button_treat = "disabled";
}
else
{
        $button_treat = "";
}

?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="f30 text-black">Bulletin de liquidation</h1>
                    <p class="page-header"><span class="f15 text-black">Traitement des bulletins de liquidation</span></p>     
                </div>
            </div>
            <div class="row">
                <div class="col-md-1">
                    <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left f12 text-black">V&eacute;rification du Bulletin<br/></div>
                </div>
                <div class="col-md-1">
                    <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left f12 text-black">Confirmation du paiement<br/></div>
                </div>
                <div class="col-md-1">
                    <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left f12 text-black">Validation<br/></div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12"><br/>
                    <?php if(($integrations[0]->Status_2 ?? "") == 5 && $_SESSION['Logiref_role']==3): ?>
                        <div id="loader2"><div class="alert alert-danger text-white"> Il y avait eu un time out pendant la validation de ce paiement, veuillez vous connecter dans Finacle pour v&eacute;rifier si ce paiement est bien comptabilis&eacute; ou pas. Si le paiement est d&eacute;j&agrave; comptabilis&eacute;, cochez la case [proc&eacute;c&eacute;der &agrave; l'&eacute;margement] sinon cochez la case [valider &agrave; nouveau].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
                    <?php endif; ?>

                    <?php if(($bulletin->Status_2 ?? "") == 1 && $_SESSION['Logiref_role']!=3  && $bank=="Equitybcdc"): ?>
                        <div id="loader2"><div class="alert alert-info text-black">Le paiement est en attente de validation, veuillez contacter le validateur pour la suite du processus.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
                    <?php endif; ?>

                    <div id="loader1"></div>

                    <div id="alert"></div>
                </div>    
            </div>    
            <div class="row">
                <div class="col-md-12" id="success_message"></div>
            </div>
            <div id="pager">
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <?php $chtml->box_body_opening('', true);?>
                <div class="row margin">
                    <div class="col-md-8 bRight">
                        <input type="hidden" name="Account" value="<?php echo $accountid; ?>">
                        <input type="hidden" name="User" value="<?php echo $userid; ?>">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label for="Service_16">Bureau (ou service)</label> 
                                            <?php echo form_dropdown('Office',$services['DGDA'],isset($bulletin->Office_6) ? $bulletin->Office_6 : "", 'class="form-control chosen-select" id="Service_16" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="year">Ann&eacute;e</label> 
                                            <?php echo form_input('Year',isset($bulletin->Year_5 ) ? $bulletin->Year_5 : "2021", 'class="form-control" id="year" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="year">Banque</label> 
                                            <?php echo form_input('Bank',isset($bulletin->Bank_11) ? $bulletin->Bank_11 : "11", 'class="form-control bg-gray" id="year" required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                            <?php echo form_input('Nif',isset($bulletin->Nif_9) ? $bulletin->Nif_9 : "" , 'class="form-control" id="company" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                           <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                            <?php echo form_input('Agent',isset($bulletin->Agent_10) ? $bulletin->Agent_10 : "0000", 'class="form-control" id="declarant" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="assessment_serial">S&eacute;rie</label>
                                            <?php echo form_input('Series',isset($bulletin->Serie_7) ? $bulletin->Serie_7: "L", 'class="form-control" id="assessment_serial" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="assessment_number">Num&eacute;ro du bulletin</label>
                                            <?php echo form_input('Number',isset($bulletin->Number_8) ? $bulletin->Number_8: "", 'class="form-control" id="assessment_number" required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="Montant_11">Montant &agrave; payer</label>
                                            <?php echo form_input('Amount',isset($bulletin->Amount_12) ? $bulletin->Amount_12 : "", 'class="form-control" id="amount" required = "required"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="devise">Devise</label>
                                            <?php echo form_dropdown('devise', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27 : "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                            <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="Mode">Mode</label> 
                                            <?php echo form_dropdown('Mode', $modes, isset($bulletin->Mode_30) ? $bulletin->Mode_30 : "", 'class="form-control" required="required" id="modeId"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="DateL">Date liquidation</label>
                                            <?php echo form_input('DateL',set_value('Datevaleur_31', date('Y-m-d', strtotime($date))), 'class="form-control" id="datepicker1" required = "required"'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label for="Account" id="accountname" class="f12 text-black"><b>Compte du client &agrave; d&eacute;biter</b></label>
                                            <?php echo form_input('bank_account',isset($bulletin->Account_28) ? $bulletin->Account_28 : "", 'class="form-control" id="bank_account" placeholder="Compte bancaire du client" required="required" '); ?>
                                            <input type="hidden" name="account_name" value="" id="account_name">
                                            <input type="hidden" name="account_currency" value="" id="account_currency">
                                            <input type="hidden" name="account_balance" value="" id="account_balance">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="Devise_account" class="f12 text-black"><b>Devise de ce compte</b></label>
                                            <?php echo form_dropdown('Devise_account', $devises, isset($bulletin->Devise_29) ? $bulletin->Devise_29 : "", 'class="form-control" id="account_devise" required="required"'); ?>
                                        </div>
                                    </div>
                                </div>
                               
                                <div class="row">
                                    <div class="col-md-12 no-padding <?php if(($integrations[0]->Status_2 ?? "") !="5" || $_SESSION['Logiref_role']!=3) echo "d-none"; ?>" id="approbation">
                                            <br/>
                                            <div class="col-md-5">
                                                <label class="">
                                                    <input type="checkbox" id="approbation_debit"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Valider la transaction &agrave; nouveau</span>
                                                </label>
                                            </div>
                                            <div class="col-md-7">
                                                <label class="">
                                                    <input type="checkbox" id="approbation_emarge"  name="approbation" value="<?= 0 ?>"> <span style="color:#069">Proc&eacute;c&eacute;der à l'&eacute;margement</span>
                                                </label>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            </br></br></br></br>
                            <div class="box-footer clearfix">
                                <div class="col-md-12 no-padding">

                                    <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                                        <?php if(in_array('3', $integration_status) || in_array('4', $integration_status) || in_array('5', $integration_status)): ?>
                                            <button type="submit" id="regul" class="btn btn-primary <?php if($_SESSION['Logiref_role']==4) echo "d-none" ?>" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Validerk&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                        <?php else : ?>
                                            <button type="submit" id="releaseLien" disabled class="btn btn-primary <?php if(($lien_details['lien_id'] ?? '') =="") echo "d-none" ?> <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?>" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==4) echo "Enregistrer"; else echo "Valider"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                        <?php endif; ?>

                                        <button type="submit" id="debit" disabled class="btn btn-primary <?php if(($lien_details['lien_id'] ?? '') !="") echo "d-none" ?>" <?php if(($integrations[0]->Status_2) && $integrations[0]->Status_2 == 5 || $integrations[0]->Status_2 == 2) echo "disabled" ?> <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==4) echo "Enregistrer"; else echo "Valider"; ?>&nbsp;&nbsp;</button>&nbsp;
                                        <button type="submit" id="verify" class="btn btn-danger d-none"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;Régulariser&nbsp;&nbsp;</button>&nbsp;
                                        <button type="submit" id="treat" class="btn btn-primary" <?php echo $button_treat ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;

                                        <?php if($role != '4') :?>
                                            <button type="submit" id="confirm" <?php if(in_array('1', $integration_status) || in_array('3', $integration_status) || in_array('4', $integration_status) || in_array('5', $integration_status)) echo "disabled"; else echo ''; ?> class="btn btn-success" ><i class="fa fa-save"></i>&nbsp;&nbsp;Emargement&nbsp;&nbsp;</button>&nbsp;
                                        <?php endif;?>

                                    <?php else : ?>
                                        <button type="submit" id="debit" disabled class="btn btn-primary d-none" <?php if(($integrations[0]->Status_2) && $integrations[0]->Status_2 == 5 || $integrations[0]->Status_2 == 2) echo "disabled" ?> <?php if($_SESSION['Logiref_role']==4) echo "disabled" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==4) echo "Enregistrer"; else echo "Valider"; ?>&nbsp;&nbsp;</button>&nbsp;
                                        <?php if(in_array('1', $integration_status) || in_array('3', $integration_status) || in_array('4', $integration_status) || in_array('5', $integration_status)): ?>
                                            <button type="submit" id="regul" class="btn btn-success" ><i class="fa fa-archive"></i>&nbsp;&nbsp;Reserver&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                        <?php endif;?>
                                        <button type="submit" id="verify" class="btn btn-danger d-none"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;Vérifier&nbsp;&nbsp;</button>&nbsp;
                                        <button type="submit" id="treat" class="btn btn-primary" <?php echo $button_treat ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                        <?php //if($role != '4') :?>
                                             <button type="submit" id="confirm" <?php if(in_array('1', $integration_status) || in_array('3', $integration_status) || in_array('4', $integration_status) || in_array('5', $integration_status)) echo "disabled"; else echo ''; ?> class="btn btn-success" ><i class="fa fa-save"></i>&nbsp;&nbsp;Emargement&nbsp;&nbsp;</button>&nbsp;
                                        <?php //endif;?>
                                    <?php endif; ?>
                                    <button type="button" id="delete" class="btn btn-danger d-none"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="delete2" class="btn btn-danger d-none"><i class="fa fa-trash-o f10"></i>&nbsp;&nbsp;Supprimer&nbsp;</button>&nbsp;&nbsp;

                                    <input type="hidden" name="action" value="" id="action">
                                    <input type="hidden" name="bulletin_id" value="<?= $bulletin->Id_0 ?>" id="bulletin_id">
                                    <input type="hidden" name="logirefid" value="<?= $bulletin->Logirefid_34 ?>" id="logirefid">
                                    <input type="hidden" name="transaction_id" value="" id="transaction_id">
                                    <input type="hidden" name="error_code" value="" id="error_code">

                                    <a type="button" href="" id="close" class="btn btn-warning mRight10"><i style="color:#fff" class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;
                                </div>
                            </div>
                    </div>
                    <div class="col-md-4 " id="treatment">
                        <div class="row">
                            <div class="col-md-12">
                                </br></br></br>
                                <div class="form-group">
                                    <label for="designation">Designation</label>
                                    <?php echo form_input('designation',set_value('designation', isset($bulletin->Designation_23) ? $bulletin->Designation_23 : ""), 'class="form-control" id="designation" required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <!-- <input type="hidden" name="concat" value="<= $compte_guichet ?>" > -->
                                <div class="form-group">
                                    <label for="company">Compte guichet unique</label> 
                                    <?php echo form_input('Compte_guichet',set_value('Compte_guichet', isset($bulletin->Account_24) ? $bulletin->Account_24 : ""), 'class="form-control" id="company" required = "required" disabled="disabled"'); ?>
                                    <input type="hidden" name="Compte_guichet" value="<?= $bulletin->Account_24; ?>" >
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="devise">Devise</label>
                                    <?php echo form_dropdown('Devise_guichet', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                    <input type="hidden" name="Devise_guichet" value="<?= $devises['CDF'] ?>" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label for="company">Commission</label> 
                                    <?php echo form_input('Commission',set_value('Commission', isset($bulletin->Commission_26) ? $bulletin->Commission_26 : ""), 'class="form-control" id="coms" required = "required" '); ?>
                                    <!--<input type="hidden" name="Commission" value="<:? =$commission ?>" <:?//= $disabled_2 ?> >-->
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="devise">Devise</label>
                                    <?php echo form_dropdown('Devise_commission', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27: "CDF", 'class="form-control"  required="required" id="recetteDevise" '); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label for="company">Montant total</label> 
                                    <?php echo form_input('Total_amount',set_value('Total_amount',isset($bulletin->Amount_12) ? $bulletin->Amount_25 : ""), 'class="form-control" id="total" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="devise">Devise</label>
                                    <?php echo form_dropdown('Devise_amount',$devises,"CDF", 'class="form-control"  required="required" '); ?>
                                    <!--<input type="hidden" name="Devise_amount" value="<?//= $devises['CDF'] ?>" >-->
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label for="reference">R&eacute;f&eacute;rence de de l&apos;OP</label>
                                    <?php echo form_input('reference',set_value('reference', isset($bulletin->Reference_19) ? $bulletin->Reference_19 : ""), 'class="form-control" id="reference"  ""'); ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="company">Taux</label> 
                                    <?php echo form_input('Taux',set_value('Taux', set_value('Taux', isset($bulletin->Taux_31) ? $bulletin->Taux_31 : "")), 'class="form-control" '); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="company">Balance du compte</label> 
                                    <?php echo form_input('balance',set_value('balance', isset($account_balance) ? $account_balance : ""), 'class="form-control" id="balance" disabled="disabled"'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $chtml->box_body_closing(); ?> 
                <?php echo form_close(); ?>
        </div>
        </div>
    </div>
<br/>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
   
'<?php if($balance =="ok"){ ?>'

$("#balance").css('background-color','#00cc33');
$("#balance").css('color','white');
$("#createLien").prop('disabled', false);

'<?php }elseif($balance =="ko"){ ?>'

$("#balance").css('background-color','red');
$("#balance").css('color','white');
$("#createLien").prop('disabled', true);

'<?php } ?>'

'<?php if(($integrations[0]->Status_2) && $integrations[0]->Status_2 == 5 && $_SESSION['Logiref_role']==3): ?>'
$('#delete').prop("disabled",false);
'<?php endif; ?>'

get_accountname();


$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});

$("#confirm").click(function(){
        $("#action").val('confirmer');
});

$("#debit").click(function(){
        $("#action").val('debit');
});
$("#verify").click(function(){
        $("#action").val('verify');
});

$("#treat").click(function(){
        $("#action").val('traiter');
});

$("#releaseLien").click(function(){
        $("#action").val('releaseLien');
});

$("#regul").click(function(){
        $("#action").val('regul');
});

$("#approbation_debit").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#debit").prop("disabled", false);
                $("#approbation_emarge").prop("checked", false);
                $("#confirm").prop("disabled", true);
        }
        else
        {
                $("#debit").prop("disabled", true);
        }  
});

$("#approbation_emarge").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#confirm").prop("disabled", false);
                $("#approbation_debit").prop("checked", false);
                $("#debit").prop("disabled", true);
        }
        else
        {
                $("#confirm").prop("disabled", true);
        } 
});

$("#bank_account").change(function(){
    
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            $('#internal_account').val(compte);
            $('#internal_account').prop('disabled', false);
            get_accountname_internal();
    }
    else
    {
            $('#internal_account').val('');
            $('#internal_account').prop('disabled', true);
            get_accountname();
    }
});

$("#account_devise").change(function(){
    var compte = $("#bank_account").val();
    if(compte.length == 14)
    {
            get_accountname_internal();
    }
    else
    {
            get_accountname();
    } 
});

$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        if(action == 'confirmer')
        {
                next_step(data);
        }
        else if(action == 'traiter')
        {
                treat_data(data);
        }
        else if(action == 'debit')
        {
                get_reservation_debit_account(data);
        }
        else if(action == 'releaseLien')
        {
                cancel_reservation(data);
        }
        else if(action == 'verify')
        {
                verify(data);
        }
        else if(action == 'regul')
        {
                get_reservation_debit_account(data);
        }
});

function cancel_reservation(data)
{
        var bank = '<?php echo $bank ?>';
        var csrf = $('input[name="csrf_name"]').val();
        var object = "single";

        if(bank == 'Boa')
        {
            validate_amount_blocked(data);
        }
        else
        {
            var bulletin_id = $('#bulletin_id').val();

            var url = '<?php echo base_url($module.'/taxaccounts/data/cancel_reservation'); ?>';

            $.ajax({
                        type        : 'POST',
                        url         : url,
                        data        : { bulletin_id : bulletin_id,  object: object, csrf_name:csrf},
                        dataType    : 'json',
                        encode          : true,
                        success: function(response)
                        {
                                $("#loader1").html('');
                                if(response.code == '200')
                                {
                                        var data = $('#mainform').serialize();
                                        get_reservation_debit_account(data);
                                }
                                else if(response.code == '407')
                                {
                                    $("#loader1").html('<div class="alert aWarning text-white">Désolé, la fonctionnalité d\'annulation d\'une réservation n\'est pas configurée pour ce compte logiref, veuillez contacter votre administrateur à cet effet<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(response.code == '404')
                                {
                                        $('#loader1').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(response.code == '405')
                                {
                                        $('#loader1').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(response.code == '406')
                                {
                                        $('#loader1').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(response.code != '')
                                {
                                        $('#loader1').html(response.error_message);
                                }
                                else
                                {
                                        $('#loader1').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                        },
                        error:function(error)
                        {
                                $("#loader1").html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
            });
        }
}

function validate_amount_blocked(data)
{
        var bulletin_id = $('#bulletin_id').val();
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url($module.'/taxbulletin/display/validate_amount_blocked'); ?>';

        $("#debit").prop('disabled', true);
        $('#treat').prop("disabled", true);

        $.ajax({
                type        : 'POST',
                url         : url,
                data        : {bulletin_id : bulletin_id, csrf_name:csrf},
                dataType    : 'json',
                encode          : true,
                success: function(result)
                {
                        if (result.response == "200")
                        {
                            $("#loader1").html('');
                            $("#loader12").html('');
                            $('#confirm').prop("disabled", false);
                            $('#releaseLien').prop("disabled", true);

                            $('#loader1').html('<div class="alert aSuccess text-white">La validation de la transaction a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger le bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $('#loader1').html('');
                            $('#loader1').html('<div class="alert aDanger text-white">'+result.message+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error)
                {
                        $('#message').html('<div class="alert alert-danger text-white">L\'envoi de la requête s\'est fait avec succès mais Igor n\'a pas retourné de réponse, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function treat_data(data)
{
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/verification'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                    
                    if(result.code === "E34")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E13" || result.code === "E003")
                    {
                            $('#loader1').html(result.message);
                    }
                    else if(result.code === "E22")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Aucune declaration trouv&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E11")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E404")
                    {
                            $('#loader1').html('<div class="alert aWarning text-white">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E405")
                    {
                            $('#loader1').html('<div class="alert aWarning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E406")
                    {
                            $('#loader1').html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E000")
                    {
                            $('#loader1').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E15")
                    {
                            $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E18")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E21")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result.code === "E411")
                    {
                            $('#loader1').html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion &agrave; amplitude, survenu lors de la recup&eacute;ration de la balance du compte du client<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $('#loader1').html('');
                            $("#balance").css('background-color','#00cc33');
                            $("#balance").css('color','white');
                            $("#balance").val('Approvisionné');

                            $("#releaseLien").prop('disabled', false);
                            $("#debit").prop('disabled', false);
                            $("#releaseLien").removeClass('hidden');
                    }

                },
                error:function(error)
                {
                    $('#loader1').html('<div class="alert aWarning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function first_transaction()
{
    var bulletin_id = $('#bulletin_id').val();
    var csrf = $('input[name="csrf_name"]').val();
    
    var url = '<?php echo base_url($module.'/taxbulletin/display/first_transaction'); ?>';
    
    //$("#debit").prop('disabled', true);
    $('#treat').prop("disabled", true);

    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : {bulletin_id : bulletin_id, csrf_name:csrf}, 
                dataType    : 'html',  
                encode          : true,
                success: function(result)
                {
                        if(result.code =='E407')
                        {
                            $('#message').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#loader1').prop("disabled",true);
                        }
                        else if(result.code =='E408')
                        {
                            $('#message').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#loader1').prop("disabled",true);
                        }
                        else if(result.code =='E409')
                        {
                            $('#message').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#loader1').prop("disabled",true);   
                        }
                        if(result.code =='200')
                        {
                            $("#loader1").html('');
                            $("#loader12").html('');
                            $('#confirm').prop("disabled", false);
                            $('#releaseLien').prop("disabled", true);

                            $('#loader1').html('<div class="alert alert-info text-white"> La validation de la transaction a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger le bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $("#loader1").html('');
                            $("#loader12").html('');
                            $('#message').html(result.msg);
                        }

                },
                error:function(error)
                {
                    $('#message').html('<div class="alert alert-danger text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
    });
}

function get_reservation_debit_account(data)
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    $("#reserve").prop('disabled', true);
    $("#debit").prop('disabled', true);

    var url = '<?php echo base_url($module.'/taxbulletin/display/debit_client'); ?>';

    $.ajax({
        type        : 'POST',
        url         : url,
        data        : data,
        dataType    : 'json',
        encode      : true,
        success: function(result){

            if(result.code=='E407')
            {
                $('#loader1').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#reserve').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else
            {
                if (['E200', 'E500', '200', '500'].includes(String(result.code)))
                {
                    '<?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>'
                    $('#confirm').prop("disabled", false);
                    $('#treat').prop("disabled", true);
                    $('#releaseLien').prop("disabled", true);
                    $('#loader1').html(result.msg);
                    '<?php else: ?>'
                    next_step(data);
                    '<?php endif; ?>'
                }
                else
                {
                    $("#loader1").html(result.msg);
                    $('#regul').prop("disabled", true);
                    $('#releaseLien').prop("disabled", true);
                    $('#verify').removeClass('d-none');
                    $('#treat').prop("disabled", true);

                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                    $('#logirefid').val(result.logirefid);
                }
            }

        },
        error:function(error)
        {
            $("#loader1").html('<div class="alert aWarning text-white">La r&eacute;servation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function verify(data)
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/verify_transaction_single';

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            $("#loader1").html('');

            if(result.code =='E407')
            {
                $('#loader1').html('<div class="alert aDanger text-white">Désolé, l\'option de vérification de transaction n\'est pas paramétrée pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#repartition').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else if(result.code =='E200')
            {
                 next_step(data); 
                '<?php //if($bank == 'sofibanque'): ?>'
                    //next_step(data); 
                '<?php //else: ?>';
                    // $("#verify").prop('disabled',true);
                    // $("#regul").prop('disabled',true);
                    // $('#treat').prop("disabled", false);
                    // $('#confirm').prop("disabled", false);
                    // $('#releaseLien').prop("disabled", true);
                '<?php //endif; ?>';
            }
            else
            {
                $('#loader1').html(result.msg);
            }
        },
        error:function(error)
        {
            $('#loader1').html('<div class="alert aWarning text-white">La régularisation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader1").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
}

function next_step(data)
{
       $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
       //$('#confirm').prop("disabled", true);
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');

       var url = '<?php echo base_url($module.'/taxbulletin/display/confirmation'); ?>';
       $.ajax({
               type        : 'POST',
               url         : url,
               data        : data,
               dataType    : 'json',
               encode      : true,
               success: function(result){
                        $('#loader1').html('');
                        $('#envoyer').html(button);

                        if(result.code === "E34")
                        {
                                //var data = $('#mainform').serialize();
                                single_recover(data);
                                //$('#loader1').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E22")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Aucune declaration trouv&eacute;e. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E13" || result.code === "E003")
                        {
                                $('#loader1').html(result.message);
                        }
                        else if(result.code === "E11")
                        {
                                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E15")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E18")
                        {
                                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E21")
                        {
                                $('#loader1').html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E002")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">L\'enregistrement du bulletin n\'a pas abouti. Veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E000")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E405")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');

                                var url = '<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $("#loader1").html('');
                                    $("#pager").html(data);
                                })
                        }
                },
                error:function(error)
                {
                    $('#loader1').html('<div class="alert aWarning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
       });

}

function single_recover(data)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    var url = '<?php echo base_url($module . '/taxbulletin/display/single_recover_in_branch'); ?>';
    $.ajax({
        type: 'POST',
        url: url,
        data: data,
        dataType: 'json',
        encode: true,
        success: function (result)
        {
            $('#loader').html('');
            if(result.code === 'E34')
            {
                $('#loader').html('');
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active');

                var url = '<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/' + result.id;
                $.get(url, function (data, status) {
                    $("#loader").html('');
                    $("#pager").html(data);
                    $('#success_message').html('<div class="alert alert-info text-black">Bulletin confirm&eacute; dans sydonia avec succ&egrave;s, veuillez cliquer sur le bouton enregistrer ci-dessous, puis contacter votre validateur urgement pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                });
            }
            else
            {
                scrollUP();
                $("#loader-sub-menu").html('<div class="alert alert-info text-black">Alerte: Problème de connéxion à Sydonia, allez dans le menu [Editer un encaissement] pour poursuivre le traitement de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error: function (error)
        {
            $("#loader-sub-menu").html('<div class="alert alert-info text-black">Alerte: Problème de connéxion à Sydonia, allez dans le menu [Editer un encaissement] pour poursuivre le traitement de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}


</script>