<div class="row">
    <div class="col-md-12">
        <table id="table" class="table table-hover table-striped">
            <tbody class="">
                <?php foreach($instructions as $row) : ?>
                    <tr>
                        <td  width="250px" class="f12 "><?php echo $row['Libelle_12'];?></td>
                        <td  width="100px" class="f12 "><?php echo $row['Operation_8'];?></td>
                        <td width="200px" class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'00000000000000000000000'; ?></td>
                        <td width="300px" class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'00000000000000000000000'; ?></td>
                        <td class="f12"><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                        
                    </tr>
                <?php endforeach;?>
            </tbody>    
        </table>
    </div>
</div>