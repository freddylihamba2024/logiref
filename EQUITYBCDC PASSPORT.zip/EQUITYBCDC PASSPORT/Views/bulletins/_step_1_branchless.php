<?php $codeBank = isset($_SESSION['Guichet_code']) ? substr($_SESSION['Guichet_code'], 1) : '51'; ?>   
<?php
if (isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else:
    $taux['Dollar_4'] = 00;
    $taux['Euro_5'] = 00;
    $taux['Rand_6'] = 00;
endif;

$user_id = $user_session_id;

if ($bulletin->Lock_46 == $user_id) {
    $view = "";
    $disabled_treat = 'disabled="disabled"';
    $disabled_confirm = '';
} else {
    $view = "view";
    $disabled_treat = '';
    $disabled_confirm = 'disabled="disabled"';
}
?>

<div class="row">
    <div class="col-md-11">

        <div class="row">
            <div class="col-md-12">
                <h1>Bulletin de liquidation</h1>
                <p class="page-header">Traitement des bulletins de liquidation</p>    
                <div id="loader"></div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-1">
                        <div id="step-1" title="" class="bRound <?php
                        if ($step == 0) {
                            echo 'bg-green-active';
                        } else {
                            echo 'bg-gray';
                        }
                        ?>  f18 center pull-right">1</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">V&eacute;rification du Bulletin<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-2" title="" class="bRound <?php
                        if ($step == 2 || $step == 1) {
                            echo 'bg-green-active';
                        } else {
                            echo 'bg-gray';
                        }
                        ?> f18 center pull-right">2</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">Confirmation du paiement<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-3" title="" class="bRound <?php
                        if ($step == 3) {
                            echo 'bg-green-active';
                        } else {
                            echo 'bg-gray';
                        }
                        ?> f18 center pull-right">3</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">Validation<br/></div>
                    </div>
                </div>

            </div>
        </div>

        <div class="col-md-12"><br/>
            <div id="loader"></div>
        </div>
        <div class="col-md-12" id="success_message"></div>
        <div id="pager" style="width: 100%;">
            <?php if ($step == 1 || $step == 2): ?>
                <?php echo view('_step_2'); ?>
            <?php elseif ($step == 3): ?>
                <?php echo view('_step_3'); ?>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                        <?php $chtml->box_body_opening('', true); ?>
                        <div class="row">
                            <div class="col-md-8 bRight">
                                <input type="hidden" name="Account" value="<?php echo $account_session_id; ?>">
                                <input type="hidden" name="User" value="<?php echo $user_session_id; ?>">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                                        </div> 
                                    </div>

                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="Service_16">Bureau (ou service)</label> 
                                                <?php echo form_dropdown('Office', $services['DGDA'], $bulletin->Office_6, 'class="form-control" id="service" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="year">Ann&eacute;e</label> 
                                                <?php echo form_input('Year', set_value('Year', $bulletin->Year_5), 'class="form-control" id="year" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="year">Banque</label> 
                                                <?php echo form_input('Bank', set_value('Bank', $bulletin->Bank_11), 'class="form-control" id="bank" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                                <?php echo form_input('Nif', set_value('Nif', $bulletin->Nif_9), 'class="form-control" id="nif" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                                <?php echo form_input('Agent', set_value('Agent', $bulletin->Agent_10), 'class="form-control" id="declarant" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="assessment_serial">S&eacute;rie</label>
                                                <?php echo form_input('Series', set_value('Series', $bulletin->Serie_7), 'class="form-control" id="assessment_serial" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="assessment_number">Num&eacute;ro du bulletin</label>
                                                <?php echo form_input('Number', set_value('Number', $bulletin->Number_8), 'class="form-control" id="assessment_number" readOnly required = "required"'); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Montant_11">Montant </label>
                                                <?php echo form_input('Amount', set_value('Amount', $bulletin->Amount_12), 'class="form-control" id="Montant_11" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="devise">Devise</label>
                                                <?php echo form_dropdown('devise', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                                <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="Mode">Mode</label> 
                                                <?php echo form_dropdown('Mode', $modes, isset($bulletin->Mode_30) ? $bulletin->Mode_30 : "", 'class="form-control"  required="required" id="modeId"readOnly'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="assessment_number">Date liquidation</label>
                                                <?php
                                                $date = $bulletin->Dateliquidation_40;
                                                $new_date = date("Y-m-d", strtotime($date));
                                                ?>
                                                <?php echo form_input('DateL', set_value('DateL', $new_date), 'class="form-control" id="datepicker1" required = "required" readOnly'); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="Account" id="accountname">Compte du client &agrave; d&eacute;biter</label>
                                                <?php echo form_input('bank_account', set_value('bank_account', $bulletin->Account_28), 'class="form-control" id="bank_account" required = "required" readOnly'); ?>
                                                <input type="hidden" name="account_name" value="" id="account_name">
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="Devise_account">Devise de ce compte</label>
                                                <?php echo form_dropdown('Devise_account', $devises, "CDF", 'class="form-control" id="account_devise" disabled="disabled"'); ?>
                                                <input type="hidden" name="Devise_account" value="<?= $devises['CDF'] ?>" >
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div id="details" class="col-md-12">

                                    </div>
                                </div>

                                <div class="box-footer clearfix">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <button type="submit" id="extourne" class="btn btn-primary hidden" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;</button>&nbsp;&nbsp;

                                            <button type="button" id="open_treatment" class="btn btn-success" <?php echo $disabled_treat; ?> ><i class="fa fa-archive " ></i>&nbsp;&nbsp;Ouvrir pour traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;

                                            <button type="button" id="verify" class="btn btn-success hidden"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                            <button type="button" id="confirm" class="btn btn-default" <?php echo $disabled_confirm; ?> ><i class="fa fa-save" ></i>&nbsp;&nbsp;Confirmer dans SYDONIA&nbsp;&nbsp;</button>&nbsp;
                                            <button type="button" id="recover" class="btn btn-primary hidden" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;esayer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                            <button type="button" id="treat" class="btn btn-primary" <?= $disabled_treat ?>><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                            <input type="hidden" name="action" value="" id="action">
                                            <input type="hidden" name="logirefid" value="" id="logirefid">
                                            <input type="hidden" name="bulletin_id" value="<?php echo $bulletin->Id_0 ?>" id="bulletin_id">
                                            <input type="hidden" name="transaction_id" value="" id="transaction_id">
                                            <input type="hidden" name="error_code" value="" id="error_code">
                                            <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="col-md-4" id="treatment">
                                <br/>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="designation">Designation</label> 
                                            <?php echo form_input('designation', set_value('designation', $bulletin->Designation_23), 'class="form-control" id="designation" required = "required" readOnly'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label for="company">Commission</label> 
                                            <?php echo form_input('Commission', set_value('Commission', $bulletin->Commission_26), 'class="form-control" id="coms" required = "required" readOnly'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="devise">Devise</label>
                                            <?php echo form_dropdown('Devise_commission', $devises, isset($bulletin->Devise_27) ? $bulletin->Devise_27 : "CDF", 'class="form-control"  required="required" id="recetteDevise" readOnly'); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label for="company">Montant total</label> 
                                            <?php echo form_input('Total_amount', set_value('Total_amount', $bulletin->Amount_25), 'class="form-control" id="total" required = "required" readOnly'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="devise">Devise</label>
                                            <?php echo form_dropdown('Devise_amount', $devises, "CDF", 'class="form-control"  required="required" readOnly'); ?>
                                            <input type="hidden" name="Devise_amount" value="<?= $devises['CDF'] ?>" >
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label for="company">Balance compte du client</label> 
                                            <?php echo form_input('balance', set_value('balance', 'Solde suffisant'), 'class="form-control" id="balance" disabled="disabled"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="company">Taux</label> 
                                            <?php echo form_input('Taux', set_value('Taux', set_value('Taux', $taux['Dollar_4'])), 'class="form-control" readOnly'); ?>
                                        </div>
                                    </div>
                                </div>

                                <input type="hidden" name="reference" value="">
                            </div>
                        </div>



                        <?php $chtml->box_body_closing(); ?> 
                        <?php echo form_close(); ?>
                    </div>
                </div>

            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-1 content">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $("#open_treatment").click(function () {
        open_treatment();
    });

    $("#confirm").click(function () {
//        $("#action").val('confirmer');
        var data = $("#mainform").serialize();
        next_step(data);
    });

    $("#treat").click(function () {
//        $("#action").val('traiter');
        var data = $("#mainform").serialize();
        treat(data)
    });

    $("#reserve").click(function () {
        $("#action").val('reserve');
    });

    $("#verify").click(function () {
//        $("#action").val('verify');
        var data = $("#mainform").serialize();
        verify(data);
    });

    $("#extourne").click(function () {
        $("#action").val('extourne');
    });

    $("#recover").click(function () {
//        $("#action").val('recover');
        var data = $("#mainform").serialize();
        single_recover(data);
    });

    $("#pager").on("change", "#coms", function () {
        $("#confirm").prop('disabled', true);
    });

    $("#pager").on("change", "#total", function () {
        $("#confirm").prop('disabled', true);
    });


    $('.chosen-select').chosen({width: "100%"});

    $("#pager").on("submit", "#mainform", function (event) {

        event.preventDefault();

        var data = $(this).serialize();
        var action = $('#action').val();

        if (action == 'traiter')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module . '/taxbulletin/display/verification'); ?>';
            $.ajax({
                type: 'POST',
                url: url,
                data: data,
                dataType: 'json',
                encode: true,
                success: function (result) {

                    if (result.code === "E34")
                    {
                        single_recover(data);
                    } else if (result.code === "E13" || result.code === "E003")
                    {
                        $('#loader').html(result.message);
                    } else if (result.code === "E22")
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucune declaration trouv&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E11")
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E404")
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E405")
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E406")
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E000")

                    {
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E15")
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E18")
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E21")
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code === "E411")
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; amplitude, survenu lors de la recup&eacute;ration de la balance du compte du client<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else
                    {
                        get_details(result.data);
                    }


                },
                error: function (error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else if (action == 'reserve')
        {
            get_reservation(data);
        } else if (action == 'verify')
        {
            verify(data);
        } else if (action == 'confirmer')
        {
            next_step(data);
        } else if (action == 'extourne')
        {
            cancel_reservation(data);
        } else if (action == 'recover')
        {
            single_recover(data);
        }
    });


    $("#cancel").click(function () {
        location.reload(true);
    });

    $("#close").click(function () {
        location.reload(true);
    });


    $("#bank_account").change(function () {
        get_accountname();
    });

    $("#account_devise").change(function () {
        get_accountname();
    });


    function treat(data) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/verification'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.code === "E34")
                {
                    single_recover(data);
                } else if (result.code === "E13" || result.code === "E003")
                {
                    $('#loader').html(result.message);
                } else if (result.code === "E22")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Aucune declaration trouv&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E11")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E404")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E405")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E406")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E000")

                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E15")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E18")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E21")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E411")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; amplitude, survenu lors de la recup&eacute;ration de la balance du compte du client<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else
                {
                    get_details(result.data);
                }


            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function next_step(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $('#confirm').prop("disabled", true);

        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        var url = '<?php echo base_url($module . '/taxbulletin/display/confirmation_branchless'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {
                $('#loader').html('');
                $('#envoyer').html(button);

                if (result.code === "E34")
                {
                    single_recover(data);
                } else if (result.code === "E22")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Aucune declaration trouv&eacute;e. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#manuel").prop('disabled', '');
                    $("#manuel").removeClass('btn-default');
                    $("#manuel").addClass('btn-success');

                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E13" || result.code === "E003")
                {
                    $('#loader').html(result.message);
                    $("#manuel").prop('disabled', '');
                    $("#manuel").removeClass('btn-default');
                    $("#manuel").addClass('btn-success');

                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E11")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E15")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Le numéro impôt n&apos;est pas reconnu..!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E18")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E21")
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E002")
                {
                    $('#envoyer').prop("disabled", false);
                    $('#loader').html('<div class="alert alert-warning text-white">L\'enregistrement du bulletin n\'a pas abouti. Veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E000")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E404")
                {
                    single_recover(data);
                } else if (result.code === "E405")
                {
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#extourne").removeClass('hidden');
                    $("#reserve").addClass('hidden');
                } else if (result.code === "E406")
                {
                    single_recover(data);
                } else if (result === "E444")
                {
                    single_recover(data);
                } else if (result.code === "OK")
                {
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');

                    var url = '<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/' + result.id;
                    $.get(url, function (data, status) {
                        $("#loader").html('');
                        $("#pager").html(data);
                        $('#success_message').html('<div class="alert alert-info text-white">Bulletin confirm&eacute; dans sydonia avec succ&egrave;s, veuillez cliquer sur le bouton enregistrer ci-dessous, puis contacter votre validateur urgement pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    })
                }
            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">La confirmation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
            }
        });

    }

    function get_details(data)
    {
        var url = "<?php echo base_url($module . '/taxbulletin/display/step_1_details'); ?>/";

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {

                if (result == 'E411')
                {
                    $('#loader').html('<div class="alert alert-danger text-white">Alerte: Probl&eacute;me de connexion &agrave; amplitude, survenu lors de la recup&eacute;ration de la balance du compte du client.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else
                {
                    $('#loader').html('');
                    $("#reserve").prop('disabled', false);
                    $('#treatment').html(result);
                }
            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function get_accountname()
    {
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var url = '<?php echo base_url($module . '/accounts/data/get_accountname'); ?>';
        if (compte !== '' && devise !== '')
        {
            $("#accountname").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {compte: compte, devise: devise},
                dataType: 'html',
                encode: true,
                success: function (reponse)
                {
                    if (reponse == '404')
                    {
                        $("#accountname").css('color', 'red');
                        $("#accountname").html('Ce compte n&apos;existe pas');
                    } else if (reponse == '406')
                    {
                        $("#accountname").css('color', 'orange');
                        $("#accountname").html('Probl&egrave;me de connexion &agrave; amplitude!');
                    } else if (reponse == '405')
                    {
                        $("#accountname").css('color', 'orange');
                        $("#accountname").html('Le format de compte n\'est pas valide');
                    } else
                    {
                        $("#accountname").css('color', 'green');
                        $("#accountname").html(reponse);
                        $("#account_name").val(reponse);
                    }


                },
                error: function (error)
                {
                    $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else
        {
            $("#accountname").html(chtml);
        }
    }

    function get_reservation(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/reservation'); ?>';

        $("#reserve").prop('disabled', true);
        $("#treat").prop('disabled', true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.code == 'E200')
                {
                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);

                    var data = $('#mainform').serialize();

                    next_step(data);
                } else if (result.code == 'E500')
                {
                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);

                    var data = $('#mainform').serialize();

                    next_step(data);
                } else if (result.code == 'E501')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E502')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E503')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E301')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> Probl&eacute;me de connexion &agrave; amplitude, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E302')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E303')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E304')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E305')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                } else if (result.code == 'E306')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').addClass('hidden');
                    $('#verify').removeClass('hidden');

                    $('#bulletin_id').val(result.id);
                    $('#logirefid').val(result.reference);
                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                }

            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/verify'); ?>';

        $("#verify").prop('disabled', true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {

                if (result == 'E200')
                {
                    next_step(data);
                } else if (result == 'E304')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result == 'E501')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> La r&eacute;servation a &eacute;t&eacute; int&eacute;gr&eacute; partiellement, veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function cancel_reservation(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/cancel_reservation'); ?>';

        $("#extourne").prop('disabled', true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#loader').html('');

                if (result == 'E200')
                {
                    $('#loader').html('<div class="alert alert-info text-white"> L\'extourne a &eacute;t&eacute; faite avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result == 'E411')
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez v&eacute;rifier les transactions dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez v&eacute;rifier dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function single_recover(data)
    {
        $('#recover').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        $("#envoyer").addClass('hidden');
        var button = $('#recover').html();
        $('#recover').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxbulletin/display/single_recover_branchless'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result)
            {
                $('#loader').html('');
                if (result == "OK")
                {
                    single_recover(data);
                } else if (result === "E000")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert alert-warning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E404")
                {
                    scrollUP();
                    $('#recover').prop("disabled", false);
                    $('#recover').html(button);
                    $("#loader").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E002")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert alert-warning text-white">Ce bulletin est d&eacute;j&agrave; pay&eacute; mais l\'enregistrement n\'a pas abouti, veuillez saisir ce bulletin manuellement dans le menu <<autres paiements>> s\il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E18")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert alert-warning text-white">Code banque non trouv&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E21")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert alert-warning text-white">Code bureau non  trouv&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E15")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert alert-warning text-white">Code com\pagnie erron&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else
                {
                    $('#loader').html('');
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');

                    var url = '<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/' + result;
                    $.get(url, function (data, status) {
                        $("#loader").html('');
                        $("#pager").html(data);
                        $('#success_message').html('<div class="alert alert-info text-white">Bulletin confirm&eacute; dans sydonia avec succ&egrave;s, veuillez cliquer sur le bouton enregistrer ci-dessous, puis contacter votre validateur urgement pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    });
                }
            },
            error: function (error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">La confirmation a pris beaucoup de temps, veuillez refaire l\'op&eacute;ration s\'l vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function open_treatment(data)
    {
        var bulletin_id = '<?php echo isset($bulletin->Id_0) ? $bulletin->Id_0 : "" ?>'

        var url = "<?php echo base_url($module . '/taxbulletin/display/lock_paiement'); ?>/" + bulletin_id;
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function (data, status) {
            $("#loader").html(data);
            $('#mainform').removeClass('view');
            $('#open_treatment').removeClass('btn-success');
            $('#open_treatment').addClass('btn-default');
            $('#open_treatment').prop('disabled', true);
            $('#confirm').removeClass('btn-default');
            $('#confirm').addClass('btn-success');
            $('#confirm').prop('disabled', false);
        });
    }

</script>



