<?php 

$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");

?>

<?php  $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid']; ?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}

?>

<!-- <div class="row">
    <div class="col-md-12">
        <?php //if (isset($param) && $param != ""): ?>
            <div id="loader2"><div class="alert alert-info text-black"> La réservation de fonds est déjà effectuée. Vérifiez la comptabilisation dans le core banking, puis cliquez sur <b>[Enregistrer]</b> pour continuer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
        <?php //endif; ?>
    </div>    
</div>  -->

<div class="row">
    <div  class="col-md-12">
        <div id="message"></div>
        <?php $chtml->box_body_opening('', true);?>
            <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
                <div class="box-body">
                    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />

                    <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                    <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                    <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                    <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                    <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                    <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                    <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                    <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                    <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                    <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                    <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                    <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                    <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                    <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                    <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                    <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                    <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />

                    <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                    <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                    <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                    <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                    <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />

                    <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
                    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />

                    <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                    <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                    <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                    <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                    <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                    <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                    <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                    <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                    <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                    <input type="hidden" name="Infos[accountname]" value='<?=  isset($infos['accountname']) ? $infos['accountname'] : ""; ?>' />
                    <input type="hidden" name="Infos[quittanceid]" value='<?=  isset($infos['quittanceid']) ? $infos['quittanceid'] : ""; ?>' />
                    <input type="hidden" name="refOp" value="<?php echo $refOp ?? "" ?>" />

                    <div class="row">
                        <div class="col-md-12 no-padding">
                        <div class="col-md-12">
                            <br/><br/>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>Bureau</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                    <b>:</b> <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>D&eacute;clarant</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $bulletin->Agent_10; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>D&eacute;signation</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $encaissement->Designation_14.' / '.$encaissement->Nif_13; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>Mode de paiement</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php  echo $modes[$encaissement->Mode_19]; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>Intutil&eacute; du compte</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b><?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>Num&eacute;ro du bulletin</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $bulletin->Serie_7.' '.$bulletin->Number_8; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12">
                                                <div class="col-md-4">
                                                    <label for="office" class="f12 text-black"><b>Ann&eacute;e du bulletin</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $bulletin->Year_5; ?>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Montant total(BL)</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo $encaissement->Montant_11.' CDF '; ?>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Commission</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo number_format($encaissement->Commission_23,2,","," ").' '.$encaissement->Devise_24;?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Total &agrave; payer</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?php echo number_format($encaissement->Total,2,","," ").' CDF'; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Compte client(&agrave; d&eacute;biter)</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Devise du compte</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Taux appliqu&eacute;</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= isset($encaissement->Taux_41 ) ? $encaissement->Taux_41 : ""; ?> CDF
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-group col-md-12 no-padding">
                                                <div class="col-md-4 no-padding">
                                                    <label for="office" class="f12 text-black"><b>Compte Guichet Unique</b></label>
                                                </div>
                                                <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <span class="<?php if($compte_cgu=='00000000000000000000000') echo 'text-red'; ?> "><?php echo $compte_cgu; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 bTop">
                            <br/><label class="f18 text-black">Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                        </div>
                    </div>

                    <div class="col-md-12"><br></div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table" class="table table-hover table-striped">
                                <thead >
                                    <tr class="bg-blue">
                                        <th width="250px" class="f12 ">Libell&eacute;</th>
                                        <th width="100px" class="f12 ">Op&eacute;ration</th>
                                        <th width="200px" class="f12 ">D&eacute;bit</th>
                                        <th width="300px" class="f12 ">Cr&eacute;dit</th>
                                        <th width="" class="f12 ">Montant</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                    <?php foreach($instructions as $row) : ?>
                                        <?php if(isset($row['Operation_8']) && $row['Operation_8'] == 'C'):?>
                                        <tr>
                                            <td  width="250px" class="f12 "><?php echo $row['Libelle_12'];?></td>
                                            <td  width="100px" class="f12 "><?php echo $row['Operation_8'];?></td>
                                            <td  class=" <?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'-'; ?></td>
                                            <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'-'; ?></td>
                                            <td  class="f12"><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                                        </tr>
                                        <?php else:?>
                                        <tr>
                                            <?php $code_taxe = isset($row['Codetaxe_28']) ? $row['Codetaxe_28'] : 'none'; ?>
                                            
                                            <?php if(!isset($tax_others_banks[$code_taxe])) : ?>
                                                <td  width="250px" class="f12"><?php echo $row['Libelle_12'];?></td>
                                                <td  width="100px" class="f12"><?php echo $row['Operation_8'];?></td>
                                                <td  class="<?php if(isset($row['Compte_9']) && $row['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_9'])? $row['Compte_9']:'00000000000000000000000'; ?></td>
                                                <td  class="<?php if(isset($row['Compte_13']) && $row['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($row['Compte_13'])? $row['Compte_13']:'00000000000000000000000'; ?></td>
                                                <td  class="f12"><?php echo $row['Devise_11'].' '.number_format($row['Montant_10'],2,","," ");?></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endif;?>
                                    <?php endforeach;?>
                                        
                                    <?php foreach($others_banks_instructions as $key=>$row) :?>
                                        <tr class="bg-gray">
                                            <td colspan="5" class="bold">
                                                <span class="f15"><b><?php echo isset($key) ? "Nivellement de la taxe ".$key : ""; ?></b></span>
                                            </td>
                                        </tr>
                                        <?php foreach($row as $value) : ?>
                                        <tr>
                                            <td  width="250px" class="f12"><?php echo $value['Libelle_12'];?></td>
                                            <td  width="100px" class="f12"><?php echo $value['Operation_8'];?></td>
                                            <td  class="<?php if(isset($value['Compte_9']) && $value['Compte_9'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($value['Compte_9'])? $value['Compte_9']:'00000000000000000000000'; ?></td>
                                            <td  class="<?php if(isset($value['Compte_13']) && $value['Compte_13'] =='00000000000000000000000') echo 'text-red'; ?> f12" width="200px"><?= isset($value['Compte_13'])? $value['Compte_13']:'00000000000000000000000'; ?></td>
                                            <td  class="f12"><?php echo $value['Devise_11'].' '.number_format($value['Montant_10'],2,","," ");?></td>
                                        </tr>
                                        <?php endforeach;?>
                                    <?php endforeach;?>
                                </tbody>    
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                        <div class="col-md-12" id="Comptabilisation" class="tScroll"></div>
                    </div>

                    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                    <div class="row">
                        <div class="col-md-12"><br/><label class="page-header">Partie additionnelle : Frais liés aux attestations</label><br /></div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-check abc-checkbox abc-checkbox-success">
                                <input class="form-check-input" id="checked_attestation"  type="checkbox"  name="Infos[PaidATTESTATION]" value="FIA" >
                                <label class="form-check-label text-blue font-bold" for="checked_attestation">
                                    Frais liés à l’impression de l'attestations
                                </label>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-check abc-checkbox">
                                <input class="form-check-input" id="checked_duplication" type="checkbox" disabled  name="Infos[PaidDUPLICATA]" value="FDA">
                                <label class="form-check-label text-blue font-bold" for="checked_duplication">
                                    Frais de duplicata d’attestation
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php endif ?>
                </div>
                <div class="box-footer clearfix">
                    <div class="row">
                        <div id="createPaiement" class="col-md-12">

                            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <button type="button" id="treat" class="btn btn-default d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif; ?>

                            <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                                <?php if($role == '3' || $role == '2' || $role =='4'):?>
                                    <button id="repartition" <?php if($bulletin->Status_2 == 1 && $role == '3') echo ''; else echo 'disabled' ?> type="submit" class="btn  <?php if($bulletin->Status_2 == 1 && $role == '3') echo 'btn-success'; else echo 'btn-default'; ?>" ><i class="fa fa-save"></i>&nbsp;&nbsp;R&eacute;partition&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php endif;?>
                                <?php if($role =='4' && ($bulletin->Status_2 == '1' || $bulletin->Status_2 == '2')):?>
                                    <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le schema comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php endif;?>
                                <button type="button" id="print_attestation" <?php //echo($bulletin->Status_2 == '3')? '' : 'disabled'; ?> class="btn btn-primary hidden"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos;attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="quittance" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <a type="button" id="quit" class="btn btn-warning" href=""><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                            <?php else : ?>

                                <?php if($role == '3' || $role == '2' || $role =='4'):?>
                                    <button id="confirm" <?php if(($bulletin->Status_2 == 2 && $role =='4') || $bulletin->Status_2 == 3) echo 'disabled'; else echo '' ?> type="submit" class="btn  <?php if($bulletin->Status_2 == 2 || $bulletin->Status_2 == 1) echo 'btn-success'; else echo 'btn-default'; ?>" ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($role == '3' || $role == '2') echo "Valider"; else echo "Enregistrer"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php endif;?>
                                <?php if($role =='4' && ($bulletin->Status_2 == '1' || $bulletin->Status_2 == '2')):?>
                                    <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le schema comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php endif;?>

                                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                    <button type="button" id="print_attestation" disabled class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos;attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php else : ?>
                                    <button type="button" id="print_attestation" <?php //echo($bulletin->Status_2 == '3')? '' : 'disabled'; ?> class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos;attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <?php endif; ?>
                                
                                <button type="button" id="quittance"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;G&eacute;n&eacute;rer la quittance&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 
    </div>
</div>


<script type="text/javascript"  charset="utf-8">
var ref = '';
var logiref_id = '';


<?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
    handle_checkbox_value("#checked_attestation", "FIA");
    handle_checkbox_value("#checked_duplication", "FDA");

    function handle_checkbox_value(selector, valueIfChecked) {
        $(selector).on("change", function () {
            const isChecked = $(this).is(':checked');
            $(this).val(isChecked ? valueIfChecked : "");

            //$("#commission").val('');
            //commission(valueIfChecked);

            if(isChecked) {
                $("#treat").removeClass("d-none");
                $("#confirm").prop("disabled", true);
                $("#Comptabilisation").removeClass('d-none');
            } else {
                $("#treat").addClass("d-none");
                $("#confirm").prop("disabled", false);
                $("#Comptabilisation").addClass('d-none');

            }
        });
    }

    $("#treat").click(function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxbulletin/display/instructions_attestation'); ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        var data = $("#confirmform").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                $("#Comptabilisation").html(result);

                if(result.code =='200'){
                        $('#message').html('');

                        $("#treat").removeClass('d-none');
                        $("#treat").prop("disabled", true);
                        $("#print_attestation").prop("disabled", true);
                        $("#confirm").prop("disabled", false);

                        $("#Comptabilisation").html(result.html);

                        $('#message').html('<div class="alert alert-info text-black"> Le traitement a été effectué avec succès. Veuillez valider les frais afin de pouvoir imprimer l\'attestation.!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
                else if (result.code == "E405") {
                        $("#treat").prop("disabled", true);
                        $("#paid_attestation").removeClass('d-none');

                        $('#message').html('<div class="alert alert-info text-black"> L\'attestation ne peut pas être imprimée tant que des écritures restent en attente de validation. Merci de valider les frais concernés.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le traitement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });
    
<?php endif; ?>;

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});

$("#print_attestation").click(function(){
       //pralert("tres");
        var bl = '<?php echo $encaissement->Sydonia_44; ?>';
        
        var url = '<?php echo base_url($module.'/taximpression/display/attestationbl'); ?>/' + bl;
        
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#cancel").click(function(){
        <?php if($_SESSION['Logiref_role'] == 4){ ?>
                        
                close_form();

        <?php }else{ ?>

            location.reload(); 

        <?php } ?>
});

$("#schema").click(function(){

        var bl = '<?php echo $encaissement->Sydonia_44; ?>';
        
        var url = '<?php echo base_url($module.'/taximpression/display/schemabl'); ?>/' + bl;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#quittance").click(function(){
    
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var button = $(this).html();
        
        $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
        var paiementid = '<?= isset($idBL) ? $idBL : "" ?>';
		var data = $('#confirmform').serialize();
        
        var url = '<?php echo base_url($module.'/taxbulletin/display/getquittance'); ?>/' + paiementid;
        
        
        $.ajax({    
                type        : 'POST', 
                url         : url, 
				data        : data,
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        
                    $(this).prop("disabled", false);
                    $('#quittance').html(button);
                    $('#message').html('');
                    
                    if(result === "E003")
                    {
                            $('#message').html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#message').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E22")
                    {
                            $('#message').html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E11")
                    {
                            $('#message').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E002")
                    {
                            $('#message').html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E001")
                    {
                            $('#message').html('<div class="alert aWarning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E003")
                    {
                            $('#message').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E000")
                    {
                            $('#message').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E005")
                    {
                            $('#message').html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E404" || result ==="E41")
                    {
                        $("#message").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                        
                        printQuittance(result);
                    }
                },
                error:function(error){
                    alert('ERROR! SYDONI 41.215.253.187 pas disponible...! ');
                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                }
        });
    
});

function submiter(data){
    
        '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>'
            var alertid = 'message';
        '<?php else: ?>'
            
            if ($("#loader-sub-menu").length) 
            {
                var alertid = 'loader-sub-menu';
            } 
            else 
            {
                var alertid = 'message';
            }
        '<?php endif; ?>'
        
        $('#'+alertid).html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/save/comptant'); ?>';
		
        $('#repartition').prop("disabled",true);
        scrollUP();

        $('#message').html('');
		
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
         
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html',
                encode      : true,
                success: function(result){

                        $('#'+alertid).html('');
                        
                        if(result=='E500')
                        {
                                $('#'+alertid).html('<div class="alert alert-info text-black">Le paiement existe d&eacute;j&agrave;, veuillez v&eacute;rifier ce paiement dans la liste de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(isNaN(result)==true)
                        {
                                $('#'+alertid).html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result > 0)
                        {
                                $("#checked_attestation").prop("disabled", true);

                                '<?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>';
                                            
                                    validate(data);
                                    
                                '<?php else: ?>'
                                
                                    '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>'
                                
                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');
                                        $('#print_quittance').prop("disabled",false);
                                        $('#quittance').prop("disabled",false);

                                        var url = '<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/' + result;
                                        $.get(url, function(data, status){
                                            $('#'+alertid).html('');
                                            $('#'+alertid).html(message);
                                            $("#pager").html(data);
                                        });

                                    '<?php else: ?>'
                                        $('#'+alertid).html(message);
                                        $('#schema').prop("disabled",true);
                                        $('#confirm').prop("disabled",true);
                                    '<?php endif; ?>'
                                    
                                '<?php endif; ?>'
                                $('#schema').prop("disabled",false);
                        }
                        else
                        {
                                $('#'+alertid).html('');
                                $('#confirm').prop("disabled",false);
                                $('#'+alertid).html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error){
                    $('#'+alertid).html('<div class="alert aDanger text-white">Le paiement n\'a pas été enregistré, veuillez refaire s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function validate(data){
        
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var url = '<?php echo base_url($module.'/taxbulletin/save/validate_single_bl'); ?>';
        scrollUP();
        $('#confirm').prop("disabled",true);
        $("#message").html('');
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        $("#message").html('');
                        $("#loader").html('');
                        
                        if(result.code=='200' && result.id > 0)
                        {
                            $("#step-2").removeClass('bg-green-active');
                            $("#step-2").addClass('bg-gray');
                            $("#step-3").removeClass('bg-gray');
                            $("#step-3").addClass('bg-green-active');
                            $('#print_quittance').prop("disabled",false);
                            $('#schema').prop("disabled",false);
                            $('#quittance').prop("disabled",false);
                            $('#repartition').prop("disabled",true);
                            
                            $("#message").html('<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.message)
                        {
                            $('#message').html('');
                            $('#message').html(result.msg);
                        }
                        else
                        {
                            $("#message").html('');
                            $("#message").html('<div class="alert aDanger text-white"> Il y a timeout lors de la comptabilisation des &eacute;critures. Veuillez v&eacute;rifier le statut de ce paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                },
                error:function(error){
                    $('#message').html('');
                    $("#message").html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures au corebanking fait avec succ&egrave;s. Le d&eacute;lai de temps de r&eacute;ponse est d&eacute;pass&eacute;, veuillez v&eacute;rifier l\'int&eacute;gration de chaque &eacute;criture dans le sch&eacute;ma comptable s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function printQuittance(file)
{
        var url = '<?php echo base_url('drive/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
        
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>
