<div class="container-fluid mt-4 px-0">

    <!-- Champ de recherche (inchangé) -->
    <div class="row mb-3 px-0">
        <div class="col-12 text-right ">
            <input type="text"
                   id="searchInput"
                   class="form-control"
                   placeholder="🔍 Rechercher..."
                   onkeyup="filterTable()"
                   style="max-width: 250px;">
        </div>
    </div>

    <!-- Tableau pleine largeur -->
    <table class="table table-striped w-100" id="bulletinTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Désignation</th>
                <th>Bénéficiaire</th>
                <th>Recette</th>
                <th>Quittance</th>
                <th>Montant</th>
                <th>Commissions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($bulletins as $bulletin): 
                
                $bulletin_data = json_decode($bulletin->Results_13, true);
            
                $quittance = $bulletin_data['receiptSerial']."".$bulletin_data['receiptNumber'];
            ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><?= $bulletin->Date_1 ?></td>
                    <td><?= $bulletin->Designation_23 ?></td>
                    <td>DGDA</td>
                    <td><?= $bulletin->Serie_7 . '-' . $bulletin->Number_8 ?></td>
                    <td><?= $quittance ?></td>
                    <td><?= $bulletin->Amount_12 . ' ' . $bulletin->Devise_27 ?></td>
                    <td><?= $bulletin->Commission_26 . ' ' . $bulletin->Devise_27 ?></td>
                </tr>
            <?php
                $i++;
            endforeach; ?>
        </tbody>
    </table>

</div>

<!-- Script de recherche -->
<script>
function filterTable() {
    let input = document.getElementById("searchInput");
    let filter = input.value.toUpperCase();
    let table = document.getElementById("bulletinTable");
    let tr = table.getElementsByTagName("tr");

    for (let i = 1; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName("td");
        let found = false;

        for (let j = 0; j < td.length; j++) {
            if (td[j].innerText.toUpperCase().indexOf(filter) > -1) {
                found = true;
                break;
            }
        }
        tr[i].style.display = found ? "" : "none";
    }
}
</script>