<?php $chtml->box_body_opening('', false); ?>
<?php echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
    <style>label {min-width: 150px !important; }</style>
    <div class="box-body">
        <div class="row margin">
            <div class="col-md-6">
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="site">Bureau</label>
                        </span>
                        <?php echo form_dropdown('Office', $services['DGDA'], $office, 'required class="form-control chosen-select"'); ?>
                    </div>
                </div>
                <div class="col-md-12  small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Agent">Declarant</label>
                        </span>
                        <?php echo form_input('Agent', set_value('Agent', $agent), ' class="form-control" required '); ?>
                    </div>
                </div>
                <!--<div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif">Num&eacute;ro imp&ocirc;t</label>
                        </span>
                        <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="designation">Designation</label>
                        </span>
                        <?php echo form_input('designation', set_value('designation', $designation), ' id= "designation" class="form-control" required '); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group no-padding">
                        <span class="input-group-addon">
                            <label for="account_name">Intitul&eacute; du compte</label>
                        </span>
                        <?php echo form_input('account_name', set_value('account_name', $account_name), ' class="form-control" required '); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group no-padding">
                        <span class="input-group-addon">
                            <label for="account">Compte &agrave; d&eacute;biter</label>
                        </span>
                        <?php echo form_input('account', set_value('account', $account), ' class="form-control" required '); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group <?php echo isset($reuseRef) ? "" : "d-none" ?>">
                        
                        <label>D&eacute;biter le client <input type="checkbox" name="debit" value="1" id="debit"></label>
                       
                        <?php if (isset($reuseRef)) : ?>
                            <input type="hidden" name="reuseRef" value="1" id="reuseRef">
                        <?php else : ?>
                           <input type="hidden" name="reuseRef" value="0" id="reuseRef" disabled="disabled">
                        <?php endif; ?>
                    </div>
                </div>-->
            </div>
            <div class="col-md-6 bLeft">
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif">Num&eacute;ro imp&ocirc;t</label>
                        </span>
                        <?php echo form_input('Nif', set_value('Nif', $nif), ' class="form-control" required'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="designation">Designation</label>
                        </span>
                        <?php echo form_input('designation', set_value('designation', $designation), ' id= "designation" class="form-control" required '); ?>
                    </div>
                </div>
                <!--<div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="site">Mode de paiement</label>
                        </span>
                        <?php echo form_dropdown('mode', $modes, $mode, 'required class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="total_amount">Montant total du lot</label>
                        </span>
                        <?php echo form_input('total_amount', set_value('total_amount', number_format($total, 2, ",", " ")), 'id="total_amount" required class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="coms">Commission totale du lot</label>
                        </span>
                        <?php echo form_input('Commission', set_value('Commission', number_format($commission, 2, ",", " ")), 'id="coms" required class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <?php $tva = $commission * 0.16; ?>
                        <span class="input-group-addon">
                            <label for="tva">TVA</label>
                        </span>
                        <?php echo form_input('tva', set_value('tva', number_format($tva, 2, ",", " ")), 'id="tva" class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group col-md-12">
                        <span class="input-group-addon">
                            <label for="total_topaid">Total &agrave; payer</label>
                        </span>
                        <?php echo form_input('total_topaid', set_value('total_topaid', number_format($total_to_paid, 2, ",", " ")), 'id="total_topaid" class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="taux">Taux appliqu&eacute;</label>
                        </span>
                        <?php echo form_input('taux', set_value('taux', number_format($taux, 2, ",", " ")), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-12 small-box">
                    <div class="input-group <?php echo isset($reuseRef) ? "" : "d-none" ?>">
                        <label>Ne pas d&eacute;biter le client <input type="checkbox" name="no_debit" value="1" id="no_debit"></label>
                    </div>
                </div>-->
            </div>
        </div>
        <div id="footpage" class="box-footer clearfix"></div>
    </div>
    <div class="box-body box-solid no-padding">
        <div class="box-body">
            <!--<input type="hidden" name="Bank" value="<?php echo $bank; ?>" />
            <input type="hidden" name="refOp" value="<?php echo $refOp; ?>" />
            <input type="hidden" name="devise_commision" value="<?php echo 'CDF'; ?>" />
            <input type="hidden" name="cdevise" value="<?php echo $cdevise; ?>" />-->

            <div class="table-responsive">
                <table class="table no-margin table-striped table-bordered">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="10px">#</th>
                            <th width="80px">Ann&eacute;e</th>
                            <th width="80px">Bulletin</th>
                            <th width="50px">Devise</th>
                            <th width="200px">Montant</th>
                            <th>Retour de SYDONIA</th>
                            <th align="center" width="90px">V&eacute;rification</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $bulletins = $results['Bulletins'];
                            $i = 1;
                            foreach ($bulletins as $bl): 
                        ?> 
                            <tr id="line<?php echo $i ?>">
                                    <td><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                                    <td><input id="year<?php echo $i; ?>" type="text" value="<?php echo $bl->year; ?>" name="years[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td><input id="bl<?php echo $i; ?>" type="text" value="<?php echo $bl->number; ?>" name="serials[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span class="form-control">CDF</span></td>
                                    <td><input id="amount<?php echo $i; ?>" type="text" value="<?php echo number_format($bl->amount, 2, ",", " "); ?>" name="amounts[<?php echo $i; ?>]" class="form-control itemgrid" required="required" /></td>
                                    <td align="center"><span id="sydonia_result<?php echo $i; ?>" class='text-yellow bold'>Bulletin non v&eacute;rifi&eacute;</span></td>
                                    <td align="center" id='btn<?php echo $i; ?>'>
                                        <span class="fa fa-fw text-gray fa-question f20"> </span>
                                    </td>
                            </tr>
                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="box-footer clearfix">
            <button type="button" id="treat" class="btn btn-primary"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <!--<button type="button" id="extourne" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Extourner&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="reserve" class="btn btn-success" disabled><i class="fa fa-archive "></i>&nbsp;&nbsp;R&eacute;server&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="verify" class="btn btn-success d-none"><i class="fa fa-external-link "></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button id="envoyer" type="submit" style="margin-left:0px;" name="submit" class="btn btn-success" disabled="disabled"><i class="fa fa-check"></i> &nbsp;Confirmer dans sydonia&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="recover" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;R&eacute;esayer&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <input type="hidden" name="logirefid" value="" id="logirefid">
            <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
            <input type="hidden" name="transaction_id" value="" id="transaction_id">
            <input type="hidden" name="error_code" value="" id="error_code">-->
            <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>
        </div>
    </div>
<?php echo form_close(); ?>
<?php $chtml->box_body_closing(); ?>

<script type="text/javascript">

        $("#extractform").submit(function(event) {
                event.preventDefault();
                var data = $(this).serialize();
                next_step(data);
        });

        $("#treat").click(function() {
                var data = $("#extractform").serialize();
                batch_traitement(data);
        });

        $("#reserve").click(function() {
                var data = $("#extractform").serialize();
                get_reservation(data);

        });

        $("#verify").click(function() {
                var data = $("#extractform").serialize();
                verify(data);

        });

        $("#extourne").click(function() {
                var data = $("#extractform").serialize();
                cancel_reservation(data);

        });

        $("#buttonCloseModal").click(function() {
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
                        $("#loader1").html('');
                        $("#pager").html(data);
                        $("#pager").addClass('content');
                        $("#close").removeClass('hidden');
                        $("#cancel").addClass('hidden');
                        $("#col").removeClass('col-md-2');
                        $("#col").addClass('col-md-1');
                        $("#content").removeClass('col-md-8');
                        $("#content").addClass('col-md-10');
                        $("#close").removeClass('col-md-2');
                        $("#close").addClass('col-md-1');
                });
        });

        $("#recover").click(function() {

                var data = $("#extractform").serialize();
                batch_recover(data);

        });

        $('#debit').change(function() {
                if ($(this).is(
                                ":checked")) {
                        $("#reserve").prop('disabled', false);
                        $("#envoyer").prop('disabled', true);
                        $("#no_debit").prop("checked", false);
                } else {
                        $("#reserve").prop('disabled', true);
                        $("#envoyer").prop('disabled', false);
                        $("#no_debit").prop("checked", true);
                }

        });

        $('#no_debit').change(function() {
                if ($(this).is(
                                ":checked")) {
                        $("#reserve").prop('disabled', true);
                        $("#envoyer").prop('disabled', false);
                        $("#debit").prop("checked", false);
                } else {
                        $("#reserve").prop('disabled', true);
                        $("#envoyer").prop('disabled', false);
                        $("#debit").prop("checked", true);
                }

        });

        function next_step(data) {
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                //$('#envoyer').prop("disabled", true);
                var button = $('#envoyer').html();
                $('#envoyer').html('<span>Chargement...</span>');
                var url = '<?php echo base_url('branch/taxbulletin/display/batch_confirmation'); ?>';
                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $('#loader1').html('');
                                if (result === "E34") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E22") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E21") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E18") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E4") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E11") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E13") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E002") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E003") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E000") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else if (result === "E404") {
                                        batch_recover(data);
                                } else if (result === "E405") {
                                        batch_recover(data);
                                } else if (result === "E406") {
                                        batch_recover(data);
                                } else if (result === "E444") {
                                        batch_recover(data);
                                } else if (result === "E411") {
                                        batch_recover(data);
                                } else if (result === "E501") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $('#envoyer').prop("disabled", true);
                                        $('#extourne').removeClass('hidden');
                                        $('#reserve').addClass('hidden');
                                } else {
                                        $('#envoyer').prop("disabled", false);
                                        $('#envoyer').html(button);
                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');
                                        $("#panel").html(result);
                                }
                        },
                        error: function(error) {
                                scrollUP();
                                $('#envoyer').prop("disabled", false);
                                $('#envoyer').html(button);
                                $('#loader1').html('<div class="alert alert-warning">La confirmation a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }


        function batch_traitement(data) {
                //alert(data)

                //$('#treat').prop("disabled", true);
                $('#buttonCloseModal').prop("disabled", true);
                var button = $('#treat').html();
                $('#treat').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var data = data;
                var url = '<?php echo base_url('branch/taxbulletin/display/batch_verification'); ?>/';
                $.ajax({
                        type: 'GET',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $('#treat').prop("disabled", false);
                                $('#buttonCloseModal').prop("disabled", false);
                                $('#treat').html(button);
                                $('#loader1').html('');
                                var result = JSON.parse(result);

                                if (result.response === "OK") {
                                    
                                        // Mise a jour du tableau avec le retour de SYDONIA
                                        var bulletins = result.bulletins;
                                        var t = 0;
                                        for (i = 0; i < bulletins.length; i++) {
                                                t = i + 1;

                                                if (bulletins[i] === "OK") {
                                                        $("#btn" + t).html('<span class="fa fa-fw text-green fa-check f20"> </span>');
                                                        $("#sydonia_result" + t).html('<div class="alert alert-success">Bulletin valide!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                } else if (bulletins[i] === "E13") {
                                                        $("#btn" + t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                                        $("#sydonia_result" + t).html('<div class="alert alert-warning">Server execption!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                } else if (bulletins[i] === "E15") {
                                                        $("#btn" + t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                                        $("#sydonia_result" + t).html('<div class="alert alert-warning">Num&eacute;ro imp&ocirc;t non r&eacute;connu<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                } else if (bulletins[i] === "E34") {
                                                        $("#sydonia_result" + t).html('<div class="alert alert-danger">Bulletin d&eacute;j&agrave; pay&eacute;!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                        $("#btn" + t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                                } else if (bulletins[i] === "E22") {
                                                        $("#sydonia_result" + t).html('<div class="alert alert-warning">Bulletin non reconnu!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                        $("#btn" + t).html('<span class="fa fa-fw text-red fa-times f20"> </span>');
                                                } else if (bulletins[i] === "E11") {
                                                        $("#sydonia_result" + t).html('<div class="alert alert-warning">Montant du bulletin est incorrect!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                        $("#btn" + t).html('<span class="fa fa-fw text-yellow fa-warning f20"> </span>');
                                                }

                                        }
                                        
                                        // Teste si la balance est suffisante et que tous les bulletins sont valides
                                        if (result.balance === "OK" && result.error === false) {
                                        
                                                // Activation de la reservation des fonds
                                                $("#reserve").prop('disabled', false);


                                                // Mise a jour du montant total a payer au cas ou la commission serait modifiee
                                                $("#total_amount").val(result.total_amount);

                                                // Mise a jour du montant total du lot des bulletins au cas ou le montant de bulletin serait modifiee
                                                $("#total_topaid").val(result.total);

                                                // mise à jour de l'affichage de la TVA
                                                $("#tva").val(result.tva);

                                                scrollUP();

                                        } else if (result.balance === "KO") {
                                                scrollUP();
                                                $('#loader1').html('<div class="alert alert-danger"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#reserve").prop('disabled', true);
                                        } else if (result.balance == "E411") {
                                                scrollUP();
                                                $('#loader1').html('<div class="alert alert-danger">Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#reserve").prop('disabled', true);
                                        }
                                        else
                                        {
                                                $("#reserve").prop('disabled', true);
                                        }
                                } else if (result.response === "batchvalide") {
                                        var bulletins = result.bulletins;

                                        var t = 0;
                                        for (i = 0; i <= bulletins; i++) {
                                                t = i + 1;

                                                $("#btn" + t).html('<span class="fa fa-fw text-green fa-check f20"> </span>');
                                                $("#sydonia_result" + t).html('<div class="alert alert-success">Bulletin valide!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        }

                                        // Teste si la balance est suffisante et que tous les bulletins sont valides
                                        if (result.balance === "OK" && result.error === false) {
                                                // Activation de la reservation des fonds
                                                $("#reserve").prop('disabled', false);

                                                // Mise a jour du montant total a payer au cas ou la commission serait modifiee
                                                $("#total_amount").val(result.total_amount);

                                                // Mise a jour du montant total du lot des bulletins au cas ou le montant de bulletin serait modifiee
                                                $("#total_topaid").val(result.total);

                                                // mise à jour de l'affichage de la TVA
                                                $("#tva").val(result.tva);

                                                scrollUP();

                                        } else if (result.balance === "KO") {
                                                scrollUP();
                                                $('#loader1').html('<div class="alert alert-danger"> Solde du compte insuffisant pour le paiement de ce lot des bulletins!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#reserve").prop('disabled', true);
                                        } else if (result.balance === "E411") {
                                                scrollUP();
                                                $('#loader1').html('<div class="alert alert-danger" >Alerte: La balance du compte n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;e, veuillez actualiser la page et refaire la saisie des informations s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#reserve").prop('disabled', true);
                                        }
                                        else
                                        {
                                                $("#reserve").prop('disabled', true);
                                        }

                                } else if (result.response === "E000") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E404") {
                                        scrollUP();
                                        $("#loader1").html('<div class="alert alert-warning">Alerte: SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E405") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E406") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: serveur SYDONIA est temporairement insdisponible. Veuillez re&eacute;ssayer dans 30 secondes...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E003") {
                                        scrollUP();
                                        $("#loader1").html('<div class="alert alert-warning">Alerte: Fatal error...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E18") {
                                        scrollUP();
                                        $("#loader1").html('<div class="alert alert-warning">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                } else if (result.response === "E15") {
                                        scrollUP();
                                        $("#loader1").html('<div class="alert alert-warning">Alerte: Code banque non trouv&eacute;...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#reserve").prop('disabled', true);
                                }


                        },
                        error: function(error) {
                                scrollUP();
                                $('#treat').html(button);
                                $('#loader1').html('<div class="alert alert-warning">La vérification a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }

        function get_reservation(data) 
        {
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var url = '<?php echo base_url($module . '/taxbulletin/display/batch_reservation'); ?>';

                $("#reserve").prop('disabled', true);

                $("#treat").prop('disabled', true);

                $("#debit").prop('disabled', true);
                $("#no_debit").prop('disabled', true);

                var desigantion = $("#designation").val();

                if (desigantion !== '') {
                        $.ajax({
                                type: 'POST',
                                url: url,
                                data: data,
                                dataType: 'html',
                                encode: true,
                                success: function(result) {
                                        $('#loader1').html('');
                                        var result = JSON.parse(result);

                                        if (result.code == 'E200') {
                                                $('#loader1').html('<div class="alert alert-info"> r&eacute;servation faite avec succ&egrave;s, veuillez cliquer sur le bouton [confirmer] pour payer ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#envoyer").removeClass('btn-default');
                                                $("#envoyer").addClass('btn-success');
                                                $("#envoyer").prop('disabled', false);

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                scrollUP();
                                        } else if (result.code == 'E500') {
                                                $('#loader1').html('<div class="alert alert-info"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce bulletin, veuillez cliquer sur le bouton [confirmer] pour payer ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $("#envoyer").removeClass('btn-default');
                                                $("#envoyer").addClass('btn-success');
                                                $("#envoyer").prop('disabled', false);

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                scrollUP();
                                        } else if (result.code == 'E501') {
                                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce lot des bulletins mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E501') {
                                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce lot des bulletins mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E502') {
                                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce lot des bulletins mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E503') {
                                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce lot des bulletins mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E301') {
                                                $('#loader1').html('<div class="alert alert-danger"> Probl&eacute;me de connexion &agrave; amplitude, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E302') {
                                                $('#loader1').html('<div class="alert alert-danger"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('hidden');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E303') {
                                                $('#loader1').html('<div class="alert alert-danger"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('d-none');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E304') {
                                                $('#loader1').html('<div class="alert alert-danger"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('d-none');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E305') {
                                                $('#loader1').html('<div class="alert alert-danger"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('d-none');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        } else if (result.code == 'E306') {
                                                $('#loader1').html('<div class="alert alert-danger"> La reservation s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour confirmer la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                                $('#reserve').addClass('d-none');
                                                $('#verify').removeClass('d-none');

                                                $('#bulletin_id').val(result.id);
                                                $('#logirefid').val(result.reference);
                                                $('#error_code').val(result.code);
                                                $('#transaction_id').val(result.transaction_id);
                                                scrollUP();
                                        }

                                },
                                error: function(error) {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">La réservation a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }


                        });
                } else {
                        scrollUP();
                        $("#reserve").prop('disabled', false);
                        $('#loader1').html('<div class="alert alert-warning">Alert : Le champ d&eacute;signation ne peut  pas &ecirc;tre vide, saisissez la d&eacute;sigantion et refaites la r&eacute;servation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

        }

        function verify(data) {
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var url = '<?php echo base_url('branch/taxbulletin/display/batch_verify'); ?>';

                $("#verify").prop('disabled', true);

                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $('#loader1').html('');

                                if (result == 'E200') {
                                        $('#loader1').html('<div class="alert alert-info"> La r&eacute;servation de fonds faite avec succès, veuillez cliquer sur le bouton [confirmer] pour payer ce  lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#envoyer").removeClass('btn-default');
                                        $("#envoyer").addClass('btn-success');
                                        $("#envoyer").prop('disabled', false);
                                        scrollUP();
                                } else if (result == 'E304') {

                                        $('#loader1').html('<div class="alert alert-danger"> La reservation n\'a pas &eacute;t&eacute; faite. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        scrollUP();
                                } else {

                                        $('#loader1').html('<div class="alert alert-danger"> Cette r&eacute;servation a &eacute;t&eacute; int&eacute;gr&eacute; partiellement, veuillez v&eacute;rifier dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        scrollUP();
                                }

                        },
                        error: function(error) {

                                $('#loader1').html('<div class="alert alert-warning">La vérification a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                scrollUP();
                        }
                });
        }

        function cancel_reservation(data) {
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var url = '<?php echo base_url($module . '/taxbulletin/display/batch_cancel_reservation'); ?>';

                $("#extourne").prop('disabled', true);

                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $('#loader1').html('');

                                if (result == 'E200') {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-info"> L\'extourne a &eacute;t&eacute; faite avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#buttonCloseModal").prop("disabled", false);
                                        $("#envoyer").prop('disabled', true);

                                } else if (result == 'E411') {
                                        $('#loader1').html('<div class="alert alert-danger"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez v&eacute;rifier les transactions dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        scrollUP();
                                } else {

                                        $('#loader1').html('<div class="alert alert-danger"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez v&eacute;rifier dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        scrollUP();
                                }

                        },
                        error: function(error) {

                                $('#loader1').html('<div class="alert alert-warning">L\'extourne a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                scrollUP();
                        }
                });
        }

        function batch_recover(data) {
                $('#recover').prop("disabled", true);
                $('#buttonCloseModal').prop("disabled", true);
                $("#envoyer").addClass('hidden');
                var button = $('#recover').html();
                $('#recover').html('<span>&nbsp;&nbsp;Traitement...&nbsp;&nbsp;</span>');
                $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                var url = '<?php echo base_url($module . '/taxbulletin/display/batch_recover'); ?>/';
                $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                                $('#loader1').html('');
                                if (result === "E000") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E404") {
                                        scrollUP();
                                        $('#recover').prop("disabled", false);
                                        $('#recover').html(button);
                                        $("#loader1").html('<div class="alert alert-warning">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else if (result === "E002") {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                } else {
                                        $('#envoyer').prop("disabled", false);
                                        $('#envoyer').html(button);
                                        $("#step-2").removeClass('bg-green-active');
                                        $("#step-2").addClass('bg-gray');
                                        $("#step-3").removeClass('bg-gray');
                                        $("#step-3").addClass('bg-green-active');
                                        $("#panel").html(result);
                                }
                        },
                        error: function(error) {
                                scrollUP();
                                $('#recover').prop("disabled", false);
                                $('#recover').html(button);
                                $('#loader1').html('<div class="alert alert-warning">La requête a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez s\'il vous plaît<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }

        function scrollUP() {
                $('html, body').animate({
                        scrollTop: $("#loader1").offset().top
                }, 20);
        }
</script>