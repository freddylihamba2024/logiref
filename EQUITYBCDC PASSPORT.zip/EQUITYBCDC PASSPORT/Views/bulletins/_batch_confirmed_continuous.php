<?php
    if ($_SESSION['userdata']['account_id'] == 45):
        $parts_account = explode('-', $compte_guichet_unique);
        $branch_code = $parts_account[0] ?? "";
    endif;
?>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    
    <div class="row">
        <div class="col-12 d-flex justify-content-end">
            <button class=" btn btn-success no-border no-radius no-margin" type="submit" id='emargement' disabled><i class="fa fa-newspaper-o text-white"></i> <span class="text-white">Emargement</span> </button>&nbsp;&nbsp;&nbsp;
            <button class=" btn btn-primary no-border no-radius no-margin " type="submit" id='repartition'><i class="fa fa-archive text-white"></i> <span class="text-white">Répartition</span> </button>&nbsp;&nbsp;&nbsp;
            <button class=" btn bg-gray no-border no-radius no-margin"  id="cancel"><i class="fa fa-fw fa-times f18"></i> </button>
            <input type="hidden" value="" id="action">
        </div>
    </div>
    <br/><br/>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Bureau</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($services['DGDA'][$paiement->Office_7]) ? $services['DGDA'][$paiement->Office_7] : "-"; ?>
                            <input type='hidden' name='Office' value='<?php isset($services['DGDA'][$paiement->Office_7]) ? $services['DGDA'][$paiement->Office_7] : ""; ?>'>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Designation</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo $paiement->Designation_15; ?>
                           <input type='hidden' name='designation' value='<?php echo $paiement->Designation_15 ?>' >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Intitul&eacute; du compte</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= $paiement->Accountholder_18; ?>
                           <input type="hidden" value="" id="account_name" name="account_name"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Compte client (&agrave; d&eacute;biter)</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= $paiement->Account_16. ' CDF '; ?>
                           <input type='hidden' name='account' value='<?php echo $paiement->Account_16 ?>'>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Montant total</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Amount_11,2,","," ").' CDF '; ?>
                           <input type='hidden' name='total_amount' value='<?php echo $paiement->Amount_11 ?>'>
                        </div>
                    </div> 
                </div>
                
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total commission</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Commission_20,2,","," ").' CDF';?>
                           <input name="Commission" value="0" id="Commission" type="hidden" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total &agrave; payer</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Total_23,2,","," ").' CDF'; ?>
                           <input type='hidden' name='total_topaid' value='<?php echo $paiement->Total_23 ?>'>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Compte Guichet Unique</label>
                        </div>
                        <div class="col-md-8">
                          <b>:</b>  <?php echo $compte_guichet_unique; ?>
                          <input type="hidden" name="logirefid" value="<?= $paiement->Lot_14 ?>">
                          <input type="hidden" name="Compte_33" value="<?= $paiement->Account_16 ?>">
                          <input type="hidden" name="branch_code" value="<?= $branch_code ?? "" ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $j =0; $k = 0; foreach($bulletins as $row){ ?>
    <input name="paimentid[]" type="hidden" value="<?php echo $row->Id_0; ?>">
    <?php 
        if($k % 10 == 0)
        { 
               $j++; 
        }
        $k++;
    ?>
    <input type="hidden" value="<?= $row->Id_0 ?>" id="paiement_treated" name="paiement_treated[<?= $j ?>][]">
<?php } ?>
<input type="hidden" value="" id="Sydonia_44" name="Sydonia_44">
<input type="hidden" value="" id="Sydonia_44_next" name="Sydonia_44_next">
<input type="hidden" value="" id="index" name="index">
<input type="hidden" value="0" id="iteration" name="iteration">
<input type="hidden" value="<?= $paiement->Id_0 ?>" id="" name="batchid">
<input type="hidden" name="lot" value="<?= $paiement->Lot_14 ?>">
<input type="hidden" name="Logirefid" value="<?= $paiement->Lot_14 ?>">
<input type="hidden" name="bulletin_id" value="<?= isset($bulletins[0]->Id_0) ? $bulletins[0]->Id_0 : ""; ?>">

<br/><br/>
<div class="col-md-12 bTop">
    <div class="col-md-12">
    <br/><label>Liste des bulletins</label><br/>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-12">
        <div id="table_view">
            <?php if(!empty($bulletins)): ?>
            <table id="dataTable" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-gray">
                        <th width="5">#</th>
                        <th width="10">Ann&eacute;e</th>
                        <th width="50">Bulletin</th>
                        <th width="20">Devise</th>
                        <th width="200">Montant</th>
                        <th class="text-center">Message</th>
                        <th width="80" class="text-center">Statut</th>
                    </tr>
                </thead>
                <tbody>
                <?php $i = 1; foreach ($bulletins as $obj) : ?>
                    <tr>
                        <td><span><b><?php echo $i; ?></b></span></td>
                        <td width=""><?php echo $obj->Year_5; ?></td>
                        <td><?php echo $obj->Serie_7 . ' ' . $obj->Number_8; ?></td>
                        <td><?php echo 'CDF'; ?></td>
                        <td><?php echo number_format($obj->Amount_12, 2, ".", ","); ?></td>
                        <td class="text-center"><span class='text-yellow bold'>Bulletin en attente de validation</span></td>
                        <td class="text-center"><span id="corebanking_result<?php echo $obj->Id_0; ?>" class="fa fa-fw text-gray fa-question f20"></span></td>
                    </tr>
                <?php $i++; endforeach; ?>
                </tbody>  
            </table>
            <?php else:?>
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun bulletin trouv&eacute;!</b></span>        
                </section>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 
<?php echo form_close();  ?>


<!-- Session script  -->    

<script type="text/javascript"  charset="utf-8">

    
    // Initialize DataTables
    table = $('#dataTable').DataTable();
    var last_value = false;
    
    $('#repartition').click(function(){
        $('#action').val('repartition');
    });
    
    get_accountname();
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'repartition')
        {
                submiter(data);
        }
        else if(action == 'emargement')
        {
                emargement(data);
        }
        else
        {
                debit_customer(data);
        }
    });
    
    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    })
    
    function gatherPaiementid() {
        const paiementid = [];
        $('input[name="paimentid[]"]').each(function(index) {
            paiementid.push({
                id: $(this).val()
            });
        });
        return paiementid;
    }
    
    function submiter(data) 
    {
        $('#repartition').prop("disabled", true);
        const paiementid = gatherPaiementid();
        repartition(0, data, paiementid);
    }
    
    function repartition(index, data, paiementid)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin'); ?>/save/validate';
        
        if(paiementid[index] !== undefined)
        {
            $('#Sydonia_44').val(paiementid[index].id);
        }
        
        if (index === paiementid.length - 1) 
		{
			// On est sur le dernier élément
			last_value = true;
			$('#Sydonia_44_next').val(paiementid[index].id);
			$('#index').val(index);
		} 
		else 
		{
			$('#Sydonia_44_next').val(paiementid[index + 1].id);
			$('#index').val(index + 1);
		}
        
        if((index) % 10 === 0)
        {
            var iteration = $('#iteration').val();
            iteration = parseInt(iteration, 10);
            iteration = iteration + 1;

            $('#iteration').val(iteration);
        }
       
        if(paiementid[index+1] !== undefined)
        {
            $("#corebanking_result"+paiementid[index].id).html('<img align="middle" height="18px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $("#corebanking_result"+paiementid[index].id).removeClass('fa fa-fw text-gray fa-question f20');
        }
        
        var data = $('#mainform').serialize();
        
        setTimeout(function() {
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){

                if(last_value)
                {
                    result_treatment();
                }
                else
                {
                    // Détruire l'ancienne instance de DataTable
                    if ($.fn.DataTable.isDataTable('#dataTable')) {
                        table.destroy();
                        $('#dataTable').empty(); // Nettoyer l'ancien contenu du tableau
                    }
                    $("#table_view").html(result);
                }
                     
                if(last_value==false)
                {
                    repartition(index+1, data, paiementid);
                }
            },
            error:function(error){
                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
        }, 500);
    }
    
    function result_treatment()
    {
        var data = $('#mainform').serialize();
        
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/result'); ?>';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-2").removeClass('bg-green-active');
                $("#step-2").addClass('bg-gray');
                $("#step-3").removeClass('bg-gray');
                $("#step-3").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    
    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert aWarning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
</script>
