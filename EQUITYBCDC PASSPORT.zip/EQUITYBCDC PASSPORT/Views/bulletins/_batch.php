<!-- Nouvelle section  -->
<div id="loader"></div>
<?php
    if (isset($_SESSION['Bank_rates'])) :
        $taux = json_decode($_SESSION['Bank_rates'], true);
        $taux_usd = $taux['Dollar_4'];
    else :
        $taux['Dollar_4'] = $taux_usd = 00;
        $taux['Euro_5']  = 00;
        $taux['Rand_6']  = 00;
    endif;
?>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">

    <div class="row">
        <div class="col-12 d-flex justify-content-end">
            <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                <button class=" btn btn-primary no-border no-radius no-margin" type="submit" id='releaseLien' <?php if($reservation_cancelled): ?> disabled <?php endif; ?> ><i class="fa fa-save text-white"></i> <span class="text-white">Débiter le compte du client</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn btn-success no-border no-radius no-margin" type="submit" id='emargement' <?php if(!$reservation_cancelled ) : ?> disabled <?php endif; ?> ><i class="fa fa-newspaper-o text-white"></i> <span class="text-white">Emargement</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn bg-gray no-border no-radius no-margin"  id="cancel"><i class="fa fa-fw fa-times f18"></i> </button>
            <?php else: ?>
                <button class=" btn btn-danger d-none no-border no-radius no-margin" type="submit" id='verify' ><i class="fa fa-history text-white"></i> <span class="text-white">Verifier</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn btn-primary no-border no-radius no-margin" type="submit" id='valider' ><i class="fa fa-save text-white"></i> <span class="text-white">Débiter le compte du client</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn btn-success no-border no-radius no-margin" type="submit" id='emargement' disabled><i class="fa fa-newspaper-o text-white"></i> <span class="text-white">Emargement</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn btn-primary no-border no-radius no-margin d-none" type="submit" id='repartition' disabled><i class="fa fa-archive text-white"></i> <span class="text-white">Répartition</span> </button>&nbsp;&nbsp;&nbsp;
                <button class=" btn bg-gray no-border no-radius no-margin" type="button" id="cancel"><i class="fa fa-fw fa-times f18"></i> </button>
            <?php endif; ?>
            <input type="hidden" value="" id="action">
        </div>
    </div>
    <br/><br/>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Bureau</label>
                        </div>
                        <div class="col-md-8">
                            <b>:</b> <?php echo isset($services['DGDA'][$paiement->Office_7]) ? $services['DGDA'][$paiement->Office_7] : "-"; ?>
                            <input type='hidden' name='Office' value='<?php echo isset($paiement->Office_7) ? $paiement->Office_7 : ""; ?>'>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="designation">Designation</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo $paiement->Designation_15; ?>
                           <input type='hidden' name='designation' value='<?php echo $paiement->Designation_15 ?>' >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="account_name">Intitul&eacute; du compte</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= $paiement->Accountholder_18; ?>
                           <input type="hidden" value="<?= $paiement->Accountholder_18; ?>" id="account_name" name="account_name"/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="account">Compte client(&agrave; d&eacute;biter)</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= $paiement->Account_16. ' CDF '; ?>
                           <input type='hidden' name='account' value='<?php echo $paiement->Account_16 ?>'>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="total_amount">Montant total</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Amount_11,2,","," ").' CDF '; ?>
                           <input type='hidden' name='total_amount' value='<?php echo $paiement->Amount_11 ?>'>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="Commission">Total commission</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Commission_20,2,","," ").' CDF';?>
                           <input name="Commission" value="<?php echo number_format($paiement->Commission_20,2,","," "); ?>" id="Commission" type="hidden" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="total_topaid">Total &agrave; payer</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($paiement->Total_23,2,","," ").' CDF'; ?>
                           <input type='hidden' name='total_topaid' value='<?php echo $paiement->Total_23 ?>'>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="account_value">Compte Guichet Unique</label>
                        </div>
                        <div class="col-md-8">
                          <b>:</b>  <?php echo $compte_guichet_unique; ?>
                          <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                          <input name="account_value" value="<?= ""; ?>" type="hidden" id="account_value" disabled="disabled" />
                          <input name="account_devise" value="CDF" type="hidden" id="account_devise" disabled="disabled" />
                        </div>
                    </div>
                </div>
                <input type='hidden' name='lot_id' value='<?php echo $paiement->Lot_14 ?>'>
                <input type='hidden' name='mode' value='7'>
                <?php $tva = $paiement->Commission_20 * 0.16; ?>
                <input type='hidden' name='tva' value='<?php echo $tva; ?>'>
                <input type='hidden' name='taux' value='<?php echo $taux_usd; ?>'>
                <input type='hidden' name='Nif' value='<?php echo $paiement->Nif_8; ?>'>
                <input type='hidden' name='Bank' value='<?php echo $paiement->Bank_10; ?>'>
                <input type='hidden' name='Agent' value='<?php echo $paiement->Agent_9; ?>'>
                <input type="hidden" name="refOp" value="<?php echo $paiement->Refop_25; ?>" />
                <input type="hidden" name="batchid" id="batchid" value="<?php echo $paiement->Id_0; ?>" />
                <input type="hidden" name="batch_id" id="" value="<?php echo $paiement->Id_0; ?>" />
                <input type="hidden" name="logirefid" value="<?php echo $paiement->Lot_14; ?>" />
                <input type="hidden" name="batch_reference" value="<?php echo $paiement->Lot_14; ?>" />
                <input type="hidden" name="devise_commision" value="CDF" />
                <input type="hidden" name="cdevise" value="<?php echo $paiement->Devise_17; ?>" />
                <input type="hidden" name="transaction_id" value="" id="transaction_id">
                <input type="hidden" name="error_code" value="" id="error_code">
            </div>
        </div>
    </div>
</div>
<br/><br/>
<div class="col-md-12 bTop">
    <div class="col-md-12">
    <br/><label>Liste des bulletins</label><br/>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-12">
        <div id="paiementslist">
            <?php if(!empty($bulletins)): ?>
            <table id="dataTable" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-gray">
                        <th width="5">#</th>
                        <th width="20">B&eacute;n&eacute;ficiaire</th>
                        <th width="10">Ann&eacute;e</th>
                        <th width="50">Bulletin</th>
                        <th width="20">Devise</th>
                        <th width="200">Montant</th>
                        <th width="80" class="text-center">Statut</th>
                    </tr>
                </thead>
                <tbody>
                <?php for ($i = 1; $i <= count($bulletins["years"]); $i++): ?>
                    <tr>
                        <td><span><b><?php echo $i; ?></b></span></td>
                        <td><b><?php echo 'DGDA'; ?></b></td>
                        <td><?php echo $bulletins["years"][$i]; ?></td>
                        <input type="hidden" value="<?php echo $bulletins["years"][$i]; ?>" name="years[<?php echo $i; ?>]" />
                        <!-- <td><php echo $bulletins["serials"][$i]. "".$bulletins["numbers"][$i]; ?></td> -->
                        <td>
                            <?php 
                                $serial = $bulletins["serials"][$i] ?? "";
                                $number = $bulletins["numbers"][$i] ?? "";

                                # Vérifie si $serial est exactement une lettre majuscule (A-Z)
                                echo preg_match('/^[A-Z]$/', $serial) 
                                    ? $serial . $number 
                                    : $serial;
                            ?>
                        </td>

                        <input type="hidden" value="<?php echo $bulletins["serials"][$i]; ?>" name="serials[<?php echo $i; ?>]" />
                        <input type="hidden" value="<?php echo $bulletins["numbers"][$i]; ?>" name="numbers[<?php echo $i; ?>]" />
                        <td><?php echo 'CDF'; ?></td>
                        <td class="text-blue"><?php echo $bulletins["amounts"][$i]; ?></td>
                        <input type="hidden" value="<?php echo $bulletins["amounts"][$i]; ?>" name="amounts[<?php echo $i; ?>]" />
                        <td class="text-center"><span id="corebanking_result<?php echo ""; ?>" class="fa fa-fw text-gray fa-question f20"></span></td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
            <?php else:?>
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun bulletin trouv&eacute;!</b></span>
                </section>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?>
<?php echo form_close(); ?>

<!-- Session script  -->

<script type="text/javascript"  charset="utf-8">

    // Initialize DataTables
    let table = $('#dataTable').DataTable();

    $('#valider').click(function(){

        $('#action').val('valider');

    });
    $('#repartition').click(function(){

        $('#action').val('repartition');

    });

    $('#emargement').click(function(){

        $('#action').val('emargement');

    });

    $('#verify').click(function(){

        $('#action').val('verify');

    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $("#releaseLien").click(function(){

        $("#action").val('releaseLien');

    });

    get_accountname();

    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'repartition')
        {
                const paiementid = gatherPaiementid();
                repartition(0, data, paiementid);
        }
        else if(action == 'emargement')
        {
                emargement(data);
        }
        else if(action == 'verify')
        {
                verify(data);
        }
        else if(action == 'releaseLien')
        {
                cancel_reservation(data);
        }
        else
        {
                debit_customer(data);
        }
    });

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });

    function gatherPaiementid() {
        const paiementid = [];
        $('input[name="paimentid[]"]').each(function(index) {
            paiementid.push({
                id: $(this).val()
            });
        });
        return paiementid;
    }

    function cancel_reservation(data)
    {
            var bank = '<?php echo $bank ?>';
            var csrf = $('input[name="csrf_name"]').val();

            if(bank == 'Boa')
            {
                    validate_amount_blocked(data);
            }
            else
            {
                    var compte = $('#account').val();
                    var devise = $('#cdevise').val();
                    var batchid = $('#batchid').val();
                    var object = "batch";

                    var url = '<?php echo base_url($module.'/taxaccounts/data/cancel_reservation'); ?>';

                    $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                    $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { compte : compte, devise : devise, batchid : batchid, object: object, csrf_name:csrf},
                            dataType    : 'json',
                            encode      : true,
                            success: function(response)
                            {
                                    $("#loader").html('');
                                    if(response.code == '200')
                                    {
                                            var data = $('#mainform').serialize();
                                            get_reservation_debit_account(data);
                                    }
                                    else if(response.code == '407')
                                    {
                                            $("#loader").html('<div class="alert aWarning text-white">Désolé, la fonctionnalité d\'annulation d\'une réservation n\'est pas configurée pour ce compte logiref, veuillez contacter votre administrateur à cet effet<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(response.code == '404')
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(response.code == '405')
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(response.code == '406')
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(response.code != '')
                                    {
                                            $('#loader').html(response.error_message);
                                    }
                                    else
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                            },
                            error:function(error)
                            {
                                    $("#loader").html('<div class="alert aDanger text-white">La reservation faite sur le compte n\'est pas annul&eacute; faute de connexion. veuillez refaire l\'op&eacute;ration.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
            }
    }

    function validate_amount_blocked(data)
    {
            var bank = '<?php echo $bank ?>';
            var csrf = $('input[name="csrf_name"]').val();

            var batchid = $('#batchid').val();

            var url = '<?php echo base_url($module.'/taxbulletin/display/validate_batch_amount_blocked'); ?>';

            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : {batchid : batchid, csrf_name:csrf},
                    dataType    : 'json',
                    encode          : true,
                    success: function(result)
                    {
                            if (result.response == "200")
                            {
                                $("#loader").html('');
                                $('#emargement').prop("disabled", false);
                                $('#releaseLien').prop("disabled", true);

                                $('#loader').html('<div class="alert aSuccess text-white">La validation de la transaction a &eacute;t&eacute faite avec succ&egrave;s, veuillez cliquer sur le bouton [Emargement] pour &eacute;marger les bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                $('#loader').html('');
                                $('#loader').html('<div class="alert aDanger text-white">'+result.message+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    },
                    error:function(error)
                    {
                            $('#loader').html('<div class="alert alert-danger text-white">L\'envoi de la requête s\'est fait avec succès mais Igor n\'a pas retourné de réponse, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function debit_customer(data)
    {
            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/debit_client_batch';

            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'json',
                    encode          : true,
                    success: function(result){

                        $("#loader").html(result);

                        if(result.code=='E407')
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#repartition').prop("disabled",true);
                                $('#valider').prop("disabled",true);
                        }
                        else
                        {
                                if(result.code == '200')
                                {
                                        $("#loader").html(result.msg);
                                        $("#emargement").prop('disabled',false);
                                }
                                else
                                {
                                        $("#loader").html(result.msg);
                                        $('#verify').removeClass('d-none');
                                        $("#valider").prop('disabled',true);

                                        $('#error_code').val(result.code);
                                        $('#transaction_id').val(result.transaction_id);
                                }
                        }
                    },
                    error:function(error){
                        $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse Finacle est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function get_reservation_debit_account(data)
    {
            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/display/debit_client_batch';

            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'json',
                    encode          : true,
                    success: function(result){

                            $("#loader").html(result);

                            if(result.code=='E407')
                            {
                                    $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de la validation de la transaction n\'est pas paramétré, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $('#repartition').prop("disabled",true);
                                    $('#valider').prop("disabled",true);
                            }
                            else
                            {
                                    if (result.code == "200")
                                    {
                                            $("#loader").html(result.msg);
                                            $('#emargement').prop("disabled", false);
                                            $('#releaseLien').prop("disabled", true);
                                    }
                                    else
                                    {
                                            $('#loader').html();
                                            $('#error_code').val(result.code);
                                            $('#transaction_id').val(result.transaction_id);
                                            $('#loader').html('<div class="alert aDanger text-white">'+result.msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                            }
                    },
                    error:function(error){
                        $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse Finacle est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function verify(data)
    {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxbulletin'); ?>/save/verify_transaction_batch';

            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'json',
                    encode      : true,
                    success: function(result){

                        if(result.code =='E407')
                        {
                            $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#repartition').prop("disabled",true);
                            $('#valider').prop("disabled",true);
                        }
                        else if(result.code =='E200')
                        {
                            $("#loader").html(result.msg);
                            $("#emargement").prop('disabled',false);
                            $("#verify").prop('disabled',true);
                        }
                        else
                        {
                            $('#loader').html(result.msg);
                        }
                    },
                    error:function(error)
                    {
                        $('#loader').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function emargement(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //$('#envoyer').prop("disabled", true);
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        var url = '<?php echo base_url('branch/taxbulletin/display/batch_confirmation'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {

                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
                $('#loader').html('');

                if(result == "E200")
                {
                    //$('#reserve').prop("disabled", true);
                    $('#reserve').addClass('d-none');
                    $('#emargement').prop("disabled", true);
                    $('#loader').html('<div class="alert alert-info">Votre paiement est en cours de traitement. Vous pouvez suivre l’évolution de vos bulletins dans le menu <strong>« Bulletins en traitement »</strong> pour suivre le statut de vos paiements.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if (result == "E34")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E22")
                {
                    scrollUP();
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E21")
                {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Code bureau non trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E18")
                {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Code banque non  trouv&eacute;. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E4")
                {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Le bureau n&apos;est sp&eacute;cifi&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if (result == "E11")
                {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                } else if (result == "E13")
                {
                    $('#loader1').html('<div class="alert aDanger text-white">Alerte: SYDONIA Server Exception!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E002")
                {
                    $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E003")
                {
                    $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else if (result == "E000")
                {
                    $('#loader').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                } 
                else if (result == "E404") 
                {
                    batch_recover(data);
                } 
                else if (result == "E405")
                {
                    batch_recover(data);
                } 
                else if (result == "E406") 
                {
                    batch_recover(data);
                } 
                else if (result == "E444") 
                {
                    batch_recover(data);
                } 
                else if (result == "E411") 
                {
                    batch_recover(data);
                } 
                else if (result == "E501") 
                {
                    $('#loader').html('<div class="alert aWarning text-white">Alerte: SYDONIA n&apos;a retourn&eacute; aucune information, reprenez l&pos;op&eacute;ration !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#envoyer').prop("disabled", true);
                    $('#extourne').removeClass('d-none');
                    $('#reserve').addClass('d-none');
                }
                else
                {
                    // Détruire l'ancienne instance de DataTable
                    if ($.fn.DataTable.isDataTable('#dataTable')) {
                        table.destroy();
                        $('#dataTable').empty(); // Nettoyer l'ancien contenu du tableau
                    }

                    $('#envoyer').prop("disabled", false);
                    $('#envoyer').html(button);
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');
                    $("#list").html(result);
                }
            },
            error: function(error) {
                scrollUP();
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
                $('#loader').html('<div class="alert aWarning text-white">La confirmation a pris beaucoup de temps, veuillez checker votre connexion internet, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function get_accountname() {

        var chtml = $("#accountname").html();
        var compte = '';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {

                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {

                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert aWarning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

</script>