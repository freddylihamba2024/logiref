<?php $montant_total = 0; ?>
<div class="row">
    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
        <div class="row">
            <div class="col-md-3 center padding-2">
                <div class="col-md-12 center">
                    <p class="page-header">
                        <br /><br /> G&eacute;n&eacute;rez la quittance de ce lot de paiement et consultez les d&eacute;tails de chaque bulletin sur la liste.
                    </p>
                </div>
            </div>
            <div class="col-md-9 bLeft">
                <div class="row">
                    <div class="col-md-12 pl-5">
                        <div class="row">
                            <div class="col-md-12">
                                <br/><br/>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 no-padding">
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4 no-padding">
                                        <label for="office">Montant total</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <span id="total_amount"></span>
                                    </div>
                                </div>
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4 no-padding">
                                        <label for="office">Total des paiements</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <?php echo  count($bulletins); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4 no-padding">
                                        <label for="office">Bureau</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <?php echo $services['DGDA'][$office]; ?>
                                    </div>
                                </div>
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4 no-padding">
                                        <label for="office">Compte guichet unique</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b> <?php echo $cGuichet; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 bTop">
                        <?php echo form_open_multipart('', array('id' => 'savePay', 'class' => '')); ?>

                        <input type="hidden" name="Compte_33" value="<?php echo $account; ?>" />
                        <input type="hidden" name="Devise_34" value="<?php echo $currency; ?>" />
                        <input type="hidden" name="balance" value="<?php echo $balance; ?>" />
                        <input type="hidden" name="accountname" value="<?php echo $accountname; ?>" />
                        <input type="hidden" name="designation" value="<?php echo $designation; ?>" />

                        <div class="box-body">
                            <input type="hidden" value="<?php echo $Logirefid; ?>" name="Logirefid" />
                            <?php if (!empty($bulletins)) : ?>
                                <table id="tableREN1" class="table table-hover table-striped">
                                    <thead>
                                        <tr class="bg-gray">
                                            <th width="5px">#</th>
                                            <th width="50px">Quittance</th>
                                            <th width="50px">Bulletin</th>
                                            <th width="50px">Ann&eacute;e</th>
                                            <th>Montant</th>
                                            <th width="10px" style="text-align:center;"><i class="fa fa-tasks f20"></i></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; foreach ($bulletins as $obj) : ?>
                                            <tr id="line<?php echo $obj->Id_0; ?>">
                                                <td width=""><?php echo $i; ?></td>
                                                <td id="result<?php echo $obj->Id_0; ?>">
                                                    <?php $BL = json_decode($obj->Results_13); echo $BL->receiptSerial . ' ' . $BL->receiptNumber; ?>
                                                </td>
                                                <td width=""><?php echo $obj->Serie_7 . ' ' . $obj->Number_8; ?></td>
                                                <td width=""><?php echo $obj->Year_5; ?></td>
                                                <td><?php echo number_format($obj->Amount_12, 2, ".", ","); ?></td>
                                                <td align="center" width="" id="pq<?php echo $obj->Id_0; ?>">
                                                    <a style="cursor: pointer" onclick="view('<?php echo $obj->Id_0; ?>')">
                                                        <i class="fa fa-fw fa-file-text f20"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php $montant_total += $obj->Amount_12;  ?>
                                        <?php $i++; endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else : ?>
                                <section>
                                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br />
                                        <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute;e!</b></h4>
                                        <br />
                                    </div>
                                </section>
                            <?php endif; ?>
                        </div>
                        <div class="box-footer clearfix">
                            <button id="sub" type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
    
    <div class="modal fade" id="modal">
        <div class="modal-dialog modal-lg modal-fullscreen-lg-down"> <!-- Ajout des classes pour plein écran sur lg -->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="title">Bulletin de liquidation</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div id="modal-pager" class="modal-body">
                    <p>One fine body&hellip;</p>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

</div>

<script type="text/javascript">
    var logirefid = '';
    var ref = '';

    $("#total_amount").html('<?= $montant_total ?>');

    $("#savePay").submit(function(event) {
        event.preventDefault();
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var data = $("#savePay").serialize();
        var url = '<?php echo base_url('branch/taxbulletin/save/save_batch'); ?>';
        $('#sub').prop("disabled", true);
        
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {

                if (isNaN(result) == true) {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                    $("#step-2").removeClass('bg-green-active');
                    $("#step-2").addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray');
                    $("#step-3").addClass('bg-green-active');

                } else if (result > 0) {
                    $("#loader-sub-menu").html('<div class="alert aSuccess  text-white">Bravo! paiements encaiss&eacute;s avec succ&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $("#loader-sub-menu").html('');
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">ERREUR : L\'encaissement du paiement a &eacute;chou&eacute;, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                alert('ERROR!' + error);
            }
        });
    });

    $('#tableREN1').DataTable({
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    function view(bId) {
        var url = '<?php echo base_url('branch/taxbulletin/display/edit'); ?>/' + bId;
        $.get(url, function(data, status) {
            $("#loader-sub-menu").html('');
            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }

    $("#buttonCloseModal").click(function() {
        location.reload(true);
    });

    $(document).ready(function(){
        $("#confirm").prop("disabled", true);
    });


    

</script>