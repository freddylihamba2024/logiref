<div class="col-md-12 mt-4" id='pager'>
    <div class="box box-solid shadow-sm border rounded" >
        <div class="box-header py-3 px-4 border-bottom bg-light">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div class="w-100">
                    <h1 class="f25 text-blue mb-1" >
                        Intégration des bulletins par bureau
                    </h1>
                    <p class="page-header text-muted mb-0 f13">
                        Extraction des fichiers par bureau de douane
                    </p>
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="mt-3 p-3 bg-white border rounded shadow-sm">
                        <div class="row align-items-end g-2">
                            
                            <!-- Date de traitement -->
                            <div class="col-md-4">
                                <label for="filter_date" class="form-label f12 fw-bold text-muted">
                                    📅 Date de traitement
                                </label>
                                <input
                                    type="input"
                                    id="filter_date"
                                    name="filter_date"
                                    class="form-control form-control-sm"
                                >
                            </div>

                            <!-- Type de paiement -->
                            <div class="col-md-4">
                                <label for="payment_type" class="form-label f12 fw-bold text-muted">
                                    Type de paiement
                                </label>
                                <select
                                    id="payment_type"
                                    name="payment_type"
                                    class="form-select  form-control form-select-sm"
                                >
                                    <option value="branch">Paiement agence</option>
                                    <option value="branchless">Paiement en ligne</option>
                                </select>
                            </div>

                            <div class="col-md-2 d-flex align-items-center">
                                <button
                                    type="button"
                                    id="btn-filter"
                                    class="btn btn-sm w-100"
                                >
                                    🔍 Filtrer
                                </button>

                                <!-- Loader circulaire -->
                                <div id="filter-loader" class="ms-5" style="display:none;">
                                    <div class="spinner-border spinner-border-sm" role="status"></div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                </div>
                <div class="header-divider mt-3 mt-md-0"></div>
            </div>
        </div>
    
        <div >
            <div id='filterResult'>
                <div class="col-md-12 px-0">
                    <?php if(!empty($files_instructions_data)): ?>
                   
                    <input type="hidden" name="type_integration" value="branch" />
                    <div class="box-body p-4 bg-light">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="integration-table">
                                <thead class="bg-blue text-center text-black">
                                    <tr>
                                        <th>Bureau</th>
                                        <th>Montant total à débiter</th>
                                        <th>Montant total à créditer</th>
                                        <th>Compte guichet unique</th>
                                        <th>Nombre de bulletins</th>
                                        <th>Nombre d’instructions</th>
                                        <th>Détails</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white text-center">
                                    <?php

                                    if(isset($treatment_on_going->Id_0))
                                    {
                                            $integrationsftpid = json_decode($treatment_on_going->Integrationsftpid_14, true);

                                            foreach($files_instructions_data as $row)
                                            { 
                                                $json_data = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                                    ?>
                                                <tr>
                                                    <td><?php echo $services['DGDA'][$row->office] ?></td>
                                                    <input type='hidden' name='file_line[]' value='<?php echo $json_data ?>' >
                                                    <td>CDF <?= number_format($row->amount_debited_by_office, 2, ",", " "); ?></td>
                                                    <td>CDF <?= number_format($row->amount_credited_by_office, 2, ",", " "); ?></td>
                                                    <td><?= $row->bank_account; ?></td>
                                                    <td><?= $row->nb_bulletins_by_office; ?></td>
                                                    <td><?= $row->nb_instructions_by_office; ?></td>
                                                    <td>
                                                        <button class="accordion-btn" id="details-<?= $row->office ?>" data-office="<?= $row->office ?>" data-target="<?= $row->office ?>" data-journalisation="<?= $json_data ?>">Voir détails</button>
                                                    </td>
                                                    <td class="text-center">
                                                        <button 
                                                            type="button"
                                                            class="btn btn-primary btn-xs btn-send-office"
                                                            data-office="<?= $row->office ?>" data-office-integration ="<?= isset($integrationsftpid[$row->office][0]) ? $integrationsftpid[$row->office][0] : 0 ?>"
                                                        >
                                                            Envoyer
                                                        </button>
                                                    </td>
                                                </tr>
                                                <tr class="details-row" id="<?= $row->office ?>">
                                                    <td colspan="8">
                                                        <div class="details-content">
                                                            <h6>Détails du bureau <?= $services['DGDA'][$row->office] ?> :</h6>
                                                            <div id="details-body-<?= $row->office ?>" class="details-body">

                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                    <?php 
                                            } 
                                    }
                                    else
                                    {
                                            foreach($files_instructions_data as $row)
                                            { 
                                                $json_data = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                                    ?>
                                                <tr>
                                                    <td><?php echo $services['DGDA'][$row->office] ?></td>
                                                    <input type='hidden' name='file_line[]' value='<?php echo $json_data ?>' >
                                                    <td>CDF <?= number_format($row->amount_debited_by_office, 2, ",", " "); ?></td>
                                                    <td>CDF <?= number_format($row->amount_credited_by_office, 2, ",", " "); ?></td>
                                                    <td><?= $row->bank_account; ?></td>
                                                    <td><?= $row->nb_bulletins_by_office; ?></td>
                                                    <td><?= $row->nb_instructions_by_office; ?></td>
                                                    <td>
                                                        <button class="accordion-btn" id="details-<?= $row->office ?>" data-office="<?= $row->office ?>" data-target="<?= $row->office ?>" data-journalisation="<?= $json_data ?>">Voir détails</button>
                                                    </td>
                                                    <td class="text-center">
                                                        <button 
                                                            type="button"
                                                            class="btn btn-primary btn-xs btn-send-office"
                                                            data-office="<?= $row->office ?>" data-office-integration =""
                                                        >
                                                            Envoyer
                                                        </button>
                                                    </td>
                                                </tr>
                                                <tr class="details-row" id="<?= $row->office ?>">
                                                    <td colspan="8">
                                                        <div class="details-content">
                                                            <h6>Détails du bureau <?= $services['DGDA'][$row->office] ?> :</h6>
                                                            <div id="details-body-<?= $row->office ?>" class="details-body">

                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php 
                                            } 
                                    }

                                    ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Total et actions -->
                        <div class="row align-items-center mt-4">
                            <div class="col-md-6">
                                <div class="p-3 border rounded bg-white shadow-sm">
                                    <p class="mb-0 fw-bold text-dark">
                                        🔢 <span class="text-uppercase">Total des fichiers d’intégration à générer :</span>
                                        <span class=" text-white fs-6 px-3 py-2" style="background-color: #007bff; border-radius: 8px"><?php echo count($files_instructions_data) ?> fichiers</span>
                                    </p>
                                </div>
                            </div>

                            <div class="col-md-6 text-end">
                                <button id="btn-create" class="btn btn-success btn-sm px-3 me-2 shadow-sm" type="submit">
                                    <i class="fa fa-cogs"></i> Créer les fichiers
                                </button>
                            </div>
                        </div>

                        <!-- Progression -->
                        <div class="mt-4">
                            <div class="progress" style="height:14px; border-radius: 8px; overflow:hidden;">
                                <div id="progress-bar" class="progress-bar progress-bar-striped bg-success" style="width: 0%"></div>
                            </div>
                            <p class="text-center mt-2 mb-0 fw-bold text-muted f12" id="progress-text">
                                0% - En attente du traitement...
                            </p>
                            <input type="hidden" name="progression" id="progression" value="" >
                            <?php if(isset($treatment_on_going->Id_0)): ?>
                                <input type="hidden" name="integrationid" id="integrationid" value="<?php echo $treatment_on_going->Integrationsftpid_14 ?>" >
                                <input type="hidden" name="offices" id="officeids" value='<?= htmlspecialchars($treatment_on_going->Officespending_17, ENT_QUOTES, "UTF-8") ?>'>
                                <input type="hidden" name="offices_treated" id="offices_treated" value='<?= htmlspecialchars($treatment_on_going->Officestreated_15, ENT_QUOTES, "UTF-8") ?>'>
                            <?php else: ?>
                                <input type="hidden" name="integrationid" id="integrationid" value="" >
                                <input type="hidden" name="offices" id="officeids" value="" >
                                <input type="hidden" name="offices_treated" id="offices_treated" value="">
                            <?php endif; ?>
                        </div>
                        <input type="hidden" name="action" value="" id="action">


                        <!-- Zone des messages -->
                        <div id="loader1" class="mt-3"></div>
                        <br/><br/>
                    </div>
                    
                    <?php else: ?>
                        <?php $chtml->box_body_opening(); ?> 
                            <section id="cat_list" class="mt-5 mb-5 text-center "><br/><br/><br/><br/><br/><br/>
                               <span class="d-block"><i class="fa fa-flask text-gray mystyle4" ></i></span>
                               <span class="d-block f14 text-black p-2">Aucun traitement d'integration à faire pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                            </section>
                        <?php $chtml->box_body_closing(); ?> 
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    
$('#filter_date').datepicker({
    todayHighlight: true,
    clearBtn: true,
    format: 'yyyy-mm-dd'
});

$("#pager").on("click", "#btn-filter", function() {

    const date = $('#filter_date').val();
    const paymentType = $('#payment_type').val();

    if (!date) {
        alert('Veuillez sélectionner une date');
        return;
    }
    
    // afficher loader
    $('#filter-loader').show();
    
    // désactiver bouton
    $('#btn-filter').prop('disabled', true).text('Filtrage...');
    var csrf = $('input[name="csrf_name"]').val();

    const url = '<?= base_url($module . '/taxbulletin/display/filter_integration_treatment') ?>';

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            filter_date: date,
            payment_type: paymentType,
            csrf_name:csrf
        },
        dataType: 'html',
        success: function (result) {
            $('#loader').html('');
            $('#filterResult').html(result);
            
            $('#filter-loader').hide();
            $('#btn-filter').prop('disabled', false).text('🔍 Filtrer');
        },
        error: function (error) {
            $('#loader').html('');
            alert('Erreur lors du filtrage');
            console.error(error);
        }
    });
});


   

</script>



