<div class="col-md-12 mt-4">
    <div class="box box-solid shadow-sm border rounded">
        <div class="box-header py-3 px-4 border-bottom bg-light">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h1 class="f25 text-blue mb-1" >
                        Intégration des bulletins par bureau
                    </h1>
                    <p class="page-header text-muted mb-0 f13">
                        Extraction des fichiers par bureau de douane
                    </p>
                </div>
                <div class="header-divider mt-3 mt-md-0"></div>
            </div>
        </div>

        <div class="col-md-12">
            <?php if(!empty($files_instructions_data)): ?>
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <input type="hidden" name="type_integration" value="branch" />
            <div class="box-body p-4 bg-light">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped" id="integration-table">
                        <thead class="bg-blue text-center text-black">
                            <tr>
                                <th>Bureau</th>
                                <th>Montant total à débiter</th>
                                <th>Montant total à créditer</th>
                                <th>Compte guichet unique</th>
                                <th>Nombre de bulletins</th>
                                <th>Nombre d’instructions</th>
                                <th>Détails</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white text-center">
                            <?php
                            
                            if(isset($treatment_on_going->Id_0))
                            {
                                    $integrationsftpid = json_decode($treatment_on_going->Integrationsftpid_14, true);
                                    
                                    foreach($files_instructions_data as $row)
                                    { 
                                        $json_data = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                            ?>
                                        <tr>
                                            <td><?php echo $services['DGDA'][$row->office] ?></td>
                                            <input type='hidden' name='file_line[]' value='<?php echo $json_data ?>' >
                                            <td>CDF <?= number_format($row->amount_debited_by_office, 2, ",", " "); ?></td>
                                            <td>CDF <?= number_format($row->amount_credited_by_office, 2, ",", " "); ?></td>
                                            <td><?= $row->bank_account; ?></td>
                                            <td><?= $row->nb_bulletins_by_office; ?></td>
                                            <td><?= $row->nb_instructions_by_office; ?></td>
                                            <td>
                                                <button class="accordion-btn" id="details-<?= $row->office ?>" data-office="<?= $row->office ?>" data-target="<?= $row->office ?>" data-journalisation="<?= $json_data ?>">Voir détails</button>
                                            </td>
                                            <td class="text-center">
                                                <button 
                                                    type="button"
                                                    class="btn btn-primary btn-xs btn-send-office"
                                                    data-office="<?= $row->office ?>" data-office-integration ="<?= isset($integrationsftpid[$row->office][0]) ? $integrationsftpid[$row->office][0] : 0 ?>"
                                                >
                                                    Envoyer
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="details-row" id="<?= $row->office ?>">
                                            <td colspan="8">
                                                <div class="details-content">
                                                    <h6>Détails du bureau <?= $services['DGDA'][$row->office] ?> :</h6>
                                                    <div id="details-body-<?= $row->office ?>" class="details-body">

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                            <?php 
                                    } 
                            }
                            else
                            {
                                    foreach($files_instructions_data as $row)
                                    { 
                                        $json_data = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                            ?>
                                        <tr>
                                            <td><?php echo $services['DGDA'][$row->office] ?></td>
                                            <input type='hidden' name='file_line[]' value='<?php echo $json_data ?>' >
                                            <td>CDF <?= number_format($row->amount_debited_by_office, 2, ",", " "); ?></td>
                                            <td>CDF <?= number_format($row->amount_credited_by_office, 2, ",", " "); ?></td>
                                            <td><?= $row->bank_account; ?></td>
                                            <td><?= $row->nb_bulletins_by_office; ?></td>
                                            <td><?= $row->nb_instructions_by_office; ?></td>
                                            <td>
                                                <button class="accordion-btn" id="details-<?= $row->office ?>" data-office="<?= $row->office ?>" data-target="<?= $row->office ?>" data-journalisation="<?= $json_data ?>">Voir détails</button>
                                            </td>
                                            <td class="text-center">
                                                <button 
                                                    type="button"
                                                    class="btn btn-primary btn-xs btn-send-office"
                                                    data-office="<?= $row->office ?>" data-office-integration =""
                                                >
                                                    Envoyer
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="details-row" id="<?= $row->office ?>">
                                            <td colspan="8">
                                                <div class="details-content">
                                                    <h6>Détails du bureau <?= $services['DGDA'][$row->office] ?> :</h6>
                                                    <div id="details-body-<?= $row->office ?>" class="details-body">

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php 
                                    } 
                            }
                            
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Total et actions -->
                <div class="row align-items-center mt-4">
                    <div class="col-md-6">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <p class="mb-0 fw-bold text-dark">
                                🔢 <span class="text-uppercase">Total des fichiers d’intégration à générer :</span>
                                <span class=" text-white fs-6 px-3 py-2" style="background-color: #007bff; border-radius: 8px"><?php echo count($files_instructions_data) ?> fichiers</span>
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6 text-end">
                        <button id="btn-create" class="btn btn-success btn-sm px-3 me-2 shadow-sm" type="submit">
                            <i class="fa fa-cogs"></i> Créer les fichiers
                        </button>
                    </div>
                </div>

                <!-- Progression -->
                <div class="mt-4">
                    <div class="progress" style="height:14px; border-radius: 8px; overflow:hidden;">
                        <div id="progress-bar" class="progress-bar progress-bar-striped bg-success" style="width: 0%"></div>
                    </div>
                    <p class="text-center mt-2 mb-0 fw-bold text-muted f12" id="progress-text">
                        0% - En attente du traitement...
                    </p>
                    <input type="hidden" name="progression" id="progression" value="" >
                    <?php if(isset($treatment_on_going->Id_0)): ?>
                        <input type="hidden" name="integrationid" id="integrationid" value="<?php echo $treatment_on_going->Integrationsftpid_14 ?>" >
                        <input type="hidden" name="offices" id="officeids" value='<?= htmlspecialchars($treatment_on_going->Officespending_17, ENT_QUOTES, "UTF-8") ?>'>
                        <input type="hidden" name="offices_treated" id="offices_treated" value='<?= htmlspecialchars($treatment_on_going->Officestreated_15, ENT_QUOTES, "UTF-8") ?>'>
                    <?php else: ?>
                        <input type="hidden" name="integrationid" id="integrationid" value="" >
                        <input type="hidden" name="offices" id="officeids" value="" >
                        <input type="hidden" name="offices_treated" id="offices_treated" value="">
                    <?php endif; ?>
                </div>
                <input type="hidden" name="action" value="" id="action">
                
                
                <!-- Zone des messages -->
                <div id="loader1" class="mt-3"></div>
                <br/><br/>
            </div>
            <?php echo form_close(); ?>
            <?php else: ?>
                <?php $chtml->box_body_opening(); ?> 
                    <section id="cat_list" class="mt-5 mb-5 text-center "><br/><br/><br/><br/><br/><br/>
                       <span class="d-block"><i class="fa fa-flask text-gray mystyle4" ></i></span>
                       <span class="d-block f14 text-black p-2">Aucun traitement d'integration à faire pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                    </section>
                <?php $chtml->box_body_closing(); ?> 
            <?php endif; ?>
        </div>
    </div>
</div>

<script type="text/javascript">
    
$('.accordion-btn').click(function() {
    var targetId = $(this).data('target');
    var journalisation=$(this).data('journalisation');

    var $row = $('#' + targetId);
    if ($row.is(':visible')) {
        $row.hide();
    } else {
        $row.show();
        get_office_bulletins(journalisation)
    }
});   

function get_office_bulletins(journalisation_data) {
    
    <?php if (isset($treatment_on_going->Status_2) && $treatment_on_going->Status_2 == '2'): ?>
        var url = '<?= base_url($module . '/taxbulletin/display/_integration_details_filter') ?>';
    <?php else: ?>
        var url = '<?= base_url($module . '/taxbulletin/display/_integration_details') ?>';
    <?php endif; ?>
    
    var bulletin_ids = journalisation_data.bulletins_ids;
    var office = journalisation_data.office;

    $(`#details-${office}`).prop('disabled',true);
    $(`#details-${office}`).html('<div class="spinner-border text-light" role="status"></div>');
    $(`#details-body-${office}`).html("");
    var csrf = $('input[name="csrf_name"]').val();
    
    $.post(url, {
        bulletins_ids: bulletin_ids,
        csrf_name:csrf
    }, function(response) {
        $(`#details-${office}`).prop('disabled',false);
        $(`#details-${office}`).html('Voir détails');
        $(`#details-body-${office}`).html(response);
    }).fail(function(err) {
        alert("Une erreur inattendue est survenue");
        $(`#details-${office}`).prop('disabled',false);
        $(`#details-${office}`).html('Voir détails');
    });

}
    
$(function () {

    $('.btn-send-office').prop('disabled', true);
    let sendingInProgress = false;
    let progress = 0;

    /* =========================
       ÉTAT INITIAL (reprise)
    ========================== */

    <?php if (isset($treatment_on_going->Status_2) && $treatment_on_going->Status_2 == '2'): ?>
        $('#btn-create').prop('disabled', true);
        $('#btn-send').removeClass('disabled');
        
        // Activer les boutons d’envoi
        $('.btn-send-office').prop('disabled', false);
    
        progress = 10;
        update_progress(progress, "Fichiers créés avec succès. Prêt pour l’envoi.");
        $('#loader1').html(
            '<div class="alert alert-info f12 mt-2">✅ Fichiers créés avec succès. Vous pouvez maintenant les envoyer.</div>'
        );
    <?php endif; ?>

    /* =========================
       ACTIONS GLOBALES
    ========================== */

    $('#btn-create').on('click', function () {
        $('#action').val('create_file');
    });

    $('#mainform').on('submit', function (event) {
        event.preventDefault();

        let action = $('#action').val();

        if (action === 'create_file') {

            <?php if (isset($treatment_on_going->Id_0) && $treatment_on_going->Id_0 != ''): ?>
                create_file('<?php echo $treatment_on_going->Id_0; ?>');
            <?php else: ?>
                save_integration_sftp($(this).serialize());
            <?php endif; ?>
        }
    });

    /* =========================
       UTILITAIRES
    ========================== */

    function update_progress(value, message) {
        if (value > 100) value = 100;
        $('#progress-bar').css('width', value + '%');
        $('#progress-text').text(Math.round(value) + '% - ' + message);
        $('#progression').val(value);
    }

    /* =========================
       SAUVEGARDE INTÉGRATION
    ========================== */

    function save_integration_sftp(data) {

        $('#loader1').html('<img height="30" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url($module.'/taxbulletin'); ?>/save/integration_sftp',
            data: data,
            dataType: 'html',
            success: function (result) {

                if (result > 0) {
                    create_file(result);
                } else {
                    $('#loader1').html('<div class="alert alert-danger">❌ Échec de création.</div>');
                }
            },
            error: function () {
                $('#loader1').html('<div class="alert alert-danger">❌ Erreur serveur.</div>');
            }
        });
    }

    /* =========================
       CRÉATION DES FICHIERS
    ========================== */

    function create_file(id) {

        $('#loader1').html('<img height="30" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url($module.'/taxbulletin'); ?>/data/create_file_xml/' + id,
            data: $('#mainform').serialize(),
            dataType: 'json',
            success: function (result) {

                if (result.code !== 200) {
                    $('#loader1').html('<div class="alert alert-danger">❌ Création échouée.</div>');
                    return;
                }

                // Tous les bureaux
                $('#officeids').val(JSON.stringify(result.bureau));

                // Aucun bureau encore envoyé
                $('#offices_treated').val(JSON.stringify([]));

                // Mapping bureau → integration ID
                $.each(result.integrationids, function (office, ids) {
                    let integrationId = ids[0];
                    $('.btn-send-office[data-office="' + office + '"]')
                        .attr('data-office-integration', integrationId);
                });
                
                $('.btn-send-office').prop('disabled', false);

                $('#btn-create').addClass('disabled');
                $('#btn-send').removeClass('disabled');

                progress = 10;
                update_progress(progress, "Fichiers créés avec succès. Prêt pour l’envoi.");

                $('#loader1').html(
                    '<div class="alert alert-info f12 mt-2">✅ Fichiers créés avec succès.</div>'
                );
            },
            error: function () {
                $('#loader1').html('<div class="alert alert-danger">❌ Erreur serveur.</div>');
            }
        });
    }

    /* =========================
       ENVOI INDIVIDUEL PAR BUREAU
    ========================== */

    $(document).on('click', '.btn-send-office', function () {

        if (sendingInProgress) return;

        const $btn = $(this);
        if ($btn.hasClass('btn-sent')) return;

        send_office_file(
            $btn.data('office'),
            $btn.data('office-integration'),
            $btn
        );
    });

    async function send_office_file(office, integrationId, $btn) {

        sendingInProgress = true;

        $('.btn-send-office').prop('disabled', true);
        $btn.html('⏳ Envoi...');

        try {

            const result = await $.ajax({
                type: 'POST',
                url: '<?php echo base_url($module.'/taxbulletin'); ?>/data/send_file_integration',
                data: $('#mainform').serialize()
                    + '&office=' + office
                    + '&integration_id=' + integrationId,
                dataType: 'json'
            });

            if (result.code !== 200) throw result;

            mark_office_as_sent(office, $btn);
            update_progress_by_state();

            $('#loader1').html(
                `<div class="alert alert-success f12 mt-2">
                    ✅ Bureau <strong>${office}</strong> envoyé avec succès.
                </div>`
            );

        } catch (e) {

            restore_buttons();

            $('#loader1').html(
                `<div class="alert alert-danger f12 mt-2">
                    ❌ Échec de l’envoi pour le bureau <strong>${office}</strong>.
                </div>`
            );
        }

        sendingInProgress = false;
    }

    /* =========================
       ÉTAT / PROGRESSION
    ========================== */

    function mark_office_as_sent(office, $btn) {

        $btn
            .prop('disabled', true)
            .addClass('btn-sent')
            .html('✔ Envoyé');

        let treated = $('#offices_treated').val()
            ? JSON.parse($('#offices_treated').val())
            : [];

        if (!treated.includes(office)) {
            treated.push(office);
            $('#offices_treated').val(JSON.stringify(treated));
        }

        $('.btn-send-office').each(function () {
            if (!$(this).hasClass('btn-sent')) {
                $(this).prop('disabled', false).html('Envoyer');
            }
        });
    }

    function restore_buttons() {
        $('.btn-send-office').each(function () {
            if (!$(this).hasClass('btn-sent')) {
                $(this).prop('disabled', false).html('Envoyer');
            }
        });
    }

    function update_progress_by_state() {

        const total = JSON.parse($('#officeids').val()).length;
        const treated = $('#offices_treated').val()
            ? JSON.parse($('#offices_treated').val()).length
            : 0;

        let percent = Math.round((treated / total) * 100);
        if (percent < 10) percent = 10;

        update_progress(percent, `📤 ${treated}/${total} bureaux envoyés`);

        if (treated === total) {
            update_progress(100, "🎉 Tous les fichiers ont été envoyés !");
        }
    }

    /* =========================
       RESTAURATION APRÈS REFRESH
    ========================== */

    (function restore_after_refresh() {

        if (!$('#offices_treated').val()) return;

        let treated = JSON.parse($('#offices_treated').val());

        treated.forEach(function (office) {
            $('.btn-send-office[data-office="' + office + '"]')
                .prop('disabled', true)
                .addClass('btn-sent')
                .html('✔ Envoyé');
        });

        update_progress_by_state();
    })();
    
    

});
</script>



