<?php
// Convertir les valeurs en entier pour éviter les erreurs de comparaison de type
$values = array_map('intval', $paiement_result);

$has300 = in_array(300, $values);
$has200 = in_array(200, $values);
?>

<div id="loader"></div>

<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>

<div class="">
    <div class="col-md-12">
        <div class="row">
            <div class="container mt-5 mb-5">
                <div class="card text-center">
                    <div class="card-body">
                        <?php if ($has300 && $has200): ?>
                            <!-- Échec partiel -->
                            <i class="fa fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                            <h4 class="card-title">Opération échouée partiellement</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a été faite partiellement, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>

                        <?php elseif ($has300): ?>
                            <!-- Échec total -->
                            <i class="fa fa-times-circle fa-3x text-danger mb-3"></i>
                            <h4 class="card-title">Opération échouée</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a échoué, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>

                        <?php elseif ($has200): ?>
                            <!-- Succès total -->
                            <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
                            <h4 class="card-title">Opération réussie</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a été faite avec succès, 
                                veuillez cliquer sur le bouton [Générer la quittance] pour télécharger la quittance.
                            </p>
                            <button type="button" id="quittance" class="btn btn-primary">Générer la quittance</button>
                            <br/><br/><br/><br/>
                        <?php else: ?>
                            <!-- Échec total -->
                            <i class="fa fa-times-circle fa-3x text-danger mb-3"></i>
                            <h4 class="card-title">Opération échouée</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a échoué, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>
                        <?php endif; ?>
                    </div>
                    <br/><br/><br/><br/>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script type="text/javascript">
    
    $("#quittance").click(function() {

        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var button = $(this).html();

        $(this).html('<span>T&eacute;l&eacute;chargement...</span>');
        var paiementid = '<?= $paiementid ?>';

        var url = '<?php echo base_url($module . '/taxbulletin/display/getquittance'); ?>/' + paiementid;

        $.ajax({
            type: 'POST',
            url: url,
            dataType: 'html',
            encode: true,
            success: function(result) {

                $(this).prop("disabled", false);
                $('#quittance').html(button);
                $('#loader1').html('');

                if (result === "E003") {
                    $('#loader1').html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E34") {
                    $('#loader1').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E22") {
                    $('#loader1').html('<div class="alert aDanger text-white">Alerte: Aucun bulletin de liquidation  trouve. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E11") {
                    $('#loader1').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E002") {
                    $('#loader1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E001") {
                    $('#loader1').html('<div class="alert aWarning text-white">Impossible d\'imprimer la quittance veuillez contacter votre administrateur!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E003") {
                    $('#loader1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E000") {
                    $('#loader1').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E005") {
                    $('#loader1').html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E404" || result === "E41") {
                    $("#loader1").html('<div class="alert aWarning text-white">Alerte: serveur SYDONI 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    printQuittance(result);
                }

            },
            error: function(error) {
                $("#loader1").html('<div class="alert aWarning text-white">L\'impression de la quittance a pris beaucoup de temps, veuillez checker votre connexion puis réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#envoyer').prop("disabled", false);
                $('#envoyer').html(button);
            }
        });

    });
    
    function printQuittance(file)
    {
        var url = '<?php echo base_url('drive/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
    }
    
</script>