<?php $userid = $this->session->userdata["user_id"]; ?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div class="col-md-10">
    <div class="col-md-12 <?= $title; ?>" >
            <h1>Gestion des agences bancaires</h1>
            <h5 class="page-header"><span class="text-gray">Trouvez ici la liste des agences bancaires.</span></h5>
    </div>
    <div class="col-md-12">
        <div id="loader"></div>
    </div>
    <div class="col-md-12">
            <?php $chtml->box_body_opening('', true); ?>
                    <?php if(!empty($guichets)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th width="5">#</th>
                                <th width="5">Code agence</th>
                                <th width="150">Angeces Bancaires</th>
                                <th>Adresse</th>
                                <th width="100">Agences BCC</th>
                                <th>Maker</th>
                                <th>Checker</th>
                                <th width="80">Validation</th>
                                <th><span class="fa fa-fw fa-edit f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        foreach($guichets as $row){
                        ?>
                            <tr>
                                <td width="5"><?php echo $row->Id_0; ?></td>
                                <td width="5"><?php echo $row->Code_10; ?></td>
                                <td width="150"><?php if($row->Status_2==1) echo '<b>'.$row->Nom_4.'</b>'; else echo '<span class="text-red">'.$row->Nom_3.'</span>'; ?></span></td>
                                <td class="bleu"><?php echo $row->Adresse_8;?></td>
                                <td width="100"><?php echo $agences[$row->Agence_5];?></td>
                                <td><?php echo (isset($users[$row->Makerid_13]))? $users[$row->Makerid_13] :' - ';?></td>
                                <td><?php echo (isset($users[$row->Checkerid_11]))? $users[$row->Checkerid_11] :' - ';?></td>
                                <td width="80">
                                    <?php if($row->Checkerid_11==0){ ?>
                                      <span class="text-red"> En attente </span>
                                    <?php }else {?>
                                      <?php echo $row->Validation_12;?>
                                    <?php } ?>
                                </td>
                                <td width="15" align="right">
                                    <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2){ ?>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                    <?php }else {?>
                                    <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>    
                    </table>
                    <?php else: ?>

                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            Aucun guichet trouv&eacute; ! <br/>
                            </div>
                        </section>
                    <?php endif;?>
            <?php $chtml->box_body_closing(); ?> 	
            
    </div>
</div>
<div class="col-md-2">
    <div class="col-md-12 <?= $title; ?>">
        <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
        <br/><br/>
    </div>
    
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});
$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        <?php if($_SESSION['Logiref_role']==1){ ?>
        $.get("<?php echo base_url($module.'/taxbranches/display/guichet'); ?>", function(data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });
        <?php }else { ?>
            $("#loader").html('<div class="alert alert-warning text-white">D&eacute;sol&eacute! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
        <?php } ?>
});

$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});
function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/taxbranches/display/guichet'); ?>/' + id +'/<?php echo $from ?>';
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
      });
}
</script>
