<?php if($guichet->Id_0 > 0) $title='Modifier'; else $title ='Nouvelle agence' ?>

<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h2><?php echo $title;?></h2>
    <p class="page-header"></p>
    <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
    <?php $chtml->box_body_opening('', true);?>
        <div class="box-body">
            <div class="col-md-4">
                <div class="form-group">
                      <label for="Code_10">Code</label>
                      <?php echo form_input('Code_10', set_value('Code_10', $guichet->Code_10), 'class="form-control" required="required" maxlength="10"'); ?>
                </div>    
            </div>
            
            <div class="col-md-8">
                <div class="form-group">
                      <label for="Nom_4">Nom</label>
                      <?php echo form_input('Nom_4', set_value('Nom_4', $guichet->Nom_4), 'class="form-control" required="required"'); ?>
                      <input name="Id_0" type="hidden" value="<?php echo $guichet->Id_0; ?>" />
                </div>
            </div>
            
            
            <div class="col-md-6">
                <div class="form-group">
                      <label for="Adresse_8">Adresse</label>
                      <?php echo form_input('Adresse_8', set_value('Adresse_8', $guichet->Adresse_8), 'class="form-control"  maxlength="200"'); ?>
                </div>    
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="Agence_5">Agences BCC</label>
                      <?php echo form_dropdown('Agence_5', $agences, $guichet->Agence_5, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                      <label for="Province_6">Province</label>
                      <?php echo form_dropdown('Province_6', $provinces, $guichet->Province_6, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
            <div class="col-md-6">
                <div class="form-group">
                      <label for="Ville_7">Ville</label>
                      <?php echo form_dropdown('Ville_7', $villes, $guichet->Ville_7, 'class="form-control"  required="required"'); ?>
                </div>    
            </div>
   
            <div class="col-md-12">
                <div class="form-group">
                      <label for="Observation_9">Commentaire</label>
                      <?php echo form_textarea(array('name' => 'Observation_9', 'cols' => 40, 'rows' => 2), set_value('Observation_9', $guichet->Observation_9), 'id="description" class="form-control" maxlength="761" '); ?>
                </div>
            </div> 
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
        </div>
    <?php $chtml->box_body_closing(); ?> 	
    <?php echo form_close(); ?>
</div>
<div class="col-md-2"></div>



<script type="text/javascript">
$("#Type1").change(function(){
    var isOfType = $('#Type1 option:selected').attr('value');
    if(isOfType ==="CAC" || isOfType ==="CPI"){
        $("#BKC").css( "display", "none");
        $("#AIP").css( "display", "");
    }else {
        $("#BKC").css( "display", "");
        $("#AIP").css( "display", "none");
    }   
});   
 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/branches/save'); ?>/guichet/<?php echo $guichet->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $guichet->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($guichet->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/guichets/branches'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/taxbranches/display/guichets'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    
}
</script>
