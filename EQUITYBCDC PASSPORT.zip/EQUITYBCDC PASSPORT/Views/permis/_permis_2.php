<?php $userid = $_SESSION["userdata"]["user_id"]; $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>

<?php
    if(isset($_POST['Amount_10']) && $_POST['Amount_10'] !="" && $encaissement->Montant_11=="")
    {
            $amount = str_replace(' ','',$_POST['Amount_10']);
            $_POST['Amount_10'] = str_replace(',','.',$amount);
    }

?>
<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if(isset($_POST['Amount_10']) && $_POST['Amount_10'] !='' && $encaissement->Montant_11==""){$encaissement->Montant_11 =  number_format($_POST['Amount_10'],2,","," ");}elseif($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if(isset($_POST['Amount_10']) && $_POST['Amount_10'] !='' && $encaissement->Notemontant_28==""){ $paiement['Notemontant'] = number_format($_POST['Amount_10'],2,","," ");} elseif($encaissement->Notemontant_28 > 0){$paiement['Notemontant'] = number_format($encaissement->Notemontant_28,2,","," ");} ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>


<?php if(isset($_POST['Reference_8']) && $_POST['Reference_8'] !='') {$reference = $_POST['Reference_8'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nifclient_7']) && $_POST['Nifclient_7'] !='') {$nif = $_POST['Nifclient_7'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($_POST['Service_9']) && $_POST['Service_9'] !='') {$content['Service'] = $_POST['Service_9'];}elseif (isset($content['Service']) && $content['Service'] !=""){$service = $content['Service'];}else{ $service = "";}?>
<?php if(isset($_POST['Typerecette_12']) && $_POST['Typerecette_12'] !='' && $encaissement->Typerecette_17 == "") {$recette = $_POST['Typerecette_12'];}elseif (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 !=""){$recette = $encaissement->Typerecette_17;}else{ $recette = "";}?>
<?php if(isset($_POST['Devise_17']) && $_POST['Devise_17'] !='') {$devise_montant = $_POST['Devise_17'];}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else if(isset($encaissement->Designation_14) && $encaissement->Designation_14 !=""){ $designation = $encaissement->Designation_14; }else{ $designation = "";}?>
<?php

    if(!empty($note)):
        $quote_parts = json_decode($note->Notereference_24, true);
        $part_prestataire = isset($quote_parts['prestataire']) ? $quote_parts['prestataire'] : '';
        $part_fraisbancaire = isset($quote_parts['fraisbancaire']) ? $quote_parts['fraisbancaire'] : '';
        $part_tresor = isset($quote_parts['tresor']) ? $quote_parts['tresor'] : '';
    endif;
?>

<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else:
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        //$infos['totalDevise'] = $devise_montant;

        $valeur01 = $devise01 = $mode = '';
        $infos['RefINSS'] = $infos['RefINPP'] = $infos['RefONEM'] = $infos['QuotasINSS'] = $infos['QuotasINPP'] = $infos['QuotasONEM'] = '';
        $infos['standard'] = '';
}

?>


<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Ndeclaration" value="<?= isset($declaration->Id_0) ? $declaration->Id_0 : 1; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
	<input type="hidden" name="Agence_20" value="<?php echo isset($_SESSION['Logiref_agence']) ? $_SESSION['Logiref_agence'] : $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo isset($_SESSION['Logiref_guichet']) ? $_SESSION['Logiref_guichet'] : $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Beneficaire_15" value="DGRAD"  id="regies" />

    <input type="hidden" name="Infos[Email]" value="<?= isset($Infos["Email"]) ? $Infos["Email"] : "" ?>" id="email">
    <input type="hidden" name="Infos[Phone]" value="<?= isset($Infos["Phone"]) ? $Infos["Phone"] : "" ?>" id="phone">

    <input type="hidden" name="Logirad_59" value="<?php echo isset($note_id) ? $note_id : $encaissement->Logirad_59; ?>" />
    <input type="hidden" name="Email_60" value="<?= isset($Infos["Email"]) ? $Infos["Email"] : "" ?>" id="">
    <input type="hidden" name="Logiradid" value="<?= $note_id; ?>"  id="" />

    <div class="box-body">

        <div class="row">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader1"></div>
            </div>
        </div>

        <!------------------------- Beneficiare  ------------------------------>
        <div class="row">

            <div class="col-md-12"><br/><span class="f12"><b><label>Partie 1 : R&eacute;gies financi&egrave;re</label></b></span></div>

            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label>
                    </span>
                    <?php echo form_dropdown('Beneficaire_15', array('DGRAD'), 'DGRAD', ' class="form-control bg-gray" required="required"  '); ?>
                    <?php if($encaissement->Id_0 !=NULL): ?>
                        <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group"  id="regie0">
                    <span class="input-group-addon">
                        <label for="Service_16">
                            <div id="ServiceId">Service recouvrement</div>
                        </label>
                    </span>
                    <?php echo form_dropdown('Service_16', $services, isset($encaissement->Service_16) ? $encaissement->Service_16 : "" , 'class="form-control select2" id="service"  required="required" '); ?>
                </div>
            </div>
        </div>

        <!-------------------------  Titre de perception  ------------------------------>
        <div class="row">

            <div class="col-md-12"><br/><span class="f12"><b><label>Partie 2 : Titre de paiement</label></b></span></div>

            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26" id="TitreId">Num&eacute;ro</label>
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $reference), ' class="form-control" id="reftitre" maxlength="25" required="required" readonly'); ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label>
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', $documents[1]), 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
        </div>

        <div id="bl" class="col-md-12"></div>

        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" readonly'); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17" class="f12">Nature paiement</label>
                    </span>
                    <?php echo form_dropdown('', $recettes, isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : "", 'class="form-control select2" id="recette" required="required" '); ?>
                    <input type="hidden" name="Typerecette_17" value="<?= isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : "" ?>">
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Art. budg&eacute;taire</label>
                    </span>
                    <?php if (isset($recette) && $recette == "27422120"): ?>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", isset($recette) ? $recette : ""), ' class="form-control" id="" maxlength="25" readonly'); ?>
                    <?php else: ?>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", isset($recette) ? $recette : ""), ' class="form-control" id="" maxlength="25"'); ?>
                    <?php endif; ?>
                </div>
            </div>

            <input type="hidden" name="Infos[standard]" value="<?= isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : ""; ?>" id="">

            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label>
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('Notemontant_28', isset($encaissement->Notemontant_28) ? $encaissement->Notemontant_28 : ""), ' id="montantNote" class="form-control" required="required" readonly'); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <?php echo form_dropdown('', $devises, isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "", 'class="form-control" id="deviseNote"  required="required" disabled="disabled" '); ?>
                    <input type="hidden" name="Notedevise_29" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-5"><br/><span class="f12"><b><label>Partie 3 : Assujetti ou Contribuable.</label></b></span></div>
            <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px;"></span><br />
                <div style="display: flex; align-items: center; width: 100%;">
                    <label style="margin-bottom: 0;">
                        Intitulé du compte :&nbsp;&nbsp;
                        <span id="accountname"></span>
                    </label>
                    <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                        <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                            <span id="" class="text-red f15"></span>&nbsp;&nbsp;<span id="labelNumber" class="text-red f15"></span>
                        </label>
                    <?php elseif(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>
                    <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                        Frais de correspondance :&nbsp;&nbsp;
                        <span id="correspondent_fees" class="text-red f15">0.00 </span>&nbsp;&nbsp;<span id="correspondent_fees_currency" class="text-red f15"></span>
                        <input type="hidden" id="correspondent_fees_to_retrieve" name="Infos[correspondent_fees]">
                        <input type="hidden" id="correspondent_fees_to_retrieve_currency" name="Infos[correspondent_fees_currency]">
                    </label>
                    <?php endif; ?>
                </div>
            </div>

            <!--<div class="col-md-3 border"></br><label>Paie pour compte&nbsp;<input type="checkbox" name="Infos[pourcompte]" value="<?php echo(isset($infos['pourcompte']))? $infos['pourcompte']:''; ?>" <?php echo isset($infos['pourcompte']) ? 'checked' :''; ?>></label></div>-->

            <input type="hidden" name="Infos[fraisbcc]"  value="1" id="infosFbcc">
            <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
        </div>

        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label>
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', isset($encaissement->Nif_13) ? $encaissement->Nif_13 : ""), 'class="form-control"  maxlength="86" readonly'); ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14"><span id="label-info">D&eacute;signation</span></label>
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', isset($encaissement->Designation_14) ? $encaissement->Designation_14 : ""), 'class="form-control" id="designation" required="required" maxlength="86" readonly'); ?>
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode_19">Mode de paiement</label>
                    </span>
                    <?php echo form_dropdown('Mode_19', $modes, $mode, 'class="form-control" required="required" id="modeId"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Taux_41">Taux de change</label>
                    </span>
                    <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    <input type="hidden" value="TTB" name="Infos[rate_code]" id="rate_code" >
                </div>

                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Datevaleur_31">Date paiement</label>
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' class="form-control" maxlength="10" disabled="disabled" required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    <input type="hidden" name="Datevaleur_31" value="<?= gmdate('Y-m-d')?>" id="">
                </div>
                <!--<div class="input-group">
                    <span class="input-group-addon">
                    <label for="Datevaleur_31">Date transaction</label>
                    </span>
                    <?php echo form_input('Infos[Datetrans]', set_value('Infos[Datetrans]', ''), ' id="dateTrans" disabled="disabled" class="form-control" maxlength="10" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>-->
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                    </span>
                    <?php echo form_input('Reference_32', set_value('Reference_32', ""), 'class="form-control" id="transID" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Compte_33"><div id="compteLabel">Compte du client</div></label>
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                    <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                    <input type="hidden" name="Infos[accounttax]" value="" id="tax_info">
                    <input type="hidden" name="account_currency" value="" disabled="disabled" id="account_currency">
                    <input type="hidden" name="account_balance" value="" disabled="disabled" id="account_balance">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant &agrave; payer</label>
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required" readonly'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23"><div id="commiision">Commission</div></label>
                    </span>
                    <?php echo form_input('Commission_23', set_value('Commission_23', 0), 'class="form-control" id="commission"'); ?>
                </div>
                <!--<div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23"><div id="tva">Tva</div></label>
                    </span>
                    <?php echo form_input('', set_value('', '0'), 'class="form-control" id="feesTva" '); ?>
                </div>-->
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Total">Montant total</label>
                    </span>
                    <?php echo form_input("Infos[totalMontant]", set_value('Total', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required" id="compteDevise" '); ?>
                </div>
                <div class="input-group">
                    <?php echo form_dropdown('', $devises, isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                    <input type="hidden" name="Devise_12" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                </div>
                <div class="input-group">
                    <?php if (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17='27422120'): ?>
                        <?php echo form_dropdown('Devise_24', $devises , isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "", 'class="form-control"  required="required" id="commissionDevise"'); ?>
                        <input type="hidden" name="" value="<?php echo 'CDF' ?>">
                    <?php else: ?>
                        <?php //echo form_dropdown('Devise_24', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="commissionDevise"'); ?>
                        <?php echo form_dropdown('Devise_24', $devises , isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "", 'class="form-control"  required="required" id="commissionDevise"'); ?>
                    <?php endif; ?>
                </div>
                <!--<div class="input-group">
                    <?php echo form_dropdown('',$devises , isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "", 'class="form-control"  required="required" id="tvaDevise"'); ?>
                </div>-->
                <div class="input-group">
                    <?php if (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17='27422120'): ?>
                        <?php echo form_dropdown("Infos[totalDevise]", array('USD'=>'USD'), 'USD', 'class="form-control bg-gray" id="totalDevise"'); ?>
                    <?php else: ?>
                        <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF'), 'CDF', 'class="form-control bg-gray" id="totalDevise"'); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-------------------------  DGRAD Permis  ------------------------------>
        <div id="DGRADQuotepart" class="d-none">
            <div class="col-md-12"><br/><label>Partie 4 : Informations additionnelle</label><br/></div>

            <div class="col-md-4 small-box">
                <div class="form-group">
                    <label for="QuotasPrestataire">Quota Prestataire</label>
                    <?php echo form_input("Infos[QuotasPrestataire]", set_value("Infos[QuotasPrestataire]", $part_prestataire), 'class="form-control" id="QuotasPrestataire" readonly'); ?>
                </div>
            </div>
            <div class="col-md-4 small-box">
                <div class="form-group">
                    <label for="QuotasFees">Quota Frais Bancaire</label>
                    <?php echo form_input("Infos[QuotasFees]", set_value("Infos[QuotasFees]", $part_fraisbancaire), 'class="form-control" id="QuotasFees" readonly'); ?>
                </div>
            </div>
            <div class="col-md-4 small-box">
                <div class="form-group">
                    <label for="QuotasTresor"> Quota Tresor Public</label>
                    <?php echo form_input("Infos[QuotasTresor]", set_value("Infos[QuotasTresor]", $part_tresor), 'class="form-control" id="QuotasTresor" readonly'); ?>
                </div>
            </div>
        </div>
    </div>

    <div  class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12 pl-0">
            <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="print" disabled="disabled" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>

<br/><br/>

<script type="text/javascript"  charset="utf-8">

    var ref = '<?php echo $encaissement->Id_0;?>';
    var montant_total = '';

    var html_quotepart =  $("#DGRADQuotepart").html();
    var montant_total = '';
    $("#DGRADQuotepart").html('');

    $(".select2").select2();

    commission();

    $('#montantNote').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#recetteMontant').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#commission').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
        todayHighlight: true,
        format: 'mm-yyyy'
    });

    $('#dateTrans').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
    });

    $('#montantNote').change(function(){
            var note = $('#montantNote').val();

            var deviseNote = $('#deviseNote option:selected').val();

            $('#montantNote').val(note);
            $('#recetteMontant').val(note);

            if(note !="")
            {

                note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

                if(deviseNote == 'USD')
                {
                    note = note * taux;
                    $('#montantTotal').val(note.toLocaleString());
                }
                else
                {
                    $('#montantTotal').val(note.toLocaleString());
                }

                $('#commission').val('');
                commission();
                get_account_tariff();
            }
    });

    $('#deviseNote').change(function(){
            var devise = $('#deviseNote option:selected').val();
            var note = $('#montantNote').val();
            $('#recetteDevise').val(devise);
            $('#totalDevise').val('CDF');
            
            if(devise !="")
            {
                note = parseFloat(note.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    note = note * taux;
                    if(note) $('#montantTotal').val(note.toLocaleString());
                }
                else
                {
                    if(note) $('#montantTotal').val(note.toLocaleString());
                }

                $('#commission').val('');

                commission();
                get_account_tariff();
            }
            
            var devise_recette = $('#deviseNote option:selected').val();
            var devise_compte = $('#compteDevise option:selected').val();

            if(devise_recette == 'USD' && devise_compte == 'CDF')
            {
                get_exchange_rate();
            }
            else
            {   
                $('#exchange_bloc').addClass('d-none');
                $('#Taux').val(taux);
            }
    });

    $('#recetteMontant').change(function(){
            var montant = $('#recetteMontant').val();
            var note = $('#montantNote').val();
            
            var deviseNote = $('#deviseNote option:selected').val();
            var recetteDevise = $('#recetteDevise option:selected').val();
            $('#recetteDevise').val(deviseNote);
            
            if(montant !="")
            {
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                note = parseFloat(note.split(' ').join('').split(',').join('.'));

                if(montant > note)
                {
                        $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
                }
                else
                {
                        var commissions = $("#commission").val();

                        if(commissions !='0' && commissions !='')
                        {
                                commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                                if(deviseNote=='USD')
                                {
                                    montant = montant * taux;

                                    montant = commissions + montant + (commissions *0.16);

                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                                else
                                {
                                    montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                        }
                        else
                        {
                                if(recetteDevise == 'USD')
                                {
                                    montant = montant * taux;
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                                else
                                {
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                        }

                        $('#info').html('');
                        commission();
                        get_account_tariff();
                } 
            } 
    });

    $('#recetteDevise').change(function(){
            commission();
            get_account_tariff();
    });

    $('#service').change(function(){
            commission();
            get_account_tariff();
    });

    $('#commission').change(function(){
            var commissions = $("#commission").val();
            var devise = $('#recetteDevise').val();
            var montant = $('#recetteMontant').val();
            
            if(commissions !='0' && commissions !='')
            {
                    commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                    
                    montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                    if(devise == 'USD')
                    {
                        montant = montant * taux;
                        montant = montant + commissions + (commissions *0.16);

                        $('#montantTotal').val(montant.toLocaleString());
                    }
                    else
                    {
                        montant = montant + (montant *0.0005) + commissions + (commissions *0.16);
                        $('#montantTotal').val(montant.toLocaleString());
                    }
            }
            else if(commissions=='0' || commissions=='')
            {
                    if(devise == 'USD')
                    {
                        montant = montant * taux;
                        
                        $('#montantTotal').val(montant.toLocaleString());
                    }
                    else
                    {
                        $('#montantTotal').val(montant.toLocaleString());
                    }
            }
    });

    '<?php if (!empty($note)): ?>';

            $("#modeId").change(function(){

                    var mode = $('#modeId option:selected').val();

                    if (mode == 5)
                    {
                            $("#dateTrans").prop("disabled", false);
                            $("#dateTrans").prop("required", true);
                            $("#labelTrans").html("R&eacute;f&eacute;rence de la transaction");
                    }
                    else
                    {
                            $("#dateTrans").prop("disabled", true);
                            $("#dateTrans").prop("required", false);
                            $("#labelTrans").html("R&eacute;f&eacute;rence de l&apos;OP");
                    }
            });

            '<?php if ($encaissement->Typerecette_17 == "27422120"): ?>'

                $("#DGRADQuotepart").css('display', '');
                $("#DGRADQuotepart").html(html_quotepart);

                function handleTransactionChange() {

                    var mode = $('#modeId option:selected').val();
                    var transID = $("#transID").val();
                    var transDate = $("#dateTrans").val();

                    if (mode == 5) 
                    {
                        $("#dateTrans").prop("disabled", false);
                        $("#dateTrans").prop("required", true);

                        if (transID !== '' && transDate !== '')
                        {
                            get_paiement_transid(transID, transDate);
                            //get_trans_details(transID, transDate);
                        }
                    }
                    else
                    {
                        $("#dateTrans").prop("disabled", true);
                        $("#dateTrans").prop("required", false);
                        $("#enregistrer").prop('disabled', false);
                    }
                }
                // Attach event listeners
                $("#transID, #dateTrans, #modeId").change(handleTransactionChange);
            '<?php endif; ?>'

    '<?php endif; ?>'


    $("#pager").on("change", "#recette", function(){
        commission();
        get_account_tariff();

    });


    $('#form').submit(function(event) {
            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        
            var data = $(this).serialize();
            var devise = $('#deviseNote option:selected').val();
            var compteDevise = $('#compteDevise option:selected').val();
            var totalDevise = $('#totalDevise option:selected').val();
            var commissionDevise = $('#commissionDevise option:selected').val();
            var recetteDevise = $('#recetteDevise option:selected').val();
            var mode = $('#modeId option:selected').val();
            var commission_value = $('#commission').val();
            var csrf = $('input[name="csrf_name"]').val();
            
            var test_balance = false;
            
            var compte = $("#compteId").val();

            if(compte.length == 14)
            {
                test_balance = false;
            }
            else
            {
                test_balance = true;
            }
            
            if(test_balance)
            {
                get_account_balance(data);

            }
            else
            {
                submiter(data);
            }
            
    });

    $("#compteId").change(function(){
        get_account_tariff(); 
        var compte = $("#compteId").val();
        
        get_account_tariff();
        
        if(compte.length == 14)
        {
                get_accountname_internal();
                
        }
        else
        {
                get_accountname(); 
            
        }
        
        '<?php if (!empty($note) && $encaissement->Typerecette_17 == "27422120"): ?>';
            var mode = $('#modeId option:selected').val();
            var transID = $("#transID").val();
            var transDate = $("#dateTrans").val();

            if(transID !== '' && transDate !='' && mode !='')
            {
                if (mode == 5) 
                {
                    $("#dateTrans").prop("disabled", false);
                    get_paiement_transid(transID, transDate);
                    //get_trans_details(transID, transDate);
                }
                else
                {
                    $("#dateTrans").prop("disabled", true);
                    //$("#enregistrer").prop('disabled', false);
                }
            }
        '<?php endif; ?>';
    });


    $("#compteDevise").change(function(){
        var compte = $("#compteId").val();
        
        if(compte.length == 14)
        {
                get_accountname_internal();
                
        }
        else
        {
                get_accountname(); 
            
        }
        
        get_account_tariff();

        
        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();
        
        if(devise_recette == 'USD' && devise_compte == 'CDF')
        {
            get_exchange_rate();
        }
        else
        {   
            $('#exchange_bloc').addClass('d-none');
            $('#Taux').val(taux);
        }
    });

    $("#cancel").click(function(){
            location.reload(true);
    });

    function commission()
    {
            $("#loader").val('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            $("#commission").val('');
            $("#Devise_24").prop("selectedIndex", 0);
            var mode = $('#modeId').val();
            var montant = $('#recetteMontant').val();
            var regie = 'DGRAD';
            var service = $('#service option:selected').val();
            var devise = $('#recetteDevise option:selected').val();
            var recette = $('#recette option:selected').val();
            var guichet = $('#guichetId').val();
            var taux = $('#Taux').val();
            var commission = $("#commission").val();
            var total_amount = '';
            var compte = $("#compteId").val();
            var csrf = $('input[name="csrf_name"]').val();
            var type_recette =  '<?php echo (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != "" ) ? $encaissement->Typerecette_17:"" ?>'

            if(montant !== '' && devise !== '' && service !== ''){
                var url = '<?php echo base_url('admin/fees/display/'); ?>default<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
                $.ajax({
                        type        : 'POST',
                        url         : url,
                        data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, compte:compte, csrf_name:csrf },
                        dataType    : 'html',
                        encode      : true,
                        success: function(reponse)
                        {
                            var result = JSON.parse(reponse);

                            if(commission == '')
                            {
                                if(parseFloat(result[0])!="")
                                {
                                        $("#commission").val(result[0]);
                                        $("#commissionDevise").val(result[1]);
                                        $("#tvaDevise").val(result[1]);
                                        $("#montantTotal").val(result[2]);

                                        $('#recetteDevise').val(result[1]);
                                }
                                else if(parseFloat(result[0]) == '0' && type_recette == "27422120")
                                {
                                        $("#commission").val(parseFloat(result[0]));
                                        $("#commissionDevise").val(devise);

                                        $("#montantTotal").val(montant);
                                        $('#recetteDevise').val(devise);

                                        $("#feesTva").val(0);
                                        $("#tvaDevise").val(devise);
                                }
                            }
                        },
                        error:function(error)
                        {
                            $('#bl').html('');
                            $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
            }
    }

    function submiter(data)
    {
            $("#loader").val('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxpermis/save/initiation'); ?><?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
            var pid = '<?php echo $encaissement->Id_0; ?>';

            scrollUP();
            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'json',
                    encode      : true,
                    success: function(result){

                            $('#loader').html('');

                            let pid = result.id;
                            let code = result.code;
                            let message = result.message;

                            if (code == 200)
                            {
                                    $('#step2').remove;
                                    $("#step-2").removeClass('bg-green-active');
                                    $("#step-2").addClass('bg-gray');
                                    $("#step-3").removeClass('bg-gray');
                                    $("#step-3").addClass('bg-green-active');
                                    scrollUP();
                                    var url = '<?php echo base_url($module.'/taxpermis/display/preview'); ?>/' + pid;
                                    $.get(url, function(data, status){
                                        $('#loader').html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#pager").html(data);
                                    })
                            }
                            else
                            {
                                    $('#loader').html('<div class="alert aDanger text-white"> '+message+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    }


    function get_accountname() 
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var core_banking = '<?php echo $core_banking; ?>';

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_customeraccounts() 
    {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            //$("#labelNumber").html('');
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#labelNumber, #compteLabel").html(loader_img);

        $('#compteDevise').prop('disabled', false);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200")
                {
                    const mapped_currency = {
                        '976': 'CDF',
                        '978': 'EUR',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'compteId',
                        name: 'Compte_33',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#compteId').prop('tagName') === 'SELECT') {
                        $('#compteId').replaceWith(select);
                    } else {
                        $('#compteId').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $("#compteLabel").html('Comptes du client');
                    $("#labelNumber").html('');

                } else{
                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
        
                    $('#compteId').replaceWith(input_html);

                    $("#compteLabel").html('Compte du client');
                    $("#labelNumber").html('');

                    if (reponse.code == '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code == '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code == '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function get_accountname_internal()
    {
            var compte = $('#compteId').val();
            var devise = $('#compteDevise option:selected').val();
            var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname_internal'); ?>';
            var ref_note = '<?php echo $encaissement->Typerecette_17; ?>';
            var csrf = $('input[name="csrf_name"]').val();

            if(compte !== '' && devise !=='')
            {   
                    $("#accountname").html('<img  align="middle" style="height:15px;margin-left:-11px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                    $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : { compte : compte, devise : devise, csrf_name:csrf}, 
                            dataType    : 'json', 
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse == '404')
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Ce compte n&apos;existe pas');
                                    }
                                    else if(reponse == '406')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                    }
                                    else if(reponse == '405')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Le format de compte n\'est pas valide');
                                    }
                                    else if(reponse.currency == null && reponse.account_name == null)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                            $("#taxinfo").html('');
                                    }
                                    else if(reponse.currency != devise)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Devise du compte incorrecte');
                                            $("#taxinfo").html('');
                                            $('#compteDevise').val('');
                                    }
                                    else
                                    {
                                            if(reponse.tax_info =='200')
                                            {
                                                    $('#tva_value').prop('disabled', true);
                                                    $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                    $('#tva').prop('checked', '');
                                                    
                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                    
                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                    
                                                    var total = montant + commissions;
                                                    
                                                    $("#montantTotal").val(total.toLocaleString());
                                            }
                                            else
                                            {
                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
                                                    
                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));
                                                    
                                                    if (ref_note == '27422120')
                                                    {
                                                            var total = montant + commissions + (commissions *0.16);
                                                    }
                                                    else
                                                    {
                                                            var total = montant + (montant *0.0005) + commissions + (commissions *0.16);
                                                    }
                                                    
                                                    $("#montantTotal").val(total.toLocaleString());
                                                    
                                                    $('#tva').prop('checked', 'checked');
                                                    $('#tva_value').prop('disabled', false);
                                                    
                                                    $("#taxinfo").html('');
                                                    $("#tax_info").val('');
                                            }
                                            $("#accountname").css('color', 'green');
                                            $("#accountname").html(reponse.account_name);
                                            $("#account_name").val(reponse.account_name);
                                            $("#account_currency").val(reponse.currency);
                                            $("#account_balance").val(reponse.balance);
                                    }
                            },
                            error:function(error)
                            {
                                alert('ERROR!' + error);
                            }  
                    });  
            }
            else
            {
                    $("#accountname").html('');
            } 
    }

    function get_exchange_rate()
    {
            var devise = $('#compteDevise').val();
            var devise_recette = $('#recetteDevise').val();
            var note_number = $('#reftitre').val();
            var csrf = $('input[name="csrf_name"]').val();
            
            $('#exchange_bloc').removeClass('d-none');
            
            $("#exchange_message").html('<img  align="middle" style="height:15px;margin-left:-11px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                    
            var url = '<?php echo base_url($module.'/rates/data/get_taux'); ?>';
            
            $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : { devise_compte : devise, devise_recette : devise_recette, note_number : note_number,csrf_name:csrf}, 
                            dataType    : 'json', 
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse.code == '200')
                                    {
                                            $("#Taux").val(reponse.rate);
                                            $('#rate_code').val('TTS');
                                            $("#exchange_message").css('color', 'green');
                                            $("#exchange_message").html('Taux de vente r&eacute;cup&eacute;r&eacute; avec succ&egrave;s.');
                                    }
                                    else if(reponse.code == '0003')
                                    {
                                            $("#exchange_message").css('color', 'red');
                                            $("#exchange_message").html('Probl&egrave;me de connexion &agrave; Finacle, le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                                    }
                            
                            },
                            error:function(error)
                            {
                                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    }); 
    }

    // function get_account_tariff()
    // {
    //         var compte = $('#compteId').val();
    //         var regie = 'DGI';
    //         var url = '<?php echo base_url($module.'/taxaccounts/data/get_account_tarification'); ?>';
    //         var ref_note = '<?php echo $encaissement->Typerecette_17; ?>';
    //         var csrf = $('input[name="csrf_name"]').val();
            
    //         if(compte !== '')
    //         {  
    //                 $("#commission").html('<img  align="middle" style="height:15px;margin-left:-26px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    //                 $.ajax({
    //                         type        : 'POST', 
    //                         url         : url, 
    //                         data        : { compte : compte, regie : regie,csrf_name:csrf}, 
    //                         dataType    : 'json', 
    //                         encode      : true,
    //                         success: function(reponse)
    //                         {
                                
    //                                 if(reponse.commission >= 0)
    //                                 {
    //                                         if (reponse.commission > 0)
    //                                         {
    //                                             $("#commission").val(reponse.commission);
    //                                             $("#commissionDevise").val(reponse.devise);
                                                
    //                                             var commissions = reponse.commission;
    //                                             commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
    //                                         }
                                            
                                            
    //                                         $("#infosFbcc").val(reponse.fraisbcc);
    //                                         $("#infosTva").val(reponse.tva);

                                            
    //                                         var tva = reponse.tva;
    //                                         var fbcc = reponse.fraisbcc;
                                            
    //                                         //$('#commission').val(commissions.toLocaleString());

                                            
    //                                         var montant = $('#recetteMontant').val();

    //                                         var recetteDevise = $('#recetteDevise option:selected').val();
                                            
                                            
    //                                         if(montant != "")
    //                                         {
    //                                             montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
    //                                             commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                                                
    //                                             if(recetteDevise=='USD')
    //                                             {
    //                                                 montant = montant * taux;

    //                                                 montant = commissions + montant + (commissions *0.16);

    //                                                 $('#montantTotal').val(montant.toLocaleString());
    //                                             }
    //                                             else if (tva == '0' && fbcc == '0')
    //                                             {
    //                                                 montant = commissions  + montant;
    //                                                 $('#montantTotal').val(montant.toLocaleString());
    //                                             }
    //                                             else if (tva == '1')
    //                                             {
    //                                                 montant = commissions  + montant + (commissions *0.16);
    //                                                 $('#montantTotal').val(montant.toLocaleString());
    //                                             }
    //                                             else if (fbcc == '1')
    //                                             {
    //                                                 montant = commissions  + montant + (montant *0.0005);
    //                                                 $('#montantTotal').val(montant.toLocaleString());
    //                                             }
    //                                             else
    //                                             {
    //                                                 if (ref_note == '27422120')
    //                                                 {
    //                                                         montant = commissions + montant + (commissions *0.16);
    //                                                 }
    //                                                 else
    //                                                 {
    //                                                         montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
    //                                                 }
    //                                                 $('#montantTotal').val(montant.toLocaleString());

    //                                             }
    //                                         }
    //                                 }
    //                         },
    //                         error:function(error)
    //                         {
    //                                 $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    //                         }
    //                 });
    //         }
    //         else
    //         {

    //         }
    // }

    function get_account_balance(data)
    {
            var compte = $('#compteId').val();
            var devise = $('#recetteDevise option:selected').val();
            var montant = $('#recetteMontant').val();
            var commission = $('#commission').val();
            var devise_compte = $('#account_currency').val();
            var devise_commission = $('#commissionDevise').val();
            var balance = $('#account_balance').val();
            var csrf = $('input[name="csrf_name"]').val();
            
            var url = '<?php echo base_url($module.'/taxaccounts/data/get_account_balance'); ?>';
            
            $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_commission : devise_commission, devise_compte : devise_compte, balance : balance,csrf_name:csrf}, 
                            dataType    : 'html',  
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse == '200')
                                    {
                                            submiter(data);
                                    }
                                    else if(reponse == '300')
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette note de perception !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(reponse == '405')
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else
                                    {
                                            $('#loader').html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion &agrave; finacle, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    $("#enregistrer").prop('disabled', false);
                            },
                            error:function(error)
                            {
                                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }  
            });
    }

    function get_paiement_transid(transID, transDate)
    {
            if(transID !== '')
            {
                    var url = '<?php echo base_url($module.'/taxpermis/data/get_paiment_transid'); ?>';

                    $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { transID : transID},
                            dataType    : 'html',
                            encode      : true,
                            success: function(reponse)
                            {
                                    if(reponse == '200')
                                    {
                                            $("#loader").html('');
                                            $("#trans_message").html('');

                                            $("#enregistrer").prop('disabled', false);

                                            $('#trans_bloc').addClass('d-none');

                                            get_trans_details(transID, transDate);
                                    }
                                    else
                                    {
                                            scrollUP();

                                            $('#trans_bloc').removeClass('d-none');

                                            $("#trans_message").css('color', 'red');
                                            $("#trans_message").html("Numéro de transaction déjà utilisé aujourd'hui");
                                            $('#loader').html('<div class="alert alert-info">INFORMATION : Ce numéro de transaction a déjà été utilisé pour la journée d aujourd hui. Veuillez vérifier et saisir un autre numéro...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                                            $("#enregistrer").prop('disabled', true);
                                    }
                            },
                            error:function(error)
                            {
                                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
            }
            else
            {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR :Réference pas saisi...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

            }
    }

    function get_trans_details(transID, transDate)
    {
            if(transID !== '' && transDate !='')
            {
                    $('#trans_bloc').removeClass('d-none');

                    $("#trans_message").html('<img  align="middle" style="height:15px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

                    var compte = $('#compteId').val();
                    var devise = $('#compteDevise option:selected').val();
                    var montant = $('#recetteMontant').val();
                    var designation = $('#designation').val();
                    var amount = $("#recetteMontant").val();
                    var csrf = $('input[name="csrf_name"]').val();

                    var url = '<?php echo base_url($module.'/taxaccounts/data/get_trans_details'); ?>';

                    $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { transID : transID, transDate:transDate, compte : compte, devise : devise, designation : designation, amount: amount,csrf_name:csrf}, 
                            dataType    : 'json',
                            encode      : true,
                            success: function(reponse)
                            {
                                    if(reponse == '405')
                                    {
                                            $("#loader").html('');

                                            $("#trans_message").css('color', 'red');
                                            $("#trans_message").html('Cette réference n&apos;existe pas.');

                                            $("#enregistrer").prop('disabled', true);
                                    }
                                    else if(reponse == '404')
                                    {
                                            $("#loader").html('');

                                            $("#trans_message").css('color', 'red');
                                            $("#trans_message").html('Le format de cette réference n\'est pas valide');

                                            $("#enregistrer").prop('disabled', true);
                                    }
                                    else if(reponse == '501')
                                    {
                                            scrollUP();

                                            $("#enregistrer").prop('disabled', true);

                                            $("#trans_message").css('color', 'red');
                                            $("#trans_message").html('Les comptes ne correspondent pas');
                                            //$("#trans_message").html(reponse.account+ ' != '+ compte);

                                            $("#message").html('');
                                            $('#loader').html('<div class="alert aDanger text-white"> Le compte saisi ne correspond pas à celui retourn&eacute par la r&eacutef&eacuterence FINACLE. veuillez saisir le bon compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    }
                                    else if(reponse.code == '200')
                                    {
                                            $("#loader").html('');
                                            $("#trans_message").css('color', 'green');
                                            $("#trans_message").html(reponse.account+ ' / '+ reponse.amount);

                                            $("#enregistrer").prop('disabled', false);
                                    }
                                    else
                                    {
                                            $("#loader").html('');
                                            $("#trans_message").css('color', 'red');
                                            $("#trans_message").html('Probl&egrave;me de connexion &agrave; finacle!');

                                            $("#enregistrer").prop('disabled', true);
                                    }

                            },
                            error:function(error)
                            {
                                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
            }
            else
            {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR :Réference pas saisi...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

            }
    }

    function arrondi_decimale(value, decimales)
    {
        var factor = Math.pow(10, decimales);
        return Math.round(value * factor);
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>