<?php #$chtml->right_side_content_opening()?>
        <div class="row">
                <div class="col-md-3"> </div>
                <?php if($country !=60){ ?>
                    <div class="col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                            <div class="col-md-12 padding-20 text-center">

                                  <h4>D&eacute;sol&eacute;! Acc&egrave;s refus&eacute;!</h4>
                                  <span><i class="fa fa-fw fa-ban f100 text-red"></i> <br/><br/></span>
                                  <span class='text-gray'>L'application logiref n'est disponible que pour les entreprises qui sont enregistr&eacute;es en RDC.</span>
                            </div>       
                        </div>
                    </div>
                <?php }else{ ?>
                    <div class="col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                            <div class="col-md-12 padding-20 text-center">

                                  <h4>D&eacute;sol&eacute;! Acc&egrave;s refus&eacute;!</h4>
                                  <span><i class="fa fa-fw fa-ban f100 text-red"></i> <br/><br/></span>
                                  <span class='text-gray'>Veuillez contacter l'administrateur de ce compte iKwook pour obtenir l'acc&egrave;s &agrave; cette section</span>
                            </div>       
                        </div>
                    </div>
                    
                <?php } ?>
                <div class="col-md-3"> </div>
        </div>
<?php #$chtml->right_side_content_closing()?>




