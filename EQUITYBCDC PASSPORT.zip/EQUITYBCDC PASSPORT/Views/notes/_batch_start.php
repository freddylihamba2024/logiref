<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
?>
<div class="col-md-12 p-0">
    <div class="row">
        <div class="col-md-12" id="loader"></div>
    </div>
    <div class="row">
        <div class="col-md-12" id="message"></div>
    </div>
    
    <div class="row">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> f16  center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Saisi de la note<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Confirmation du paiement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Impression de la preuve<br/></div>
        </div>
    </div>
    <div class="row"><div class="col-md-12"><br/></div></div>
    <div class="row">
        <div class="col-md-12" id="loader"></div>
    </div>
    <div class="row">    
        <div id="pager" class="col-md-12">
            <?php if($step==2): ?>
                <?php echo $this->load->view('_step_2'); ?>
            <?php elseif($step==3): ?>
                <?php echo $this->load->view('_step_3'); ?>
            <?php else: ?>
                <?php $chtml->box_body_opening("", true);?>  
                <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => '')); ?>
                    <style>.badge.bg-blue,.badge.bg-green,.badge.bg-red {color: #fff !important;font-weight: 600;}</style>

                    <input type="hidden" name="Commission" value="" id="commission" />
                    <input type="hidden" name="Commission_lot" value="" id="commission_lot" />
                    <input type="hidden" name="Commission_currency" value="" id="Commission_currency" />
                    <input type="hidden" name="Commission_attestation" value="" id="commission_attestation" />
                    <input type="hidden" name="Total_commission" value="" id="total_com" />
                    <input type="hidden" name="Total_amount" value="" id="recetteMontant" />
                    <input type="hidden" name="Total_to_paid" value="" id="montantTotal" />
                    <input type="hidden" name="TotalDevise" value="" id="totalDevise" />

                    <div class="box-body">
                        <div class="row margin">
                            <div class="col-md-8 bRight">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Service_16" class="f12 text-black"><b>Service recouvrement</b></label> 
                                            <?php echo form_dropdown('Service', $services, "" , 'class="form-control select2" id="service"  required="required" '); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Beneficaire" class="f12 text-black"><b>B&eacute;n&eacute;ficiare</b></label> 
                                            <?php echo form_dropdown('Beneficaire',array('DGRAD'),'DGRAD', 'class="form-control bg-gray" id="Service_16" required = "required" disabled'); ?>
                                            <input type="hidden" name="Beneficaire" value="<?= "DGRAD" ?>" />
                                        </div>
                                    </div>  
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Designation_14" class="f12"><b>D&eacute;signation</b></label> 
                                            <?php echo form_input('Designation', set_value('Designation', ""), 'class="form-control" id="designation" required="required" maxlength="86" '); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="Notedate"><b>Date &eacute;mission</b></label>
                                            <?php echo form_input('Notedate', set_value('Notedate', date('d-m-Y')), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label  for="Devise_34"><div id="compteLabel"><b>Devise de la note</b></div></label> 
                                            <?php echo form_dropdown('Notedevise', $devises, "", 'class="form-control" id="recetteDevise"  required="required"'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Nif_13"><b>Num&edot;ro imp&ocirc;t</b></label> 
                                                <?php echo form_input('Nif', set_value('Nif', ""), 'class="form-control" id="Nif"  maxlength="86"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="" class="f12"></label> 
                                                <?php echo form_input('Infos[CustomerNumber]', set_value('Infos[CustomerNumber]', isset($infos['CustomerNumber']) ? $infos['CustomerNumber'] : ""), 'class="form-control" id="customerNumber" maxlength="7" placeholder="Numéro du client"'); ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Nif_13"><b>Num&edot;ro imp&ocirc;t</b></label> 
                                                <?php echo form_input('Nif', set_value('Nif', ""), 'class="form-control" id="Nif"  maxlength="86"'); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="Mode_19"><b>Mode de paiement</b></label> 
                                            <?php echo form_dropdown('Mode', $modes, '', 'class="form-control" required="required" id="modeId"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="Taux_41">Taux de change</label> 
                                            <?php echo form_input('Taux', $taux['Dollar_4'], 'class="form-control" id="Taux" readonly'); ?>
                                        </div>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group"> 
                                            <label  for="Compte" id="accountname" ><div id="compteLabel"><b>Compte du client</b></div></label> 
                                            <?php echo form_input('Compte', set_value('Compte',  "" ), 'class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                                            <input type="hidden" name="accountname" value="" id="account_name">
                                            <input type="hidden" name="account_currency" value="" id="account_currency">
                                            <input type="hidden" name="account_balance" value="" id="account_balance">
                                            <input type="hidden" name="accountType" value="" id="account_type">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label  for="cDevise"><div id="compteLabel"><b>Devise</b></div></label> 
                                            <?php echo form_dropdown('cDevise', $devises, '', 'class="form-control"  required="required" id="compteDevise"'); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="Reference_32"><b>R&eacute;f&eacute;rence de l&apos;OP</b></label>
                                            <?php echo form_input('Reference', set_value('Reference', ""), 'class="form-control" '); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <br/>
                                        <label class="f12 text-black page-header"><b>Partie additionnelle : Frais liés aux attestations</b></label><br/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-check abc-checkbox abc-checkbox-success">
                                            <input class="form-check-input" id="print_attestation" type="checkbox" checked="" name="PaidATTESTATION" value="<?= "FIA" ?>" >
                                            <label class="form-check-label text-blue font-bold" for="print_attestation">
                                                Frais liés à l’impression de l'attestations
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-check abc-checkbox">
                                            <input class="form-check-input" id="print_duplicata" type="checkbox" <?= ($_SESSION['Logiref_role'] != 4) ? "":"disabled" ?>  name="PaidDUPLICATA" value="<?= "FDA" ?>"  >
                                            <label class="form-check-label text-blue font-bold" for="print_duplicata">
                                                Frais de duplicata d’attestation
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <?php endif ?>
                            </div>
                            <div class="col-md-4" id="">
                                <div class="box box-secondary" id="batchBox">
                                    <div class="box-header with-border" id="title_upload">
                                        <h6 class="box-title">
                                            <i class="fa fa-upload"></i> Importation des paiements
                                        </h6>
                                    </div>
                                    <div class="box-body mt-4" id="box_upload">
                                        <!-- Upload -->
                                        <div class="form-group">
                                            <label class="f12"><b>Fichier Excel des notes</b></label>
                                            <input type="file"
                                                id="batch_file"
                                                name="batch_file"
                                                class="form-control"
                                                accept=".xlsx,.xls"
                                                required
                                                aria-describedby="batchHelp">
                                            <small id="batchHelp" class="text-muted">
                                                Format attendu : Numéro note | Montant | Devise
                                            </small>
                                        </div>
                                        <!-- Loader -->
                                        <div id="batch_loader" class="text-center" style="display:none;">
                                            <i class="fa fa-spinner fa-spin fa-2x"></i>
                                            <p>Analyse du fichier en cours…</p>
                                        </div>
                                        <!-- Résumé -->
                                        <div id="batch_summary" style="display:none;">
                                            <hr/>
                                            <p class="f12"><b>Résumé du fichier</b></p>
                                            <ul class="list-group">
                                                <li class="list-group-item">
                                                    Nombre de lignes
                                                    <span class="badge bg-blue pull-right" id="sum_lines">0</span>
                                                </li>
                                                <li class="list-group-item">
                                                    Lignes valides
                                                    <span class="badge bg-green pull-right" id="sum_valid">0</span>
                                                </li>
                                                <li class="list-group-item">
                                                    Lignes rejetées
                                                    <span class="badge bg-red pull-right" id="sum_invalid">0</span>
                                                </li>
                                                <li class="list-group-item">
                                                    Montant à payer
                                                    <span class="badge bg-gray pull-right">
                                                        <span id="sum_amount">0</span> <span id="sum_currency">CDF</span>
                                                    </span>
                                                </li>
                                                <li class="list-group-item">
                                                    Commission totale
                                                    <span class="badge bg-gray pull-right">
                                                        <span id="sum_commission">0</span> <span id="com_currency"></span>
                                                    </span>
                                                </li>
                                                <li class="list-group-item">
                                                    Montant total à payer
                                                    <span class="badge bg-gray pull-right">
                                                        <span id="sum_total">0</span> <span id="sumtotal_currency"></span>
                                                    </span>
                                                </li>
                                                <li class="list-group-item">
                                                    Balance compte du client
                                                    <span id="balance" class="badge  pull-right">
                                                        <span id="msg_balance"></span> 
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>

                                        <input type="hidden" name="batch_excel_data" id="batch_excel_data">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <div class="row mt-3">
                            <div class="col-md-12">
                            <button id="continued" type="submit" class="btn btn-primary pull-left disabled"><i class="fa fa-arrow-circle-right"></i>&nbsp;&nbsp;Continuer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <!--  <button type="button" id="treat" class="btn btn-primary"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;-->
                                <a id="cancel" class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                            </div>
                        </div>
                    </div>

                <?php echo form_close(); ?>
                <?php $chtml->box_body_closing(); ?>
            <?php endif;?>
        </div>
    </div>     
</div>
<script>
    const CSRF_NAME  = '<?= csrf_token() ?>';
    const CSRF_HASH  = '<?= csrf_hash() ?>';
</script>

<script type="text/javascript">

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $(".select2").select2();
        
    $("#mainform").submit(function(event){
        event.preventDefault();

        let form = document.getElementById('mainform'); 
        let formData = new FormData(form); 
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        next_step(formData);
    });

    // Quand on change le fichier
    $('#batch_file').on('change', function () {
        handle_process_lot_excel();
    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $("#compteId").change(function() {

        var bank = '<?php echo $bank; ?>';

        if(bank == '@boa')
        {
            var compte = $(this).val();

            if (compte.length < 18) 
            {
                $("#accountname").removeClass('text-black');
                $("#accountname").removeClass('text-green');
                $("#accountname").addClass('text-red');
                $("#accountname").text('Numéro de compte invalide');
                $("#compteId").val('');
            } 
            else 
            {
                get_accountname();
            }
        }
        else
        {
            get_accountname();
        }

        get_account_exemption();
    });

    $("#compteDevise").change(function(){
        get_accountname(); 
        get_account_exemption();
    });

    <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
        $("#Taux").change(function(){
            let montant       = $('#recetteMontant').val();
            let recetteDevise = $('#recetteDevise option:selected').val();
            let tauxModif     = parseFloat($('#Taux').val().split(' ').join('').split(',').join('.'));
           
            if(montant !="" && recetteDevise != "")
            {
                handle_exchange_rate(false, montant) 
                handle_process_lot_excel();
            }
        });

        // Désactiver le bouton pendant la saisie
        $('#Taux').on("keyup", function() {
            $('#continued').addClass('disabled'); 
        });

        // Quand on sort du champ (fin de saisie), 
        $('#Taux').on("blur", function() {
            $('#continued').removeClass('disabled'); 
        });
    <?php endif; ?>

    function get_accountname() 
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var core_banking = '<?php echo $core_banking; ?>';

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);

                            // Vérifier si branch_code existe avant de l'utiliser
                            if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                                $("#branch_code").val(reponse.branch_code);
                            }
                    }
                },
                error: function(error) {
                    $("#loader").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } 
    }

    function get_account_exemption()
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        var url = '<?php echo base_url('branch/taxaccounts/data/get_account_exemption'); ?>';

        if (compte === '' || devise === '') {
            if (typeof callback === 'function') callback(null);
            return;
        }

        $.ajax({
            type: 'POST',
            url: url,
            data: { compte: compte, devise: devise, csrf_name: csrf },
            dataType: 'json',
            success: function(reponse) {
                if (reponse.code == '200') 
                {
                    const formattedCommission = Number(reponse.comm).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $("#commission").val(reponse.comm);
                    $("#commission_attestation").val(reponse.comm);
                } 

                //if (typeof callback === 'function') callback(reponse);
            },
            error: function() {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                if (typeof callback === 'function') callback(null);
            }
        });
    }

    function handle_process_lot_excel() 
    {
        const recetteDevise = $('#recetteDevise option:selected').val(); 
        if (!validate_devise(recetteDevise)) return;

        const file = $('#batch_file')[0].files[0];
        if (!validate_file(file)) return;

        // Construire FormData avec tout le formulaire 
        let form = document.getElementById('mainform'); 
        let formData = new FormData(form); 
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        let url = '<?= base_url('branch/taxnotes/data/handle_process_lot_excel'); ?>';

        $('#batch_loader').show();
        $('#batch_summary').hide();

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                $('#batch_loader').hide();
                $("#title_upload").hide();

                $("#box_upload").removeClass("mt-4");

                if (res.error) return alert(res.error);

                if (res.invalid_lines > 0 && res.rejected) { 
                    $("#loader").html(build_rejected_html(res.rejected, res.invalid_lines)); 
                }

                toggle_continue_button(res.grand_total);
                update_summary(res, recetteDevise);
                update_balance(res.balance)

                <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
                    handle_exchange_rate(true, res.total_montant ?? 0); 
                <?php endif; ?>
            },
            error: function (xhr) {
                $('#batch_loader').hide();
                let msg = xhr.responseText || 'Erreur lors de la lecture du fichier';
                alert(msg);
            }
        });
    }

    function validate_file(file) 
    { 
        if (!file) return false; 
        const ext = file.name.split('.').pop().toLowerCase(); 
        
        if (!['xls', 'xlsx'].includes(ext)) 
        { 
            alert('Format invalide. Veuillez choisir un fichier Excel (.xls ou .xlsx)'); 
            return false; 
        } 
        
        return true;
    }

    function validate_devise(devise) 
    { 
        if (!devise) { 
            alert('Veuillez sélectionner la devise de la note avant de télécharger le fichier.'); 

            $('#batch_file').val(''); 
            return false; 
        } 

        return true; 
    }

    function build_rejected_html(rejected, invalidCount) 
    { 
        let html = ` 
            <div class="alert alert-danger"> 
                <strong>${invalidCount} ligne(s) rejetée(s) :</strong> 
                <ul class="list-group mt-2">`; 
                
        rejected.forEach(rej => { 
            html += ` 
                <li class="list-group-item list-group-item-danger"> 
                    Ligne ${rej.ligne} 
                    - Note: <b>${rej.numero || '-'}</b> 
                    - Montant: <b>${rej.montant}</b> 
                    - Devise: <b>${rej.devise || '-'}</b> 
                    <span class="badge bg-red pull-right">${rej.raison}</span> 
                </li>`; 
            }); 
            
            return html + ` </ul> 
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> 
                </div>`; 
    }

    function update_summary(res, devise) 
    { 
        const formattedCommission   = Number(res.commission_total).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        const formattedMontant      = Number(res.total_montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        const formattedMontantTotal = Number(res.grand_total).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        $('#batch_summary').show();

        $('#sum_lines').text(res.total_lines ?? 0);
        $('#sum_valid').text(res.valid_lines ?? 0);
        $('#sum_invalid').text(res.invalid_lines ?? 0);

        $('#sum_amount').text((formattedMontant ?? 0));
        $('#sum_commission').text((formattedCommission ?? 0));
        $('#sum_total').text((formattedMontantTotal ?? 0));
        $('#sum_currency').text(res.currency ?? 'CDF');

        // Remplir automatiquement la partie paiement
        $('#recetteMontant').val(res.total_montant ?? 0);
        $('#commission').val(res.commission ?? 0);
        $('#commission_lot').val(res.commission_lot ?? 0);
        $('#commission_attestation').val(res.com_attestation ?? 0);
        $('#Commission_currency').val(res.commission_devise ?? 0);

        
        $('#total_com').val(res.commission_total ?? 0);
        $('#montantTotal').val(res.grand_total ?? 0);
        $('#totalDevise').val(devise ?? '');

        $('#com_currency').text(res.commission_devise ?? '');
        $('#sumtotal_currency').text(devise ?? '');

        // Stockage pour submit final
        //$('#batch_excel_data').val(JSON.stringify(res.lines ?? []));
        $('#batch_excel_data').val(res.lines ? JSON.stringify(res.lines) : "[]");
    }

    function update_balance(balance) 
    { 
        if (balance === "OK") { 
            $("#balance").addClass('bg-green').removeClass('bg-red'); 
            $("#msg_balance").html('SUFFISANTE'); 
            $('#continued').removeClass('disabled'); 

        } else { 
            $("#balance").removeClass('bg-green').addClass('bg-red'); 
            $("#msg_balance").html('INSUFFISANTE'); 
            $('#continued').addClass('disabled'); 
        } 
    }

    function toggle_continue_button(total) 
    { 
        $('#continued').toggleClass('disabled', !(total > 0)); 
    }

    function handle_exchange_rate(param, montant_note) 
    {
        const taux_initial  = <?= $taux['Dollar_4']; ?>;
        const devise_note   = $('#recetteDevise option:selected').val();
        const devise_compte = $('#compteDevise option:selected').val();

        // Conversion si devise est CDF
        if (devise_note === 'CDF') {
            montant_note = montant_note / taux_initial;
        }

        $("#Taux").prop("readonly", false);

        $("#Tauxflag").remove();

        const seuil = parseFloat(5001);
        const condition_taux = montant_note >= seuil &&
            ((devise_compte === 'USD' && devise_note === 'CDF') || (devise_note === 'USD' && devise_compte === 'CDF'));

        if (condition_taux) {
            $('#message').html(`
                <div class="alert alert-info text-black">
                    Le montant de cette opération dépasse 5 000 $. 
                    Veuillez renseigner un taux de change validé par votre superviseur avant de continuer.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                </div>
            `);

            $("#Taux").prop("required", true);

            if (param) {
                const taux_modif = parseFloat($('#Taux').val().replace(/[\s,]/g, '.')) || taux_initial;
                $("#Taux").val(taux_modif === taux_initial ? '' : taux_modif);
            }

            if (!$("#Tauxflag").length) {
                set_taux_flag(1);
            }

        } else {
            $('#message').html('');
            $("#Taux").prop("readonly", true);
            $("#Taux").prop("required", false).val(taux_initial);
            set_taux_flag(0);
        }
    }

    function set_taux_flag(value) 
    {
        const $flag = $("#Tauxflag");

        if ($flag.length) {
            $flag.val(value);
        } else {
            $('<input>', {
                type: 'hidden',
                id: 'Tauxflag',
                name: 'Tauxflag',
                value: value
            }).appendTo('form');
        }
    }

    function next_step(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module.'/taxnotes/display/batch_step_2'); ?>';
        
        $.ajax({
                url: url,
                type: 'POST',
                data: data,
                contentType: false,
                processData: false,
                dataType: 'html',
                success: function(result){

                    $("#loader").html('');

                    if(result == "KO")
                    {
                        $("#loader").html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de ce lot des notes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $("#sub").prop('disabled', true);
                    }
                    else 
                    {
                        $("#pager").html(result);
                        
                        $("#step-1").removeClass('bg-green-active');
                        $("#step-1").addClass('bg-gray');
                        $("#step-2").removeClass('bg-gray');
                        $("#step-2").addClass('bg-green-active');
                    }
                },
                error:function(error){
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La vérification a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
    }
</script>
