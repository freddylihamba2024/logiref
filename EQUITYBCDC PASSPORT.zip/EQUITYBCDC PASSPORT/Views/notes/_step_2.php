<?php $feuille=''; $Infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>

<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php if(isset($_POST['Reference_8']) && $_POST['Reference_8'] !='') {$reference = $_POST['Reference_8'];}else{ $reference = "";}?> 

<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;

if(!isset($infos['totalMontant']))
{
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = 'CDF';

    $valeur01 = $devise01 = $mode = '';
    $infos['standard'] = '';
}

if(isset($note->Id_0) && $note->Id_0 != "")
{
        $disabled = "readOnly"; 
}
else 
{
        $disabled = "";
}

?>

<?php $chtml->box_body_opening('', true);?>

<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
    <style>label {min-width: 150px !important; }</style>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Beneficaire_15" value="DGRAD"  id="regies" />
    <input type="hidden" id="compte_mad" value="<?php echo isset($compte_mad['account']) ? $compte_mad['account'] : ""; ?>" />
    <input type="hidden" id="compte_mad_currency" value="<?php echo isset($compte_mad['currency']) ? $compte_mad['currency'] : ""; ?>" />
    <input type="hidden" name="Infos[Branch_code]" value=""  id="branch_code" />

    <div class="box-body">
        <div class="row">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
            </div> 
        </div>
        <!-- <div class="row">
            <div class="col-md-12" id="loader"></div>
        </div> -->
        
        <!------------------------- Beneficiare  ------------------------------>
        <div class="row">
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
        </div>
        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                    </span>
                    <?php echo form_dropdown('Beneficaire_15', array('DGRAD'), 'DGRAD', ' class="form-control bg-gray" required="required" '); ?>
                    <?php if($encaissement->Id_0 !=NULL): ?>
                        <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                    <?php endif; ?>
                </div>
            </div> 
            <div class="col-md-7 small-box">
                <div class="input-group" id="regie0">
                    <span class="input-group-addon">
                        <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                    </span>
                    <?php if($disabled =="readOnly"): ?>
                        <?php echo form_dropdown('Service_16', $services, isset($encaissement->Service_16) ? $encaissement->Service_16 : "" , 'class="form-control select2" id="service"  required="required" disabled '); ?>
                        <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" >
                    <?php else: ?>
                        <?php echo form_dropdown('Service_16', $services, isset($encaissement->Service_16) ? $encaissement->Service_16 : "" , 'class="form-control select2" id="service"  required="required" '); ?>
                    <?php endif; ?>
                </div>
            </div> 
        </div> 
            
        <!-------------------------  Titre de perception  ------------------------------>
        <div class="row">
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
        </div>
        <div class="row">
            <div class="col-md-5  small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $reference), ' class="form-control" id="reftitre" maxlength="25"  required="required" '.$disabled); ?>
                </div>
            </div>
            <div class="col-md-7  small-box">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', $documents[1]), 'class="form-control" disabled="disabled" id="doc" required="required" ' .$disabled); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
        </div>
        <div class="row"><div id="bl" class="col-md-12"></div></div>
        <div class="row">
            <div class="col-md-5  small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('d-m-Y', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" ' .$disabled); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7  small-box">
                <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label> 
                    </span>
                    <?php if($disabled == "readOnly"): ?>
                        <?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control select2" id="recette" required="required" disabled '); ?>
                        <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17; ?>" >
                    <?php else: ?>
                        <?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control select2" id="recette" required="required" '); ?>
                    <?php endif;?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Art. budg&eacute;taire</label>
                    </span>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : ""), ' class="form-control" id="article-budgetaire" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label> 
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('Notemontant_28', isset($encaissement->Notemontant_28) ? $encaissement->Notemontant_28 : ""), ' id="montantNote" class="form-control" required="required"' .$disabled ); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>

                    <?php if($disabled == 'readOnly'): ?>
                        <?php echo form_dropdown('Notedevise_29', $devises, isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : '', 'class="form-control"  required="required" id="recetteDevise" disabled'); ?>
                        <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>">
                    <?php else: ?>
                        <?php echo form_dropdown('Notedevise_29', $devises, isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "", 'class="form-control" id="deviseNote"  required="required"'); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!------------------------- Payement  ------------------------------>
        
        <div class="row">
            <div class="col-md-5"><br /><span class="f12 text-black">Partie 3 : Client, Assujetti ou Contribuable.</span></div>
            <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px;"></span><br />
                <div style="display: flex; align-items: center; width: 100%;">
                    <label style="margin-bottom: 0;">
                        Intitulé du compte :&nbsp;&nbsp;
                        <span id="accountname"></span>
                    </label>
                    <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                        <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                            <span id="" class="text-red f15"></span>&nbsp;&nbsp;<span id="labelNumber" class="text-red f15"></span>
                        </label>
                    <?php elseif(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>
                    <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                        Frais de correspondance :&nbsp;&nbsp;
                        <span id="correspondent_fees" class="text-red f15">0.00 </span>&nbsp;&nbsp;<span id="correspondent_fees_currency" class="text-red f15"></span>
                        <input type="hidden" id="correspondent_fees_to_retrieve" name="Infos[correspondent_fees]">
                        <input type="hidden" id="correspondent_fees_to_retrieve_currency" name="Infos[correspondent_fees_currency]">
                    </label>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', isset($encaissement->Nif_13) ? $encaissement->Nif_13 : ""), 'class="form-control"  maxlength="86"' .$disabled); ?>
                </div>
            </div> 
            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14" class="f12">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" '.$disabled.' '); ?>
                    </div>
                </div>
                <div class="col-md-2 small-box">
                    <div class="input-group">
                        <span class="input-group-addon no-padding"></span>
                        <?php echo form_input('Infos[CustomerNumber]', set_value('Infos[CustomerNumber]', isset($infos['CustomerNumber']) ? $infos['CustomerNumber'] : ""), 'class="form-control" id="customerNumber" maxlength="7" placeholder="Numéro du client" '.$disabled.' '); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-7 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14" class="f12">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" '.$disabled.' '); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode_19">Mode de paiement</label> 
                    </span>
                    <?php echo form_dropdown('Mode_19', $modes, $mode, 'class="form-control" required="required" id="modeId"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Taux_41">Taux de change</label> 
                    </span>
                    <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                       <label for="Datevaleur_31">Date paiement</label>
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('d-m-Y', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '.$disabled); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                    </span>
                    <?php echo form_input('Reference_32', set_value('Reference_32', ""), 'class="form-control" '); ?>
                </div>
            </div> 
            <div class="col-md-5 small-box">
                <div class="input-group"> 
                    <span class="input-group-addon">
                        <label  for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                    <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                    <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                    <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
                    <input type="hidden" name="Infos[accountType]" value="" id="account_type">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant &agrave; payer</label> 
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required" '.$disabled); ?>
                </div>
                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23" class="f12">
                                <div id="commissionLabel">Commission</div>
                            </label>
                        </span>
                        <!-- Premier input collé au label -->
                        <?php echo form_input('Commission_23', set_value('Commission_23', isset($encaissement->Commission_23a) ? $encaissement->Commission_23a : ''),'class="form-control" id="commission" required="required" placeholder="Com. Note"'); ?>

                        <!-- Deuxième input avec un petit espace -->
                        <span class="input-group-addon" style="background:transparent; border:none; padding:0 4px;"></span>
                        <?php echo form_input('Infos[CommissionAttestation]', set_value('Infos[CommissionAttestation]', isset($infos['CommissionAttestation']) ? $infos['CommissionAttestation'] : ""),'class="form-control" id="commissionAttestation" required="required" placeholder="Com. Attest." style="max-width:150px;"'); ?>
                    </div>
                <?php else : ?>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23" class="f12"><div id="commissionLabel">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission"'); ?>
                    </div>
                <?php endif; ?>
                <input type="hidden" id="commission_to_retrieve" value="">

                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Total">Montant total</label> 
                    </span>
                    <?php echo form_input("Infos[totalMontant]", set_value('Total', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>
                    <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required" id="compteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>
                    <?php if($disabled == 'readOnly'): ?>
                        <?php echo form_dropdown('Devise_12', $devises, isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : '', 'class="form-control"  required="required" id="recetteDevise" disabled'); ?>
                        <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>">
                    <?php else: ?>
                        <?php echo form_dropdown('Devise_12', $devises, isset($encaissement->Devise_12) ? $encaissement->Devise_12 : '', 'class="form-control"  required="required" id="recetteDevise" '); ?>
                    <?php endif; ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>
                    <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF', 'USD'=>'USD'), 'CDF', 'class="form-control"  required="required" id="commissionDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>
                    <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF', 'USD'=>'USD'), 'CDF', 'class="form-control bg-gray" id="totalDevise"'); ?>
                </div>
            </div>
        </div>

        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
        <div class="row">
            <div class="col-md-12"><br/><label class="f12 text-black page-header"><b>Partie additionnelle : Frais liés aux attestations</b></label><br/></div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="form-check abc-checkbox abc-checkbox-success">
                    <input class="form-check-input" id="print_attestation" type="checkbox" checked="" name="Infos[PaidATTESTATION]" value="<?= "FIA" ?>" >
                    <label class="form-check-label text-blue font-bold" for="print_attestation">
                        Frais liés à l’impression de l'attestations
                    </label>
                </div>
            </div>
            <div class="col-md-7">
                <div class="form-check abc-checkbox">
                    <input class="form-check-input" id="print_duplicata" type="checkbox" <?= ($_SESSION['Logiref_role'] != 4) || (isset($encaissement->Printattestation_57) && $encaissement->Printattestation_57 >= 1) ? "":"disabled" ?>  name="Infos[PaidDUPLICATA]" value="<?= "FDA" ?>"  >
                    <label class="form-check-label text-blue font-bold" for="print_duplicata">
                        Frais de duplicata d’attestation
                    </label>
                </div>
            </div>
        </div>
        <?php endif ?>
    </div>
    <div  class="box-footer clearfix">
        <div class="row">
            <div id="createPaiement" class="col-md-12">
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="print" disabled="disabled" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
            </div>
        </div>
    </div>

<?php echo form_close(); ?>
<?php $chtml->box_body_closing(); ?>

<script type="text/javascript"  charset="utf-8">

    $(".select2").select2();

    var taux = '<?php echo $taux['Dollar_4']; ?>';

    var bank = '<?php echo $bank; ?>';
    var ref = '<?php echo $encaissement->Id_0;?>';
    var montant_total = '';
    commission();

    $('#montantNote').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#recetteMontant').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#commission').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $("#contenter").on("click", "#close_form", function(){
        close_form();
    });

    $(".select2").select2();

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
       format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $('#montantNote').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#recetteMontant').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#commission').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#montantNote').change(function(){
        var note = $('#montantNote').val();
        var deviseNote = $('#deviseNote option:selected').val();

        $('#montantNote').val(note);
        $('#recetteMontant').val(note);

        '<?php if(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>'
            if(deviseNote == 'USD')
            {
                get_correspodent_fees();
            }
        '<?php endif; ?>'

        <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
            handle_exchange_rate(true) 
        <?php endif; ?>
        
        commission();
    });

    $('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        var mode = $('#modeId option:selected').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            '<?php if(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>'
                if(devise == 'USD')
                {
                    get_correspodent_fees();
                }
            '<?php endif; ?>'
            
            commission();

            '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
                if(mode == '5')
                {
                    get_accountinternal();
                }
            '<?php endif; ?>';

            <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
                handle_exchange_rate(true) 
            <?php endif; ?>
        }
    });

    <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
        $("#Taux").change(function(){
            var note = $('#montantNote').val();
            var deviseNote = $('#deviseNote option:selected').val();
            var tauxModif = parseFloat($('#Taux').val().split(' ').join('').split(',').join('.'));
           
            if(note !="" && deviseNote != "")
            {
                handle_exchange_rate(false) 

                $('#commission').val('');
                commission();
            }
        });
    <?php endif; ?>

    $('#recetteMontant').change(function()
    {
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();

        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);

        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else
            {
                '<?php if(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>'
                
                    if(deviseNote == 'USD')
                    {
                        get_correspodent_fees();
                    }
                    
                '<?php endif; ?>'
                
                $('#info').html('');
                commission();
            } 
        }
    });

    $('#recetteDevise').change(function(){
            commission();
    });

    $('#service').change(function(){
            commission();
    });

    $('#modeId').change(function() {
        var mode = $('#modeId option:selected').val();

        if(mode == '5')
        {
            '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
                get_accountinternal();
            '<?php endif; ?>';
        }
        else
        {
            $("#compteId").val(''); 
            $("#compteDevise").val('');
            $("#accountname").html('');
        }

        commission();
    });

    $('#commission').change(function(){
        clear_correspondent_fees();
        update_montant_total_final();
    });


    $("#pager").on("change", "#recette", function(){
        commission();

        var recette = $('#recette option:selected').val();
        
        $("#article-budgetaire").val(recette);
    });

    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        //$("#enregistrer").prop('disabled', true);
        scrollUP();
        
        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();
        
        if(mode == '7' || mode == '8')
        {
                get_account_balance(data);  
        }
        
        else
        {
                get_account_balance(data);  
        }  
    });

    $("#compteId").change(function() {

        var bank = '<?php echo $bank; ?>';

        if(bank == '@boa')
        {
            var compte = $(this).val();

            if (compte.length < 18) 
            {
                $("#accountname").removeClass('text-black');
                $("#accountname").removeClass('text-green');
                $("#accountname").addClass('text-red');
                $("#accountname").text('Numéro de compte invalide');
                $("#compteId").val('');
            } 
            else 
            {
                get_accountname();
            }
        }
        else
        {
            get_accountname();
        }
        commission();

    });

    $("#compteDevise").change(function(){
        get_accountname(); 
        commission();

        <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
            handle_exchange_rate(true) 
        <?php endif; ?>
    });

    '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
        $("#customerNumber").change(function(){
            var customer_number = $(this).val();

            if (customer_number.length <= '7') 
            {
                get_customeraccounts()
            }
        });
    '<?php endif ?>';

    $(document).on('change', '#compteId', function () {
        
        $("#accountname").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $(this).find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#accountname').html('');
            $('#account_name, #account_currency, #account_balance, #account_type').val('');
            $('#compteDevise').val('').trigger('change');
            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '978': 'EUR',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        // Ajoute un délai avant d'afficher les infos
        setTimeout(function () {
            $('#accountname').removeClass().addClass('text-green').html(name);
            $('#account_name').val(name);
            $('#account_currency').val(currency);
            $('#account_balance').val(balance);
            $('#account_type').val(type);

            if (currency) {
                $('#compteDevise').val(currency);
                $('#compteDevise').prop('disabled', true);

                // Supprime tout champ hidden existant pour éviter les doublons
                $('input[name="Devise_34"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_34',
                    value: currency
                }).appendTo('form');
            }
        }, 2000);
    });

    $("#cancel").click(function(){
        <?php if($_SESSION['Logiref_role'] == 4): ?>
                close_form();
        <?php else: ?>
            location.reload(); 
        <?php endif; ?>
    });

    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
        handle_checkbox_value("#print_attestation", "FIA");
        handle_checkbox_value("#print_duplicata", "FDA");

        function handle_checkbox_value(selector, valueIfChecked) {
            $(selector).on("change", function () {
                const isChecked = $(this).is(':checked');
                $(this).val(isChecked ? valueIfChecked : "");

                $("#commission").val('');
                commission();
            });
        }

        function commission_attestation() 
        {
            var print_type = $("#print_attestation").val();
            var regie = 'DGI';
            var montant = $('#recetteMontant').val();
            var devise = $('#recetteDevise option:selected').val();
            var commission = $("#commission").val();
            var taux = $('#Taux').val();
            var csrf = $('input[name="csrf_name"]').val();

            $("#enregistrer").prop('disabled', true);

            if (montant !== '' && devise !== '') {
                var url = '<?php echo base_url('admin/fees/display/'); ?>/impression_fees<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
                
                commission = commission ? parseFloat(commission.toString().replace(/\s+/g, "")) : 0;
                montant    = montant ? parseFloat(montant.toString().replace(/\s+/g, "")) : 0;

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        print_type: print_type,
                        regie: regie,
                        montant: montant,
                        commission : commission,
                        devise: devise,
                        taux: taux,
                        csrf_name:csrf
                    },
                    dataType: 'html',
                    encode: true,
                    success: function(reponse) {

                        const result = JSON.parse(reponse);

                        const commission1 = result[0] ? parseFloat(result[0]) : 0;
                        const montant1    = result[2] ? parseFloat(result[2]) : 0;

                        const comm_total    = commission + commission1;
                        const montant_total = commission + montant1;

                        // Formatage
                        const formattedCommission = Number(commission1).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        const formattedMontant    = Number(montant_total).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

                        $("#commissionAttestation").val(formattedCommission);
                        //$("#commissionDevise").val(result[1]);
                        $("#montantTotal").val(formattedMontant);

                        $("#enregistrer").prop('disabled', false);

                        update_montant_total_final();
                    },
                    error: function(error) {
                        $('#bl').html('');
                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        }
    <?php endif; ?>

    function commission()
    {
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId option:selected').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGRAD';
        var commission = $("#commission").val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var compte = $('#compteId').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        '<?php if(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>'
            if(devise != 'USD')
            {
                clear_correspondent_fees();
            }
        '<?php endif; ?>'
        
        //$("#enregistrer").prop('disabled', true);
        
        if(montant !== '' && devise !== '' && service !== ''){
           
            var url = '<?php echo base_url('admin/fees/display/'); ?>/default<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, compte : compte, taux:taux, csrf_name:csrf}, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        var fees_found = (result[3] === true || result[3] === "true");
                        
                        if(fees_found)
                        {
                                // $("#commission_to_retrieve").val(result[0]);
                                // result[0] = result[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                                // result[2] = result[2].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                                // $("#commission").val(result[0]);
                                // $("#commissionDevise").val(result[1]);
                                
                                // update_montant_total_final();
                                
                                $("#loader-sub-menu").html('');

                                const formattedCommission = Number(result[0]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                                const formattedMontant    = Number(result[2]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

                                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                    if ($("#print_attestation").is(':checked')) {
                                        $("#commission").val(formattedCommission);
                                        $("#commissionDevise").val(result[1]);

                                        commission_attestation();
                                    } else {
                                        $("#commissionLabel").html("Commission");

                                        $("#commission").val(formattedCommission);
                                        $("#commissionDevise").val(result[1]);

                                        $("#commissionAttestation").val(0);
                                        
                                        $("#montantTotal").val(formattedMontant);
                                    }
                                <?php else : ?>
                                    $("#commission").val(formattedCommission);
                                    $("#commissionDevise").val(result[1]);

                                    $("#montantTotal").val(formattedMontant);
                                <?php endif; ?>

                                update_montant_total_final();
                        }
                        else
                        {
                                if(commission === '0' || commission === '')
                                {
                                        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                            if ($("#print_attestation").is(':checked')) {
                                                
                                                $("#commission").val('0');
                                                $("#commissionDevise").val('CDF');

                                                commission_attestation();
                                            } else {
                                                $("#commission").val('0');
                                                $("#commissionDevise").val('CDF');
                                                $("#commissionAttestation").val(0);

                                            }
                                        <?php else : ?>
                                                $("#commission").val('0');
                                                $("#commissionDevise").val('CDF');

                                        <?php endif; ?>

                                        //$("#commission").val('0');
                                        //$("#commissionDevise").val('CDF');

                                        update_montant_total_final();
                                        
                                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Les frais bancaires par rapport à ce montant de paiement ne sont pas paramétrés pour cette agence, veuillez contacter votre administrateur s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                        }
                        
                        $("#enregistrer").prop('disabled', false);
                        
                    },
                    error:function(error)
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La récupération a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
    }

    function get_correspodent_fees()
    { 
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId option:selected').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGRAD';
        var commission = $("#commission").val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var compte = $('#compteId').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var csrf = $('input[name="csrf_name"]').val();
        //$("#enregistrer").prop('disabled', true);
        
        if(montant !== '' && devise !== '' && service !== ''){
           
            var url = '<?php echo base_url('admin/fees/display/'); ?>/correspondent_fees<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, compte : compte, csrf_name:csrf}, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        var fees_found = (result[3] === true || result[3] === "true");
                        
                        if(fees_found)
                        {
                                result[0] = Number(result[0]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                                result[2] = Number(result[2]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                                
                                $("#correspondent_fees").html(result[0]);
                                $("#correspondent_fees_currency").html(result[1]);
                                
                                $("#correspondent_fees_to_retrieve").val(result[0]);
                                $("#correspondent_fees_to_retrieve_currency").val(result[1]);
                                update_montant_total_final();
                                $("#loader-sub-menu").html('');
                        }
                        else
                        {
                                $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Les frais de correpondance  pour les paiements DGRAD USD ne sont pas paramétrés pour cette agence, veuillez contacter votre administrateur s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    },
                    error:function(error)
                    {
                        $("#bl").html('<div class="alert aDanger text-white"> La récupération a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
    }
    
    function get_account_balance(data)
    {
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_commission = $('#commissionDevise').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        if (balance == "no-verification-balance")
        {
            submiter(data);
        }
        else
        {
            var url = '<?php echo base_url('branch/taxaccounts/data/get_account_balance'); ?>';

            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_commission : devise_commission, devise_compte : devise_compte, balance : balance, csrf_name:csrf}, 
                dataType    : 'html',  
                encode      : true,
                success: function(reponse)
                {
                        if(reponse == '200')
                        {
                            submiter(data);
                        }
                        else if(reponse == '300')
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette d&eacute;claration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(reponse == '405')
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        $("#enregistrer").prop('disabled', false);
                },
                error:function(error)
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }  
            });
        }
    }
    
    function get_accountinternal() 
    {
        var mode = $('#modeId option:selected').val();
        var devise = $('#deviseNote option:selected').val();
        var regie = 'DGRAD';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountinternal'); ?>';
        
        if (devise !== '' && mode !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    devise: devise,
                    regie: regie,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    $("#loader-sub-menu").html('');

                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
                    $('#compteId').replaceWith(input_html);
                    
                    if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le compte n&apos;existe pas');
                    }
                    else
                    {
                            if (reponse.account ===  '000000000000000000000000')
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-green');
                                    $("#accountname").addClass('text-yellow');
                                    $("#accountname").html("Le compte interne n’a pas été paramétré pour cette agence");
                                    
                                    $("#compteId").val(reponse.account).css("color", "red");

                                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le compte interne n’a pas été paramétré pour cette agence<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-yellow');
                                    $("#accountname").addClass('text-green');
                                    $("#accountname").html("Compte interne");
                                    $("#account_name").val("Compte interne");
                                    $("#account_type").val("MAD");
                                    $("#account_currency").val(reponse.currency);
                                    
                                    $("#account_balance").val("no-verification-balance");
                                    
                                    $("#compteId").val(reponse.account);
                                    $("#compteDevise").val(reponse.currency);
                            }
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function submiter(data)
    {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
            var url = '<?php echo base_url($module.'/taxnotes/save/'); ?>/comptant<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
            var pid = '<?php echo $encaissement->Id_0; ?>';

            var core_banking = '<?php echo $core_banking; ?>';

            scrollUP();
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'json', 
                    encode          : true,
                    success: function(result){

                            $("#loader-sub-menu, #loader, #message").html('');
                            if(result.code === "E300")
                            {
                                    $("#message").html('');
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">D&eacute;saccord commercial ou administratif. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E406")
                            {
                                    $("#message").html('');
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E411")
                            {
                                    $("#message").html('');
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E412")
                            {
                                    $("#message").html('');
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Ce paiement a un probl&egrave;me, veuillez conctater votre administrateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E305")
                            {
                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;. Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E200") 
                            {
                                    $('#step2').remove;
                                    $("#step-2").removeClass('bg-green-active');
                                    $("#step-2").addClass('bg-gray');
                                    $("#step-3").removeClass('bg-gray');
                                    $("#step-3").addClass('bg-green-active');

                                    scrollUP();
                                    var url = '<?php echo base_url($module.'/taxnotes/display/preview'); ?>/' + result.id;
                                    $.get(url, function(data, status){
                                        $("#pager").html(data);
                                        $("#loader-sub-menu").html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    });
                            }
							else {
								$("#loader-sub-menu").html('');
								$("#loader-sub-menu").html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
							}
                    },
                    error:function(error){
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;. Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function get_accountname() 
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var core_banking = '<?php echo $core_banking; ?>';

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);

                            // Vérifier si branch_code existe avant de l'utiliser
                            if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                                $("#branch_code").val(reponse.branch_code);
                            }
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_account_exemption(callback)
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        var url = '<?php echo base_url('branch/taxaccounts/data/get_account_exemption'); ?>';

        if (compte === '' || devise === '') {
            if (typeof callback === 'function') callback(null);
            return;
        }

        $.ajax({
            type: 'POST',
            url: url,
            data: { compte: compte, devise: devise, csrf_name: csrf },
            dataType: 'json',
            success: function(reponse) {
                if (reponse.code == '200') 
                {
                    const formattedCommission = Number(reponse.comm).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $("#commission").val(formattedCommission);
                    $("#commissionAttestation").val(formattedCommission);
                } 

                if (typeof callback === 'function') callback(reponse);
            },
            error: function() {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                if (typeof callback === 'function') callback(null);
            }
        });
    }

    function get_customeraccounts() 
    {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            //$("#labelNumber").html('');
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#labelNumber, #compteLabel").html(loader_img);

        $('#compteDevise').prop('disabled', false);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200")
                {
                    const mapped_currency = {
                        '976': 'CDF',
                        '978': 'EUR',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'compteId',
                        name: 'Compte_33',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#compteId').prop('tagName') === 'SELECT') {
                        $('#compteId').replaceWith(select);
                    } else {
                        $('#compteId').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $("#compteLabel").html('Comptes du client');
                    $("#labelNumber").html('');

                } else{
                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
        
                    $('#compteId').replaceWith(input_html);

                    $("#compteLabel").html('Compte du client');
                    $("#labelNumber").html('');

                    if (reponse.code == '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code == '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code == '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function scrollUP()
    {
        $('html, body').animate({
            scrollTop: $("#loader-sub-menu").offset().top
        }, 20);
    }

    function close_form()
    {
        <?php if(isset($previous_menu) && $previous_menu != ""){ ?>

                $.get("<?php echo base_url($module.'/taxreports/display/'.$previous_menu); ?>", function (data, status) {
                    $("#loader-sub-menu").html('');
                    $("#pager").html(data);
                    $("#pager").addClass('content');

                    $("#close").removeClass('hidden');
                    $("#close_form").addClass('hidden');

                });

        <?php }else{ ?>

                location.reload(); 

        <?php } ?>

    }

    function format_amount(amount)
    {
        amount = amount.replace(/ /g,"");
        amount = amount.replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        return amount;
    }

    function update_montant_total_final() 
    {
        get_account_exemption(function(reponse) {
            // Ici on est sûr que #commission et #commissionAttestation sont mis à jour
            compute_montant_total();
        });
    }

    function compute_montant_total() 
    {
        let taux = parseFloat($('#Taux').val().replace(/\s+/g, '').replace(',', '.')) || <?= $taux['Dollar_4']; ?>;
        let montant_initial = montant = parseFloat($('#recetteMontant').val().replace(/\s/g, '')) || 0;
        let commission = parseFloat($('#commission').val().replace(/\s/g, '')) || 0;
        let commissionAttestation = parseFloat(($('#commissionAttestation').val()?.replace(/\s/g, '') ?? '0')) || 0;

        '<?php if(isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>'

            var correspondentFees = parseFloat($('#correspondent_fees_to_retrieve').val().replace(/\s/g, '')) || 0;
            const deviseCorrespondent = $('#correspondent_fees_to_retrieve_currency').val();

            if (deviseCorrespondent === 'USD')
            {
                correspondentFees = correspondentFees * taux;
            }

        '<?php else: ?>'

            var correspondentFees = 0;
            var deviseCorrespondent = '';

        '<?php endif; ?>'

        const deviseMontant = $('#recetteDevise').val();
        const deviseCommission = $('#commissionDevise').val();

        const tva = (commission * 16) / 100;
        const tvaAttestation = (commissionAttestation * 16) / 100;

        let fraisBCC = 0;

        '<?php if(isset($options['ALL']['bcc-fees-deduction'])): ?>'

            '<?php if(isset($options['ALL']['no-deduction-fees-bcc-when-commission-is-null'])): ?>'

                if (commission > 0)
                {
                    fraisBCC = (montant_initial * 0.5) / 1000;

                    if(deviseMontant == 'USD')
                    {
                        fraisBCC = fraisBCC * taux;
                    }
                }

            '<?php else: ?>'

                    fraisBCC = (montant_initial * 0.5) / 1000;

                    if(deviseMontant == 'USD')
                    {
                        //fraisBCC = fraisBCC * taux;
                        fraisBCC = fraisBCC / taux;
                    }

            '<?php endif; ?>'

        '<?php endif; ?>'

        const montantTotal = montant + commission + commissionAttestation + correspondentFees + fraisBCC + tva + tvaAttestation;

        const montantTotalFormatted = montantTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        $('#montantTotal').val(montantTotalFormatted);
        $('#totalDevise').val(deviseMontant);
    }

    function clear_correspondent_fees()
    {
        const correspondent_fees_amount = 0;
        const correspondent_fees_amount_formatted = correspondent_fees_amount.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        $("#correspondent_fees").html(correspondent_fees_amount);
        $("#correspondent_fees_currency").html('');

        $("#correspondent_fees_to_retrieve").val('');
        $("#correspondent_fees_to_retrieve_currency").val('');
    }

    function handle_exchange_rate(param) 
    {
        const taux_initial = <?= $taux['Dollar_4']; ?>;

        // Nettoyage et parsing du montant
        let montant_note = parseFloat($('#montantNote').val().replace(/\s/g, '').replace(',', '.')) || 0;
        const devise_note = $('#deviseNote').val();
        const devise_compte = $('#compteDevise').val();

        // Conversion si devise est CDF
        if (devise_note === 'CDF') {
            montant_note = montant_note / taux_initial;
        }

        $("#Tauxflag_58").remove();

        const seuil = parseFloat(5001);
        const condition_taux = montant_note >= seuil &&
            ((devise_compte === 'USD' && devise_note === 'CDF') || (devise_note === 'USD' && devise_compte === 'CDF'));

        if (condition_taux) {
            $('#loader').html(`
                <div class="alert alert-info text-black">
                    Le montant de cette opération dépasse 5 000 $. 
                    Veuillez renseigner un taux de change validé par votre superviseur avant de continuer.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                </div>
            `);

            $("#Taux").prop("required", true);

            if (param) {
                const taux_modif = parseFloat($('#Taux').val().replace(/[\s,]/g, '.')) || taux_initial;
                $("#Taux").val(taux_modif === taux_initial ? '' : taux_modif);
            }

            if (!$("#Tauxflag_58").length) {
                set_taux_flag(1);
            }
        } else {
            $('#loader, #loader2, #loader3').html('');
            $("#Taux").prop("required", false).val(taux_initial);
            set_taux_flag(0);
        }
    }

    function set_taux_flag(value) 
    {
        const $flag = $("#Tauxflag_58");

        if ($flag.length) {
            $flag.val(value);
        } else {
            $('<input>', {
                type: 'hidden',
                id: 'Tauxflag_58',
                name: 'Tauxflag_58',
                value: value
            }).appendTo('form');
        }
    }


</script>

