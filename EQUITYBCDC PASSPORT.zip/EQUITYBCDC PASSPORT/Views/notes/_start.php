<div class="col-md-12 p-0">
    <div class="row">
        <div class="col-md-12" id="loader"></div>
    </div>
    
    <div class="row">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> f16  center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">V&eacute;rification de la note<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Confirmation du paiement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left">Impression de la preuve<br/></div>
        </div>
    </div>
    <div class="row"><div class="col-md-12"><br/></div></div>
    <div class="row">    
        <div id="pager" class="col-md-12">
            <?php if($step==2): ?>
                <?php echo $this->load->view('_step_2'); ?>
            <?php elseif($step==3): ?>
                <?php echo $this->load->view('_step_3'); ?>
            <?php else: ?>
                <?php $chtml->box_body_opening("", true);?>  
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <div class="row">
                    <div class="col-md-3">
                        <div id="approvalWarning" style="color:#F00"></div><br/>
                        <p>
                            Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de cette note!
                        </p>
                        <br/><br/>
                    </div>
                    <div class="col-md-9 bLeft">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                                          <?php echo form_input('Reference_8','', 'class="form-control"  id="Reference_32" '); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="row">
                                <div class="col-md-12">
                                    <button id="saisie" type="button" style="margin-left:5px;" name="button" class="btn btn btn-default pull-left margin" disabled='disabled'><i class="fa fa-pencil"></i> Saisie manuelle </button>&nbsp;
                                    <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                    <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
                <?php $chtml->box_body_closing(); ?>
            <?php endif;?>
        </div>
    </div>     

</div>


<script type="text/javascript">
    
$(".select2").select2();

$('#Montant_11').on("keyup", function() {
    this.value = this.value.replace(/ /g,"");
    this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
});
    
$("#mainform").submit(function(event){
     event.preventDefault();
     var data = $(this).serialize();
     next_step(data);

});

$("#saisie").click(function(){
    var data = $("#mainform").serialize();
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
    var url = '<?php echo base_url($module.''); ?>/taxnotes/display/create';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        success: function(result){

                $("#loader-sub-menu").html('');
                $("#pager").html(result);
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-gresen-active');
        },
        error:function(error){
            $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La requête a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
});


$("#cancel").click(function(){
   location.reload(true);
});

function next_step(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
    //var url = '<?php //echo base_url($module.'/taxnotes/display/create'); ?>';
    var url = '<?php echo base_url($module.'/taxnotes/display/verification'); ?>';
    
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){

                $("#loader-sub-menu").html('');

                if(result == "E404")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white"> D&eacute;sol&eacute;... Aucune information trouv&eacute;e pour ce num&eacute;ro de r&eacute;f&eacute;rence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#saisie").removeClass('btn-default');
                    $("#saisie").addClass('btn-success');
                    $("#saisie").prop("disabled", '');

                    $("#bloc_manual").removeClass('hidden');

                    $("#Montant_11").prop('required', true);
                    $("#service").prop('required', true);
                    $("#recette").prop('required', true);
                    $("#recetteDevise").prop('required', true);
                }
                else if(result == "E406")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!...probl&egrave;me de connexion avec Logirad !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#saisie").removeClass('btn-default');
                    $("#saisie").addClass('btn-success');
                    $("#saisie").prop("disabled", '');

                    $("#bloc_manual").removeClass('hidden');
                    $("#ref_note").removeClass('col-md-6');
                    $("#ref_note").addClass('col-md-12');
                }
                else if(result == "E002")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Un probl&eagrave;me de connexion est survenu lors de la r&eacute;cup&eacute;ration de la note de perception. Veuillez r&eacute;essayer s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == "E405")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Alerte: La r&eacute;f&eacute;rence n&pos;est pas envoy&eacute;e...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else 
                {
                    $("#pager").html(result);
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');
                }
            },
            error:function(error){
                $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La vérification a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
    });
}
</script>
