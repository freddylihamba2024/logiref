<?php if(!empty($lines)): ?>
      <table id="table" class="table table-hover table-striped">
          <thead>
                <tr class="bg-gray">
                    <th width="6%">Id</th>
                    <th width="3%">Sens</th>
                    <th>D&eacute;bit</th>
                    <th>Cr&eacute;dit</th>
                    <th  width="13%">Montant d&eacute;bit</th>
                    <th  width="13%">Montant cr&eacute;dit</th>
                    <th>Designation</th>
                    <th width="8%">Date</th>
                    <th class="text-center">Statut</th>
                </tr>
          </thead>
          <tbody>
            <?php
                foreach($lines as $row) {
            ?>
                    <tr class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>">
                        <td width="6%"><?php echo $row->Id_0; ?></td>
                        <td width="3%"><?php echo $row->Operation_8; ?></td>
                        <td width="13%" class="<?php if($row->Compte_9=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_9; ?></td>
                        <td width="13%" class="<?php if($row->Compte_13=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_13; ?></td>
                        <td><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                        <td><?php echo (!empty($row->Devise_26))?$row->Devise_26." ". number_format($row->Montant_25,2,","," ") : $row->Devise_11." ". number_format($row->Montant_10,2,","," ");?></td>
                        <td><?php echo $row->Libelle_12; ?></td>
                        <td width="8%"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                        <td width="10%" class="text-center">
                            <?php if (isset($row->Status_2) && $row->Status_2 == "2"): ?>
                                <span class='text-green bold'>Intégré</span>
                            <?php elseif(isset($row->Status_2) && $row->Status_2 == "5"): ?>
                                <span class='text-red bold'>Non intégré</span>
                            <?php else: ?>
                                <span class='text-yellow bold'>En attente de validation</span>
                            <?php endif; ?>
                        </td>
                    </tr>
            <?php
                }
            ?>
          </tbody>
      </table>
<?php endif;?>