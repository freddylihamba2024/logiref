<?php 
$userid = $this->session->userdata["user_id"];
$usertype = $this->session->userdata["user_type"];
$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;

?>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<div class="row">
    <div class="col-md-12 no-padding" id="message1"></div>
</div>
<div class="row">
    <div class='col-md-12 no-padding'>
        <?php $chtml->box_body_opening('', true); ?>
        <div id="list"  class="col-md-12">
            <?php if(!empty($encaissements) || !empty($bulletins) || !empty($prepayments)): ?>
            <table id="table" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-gray">
                        <th></th>
                        <th>Date</th>
                        <th>Client</th>
                        <th>B&eacute;n&eacute;ficiaire</th>
                        <th>Recette</th>
                        <th>Montant</th>
                        <th>Commissions</th>
                        <th>Op&eacute;rateur</th>
                        <th><span class="fa fa-fw fa-folder f14"></span></th>
                        <th id="all"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check hidden f16"></i></th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                # Block las BL
                foreach($bulletins as $row){ 
                    $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - '; 
                    $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                    $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                    $results = json_decode($row->Results_13);
                    $recieptDate = explode("/",$results->receiptDate);
                    $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                ?>
                   <tr>
                        <td width="5"><b><?= ++$i; ?></b></span></td>
                        <td width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                        </td>
                        <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                        <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                        <td class="text-blue">
                            <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                        </td>
                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                        </td>
                        <td width="25">
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_12; ?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                            <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_12; ?>' name="amounts_bulletins[]" />
                        </td>
                    </tr>
                <?php 

                } 
                ?>

               <?php 
                #Block last prepayment
                foreach($prepayments as $row){ 
                    $agence = (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - '; 
                    $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                    $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                ?>
                   <tr>
                        <td width="5"><b><?= ++$i; ?></b></span></td>
                        <td width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                        </td>
                        <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                        <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?><br>
                            <span class="text-gray">Bulletin pr&eacute;pay&eacute;</span>
                        </td>
                        <td class="text-blue">
                            <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                        </td>
                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                        </td>
                        <td width="25">
                            <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                            <input type='hidden' class="input_val1" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="amounts_prepayments[]" />
                        </td>
                    </tr>
                <?php 

                } 
                ?>

                <?php  

                # 

                foreach($encaissements as $row){ 
                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                ?>
                    <tr>
                        <td width="5"><b><?= ++$i; ?></b></span></td>
                        <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                        </td>
                        <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                        <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                        <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                        <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                            <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                              <br/>
                              <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                            <?php endif;?>
                        </td>
                        <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                        </td>
                        <td width="25">
                            <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' onclick="reverser('<?php echo $row->Id_0;?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Devise_12;?>', '<?php echo $row->Contrevaleur_22; ?>')" value="<?php echo $row->Id_0; ?>" name="paiements[<?php echo $row->Beneficaire_15;?>][]" />
                            <input type='hidden' class="input_val2" disabled="disabled" id='t<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Montant_11; ?>' name="amounts_paiements[]" />
                            <input type='hidden'  value='<?php echo $row->Devise_12; ?>' name="devise_paiement[]" />
                        </td>
                    </tr>
                <?php 

                } 
                ?>
                </tbody>    
            </table>
            <?php else:?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun paiement trouv&eacute;!<br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
        <div  class="box-footer clearfix col-md-12">
            <div class="row">
                <div id="createPaiement" class="col-md-12 no-padding">
                    <button type="submit" id="submit"  name="submit" class="btn btn-success pull-left disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;<span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="sendXML" class="btn btn-default" disabled><i class="fa fa-share-square-o"></i>&nbsp;&nbsp;Envoyer en XML&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="uploadExcel" class="btn btn-default" disabled><i class="fa  fa-file-excel-o"></i>&nbsp;&nbsp;T&eacute;l&eacute;charger le fichier Excel &nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
</div>
<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
var ref = '';
$("#search").click(function(e){
   
    var regie = $('#regie option:selected').val(); 
    if(regie !="")
    {
            search_paiements(regie);
    }
    else
    {
            $('#loader').html('<div class="alert aWarning text-white">Alerte: Veuillez s&eacute;l&eacute;ctionner r&eacute;gie pour filtrer les paiements !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
     
});

$("#sendXML").click(function(){
    
        if(ref !=='')
        {
            alert(ref)
        }
        else
        {
            $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        }
    
});

$("#uploadExcel").click(function(){
    
    
        if(ref !=='')
        {
            
            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/offline'); ?>/data/export_to_excel/'+ref;

            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(result){
                            
                            var $allInputs = $("#table").find("input[type = 'checkbox']"); 
                            for(var i = 0; i < $allInputs.length ; i++)
                            {
                                    $($allInputs[i]).prop('disabled',true);
                            }
                            
                            if(result === "404")
                            {
                                    $('#message1').html('<div class="alert aWarning text-white">Alerte: echec! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                   //$("#loader").html(result);
                                   print(result);
                            }
                           
                           

                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });
            
        }
        
});
 
 
$('#checkall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', 'checked');
    $('.check').removeClass("hidden");
    $('#checkall').addClass("hidden");
    $('#uncheckall').removeClass("hidden");
    
    $('.input_val').prop('disabled', false);
    $('.input_val1').prop('disabled', false);
    $('.input_val2').prop('disabled', false);
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;

    
    $("#submit").removeClass("disabled");
    $("#submit").prop("disabled",false);
    $("#index").html('('+ index+')');
});

$('#uncheckall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', '');
    $('.check').addClass("hidden");
    $('#checkall').removeClass("hidden");
    $('#uncheckall').addClass("hidden");
    
    $('.input_val').prop('disabled', true);
    $('.input_val1').prop('disabled', true);
    $('.input_val2').prop('disabled', true);
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;
    
    $("#submit").removeClass("btn-primary");
    $("#submit").addClass("btn-success");
    $("#submit").prop("disabled",true);
    $("#index").html('');
    
});



$("#mainform").submit(function(event){
        event.preventDefault();
        $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/offline'); ?>/save/instructions';
        
        var data = $(this).serialize();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    
                    if(result === "202")
                    {
                            $('#message1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E202...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "400")
                    {
                            $('#message1').html('<div class="alert aWarning text-white">Alerte: Aucune instrcution n&apos;a &eacute;t&eacute; trouv&eacute;e!...rassurez-vous que les paiements s&eacute;l&eacute;ctionn&eacute;es ne sont pas valid&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "501")
                    {
                            $('#message1').html('<div class="alert aWarning text-white">Alerte: erreur fatal E501...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            ref = result;
                            $('#message1').html('');
                            
                           
                            
                            $("#uncheckall").prop('disabled',true);
                            $("#checkall").prop('disabled',true);
                            
                            $("#sendXML").removeClass('btn-default');
                            $("#sendXML").addClass('btn-primary');

                            $("#uploadExcel").removeClass('btn-default');
                            $("#uploadExcel").addClass('btn-success');

                            $('#sendXML').prop('disabled', false);
                            $('#uploadExcel').prop('disabled', false);
                            $('#submit').prop('disabled', true);
                            $("#message1").html('<div class="alert aSuccess text-white">Bravo! enregistrement eff&eacute;ctu&eacute; avec succ&egrave;s...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

function view(id, regie)
{
    var url ='';
    if(regie === 'DGDA')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGI')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGRAD')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
        
         
    }
          
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function view_manual(id, regie)
{
    
    var url ="<?php echo base_url($module.'/taxothers/display/preview'); ?>/"  + id;
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function viewPrepayment(id)
{
    '<?php if($_SESSION['Logiref_role'] !=4): ?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php else :?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php endif; ?>'
        
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function reverser(id, regie, devise)
{
        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;

        if(index > 0)
        {
                $('#t'+id+''+regie).prop('disabled', false);
                $('#r'+id+''+regie).prop('disabled', false);

                $("#submit").removeClass("disabled");
                $("#submit").prop("disabled",false);
                $("#index").html('('+ index+')');
        }
        else if(index <= 0)
        {
                $('#checkall').removeClass("hidden");
                $('#uncheckall').addClass("hidden");
                
                $('#t'+id+''+regie).prop('disabled', true);
                $('#r'+id+''+regie).prop('disabled', true);
                
                $("#submit").removeClass("btn-primary");
                $("#submit").addClass("btn-success");
                $("#submit").prop("disabled",true);
                $("#index").html('');

                regie = "";
                devise = "";
        }
}


function search_paiements(regie)
{
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxoffline/display/search'); ?>';
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : {regie : regie}, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    
                    $('#message1').html('');
                    $('#list').html(result);
                    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function print(buffer)
{
    var w = window.open('<?php echo base_url()?>'+buffer);
}
</script>



