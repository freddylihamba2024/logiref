<?php 

$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>

<div class="row">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <div>
            <h1 class="text-blue f30">Paiements extraits</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente tous les paiments extraits pour la reconciliation.</span></p> 
        </div>
    </div>
</div>

<div id="pager"  class="">
    <div class="row">
        <div class="col-md-12">
            <?php $chtml->box_body_opening('', true); ?>
                <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">R&eacute;gie financière</span>
                                    <input class="form-control" name="start" value="DGDA" id="regie" type="text" disabled>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">De </span>
                                    <input class="form-control" name="start" value="" id="datepicker1" type="text">
                                    <span class="input-group-addon"> à </span>
                                    <input class="form-control" name="end" value=""  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <button type="button" id="search" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div  id="loader" class="col-md-12"></div>
            <div class="row">
                <div id="panel" class="col-md-12">
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                        <?= csrf_field() ?>
                        <?php $chtml->box_body_opening('', true); ?>
                        <div id="list"  class="col-md-12">
                            <?php if(!empty($encaissements) || !empty($bulletins) || !empty($prepayments)): ?>
                                <table id="table" class="table table-hover table-striped">
                                    <thead>
                                        <tr class="bg-gray">
                                            <th></th>
                                            <th>Date</th>
                                            <th>Client</th>
                                            <th>B&eacute;n&eacute;ficiaire</th>
                                            <th>Recette</th>
                                            <th>Montant</th>
                                            <th>Commissions</th>
                                            <th>Op&eacute;rateur</th>
                                            <th><span class="fa fa-fw fa-folder f14"></span></th>
                                            <th id="all"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check d-none f16"></i></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        # Block last BL
                                        foreach($bulletins as $row):
                                            $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - '; 
                                            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                            $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                            $results = json_decode($row->Results_13);
                                            $recieptDate = explode("/",$results->receiptDate);
                                            $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                                        ?>
                                        <tr>
                                            <td width="5"><b><?= ++$i; ?></b></span></td>
                                            <td width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                            </td>
                                            <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                            <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                            <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                            <td class="text-blue">
                                                <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                            </td>
                                            <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                            <td width="25">
                                                <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_12; ?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                                                <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_12; ?>' name="amounts_bulletins[]" />
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>

                                        <?php 
                                            #Block last prepayment
                                            foreach($prepayments as $row):
                                                $agence = (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - '; 
                                                $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                                                $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                        ?>
                                        <tr>
                                            <td width="5"><b><?= ++$i; ?></b></span></td>
                                            <td width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                            </td>
                                            <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                                            <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                            <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?><br>
                                                <span class="text-gray">Bulletin pr&eacute;pay&eacute;</span>
                                            </td>
                                            <td class="text-blue">
                                                <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                                            </td>
                                            <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                            <td width="25">
                                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                                                <input type='hidden' class="input_val1" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="amounts_prepayments[]" />
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>

                                        <?php if(!empty($encaissements)): ?>
                                        <?php  
                                            # Encaissements
                                            foreach($encaissements as $row):
                                                $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                                $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                        ?>
                                        <tr>
                                            <td width="5"><b><?= ++$i; ?></b></span></td>
                                            <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                            </td>
                                            <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                            <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                            <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                                            <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                                <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                                <br/>
                                                <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                                <?php endif;?>
                                            </td>
                                            <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                            <td width="25">
                                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' onclick="reverser('<?php echo $row->Id_0;?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Devise_12;?>', '<?php echo $row->Contrevaleur_22; ?>')" value="<?php echo $row->Id_0; ?>" name="paiements[<?php echo $row->Beneficaire_15;?>][]" />
                                                <input type='hidden' class="input_val2" disabled="disabled" id='t<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Montant_11; ?>' name="amounts_paiements[]" />
                                                <input type='hidden'  value='<?php echo $row->Devise_12; ?>' name="devise_paiement[]" />
                                            </td>
                                        </tr>
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    </tbody>    
                                </table>
                            <?php else:?>
                                <div class="col-md-12">
                                    <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                            <span class="d-block p-2 f14 text-black"> Aucun paiement trouv&eacute;!</span>
                                    </section>
                                </div>
                            <?php endif;?>
                        </div>
                        <div  class="box-footer clearfix col-md-12">
                            <div class="row">
                                <div id="createPaiement" class="col-md-12 no-padding">
                                    <button type="submit" id="submit"  name="submit" class="btn btn-success pull-left disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;<span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                    <button type="button" id="uploadExcel" class="btn btn-default" disabled><i class="fa  fa-file-excel-o"></i>&nbsp;&nbsp;T&eacute;l&eacute;charger le fichier Excel &nbsp;&nbsp;</button>&nbsp;&nbsp;
                                </div>
                            </div>
                        </div>
                        <?php $chtml->box_body_closing(); ?>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
 
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});

let ref = '';

let table = $('#table').DataTable({
    "paging": true,
    "lengthChange": false,
    "searching": false,
    "ordering": true,
    "info": true,
    "autoWidth": false,
    "pageLength": 50, // pas pageSize
    "bFilter": false,
    "bLengthChange": false
});

// cocher tout
$(document).on("click", "#checkall", function() {
    // Sélectionner tous les checkboxes de toutes les pages
    table.$('input:checkbox').prop('checked', true);

    $('.check').removeClass("d-none");
    $('#checkall').addClass("d-none");
    $('#uncheckall').removeClass("d-none");

    $('.input_val, .input_val1, .input_val2').prop('disabled', false);

    var index = table.$('input:checkbox:checked').length;

    $("#submit").removeClass("disabled").prop("disabled", false);
    $("#index").html('(' + index + ')');
});

// décocher tout
$(document).on("click", "#uncheckall", function() {
    // Décocher tous les checkboxes de toutes les pages
    table.$('input:checkbox').prop('checked', false);

    $('.check').addClass("d-none");
    $('#checkall').removeClass("d-none");
    $('#uncheckall').addClass("d-none");

    $('.input_val, .input_val1, .input_val2').prop('disabled', true);

    $("#submit").removeClass("btn-primary").addClass("btn-success").prop("disabled", true);
    $("#index").html('');
});


$("#search").click(function(event){
    event.preventDefault();
   
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    
    let  url = '<?php echo base_url($module.'/taxoffline/display/extractions/search'); ?>';
    let data = $("#searchform").serialize();
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                    
                    $('#loader').html('');
                    $('#list').html(result);

                    // Réinitialiser DataTable
                    if ($.fn.DataTable.isDataTable('#table')) {
                        $('#table').DataTable().destroy();
                    }
                    table = $('#table').DataTable({
                        paging: true,
                        searching: false,
                        ordering: false,
                        pageLength: 50, 
                    });
                    
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
     
});


$(document).on("submit", "#mainform", function(event){
    event.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    
    let url = '<?php echo base_url($module.'/taxoffline'); ?>/save/instructions';
    
    // récupère TOUS les inputs (toutes pages confondues)
    let data = table.$('input, select, textarea').serialize();
    data += '&<?= csrf_token() ?>=<?= csrf_hash() ?>';

    $.ajax({
        type: 'POST', 
        url: url, 
        data: data, 
        dataType: 'html', 
        encode: true,
        success: function(response){
            var result = JSON.parse(response);

            if (result.code === "200") {
                ref = result.pid;
                $('#loader').html('');

                $("#uncheckall").prop('disabled',true);
                $("#checkall").prop('disabled',true);

                $("#uploadExcel").removeClass('btn-default').addClass('btn-success');
                $('#uploadExcel').prop('disabled', false);
                $('#submit').prop('disabled', true);

                $("#loader").html('<div class="alert aSuccess text-white">Bravo! enregistrement eff&eacute;ctu&eacute; avec succ&egrave;s...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result.code === "202") {
                $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E202! '+result.message+' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result.code === "400") {
                $('#loader').html('<div class="alert aWarning text-white">Alerte: '+result.message+' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result.code === "501") {
                $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E501! '+result.message+' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else {
                $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E000! r&eacute;essayez...! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error:function(error){
            alert('ERROR!' + error);
        }
    });
});

// export Excel
$(document).on("click", "#uploadExcel", function(){
    if(ref !=='') {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

        var data = $("#mainform").serialize();
        var url = '<?php echo base_url($module.'/taxoffline'); ?>/data/export_to_excel/'+ref;

        $.ajax({
            type: 'POST', 
            url: url, 
            data: data, 
            dataType: 'html', 
            encode: true,
            success: function(result){
                // désactiver toutes les checkbox après export
                $("#table").find("input[type='checkbox']").prop('disabled',true);
                
                if(result === "404") {
                    $('#loader').html('<div class="alert aWarning text-white">Alerte: echec! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $("#loader").html('');
                    window.open(result, '_blank');
                }
            },
            error:function(error){
                alert('ERROR:'+error);
            }
        });
    }
});

// gestion des checkboxes individuels avec delegation
$(document).on("change", "#table input[type='checkbox']", function(){
    var index = table.$('input:checkbox:checked').length;

    if(index > 0){
        $("#submit").removeClass("disabled").prop("disabled", false);
        $("#index").html('(' + index + ')');
    } else {
        $("#submit").addClass("disabled").prop("disabled", true);
        $("#index").html('');
    }
});


function view(id, regie)
{
    var url ='';
    if(regie === 'DGDA')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGI')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGRAD')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/edit'); ?>/"  + id;
        '<?php endif; ?>' 
    }
          
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function viewPrepayment(id)
{
    '<?php if($_SESSION['Logiref_role'] !=4): ?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php else :?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php endif; ?>'
        
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#loader").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function reverser(id, regie, devise)
{
        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;

        if(index > 0)
        {
                $('#t'+id+''+regie).prop('disabled', false);
                $('#r'+id+''+regie).prop('disabled', false);

                $("#submit").removeClass("disabled");
                $("#submit").prop("disabled",false);
                $("#index").html('('+ index+')');
        }
        else if(index <= 0)
        {
                $('#checkall').removeClass("hidden");
                $('#uncheckall').addClass("hidden");
                
                $('#t'+id+''+regie).prop('disabled', true);
                $('#r'+id+''+regie).prop('disabled', true);
                
                $("#submit").removeClass("btn-primary");
                $("#submit").addClass("btn-success");
                $("#submit").prop("disabled",true);
                $("#index").html('');

                regie = "";
                devise = "";
        }
}
</script>

