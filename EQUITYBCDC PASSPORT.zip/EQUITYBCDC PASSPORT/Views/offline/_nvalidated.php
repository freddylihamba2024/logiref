<?php if(!empty($integrations)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-aqua-active">
                <th></th>
                <th>Int&eacute;gr&eacute; par</th>
                <th>B&eacute;n&eacute;ficiaire</th>
                <th class="center">Nombre de paiements</th>
                <th class="center">Nombre d&apos;instructions</th>
                <th>Montant</th>
                <th>Date</th>
                <th><span class="fa fa-fw fa-folder f14"></span></th>
                <th width="5%">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php  foreach($integrations as $row){ 

        ?>
            <tr>
                <td><b>#</b></td>
                <td class=""><?= isset($users[$row->Creator_4]) ? $users[$row->Creator_4] : ""; ?></td>
                <td class=""><?php echo $row->Regie_13; ?></td>
                <td class="center"><?php echo $row->Paiements_10; ?></td>
                <td class="center"><?php echo $row->Instructions_11; ?></td>
                <td>
                    <?php 
                            if($row->Devise_16 == ""):
                                echo 'CDF '.number_format($row->Montant_12,2,","," "); ?>
                    <?php   
                            else:
                                echo $row->Devise_16.' '.number_format($row->Montant_12,2,","," "); 
                            endif;
                    ?>
                </td>
                <td><?php echo $row->Date_1 ?></td>
                <td class=""> 
                    <?php  if(file_exists($row->Pathexcel_8) || strlen($row->Pathexcel_8)>5):?>
                        <a href="<?php echo base_url($row->Pathexcel_8); ?>" target="_blank"><span class="fa fa-file-excel-o text-green f14"> </span></a>
                    <?php else :?>
                        <span class="fa fa-file-excel-o text-gray f14"> </span>
                    <?php endif;?>
                </td>
                <td width="25" id="check<?php echo $row->Id_0;?>">
                    <a id="btnv<?php echo $row->Id_0;?>" onclick="confirm('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-primary">Confirmer</a>
                </td>
            </tr>
        <?php 

        } 
        ?>
        </tbody>    
    </table>
<?php else:?>
    <section id="cat_list">
        <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            Aucune intégration en attente de confirmation !<br/>
        </div>
    </section>z
<?php endif;?>

    
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": false,
      "bLengthChange": false
});

</script>