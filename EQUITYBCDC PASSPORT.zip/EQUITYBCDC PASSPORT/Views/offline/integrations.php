<?php 

$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>
<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-5 pull-left">
                <h2 class="text-blue">Paiements int&eacute;gr&eacute;s manuellement</h2>
            </div>
            <div class="col-md-7 pull-right">
                <ul class="nav pull-right">
                    <li class="nav-item">
                        <a class="f14 bRight active" onclick="pager('nvalidated_paiements')" id="paiements" > 
                            <i class="fa fa-list-ul text-success f18"></i> <span class="f13" > Paiements export&eacute;s</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="f14 bRight active" onclick="pager('nvalidated')" id="nvalidated" > 
                            <i class="fa fa-warning text-yellow f18"></i> <span class="f13" >Intégrations en attente validation</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="f14 bRight" onclick="pager('validated')" id="validated" > 
                            <i class="fa fa-check text-blue f18"></i> <span class="f13" >Valid&eacute;s</span>
                        </a>
                    </li>
                </ul>
            </div> 
        </div>
        <div class="row">
            <div class="col-md-12" style="margin-top:-8px;">
                    <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente tous les pr&eacute;paiments extraits pour le traitement.</span></h5>
            </div>
        </div>
        <div><br></div>
        <div id="pager"  class="col-md-12"></div>
        <div  id="loader" class="col-md-12"></div>
        <div class="row">
            <div id="panel" class="col-md-12">
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <?php $chtml->box_body_opening('', true); ?>
                    <div class="box-body col-md-12" id="paiementslist">
                        <?php if(!empty($integrations)): ?>
                        <table id="table" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-aqua-active">
                                    <th></th>
                                    <th>Int&eacute;gr&eacute; par</th>
                                    <th>B&eacute;n&eacute;ficiaire</th>
                                    <th class="center">Nombre de paiements</th>
                                    <th class="center">Nombre d&apos;instructions</th>
                                    <th>Montant</th>
                                    <th>Date</th>
                                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                                    <th width="5%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php  foreach($integrations as $row){ 

                            ?>
                                <tr>
                                    <td><b>#</b></td>
                                    <td class=""><?= isset($users[$row->Creator_4]) ? $users[$row->Creator_4] : ""; ?></td>
                                    <td class=""><?php echo $row->Regie_13; ?></td>
                                    <td class="center"><?php echo $row->Paiements_10; ?></td>
                                    <td class="center"><?php echo $row->Instructions_11; ?></td>
                                    <td>
                                        <?php 
                                                if($row->Devise_16 == ""):
                                                    echo 'CDF '.number_format($row->Montant_12,2,","," "); ?>
                                        <?php   
                                                else:
                                                    echo $row->Devise_16.' '.number_format($row->Montant_12,2,","," "); 
                                                endif;
                                        ?>
                                    </td>
                                    <td><?php echo $row->Date_1 ?></td>
                                    <td class=""> 
                                        <?php  if(file_exists($row->Pathexcel_8) || strlen($row->Pathexcel_8)>5):?>
                                            <a href="<?php echo base_url($row->Pathexcel_8); ?>" target="_blank"><span class="fa fa-file-excel-o text-green f14"> </span></a>
                                        <?php else :?>
                                            <span class="fa fa-file-excel-o text-gray f14"> </span>
                                        <?php endif;?>
                                    </td>
                                    <td width="25" id="check<?php echo $row->Id_0;?>">
                                        <a id="btnv<?php echo $row->Id_0;?>" onclick="confirm('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-primary">Confirmer</a>
                                    </td>
                                </tr>
                            <?php 

                            } 
                            ?>
                            </tbody>    
                        </table>
                        <?php else:?>
                        <div class="col-md-12">
                            <section id="cat_list" class="text-center marginTop150">
                                <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                <span class="d-block p-2 f14 text-black">Aucune intégration en attente de confirmation !</span>
                            </section>
                        </div>
                        <?php endif;?>
                    </div>
                <?php $chtml->box_body_closing(); ?>
            <?php echo form_close(); ?>
        </div>
        </div>


</div>

<script type="text/javascript">
$("#nvalidated").css('background-color', 'rgba(0,0,0,0.04)');
$("#validated").css('background-color', '');  
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": false,
      "bLengthChange": false
});


function view(id){
      
    var url = '<?php echo base_url($module.'/offliene/display/export'); ?>/' + id;
    var w = window.open(url);
}

function pager(tab) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module); ?>/taxoffline/display/' + tab ;
        $.get(url, function(data, status){
                $("#loader").html('');
                $("#paiementslist").html(data);
                
                if(tab=='nvalidated')
                {
                    $("#nvalidated").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#paiements").css('background-color', '');
                    $("#validated").css('background-color', '');
                }
                else if(tab=='validated')
                {
                    $("#validated").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#nvalidated").css('background-color', '');
                    $("#paiements").css('background-color', '');
                }  
                else if(tab=='nvalidated_paiements')
                {
                    $("#paiements").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#validated").css('background-color', '');
                    $("#nvalidated").css('background-color', '');
                }  
        });
}


function confirm(id)
{
    $("#btnv"+id).html('...');
    $("#btnv"+id).prop('disabled', false);
    var url ="<?php echo base_url($module.'/taxoffline/save/confirmation'); ?>/"  + id;
    
    var btn = $("#check"+id).html();
    $.get(url, function(data, status){
        if(data > 0)
        {
            $("#btnv"+id).html('');
            $("#check"+id).html('<span class="fa fa-fw text-green fa-check f20"></span>');
        }
        else
        {
            $("#btnv"+id).prop('disabled', false);
            $("#check"+id).html(btn);
        }
      
        
    });
}

</script>

