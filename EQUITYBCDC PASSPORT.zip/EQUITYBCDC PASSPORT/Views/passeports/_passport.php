<div class="col-md-12">
    <div class="row">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">V&eacute;rification de la note<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound  <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">Confirmation du paiement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">Impression de la preuve<br/></div>
        </div>
    </div>
</div>

<div class="col-md-12 pr-0 pl-0"><br/>
    <div id="loader"></div>
    <div id="logirad-message"></div>
</div>

<div id="pager" class="">
    <?php
        if($step==2) :
            echo view('_passport_2');
        elseif($step==3):
            echo view('_passport_3');
        else:
    ?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $chtml->box_body_opening("", true);?>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-4">
                        <div id="approvalWarning"></div><br/>
                        <p>
                            Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de passeport !
                        </p>
                        <br/><br/>
                    </div>
                    <div class="col-md-8 bLeft">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                                <?php echo form_input('Reference_8','', 'class="form-control"  id="Reference_32" required = "required"'); ?>
                                <input type="hidden" name="Typerecette_12" value="27421600"/>
                            </div>
                        </div>
                        <div class="box-footer  clearfix">
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                    <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?>
    <?php endif; ?>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    $("#mainform").submit(function(event){
        event.preventDefault();

        var data = $(this).serialize();
        next_step(data);

    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $('#Reference_32').on('input', function() {
        var currentText = $(this).val();
        var upperText = currentText.toUpperCase();
        $(this).val(upperText);
    });

    function next_step(data)
    {
        $("#loader").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . "/taxpasseport/display/verification"); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (res) {
                $('#loader').html('');

                switch(res.code) {
                    case "E604":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Aucune information trouv&eacute;e pour cette r&eacute;f&eacute;rence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E000":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Logirad n\'est pas disponible !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "401":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Aucune authorisation trouvée pour Logirad !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "402":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Logirad : Le token d\'autorisation a expiré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "500":
                        $('#loader').html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Logirad: Echec de la connexion : votre mot de passé a expiré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E404":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Le num&eacute;ro de la note de perception est incorrect! Veuillez v&eacute;rifier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E503":
                        $('#loader').html(res.message);
                        break;
                    case "E504":
                        $('#loader').html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... Le paiement de cette note de perception a déjà été confirmé avec succès dans LOGIRAD !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E505":
                        $('#loader').html(res.message);
                        break;
                    case "E506":
                        $('#loader').html(res.message);
                        break;
                    case "E001":
                        $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E22":
                        $('#loader').html('<div class="alert aWarning text-white">Alerte: La r&eacute;f&eacute;rence n&pos;est pas envoy&eacute;e...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "E406":
                        $("#loader").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;!... un probleme est survenu. Merci de reessayer plus tard<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        break;
                    case "LOCKOUT":
                        $("#loader").html('<span style="color:#F00">' + res.message + '</span>');
                        break;
                    case "SUCCESS":
                        // Affiche le contenu HTML généré côté serveur
                        $("#pager").html(res.html);
                        $("#step-1").removeClass('bg-green-active').addClass('bg-gray');
                        $("#step-2").removeClass('bg-gray').addClass('bg-green-active');
                        break;
                    default:
                        // Par défaut, si code inconnu
                        $("#loader").html('<div class="alert aWarning text-white">Erreur inattendue. Merci de réessayer.</div>');
                }
            },
            error: function (error) {
                alert("Erreur AJAX : " + error.responseText);
            }
        });
    }
</script>