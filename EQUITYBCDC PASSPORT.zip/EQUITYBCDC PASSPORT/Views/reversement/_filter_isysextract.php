<?php 

$paiements = 0;
$paiements_dgrad = 0;
$suspend = 0;
$urgent = 0;
$paiements_dgi = 0;
$paiements_dgi_usd = 0;
$paiements_dgrad_usd = 0;
$paiements_dgda_usd = 0;

$i = 0;

?>

<?php if(!empty($encaissements)): ?>
<table id="table" class="table table-hover table-striped">
    <thead  class="bg-gray">
        <tr>
            <th></th>
            <th class="f12">Date</th>
            <th class="f12">Client</th>
            <th class="f12">B&eacute;n&eacute;ficiaire</th>
            <th class="f12">Service</th>
            <th class="f12">Recette</th>
            <th class="f12">Montant</th>
            <th class="f12">Op&eacute;rateur</th>
        </tr>
    </thead>
    <tbody>
        <?php 
            foreach($encaissements as $row){ 
            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        ?>
        <tr>
            <td width="5"><b>#</b></span></td>
            <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
            </td>
            <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
            <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
            <td width="20"><b><?php echo $row->Service_16; ?></b></td>
            <td><?php echo $row->Noteid_26.'-'.$row->Typerecette_17; ?></td>
            <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                <br/>
                <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                <?php endif;?>
            </td>
            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>

        </tr>
    <?php 
       if($row->Beneficaire_15 =="DGRAD")
       {
           $paiements_dgrad = $paiements_dgrad + $row->Contrevaleur_22;
       }
       elseif($row->Beneficaire_15 =="DGI")
       {
           $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
       }
        if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGRAD") $paiements_dgrad_usd = $paiements_dgrad_usd + $row->Montant_11;
        if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGI") $paiements_dgi_usd = $paiements_dgi_usd + $row->Montant_11;

    } 
    ?>

    </tbody>    
</table>
<?php else:?>
<div class="col-md-12">
    <section id="cat_list" class="text-center marginTop150">
            <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
            <span class="d-block f14 text-black p-2">Aucun paiement trouv&eacute;!</span>
    </section>
</div>
<?php endif;?>