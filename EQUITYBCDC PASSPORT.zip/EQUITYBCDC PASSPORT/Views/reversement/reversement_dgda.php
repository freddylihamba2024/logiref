<?php 

$paiements = 0;
$paiements_dgrad = 0;
$suspend = 0;
$urgent = 0;
$paiements_dgi = 0;
$paiements_dgi_usd = 0;
$paiements_dgrad_usd = 0;
$paiements_dgda_usd = 0;

$i = 0;

?>

<div id="pager"  class="col-md-12"> 
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <?php if($_SESSION['Logiref_role']==4 ||$_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>
                    <div class="col-md-12">
                        <div class="row marginBottom50">
                            <div class="col-md-4 ">
                                <div class="row">
                                    <div class="col-md-4" >
                                        <div id="step-2" title="" class="bRound bg-gray f15 center pull-right active">1</div>
                                    </div>
                                    <div class="col-md-8" >
                                        <div class="pull-left f12 text-black">S&eacute;l&eacute;ction des paiements<br/></div>
                                    </div>
                                </div>  
                            </div>
                            <div class="col-md-4 ">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div id="step-2" title="" class="bRound bg-gray f15 center pull-right">2</div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="pull-left f12 text-black">Int&eacute;gration des paiements<br/></div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-md-4 ">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div id="step-3" title="" class="bRound bg-gray f15 center pull-right">3</div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="pull-left f12 text-black">Validation des paiements<br/></div>
                                    </div>   
                                </div>
                            </div>
                        </div>  
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 hidden" id="message">
            <div class="alert alert-warning">ISYS-REGIESSSSS n'est pas disponible pour l'isntant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>
        </div>
    </div>
<!--    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2">
                            <h5 class="card-title f12 text-black">Total DGDA</h5>
                            <div class="col-6"></div>
                            <p class="text-green f18"> <b>CDF <span id="paiements_dgda"></span>27 994 593</b></p>
                            <p class="text-blue f18"> <b>USD <span id="paiement_dgda_usd"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2">
                            <h5 class="card-title f12 text-black">Total DGRAD</h5>
                            <p class="text-green  f18"> <b>CDF <span id="paiement_dgrad"></span> 234 000</b></p>
                            <p class="text-blue f18"> <b>USD <span id="paiement_dgrad_usd"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                     <div class="card">
                        <div class="card-body p-2">
                            <h5 class="card-title f12 text-black">Total DGI</h5>
                            <p class="text-green f18"> <b>CDF <span id="paiement_dgi"></span>50 025,55</b></p>
                            <p class="text-blue f18"> <b>USD <span id="paiement_dgi_usd"></span></b></p>
                        </div>
                    </div>
                </div>
            </div><br>
        </div><br>

    </div>-->
   
    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
    <div class="col-md-12" id="loader"></div>
   
        <?php $chtml->box_body_opening('', true); ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12"  id="contents">
                        <div id="paiementslist">
                            <?php if(!empty($bulletins)): ?>
                            <table id="table" class="table table-hover table-striped">
                                <thead  class="bg-gray">
                                    <tr>
                                        <th></th>
                                        <th class="f12">Date</th>
                                        <th class="f12">Client</th>
                                        <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                        <th class="f12">Recette</th>
                                        <th class="f12">Montant</th>
                                        <th class="f12">Commissions</th>
                                        <th class="f12">Op&eacute;rateur</th>
                                        <th class="f12"><span class="fa fa-fw fa-tasks f14"></span></th>
                                        
                                            <th class="f12"><span class="fa fa-fw fa-folder f14"></span></th>
                                       
                                        <th class="f12"><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                # Block las BL
                                foreach($bulletins as $row){ 
                                    $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - '; 
                                    $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                    $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                    $results = json_decode($row->Results_13);
                                    $recieptDate = explode("/",$results->receiptDate);
                                    $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                                ?>
                                <tr>
                                        <td width="5"><b>#</b></span></td>
                                        <td  width="50" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                        </td>
                                        <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                        <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                        <td class="text-blue">
                                            <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                        </td>
                                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                        <td width="25">
                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                        </td>
                                        <?php if($row->Status_2!=3){ ?>
                                            <td width="25">
                                                <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                                <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->Year_5."".$row->Serie_7."".$row->Number_8; ?>" name="bulletins[]" />
                                                <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                                <?php }else { ?>
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                <?php } ?>
                                            </td>
                                            <td width="25">
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                            </td>
                                        <?php }else{ ?>
                                            <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                                                <td width="25">
                                                    <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_12; ?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                                                    <input type='hidden' disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_12; ?>' name="total_dgda[]" />
                                                    <input type='hidden' disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                                                </td>
                                            <?php }else{ ?>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                </td>
                                            <?php } ?>
                                            <td width="25">
                                                <?php if(isset($row->Pdfcontent_18) && $row->Pdfcontent_18 !=""):?>
                                                    <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                <?php else: ?>
                                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                <?php endif; ?>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                <?php 
                                
                                        //$paiements_dgda = $paiements_dgda + $row->Amount_12;
                                        //$commissions = $commissions + $row->Commission_26;
                                        //if(isset($row->Devise_29) && $row->Devise_29=='CDF') $paiements_cdf = $paiements_cdf + $row->Amount_12;
                                } 
                                ?>
                                    
                            <?php 
                                
                                #Block last prepayment
                                foreach($prepayments as $row){ 
                                    $agence = (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - '; 
                                    $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                                    $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                ?>
                                <tr>
                                        <td width="5"><b>#</b></span></td>
                                        <td width="50" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                        </td>
                                        <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                        <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?></td>
                                        <td class="text-blue">
                                            <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                                        </td>
                                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                        <td width="25">
                                            <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                        </td>
                                        <?php if($row->Status_2!=3){ ?>
                                            <td width="25">
                                                <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_30==$_SESSION['Logiref_agence']){ ?>
                                                    <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                                                    <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="total_prepayments[]" />
                                                    <input type='hidden' class="input_val" disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                                                <?php }else if($_SESSION['Logiref_role']==4 && $row->Creator_4==$this->session->userdata['user_id']){ ?>
                                                <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"></span></a>
                                                <?php }else { ?>
                                                <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                <?php } ?>
                                            </td>
                                            <td width="25">
                                                <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"></span></a>
                                            </td>
                                        <?php }else{ ?>
                                            <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                                                <td width="25">
                                                    <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                                                    <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="total_prepayments[]" />
                                                    <input type='hidden' class="input_val" disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                                                </td>
                                            <?php }else{ ?>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                </td>
                                            <?php } ?>
                                            <td width="25">
                                                <?php if(isset($row->Pdfcontent_18) && $row->Pdfcontent_18 !=""):?>
                                                    <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                <?php else: ?>
                                                    <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                <?php endif; ?>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                <?php 
//                                        $paiements = $paiements + $row->Amount_18;
//                                        $commissions = $commissions + $row->Commission_24;
//                                        if(isset($row->Devise_29) && $row->Devise_29=='CDF') $paiements_cdf = $paiements_cdf + $row->Amount_18;
                                } 
                                ?>
                                    
                                
                                </tbody>    
                            </table>
                            <?php else:?>
                            <div class="col-md-12">
                                <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                                        <span class="d-block f14 text-black p-2">Aucun paiement trouv&eacute;!</span>
                                </section>
                            </div>
                            <?php endif;?>
                        </div>
                </div>
                <div class="box-footer clearfix col-md-12">
                    <div id="createPaiement" class="col-md-12 no-padding">
                        <button type="submit" id="submit"  name="submit" class="btn btn-success pull-left disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer la s&eacute;l&eacute;ction <span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit"id="export" class="btn btn-primary" disabled><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;Exporter en excel&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <input type="hidden" id="action" value="">
                        <button type="button" id="cancel" class="btn btn-default" disabled><i class="fa fa-share-square-o"></i>&nbsp;&nbsp;Reverser automatiquement &nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <a class="btn btn-warning" href=""><span class="fa fa-times"></span>&nbsp; Quitter &nbsp;</a>
                    </div>

                </div>
            </div>
        </div>   
        <?php $chtml->box_body_closing(); ?><br><br>
       
   <?php echo form_close(); ?>
</div>

<script type="text/javascript">

$("#contenter").on("click", ".item", function(){
    
    var id = $(this).attr('data-id-item');
    $("#form_validated").removeClass('hidden');
    $("#close").addClass('hidden');
    $("#cancel").addClass('hidden');
    
});

$('#submit').click(function(){
    $('#action').val('submit');
    
});

$('#export').click(function(){
    
    $('#action').val('export');
    
});

$('#checkall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', 'checked');
    $('.check').removeClass("hidden");
    $('#checkall').addClass("hidden");
    $('#uncheckall').removeClass("hidden");
    
    $('#regie_all').prop('disabled', false);
    
    $('.input_val').prop('disabled', false);
    
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;

    
    $("#submit").removeClass("disabled");
    $("#submit").prop("disabled",false);
    $("#index").html('('+ index+')');
});

$('#uncheckall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', '');
    $('.check').addClass("d-none");
    $('#checkall').removeClass("d-none");
    $('#uncheckall').addClass("d-none");
    
    $('#regie_all').prop('disabled', true);
    
    $('.input_val').prop('disabled', true);
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;
    
    $("#submit").removeClass("btn-primary");
    $("#submit").addClass("btn-success");
    $("#submit").prop("disabled",true);
    $("#index").html('');
    
});
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        var data = $(this).serialize();
        
        var action = $('#action').val();
        
        if(action == 'submit')
        {
                submiter(data);
        }
        else
        {
                export_to_excel(data);
        }
        
});

function submiter(data)
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module.'/taxreversement'); ?>/display/start';
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#message').removeClass('d-none');
                    $('#export').prop('disabled', false);
                    $('#submit').prop('disabled', true);
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');
                    $("#contents").html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}

function export_to_excel(data)
{
        var url = '<?php echo base_url($module.'/taxreversement'); ?>/display/export';
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){
                
                    if(result === "E201" || result === "E401")
                    {
                            $("#loader").html('<div class="alert alert-warning text-white">Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                           print(result);
                    }
            },
            error:function(error){
                $("#loader").html('<div class="alert aDanger text-white"> La vérification a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
}

function view(id, regie)
{
        var url ='';
        if(regie === 'DGDA')
        {
             var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGI')
        {
             var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGRAD')
        {
             var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
        }

        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#pager").html(data);

        });
}

function view_prepayment(id)
{
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        $.get(url, function(data, status){
            $("#loader").html('');
            $("#pager").html(data);

        });
}

function print_payment(pid)
{
        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
}

function reverser(id, regie, devise)
{
            
            
            var $checedInputs = $('#table').find("input:checked");
            var index = $checedInputs.length;

            if(index > 0)
            {
                    $('#t'+id+''+regie).prop('disabled', false);
                    $('#r'+id+''+regie).prop('disabled', false);

                    $("#submit").removeClass("disabled");
                    $("#submit").prop("disabled",false);
                    $("#index").html('('+ index+')');



            }
            else if(index <= 0)
            {
                    $('#checkall').removeClass("d-none");
                    $('#uncheckall').addClass("d-none");
                    
                    $('#t'+id+''+regie).prop('disabled', true);
                    $('#r'+id+''+regie).prop('disabled', true);
                    
                    $("#submit").removeClass("btn-primary");
                    $("#submit").addClass("btn-success");
                    $("#submit").prop("disabled",true);
                    
                    $("#index").html('');

                    regie = "";
                    devise = "";
                    
                    localStorage.setItem("regie",regie);
                    localStorage.setItem("devise",devise);
            }

            if(index == 1)
            {
                    localStorage.setItem("regie",regie);
                    localStorage.setItem("devise",devise);
            }

            var needle_regie = localStorage.getItem("regie");
            var needle_devise = localStorage.getItem("devise");

            if(needle_regie != "" && needle_regie != regie)
            {
                    $('#table').find("input:checked").prop('checked', false);
                    $("#loader").html('<div class="alert alert-warning text-white">Veuillez s&eacute;l&eacute;ctionner les paiements d\'une m&ecirc;me r&eacute;gie et d\'une m&ecirc;me devise par reversement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#submit").removeClass("btn-primary");
                    $("#submit").addClass("btn-success");
                    $("#submit").prop("disabled",true);
                    $("#index").html('');
                    regie = "";
                    localStorage.setItem("regie",regie);
                    scrollUP();
            }
            if(needle_devise != "" && needle_devise != devise)
            {
                    $('#table').find("input:checked").prop('checked', false);
                    $("#loader").html('<div class="alert alert-warning text-white">Veuillez s&eacute;l&eacute;ctionner les paiements d\'une m&ecirc;me r&eacute;gie par reversement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#submit").removeClass("btn-primary");
                    $("#submit").addClass("btn-success");
                    $("#submit").prop("disabled",true);
                    $("#index").html('');
                    regie = "";
                    localStorage.setItem("regie",regie);
                    scrollUP();
            }
        
        
}


function printQuittance(file)
{
        var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
        
}
function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

function print(buffer) {
    var link = document.createElement('a');
    link.href = '<?php echo base_url()?>' + buffer;
    link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

</script>
