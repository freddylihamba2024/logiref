<?php 

$paiements = 0;
$paiements_dgrad = 0;
$suspend = 0;
$urgent = 0;
$paiements_dgi = 0;
$paiements_dgi_usd = 0;
$paiements_dgrad_usd = 0;
$paiements_dgda_usd = 0;

$i = 0;

?>

<div id="pager"  class="col-md-12"> 
    <div class="row">
        
        <div class="col-md-12 ">
                <h2 class="f30 text-blue">Taxes Reversées</h2>
                <p class="page-header"><span class="f12 text-black">Cette sections vous permet de sélectionner la preuve de paiement à imprimer.</span></p>     
        </div>
       
        <div class="ibox bg-white">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                                <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for=""><b>R&eacute;gie</b></label>
                                                <?php echo form_dropdown('Regie', $regies, '', ' id="TitreId" class="form-control" '); ?>

                                            </div>    
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for=""><b>Bureau</b></label>
                                                <?php echo form_dropdown('Office', $services, '', ' id="Office" class="form-control" '); ?>

                                            </div>    
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for=""><b>Recette</b></label>
                                                <?php echo form_dropdown('Recette', $recettes, '', ' id="recette" class="form-control" '); ?>

                                            </div>    
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">

                                                <label for=""><b>P&eacute;riode</b></label>
                                                <div class="input-daterange input-group">
                                                    <span class="input-group-addon">De </span>
                                                    <input class="form-control" name="start" value="" id="datepicker1" type="text">
                                                    <span class="input-group-addon"> à </span>
                                                    <input class="form-control" name="end" value=""  id="datepicker2" type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-1 text-right d-flex align-items-center">
                                            <button type="submit" class="btn btn-primary" >Extraire</button>
                                        </div>
                                        <div class="col-md-1 text-right d-flex align-items-center">
                                            <button type="submit"id="export" class="btn btn-success">Exporter</button>
                                        </div>
                                    </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>

                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="col-md-12" id="loader"></div>

                    <?php //$chtml->box_body_opening('', true); ?>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12"  id="contents">
                                    <div id="result">
                                        <?php if(!empty($encaissements)): ?>
                                        <table id="table" class="table table-hover table-striped">
                                            <thead  class="bg-gray">
                                                <tr>
                                                    <th></th>
                                                    <th class="f12">Date</th>
                                                    <th class="f12">Client</th>
                                                    <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                                    <th class="f12">Service</th>
                                                    <th class="f12">Recette</th>
                                                    <th class="f12">Montant</th>
                                                    <th class="f12">Op&eacute;rateur</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    foreach($encaissements as $row){ 
                                                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                                ?>
                                                <tr>
                                                    <td width="5"><b>#</b></span></td>
                                                    <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                    <td width="20"><b><?php echo $row->Service_16; ?></b></td>
                                                    <td><?php echo $row->Noteid_26.'-'.$row->Typerecette_17; ?></td>
                                                    <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                                        <br/>
                                                        <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                                        <?php endif;?>
                                                    </td>
                                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                                    
                                                </tr>
                                            <?php 
                                               if($row->Beneficaire_15 =="DGRAD")
                                               {
                                                   $paiements_dgrad = $paiements_dgrad + $row->Contrevaleur_22;
                                               }
                                               elseif($row->Beneficaire_15 =="DGI")
                                               {
                                                   $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                               }
            //                                        $paiements = $paiements + $row->Contrevaleur_22;
            //                                        $commissions = $commissions + $row->Commission_23;
            //                                        if($row->Devise_12=='CDF') $paiements_cdf = $paiements_cdf + $row->Montant_11;
                                                if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGRAD") $paiements_dgrad_usd = $paiements_dgrad_usd + $row->Montant_11;
                                                if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGI") $paiements_dgi_usd = $paiements_dgi_usd + $row->Montant_11;

                                            } 
                                            ?>

                                            </tbody>    
                                        </table>
                                        <?php else:?>
                                        <div class="col-md-12">
                                            <section id="cat_list" class="text-center marginTop150">
                                                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                                                    <span class="d-block f14 text-black p-2">Aucun paiement trouv&eacute;!</span>
                                            </section>
                                        </div>
                                        <?php endif;?>
                                    </div>
                            </div>

                        </div>
                    </div>   
                    <?php //$chtml->box_body_closing(); ?><br><br>

               <?php echo form_close(); ?>
        </div>
    </div>
</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">


    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    

      $("#searchform").submit(function (e) {

        e.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxreports/display/filter_isysextract'); ?>';
        var data = $(this).serialize();
        console.log(data)
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#message').html('');
                $('#result').html(result);
            },
            error: function (error) {
                alert('ERROR!' + error);
            }
        });

    });





</script>
