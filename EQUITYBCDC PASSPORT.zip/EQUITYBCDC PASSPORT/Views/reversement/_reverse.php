<?php if(!empty($encaissements) || !empty($encaissements_immatriculation)): ?>
<div class="box-body">
    <div class="col-md-12 no-padding">
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-gray">
                    <th>#</th>
                    <th>Regie</th>
                    <th>Service</th>
                    <th>Recette</th>
                    <th>R&eacute;f&eacute;rence</th>
                    <th>Titre</th>
                    <th>validation</th>
                    <th>Montant</th>
                    <th>Devise</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach($encaissements as $row){
            ?>
                <tr>
                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                    <td width="100"><?php echo $regie = isset($regies['Regies'][$row->Beneficaire_15]) ? $regies['Regies'][$row->Beneficaire_15]: 'DGDA'; ?></td>
                    <td width="100"><?php echo $row->Service_16; ?><br/></td>
                    <td width="100"><?php echo $row->Typerecette_17; ?></td>   
                    <td ><?php echo $row->Logirefid_4.$i; ?></td> 
                    <td ><?php echo $row->Noteid_26; ?></td> 
                    <td <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td> 
                    <td><?php echo number_format($row->Montant_11,2,","," "); ?></td> 
                    <td width="50"><?php echo $row->Devise_12; ?></td>
                    <input type='hidden' value='<?php echo $row->Id_0; ?>' name="ids[]" />
                </tr>

            <?php 
            } 
            ?>

            <?php 
            foreach($encaissements_immatriculation as $row){
            ?>
                <tr>
                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                    <td width="100"><?php echo $regie = isset($regies['Regies'][$row->Beneficaire_15]) ? $regies['Regies'][$row->Beneficaire_15]: 'DGDA'; ?></td>
                    <td width="100"><?php echo $row->Service_16; ?><br/></td>
                    <td width="100"><?php echo $row->Typerecette_17; ?></td>   
                    <td ><?php echo $row->Logirefid_4.$i; ?></td> 
                    <td ><?php echo $row->Noteid_26; ?></td> 
                    <td <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td> 
                    <td><?php echo number_format($row->Montant_11,2,","," "); ?></td> 
                    <td width="50"><?php echo $row->Devise_12; ?></td>
                    <input type='hidden' value='<?php echo $row->Id_0; ?>' name="ids[]" />
                </tr>

            <?php 
            } 
            ?>
            </tbody>    
        </table>
    </div>
</div>
<?php else: ?>
    <div class="col-md-12">
        <section id="cat_list" class="text-center pt-5 pb-5">
            <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
            <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;</span>
        </section>
    </div>
<?php endif;?>