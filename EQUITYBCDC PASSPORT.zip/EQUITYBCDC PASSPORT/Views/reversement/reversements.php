<div class="row" style="margin-top: -50px;">
            <div class="col-md-12">
                    <div class="row">
                            <div class="col-md-12 ">
                                    <h2 class="f30 text-blue">Journal des reversements</h2>
                                    <p class="page-header"><span class="f12 text-black">Cette vue vous permet de procéder au reversement des paiements encaissés.</span></p>     
                            </div>
                    </div>
                   
                    <div class="row">
                            <div class="col-md-12 p-0" id="sub-menu">
                                    <div class="col-md-12 p-0">
                                        <div class="box-body">
                                                <?php $chtml->box_body_opening("", true);?>
                                                <div class="row">
                                                        <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label for="type" class="f12 text-black">Selectionner le type de reversement à traiter</label>
                                                                    <?php echo form_dropdown('type', $reversements, "", 'class="form-control default-width" id="type" '); ?>
                                                                </div>
                                                        </div>
                                                </div>
                                                <?php $chtml->box_body_closing(); ?>

                                               
                                                <div class="col-md-12 p-0" id="sub-menu">
                                                        <div id="loader-sub-menu">
                                                            <section id="cat_list" class="text-center marginTop150">
                                                                    <span class="d-block p-2 "><span class="fa fa-share-square-o text-navy mystyle4" ></span></br>
                                                                    <span class="d-block p-2 f12 text-black">Aucune option sélectionnée. Veuillez en choisir une pour procéder au reversement des paiements.</span>
                                                            </section>
                                                       </div>
                                                </div>
                                        </div>
                                    </div>
                            </div>
                    </div>
        </div>
</div>

<script type="text/javascript">
    
    $('#type').change(function(){
        var type = $('#type option:selected').val();
        
        if(type != '')
        {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            action(type);
        }
    });
    
    
    function action(which) {
        
        if (which === 'dailly') {
           $.get("<?php echo base_url($module . '/taxreports/display/validated/dailly'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'reversement_dgi') {
           $.get("<?php echo base_url($module . '/taxreports/display/validated/reversement_dgi'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'reversement_dgrad') {
           $.get("<?php echo base_url($module . '/taxreports/display/validated/reversement_dgrad'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'reversement_dgda') {
           $.get("<?php echo base_url($module . '/taxreports/display/validated/reversement_dgda'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
     }
    

</script>