<?php $userid = $this->session->userdata["user_id"];  $Infos = $encaissement->Notereference_30; $idBL = '';?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php //if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,0,","," "); ?>
<?php //if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,0,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php $Standard01=''; $total = 0;  ?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="loader"></div>
    <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'form', 'class' => 'view')); ?>
            <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
            <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
            <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
            <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
            <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
            <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
            <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
            <input type="hidden" name="Beneficaire_15" value="DGDA"  id="regies" />
            <div class="box-body">
                
                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                    <div id="loader"></div>
                </div> 
               
                <!------------------------- Beneficiare  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gie financi&egrave;re</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                    </span>
                    <?php echo form_dropdown('Beneficaire_15', array('DGDA'), 'DGDA', ' class="form-control bg-gray" required="required"  '); ?>
                    <?php if($encaissement->Id_0 !=NULL): ?>
                        <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                    <?php endif; ?>
                </div>
            </div> 
            <div class="col-md-7">
                <div class="input-group"  id="regie0">
                    <span class="input-group-addon">
                        <label for="Service_16"><div id="ServiceId">Bureau</div></label> 
                    </span>
                    <span id="slist"><?php echo form_dropdown('Service_16', $services, isset($content['Service']) ? $content['Service'] : "" , 'class="form-control chosen-select" id="service"  required="required" '); ?></span>

                </div>
            </div> 
            <!-------------------------  Titre de perception  ------------------------------>
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Type"><div id="TitreId">Type</div></label> 
                    </span>
                    <?php echo form_input('Type', set_value('Type', ''), ' class="form-control" id="Type" maxlength="25"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="declarant"><div id="TitreId">D&eacute;clarant</div></label> 
                    </span>
                    <?php echo form_input('Declarant', set_value('Declarant', ''), ' class="form-control" id="declarant" required="required" maxlength="25"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Bank"><div id="TitreId">Banque</div></label> 
                    </span>
                    <?php echo form_input('Bank', set_value('Bank', '5101'), ' class="form-control" id="Bank" required="required" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-7">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', ''), 'class="form-control" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="5">
                </div>
            </div>
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Enregistrement</label> 
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', ''), 'class="form-control" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="5">
                </div>
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">D&eacute;clarations</label> 
                    </span>
                    <?php echo form_input('Notetype_25', set_value('Notetype_25', ''), 'class="form-control" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="5">
                </div>
            </div>
            <div class="col-md-3">
                <div class="input-group">
                    <span class="input-group-addon">
                    Date
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                    Date
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
                <!------------------------- Payement  ------------------------------>
                <div class="col-md-5 border"><br/><label>Partie 3 : Client, Assujetti ou Contribuable. </label></div>
                <div class="col-md-7 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"></span></label></div>
                <div class="col-md-12">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Adresse">Addresse</label> 
                        </span>
                        <?php echo form_input('Adresse', set_value('Adresse', ''), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                        </span>
                        <?php echo form_input('Nif_13', set_value('Nif_13', ''), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div> 
                <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', ''), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19">Mode de paiement</label> 
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, '', 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41">Taux de change</label> 
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                           <label for="Datevaleur_31">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                        </span>
                        <?php echo form_input('Reference_32', set_value('Reference_32', ""), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-5">
                    <div class="input-group"> 
                        <span class="input-group-addon">
                            <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11">Montant &agrave; payer</label> 
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', isset($paiement['Notemontant']) ? $paiement['Notemontant'] : ""), 'class="form-control" id="recetteMontant" required="required"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23"><div id="commiision">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Total">Montant total</label> 
                        </span>
                        <?php echo form_input("Infos[totalMontant]", set_value('Infos[totalMontant]', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required" id="compteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_12', $devises, '', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown("Infos[totalDevise]", $devises, '', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                    </div>
                </div>

                <!-------------------------  DGDA Informations additionnelles  ------------------------------>
                <div>
                    <div class="col-md-12"><br/><label id="infosTitle">Partie 4 : d&eacute;tails des taxes </label><br/></div>
                    <div id="details" class="col-md-12">
                        <div class="table-responsive">
                            <table class="table no-margin table-striped table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th>Taxe</th>
                                        <th>Montant</th>
                                        <th class="center" width="2%"><span class="fa fa-fw fa-trash-o f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody id="listTaxes">
                                    <?php for($i=1; $i < 5; $i++){ ?>
                                        <tr> 
                                            <td><?php echo form_dropdown('taxes[]', $recettes, '', 'class="form-control itemgrid iwtd" required="required"'); ?></td>
                                            <td><input type="text"  name="amounts[]"  value=""  class="form-control itemgrid" required="required"/></td>
                                            <td align="center"><a style="cursor:pointer" onclick="deleField('<?php echo $i; ?>')" ><span class="fa fa-fw text-red fa-trash-o f14"> </span></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td align="center">
                                            <button id="addfield" type="button" onclick="addField()" class="btn btn-primary pull-right">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                    <div  id="Comptabilisation" class="col-md-12"></div>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div id="createPaiement" class="col-md-12">
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; Attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="closeModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>


<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>'; 
var montant_total = '';
var Dtaux=[];
Dtaux['USD'] = '<?php echo $taux['Dollar_4']; ?>'; 
Dtaux['EUR'] = '<?php echo $taux['Euro_5']; ?>'; 
Dtaux['ZAF'] = '<?php echo $taux['Rand_6']; ?>'; 
//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});

$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

$('#datepicker3').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

$('#recetteMontant').change(function(){
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        
        if((recetteDevise === deviseNote) && (montant > note))
        {
                $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
        }
        else
        {
                $('#info').html('');
                commission();
        }  
});

$('#recetteDevise').change(function(){
        commission();
});

$('#commission').change(function(){
    
        var commissions = parseFloat($("#commission").val());
        if(commissions !='0' && commissions !='')
        {
                montant_total = parseFloat($('#montantTotal').val());

                montant_total += commissions;

                $('#montantTotal').val(montant_total);
        }
        
});


$("#compteId").change(function(){
    get_accountname(); 
});

$("#compteDevise").change(function(){
    get_accountname(); 
});

$("#closeModal").click(function(){
        location.reload(true);
});

$('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#enregistrer").prop('disabled', true);
        
        var devise = 'CDF';
        var data = $(this).serialize();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission option:selected').val();
        
        if(mode == '7' || mode == '8')
        {
                if(commission_value == '0' || commission_value =='')
                {
                        scrollUP();
                        $('#loader').html('<div class="alert aDanger text-white"> La commission ne peut pas &ecirc;tre nulle, veuillez renseigner la commission pour ce paiement s\'il vous plait !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                        if(compteDevise === devise && recetteDevise === devise && commissionDevise === devise)
                        {
                                submiter(data);  
                        }
                        else
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert aDanger text-white"> Rassurez-vous que tous les montants sont dans la m&ecirc;me devise !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                }
        }
        
        else
        {
                if(commission_value == '0' || commission_value =='')
                {
                        scrollUP();
                        $('#loader').html('<div class="alert aDanger text-white"> La commission ne peut pas &ecirc;tre nulle, veuillez renseigner la commission pour ce paiement s\'il vous plait !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                        if(recetteDevise === devise && commissionDevise === devise)
                        {
                                submiter(data);  
                        }
                        else
                        {
                                scrollUP();
                                $('#loader').html('<div class="alert aDanger text-white"> Rassurez-vous que tous les montants sont dans la m&ecirc;me devise !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');;
                        }
                }
        } 
        
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var commission = $("#commission").val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet, csrf_name:csrf}, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '' || commission == '0')
                        {
                            $("#commission").val(result[0]);
                            $("#commissionDevise").val(result[1]);
                            $("#montantTotal").val(result[2]);
                        }
                        //$('#loader').html(reponse);
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}


function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise, csrf_name:csrf}, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; amplitude!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else
                                {
                                         $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse);
                                        $("#account_name").val(reponse);
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}


function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

function addField()
{
        var url = '<?php echo base_url($module.'/others'); ?>/display/selectTaxes';
        $.get(url, function(data, status){
            $("#listTaxes").append('<tr><td>'+ data +'</td><td><input type="text" name="amounts[]" value="" class="itemgrid form-control" id="Reference[]" required="required"></td><td align="center"><a style="cursor:pointer" onclick="deleField()" ><span class="fa fa-fw text-red fa-trash-o f14"></span></a></td></tr>');
        });
        
}

function deleField(id)
{
    
}


function submiter(data)
{
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxothers/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        scrollUP();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E300")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert aDanger text-white"> Solde du client insuffisant, désaccord commercial ou administratif. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E412")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert aDanger text-white"> Ce paiement a un probl&egrave;me, veuillez conctater votre administrateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#step2').remove;
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                
                                var url = '<?php echo base_url($module.'/taxothers/display/preview'); ?>/' + result;
                                $.get(url, function(data, status){
                                    $('#loader').html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                })
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

</script>




