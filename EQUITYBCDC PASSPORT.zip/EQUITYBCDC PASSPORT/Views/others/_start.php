<div class="row">    
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="loader1"></div>
            <div class="row">
                <div class="col-md-12">
                    <h1>Bulletin par cr&eacute;dit</h1>
                    <p class="page-header">Traitement des bulletins de liquidation</p>     
                </div>
            </div>
        
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-1">
                        <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?>  f18 center pull-right">1</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">V&eacute;rification du Bulletin<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">2</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">Confirmation du paiement<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> f18 center pull-right">3</div>
                    </div>
                    <div class="col-md-3">
                        <div class="pull-left">Validation<br/></div>
                    </div>
                </div>
            </div>
        <div class="col-md-12"><br/>
            <div id="loader"></div>
        </div>
        <div id="pager">
            <?php if($step == 1 || $step == 2 ):?>
                <?php $this->load->view('_step_2'); ?>
            <?php elseif($step == 3):?>
                <?php $this->load->view('_step_3'); ?>
            <?php else:?>
                <div class="row">
                    <div class="col-md-12">
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <?php $chtml->box_body_opening('', true);?>
                    <div class="row">
                        <div class="col-md-8 bRight">
                            <input type="hidden" name="Account" value="<?php echo $this->session->userdata['account_id']; ?>">
                            <input type="hidden" name="User" value="<?php echo $this->session->userdata['user_id']; ?>">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h2 class=" f20 w-300 page-header">V&eacute;rifier l'authenticit&eacute; d'un bulletin de liquidation</h2>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="Service_16">Bureau (ou service)</label> 
                                                <?php echo form_dropdown('Office',$services['DGDA'],'501B', 'class="form-control select2" id="Service_16" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="year">Ann&eacute;e</label> 
                                                <?php echo form_input('Year','2019', 'class="form-control" id="year" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="year">Banque</label> 
                                                <?php echo form_input('Bank','1150', 'class="form-control bg-gray" id="year" required = "required"'); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="company">Num&eacute;ro d'imp&ocirc;t</label> 
                                                <?php echo form_input('Nif','', 'class="form-control" id="company" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                               <label for="declarant">Num&eacute;ro du d&eacute;clarant</label> 
                                                <?php echo form_input('Agent','0000', 'class="form-control" id="declarant" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="assessment_serial">S&eacute;rie</label>
                                                <?php echo form_input('Series','L', 'class="form-control" id="assessment_serial" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="assessment_number">Num&eacute;ro du bulletin</label>
                                                <?php echo form_input('Number','', 'class="form-control" id="assessment_number" required = "required"'); ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="Montant_11">Montant &agrave; payer</label>
                                                <?php echo form_input('Amount','', 'class="form-control" id="Montant_11" required = "required"'); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="devise">Devise</label>
                                                <?php echo form_dropdown('devise', $devises, "CDF", 'class="form-control"  required="required" id="recetteDevise" disabled="disabled"'); ?>
                                                <input type="hidden" name="devise" value="<?= $devises['CDF'] ?>" >
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="Mode">Mode de paiement</label> 
                                                <?php echo form_dropdown('Mode', $modes, "", 'class="form-control" required="required" id="modeId"'); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="Account" id="accountname">Compte du client &agrave; d&eacute;buter</label>
                                                <?php echo form_input('bank_account','', 'class="form-control" id="bank_account" placeholder="E.g: 0000100002000030000400005" required="required" '); ?>
                                                <input type="hidden" name="account_name" value="" id="account_name">
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="Devise_account">Devise de ce compte</label>
                                                <?php echo form_dropdown('Devise_account', $devises, "CDF", 'class="form-control" id="account_devise" disabled="disabled"'); ?>
                                                <input type="hidden" name="Devise_account" value="<?= $devises['CDF'] ?>" >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="details" class="col-md-12"></div>
                                <div class="box-footer clearfix">
                                    <div class="col-md-12">
                                        <button type="submit" id="confirm" class="btn btn-default" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer dans SYDONIA&nbsp;&nbsp;</button>&nbsp;  
                                        <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                        <input type="hidden" name="action" value="" id="action">
                                        <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
                                    </div>
                                </div>
                        </div>
                        <div class="col-md-4 no-padding " id="treatment">

                        </div>
                    </div>
                    <?php $chtml->box_body_closing(); ?> 
                    <?php echo form_close(); ?>
                </div>
                </div>
            <?php endif;?>
        </div>
    </div>
    <div class="col-md-1 content">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    
</div><!-- comment -->

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    
$("#confirm").click(function(){
        $("#action").val('confirmer');
});

$("#treat").click(function(){
        $("#action").val('traiter');
});

$('.chosen-select').chosen({width: "100%"});
   
$("#pager").on("submit", "#mainform", function(event){
    
        event.preventDefault();
        var data = $(this).serialize();
        var action = $('#action').val();
        if(action == 'traiter')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxothers/display/verification'); ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                        if(result === "E003")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E22" || result === "E13")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               
                        }
                        else if(result === "E11")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Montant &agrave; payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E000")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === null)
                        {
                                var url = '<?php echo base_url($module.'/othes/display/edit'); ?>/';
                                $.get(url, function(data, status){
                                    $("#loader").html('');
                                    $("#pager").html(data);
                                })
                        }
                        else
                        {
                                $('#loader').html('');
                                $("#confirm").removeClass('btn-default');
                                $("#confirm").addClass('btn-success');
                                $("#confirm").prop('disabled', false);
                                $('#treatment').html(result);
                        }
                       
                            
                    },
                    error:function(error)
                    {
                        $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }
        else if(action == 'confirmer')
        {
            next_step(data);
        }
});

$("#balance").css('background-color','#00cc33');

$("#cancel").click(function(){
        location.reload(true);
});
   
$("#close").click(function(){
        location.reload(true);
});


$("#bank_account").change(function(){
    get_accountname(); 
});

$("#account_devise").change(function(){
    get_accountname(); 
});

   
function next_step(data)
{
       $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
       $('#envoyer').prop("disabled", true);
       var button = $('#envoyer').html();
       $('#envoyer').html('<span>Chargement...</span>');
       var url = '<?php echo base_url($module.'/taxothers/display/confirmation'); ?>';
       $.ajax({
               type        : 'POST', 
               url         : url, 
               data        : data, 
               dataType    : 'html', 
               encode      : true,
               success: function(result){
                        $('#loader').html('');
                        $('#envoyer').html(button);
                        if(result === "E003")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valides!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#envoyer').prop("disabled", '');
                        }
                        else if(result === "E34")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Ce bulletin de liquidation &agrave; d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E22" || result === "E13")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: Aucun bulletin de liquidation trouv&eacute;. Les informations renseign&eacute;es ne correspondent &agrave; aucun bulletin !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#manuel").prop('disabled', '');
                                $("#manuel").removeClass('btn-default');
                                $("#manuel").addClass('btn-success');
                        }
                        else if(result === "E11")
                        {
                                $('#loader').html('<div class="alert aDanger text-white">Alerte: Montant a payer incorrect. Veuillez renseigner des informations correctes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E300")
                        {
                                $('#loader').html('<div class="alert aDanger text-white"> Solde du client insuffisant, désaccord commercial ou administratif. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E406")
                        {
                                $('#loader').html('<div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $('#loader').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E412")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert aDanger text-white"> Ce paiement a un probl&egrave;me, veuillez conctater votre administrateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E002")
                        {
                                $('#loader').html('<div class="alert alert-warning text-white">Alerte: erreur fatal E002...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E003")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E005")
                        {
                                $('#envoyer').prop("disabled", false);
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E000")
                        {
                                $('#loader').html('<div class="alert aWarning text-white">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                 $('#loader').html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                 $('#envoyer').prop("disabled", '');
                                 $('#envoyer').prop("disabled", false);
                                 $("#manuel").prop('disabled', '');
                                 $("#manuel").removeClass('btn-default');
                                 $("#manuel").addClass('btn-success');
                        }
                        else if(result === "OK")
                        {
                                 $('#loader').html('<div class="alert aWarning text-white">Alerte: Pas de retour attendu...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');
                               
                                var url = '<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/' + result;
                                $.get(url, function(data, status){
                                    $("#loader").html('');
                                    $("#pager").html(data);
                                })
                        }
               },
                error:function(error)
                {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                   $('#envoyer').prop("disabled", false);
                   $('#envoyer').html(button);
                }
       });
                       
}

function get_accountname()
{
        var chtml = $("#accountname").html();
        var compte = $('#bank_account').val();
        var devise = $('#account_devise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise, csrf_name:csrf}, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; amplitude!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else
                                {
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse);
                                        $("#account_name").val(reponse);
                                }
                                
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html(chtml);
        } 
}

</script>


