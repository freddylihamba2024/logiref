<?php   $Infos = $encaissement->Notereference_30; $idBL = '';?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php //if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,0,","," "); ?>
<?php //if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,0,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php $Standard01=''; $total = 0;  ?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';   
}

  
?>
<div class="row">
    <div  class="col-md-12">
        <div class="row">
            <div class="col-md-12" id="success_message"></div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-12">
                    <div id="loader2"></div>
                </div>
            </div>
        </div>
        <div id="pager">
            <?php $chtml->box_body_opening('', true);?>
                <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
                    <style>label {min-width: 150px !important; }</style>
                    <div class="box-body">
                        <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                        <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                        <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                        <input type="hidden" name="Makerid_9" value="<?php echo $userid; ?>" />
                        <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                        <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class=" f20 w-300 page-header"><?php echo '#'.$encaissement->Noteid_26; ?>: Renseignez les informations requises</h2>
                            </div> 
                        </div>    
                         <!-------------------------  Titre de perception  ------------------------------>

                        <div id="DGDAComplement">
                            <div class="row">
                                <div class="col-md-12"><br/><label>Partie 1 : Informations du bulletins</label><br/></div>
                            </div>   
                            <div class="row">
                                <div class="col-md-5 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="standard" id="StandardLabel01">D&eacute;clarant</label> 
                                        </span>
                                        <?php echo form_input("Infos[Agent]",'0000', ' class="form-control" id="Standard01" required="required" maxlength="25"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-7 small-box">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Service_16">Bureau</label>
                                    </span>
                                    
                                    <select name="Service_16" class="form-control select2" id="service" required="required">
                                        <option value="" selected disabled></option>
                                        <?php foreach ($services['DGDA'] as $key => $value): ?>
                                            <option value="<?= $key; ?>"><?= $value; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            </div></br>
                            
                            <div class="row">
                                <div class="col-md-12"></div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-5 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="serie">S&eacute;rie bulletin</label>
                                        </span>
                                        <?php echo form_input('Infos[serie]', 'L', 'class="form-control" required="required" id="assessment_serial" '); ?>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="serie">S&eacute;rie quittance</label>
                                        </span>
                                        <?php echo form_input('Infos[Qserie]', 'Q', 'class="form-control" required="required"'); ?>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="Reference_32">R&eacute;f&eacute;rence OP</label>
                                        </span>
                                        <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                                    </div></br>
                                </div></br>
                                <div class="col-md-4 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="number">Num&eacute;ro bulletin</label>
                                        </span>
                                        <?php echo form_input('Infos[number]', '', 'class="form-control" required="required" id="assessment_number" '); ?>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="number">Num&eacute;ro quittance</label>
                                        </span>
                                        <?php echo form_input('Infos[Qnumber]', '', 'class="form-control" required="required"'); ?>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="bank">Banque</label>
                                        </span>
                                        <?php echo form_input('Infos[bank]', '', 'class="form-control" required="required"'); ?>
                                    </div></br>
                                </div></br>
                                <div class="col-md-3 small-box">

                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <b>Date de la note</b>
                                        </span>
                                        <?php echo form_input('Notedate_27', set_value('Notedate_27', gmdate('Y-m-d')), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <b>Date quittance</b>
                                        </span>
                                        <?php echo form_input('Infos[receiptdate]', set_value('Infos[receiptdate]', gmdate('Y-m-d')), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div></br>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <b>Ann&eacute;e</b>
                                        </span>
                                        <?php echo form_input('Infos[year]', gmdate('Y'), 'class="form-control" id="datepicker3" required="required"'); ?>
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div></br>
                                </div>
                            </div></br>
                        </div>
                        <div class="row"> 
                            <div class="col-md-12"></div>
                        </div>
                        <!------------------------- Payement  ------------------------------>
                        <div class="row">
                            <div class="col-md-5"><br/><label>Partie 2 : Client, Assujetti ou Contribuable. </label></div>
							<div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px;"></span><br />
                                <div style="display: flex; align-items: center; width: 100%;">
                                    <label style="margin-bottom: 0;">
                                        Intitulé du compte :&nbsp;&nbsp;
                                        <span id="accountname"></span>
                                    </label>
                                    <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                        <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                                            <span id="" class="text-red f15"></span>&nbsp;&nbsp;<span id="labelNumber" class="text-red f15"></span>
                                        </label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>   
                      
                        <div class="row">
                            <div class="col-md-5 small-box">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Nif_13">NIF Client</label> 
                                    </span>
                                    <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  required="required" id="company" maxlength="86"'); ?>
                                </div>
                            </div>
							<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                <div class="col-md-5 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="Designation_14">Designation</label> 
                                        </span>
                                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" id="designation" required="required" maxlength="86"'); ?>
                                    </div>
                                </div>
                                <div class="col-md-2 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon no-padding"></span>
                                        <?php echo form_input('Infos[CustomerNumber]', set_value('Infos[CustomerNumber]', isset($infos['CustomerNumber']) ? $infos['CustomerNumber'] : ""), 'class="form-control" id="customerNumber" maxlength="7" placeholder="Numéro du client" '.$disabled.' '); ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-md-7 small-box">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <label for="Designation_14">Designation</label> 
                                        </span>
                                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" id="designation" required="required" maxlength="86"'); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div></br>
                        <div class="row">
                            <div class="col-md-5">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Mode_19">Mode</label> 
                                    </span>
                                    <?php echo form_dropdown('Mode_19', $modes, '', 'class="form-control" required="required" id="modeId"'); ?>
                                </div></br>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Taux_41">Taux de change</label> 
                                    </span>
                                    <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                                </div></br>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                       <label for="Datevaleur_31">Date paiement</label>
                                    </span>
                                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker4" class="form-control" maxlength="10"  required="required" '); ?>
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                </div></br>

                            </div>
                            <div class="col-md-5">
                                <div class="input-group"> 
                                    <span class="input-group-addon">
                                        <label for="Compte_33"><div id="compteLabel">Compte &agrave; d&eacute;biter</div></label> 
                                    </span>
                                    <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" required="required" id="compteId"'); ?>
                                    <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                                </div></br>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Montant_11">Montant &agrave; payer</label> 
                                    </span>
                                    <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                                </div></br>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <label for="Commission_23">Commission</label> 
                                    </span>
                                    <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), ' id="commission" class="form-control" required="required"'); ?>
                                </div></br>
                            </div></br>
                            <div class="col-md-2">
                                <div class="input-group">
                                    <span class="no-padding"></span>
                                    <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required"  id="compteDevise"'); ?>
                                </div></br>
                                <div class="input-group">
                                    <span class="no-padding"></span>
                                    <?php echo form_dropdown('Devise_12', $devises, 'CDF', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                                </div></br>
                                <div class="input-group">
                                    <span class="no-padding"></span>
                                    <?php echo form_dropdown('Devise_24', $devises,'CDF', 'class="form-control" id="commissionDevise"  required="required"'); ?>
                                </div></br>
                            </div></br>
                        </div>    
                        <!-------------------------  DGDA Informations additionnelles  ------------------------------>
                        
                        <div class="row">
                            <div class="col-md-12"><br/><label id="infosTitle">Partie 3 : diff&eacute;rentes taxes </label><br/></div>
                        </div> 
                        <div class="row">
                            <div id="details" class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table no-margin table-striped table-bordered">
                                        <thead class='bg-blue'>
                                            <tr>
                                                <th>Taxe</th>
                                                <th>Montant</th>
                                                <th class="center" width="2%"><span class="fa fa-fw fa-trash-o f14"></span></th>
                                            </tr>
                                        </thead>
                                        <tbody id="listTaxes">
                                            <?php for($i=1; $i < 2; $i++){ ?>
                                                <tr id="line<?= $i; ?>"> 
                                                    <td>
                                                        <select name="taxes[]" class="form-control itemgrid iwtd" required="required">
                                                            <option value="" selected disabled></option>
                                                            <?php  foreach ($recettes as $regie => $row): ?>
                                                                <?php  foreach ($row as $key=>$value): ?>
                                                                    <option value="<?= $key; ?>"><?= $value; ?></option>
                                                                <?php endforeach; ?>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                    <td><input type="text" value="" name="amounts[]"  id="fields<?= $i; ?>" data-id-field="<?= $i; ?>" class="itemgrid form-control fields" required="required"/></td>
                                                    <td align="center"><a style="cursor:pointer" onclick="" ><span class="fa fa-fw text-red fa-trash-o f14 text-gray"> </span></a></td>
                                                </tr>
                                            <?php } ?>
                                            <input type="hidden" value="<?= $i-1; ?>" id="increment" >
                                            <input type="hidden" value="<?= $i-1; ?>" id="increment_new_tax" >
                                            <input type="hidden" value="0" id="amount_total" >
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td class="pull-right"><b>Montant total du bulletin :</b></td>
                                                <td><b><span id="total">0,00</span> CDF</b></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    <button id="addFieldNewTax" type="button" onclick="addNewTax()" class="btn btn-primary pull-right">
                                                        <i class=""></i>Autres taxes
                                                    </button>
                                                </td>
                                                <td>
                                                    <button id="addfield" type="button" onclick="addField()" class="btn btn-primary pull-right">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12"><br/>_ _ _ _ _ _ _ <br/></div>
                        <div  id="Comptabilisation" class="col-md-12"></div>
                    </div>
                    <div class="box-footer clearfix">
                        <div class="row">
                            <div class="col-md-12">
                                <b>
                                    <input type="checkbox" name="notemanuelle" value="notemanuelle" id="notemanuelle" style="background-color: green !important"> Cocher ici s&apos;il s&apos;agit d&apos;une note manuelle de versement.<br>
                                </b>
                            </div>
                        </div>  
                        <div class="row">
                            <div id="createPaiement" class="col-md-12">
                                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l&apos; Attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="closeModal" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="submit" id="reserve" class="btn btn-success d-none"><i class="fa fa-archive " ></i>&nbsp;&nbsp;R&eacute;server&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="submit" id="verify" class="btn btn-success d-none"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <input type="hidden" name="action" value="" id="action">
                                <input type="hidden" name="logirefid" value="" id="logirefid">
                                <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                                <input type="hidden" name="transaction_id" value="" id="transaction_id">
                                <input type="hidden" name="error_code" value="" id="error_code">
                            </div>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?> 
      </div>
</div>
</div>


<script type="text/javascript"  charset="utf-8">
    
$(".select2").select2();

var ref = '<?php echo $encaissement->Id_0;?>';

$("#notemanuelle").click(function(){
    
        if($(this).is(":checked"))
        {
                $("#reserve").removeClass('d-none');
                $("#enregistrer").prop('disabled', true);
        }
        else
        {
                $("#reserve").addClass('d-none');
                $("#enregistrer").prop('disabled', false);
        }
    
});

$("#enregistrer").click(function(){
    
        $("#action").val('save');
});


$("#reserve").click(function(){
        $("#action").val('reserve');
});

$("#verify").click(function(){
        $("#action").val('verify');
});

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	 format: 'yyyy-mm-dd'
});

$('#datepicker3').datepicker({
    startView: 2, // Afficher uniquement les années au début
    minViewMode: 2, // Afficher uniquement les années
    todayBtn: "linked",
    keyboardNavigation: false,
    forceParse: false,
    autoclose: true,
    format: "yyyy" // Format de l'année uniquement
});

$('#datepicker4').datepicker({
        todayHighlight: true,
	 format: 'yyyy-mm-dd'
});

$("#compteId").change(function(){
    get_accountname(); 
});

$("#compteDevise").change(function(){
    get_accountname(); 
});

$('#recetteMontant').on("keyup", function() {
    var amount = $(this).val();
    this.value = format_amount(amount);
});

$('#commission').on("keyup", function() {
    var amount = $(this).val();
    this.value = format_amount(amount);
});

$('#recetteMontant').change(function(){
    
    $("#commission").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

    var montant = $(this).val();

    if(montant !== '')
    {
        checkMontant();
        commission();
    }
   
    
});

$("#closeModal").click(function(){
    location.reload(true);
});

'<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
    $("#customerNumber").change(function(){
        var customer_number = $(this).val();

        if (customer_number.length <= '7') 
        {
            get_customeraccounts()
        }
    });
'<?php endif ?>';

$(document).on("input", ".fields", function() {
    let val = $(this).val();
    let formatted = format_amount(val);
    $(this).val(formatted);
});


$(document).on('change', '#compteId', function () {
        
    $("#accountname").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

    const selected = $(this).find(':selected');
    const name = selected.data('name');
    const currency_code = selected.data('currency');
    const balance = selected.data('balance');
    const type = selected.data('type');

    if (!selected.val()) {
        $('#accountname').html('');
        $('#account_name, #account_currency, #account_balance, #account_type').val('');
        $('#compteDevise').val('').trigger('change');
        return;
    }

    const mapped_currency = {
        '976': 'CDF',
        '978': 'EUR',
        '840': 'USD'
    };

    const currency = mapped_currency[currency_code];

    // Ajoute un délai avant d'afficher les infos
    setTimeout(function () {
        $('#accountname').removeClass().addClass('text-green').html(name);
        $('#account_name').val(name);
        $('#account_currency').val(currency);
        $('#account_balance').val(balance);
        $('#account_type').val(type);

        if (currency) {
            $('#compteDevise').val(currency);
            $('#compteDevise').prop('disabled', true);

            // Supprime tout champ hidden existant pour éviter les doublons
            $('input[name="Devise_34"]').remove();

            // Ajoute un input hidden pour l'envoi correct de la valeur
            $('<input>').attr({
                type: 'hidden',
                name: 'Devise_34',
                value: currency
            }).appendTo('form');
        }
    }, 2000);
});

$("#pager").on("submit", "#confirmform", function(event){
    
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        scrollUP();
        
        var data = $(this).serialize();
        var action = $('#action').val();
        
        if(action == 'save')
        {
            submiter(data);
        }
        else if(action == 'reserve')
        {
            <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
                get_reservation(data);
            <?php else :  ?>
                create_bulletin_and_debit_the_customer(data);
            <?php endif;  ?>
        }
        else if(action == 'verify')
        {
            // Verification de la reseravtion en cas d'echec
            verify(data);   
        }   
});

$("#details").on("change", ".fields", function()
{
        var id_field = $(this).attr('data-id-field');
        
        var montant = $('#fields'+id_field).val();
        
        var montant_total = $('#amount_total').val();
        
        var recetteMontant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
        
        var montant = parseFloat($('#fields'+id_field).val().split(' ').join('').split(',').join('.'));
        
        montant_total = parseFloat(montant_total);
        
        montant_total += montant;

        $('#amount_total').val(montant_total)
        $('#total').html(montant_total.toLocaleString())
        
        if(montant_total > recetteMontant)
        {
            scrollUP();
            $('#loader-sub-menu').html('<div class="alert aWarning text-white">La somme des montants des taxes ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            $("#enregistrer").prop('disabled', true);
            montant_total = montant_total - montant;
            $('#amount_total').val(montant_total)
            $('#total').html(montant_total.toLocaleString())
            //$("#addfield").prop('disabled', true);
        }
        else
        {
            
            $('#loader-sub-menu').html('');
            $("#enregistrer").prop('disabled', false);
            //$("#addfield").prop('disabled', false);
        }  
});

function submiter(data){

    $("#loader-sub-menu").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    var url = '<?php echo base_url('branch/taxothers/display/encaissement'); ?>';

    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){
                    
                    if(result === "E412")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Le montant à payer doit être égal à la somme totale des taxes du bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E404" || result === "E22")
                    {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E402")
                    {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">Le paiement existe déjà, veuillez le retrouver dans le menu paiement non valid&eacute; .<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E405")
                    {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E13")
                    {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">Cette D&eacute;claration est introuvable.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E406")
                    {
                            $('#loader-sub-menu').html('<div class="alert aDanger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E501" || result === "E502")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Avertissement:Ce paiement existe d&eacute;j&agrave; dans le syst&egrave;me, allez v&eacute;rifier  dans le rapport des paiements en attente de validation!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E503")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Avertissement:Ce paiement existe d&eacute;j&agrave; dans le syst&egrave;me, allez v&eacute;rifier  dans le rapport des paiements valid&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E003")
                    {
                            $('#loader-sub-menu').html('<div class="alert aWarning text-white">Alerte: erreur fatal E003...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $('#loader-sub-menu').html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            
                            var url = '<?php echo base_url($module.'/taxothers/display/preview'); ?>/' + result;

                            $.get(url, function(data, status){
                                $("#pager").html(data);
                            });
                    }
            },
            error:function(error){
                $('#loader-sub-menu').html('<div class="alert aWarning text-white">Ce bulletin existe déjà, vous ne pouvez pas le saisir deux fois.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
    });
        
}

function get_reservation(data)
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var Office = $('#service option:selected').val();
        var Number = $('#assessment_number').val();
        var Series = $('#assessment_serial').val();
        var Nif = $('#company').val();
        var Year = $('#datepicker3').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxaccounts/data/get_reservation'); ?>';
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : { compte : compte, devise : devise, montant : montant, Office: Office, Year: Year, Number: Number, Nif:Nif, Series: Series, csrf_name:csrf}, 
            dataType    : 'json',  
            encode          : true,
            success: function(response)
            {	
                if(response.code == '200')
                {
                    $("#lien_id").val(response.lien_id);
                    $("#date_lien").val(response.date_lien);
                    create_bulletin_and_reserve_the_fund(data, "reservation");
                }
                else if(response.code =='E500')
                {
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#mainform').serialize();

                    $("#loader-sub-menu").html('');

                    $("#loader-sub-menu").html('<div class="alert alert-info text-black"> Vous avez d&eacute;j&agrave; fait une r&eacute;servation pour ce paiement, veuillez contacter le validateur pour la validation de ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '404')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">La r&eacute;servation n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '405')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">La r&eacute;servation n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '406')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Probl&egrave;me de connexion survenu entre logiref et synergies, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code == '407')
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Désolé, la fonctionnalité de reservation de fonds n\'est pas configurée pour ce compte logiref, veuillez contacter votre administrateur à cet effet<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(response.code != '')
                {
                    $("#loader-sub-menu").html(response.error_message);
                }
                else
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error)
            {
                $('#message').html('<div class="alert aWarning text-white">Alerte: Probl&eacute;me de connexion &agrave; synergies. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
}

function get_reservation_debit_account(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxothers/display/debit_client'); ?>';

    //$("#reserve").prop('disabled', true);
    $("#treat").prop('disabled', true);

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){

            if(result.code=='E407')
            {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#reserve').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else
            {
                if(result.code == 'E200' || result.code == 'E500')
                {
                    var data = $('#confirmform').serialize();
                    submiter(data);
                }
                else
                {
                    $("#loader-sub-menu").html(result.msg);
                    $('#verify').removeClass('d-none');
                    //$("#reserve").prop('disabled',true);

                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                    $('#logirefid').val(result.logirefid);
                }
            } 

        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La r&eacute;servation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function create_bulletin_and_debit_the_customer(data, type=null)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                
    //$('#reserve').prop("disabled", true);
    var button = $('#reserve').html();
    $('#reserve').html('<span>Chargement...</span>');
   
    scrollUP();

    var url = '<?php echo base_url($module.'/taxothers/display/create_note'); ?>/'+type;

    $.ajax({
           type        : 'POST', 
           url         : url, 
           data        : data, 
           dataType    : 'json', 
           encode      : true,
           success: function(result){
                $('#reserve').html(button);
                $("#loader-sub-menu").html(result);

                if(result.code == 'E200')
                {   
                    $('#logirefid').val(result.logirefid);
                    $('#bulletin_id').val(result.id);
                    var data = $('#confirmform').serialize();

                    get_reservation_debit_account(data);    
                } 
                else 
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
           },
           error:function(error){
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement a pris beaucoup de temps, veuillez réessayer, puis réessayez s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#envoyer').html(button);
           }
    });
}

function create_bulletin_and_reserve_the_fund(data, type=null)
{
    data = $('#confirmform').serialize();

    var bank = '<?php echo $bank ?>';

    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxothers/display/create_bulletin'); ?>/'+type;

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json',  
        encode          : true,
        success: function(response)
        {	
            if(response.id > 0)
            {
                '<?php if(isset($options['DGDA']['funds-reservation-with-instructions'])): ?>';
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#confirmform').serialize();
                    
                    initiate_transaction(data);
                    
                '<?php else: ?>'
                    $('#bulletin_id').val(response.id);
                    $('#logirefid').val(response.reference);

                    var data = $('#confirmform').serialize();

                    $("#loader-sub-menu").html('<div class="alert aSuccess text-white"> L\'enregistrement fait avec succ&egrave;s, veuillez contacter le validateur pour la condirmation de ce bulletin.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    //$("#reserve").prop('disabled', true);
                    $("#treat").prop('disabled', true);
                '<?php endif; ?>'
            }
            else
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error:function(error)
        {
            $('#message').html('<div class="alert aWarning text-white"> L\'enregistrement de ce paiement n\'a pas abouti, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }  
    });
}

function initiate_transaction(data)
{  
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxothers/display/initiate_transaction'); ?>';
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            
            if(result.code == '200')
            {
                    var data = $('#confirmform').serialize();
                    submiter(data);
            }
            else
            {
                    //$("#reserve").prop('disabled', true);
                    $("#notemanuelle").prop('disabled', true);
                    $("#loader-sub-menu").html(result.message);
                    
            }
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement du paiement a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function verify(data)
{
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxothers'); ?>/display/verify_transaction_single';

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            $("#loader-sub-menu").html('');

            if(result.code =='E407')
            {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#repartition').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else if(result.code =='E200')
            {
                $("#verify").prop('disabled',true);
                next_step(data);
            }
            else
            {
                $('#loader-sub-menu').html(result.msg);
            }
        },
        error:function(error)
        {
            $('#loader-sub-menu').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function cancel_reservation(data)
{
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxbulletin/display/cancel_reservation'); ?>';
        
        $("#extourne").prop('disabled', true);
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){
                $("#loader-sub-menu").html('');

                if(result.code =='E407')
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option d\'annulation de réservation n\'est pas paramétrée pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#repartition').prop("disabled",true);
                    $('#valider').prop("disabled",true);
                }
                else if(result =='E200')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info text-black"> L\'extourne a &eacute;t&eacute; faite avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result =='E411')
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

            },
            error:function(error)
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'extourne a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
}

function get_customeraccounts() 
{
    const customer_number = $('#customerNumber').val();
    const csrf = $('input[name="csrf_name"]').val();
    const core_banking = '<?php echo $core_banking; ?>';

    const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

    if (!customer_number) {
        //$("#labelNumber").html('');
        $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
        return;
    }

    const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
    $("#labelNumber, #compteLabel").html(loader_img);

    $('#compteDevise').prop('disabled', false);

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            customer_number: customer_number,
            csrf_name: csrf
        },
        dataType: 'json',
        encode: true,
        success: function (reponse) {

            if (reponse.code == "200")
            {
                const mapped_currency = {
                    '976': 'CDF',
                    '978': 'EUR',
                    '840': 'USD'
                };

                let select = $('<select>', {
                    id: 'compteId',
                    name: 'Compte_33',
                    class: 'form-control form-control-md',
                    required: true
                });

                select.append('<option value="">Sélectionnez un compte du client</option>');

                $.each(reponse, function (index, account) {
                    if (!isNaN(index)) {

                        const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                        const option_text = `${account.accountNumber} - (${currency_label})`;

                        select.append($('<option>', {
                            value: account.accountNumber,
                            text: option_text,
                            'data-name': account.name,
                            'data-currency': account.currencyCode,
                            'data-balance': account.balance,
                            'data-type': account.type
                        }));
                    }
                });

                // Remplace l'élément actuel (input ou select)
                if ($('#compteId').prop('tagName') === 'SELECT') {
                    $('#compteId').replaceWith(select);
                } else {
                    $('#compteId').replaceWith(select);
                }

                // Déclenche le changement
                select.trigger('change');

                $("#compteLabel").html('Comptes du client');
                $("#labelNumber").html('');

            } else{
                const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
    
                $('#compteId').replaceWith(input_html);

                $("#compteLabel").html('Compte du client');
                $("#labelNumber").html('');

                if (reponse.code == '406') {
                    $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                    return;
                } else if (reponse.code == '405') {
                    $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                    return;
                } else if (reponse.code == '404') {
                    $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                    return;
                }
            }
        },
        error: function () {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}

function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; au corebanking');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Un problème est survenu lors de la récupération des informations du compte.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        } 
}

function commission() {

    $("#Devise_24").prop("selectedIndex", 0);
    var mode = $('#modeId').val();
    var montant = $('#recetteMontant').val();
    var regie = 'DGDA';
    var service = $('#service option:selected').val();
    var devise = $('#recetteDevise option:selected').val();
    var commission = $("#commission").val();
    var recette = '';
    var guichet = $('#guichetId').val();
    var compte = $('#compteId').val();
    var taux = $('#Taux').val();
    var csrf = $('input[name="csrf_name"]').val();

    if (montant !== '' && devise !== '' && service !== '') {
        var url = '<?php echo base_url('admin/fees/display/'); ?>/default<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
        $("#commission").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                mode: mode,
                regie: regie,
                service: service,
                recette: recette,
                devise: devise,
                montant: montant,
                guichet: guichet,
                compte : compte,
                csrf_name:csrf
            },
            dataType: 'html',
            encode: true,
            success: function(reponse) {
                var result = JSON.parse(reponse);

                if (commission == '' || commission == '0') 
                {
                    $("#commission").val(result[0]);
                    $("#commissionDevise").val(result[1]);
                    
                    //montant = result[2].toFixed(2);
                    //$("#montantTotal").val(montant);
                }

                //$("#enregistrer").prop('disabled', false);
            },
            error: function(error) {
                $('#bl').html('');
                $("#loader-sub-menu").html('<div class="alert aWarning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
}

function addField()
{
        var increment = $('#increment').val();
        increment = parseFloat(increment);
        increment +=1;
        $('#increment').val(increment);
        
        var url = '<?php echo base_url($module.'/taxothers'); ?>/display/selectTaxes';
        $.get(url, function(data, status){

            $("#listTaxes").append('<tr id="line'+increment+'"><td>'+ data +'</td><td><input type="text" name="amounts[]" value="" class="itemgrid form-control fields" id="fields'+increment+'" data-id-field="'+increment+'" required="required"></td><td align="center"><a style="cursor:pointer" onclick="deleField('+increment+')" ><span class="fa fa-fw text-red fa-trash-o f14"></span></a></td></tr>');
			//$(".selecttaxes").select2();
        });
        
}

function addNewTax()
{
        var increment = $('#increment').val();
        increment = parseFloat(increment);
        increment +=1;
        $('#increment').val(increment);
        
        var url = '<?php echo base_url($module.'/taxothers'); ?>/display/input_new_tax';
        $.get(url, function(data, status){

            $("#listTaxes").append('<tr id="line'+increment+'"><td>'+ data +'</td><td><input type="text" name="amounts[]" value="" class="itemgrid form-control fields" id="fields'+increment+'" data-id-field="'+increment+'" required="required"></td><td align="center"><a style="cursor:pointer" onclick="deleField('+increment+')" ><span class="fa fa-fw text-red fa-trash-o f14"></span></a></td></tr>');
        });
        
}

function deleField(id)
{
        var montant = parseFloat($('#fields'+id).val().split(' ').join('').split(',').join('.'));

        if (isNaN(montant)) 
        {
            montant = 0;
        }

        $('#line'+id).remove();
        
        var montant_total = parseFloat($('#amount_total').val().split(' ').join('').split(',').join('.'));        
        
        montant_total = montant_total - montant;

        var recetteMontant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
        
        $('#amount_total').val(montant_total);
        
        $('#total').html(montant_total.toLocaleString());  
        
        if (recetteMontant == montant_total)
        {
            $("#enregistrer").prop('disabled', false);
            //$("#addfield").prop('disabled', false);
            $('#loader-sub-menu').html('');
        }
        else
        {

        }
}

function checkMontant()
{
        var MontanTotal = parseFloat($('#amount_total').val().split(' ').join('').split(',').join('.'));
        var recetteMontant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

        if(recetteMontant <= MontanTotal)
        {
            $('#recetteMontant').val('');
            $('#commission').val('');
        }
}

function format_amount(value) {

        value = value.replace(",", ".");

        // Séparer la partie entière et la partie décimale
        let parts = value.split(".");

        // Garder uniquement les chiffres dans la partie entière
        let part_integer = parts[0].replace(/\D/g, "");

        // Ajouter espace comme séparateur des milliers
        part_integer = part_integer.replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        // Si décimal présent, on le conserve
        if (parts.length > 1) {
            return part_integer + "." + parts[1].replace(/\D/g, "");
        } else {
            return part_integer;
        }
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader-sub-menu").offset().top
    }, 20);
}




</script>



