<div class="row">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-1">
                    <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">1</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left p-2">V&eacute;rification de la d&eacute;claration<br/></div>
                </div>
                <div class="col-md-1">
                    <div id="step-2" title="" class="bRound <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">2</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left p-2">Confirmation du paiement<br/></div>
                </div>
                <div class="col-md-1">
                    <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">3</div>
                </div>
                <div class="col-md-3">
                    <div class="pull-left p-2">Impression de la preuve<br/></div>
                </div>
            </div>
        </div>
        <div id="loader-sub-menu"></div>
        <div class="col-md-12"><br/></div>
        <div id="pager" class="col-md-12 no-padding">
            <?php
                if($step==2)
                {
                        echo $this->load->view('_step_2');
                }
                elseif($step==3)
                {
                        echo $this->load->view('_step_3');
                }
                else
                {
            ?>
            <?php $chtml->box_body_opening("", true);?>
                <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div id="approvalWarning" style="color:#F00"></div><br/>
                            <p>
                                Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de la declaration DGPEK.
                            </p>
                            <br/><br/>
                        </div>
                        <div class="col-md-8 bLeft">
                            <div class="box-body">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="Noteid_26" style="padding-left:0;">Num&eacute;ro de la d&eacute;claration</label>
                                        <?php echo form_input('Noteid_26','', 'class="form-control"  id="Noteid_26" required="required"'); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" style="margin:0px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?>

            <?php }?>
        </div>
    </div>
</div>

<script type="text/javascript">

    $('#mainform').submit(function(event){
            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            var data = $(this).serialize();
            next_step(data);

    });

    function next_step(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxdgpek/display/verification'); ?>';
            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){

                            $('#loader-sub-menu').html('');

                            $("#pager").html(result);
                            $("#step-1").removeClass('bg-green-active');
                            $("#step-1").addClass('bg-gray');
                            $("#step-2").removeClass('bg-gray');
                            $("#step-2").addClass('bg-green-active');

                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    }

    $("#cancel").click(function(){
        location.reload(true);
    });

</script>