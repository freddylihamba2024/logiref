<div class="col-md-11">
    <h2 class="text-blue"><?php echo $title; ?></h2>
    <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente tous les odres de paiement effectu&eacute;s.</span></h5>
</div>
<div class="col-md-1">
</div>
<div class="col-md-11">
    <div id="loader"></div>
    <?php if (!empty($ordres)): ?>
    <?php $chtml->box_body_opening('', true); ?>  
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-gray">
                    <th width="4%">#</th>
                    <th width="10%">Date</th>
                    <th width="10%">Status</th>
                    <th width="10%">B&eacute;n&eacute;ficiaire</th>
                    <th width="10%">Service</th>
                    <th width="20%">Compte</th>
                    <th width="15">Montant</th>
                    <th width="5%"><span class="fa fa-fw fa-folder f14"></span></th>
                    <th width="5%"><span class="fa fa-fw fa-file-pdf-o f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;  foreach($ordres as $row):?>
                    <tr>
                        <td width="4%"><?php echo $i;?></td>
                        <td width="10%"><?php echo $row->Date_1;?></td>
                        <td width="10%"><span class="badge  <?php echo $OrderColor[$row->Status_2]; ?>"> <?php echo $status[$row->Status_2];?></span></td>
                        <td  width="10%"><?php echo $row->Regie_7;?></td>
                        <td  width="10%"><?php if($row->Service_8 == 0)echo '-'; else echo $row->Service_8;?></td>
                        <td width="20%"><?php echo $row->Account_10;?></td>
                        <td width="15%"><?php echo $row->Currency_11.' '.number_format($row->Amount_12,2,","," ");?></td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1 || $row->Status_2 == 2):?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Status_2; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item">
                                    <?php if($row->Status_2 == 1):?>
                                        <span class="fa fa-fw text-green fa-edit f14"> </span>
                                    <?php elseif($row->Status_2 == 2):?>
                                        <span class="fa fa-fw text-yellow fa-folder-open-o f14"> </span>
                                    <?php endif;?>
                                </a>
                            <?php endif;?>
                        </td>
                        <td width="5%"> 
                            <?php if($row->Status_2 == 1):?>
                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                            <?php elseif($row->Status_2 == 2):?>
                                <a style="cursor:pointer" onclick="print('<?php echo $row->Paiementid_15; ?>')" ><span class="fa fa-fw text-yellow fa-file-pdf-o f14"> </span></a>
                            <?php endif;?>
                        </td>
                    </tr>
                <?php $i++; endforeach;?>
            </tbody>
        </table>
    <?php $chtml->box_body_closing(); ?>
    <?php else: ?>
        <section>
            <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <h4 align="center"><b>Aucun odre de paiement trouv&eacute;!</b></h4>
                <br/>
            </div>
        </section>
    <?php endif; ?> 
</div>
<div class="col-md-1"></div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
    "paging": true,
    "order": [[5, "DESC" ]],
    "lengthChange": false,
    "searching": false,
    "ordering": true,
    "info": true,
    "autoWidth": false
});
 
$("#NewOP").click(function()
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get("<?php echo base_url($module.'/clients/display/ordre'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
            $('#requestPage').css( "display", "block");
    });
});

$("#contenter").on("click", ".item", function(){
    
    var from = '<?= isset($from) ? $from : "" ?>';
    
    if(from =="new")
    {
        $("#form_order").removeClass('hidden');
        $("#close").addClass('hidden');
        $("#cancel").addClass('hidden');
    }
    else
    {
        $("#form_orders").removeClass('hidden');
        $("#close").addClass('hidden');
        $("#cancel").addClass('hidden');
    }
    
    
});

function view(id, status)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');

    var from = '<?= isset($from) ? $from : "" ?>';

    var url = '<?php echo base_url($module.'/bank/display/order'); ?>/' + id +'/'+status+'/'+from;
    $.get(url, function(data, status){
      $("#loader").html('');
      $("#pager").html(data);
    });
}

function print(id)
{
        $('#enregistrer').prop("disabled",true);
         
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + id;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
}
</script>