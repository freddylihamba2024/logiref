<div class="row">
    <div class="col-md-9">
        <!--<div class="row">
            <div class="col-md-4">
                <div class="ibox ">
                    <div class="ibox-title">
                        <div class="ibox-tools">
                            <span class="label label-success float-right">DGI</span>
                        </div>
                        <h5>Paiement Journalier</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?= number_format($DGI_USD,2,',',' ') ?></h1>
                        <span class="label label-danger">USD</span>
                        <div class="float-right text-right">
                            <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                        </div>
                    </div>
                    <div class="ibox ">
                        <div class="ibox-content ibox-heading">
                            <h3><?= number_format($DGI_CDF,2,',',' ') ?></h3>
                            <small class="label">CDF</small>
                            <div class="float-right text-right">
                                <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox ">
                    <div class="ibox-title">
                        <div class="ibox-tools">
                            <span class="label label-info float-right">DGRAD</span>
                        </div>
                        <h5>Paiement Journalier</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?= number_format($DGRAD_USD,2,',',' ') ?></h1>
                        <span class="label label-danger">USD</span>
                        <div class="float-right text-right">
                            <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                        </div>
                    </div>
                    <div class="ibox ">
                        <div class="ibox-content ibox-heading">
                            <h3><?= number_format($DGRAD_CDF,2,',',' ') ?></h3>
                            <small class="label">CDF</small>
                            <div class="float-right text-right">
                                <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox ">
                    <div class="ibox-title">
                        <div class="ibox-tools">
                            <span class="label label-primary float-right">DGDA</span>
                        </div>
                        <h5>Paiement Journalier</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?= number_format($DGDA_CDF,2,',',' ') ?></h1>
                        <span class="label label-danger">USD</span>
                        <div class="float-right text-right">
                            <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                        </div>
                    </div>
                    <div class="ibox ">
                        <div class="ibox-content ibox-heading">
                            <h3>0,00</h3>
                            <small class="label">CDF</small>
                            <div class="float-right text-right">
                                <span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->

        <div class="row">
            <div class="col-md-4">
                <div class="ibox">
                    <div class="ibox-title bg-light">
                        <h5>DGDA</h5>
                    </div>
                    <div class="ibox-content">
                        <h4 class="mt-2 mb-1"><?= number_format(0.00,2,","," "). " USD" ?></h4>
                        <small class="text-success">(Paiements)</small>
                        <h4 class="mt-4 mb-2"><?= number_format($DGDA_CDF,2,","," "). " <span class='text-info'>CDF</span>" ?></h4>
                        <small class="text-success">(Paiements)</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox ">
                    <div class="ibox-title bg-light">
                        <h5>DGI</h5>
                    </div>
                    <div class="ibox-content">
                        <h4 class="mt-2 mb-1"><?= number_format($DGI_USD,2,","," "). " USD" ?></h4>
                        <small class="text-success">(Paiements)</small>
                        <h4 class="mt-4 mb-2"><?= number_format($DGI_CDF,2,","," "). " <span class='text-info'>CDF</span>" ?></h4>
                        <small class="text-success">(Paiements)</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox ">
                    <div class="ibox-title bg-light">
                        <h5>DGRAD</h5>
                    </div>
                    <div class="ibox-content">
                        <h4 class="mt-2 mb-1"><?= number_format($DGRAD_USD,2,","," "). " USD" ?></h4>
                        <small class="text-success">(Paiements)</small>
                        <h4 class="mt-4 mb-2"><?= number_format($DGRAD_CDF,2,","," "). " <span class='text-info'>CDF</span>" ?></h4>
                        <small class="text-success">(Paiements)</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!--div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-title">
                        <h5>Orders</h5>
                        <div class="ibox-tools">
                            <div class="btn-group">
                                <button type="button" class="btn btn-xs btn-white active">Today</button>
                                <button type="button" class="btn btn-xs btn-white">Monthly</button>
                                <button type="button" class="btn btn-xs btn-white">Annual</button>
                            </div>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="row">
                        <div class="col-lg-9">
                            <div class="flot-chart">
                                <div class="flot-chart-content" id="flot-dashboard-chart"></div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <ul class="stat-list">
                                <li>
                                    <h2 class="no-margins">2,346</h2>
                                    <small>Total orders in period</small>
                                    <div class="stat-percent">48% <i class="fa fa-level-up text-navy"></i></div>
                                    <div class="progress progress-mini">
                                        <div style="width: 48%;" class="progress-bar"></div>
                                    </div>
                                </li>
                                <li>
                                    <h2 class="no-margins ">4,422</h2>
                                    <small>Orders in last month</small>
                                    <div class="stat-percent">60% <i class="fa fa-level-down text-navy"></i></div>
                                    <div class="progress progress-mini">
                                        <div style="width: 60%;" class="progress-bar"></div>
                                    </div>
                                </li>
                                <li>
                                    <h2 class="no-margins ">9,180</h2>
                                    <small>Monthly income from orders</small>
                                    <div class="stat-percent">22% <i class="fa fa-bolt text-navy"></i></div>
                                    <div class="progress progress-mini">
                                        <div style="width: 22%;" class="progress-bar"></div>
                                    </div>
                                </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->

            <div class="col-lg-12">
                <div class="ibox">
                    <!--<div class="ibox-title">
                        <h5>Tableau de statistique des paiements journalière par agences</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="table_foo_table.html#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="table_foo_table.html#" class="dropdown-item">Config option 1</a>
                                </li>
                                <li><a href="table_foo_table.html#" class="dropdown-item">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>-->
                    <div class="ibox-content">
                        <!--<input type="text" class="form-control form-control-sm m-b-xs" id="filter" placeholder="Rechercher dans la table">

                        <table id="table" class="table table-stripped" data-page-size="15" data-filter=#filter>-->

                        <div class="table-responsive">
                            <table id="table" class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th>No</th>
                                        <th>Agences</th>
                                        <th>Regies</th>
                                        <th>Nombre</th>
                                        <th>Montant USD</th>
                                        <th>Montant CDF</th>
                                    </tr>
                                    <?php
                                    if(count($agences) > 0){
                                        $i = 1;
                                        foreach($agences as $agence){
                                    ?>
                                    <tr rowspan="3">
                                        <td rowspan="3" style="vertical-align:middle;">
                                            <?= $i ?>
                                        </td>
                                        <td rowspan="3" style="vertical-align:middle;">
                                            <?= $agence->Nom_4 ?>
                                        </td>
                                        <td>DGRAD</td>
                                        <td><?= ($agence->DGRAD_USD_ToT) + ($agence->DGRAD_CDF_ToT) ?></td>
                                        <td><?= number_format($agence->DGRAD_USD,2,',',' ') ?></td>
                                        <td><?= number_format($agence->DGRAD_CDF,2,',',' ') ?></td>
                                    </tr>
                                    <tr>
                                        <td>DGI</td>
                                        <td><?= ($agence->DGI_USD_ToT) + ($agence->DGI_CDF_ToT) ?></td>
                                        <td><?= number_format($agence->DGI_USD,2,',',' ') ?></td>
                                        <td><?= number_format($agence->DGI_CDF,2,',',' ') ?></td>
                                    </tr>
                                    <tr>
                                        <td>DGDA</td>
                                        <td><?= $agence->DGDA_CDF_ToT ?></td>
                                        <td></td>
                                        <td><?= number_format($agence->DGDA_CDF,2,',',' ') ?></td>
                                    </tr>
                                    <?php
                                                $i++;
                                            }
                                        }
                                        else{
                                ?>
                                    <tr>
                                        <td class="center" colspan="6">Aucun résultat</td>
                                    </tr>
                                <?php
                                        }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="6">
                                            <ul class="pagination float-right"></ul>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 bLeft h-600">
        <div class="col-md-12 h-300">
            <h4 class="f18 ">Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br /></h4>
            <span class='f16 text-gray'>Aucune alerte trouv&eacute;e !<br /><br /></span>
        </div>
        <div class="col-md-12 bTop d-block f18" >
            <h4 class="f18">Insights<br /></h4>
            <span class='f16 text-gray'>Aucune donn&eacute;e trouv&eacute;e !<br /><br /></span>
        </div>
    </div>
</div>

<br/>
<br/>

<!--<div class="row">
    <!--<div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title text-blue">
                <h5>Personnes actuellement en attente<span class="label label-primary"><?php //echo $total_waiting;?></span></h5>
                <div class="ibox-tools">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-users"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#">Voir toutes les agences</a></li>
                        <li><a href="#">Rechercher une agence</a></li>
                    </ul>
                </div>
            </div>
            <div class="ibox-content">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-hover margin bottom">
                            <thead>
                                <tr>
                                    <th style="width: 1%" class="text-center">ID.</th>
                                    <th>Agence bancaire</th>
                                    <th class="text-center">Heure</th>
                                    <th class="text-center">Personne</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php /*$count=0; ?>
                                <?php foreach($guichets as $key=> $val): ?>
                                <?php if(isset($branches_infos[$key]['total']) && ($branches_infos[$key]['total']-$branches_infos[$key]['served'])>0): ?>
                                <tr>
                                    <td class="text-center"><?php echo $key; ?></td>
                                    <td class="text-blue"> <?php echo $val; ?> </td>
                                    <td class="text-center small"><?php echo gmdate('H:s'); ?> </td>
                                    <td class="text-center"><span class="label label-primary"> <?php echo $branches_infos[$key]['total']-$branches_infos[$key]['served']; ?> </span> </td>
                                </tr>
                                <?php elseif(!empty($val)): ?>
                                <tr>
                                    <td class="text-center"><?php echo $key; ?></td>
                                    <td> <?php echo $val; ?> </td>
                                    <td class="text-center small"><?php echo gmdate('H:s'); ?> </td>
                                    <td class="text-center"><span class="label label-warningy"> <?php echo 0; ?> </span> </td>
                                </tr>
                                <?php $count++; ?>
                                <?php endif; ?>
                                <?php if($count==25) break; ?>
                                <?php endforeach;*/ ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5 class="text-blue">Visites par type d’opération</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-area-chart text-blue fa-2x"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <table class="table table-hover no-margins">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Service/Type d’opération</th>
                            <th>Stat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php /*$i=1; ?>
                        <?php if(!empty($token_by_category)): ?>
                        <?php foreach($token_by_category as $val): ?>
                        <?php if(isset($categories[$val->category])){ ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td class="text-blue"><?php if(isset($categories[$val->category])) echo $categories[$val->category]; ?></td>
                            <td> <span class="label label-primary"> <?php echo $val->total; ?> </span></td>
                        </tr>
                        <?php } ?>
                        <?php endforeach; ?>
                        <?php endif;*/ ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5 class="text-blue">RDV par type d’opération</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-clock-o text-green fa-2x"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <table class="table table-hover no-margins">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Service/Type d’opération</th>
                            <th>Stat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php /*$i=1; ?>
                        <?php if(!empty($appointment_by_category)): ?>
                        <?php foreach($appointment_by_category as $val): ?>
                        <?php if(isset($categories[$val->category])){ ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td class="text-blue"><?php if(isset($categories[$val->category])) echo $categories[$val->category]; ?></td>
                            <td> <span class="label bg-green text-white"> <?php echo $val->total; ?> </span></td>
                        </tr>
                        <?php } ?>
                        <?php endforeach; ?>
                        <?php endif;*/ ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>-->

<!-- Page-Level Scripts -->
<script type="text/javascript">

    $(document).ready(function() {

        $("#table").DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": true,
            "ordering": true,
            "info": false,
            "autoWidth": false,
            "pageSize": 50,
            //"dom": '<"row"<"col-md-6 d-flex align-items-center custom-search"f><"col-md-6 text-right"p>>', // Personnalisation du DOM
            "language": {
                "paginate": {
                    "next": "<i class='fa fa-chevron-right'></i>", // Remplace "Next"
                    "previous": "<i class='fa fa-chevron-left'></i>" // Remplace "Previous"
                },
                "search": "Rechercher :", // Traduction de la recherche
                "lengthMenu": "Afficher _MENU_ entrées",
                "zeroRecords": "Aucun enregistrement trouvé",
                "infoEmpty": "Aucune donnée disponible",
                "infoFiltered": "(filtré à partir de _MAX_ total des enregistrements)"
            },
            "initComplete": function () {
                // Déplacer la barre de recherche vers votre conteneur personnalisé
                $(".dataTables_filter").appendTo("#custom-search");
            }
        });

        /*$('.footable').footable();
        $('.footable2').footable();

        var lineData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
                {
                    label: "Example dataset",
                    backgroundColor: "rgba(26,179,148,0.5)",
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: [28, 48, 40, 19, 86, 27, 90]
                },
                {
                    label: "Example dataset",
                    backgroundColor: "rgba(220,220,220,0.5)",
                    borderColor: "rgba(220,220,220,1)",
                    pointBackgroundColor: "rgba(220,220,220,1)",
                    pointBorderColor: "#fff",
                    data: [65, 59, 80, 81, 56, 55, 40]
                }
            ]
        };

        var lineOptions = {
            responsive: true
        };

        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});*/

    });
</script>