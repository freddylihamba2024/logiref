<div class="row">
        <div class="col-md-1 text-center">
                <a href="<?php echo base_url('/main/overview'); ?>"><span class="fa fa-th text-blue f40"></span></a>
        </div>

    <div class="col-md-10 no-padding" id="content">
            <div id="loader" class="loader"></div>
        
            <div class="col-md-12" id="alert"></div>
            
            <div class="row">
                        <div class="col-md-12 no-padding">
                            <div class="col-md-12 f24 text-black">
                                    <h1>Traitement <b>Taxes et Impôts</b></h1>
                                    <p class="page-header">Solution de l'automatisation du traitement des paiements DGI, DGRAD & DGDA</p>
                            </div>
                        </div>

                        <div class="col-md-12">
                                <div class="row">
                                        <div class="col-sm-6">
                                                <div class="col-md-12">
                                                        <h1 class="m-b-xs text-blue">
                                                                <b>CDF </b>
                                                        </h1>
                                                        <small class="m-b-xs text-blue">1 USD</small>
                                                        <div id="sparkline1" class="m-b-sm"><canvas style="display: inline-block; width: 353.333px; height: 50px; vertical-align: top;" width="353" height="50"></canvas></div>
                                                </div>
                                                <div class="col-md-12">
                                                        <div class="row">
                                                                <div class="col-md-4 text-orange">
                                                                        <small class="stats-label">1 EUR</small>
                                                                        <h4>CDF </h4>
                                                                </div>
                                                                <div class="col-md-4 text-red">
                                                                        <small class="stats-label">1 POUND</small>
                                                                        <h4>CDF </h4>
                                                                </div>
                                                                <div class="col-md-4 text-black">
                                                                        <small class="stats-label">1 RAND</small>
                                                                        <h4>ff</h4>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                        
                                        <div class="col-sm-6">
                                            <div class="ibox-content m-b">
                                                <div class="row m-t-xs">
                                                        <div class="col-md-12">
                                                                <h3 class="no-margins text-blue"> <b>Nouveaux paiements.. </b> </h3>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="nav nav-pills nav-stacked">
                                                                <li id=''><a onclick="action('_taux')" class="text-blue f12"><i class="fa fa-plus-circle"></i> Changer les taux de change</a></li>
                                                                <li id=''><a onclick="action('sydonia')" class="text-blue f12"><i class="fa fa-cogs"></i> Configuration acces SYDONIA</a></li>
                                                                <li id=''><a onclick="message()" class=" f12"><i class="fa fa-credit-card-alt"></i> Approvisionnement compte pr&eacute;paiement</a></li>
                                                                <li id=''><a onclick="message()" class=" f12"><i class="fa fa-file-excel-o"></i> Extraction licence BCC</a></li>
                                                            </ul>
                                                            <ul class="nav nav-pills nav-stacked">
                                                                <li id=''><a onclick="action('situation_dgi')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re (DGI)</a></li>
                                                                <li id=''><a onclick="action('situation_dgrad')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re (DGRAD)</a></li>
                                                                <li id=''><a onclick="action('situation_dgda')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re guichet unique (DGDA)</a></li>
                                                                <li id=''><a onclick="" class=" f12"><i class="fa fa-minus"></i> Situation journali&egrave;re de pr&eacute;paiement (DGDA)</a></li>
                                                            </ul>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                        </div>

                        <div class="col-md-12 no-padding">
                                <div class="col-md-12 f24 text-blue">
                                        <p class="page-header"></p>
                                        <h3>Outils disponibles pour la <b></b></h3>
                                        <p class="page-header">Les solutions visant à simplifier divers traitements de paiement sont centralisées et intégrées.</p>
                                </div>
                        </div>

                </div>
            
            
            
            

        <div id="pager">
            <div class="row no-padding">
                <div class="col-md-8">
                    <h2 class="text-blue f25"><?php echo " Nouveau..."; ?></h2>
                    <p class="page-header"></p>
                </div>
                <div class="col-md-3">
                    <h2 class="text-blue f25" ><a class="text-blue" href="#" id="alerts"><?php echo " Alertes"; ?> <i class="text-gray glyphicon glyphicon-bell f16"></i></a></h2>
                    <p class="page-header"></p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 bRight">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('declaration')">
                                    <i class="fa fa-file-text text-aqua f30"></i><br/>
                                    <span class="f12 text-black">D&eacute;claration (DGI)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('note_perception')">
                                    <i class="fa fa-file-text-o text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Note de perception (DGRAD)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('bulletin')">
                                    <i class="fa fa-file-code-o text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Bulletin de liquidation (DGDA)</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('_other')" >
                                    <i class="fa fa-files-o text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Autres paiements(DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('_prepaymentList')" >
                                    <i class="fa fa-file-zip-o text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Pr&eacute;paiement (DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('_integrations_offline')" >
                                    <i class="fa fa-share-square-o text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Int&eacute;gration manuelle</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('_bulletins')" >
                                    <i class="fa fa-server text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Lot des bulletins (DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('_recover')" >
                                    <i class="fa fa-server text-aqua f30"></i><br/>
                                    <span class="f12 text-black">Recup&eacute;ration des paiements (DGDA)</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <?php if (!empty($alerts)) : ?>
                        <div>
                            <?php foreach ($alerts as $row) :
                                   $bl_info = json_decode($row->Bulletin_9);
                               ?>
                                <div class="timeline-item">
                                    <div class="row">
                                        <div class="col-xs-4 date">
                                            <i class="fa fa-file-text"></i>
                                            <?php
                                               $s = $row->Date_1;
                                               $dt = new DateTime($s);

                                               $date = $dt->format('d-m-Y');
                                               $time = $dt->format('h:i:s');

                                               echo $time;
                                               ?>
                                            <br />
                                            <small class="text-navy">
                                                <?php
                                                   $now = gmdate('Y-m-d H:i:s');

                                                   $current_date_time_sec = strtotime($row->Date_1);
                                                   $future_date_time_sec = strtotime($now);

                                                   $difference = $future_date_time_sec - $current_date_time_sec;

                                                   $seconds = ($difference % 60);
                                                   $seconds = (int)$seconds;

                                                   $minutes = ($difference / 60 % 60);
                                                   $minutes = (int)$minutes;

                                                   $hours = ($difference / 3600);
                                                   $hours = (int)$hours;

                                                   $days = ($hours / 24);
                                                   $days = (int)$days;

                                                   if ($minutes < 1) :
                                                       if ($seconds == 1) echo "Il y a " . $seconds . " seconde";
                                                       else echo "Il y a " . $seconds . " secondes";
                                                   elseif ($hours < 1) :
                                                       if ($minutes == 1) echo "Il y a " . $minutes . " minute";
                                                       else echo "Il y a " . $minutes . " minutes";
                                                   elseif ($days < 1) :
                                                       if ($hours == 1) echo "Il y a " . $hours . " heure";
                                                       else echo "Il y a " . $hours . " heures";
                                                   else :
                                                       if ($days == 1) echo "Il y a " . $days . " jour";
                                                       else echo "Il y a " . $days . " jours";
                                                   endif;
                                                   ?>

                                            </small>
                                            <?php if ($row->Lock_12 == 0) : ?>
                                                <div>
                                                    <?php if ($row->Type_13 == 'batch') : ?>
                                                        <span><a class="cursor-pointer" onclick="edit_alert_batch(<?php echo $row->Paiementid_11; ?>)"><i class="fa fa-edit font-action-edit text-blue f18"></i></a></span>
                                                    <?php else : ?>
                                                        <span><a class="cursor-pointer" onclick="edit_alert(<?php echo $row->Id_0; ?>)"><i class="fa fa-edit font-action-edit text-blue f18"></i></a></span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else : ?>
                                                <?php if ($row->Lock_12 == $user_id) : ?>
                                                    <div>
                                                        <?php if ($row->Type_13 == 'batch') : ?>
                                                            <span><a class="cursor-pointer" onclick="edit_alert_batch(<?php echo $row->Paiementid_11; ?>)"><i class="fa fa-edit font-action-edit text-blue f18"></i></a></span>
                                                        <?php else : ?>
                                                            <span><a class="cursor-pointer" onclick="edit_alert(<?php echo $row->Id_0; ?>)"><i class="fa fa-edit font-action-edit text-blue f18"></i></a></span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php else : ?>
                                                    <div>
                                                        <span><a class="cursor-pointer" onclick="" href="#"><i class="fa fa-lock font-action-edit text-yellow f18"></i></a></span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-xs-6">
                                            <?php if ($row->Type_13 == 'batch') : ?>
                                                <p class="m-b-xs"><strong>Bulletin en lot</strong></p>
                                                <p><?php echo $row->Message_7; ?></p>
                                            <?php else : ?>
                                                <p class="m-b-xs"><strong>Paiement BL <?php echo isset($bl_info->serial) ? $bl_info->serial . '' . $bl_info->number : ""; ?></strong></p>
                                                <p><?php echo $row->Message_7; ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <div>
                            <span class='text-gray f16 '>Aucune alerte trouv&eacute;e !<br /><br /></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-blue f25" ><?php echo " Rapports..."; ?></h2>
                    <p class="page-header"></p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 bRight">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('unvalidated')" >
                                    <i class="fa fa-sticky-note-o text-aqua f30"></i><br />
                                   <span class="f12 text-black">Paiements non valid&eacute;s</span>
                                </a>
                            </div>
                        </div>
                       <div class="col-md-4 col-sm-4 col-xs-4">
                           <div class="appsbox box no-border">
                                <a onclick="action('validated')" >
                                    <i class="fa fa-sticky-note  text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Paiements valid&eacute;s</span>
                                </a>
                           </div>
                       </div>
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('reversed')" >
                                    <i class="fa fa-share-square-o text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Paiements revers&eacute;s</span>
                                </a>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('paiements_rbo')" >
                                    <i class="fa fa-list-alt text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Paiements (RBO)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('paiement_tresor')" >
                                    <i class="fa fa-list-alt  text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Guichet unique douane (Tresor)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('paiement_propre')" >
                                    <i class="fa fa-list-ul  text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Guichet unique (Hors Tresor)</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('fond_propre')" >
                                    <i class="fa fa-list fa-newspaper-o  text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Fonds propres (DGI & DGRAD)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="message_up()" >
                                    <i class="fa fa-list-alt text-aqua   f30"></i><br />
                                    <span class="f12 text-black">Bulletins comptant(DGDA)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('prepayments')" >
                                    <i class="fa fa-list-ul text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Pr&eacute;paiments (DGDA)</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="message_up()" >
                                    <i class="fa fa-files-o text-aqua f30"></i><br />
                                    <span class="f12 text-black">D&eacute;claration Licence BCC</span>
                                </a>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('_integrations')" >
                                    <i class="fa fa-list-alt text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Int&eacute;grations manuelles</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('regularisation')" >
                                    <i class="fa fa-refresh text-aqua  f30"></i><br />
                                    <span class="f12 text-black">R&eacute;gularisations</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('reversement')" >
                                    <i class="fa fa-server text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Reversements ISYS</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('rbo_verification')" >
                                    <i class="fa fa-list fa-sticky-note-o  text-aqua  f30"></i><br />
                                    <span class="f12 text-black">Paiements à contrev&eacute;rifier (RBO)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4 ">
                            <div class="appsbox box no-border">
                                <a onclick="action('rbo_rejected')" >
                                    <i class="fa fa-list fa-upload  text-aqua   f30"></i><br />
                                    <span class="f12 text-black">Paiements rejet&eacute;s (RBO)</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('rbo_comptant')" >
                                     <i class="fa fa-sticky-note  text-aqua  f30"></i><br />
                                     <span class="f12 text-black">Paiments comptabilis&eacute;s (RBO)</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="appsbox box no-border">
                                <a onclick="action('others_banks_taxes')" >
                                     <i class="fa fa-superpowers  text-aqua  f30"></i><br />
                                     <span class="f12 text-black">Taxes autres banques</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                </div>

                <div class="col-md-4">
                    <ul class="nav nav-pills nav-stacked">
                        <li id=''><a onclick="action('_taux')" class="text-blue f12"><i class="fa fa-plus-circle"></i> Changer les taux de change</a></li>
                        <li id=''><a onclick="action('sydonia')" class="text-blue f12"><i class="fa fa-cogs"></i> Configuration acces SYDONIA</a></li>
                        <li id=''><a onclick="message()" class=" f12"><i class="fa fa-credit-card-alt"></i> Approvisionnement compte pr&eacute;paiement</a></li>
                        <li id=''><a onclick="message()" class=" f12"><i class="fa fa-file-excel-o"></i> Extraction licence BCC</a></li>
                    </ul>
                    <ul class="nav nav-pills nav-stacked">
                        <li id=''><a onclick="action('situation_dgi')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re (DGI)</a></li>
                        <li id=''><a onclick="action('situation_dgrad')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re (DGRAD)</a></li>
                        <li id=''><a onclick="action('situation_dgda')" class="text-blue f12"><i class="fa fa-minus"></i> Situation journali&egrave;re guichet unique (DGDA)</a></li>
                        <li id=''><a onclick="" class=" f12"><i class="fa fa-minus"></i> Situation journali&egrave;re de pr&eacute;paiement (DGDA)</a></li>
                        <li id=''><a onclick="action('unknown_status')" class="text-blue f12"><i class="fa fa-minus"></i> Historique des des transactions avec statut inconnu (DGDA)</a></li>
                        <li id=''><a onclick="action('failed_transactions')" class="text-blue f12"><i class="fa fa-minus"></i> Historique des transactions non int&eacute;gr&eacute;es (DGDA)</a></li>
                        <li id=''><a onclick="action('regularisations')" class="text-blue f12"><i class="fa fa-minus"></i> Historique des regularisations</a></li>
                        <li id=''><a onclick="action('taux')" class="text-blue f12"><i class="fa fa-minus"></i> Historique de taux de change</a></li>
                    </ul>
                </div>
            </div>
            <br>
        </div>
    </div>

    <div class="col-md-1 content" id="cancel">
        <a href="<?php echo base_url('/main/overview'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content d-none" id="close">
        <a href="" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>

    <div class="col-md-1 content d-none" id="form_paiement">
        <a href="" class="btn btn-app no-border pull_left" id="close_paymentunique"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content d-none" id="form_unvalidated">
        <a href="" class="btn btn-app no-border pull_left" id="close_unvalidated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content d-none" id="form_validated">
        <a href="" class="btn btn-app no-border pull_left" id="close_validated"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content d-none" id="form_order">
        <a href="" class="btn btn-app no-border pull_left" id="close_order"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    <div class="col-md-1 content d-none" id="form_orders">
        <a href="" class="btn btn-app no-border pull_left" id="close_orders"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

 <script type="text/javascript">
     $("#close_unvalidated").click(function() {
         $.get("<?php echo base_url($module . '/bank/display/nvalidated'); ?>", function(data, status) {
             $("#loader").html('');
             $("#pager").html(data);
             $("#pager").addClass('content');
             $("#form_unvalidated").addClass('d-none');
             $("#close").removeClass('d-none');

         });
     });

     $("#close_paymentunique").click(function() {
         $.get("<?php echo base_url($module . '/bank/display/gudouane'); ?>", function(data, status) {
             $("#loader").html('');
             $("#pager").html(data);
             $("#pager").addClass('content');
             $("#form_paiement").addClass('d-none');
             $("#close").removeClass('d-none');

         });
     });

     $("#close_validated").click(function() {
         $.get("<?php echo base_url($module . '/bank/display/validated'); ?>", function(data, status) {
             $("#loader").html('');
             $("#pager").html(data);
             $("#pager").addClass('content');
             $("#form_validated").addClass('d-none');
             $("#close").removeClass('d-none');
         });
     });

     $("#close_order").click(function() {
         $.get("<?php echo base_url($module . '/bank/display/ordres/new'); ?>", function(data, status) {
             $("#loader").html('');
             $("#pager").html(data);
             $("#pager").addClass('content');
             $("#form_order").addClass('d-none');
             $("#close").removeClass('d-none');
         });
     });

     $("#close_orders").click(function() {
         $.get("<?php echo base_url($module . '/bank/display/ordres'); ?>", function(data, status) {
             $("#loader").html('');
             $("#pager").html(data);
             $("#pager").addClass('content');
             $("#form_orders").addClass('d-none');
             $("#close").removeClass('d-none');
         });
     });

     $("#pager").on("click", "#buttonCloseModal1", function() {
         var from = $('#from').val();

         if (from == "validated") {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             var url = '<?php echo base_url($module . '/bank'); ?>/display/validated';
             $.get(url, function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#form_validated").addClass('d-none');
                 $("#close").removeClass('d-none');
             });

         } else if (from == "payement_unique") {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             var url = '<?php echo base_url($module . '/bank'); ?>/display/gudouane';
             $.get(url, function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#form_paiement").addClass('d-none');
                 $("#close").removeClass('d-none');
             });
         }
         

     });

     $("#pager").on("click", "#buttonCloseOrdre", function() {

         var from = $('#from').val();

         if (from == "new") {
             $.get("<?php echo base_url($module . '/bank/display/ordres/new'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#form_order").addClass('d-none');
                 $("#close").removeClass('d-none');
             });
         } else {
             $.get("<?php echo base_url($module . '/bank/display/ordres'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#form_orders").addClass('d-none');
                 $("#close").removeClass('d-none');
             });
         }

     });

     $("#container").on("click", "#buttonCloseModal", function() {
         location.reload();
     });

     function action(which) {

         $("#alert").html('');

         if (which === 'declaration') {
             $("#loader").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
                 //$("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === 'note_perception') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxnotes/display/start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === 'bulletin') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxbulletin/display/start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === 'situation_dgda') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/situation_dgda'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === 'situation_dgi') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/situation_dgi'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === 'situation_dgrad') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/situation_dgrad'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === '_taux') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxrates/display/taux'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }

         if (which === '_other') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxothers/display/start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }

         if (which === '_accise') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }

         if (which === '_creditpaiement') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }

         if (which === '_order') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/bank/display/ordres/new'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'unvalidated') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/nvalidated'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'validated') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/pending'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'reversed') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/transferred'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'reversement') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/validated'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'paiement_propre') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/paiement_propre'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'paiements_dgda') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/paiements_gu'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }

         if (which === 'paiement_tresor') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/paiement_tresor'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'fond_propre') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/fond_propre'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'taux') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxrates/display/list'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'orders') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/bank/display/ordres'); ?>", function(data, status) {

                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');

             });
         }

         if (which === '_bulletins') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === '_recover') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxbulletin/display/batch_recover_start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === '_prepaymentList') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxprepayments/display/start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#container").html(data);
             });
         }
         if (which === '_prepayment') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxprepayments/display/procurement'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === '_declaration') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/licence/display/start'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'prepayments') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/prepayments'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'declarations') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/declarationslist'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'sydonia') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxusers/display/accountsydonia'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === '_integrations_offline') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxoffline/display/paiements'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === '_integrations') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxoffline/display/integrations'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'regularisation') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxequalize/display/unequalized'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'failed_transactions') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/failed_transactions'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'unknown_status') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/unknown_status_transactions'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'regularisations') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/regularisations'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'paiements_rbo') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url('branch/taxreports/display/paiements_rbo'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'rbo_verification') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url('branch/taxreports/display/rbo_verification'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'rbo_rejected') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url('branch/taxreports/display/rbo_rejected'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'rbo_treat') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/rbo_treat'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'rbo_comptant') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url('branch/taxreports/display/rbo_comptant'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'others_banks_taxes') {
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
             $.get("<?php echo base_url($module . '/taxreports/display/others_banks_taxes'); ?>", function(data, status) {
                 $("#loader").html('');
                 $("#pager").html(data);
                 $("#pager").addClass('content');
                 $("#close").removeClass('d-none');
                 $("#cancel").addClass('d-none');
                 $("#col").removeClass('col-md-2');
                 $("#col").addClass('col-md-1');
                 $("#content").removeClass('col-md-8');
                 $("#content").addClass('col-md-10');
                 $("#close").removeClass('col-md-2');
                 $("#close").addClass('col-md-1');
             });
         }
         if (which === 'isys') {

         }
     }

     function edit_alert(id) {
         $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

         var url = '<?php echo base_url('branch/taxbulletin/display/step_1_process'); ?>/' + id;

         $.get(url, function(data, status) {

             if (data == '0') {
                 $("#loader").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
             } else {
                 $("#loader").html('');
                 $("#container").html(data);
             }
         });
     }

     function edit_alert_batch(id) {
         $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');

         var url = '<?php echo base_url('branch/taxbulletin/display/batch_step_1_process'); ?>/' + id;

         $.get(url, function(data, status) {

             if (data == '0') {
                 $("#loader").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
             } else {
                 $("#loader").html('');
                 $("#pager").addClass('content');
                 $("#pager").html(data);
             }
         });
     }

     function message() {
         $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Ce menu n\'est pas encore disponible, veuillez contacter votre administrateur.</div>');
     }

     function message_up() {
         scrollUP();
         $("#alert").html('<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Ce menu n\'est pas encore disponible, veuillez contacter votre administrateur.</div>');
     }

     function scrollUP() {
         $('html, body').animate({
             scrollTop: $("#loader").offset().top
         }, 20);
     }
 </script>