<div class="row">
            <div class="col-md-12">
                    <div class="row">
                            <div class="col-md-12 ">
                                    <h2 class="f30 text-blue">Validation des paiements</h2>
                                    <p class="page-header"><span class="f12 text-black">Cette vue vous permet de sélectionner le type des paiements à valider.</span></p>     
                            </div>
                    </div>
                    <div class="row">
                            <div class="col-md-12 p-0">
                                    <div class="col-md-12 p-0">
                                            <div id="loader-sub-menu"></div><br/>
                                     </div>
                                    <div class="box-body">
                                            <?php $chtml->box_body_opening("", true);?>
                                            <div class="row">
                                                    <div class="col-md-12">
                                                            <div class="form-group">
                                                                    <label for="type" class="f12 text-black">Selectionner le type de paiement</label>
                                                                    <?php echo form_dropdown('type', array(''=>'', 'DGI'=>array('declaration'=>'Déclaration', 'amr-a'=>'Déclaration AMR-A', 'amr-b'=>'Déclaration AMR-B', 'plaque'=>'Vente de plaques d\'immatriculation'), 'DGRAD'=>array('note_perception'=>'Note de perception', 'gardienage'=>'Taxe de gardienage'), 'DGDA'=>array('bulletin'=>'Bulletin de liquidation', 'batch'=>'Lot des bulletins', 'recover'=>'Récupération des paiements', 'other'=>'Autres paiements', 'prepayment'=>'Bulletin des prépaiements')), "", 'class="form-control default-width" id="type" '); ?>
                                                            </div>
                                                    </div>
                                            </div>
                                            <?php $chtml->box_body_closing(); ?>


                                            <div class="col-md-12 p-0" id="sub-menu">
                                                    <section id="cat_list" class="text-center marginTop150">
                                                            <span class="d-block p-2 "><span class="fa fa-language text-navy mystyle4" ></span></br>
                                                            <span class="d-block p-2 f12 text-black">Aucun type de paiement sélectionné. Veuillez en choisir un pour procéder au traitement de paiements des taxes.</span>
                                                    </section>
                                            </div>

                                    </div>
                            </div>
                    </div>
        </div>
</div>

<script type="text/javascript">
    
    $('#type').change(function(){
        var type = $('#type option:selected').val();
        
        if(type != '')
        {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            action(type);
        }
    });
    
    
    function action(which) {
        
         if (which === 'declaration') {
            $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'amr-b') {
            $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'amr-a') {
            $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'plaque') {
            $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'note_perception') {
            $.get("<?php echo base_url($module . '/taxnotes/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'gardienage') {
            $.get("<?php echo base_url($module . '/taxnotes/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'bulletin') {
            $.get("<?php echo base_url($module . '/taxbulletin/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'situation_dgda') {
            $.get("<?php echo base_url($module . '/taxreports/display/situation_dgda'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'situation_dgi') {
            $.get("<?php echo base_url($module . '/taxreports/display/situation_dgi'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'situation_dgrad') {
            $.get("<?php echo base_url($module . '/taxreports/display/situation_dgrad'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === '_taux') {
            $.get("<?php echo base_url($module . '/taxrates/display/taux'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === 'other') {
            $.get("<?php echo base_url($module . '/taxothers/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === '_accise') {
            $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === '_creditpaiement') {
            $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === '_order') {
            $.get("<?php echo base_url($module . '/bank/display/ordres/new'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'unvalidated') {
            $.get("<?php echo base_url($module . '/taxreports/display/nvalidated'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'validated') {
            $.get("<?php echo base_url($module . '/taxreports/display/pending'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'reversed') {
            $.get("<?php echo base_url($module . '/taxreports/display/transferred'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'reversement') {
            $.get("<?php echo base_url($module . '/taxreports/display/validated'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'paiement_propre') {
            $.get("<?php echo base_url($module . '/taxreports/display/paiement_propre'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'paiements_dgda') {
            $.get("<?php echo base_url($module . '/taxreports/display/paiements_gu'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === 'paiement_tresor') {
            $.get("<?php echo base_url($module . '/taxreports/display/paiement_tresor'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'fond_propre') {
            $.get("<?php echo base_url($module . '/taxreports/display/fond_propre'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'taux') {
            $.get("<?php echo base_url($module . '/taxrates/display/list'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'orders') {
            $.get("<?php echo base_url($module . '/bank/display/ordres'); ?>", function(data, status) {

                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);

            });
         }

         if (which === 'batch') {
            $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'recover') {
            $.get("<?php echo base_url($module . '/taxbulletin/display/batch_recover_start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#container").html(data);
            });
         }
         if (which === 'prepayment') {
            $.get("<?php echo base_url($module . '/taxprepayments/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#container").html(data);
            });
         }
         if (which === '_declaration') {
            $.get("<?php echo base_url($module . '/licence/display/start'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'prepayments') {
            $.get("<?php echo base_url($module . '/taxreports/display/prepayments'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'declarations') {
            $.get("<?php echo base_url($module . '/taxreports/display/declarationslist'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'sydonia') {
            $.get("<?php echo base_url($module . '/taxusers/display/accountsydonia'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === '_integrations_offline') {
            $.get("<?php echo base_url($module . '/taxoffline/display/paiements'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === '_integrations') {
            $.get("<?php echo base_url($module . '/taxoffline/display/integrations'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'regularisation') {
            $.get("<?php echo base_url($module . '/taxequalize/display/unequalized'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'failed_transactions') {
            $.get("<?php echo base_url($module . '/taxreports/display/failed_transactions'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'unknown_status') {
            $.get("<?php echo base_url($module . '/taxreports/display/unknown_status_transactions'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'regularisations') {
            $.get("<?php echo base_url($module . '/taxreports/display/regularisations'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'paiements_rbo') {
            $.get("<?php echo base_url('branch/taxreports/display/paiements_rbo'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'rbo_verification') {
            $.get("<?php echo base_url('branch/taxreports/display/rbo_verification'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'rbo_rejected') {
            $.get("<?php echo base_url('branch/taxreports/display/rbo_rejected'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'rbo_treat') {
            $.get("<?php echo base_url($module . '/taxreports/display/rbo_treat'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'rbo_comptant') {
            $.get("<?php echo base_url('branch/taxreports/display/rbo_comptant'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'others_banks_taxes') {
            $.get("<?php echo base_url($module . '/taxreports/display/others_banks_taxes'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
     }
    

</script>