<?php
        if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0) 
        {
                $bank = json_decode($_SESSION['Bank_rates'], true);
                $usd = $bank['Dollar_4'];
                $eur = $bank['Euro_5'];
                $rand = $bank['Rand_6'];
                $pound = $bank['Pound_7'];
        } 
        else 
        {
                $usd = $eur = $rand = $pound = 0.0;
        }
        
        $modules = isset($_SESSION['userdata']['modules']) ? json_decode($_SESSION['userdata']['modules'], true) : '';

?>

<div class="row">
        <div class="col-md-1 text-center">
            
        </div>

        <div class="col-md-10 content">
                <div id="loader"></div>
                <div class="row">
                        <div class="col-md-12 no-padding">
                            <div class="col-md-12 f24 text-black">
                                    <h1>Bo&icirc;te à Outils <b>iKwook Logiref</b></h1>
                                    <p class="page-header">Solutions logicielles intelligentes pour l'automatisation du traitement des paiements</p>
                            </div>
                        </div>

                        <div class="col-md-12">
                                <div class="row">
                                        <div class="col-sm-8">
                                                <div class="col-md-12">
                                                        <h1 class="m-b-xs text-blue">
                                                                <b>CDF <?= number_format($usd,2,","," "); ?></b>
                                                        </h1>
                                                        <small class="m-b-xs text-blue">1 USD</small>
                                                        <div id="sparkline1" class="m-b-sm"><canvas style="display: inline-block; width: 353.333px; height: 50px; vertical-align: top;" width="353" height="50"></canvas></div>
                                                </div>
                                                <div class="col-md-12">
                                                        <div class="row">
                                                                <div class="col-md-4 text-orange">
                                                                        <small class="stats-label">1 EUR</small>
                                                                        <h4>CDF <?= number_format($eur,4,","," ") ?></h4>
                                                                </div>
                                                                <div class="col-md-4 text-red">
                                                                        <small class="stats-label">1 POUND</small>
                                                                        <h4>CDF <?= number_format($pound,4,","," ") ?></h4>
                                                                </div>
                                                                <div class="col-md-4 text-black">
                                                                        <small class="stats-label">1 RAND</small>
                                                                        <h4>CDF <?= number_format($rand,4,","," ") ?></h4>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                        
                                        <div class="col-sm-4">
                                                <div class="row m-t-xs">
                                                        <div class="col-md-12">
                                                                <h5 class="m-b-xs">Bienvenue !</h5>
                                                                <h1 class="no-margins"><?php echo $session->userdata['user_fname'] .' '. $session->userdata['user_sname']; ?></h1>
                                                                <div class="font-bold text-navy">Account ID: <?php echo $session->userdata['account_id']; ?> <i class="fa fa-bolt"></i> Dernière connexion: *VAR</div>
                                                        </div>
                                                </div>
                                                <table class="table small m-t-sm">
                                                        <tbody>
                                                                <tr>
                                                                        <td>Banque</td>
                                                                        <td><strong>: <?php echo $session->userdata['account_business']; ?></strong></td>
                                                                </tr>
                                                                <tr>
                                                                        <td>Agence</td>
                                                                        <td><strong>: *VAR</strong></td>
                                                                </tr>
                                                                <tr>
                                                                        <td>Guichet</td>
                                                                        <td><strong>: *VAR</strong></td>
                                                                </tr>
                                                                <tr>
                                                                        <td>Profil</td>
                                                                        <td><strong>: *VAR</strong></td>
                                                                </tr>
                                                        </tbody>
                                                </table>
                                        </div>
                                </div>
                        </div>

                        <div class="col-md-12 no-padding">
                                <div class="col-md-12 f24 text-blue">
                                        <p class="page-header"></p>
                                        <h3>Outils disponibles pour la <b><?php echo $session->userdata['account_business']; ?></b></h3>
                                        <p class="page-header">Les solutions visant à simplifier divers traitements de paiement sont centralisées et intégrées.</p>
                                </div>
                        </div>

                </div>
     
                <div class="row">
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('branch/taxdashboards/set/etax'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">e-Tax</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-calculator"></i> Impôts & Taxes
                                                        </h2>
                                                        <small>Encaissement impôts et taxes </small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                        
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('eximtrade/eximtradedashboards/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Eximtrade</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-plane"></i> Seguce, OCC & BIVAC
                                                        </h2>
                                                        <small>Encaissement factures export et import </small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                        
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('elicense/elicensedashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">e-License</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-calendar"></i> IB, EB, IS, ES & RC
                                                        </h2>
                                                        <small>Suivi des souscriptions et licences</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                        
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('2ibanking/eximtradedashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Internet banking</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-desktop"></i> Banque en ligne
                                                        </h2>
                                                        <small>Suivi des paiements en ligne</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                        
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('etoll/etolldashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">e-Toll + e-tickets</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-taxi"></i> Points de ventes
                                                        </h2>
                                                        <small>Gestion des points (péages, tickets, etc.)</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                    
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('qleads/qleadsdashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Qleads</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-users"></i> Files d'attente
                                                        </h2>
                                                        <small>Suivi de la clientèle et perfomance</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                    
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('iabanking/abankingdashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Agency Banking</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-globe"></i> Agents bancaires
                                                        </h2>
                                                        <small>Suivi et gestion des agents bancaires</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                    
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('debitorders/abankingdashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Debit Orders</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-eercast"></i> Ordres de débit
                                                        </h2>
                                                        <small>Automatisation des ordres de paiements</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                    
                        <div class="col col-lg-4 mb-4">
                                <div class="card text-center cursor-pointer">
                                        <div class="card-body">
                                                <a href="<?php echo base_url('iabanking/etolldashboard/set/menus'); ?>" class="text-blue">
                                                        <h5 class="m-b-md">Subscriptions</h5>
                                                        <h2 class="text-navy">
                                                                <i class="fa fa fa-address-card-o"></i> Abonnements
                                                        </h2>
                                                        <small>Traitement des cotisations, abonnements ou souscriptions</small>
                                                </a>
                                        </div>
                                </div>
                        </div>
                    
                    
                    <?php if(array_key_exists('e-toll', $modules)): ?>
                    
                    <?php endif; ?>
                    
                </div>
                
                <div class="row">
                        <div class="col-md-12 f24 text-black text-center">
                                <p class="page-header"></p>
                                <p class="page-header">&copy; Powered by iKwook Express Sarl.</p>
                        </div>
                </div>
        </div>
</div>


<!-- Sparkline -->
<script src="<?= base_url('ikwook_bootstraps/inspinia/js/plugins/sparkline/jquery.sparkline.min.js') ?>"></script>
    
<script>
        $(document).ready(function(){
            
            var sparklineCharts = function(){
                    $("#sparkline1").sparkline([34, 43, 43, 35, 44, 32, 44, 52], {
                            type: 'line',
                            width: '100%',
                            height: '50',
                            lineColor: '#1ab394',
                            fillColor: "transparent"
                    });

                    $("#sparkline2").sparkline([32, 11, 25, 37, 41, 32, 34, 42], {
                            type: 'line',
                            width: '100%',
                            height: '50',
                            lineColor: '#1ab394',
                            fillColor: "transparent"
                    });

                    $("#sparkline3").sparkline([34, 22, 24, 41, 10, 18, 16,8], {
                            type: 'line',
                            width: '100%',
                            height: '50',
                            lineColor: '#1C84C6',
                            fillColor: "transparent"
                    });
            };

            var sparkResize;

            $(window).resize(function(e) {
                    clearTimeout(sparkResize);
                    sparkResize = setTimeout(sparklineCharts, 500);
            });

            sparklineCharts();
            
        });
</script>