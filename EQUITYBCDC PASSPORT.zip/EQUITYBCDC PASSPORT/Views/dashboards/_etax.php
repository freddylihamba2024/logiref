<div class="row">
        <div class="col-md-12">
                <div class="row" id="general_block">
                    <div class="col-md-12">
                        <h2 class="f30 text-blue" id="title">Paiements des taxes</h2>
                        <p class="page-header"><span class="f12 text-black" id="sub-title">Cette vue vous permet de sélectionner le type des paiements à traiter.</span></p>     
                    </div>
                </div>
                <div class="row d-none" id="prepayment_block">
                    <div class="col-md-12 p-0">
                        <div class="row page-header">
                            <div class="col-md-6 p-0">
                                <div class="col-md-12">
                                    <h2 class="f30 text-blue" id="title-prepayment">Paiements des taxes</h2>
                                    <p class=""><span class="f12 text-black" id="sub-title-prepayment">Cette vue vous permet de sélectionner le type des paiements à traiter.</span></p>     
                                </div>
                            </div>
                            <div class="col-md-6">

                                <div class="statistic-box m-2">
                                    <?php echo form_open('', array('id' => 'extractform', 'class' => 'innovate')); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="pull-right">
                                                <input type="hidden" name="facture" value="" id ="facture">
                                                <button id="extract" type="submit" class="btn btn-primary pull-left page-header"><i class="fa fa-download"></i>&nbsp;&nbsp;Réextraire&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                                <button type="button" id="historique" class="btn btn-warning page-header" onclick="historique('')" ><i class=" fa fa-archive"></i> Historique</button> &nbsp;&nbsp;
                                                <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle" type="button">Filtrage Groupé&nbsp;&nbsp;</button>
                                                <ul class="dropdown-menu">
                                                    <li><a onclick="filter('customer')">Client</a></li>
                                                    <div class="dropdown-divider"></div>
                                                    <li><a onclick="filter('office')">Bureau</a></li>
                                                    <div class="dropdown-divider"></div>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="row">
                    <div class="col-md-12">-->
                        <div id="loader-sub-menu"></div><br/>
                    <!--</div>
                </div>
                <div class="row">-->
                        <div class="col-md-12 p-0" id="sub-menu">
                                <div class="col-md-12 p-0">
                                        <div class="box-body p-0">
                                                <?php $chtml->box_body_opening("", true);?>
                                                <div class="row">
                                                        <div class="col-md-12">
                                                                <div class="form-group">
                                                                        <label for="type" class="f12 text-black">Selectionner le type de paiement</label>
                                                                        <?php echo form_dropdown('type', $menus, "", 'class="form-control default-width" id="type" '); ?>
                                                                </div>
                                                        </div>
                                                </div>
                                                <?php $chtml->box_body_closing(); ?>

                                                <section id="cat_list" class="text-center marginTop150">
                                                        <img  height="100px" width="100px" src="<?php echo base_url('ikwook_files/images/Choisir noir.png'); ?>"/>
                                                        <span class="d-block p-2 f12 text-black">Aucun type de paiement sélectionné. Veuillez en choisir un pour procéder au traitement de paiements des taxes.</span>
                                                </section>
                                        </div>
                                </div>
                        </div>
                <!--</div>-->
        </div>
</div>

<script type="text/javascript">

    $('#type').change(function(){
        var type = $('#type option:selected').val();

        if(type != '')
        {
            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            action(type);
        }
    });


    function action(which) {

        //$('#sub-menu').removeClass('p-0');

        if (which === 'DGRK') {
           $.get("<?php echo base_url($module . '/taxdgrk/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Note de perception (DGRK)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'DGPEK') {
           $.get("<?php echo base_url($module . '/taxdgpek/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Note de perception (DGPEK)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'declaration') {
           $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('D&eacute;claration (DGI)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une déclaration.');
           });
        }
        if (which === 'inv') {
           $.get("<?php echo base_url($module . '/taximmatriculation/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('D&eacute;claration (DGI)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une plaque d\'immatriculation.');
           });
        }
        if (which === 'inv2') {
           $.get("<?php echo base_url('inv/immatriculation/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('D&eacute;claration (DGI)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une plaque d\'immatriculation.');
           });
        }
        if (which === 'amr') {
           $.get("<?php echo base_url($module . '/taxdeclaration/display/start_amr'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('D&eacute;claration (DGI)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une déclaration.');
           });
        }
        if (which === 'plaque') {
           $.get("<?php echo base_url($module . '/taxdeclaration/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('D&eacute;claration (DGI)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une déclaration.');
           });
        }
        if (which === 'note_perception') {
           $.get("<?php echo base_url($module . '/taxnotes/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Note de perception (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'batch_notes') {
           $.get("<?php echo base_url($module . '/taxnotes/display/batch_start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Note de perception (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un lot des notes de perception.');
           });
        }
        if (which === 'note_passeport') {
           $.get("<?php echo base_url($module . '/taxpasseport/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Paiement des passeports (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'passport') {
           $.get("<?php echo base_url('passeport/passeport/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Paiement des passeports (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'note_permis') {
           $.get("<?php echo base_url($module . '/taxpermis/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Paiement permis de conduire (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'gardienage') {
           $.get("<?php echo base_url($module . '/taxnotes/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Note de perception (DGRAD)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'une note de perception.');
           });
        }
        if (which === 'bulletin') {
           $.get("<?php echo base_url($module . '/taxbulletin/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Bulletin de liquidation (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un bulletin de liquidation.');
           });
        }
        if (which === 'other') {
           $.get("<?php echo base_url($module . '/taxothers/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Autres paiements (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un bulletin de liquidation.');
           });
        }
        if (which === '_accise') {
           $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Droits d\'accise (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un bulletin de liquidation.');
           });
        }
        if (which === '_creditpaiement') {
           $.get("<?php echo base_url($module . '/bank/display/comptant'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Bulletin crédit (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un bulletin de liquidation.');
           });
        }
        if (which === 'batch') {
           $.get("<?php echo base_url($module . '/taxbulletin/display/batch_start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               
               $("#sub-menu").html(data);
               $("#title").html('Bulletin de liquidation (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet d\'effectuer le paiement d\'un bulletin de liquidation.');
           });
        }
        if (which === 'recover') {
           $.get("<?php echo base_url($module . '/taxbulletin/display/batch_recover_start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
               $("#title").html('Récupération des paiements (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet de récupérer les bulletins déjà payé.');
           });
        }
        if (which === 'prepayment') {
           $.get("<?php echo base_url($module . '/taxprepayments/display/start'); ?>", function(data, status) {

               $("#loader-sub-menu").html('');
               $("#general_block").addClass('d-none');
               $("#prepayment_block").removeClass('d-none');
               $("#sub-menu").html(data);
               $("#title").html('Bulletin des prépaiements (DGDA)');
               $("#sub-title").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
               $("#title-prepayment").html('Bulletin des prépaiements (DGDA)');
               $("#sub-title-prepayment").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
           });
        }
        if (which === '_declaration') {
           $.get("<?php echo base_url($module . '/licence/display/start'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'prepayments') {
           $.get("<?php echo base_url($module . '/taxreports/display/prepayments'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'regularisations') {
           $.get("<?php echo base_url($module . '/taxreports/display/regularisations'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
        if (which === 'others_banks_taxes') {
           $.get("<?php echo base_url($module . '/taxreports/display/others_banks_taxes'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
    }

</script>