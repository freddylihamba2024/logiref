    <?php
        if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0) {
            $bank = json_decode($_SESSION['Bank_rates'], true);
            $usd = $bank['Dollar_4'];
            $eur = $bank['Euro_5'];
            $rand = $bank['Rand_6'];
            $pound = $bank['Pound_7'];
        }
        else {
            $usd = $eur = $rand = $pound = 0.0;
        }
    ?>
    <div class="row">
        <div class="col-md-9">

            <div class="row">
                <div class="col-md-4">
                    <div class="ibox">
                        <div class="ibox-title bg-light">
                            <h5>DGDA</h5>
                        </div>
                        <div class="ibox-content">
                            <h4 class="no-margins"><?= number_format($stats['paiement_DGDA'],2,","," "). " CDF" ?></h4>
                            <small class="text-success">(Paiements)</small>
                            <h5 class="mt-3">Commissions : <?= number_format($stats['commission_DGDA'],2,","," "). " CDF" ?></h5>
                            <h5 class="">
                                <span class="text-info">TVA</span> : <?= number_format($stats['tva_DGDA'],2,","," "). " CDF" ?>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="ibox ">
                        <div class="ibox-title bg-light">
                            <h5>DGI</h5>
                        </div>
                        <div class="ibox-content">
                            <h4 class="no-margins"><?= number_format($stats['paiement_DGI'],2,","," "). " CDF" ?></h4>
                            <small class="text-success">(Paiements)</small>
                            <h5 class="mt-3">Commissions : <?= number_format($stats['commission_DGI'],2,","," "). " CDF" ?></h5>
                            <h5 class="">
                                <span class="text-info">TVA</span> : <?= number_format($stats['tva_DGI'],2,","," "). " CDF" ?>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="ibox ">
                        <div class="ibox-title bg-light">
                            <h5>DGRAD</h5>
                        </div>
                        <div class="ibox-content">
                            <h4 class="no-margins"><?= number_format($stats['paiement_DGRAD'],2,","," "). " CDF" ?></h4>
                            <small class="text-success">(Paiements)</small>
                            <h5 class="mt-3">Commissions : <?= number_format($stats['commission_DGRAD'],2,","," "). " CDF" ?></h5>
                            <h5 class="">
                                <span class="text-info">TVA</span> : <?= number_format($stats['tva_DGRAD'],2,","," "). " CDF" ?>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                if (!empty($operators)) :
            ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table id="table" class="table table-striped" width="100%">
                                    <tbody>
                                        <tr>
                                            <th>#</th>
                                            <th>Opérateurs</th>
                                            <th>Guichets</th>
                                            <th>Paiements</th>
                                            <th>Commissions</th>
                                            <th>TVA</th>
                                            <th>Date</th>
                                            <!--<td><a href=""><i class="fa fa-pencil text-muted"></i></a></td>-->
                                        </tr>
                                        <?php
                                            $i = 1;
                                            foreach($operators as $key => $value){
                                        ?>
                                            <tr>
                                                <td><?= $i ?></td>
                                                <td><?= $users[$key] ?? "" ?></td>
                                                <td><?= !empty($guichets[$value["guichets"]])?$guichets[$value["guichets"]]:"" ?></td>
                                                <td><?= number_format($value['paiements'],2,","," "). " CDF" ?></td>
                                                <td><?= number_format($value['commissions'],2,","," "). " CDF" ?></td>
                                                <td><strong><?= number_format($value['tva'],2,","," "). " CDF" ?></strong></td>
                                                <td><?= $value['date'] ?></td>
                                                <!--<td><a href="dashboard_5.html#"><i class="fa fa-pencil text-warning"></i></a></td>-->
                                            </tr>
                                        <?php
                                                $i++;
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <section id="cat_list" class="bg-white text-center pt-5 pb-5">
                    <span class="d-block">
                        <span class="fa fa-flask text-black mystyle4" ></span>
                    </span>
                    <span class="d-block f13 text-muted p-1">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                </section>
            <?php endif; ?>

        </div>
        <div class="col-md-3 bLeft h-600">
            <div class="col-md-12 h-300">
                <h4 class="f18 ">Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br /></h4>
                <?php if (!empty($members)) { ?>

                <?php } else { ?>
                    <span class='f16 text-gray'>Aucune alerte trouv&eacute;e !<br /><br /></span>
                <?php } ?>
            </div>
            <div class="col-md-12 bTop d-block f18" >
                <h4 class="f18">Insights<br /></h4>
                <?php if (!empty($members)) { ?>

                <?php } else { ?>
                    <span class='f16 text-gray'>Aucune donn&eacute;e trouv&eacute;e !<br /><br /></span>
                <?php } ?>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $("#table").DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false,
                "pageSize": 50,
                //"dom": '<"row"<"col-md-6 d-flex align-items-center custom-search"f><"col-md-6 text-right"p>>', // Personnalisation du DOM
                "language": {
                    "paginate": {
                        "next": "<i class='fa fa-chevron-right'></i>", // Remplace "Next"
                        "previous": "<i class='fa fa-chevron-left'></i>" // Remplace "Previous"
                    },
                    "search": "Rechercher :", // Traduction de la recherche
                    "lengthMenu": "Afficher _MENU_ entrées",
                    "zeroRecords": "Aucun enregistrement trouvé",
                    "infoEmpty": "Aucune donnée disponible",
                    "infoFiltered": "(filtré à partir de _MAX_ total des enregistrements)"
                },
                "initComplete": function () {
                    // Déplacer la barre de recherche vers votre conteneur personnalisé
                    $(".dataTables_filter").appendTo("#custom-search");
                }
            });
        });
    </script>