<?php 
if($user->Id_0 > 0) $title='Modifier'; else $title ='Ajouter un utilisateur';

if($_SESSION['Logiref_role'] == 2)
{
        $status_2 = $user->Statusvalidate_19;
}
else
{
        $status_2 = $user->Status_2;
}

?>
<div class="col-md-2"></div>
<div class="col-md-8">
    <div id="loader"></div>
    <h1><?php echo $title; ?></h1>
    <span class="page-header">
    </span>
    <?php $chtml->box_body_opening('', true); ?>
    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' =>'innovate')); ?>
        <div class="box-body">
            <input type="hidden" value="<?php echo $user->Statusvalidate_19; ?>" name="statusvalidate" />
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-addon"><label for="code">Code</label></span>
                    <?php echo form_input('code', set_value('code', $user->Code_12), 'class="form-control" required="required" maxlength="86"'); ?>
                    <input name="Id_0" type="hidden" value="<?php echo $user->Id_0; ?>" />
                </div>    
            </div>
            <div class="col-md-8">
                <div class="input-group">
                      <span class="input-group-addon"><label for="starts">Privil&egrave;ge</label></span>
                      <?php echo form_dropdown('role', $roles, $user->Role_4, ' class="form-control" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-12">
                <?php if($user->Userid_13==''){ ?>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="userid">Utilisateur</label></span>
                        <?php echo form_dropdown('userid', $users, $user->Userid_13, ' class="form-control" required="required"'); ?>
                    </div>
                <?php }else{ ?>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="userid">Noms</label></span>
                        <?php echo form_dropdown('name', $noms, $user->Userid_13, ' class="form-control" disabled="disabled" required="required"'); ?>
                        <input type="hidden" value="<?php echo $user->Userid_13; ?>" name="userid" />
                    </div>
                <?php } ?>    
            </div>
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-addon"><label for="province">Province</label></span>
                    <?php echo form_dropdown('province', $provinces, $user->Province_5,  '  class="form-control" required="required"'); ?>
                </div>   
                <div class="input-group">
                    <span class="input-group-addon"><label for="agence">Agence BCC</label></span>
                    <?php echo form_dropdown('agence', $agences, $user->Agence_7, ' id="agences" class="form-control" required="required"'); ?>
                </div>
            </div> 
            <div class="col-md-6 bLeft">
                  <div class="input-group">
                      <span class="input-group-addon"><label for="ville">Ville</label></span>
                      <?php echo form_dropdown('ville', $villes, $user->Ville_6, '  class="form-control" required="required"'); ?>
                  </div>
                  <div class="input-group">
                        <span class="input-group-addon"><label for="guichet">Agence bancaire</label></span>
                        <span id="slist"><?php echo form_dropdown('guichet', $guichets, $user->Guichet_8, ' id="guichet" class="form-control" '); ?></span>
                  </div>      
            </div>
            <?php $disabled = ($_SESSION['Logiref_role'] == 2)? 'disabled' :''; if($user->Id_0 > 0){ ?>
                <div class="col-md-12">
                    <div class="input-group">
                        <span class="input-group-addon"><label for="status">Statut</label></span>
                        <?php echo form_dropdown('status', $statut, $status_2, ' class="form-control" required="required" '.$disabled.''); ?>
                    </div>
                </div>
            <?php } ?> 
        </div>
        <div class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Valider..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;&nbsp;
                <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
            </div>
        </div>
    <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(true); ?>
</div>
<div class="col-md-2">
    <a id="cancel" class="btn btn-app no-border" href="#"><i class="fa fa-fw fa-times text-gray f40"></i></a>
</div>


<script type="text/javascript">
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxusers/save/user'); ?>/<?php echo $user->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $user->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($user->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

<?php if(isset($user->Id_0) && $user->Id_0!='' && $user->Id_0!=0){?>
      shower();
<?php } ?>
    
$('#agences').change(function(){
      shower();
      
});

function shower()
{
      $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      //$("#Standard01").type='text';
      var agence = $('#agences option:selected').val();
      
      var url = '<?php echo base_url($module.'/settings'); ?>/display/dropdowns/' + agence+ '/guichets/<?php echo $user->Guichet_8; ?>';
      $.get(url, function(data, status){
                if(data!="")
                {
                        $("#slist").html(data);
                }
            
      });
} 

$("#cancel").click(function(){
     closeModal();
});

$("#close").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
      
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
            $.get("<?php echo base_url($module.'/settings/display/settings/privileges/users'); ?>", function(data, status){
                $("#loader").html('');
                $("#container").html(data);
            });
    }
    else
    {
            $.get("<?php echo base_url($module.'/taxusers/display/privileges'); ?>", function(data, status){
                $("#loader").html('');
                $("#container").html(data);
            });
    }
}
</script>
