<?php
$encryptions = json_decode($identifiants->Password_18, true);

$password = isset($encryptions['encryption']) ? $encryptions['encryption'] : "";
$codebank = isset($encryptions['codebank']) ? $encryptions['codebank'] : "";

if($identifiants->Id_0 != "")
{
        $action = "Modifier";
}
else
{
        $action = "Enregistrer";
}


?>
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="loader1"></div>
        
        <h1 class="f30 text-blue">Ajout des acc&egrave;s de connexion SYDONIA</h1>
        <p class="page-header"><span class="f12 text-black">Configuration des acc&egrav;s  de connexion &agrave; Sydonia.</span></p>
        
        <?php $chtml->box_body_opening('', true);?>
        <div class="row">
            <div class="col-md-3 center padding-20">
                <div class="row">
                    <div class="col-md-12 center">
                        <p class="page-header">
                            <br/><br/>Remplissez les champs recquis pour configurer la connexion &agrave; sydonia.
                        </p> 
                    </div>
                </div>
            </div>
            <div class="col-md-9 bLeft">
                <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="code">Code de la banque</label> 
                                    <?php echo form_input('code',$codebank, 'class="form-control"  required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="login">Identifiant</label> 
                                    <?php echo form_input('login',$identifiants->Login_17, 'class="form-control"  required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password">Mot de passe</label> 
                                    <?php echo form_password('password',$password, 'class="form-control" id="password" required = "required"'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="confirmpass">Confirmez le mot de passe</label> 
                                    <?php echo form_password('confirmpass',$password, 'class="form-control" id="confirmpass"  required = "required"'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="details" class="col-md-12"></div>
                    <div class="box-footer clearfix">
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" id='envoyer' class="btn btn-primary pull-left" ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php echo $action;?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <a id="closeModal" href="<?= base_url('/branch/taxdashboards/set/etax') ?>" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</a>&nbsp;&nbsp;
                            </div>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>

        <?php $chtml->box_body_closing(); ?> 
    </div>
    <div class="col-md-1">

    </div>
</div><!-- comment -->

<script type="text/javascript">
$("#mainform").submit(function(event){
    
        event.preventDefault();

        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxusers/save/'); ?>/account_sydonia<?php echo $identifiants->Id_0 > 0 ? '/'.$identifiants->Id_0 : ''; ?>';
        var data = $(this).serialize();
        
        var pass = $("#password").val();
        var passConf = $("#confirmpass").val();
        if(pass === passConf)
        {
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                            $('#loader1').html('');
                            $('#loader1').html(result);
                    },
                    error:function(error){
                            $('#loader1').html('<div class="alert aDanger text-white">D&eacute;sol&eacute; : une erreur s\'est produite, veuillez r&eacute;essayer s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
        }
        else
        {
            $('#loader1').html('<div class="alert aWarning text-white"> Alerte: le mot de passe saisi pour confirmation n\'est pas identique au mot de passe initial...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
});


</script>
