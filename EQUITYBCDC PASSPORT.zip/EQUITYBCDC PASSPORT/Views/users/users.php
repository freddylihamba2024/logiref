<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div id="pager" class="content">
    <div class="col-md-10">
        <div class="col-md-12 <?= $title; ?>">
            <h1><i class="fa fa-book f35 text-green"></i>&nbsp;&nbsp;<span class="text-blue">Gestion des habilitations</span></h1>
        </div>
        <div class="col-md-12">
            <div id="loader"></div>
        </div>
        <div class="col-md-12">
            <?php if(!empty($members)): ?>
                <?php $chtml->box_body_opening('', true); ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th>#</th>
                                <th>Nom complet</th>
                                <th width="150px">Role</th>
                                <th>Agence bancaire</th>
                                <th width="100px">Statut</th>
                                <th>Maker</th>
                                <th>Checker</th>
                                <th width="80">Validation</th>
                                <th width="10px"><span class="fa fa-fw fa-edit f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php 
                          $i =0;
                          foreach($members as $row){
                          ?>
                            <?php if(isset($users[$row->Userid_13])):?>
                            <tr>
                                <td width="5"><?php echo ++$i; ?></td>
                                <td width="250"><b><?php if(isset($users[$row->Userid_13])) echo $users[$row->Userid_13]; ?></b></td>
                                <td class="bleu"><?php echo $roles[$row->Role_4];?></td>
                                <td width="150"><?php if(isset($guichets[$row->Guichet_8])) echo $guichets[$row->Guichet_8]; else echo"-"?></td>
                                <td>
                                    <?php 
                                        if($row->Checker_15 == "" || $row->Maker_14 !='')
                                        {
                                                $Status_2 = $row->Status_2;
                                        }
                                        else
                                        {
                                                $Status_2 = $row->Status_2;
                                        }
                                    ?>
                                    <span class="badge <?php echo $statutColor[$Status_2]?>">
                                        <?php echo $statut[$Status_2]; ?>
                                    </span>
                                </td>
                                <td >
                                    <?php echo(isset($users[$row->Maker_14]))? $users[$row->Maker_14] :' - '; ?>
                                </td>
                                <td>
                                   <?php echo (isset($users[$row->Checker_15])) ? $users[$row->Checker_15] :" - ";?>
                                </td>
                                <td width="80">
                                    <?php if($row->Checker_15==0){ ?>
                                        <span class="text-red"> En attente </span>
                                    <?php }else {?>
                                        <?php echo $row->Validation_16;?>
                                    <?php } ?>
                                </td>
                                <td width="25" align="right">
                                    <?php if(($usertype =='200' || $_SESSION['Logiref_role'] == 2) && $userid != $row->Userid_13){?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-orange fa-pencil f14"> </span></a>
                                    <?php }else {?>
                                        <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php } ?>
                                </td>                                                          
                            </tr>
                            <?php endif;?>
                          <?php } ?>
                        </tbody>    
                    </table>
                <?php $chtml->box_body_closing(); ?> 	
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-yellow mystyle4"></i><br/>
                        <h4 align="center"><b>Aucune habilitation faite! </b> </h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    </div>
    <div class="col-md-2 <?= isset($from) ? $from : "" ?>">
        <div class="col-md-12 <?= $title; ?>">
            <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
            <br/><br/>
        </div>
        <div class="col-md-12 bTop <?= $title; ?>" >
            <h4></h4>
            <span class="text-gray f12">
                Faites une nouvelle habilitation
            </span>
            <br/><br/><br/>
        </div>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
//************************************************************

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

//What to show or not
$('#GroupEditBox').css( "display", "none");
$('.direct-chat-msg').css("display", "none");


//**********************************************************
//Add a member
$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module.'/taxusers/display/user'); ?>", function(data, status) {
        $("#loader").html('');
        $("#container").html(data);
    });
});



$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/taxusers/display/user'); ?>/' + id +'/<?php echo $from ?>';
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
      });
}
</script>
