<section class="bulletin-tab">
    <!-- Menu interne -->
    <div class="sub-tabs">
        <button class="sub-tab active" data-url="<?= base_url('branch/taximmatriculation/display/_integration_branch') ?>">
            Paiements en agence
        </button>
        <button class="sub-tab" data-url="<?= base_url('branch/taximmatriculation/display/_integration_branchless') ?>">
            Paiements en ligne
        </button>
<!--        <button class="sub-tab" data-url="<?= base_url('branch/taximmatriculation/display/_integration_filter') ?>">
            Filtrage des intégrations
        </button>-->
    </div>
    <!-- Container de vues -->
    <div id="bulletin-container">
        <!-- Vue chargée dynamiquement -->
    </div>
</section>
<script type="text/javascript">

    $(document).ready(function(e){
        loadTabView("<?= base_url('branch/taximmatriculation/display/_integration_branch') ?>")
    })

    function loadTabView(url) 
    {
        var container=$("#bulletin-container");
        container.html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url,function(response){
            container.html(response);
        }).fail(function(e){
            container.html("Une erreur est survenue lors de l'affichage");
        })
    }

    $(".sub-tab").on("click",function(e){
        $(".sub-tab").removeClass('active');
        $(this).addClass('active');
        var url=$(this).data("url");
        loadTabView(url);
    })
    // subTabs.forEach(tab => {
    //     tab.addEventListener('click', () => {
    //         subTabs.forEach(t => t.classList.remove('active'));
    //         tab.classList.add('active');

    //         loadView(tab.dataset.url);
    //     });
    // });

</script>