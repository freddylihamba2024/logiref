<div class="col-md-12 px-0">
    <?php if(!empty($files_instructions_data)): ?>
    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
    <input type="hidden" name="type_integration" value="branch" />
    <div class="box-body p-4 bg-light">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped">
                <thead class="bg-primary text-white">
                    <tr>
                        <th style="width: 5%">
                            <input type="checkbox" id="select-all" />
                        </th>
                        <th style="width: 15%">Bureau</th>
                        <th style="width: 15%">Date de création</th>
                        <th style="width: 20%">Designation</th>
                        <th style="width: 15%">Type</th>
                        <th style="width: 10%">Quantité</th>
                        <th style="width: 10%">Montant</th>
                        <th style="width: 10%">État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($files_instructions_data)):
                        foreach ($files_instructions_data as $journalisation):
                            $office = $journalisation['office'];
                            $notes_ids = json_encode($journalisation['notes_ids']);
                            $created_date = $journalisation['created_date'];
                            $notes_count = count($journalisation['notes_ids']);
                            $total_amount = $journalisation['total_amount'];
                            $status = $journalisation['status'];
                            $designation = $journalisation['designation'] ?? 'N/A';
                            $type = $journalisation['type'] ?? 'N/A';
                            $status_color = isset($journalisation['status_color']) ? $journalisation['status_color'] : 'secondary';
                    ?>
                        <tr>
                            <td class="text-center">
                                <input type="checkbox" name="selected_offices[]" value="<?= $office ?>" />
                            </td>
                            <td><strong><?= $office ?></strong></td>
                            <td><?= $created_date ?></td>
                            <td><?= $designation ?></td>
                            <td><?= $type ?></td>
                            <td class="text-center"><?= $notes_count ?></td>
                            <td class="text-right"><?= number_format($total_amount, 2, ',', ' ') ?> XOF</td>
                            <td class="text-center">
                                <span class="badge badge-<?= $status_color ?>"><?= $status ?></span>
                            </td>
                        </tr>
                        <tr class="accordion-row" id="details-row-<?= $office ?>" style="display:none;">
                            <td colspan="8">
                                <button type="button" class="btn btn-info btn-sm accordion-btn" id="details-<?= $office ?>" 
                                    data-target="details-body-<?= $office ?>" 
                                    data-journalisation='<?php echo json_encode($journalisation); ?>'>
                                    Voir détails
                                </button>
                                <div id="details-body-<?= $office ?>" class="mt-3"></div>
                            </td>
                        </tr>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Total et actions -->
        <div class="row align-items-center mt-4">
            <div class="col-md-6">
                <div class="total-box p-3 bg-white border rounded">
                    <h5 class="mb-2">Résumé</h5>
                    <p><strong>Notes sélectionnées:</strong> <span id="selected-count">0</span></p>
                    <p><strong>Montant total:</strong> <span id="total-amount">0.00</span> XOF</p>
                </div>
            </div>

            <div class="col-md-6 text-end">
                <button type="button" class="btn btn-primary" id="btn-create">
                    📄 Créer les fichiers
                </button>
                <button type="button" class="btn btn-success" id="btn-send" disabled>
                    📤 Envoyer les fichiers
                </button>
            </div>
        </div>

        <!-- Progression -->
        <div class="mt-4">
            <div class="progress" style="height: 25px;">
                <div id="progress-bar" class="progress-bar progress-bar-animated bg-success" role="progressbar" 
                    style="width: 0%">
                    <span id="progress-text">0% - En attente</span>
                </div>
            </div>
            <input type="hidden" id="progression" value="0" />
        </div>
        <input type="hidden" name="action" value="" id="action">


        <!-- Zone des messages -->
        <div id="loader1" class="mt-3"></div>
        <br/><br/>
    </div>
    <?php echo form_close(); ?>
    <?php else: ?>
        <?php $chtml->box_body_opening(); ?> 
        <?php $chtml->box_body_closing(); ?> 
    <?php endif; ?>
</div>

<script type="text/javascript">
    
$(document).off('click', '.accordion-btn').on('click', '.accordion-btn', function() {
    var targetId = $(this).data('target');
    var journalisation=$(this).data('journalisation');

    var $row = $('#' + targetId);
    if ($row.is(':visible')) {
        $row.hide();
    } else {
        $row.show();
        get_office_notes(journalisation)
    }
});   

function get_office_notes(journalisation_data) {
    var url = '<?= base_url($module . '/taximmatriculation/display/_integration_details_filter') ?>';
    
    var note_ids = journalisation_data.notes_ids;
    var office = journalisation_data.office;

    $(`#details-${office}`).prop('disabled',true);
    $(`#details-${office}`).html('<div class="spinner-border text-light" role="status"></div>');
    $(`#details-body-${office}`).html("");
    var csrf = $('input[name="csrf_name"]').val();

    $.post(url, {
        notes_ids: note_ids,
        csrf_name:csrf
    }, function(response) {
        $(`#details-${office}`).prop('disabled',false);
        $(`#details-${office}`).html('Voir détails');
        $(`#details-body-${office}`).html(response);
    }).fail(function(err) {
        alert("Une erreur inattendue est survenue");
        $(`#details-${office}`).prop('disabled',false);
        $(`#details-${office}`).html('Voir détails');
    });

}

$(function () {

    $('.btn-send-office').prop('disabled', true);
    let sendingInProgress = false;
    let progress = 0;

    /* =========================
       ÉTAT INITIAL (reprise)
    ========================== */

    <?php if (isset($treatment_on_going->Status_2) && $treatment_on_going->Status_2 == '2'): ?>
        $('#btn-create').prop('disabled', true);
        $('#btn-send').removeClass('disabled');
        
        // Activer les boutons d'envoi
        $('.btn-send-office').prop('disabled', false);
    
        progress = 10;
        update_progress(progress, "Fichiers créés avec succès. Prêt pour l'envoi.");
        $('#loader1').html(
            '<div class="alert alert-info">Fichiers prêts à être envoyés. Cliquez sur "Envoyer les fichiers" pour procéder.</div>'
        );
    <?php endif; ?>

    /* =========================
       ACTIONS GLOBALES
    ========================== */

    $('#btn-create').on('click', function () {
        $('#action').val('create_file');
    });

    $('#mainform').on('submit', function (event) {
        event.preventDefault();

        let action = $('#action').val();

        if (action === 'create_file') {
            create_file($('#mainform').serialize());
        }
    });

    /* =========================
       UTILITAIRES
    ========================== */

    function update_progress(value, message) {
    
        if (value > 100) value = 100;
         
        $('#progress-bar').css('width', value + '%');
        $('#progress-text').text(Math.round(value) + '% - ' + message);
        $('#progression').val(value);
    }

    /* =========================
       SAUVEGARDE INTÉGRATION
    ========================== */

    function save_integration_sftp(data) {

        $('#loader1').html('<img height="30" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.ajax({
            type: 'POST',
            url: '<?= base_url($module . '/taximmatriculation/save_integration_sftp') ?>',
            data: data,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    update_progress(100, 'Intégration sauvegardée avec succès');
                } else {
                    update_progress(0, response.message || 'Erreur lors de la sauvegarde');
                }
            },
            error: function() {
                update_progress(0, 'Erreur lors de la sauvegarde');
            }
        });
    }

    /* =========================
       CRÉATION DES FICHIERS
    ========================== */

    function create_file(id) {

        $('#loader1').html('<img height="30" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.ajax({
            type: 'POST',
            url: '<?= base_url($module . '/taximmatriculation/create_file') ?>',
            data: id,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    update_progress(50, 'Fichiers créés avec succès');
                    $('#btn-create').prop('disabled', true);
                    $('#btn-send').prop('disabled', false);
                    $('.btn-send-office').prop('disabled', false);
                    save_integration_sftp(id);
                } else {
                    update_progress(0, response.message || 'Erreur lors de la création');
                }
            },
            error: function() {
                update_progress(0, 'Erreur lors de la création');
            }
        });
    }

    /* =========================
       ENVOI INDIVIDUEL PAR BUREAU
    ========================== */

    $(document).off('click', '.btn-send-office').on('click', '.btn-send-office', function (e) {
    });

    async function send_office_file(office, integrationId, $btn) {

        if (sendingInProgress) {
            return;
        }

        const formData = new FormData();
        formData.append('office', office);
        formData.append('integration_id', integrationId);

        try {
            sendingInProgress = true;
            $btn.prop('disabled', true);
            $btn.html('<div class="spinner-border spinner-border-sm" role="status"></div>');

            const response = await fetch('<?= base_url($module . '/taximmatriculation/send_file') ?>', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Erreur lors de l\'envoi');
            }

            const data = await response.json();

            if (data.success) {
                mark_office_as_sent(office, $btn);
                progress = Math.min(progress + 10, 90);
                update_progress(progress, `Envois en cours... ${office}`);
            } else {
                $btn.prop('disabled', false);
                $btn.html('⚠️ Erreur');
            }
        } catch (error) {
            console.error(error);
            $btn.prop('disabled', false);
            $btn.html('❌ Erreur');
        } finally {
            sendingInProgress = false;
        }
    }

    /* =========================
       ÉTAT / PROGRESSION
    ========================== */

    function mark_office_as_sent(office, $btn) {

        $btn.addClass('btn-sent');
        $btn.removeClass('btn-danger btn-warning');
        $btn.addClass('btn-success');
        $btn.prop('disabled', true);
        $btn.html('✅ Envoyé');

        // Marquer la checkbox correspondante comme cochée
        $(`input[name="selected_offices[]"][value="${office}"]`).prop('checked', true);
        
        // Mettre à jour le row
        const $row = $(`#details-row-${office}`);
        $row.find('span.badge').removeClass('badge-secondary badge-warning badge-danger').addClass('badge-success');
        $row.find('span.badge').text('Envoyé');

        update_progress_by_state();
    }

    function restore_buttons() {

        $('.btn-send-office').each(function() {
            const $btn = $(this);
            if (!$btn.hasClass('btn-sent')) {
                $btn.prop('disabled', false);
            }
        });
    }

    function update_progress_by_state() {

        const totalBtns = $('.btn-send-office').length;
        const sentBtns = $('.btn-send-office.btn-sent').length;

        if (totalBtns > 0) {
            progress = 10 + (sentBtns / totalBtns) * 80;
            if (sentBtns === totalBtns) {
                progress = 100;
                update_progress(progress, 'Tous les fichiers ont été envoyés avec succès');
            } else {
                update_progress(progress, `${sentBtns} sur ${totalBtns} bureaux traités`);
            }
        }
    }

    /* =========================
       RESTAURATION APRÈS REFRESH
    ========================== */

    (function restore_after_refresh() {

        // Vérifier les notes envoyées via le DOM
        $('.btn-send-office.btn-sent').each(function() {
            const office = $(this).closest('tr').find('td:nth-child(2)').text();
            mark_office_as_sent(office, $(this));
        });

        restore_buttons();
        update_progress_by_state();
    })();
    
    

});


</script>
