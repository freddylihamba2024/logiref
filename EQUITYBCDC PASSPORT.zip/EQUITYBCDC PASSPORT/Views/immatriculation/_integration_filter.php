<div class="col-md-12 mt-4" id='pager'>
    <div class="box box-solid shadow-sm border rounded" >
        <div class="box-header py-3 px-4 border-bottom bg-light">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div class="w-100">
                    <h1 class="f25 text-blue mb-1" >
                        Intégration des notes par bureau
                    </h1>
                    <p class="page-header text-muted mb-0 f13">
                        Extraction des fichiers par bureau de douane
                    </p>
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="mt-3 p-3 bg-white border rounded shadow-sm">
                        <div class="row align-items-end g-2">
                            
                            <!-- Date de traitement -->
                            <div class="col-md-4">
                                <label for="filter_date" class="form-label">Date de traitement</label>
                                <input type="text" id="filter_date" name="filter_date" class="form-control" placeholder="YYYY-MM-DD" required />
                            </div>

                            <!-- Type de paiement -->
                            <div class="col-md-4">
                                <label for="payment_type" class="form-label">Type de paiement</label>
                                <select id="payment_type" name="payment_type" class="form-control">
                                    <option value="">Tous les types</option>
                                    <option value="branch">En agence</option>
                                    <option value="rbo">En ligne (RBO)</option>
                                </select>
                            </div>

                            <div class="col-md-2 d-flex align-items-center">
                                <button type="button" id="btn-filter" class="btn btn-primary w-100">
                                    🔍 Filtrer
                                </button>
                            </div>
                            
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                </div>
                <div class="header-divider mt-3 mt-md-0"></div>
            </div>
        </div>
    
        <div >
            <div id='filterResult'>
                <div class="col-md-12 px-0">
                    <?php if(!empty($files_instructions_data)): ?>
                   
                    <input type="hidden" name="type_integration" value="branch" />
                    <div class="box-body p-4 bg-light">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="integration-table">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th style="width: 5%">
                                            <input type="checkbox" id="select-all" />
                                        </th>
                                        <th style="width: 15%">Bureau</th>
                                        <th style="width: 15%">Date de création</th>
                                        <th style="width: 20%">Designation</th>
                                        <th style="width: 15%">Type</th>
                                        <th style="width: 10%">Quantité</th>
                                        <th style="width: 10%">Montant</th>
                                        <th style="width: 10%">État</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($files_instructions_data)):
                                        foreach ($files_instructions_data as $journalisation):
                                            $office = $journalisation['office'];
                                            $notes_ids = json_encode($journalisation['notes_ids']);
                                            $created_date = $journalisation['created_date'];
                                            $notes_count = count($journalisation['notes_ids']);
                                            $total_amount = $journalisation['total_amount'];
                                            $status = $journalisation['status'];
                                            $designation = $journalisation['designation'] ?? 'N/A';
                                            $type = $journalisation['type'] ?? 'N/A';
                                            $status_color = isset($journalisation['status_color']) ? $journalisation['status_color'] : 'secondary';
                                    ?>
                                        <tr>
                                            <td class="text-center">
                                                <input type="checkbox" name="selected_offices[]" value="<?= $office ?>" />
                                            </td>
                                            <td><strong><?= $office ?></strong></td>
                                            <td><?= $created_date ?></td>
                                            <td><?= $designation ?></td>
                                            <td><?= $type ?></td>
                                            <td class="text-center"><?= $notes_count ?></td>
                                            <td class="text-right"><?= number_format($total_amount, 2, ',', ' ') ?> XOF</td>
                                            <td class="text-center">
                                                <span class="badge badge-<?= $status_color ?>"><?= $status ?></span>
                                            </td>
                                        </tr>
                                        <tr class="accordion-row" id="details-row-<?= $office ?>" style="display:none;">
                                            <td colspan="8">
                                                <button type="button" class="btn btn-info btn-sm accordion-btn" id="details-<?= $office ?>" 
                                                    data-target="details-body-<?= $office ?>" 
                                                    data-journalisation='<?php echo json_encode($journalisation); ?>'>
                                                    Voir détails
                                                </button>
                                                <div id="details-body-<?= $office ?>" class="mt-3"></div>
                                            </td>
                                        </tr>
                                    <?php
                                        endforeach;
                                    endif;
                                    ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Total et actions -->
                        <div class="row align-items-center mt-4">
                            <div class="col-md-6">
                                <div class="total-box p-3 bg-white border rounded">
                                    <h5 class="mb-2">Résumé</h5>
                                    <p><strong>Notes sélectionnées:</strong> <span id="selected-count">0</span></p>
                                    <p><strong>Montant total:</strong> <span id="total-amount">0.00</span> XOF</p>
                                </div>
                            </div>

                            <div class="col-md-6 text-end">
                                <button type="button" class="btn btn-primary" id="btn-create">
                                    📄 Créer les fichiers
                                </button>
                                <button type="button" class="btn btn-success" id="btn-send" disabled>
                                    📤 Envoyer les fichiers
                                </button>
                            </div>
                        </div>

                        <!-- Progression -->
                        <div class="mt-4">
                            <div class="progress" style="height: 25px;">
                                <div id="progress-bar" class="progress-bar progress-bar-animated bg-success" role="progressbar" 
                                    style="width: 0%">
                                    <span id="progress-text">0% - En attente</span>
                                </div>
                            </div>
                            <input type="hidden" id="progression" value="0" />
                        </div>
                        <input type="hidden" name="action" value="" id="action">


                        <!-- Zone des messages -->
                        <div id="loader1" class="mt-3"></div>
                        <br/><br/>
                    </div>
                    
                    <?php else: ?>
                        <?php $chtml->box_body_opening(); ?> 
                        <?php $chtml->box_body_closing(); ?> 
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    
$('#filter_date').datepicker({
    todayHighlight: true,
    clearBtn: true,
    format: 'yyyy-mm-dd'
});

$("#pager").on("click", "#btn-filter", function() {

    const date = $('#filter_date').val();
    const paymentType = $('#payment_type').val();

    if (!date) {
        alert('Veuillez sélectionner une date');
        return;
    }
    
    // afficher loader
    $('#filter-loader').show();
    
    // désactiver bouton
    $('#btn-filter').prop('disabled', true).text('Filtrage...');
    var csrf = $('input[name="csrf_name"]').val();

    const url = '<?= base_url($module . '/taximmatriculation/display/filter_integration_treatment') ?>';

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            filter_date: date,
            payment_type: paymentType,
            csrf_name:csrf
        },
        dataType: 'html',
        success: function (result) {
            $('#loader').html('');
            $('#filterResult').html(result);
            
            $('#filter-loader').hide();
            $('#btn-filter').prop('disabled', false).text('🔍 Filtrer');
        },
        error: function (error) {
            $('#loader').html('');
            alert('Erreur lors du filtrage');
            console.error(error);
        }
    });
});


   

</script>
