<?php
    $userid = $encaissement->Makerid_9;
    $feuille = '';
    $infos = json_decode($encaissement->Notereference_30, true);
    $disabled = "disabled";
?>

<?php if (isset($encaissement->Type_58) && !is_null($encaissement->Type_58) && $encaissement->Type_58 != ""): ?>
    <div class="alert aWarning text-white" id='mobile_payment_msg'> Ce paiement a &eacute;t&eacute; initi&eacute; en ligne, veuillez cliquer sur le bouton modifier pour completer les informations manquantes.</div>
<?php endif; ?>

<?php
if (isset($infos['accounttax']) && $infos['accounttax'] != "") {
    #when the customer is exempted from tax
    $disabled_1 = "disabled";
    $disabled_2 = "";
} else {
    #when the customer is not exempted from tax
    $disabled_1 = "";
    $disabled_2 = "disabled";
}

if(isset($encaissement->Status_2) && ($encaissement->Status_2=='3' || $encaissement->Status_2=='7'))
{
    $validate='disabled';
}
else
{
    $validate='';
}

$quote_parts = array();
if (!empty($encaissement)):
    $quote_parts = $infos['beneficiaries'];
endif;


$tva = (floatval($encaissement->Commission_23) * 0.16);

$montant_total = $encaissement->Montant_11 + $encaissement->Commission_23 + $tva;

?>

<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}
?>
<?php if ($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11, 2, ",", " "); ?>
<?php if ($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28, 2, ",", " "); ?>
<?php if ($encaissement->Commission_23 > 0) $encaissement->Commission_23 = number_format($encaissement->Commission_23, 2, ",", " "); ?>
<?php if ($_SESSION['Logiref_role'] == 4 && $userid == $_SESSION['userdata']['user_id'] && $encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == 0) $feuille = ''; ?>
<?php //$Standard01='';
?>


<?php if (isset($_POST['Reference_14']) && $_POST['Reference_14'] != '') {
    $reference = $_POST['Reference_14'];
} elseif (isset($content['Reference_32']) && $content['Reference_32'] != "") {
    $reference = $content['Reference_32'];
} else {
    $reference = "";
} ?>
<?php if (isset($_POST['Nif_17']) && $_POST['Nif_17'] != '') {
    $nif = $_POST['Nif_17'];
} elseif (isset($content['Nif']) && $content['Nif'] != "") {
    $nif = $content['Nif'];
} else {
    $nif = "";
} ?>
<?php if (isset($client->Designation_5) && $client->Designation_5 != '') {
    $designation = $client->Designation_5;
} elseif (isset($content['Denomination']) && $content['Denomination'] != "") {
    $designation = $content['Denomination'];
} else {
    $designation = "";
} ?>
<?php
if (isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else:
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if (!isset($infos['totalMontant'])) {
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = $encaissement->Devise_12;
}
?>

<div id="logirad-message"></div>

<?php echo form_open('', array('id' => 'form', 'class' => $view . " mb-0")); ?>
<style>
    label {
        min-width: 150px !important;
    }
</style>
<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
<input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
<input type="hidden" name="Infos[Email]" value="<?= isset($infos["Email"]) ? $infos["Email"] : "" ?>" id="email">
<input type="hidden" name="Infos[Phone]" value="<?= isset($infos["Phone"]) ? $infos["Phone"] : "" ?>" id="phone">
<input type="hidden" name="Email_54" value="<?= isset($encaissement->Email_54) ? $encaissement->Email_54 : "" ?>" id="">

<?php $chtml->box_body_opening('', true); ?>

<div class="box-body">

    <div class="">
        <div class="col-md-12">
            <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
            <div id="loader1"></div>
        </div>
    </div>

    <!------------------------- Beneficiare  ------------------------------>
    <div class="row">

        <div class="col-md-12"><br /><span class="f12"><b><label>Partie 1 : R&eacute;gies financi&egrave;re</label></b></span><br /></div>

        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label>
                </span>
                <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" required="required"  '); ?>
                <?php if ($encaissement->Id_0 != NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-7 small-box">
            <div class="input-group" id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16">
                        <div id="ServiceId">Service recouvrement</div>
                    </label>
                </span>
                <?php echo form_dropdown('', $services, $encaissement->Service_16, 'class="form-control select2" id="service" disabled="disabled"'); ?>
                <input type="hidden" name="Service_16" value="<?= isset($encaissement->Service_16) ? $encaissement->Service_16 : "" ?>">
            </div>
        </div>

    </div>

    <!-------------------------  Titre de perception  ------------------------------>

    <div class="row">

        <div class="col-md-12"><br/><span class="f12"><b><label>Partie 2 : Titre de paiement</label></b></span><br/></div>

        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26">
                        <div id="TitreId">Num&eacute;ro</div>
                    </label>
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25" required="required" readonly '); ?>
            </div>
        </div>
        <div class="col-md-7 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25">Document</label>
                </span>
                <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                <input type="hidden" name="Notetype_25" value="1">
            </div>
        </div>
    </div>

    <div id="bl" class="col-md-12"></div>

    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" readonly '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-7 small-box">
            <div class="input-group" id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17">Nature paiement</label>
                </span>
                <?php echo form_dropdown('', $recettes, $encaissement->Typerecette_17, 'class="form-control select2" id="recette" disabled="disabled"'); ?>
                <input type="hidden" name="Typerecette_17" value="<?= isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : "" ?>">
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard">Art. budg&eacute;taire</label>
                </span>
                <?php echo form_input("Artbudgetaire_18", set_value("Artbudgetaire_18", $encaissement->Artbudgetaire_18), ' class="form-control"  maxlength="25" readonly'); ?>
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28">Montant de la note</label>
                </span>
                <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required" readonly'); ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <?php echo form_dropdown('', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required" disabled="disabled" '); ?>
                <input type="hidden" name="Notedevise_29" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
            </div>
        </div>
    </div>

    <!------------------------- Payement  ------------------------------>

    <div class="row">
        <div class="col-md-5"><br /><span class="f12"><b><label>Partie 3 : Assujetti ou Contribuable.</label></b></span><br /></div>
        <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px;"></span><br />
            <div style="display: flex; align-items: center; width: 100%;">
                <label style="margin-bottom: 0;">
                    Intitulé du compte :&nbsp;&nbsp;
                    <span id="accountname"></span>
                </label>
                <?php if (isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                    <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                        <span id="" class="text-red f15"></span>&nbsp;&nbsp;<span id="labelNumber" class="text-red f15"></span>
                    </label>
                <?php elseif (isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>
                    <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                        Frais de correspondance :&nbsp;&nbsp;
                        <span id="correspondent_fees" class="text-red f15">0.00 </span>&nbsp;&nbsp;<span id="correspondent_fees_currency" class="text-red f15"></span>
                        <input type="hidden" id="correspondent_fees_to_retrieve" name="Infos[correspondent_fees]">
                        <input type="hidden" id="correspondent_fees_to_retrieve_currency" name="Infos[correspondent_fees_currency]">
                    </label>
                <?php endif; ?>
            </div>
        </div>

        <!--<div class="col-md-3 border"></br><label>Paie pour compte&nbsp;<input type="checkbox" name="Infos[pourcompte]" value="<?php echo (isset($infos['pourcompte'])) ? $infos['pourcompte'] : ''; ?>" <?php echo isset($infos['pourcompte']) ? 'checked' : ''; ?>></label></div>-->

        <input type="hidden" name="Infos[fraisbcc]" value="1" id="infosFbcc">
        <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
    </div>

    <div class="col-md-12 d-none" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux d'echange : </b> <span id="exchange_message"></span></div>
    <div class="col-md-12 d-none" id="trans_bloc"><b>Détails de la transaction: </b> <span id="trans_message"></span></div>

    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Nif_13">Num&edot;ro imp&ocirc;t</label>
                </span>
                <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86" readonly'); ?>
            </div>
        </div>
        <div class="col-md-7 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Designation_14">D&eacute;signation</label>
                </span>
                <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" readonly'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Mode_19">Mode de paiement</label>
                </span>
                <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Taux_41">Taux de change</label>
                </span>
                <?php echo form_input('Taux_41', ($encaissement->Taux_41 != "") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control"'); ?>
                <input type="hidden" value="<?php echo isset($infos['rate_code']) ? $infos['rate_code'] : "" ?>" name="Infos[rate_code]" id="rate_code">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Datevaleur_31">Date paiement</label>
                </span>
                <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10" disabled="disabled" required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                <input type="hidden" name="Datevaleur_31" value="<?php echo date('Y-m-d', strtotime($encaissement->Datevaleur_31)) ?>" id="">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Datetrans">Date transaction</label>
                </span>
                <?php
                if (isset($encaissement->Mode_19) && $encaissement->Mode_19 == '5'):
                    $date_trans = isset($infos['Datetrans']) ? $infos['Datetrans'] : "";
                    $date_form = date('d-m-Y', strtotime($date_trans));
                    $readonly = '';
                else:
                    $readonly = 'disabled';
                    $date_form = '';
                endif;
                ?>
                <?php echo form_input('Infos[Datetrans]', set_value('Infos[Datetrans]', $date_form), ' id="dateTrans" class="form-control" maxlength="10" ' . $readonly); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                </span>
                <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Compte_33">
                        <div id="compteLabel">Compte du client</div>
                    </label>
                </span>
                <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                <input type="hidden" name="account_name" value="<?php echo (isset($encaissement->Compte_33)) ? $encaissement->Compte_33 : ''; ?>" id="account_name">
                <input type="hidden" name="account_currency" value="" disabled="disabled" id="account_currency">
                <input type="hidden" name="account_balance" value="" disabled="disabled" id="account_balance">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Montant_11">Montant &agrave; payer</label>
                </span>
                <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required" readonly'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Commission_23">
                        <div id="commiision">Commission</div>
                    </label>
                </span>
                <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" '); ?>

            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Commission_23">
                        <div id="tva">Tva</div>
                    </label>
                </span>
                <?php $tva = (floatval(str_replace(',','.',$encaissement->Commission_23)) * 0.16); ?>
                <?php echo form_input('', set_value('', round($tva,2)), 'class="form-control" id="feesTva" readonly '); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Total">Montant total</label>
                </span>
                <?php echo form_input("montantTotal", set_value('Total', round($montant_total,2)), 'class="form-control bg-gray" id="montantTotal"'); ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('Devise_24', array('USD' => 'USD'), 'USD', 'class="form-control"  required="required" id="commissionDevise" disabled="disabled"'); ?>
                <input type="hidden" name="Devise_12" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown('', $devises, "USD", 'class="form-control"  required="required" disabled="disabled" id="tvaDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                <?php echo form_dropdown("Infos[totalDevise]", array('USD' => 'USD'), 'USD', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
            </div>
            <input type="hidden" name="Devise_24" value="<?php echo isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "" ?>">
        </div>
    </div>

    <!-------------------------  DGI Immatriculation  ------------------------------>
    <div id="DGIQuotepart">

        <div class="col-md-12 p-0"><br/><span class="f12"><b><label>Partie 4 : Informations additionnelle</label></b></span><br/></div>

        <div class="row">
            <?php foreach ($quote_parts as $i => $part): ?>
                <div class="col-md-3 small-box">
                    <div class="form-group">
                        <label><?= esc($part['beneficiary_code']) ?></label>

                        <input type="hidden"
                            name="Infos[beneficiaries][<?= $i ?>][beneficiary]"
                            value="<?= esc($part['beneficiary_code']) ?>">

                        <?= form_input(
                            "Infos[beneficiaries][$i][amount]",
                            set_value("Infos[beneficiaries][$i][amount]", $part['amount']),
                            'class="form-control" readonly'
                        ); ?>

                        <input type="hidden"
                            name="Infos[beneficiaries][<?= $i ?>][currency]"
                            value="<?= esc($part['currency'] ?? 'USD') ?>">
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

    <?php if (isset($options['ALL']['Validation-of-license-plate-payment-by-SIOP']) && isset($infos['validateBySiop']) && $infos['validateBySiop'] == 1): ?>
        <!--<div class="col-md-12 p-0"><br/><span class="f12"><b><label>Partie 5 : Choix validation</label></b></span><br/></div>
        <div class="col-md-12 mb-3 mt-2 pl-0">
            <label style="display: flex; align-items: center; gap: 8px;">
                <input type="checkbox" name="ValidateBySiop_39" value="1" id="validate_siop" <?= isset($infos['validateBySiop']) && $infos['validateBySiop'] == 1 ? 'checked' : '' ?>>
                Validation par SIOP
            </label>
        </div>-->
        <input type="hidden" name="ValidateBySiop_39" id="validate_siop" value="1" />
    <?php endif; ?>

    <!------------------------- Repartitions  ------------------------------>
    <div class="row">
        <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
    </div>
    <div class="row">
        <div id="Comptabilisation" class="col-md-12"></div>
    </div>
    <!-------------------------  END  ------------------------------>
</div>
<div class="box-footer clearfix">
    <div id="createPaiement" class="col-md-12 pl-0 pr-0">
        <!-------------------------  No valider  ------------------------------>
        <?php if ($encaissement->Checkerid_10 == 0 && ($userid == $_SESSION['userdata']['user_id'] || $_SESSION['Logiref_role'] != 4)): ?>
            <?php if ($encaissement->Checkerid_10 != 5) : ?>
                <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>
                    <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <?php endif; ?>
                <?php if (!empty($print_attestation) && $print_attestation): ?>
                    <div class="btn-group">
                        <button type="button" id="attestation" class="btn btn-primary no-border no-margin">
                            <i class="fa fa-folder-open"></i> Preuve de paiement
                        </button>

                        <button type="button" class="btn btn-secondary no-border dropdown-toggle f14" id="dropdownToggle">
                            <span class="caret"></span>
                        </button>

                        <ul class="dropdown-menu text-left" role="menu" id="dropdownMenu" style="display: none;">
                            <li><a onclick="print()"><i class="fa fa-print f14"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</a></li>
                            <li class="divider"></li>
                            <li><a onclick="mail()"><i class="fa fa-envelope f14"></i>&nbsp;&nbsp;Envoyer l'attestation par mail&nbsp;&nbsp;</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
                <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php endif; ?>
        <?php endif; ?>

        <!-------------------------  Valider  ------------------------------>
        <?php if ($encaissement->Checkerid_10 > 0 && ($userid = $_SESSION['userdata']['user_id'] || $_SESSION['Logiref_role'] != 4)): ?>
            <button type="button" disabled='<?= $validate ?>' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Valider";else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;

            <?php if($encaissement->Status_2 == 7): ?>
                <button id="confirmation_note" type="button" class="btn btn-dark ml-2"><i class="fa fa-save"></i>&nbsp;&nbsp; Confirmer paiement &nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php endif; ?>

            <?php if ($encaissement->Status_2 == 2 || $encaissement->Status_2 == 3 || $encaissement->Status_2 == 7): ?>
                <div class="btn-group">
                    <button type="button" id="attestation" class="btn btn-primary no-border no-margin">
                        <i class="fa fa-folder-open"></i> Preuve de paiement
                    </button>

                    <button type="button" class="btn btn-secondary no-border dropdown-toggle f14" id="dropdownToggle">
                        <span class="caret"></span>
                    </button>

                    <ul class="dropdown-menu text-left" role="menu" id="dropdownMenu" style="display: none;">
                        <li><a onclick="print()"><i class="fa fa-print f14"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</a></li>
                        <li class="divider"></li>
                        <li><a onclick="mail()"><i class="fa fa-envelope f14"></i>&nbsp;&nbsp;Envoyer l'attestation par mail&nbsp;&nbsp;</a></li>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>

        <button type="button" id="closePanel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
    </div>
</div>
<?php $chtml->box_body_closing(); ?>

<br/><br/>

<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.6.0.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<!-------------------------  Section identique a Step 2  ------------------------------>

<script type="text/javascript" charset="utf-8">
    var ref = '<?php echo $encaissement->Id_0; ?>';
    var controller = '<?php echo $controller; ?>';
    var from = '<?php echo $from; ?>';

    $(".select2").select2();

    var compte = $("#compteId").val();
    if (compte.length == 14) {
        get_accountname_internal();
    } else {
        get_accountname();
    }

    var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy'
    });

    $('#dateTrans').datepicker({
        todayHighlight: true,
        format: 'dd-mm-yyyy',
        autoclose: true
    }).on('changeDate', function(e) {
        // Ici ça se déclenche uniquement quand l’utilisateur choisit une date
        handleTransactionChange();
    });

    $('#montantNote').on("keyup", function() {
        this.value = this.value.replace(/ /g, "");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#recetteMontant').on("keyup", function() {
        this.value = this.value.replace(/ /g, "");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#commission').on("keyup", function() {
        this.value = this.value.replace(/ /g, "");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#montantNote').change(function() {
        var note = $('#montantNote').val();

        var deviseNote = $('#deviseNote option:selected').val();

        $('#montantNote').val(note);
        $('#recetteMontant').val(note);

        if (note != "") {
            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if (deviseNote == 'USD') {
                note = note * taux;
                $('#montantTotal').val(note.toLocaleString());
            } else {
                $('#rate_code').val('TTB');
                $('#montantTotal').val(note.toLocaleString());
            }

            //$('#commission').val('');
            commission();
            get_account_tariff();
        }
    });

    $('#deviseNote').change(function() {
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('USD');

        if (devise != "") {
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if (devise == 'USD') {
                note = note * taux;
                if (note) $('#montantTotal').val(note.toLocaleString());
            } else {
                $('#rate_code').val('TTB');
                if (note) $('#montantTotal').val(note.toLocaleString());
            }

            //$('#commission').val('');

            commission();
            get_account_tariff();
        }

        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();

        if (devise_recette == 'USD' && devise_compte == 'CDF') {
            //get_exchange_rate();
        } else {
            $('#exchange_bloc').addClass('d-none');
            $('#Taux').val(taux);
        }
    });

    $('#recetteMontant').change(function() {
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();

        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);

        if (montant != "") {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if (montant > note) {
                $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else {
                var commissions = $("#commission").val();

                if (commissions != '0' && commissions != '') {
                    commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                    $('#montantTotal').val(montant.toLocaleString());
                }
                else {
                    $('#montantTotal').val(montant.toLocaleString());
                }

                $('#info').html('');
                commission();
                get_account_tariff();
            }
        }
    });

    $('#recetteDevise').change(function() {
        commission();
        get_account_tariff();
    });

    $('#service').change(function() {
        commission();
        get_account_tariff();
    });

    $('#commission').change(function() {
        var commissions = $("#commission").val();
        var devise = $('#recetteDevise').val();
        var montant = $('#recetteMontant').val();
        var totalDevise = $('#totalDevise').val();

        if (commissions != '0' && commissions != '') {
            commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));

            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
            montantA = montant;
            montant = montantA + commissions + (commissions * 0.16);

            $('#montantTotal').val(montant.toLocaleString());
        } else if (commissions == '0' || commissions == '') {
            montant = montant;
            $('#montantTotal').val(montant.toLocaleString());
        }
    });

    $('#commission').trigger('change');

    $("#pager").on("change", "#recette", function() {
        commission();
        get_account_tariff();
    });

    $("#modeId").change(function() {

        var mode = $('#modeId option:selected').val();

        if (mode == 5) {
            $('#trans_bloc').removeClass('d-none');


            $("#dateTrans").prop("disabled", false);
            $("#dateTrans").prop("required", true);
            $("#transID").val('');
            $("#labelTrans").html("R&eacute;f&eacute;rence de la transaction");
        } else {
            $('#trans_bloc').addClass('d-none');
            $("#trans_message").html('');

            $("#dateTrans").prop("disabled", true);
            $("#dateTrans").prop("required", false);
            $("#dateTrans").val("");
            $("#transID").val('');
            $("#labelTrans").html("R&eacute;f&eacute;rence de l&apos;OP");
        }
    });

    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();
        var csrf = $('input[name="csrf_name"]').val();

        var test_balance = false;

        var compte = $("#compteId").val();

        if (compte.length == 14) {
            test_balance = false;
        } else {
            test_balance = true;

        }

        if (test_balance) {
            get_account_balance(data);

        } else {

            '<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 9): ?>';
            submiter(data, 'update');
            '<?php endif; ?>';

            '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>';
            submiter(data, 'validation');
            '<?php endif; ?>';
        }

    });

    $("#confirmation_note").on('click',function(e){
        var data=$("#form").serialize();
        submiter(data,"confirmation_note");
    });

    $("#compteId").change(function() {
        get_account_tariff();
        var compte = $("#compteId").val();

        if (compte.length == 14) {
            get_accountname_internal();

        } else {
            get_accountname();
        }
    });

    $("#compteDevise").change(function() {
        var compte = $("#compteId").val();

        if (compte.length == 14) {
            get_accountname_internal();
        } else {
            get_accountname();
        }
        commission();
        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();

        if (devise_recette == 'USD' && devise_compte == 'CDF') {
            // get_exchange_rate();
        } else {
            $('#exchange_bloc').addClass('d-none');
            $('#Taux').val(taux);
        }
    });

    function get_accountname() {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();

        var core_banking = '<?php echo $core_banking; ?>';

        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';

        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name: csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if (reponse.code == '404') {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").removeClass('text-green');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Ce compte n&apos;existe pas');
                    } else if (reponse.code == '406') {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").removeClass('text-green');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Probl&egrave;me de connexion &agrave; ' + core_banking);
                    } else if (reponse.code == '405') {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").removeClass('text-green');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Le format de compte n\'est pas valide');
                    } else if (reponse.currency == null && reponse.account_name == null) {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").removeClass('text-green');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Probl&egrave;me de connexion &agrave; ' + core_banking);
                    } else if (reponse.currency != devise) {
                        $("#accountname").removeClass('text-green');
                        $("#accountname").removeClass('text-black');
                        $("#accountname").addClass('text-red');
                        $("#accountname").html('Devise du compte incorrecte');
                    } else {
                        $("#accountname").removeClass('text-black');
                        $("#accountname").addClass('text-green');
                        $("#accountname").html(reponse.account_name);
                        $("#account_name").val(reponse.account_name);
                        $("#account_currency").val(reponse.currency);
                        $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader").html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_customeraccounts() {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            //$("#labelNumber").html('');
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" style="height:15px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#labelNumber, #compteLabel").html(loader_img);

        $('#compteDevise').prop('disabled', false);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function(reponse) {

                if (reponse.code == "200") {
                    const mapped_currency = {
                        '976': 'CDF',
                        '978': 'EUR',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'compteId',
                        name: 'Compte_33',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function(index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplace l'élément actuel (input ou select)
                    if ($('#compteId').prop('tagName') === 'SELECT') {
                        $('#compteId').replaceWith(select);
                    } else {
                        $('#compteId').replaceWith(select);
                    }

                    // Déclenche le changement
                    select.trigger('change');

                    $("#compteLabel").html('Comptes du client');
                    $("#labelNumber").html('');

                } else {
                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';

                    $('#compteId').replaceWith(input_html);

                    $("#compteLabel").html('Compte du client');
                    $("#labelNumber").html('');

                    if (reponse.code == '406') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        return;
                    } else if (reponse.code == '405') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        return;
                    } else if (reponse.code == '404') {
                        $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        return;
                    }
                }
            },
            error: function() {
                $("#loader").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    $("#cancel").click(function() {
        location.reload(true);
    });

    function commission() {
        $("#loader").val('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //$("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var commission = $("#commission").val();
        var total_amount = '';
        var compte = $("#compteId").val();
        var csrf = $('input[name="csrf_name"]').val();
        var type_recette = '<?php echo (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != "") ? $encaissement->Typerecette_17 : "" ?>'

        if (montant !== '' && devise !== '' && service !== '') {
            var url = '<?php echo base_url('admin/fees/display/'); ?>default<?php echo $encaissement->Id_0 > 0 ? '/' . $encaissement->Id_0 : ''; ?>';
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    mode: mode,
                    regie: regie,
                    service: service,
                    recette: recette,
                    devise: devise,
                    montant: montant,
                    guichet: guichet,
                    compte: compte,
                    csrf_name: csrf
                },
                dataType: 'html',
                encode: true,
                success: function(reponse) {
                    var result = JSON.parse(reponse);

                    if (commission == '') {
                        if (parseFloat(result[0]) != "") {
                            // $("#commission").val(result[0]);
                            // $("#commissionDevise").val(result[1]);
                            // $("#tvaDevise").val(result[1]);
                            // $("#montantTotal").val(result[2]);

                            // $('#recetteDevise').val(result[1]);

                            // var tva=parseFloat(result[0])* 0.16;

                            // var realTva=parseFloat(tva.toFixed(2));

                            // $("#tva").val(realTva);
                            // $("#feesTva").val(realTva);
                        }
                    }
                },
                error: function(error) {
                    $('#bl').html('');
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }

    function submiter(data, obj) {

        $("#loader").val('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taximmatriculation/save'); ?>/' + obj + '<?php echo $encaissement->Id_0 > 0 ? '/' . $encaissement->Id_0 : ''; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';

        // Manage the message and the button when it's the validator or the supervisor
        var message = 'Bravo! paiement enregistr&eacute; avec succ&egrave;s !.';
        $('#enregistrer').attr("disabled",true);

        '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>'
            scrollUP();
            $('#confirmation_note').attr("disabled",true);
            message = 'Bravo! paiement valid&eacute; avec succ&egrave;s !.';
        '<?php endif; ?>'

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                let pid = result.id;
                let code = result.code;
                let msg = result.message;

                $('#loader').html('');

                if (code === 200) {
                    $('#step2').remove;
                    $("#step-2").removeClass('bg-green-active');
                    $("#step-2").addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray');
                    $("#step-3").addClass('bg-green-active');

                    $('#print').prop("disabled", false);
                    $("#enregistrer").attr('disabled',true);
                    $('#confirmation_note').attr("disabled",true);

                    $('#loader').html(`<div class="alert aSuccess text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                }
                else if (code === 300 || code === 411){

                    $("#message").html('');
                    $('#loader').html(`<div class="alert aWarning text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                    $("#enregistrer").attr('disabled',false);
                    $("#enregistrer").html('Réessayer');
                }
                else if(code===400)
                {
                    $("#message").html('');
                    $("#enregistrer").attr('disabled',true);
                    $('#confirmation_note').attr("disabled",false);

                    $("#enregistrer").attr('disabled',false);
                    $("#enregistrer").html('Réessayer');

                    $('#loader').html('<div class="alert alert-info"> ' + msg + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(code===201)
                {
                    console.log("201")
                    $("#message").html('');
                    $("#enregistrer").attr('disabled',true);
                    $('#confirmation_note').attr("disabled",true);

                    $('#loader').html('<div class="alert alert-info"> ' + msg + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {

                    $("#message").html('');
                    $('#loader').html(`<div class="alert aDanger text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                    $("#enregistrer").attr('disabled',false);
                    $("#enregistrer").html('Réessayer');
                }

                var url = '<?php echo base_url($module . '/taximmatriculation/display/preview'); ?>/' + gid;
                $.get(url, function(data, status) {
                    $("#pager").html(data);
                });

            },
            error: function(error) {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $("#enregistrer").attr('disabled',false);
                $("#enregistrer").html('Réessayer');
                $('#confirmation_note').attr("disabled",false);
            }
        });
    }


    $("#confirm_note").click(function(event) {

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taximmatriculation/save/confirmation_note/'.$encaissement->Id_0); ?>';
        var data = $("#form").serialize();
        scrollUP();
        $('#confirm_note').attr("disabled", true);
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                let pid = result.id;
                let code = result.code;
                let msg = result.message;

                $('#loader').html('');

                if (code === 200) {
                    $("#message").html('');
                    $('#loader').html(`<div class="alert aSuccess text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                }
                else if(code===201)
                {
                     $('#loader').html(`<div class="alert aInfo text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                }
                else if (code === 400) {
                    $("#message").html('');
                    $('#loader').html(`<div class="alert aWarning text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                } else {
                    $("#message").html('');
                    $('#loader').html(`<div class="alert aWarning text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
                }
            },
            error: function(error) {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    });

    $("#traiter").click(function(event) {

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taximmatriculation/save/traitement/'.$encaissement->Id_0); ?>';
        var data = $("#form").serialize();

        var gid = '<?php echo $encaissement->Id_0; ?>';
        scrollUP();

        $('#traiter').attr("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                let pid = result.id;
                let code = result.code;
                let msg = result.message;

                $('#loader').html('');

//                if (code === 200) {
//                    $("#message").html('');
//                    $('#loader').html(`<div class="alert aSuccess text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
//
//                    var url = '<?php echo base_url($module . '/taximmatriculation/display/preview'); ?>/' + gid;
//                    $.get(url, function(data, status) {
//                        $("#pager").html(data);
//                    });
//                }
//                else if(code===201)
//                {
//                     $('#loader').html(`<div class="alert aInfo text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
//                }
//                else if (code === 400) {
//                    $("#message").html('');
//                    $('#loader').html(`<div class="alert aWarning text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
//                } else {
//                    $("#message").html('');
//                    $('#loader').html(`<div class="alert aWarning text-white">${msg}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>`);
//                }
            },
            error: function(error) {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    });

    $("#closePanel").click(function() {

        closeView(controller, from);

    });

    function closeView(controller, display) {
        if (controller != '' && display != '') {
            $.get("<?php echo base_url($module . '/' . $controller . '/display/' . $from); ?>", function(data, status) {
                $("#loader").html('');
                $("#container").html(data);
            });
        } else {
            location.reload();
        }
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript" charset="utf-8">
    $("#delete").click(function() {

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var id = '<?php echo $encaissement->Id_0; ?>';

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function(isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taximmatriculation/save/deletion'); ?>/' + id;
                $.get(url, {
                    recette: recette
                }, function(result, status) {
                    var result = JSON.parse(result);

                    if (result.code === 200) {
                        $('#loader').html('<div class="alert aSuccess text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", true);
                        $('#print').prop("disabled", true);
                        $('#schema').prop("disabled", true);
                        $('#delete').prop("disabled", true);
                    } else {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
    });

    $("#print").click(function() {
        $('#enregistrer').prop("disabled", true);
        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/attestation_immatriculation'); ?>/' + ref;

        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    });

    function mail()
    {
        $("#loader").html(
            '<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />'
        );

        var id = ref;

        var url = '<?php echo base_url($module . '/taximpression/display/email_immatriculation'); ?>/' + id;

        $.get(url, function(data, status)
        {
            $('#loader').html('');
            $('#sendmail').prop("disabled", false);

            let response = JSON.parse(data);

            if (response.status == 1)
            {
                $('#loader').html(
                    '<div class="alert aSuccess text-white">' +
                    'Preuve de paiement envoy&eacute;e par mail avec succ&egrave;s !' +
                    '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>' +
                    '</div>'
                );
            }
            else
            {
                let message = response.error ?? 'Une erreur s\'est produite, veuillez reprendre.';

                $('#loader').html(
                    '<div class="alert aDanger text-white">' +
                    'Preuve de paiement non envoy&eacute;e. ' + message +
                    '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>' +
                    '</div>'
                );
            }
        })
        .fail(function()
        {
            $('#loader').html(
                '<div class="alert aDanger text-white">' +
                'Erreur serveur lors de l\'envoi du mail.' +
                '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>' +
                '</div>'
            );

            $('#sendmail').prop("disabled", false);
        });
    }

    function print() {

        $('#enregistrer').prop("disabled", true);
        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/attestation_immatriculation'); ?>/' + ref;

        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    }

    $("#schema").click(function() {

        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/schema_immatriculation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    });

    <?php if (isset($encaissement->Logirefid_4) && $encaissement->Logirefid_4 != '' && $encaissement->Logirefid_4 != 0) { ?>
        var mode = $('#modeId').val();
        if (mode === '7' || mode == '8') {
            $("#compteId").prop('disabled', '');
            $("#compteDevise").prop('disabled', '');
        }
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
    <?php } ?>

    function comptabilisation(ref) {
        var url = '<?php echo base_url($module . '/taxcomptabilisation/display/get_details_immatriculation'); ?>/' + ref;
        $.get(url, function(data, status) {
            $("#Comptabilisation").html(data);
        });
    }

    function MM_openBrWindow(theURL, winName, features) { //v2.0
        window.open(theURL, winName, features);
    }

    function get_exchange_rate() {
        var devise = $('#compteDevise').val();
        var devise_recette = $('#recetteDevise').val();
        var note_number = $('#reftitre').val();
        var csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        $('#exchange_bloc').removeClass('d-none');

        $("#exchange_message").html('<img  align="middle" style="height:15px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxrates/data/get_taux'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                devise_compte: devise,
                devise_recette: devise_recette,
                note_number: note_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function(reponse) {
                if (reponse.code == '200') {
                    $("#Taux").val(reponse.rate);
                    $('#rate_code').val('TTS');
                    $("#exchange_message").css('color', 'green');
                    $("#exchange_message").html('Taux de vente r&eacute;cup&eacute;r&eacute; avec succ&egrave;s.');
                } else if (reponse.code == '0003') {
                    $("#exchange_message").css('color', 'red');
                    $("#exchange_message").html('Probl&egrave;me de connexion &agrave; ' + core_banking + ', le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                }

            },
            error: function(error) {
                $('#loader').html('<div class="alert aWarning text-white text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function get_account_tariff() {
        var compte = $('#compteId').val();
        var regie = 'DGI';
        var csrf = $('input[name="csrf_name"]').val();
        var url = '<?php echo base_url($module . '/taxaccounts/data/get_account_tarification'); ?>';

        if (compte !== '') {
            $("#commission").html('<img  align="middle" style="height:15px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    regie: regie,
                    csrf_name: csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    if (reponse.commission >= 0) {
                        $("#commission").val(reponse.commission);
                        $("#commissionDevise").val(reponse.devise);

                        $("#infosFbcc").val(reponse.fraisbcc);
                        $("#infosTva").val(reponse.tva);

                        var commissions = reponse.commission;
                        var tva = reponse.tva;
                        var fbcc = reponse.fraisbcc;

                        commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));
                        //$('#commission').val(commissions.toLocaleString());


                        var montant = $('#recetteMontant').val();

                        var recetteDevise = $('#recetteDevise option:selected').val();


                        if (montant != "") {
                            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                            if (recetteDevise == 'USD') {
                                montant = montant * taux;

                                montant = commissions + montant + (commissions * 0.16);

                                $('#montantTotal').val(montant.toLocaleString());
                            } else if (tva == '0' && fbcc == '0') {
                                montant = commissions + montant;
                                $('#montantTotal').val(montant.toLocaleString());
                            } else if (tva == '1') {
                                montant = commissions + montant + (commissions * 0.16);
                                $('#montantTotal').val(montant.toLocaleString());
                            } else if (fbcc == '1') {
                                montant = commissions + montant + (montant * 0.0005);
                                $('#montantTotal').val(montant.toLocaleString());
                            } else {
                                montant = commissions + (montant * 0.0005) + montant + (commissions * 0.16);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                        }
                    }
                },
                error: function(error) {
                    $('#loader').html('<div class="alert aWarning text-white text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {

        }
    }

    function get_account_balance(data) {
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_compte = $('#account_currency').val();
        var devise_commission = $('#commissionDevise').val();
        var balance = $('#account_balance').val();
        var csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        var url = '<?php echo base_url($module . '/taxaccounts/data/get_account_balance_inv'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                compte: compte,
                devise: devise,
                montant: montant,
                commission: commission,
                devise_commission: devise_commission,
                devise_compte: devise_compte,
                balance: balance,
                csrf_name: csrf
            },
            dataType: 'html',
            encode: true,
            success: function(reponse) {
                if (reponse == '200') {
                    '<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 9): ?>';
                    submiter(data, 'update');
                    '<?php endif; ?>';

                    '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>';
                    submiter(data, 'validation');
                    '<?php endif; ?>';
                } else if (reponse == '300') {
                    $('#loader').html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette note de perception !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (reponse == '405') {
                    $('#loader').html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion &agrave; ' + core_banking + ', survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                $("#enregistrer").prop('disabled', false);
            },
            error: function(error) {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
</script>

<script>
    $(function() {
        const $dropdown = $('#dropdownMenu');

        // Clic sur le bouton → ouvrir/fermer le menu
        $('#dropdownToggle').on('click', function(e) {
            e.stopPropagation(); // empêche la fermeture immédiate
            $dropdown.toggle(); // ouvre/ferme
        });

        // Clic n’importe où ailleurs → ferme le menu
        $(document).on('click', function() {
            $dropdown.hide();
        });

        // Empêche fermeture si on clique à l’intérieur du menu
        $dropdown.on('click', function(e) {
            e.stopPropagation();
        });
    });
</script>