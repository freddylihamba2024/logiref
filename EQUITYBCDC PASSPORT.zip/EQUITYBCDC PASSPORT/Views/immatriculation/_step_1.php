<div class="col-md-12">
    <div class="row">
        <div class="col-md-1">
            <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">1</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">V&eacute;rification de la note<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-2" title="" class="bRound  <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">2</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">Confirmation du paiement<br/></div>
        </div>
        <div class="col-md-1">
            <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> center pull-right">3</div>
        </div>
        <div class="col-md-3">
            <div class="pull-left p-2">Impression de la preuve<br/></div>
        </div>
    </div>
</div>

<div class="col-md-12 pr-0 pl-0"><br/>
    <div id="loader"></div>
    <div id="logirad-message"></div>
</div>

<div id="pager" class="">
    <?php
        if($step==2) :
            echo view('_step_2');
        elseif($step==3):
            echo view('_step_3');
        else:
    ?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $chtml->box_body_opening("", true);?>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-4">
                        <div id="approvalWarning"></div><br/>
                        <p>
                            Renseignez le num&eacute;ro de la note de perception en suite cliquez sur suivant pour effectuer le paiement de plaque d'immatriculation !
                        </p>
                        <br/><br/>
                    </div>
                    <div class="col-md-8 bLeft">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="type">Num&eacute;ro de r&eacute;f&eacute;rence de la note</label>
                                <?php echo form_input('Reference_6','', 'class="form-control"  id="Reference_6" required = "required"'); ?>
                                <input type="hidden" name="Typerecette_12" value=""/>
                            </div>
                        </div>
                        <div class="box-footer  clearfix">
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                    <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?>
    <?php endif; ?>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    $("#mainform").submit(function(event){
        event.preventDefault();

        var data = $(this).serialize();
        next_step(data);

    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $('#Reference_6').on('input', function() {
        var currentText = $(this).val();
        var upperText = currentText.toUpperCase();
        $(this).val(upperText);
    });

    function next_step(data)
    {
        $("#loader").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . "/taximmatriculation/display/verification"); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (response) {
                    $('#loader').html('');

                    if(response.code===404)
                    {
                            $('#loader').html('<div class="alert aWarning text-white">Note de perception non trouvée!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code===405)
                    {
                            $('#loader').html('<div class="alert aWarning text-white">Cette note de perception a été déjà payé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code===407)
                    {
                            $('#loader').html('<div class="alert aWarning text-white">Note de perception trouvée mais la liste des beneficiaires est vide. Impossible de procéder au paiement<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code===406)
                    {
                            $('#loader').html('<div class="alert aWarning text-white">Cette note de perception est en attente de validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code===400)
                    {
                            $('#loader').html('<div class="alert aDanger text-white"> Alerte : Le serveur n\'a pas pu finaliser ou traiter votre requête !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code===500)
                    {
                            $('#loader').html('<div class="alert aWarning text-white">Problème de connexion : Une erreur est survenue lors du traitement de la demande...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(response.code==="SUCCESS")
                    {
                            $("#loader-sub-menu").html('');
                            $("#pager").html(response.html);
                            $("#step-1").removeClass('bg-green-active');
                            $("#step-1").addClass('bg-gray');
                            $("#step-2").removeClass('bg-gray');
                            $("#step-2").addClass('bg-green-active');
                   }

            },
            error: function (error) {
                alert("Erreur AJAX : " + error.responseText);
            }
        });
    }
</script>