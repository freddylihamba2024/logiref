<?php if(isset($service->Id_0) && $service->Id_0!='' && $service->Id_0 !=0){$feuille='innovate'; $title = "Modifier un service";}else{$feuille='innovate'; $title ="Nouveau service";}?>

    <div class="col-md-1"></div>
    <div class="col-md-9">
        <div id="loader"></div>
        <h1><?php echo $title; ?></h1>
        <p class="page-header">
            Veuillez renseigner toutes les informations pour ajouter un nouveau service. Nous vous en remercions.
        </p>
        <?php $chtml->box_body_opening('', true);?>
            <?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
                <div class="box-body">
                    <div class="col-md-4">
                        <div class="form-group">
                              <label for="Code_7">Code</label>
                              <?php echo form_input('Code_7', set_value('Code_7', $service->Code_7), 'class="form-control" required="required" maxlength="5"'); ?>
                              <input name="Id_0" type="hidden" value="<?php echo $service->Id_0; ?>" />
                        </div>    
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="Beneficiare_5">B&eacute;n&eacute;ficiaire</label>
							<?php echo form_dropdown('Direction_4', $beneficiaires, $service->Direction_4, 'class="form-control"  required="required"'); ?>
                        </div>    
                    </div>
                     <div class="col-md-4">
                        <div class="form-group">
                              <label for="Type_9">Type Service</label>
                              <?php echo form_input('Type_9', set_value('Type_9', $service->Type_9), 'class="form-control" placeholder="DGE, CDI, CIS" maxlength="10"'); ?>
                        </div>    
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                              <label for="Service_5">Service</label>
                              <?php echo form_input('Service_5', set_value('Service_5', $service->Service_5), 'class="form-control" required="required" maxlength="200"'); ?>
                        </div>    
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                              <label for="Province_8">Province fiscale</label>
                              <?php echo form_dropdown('Province_8', $provinces, $service->Province_8, 'class="form-control"  required="required"'); ?>
                        </div>    
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                              <label for="Description_6">Description</label>
                              <?php echo form_textarea(array('name' => 'Description_6', 'cols' => 40, 'rows' => 2), set_value('Description_6', $service->Description_6), 'id="description" class="form-control" maxlength="761"  required="required" '); ?>
                        </div>
                    </div>
                </div>
                <div id="continue" class="box-footer clearfix">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="buttonCloseModal" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
                    </div>
                </div>
            <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 	  
    </div>
    <div class="col-md-2">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>



<script type="text/javascript">

 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/settings/save'); ?>/service/<?php echo $service->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $service->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($service->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});


function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/services/settings'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/settings/display/services'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    
}

</script>




