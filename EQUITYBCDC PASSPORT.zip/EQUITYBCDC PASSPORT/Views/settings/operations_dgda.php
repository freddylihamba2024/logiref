<?php

    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $paiements_dgi = 0;
    #$commissions = 0;
    $suspend = 0;
    $urgent = 0;
    $i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12">

    <div class="col-md-12">
        <h2 class="text-blue f30">Archivages paiements DGDA</h2>
        <p class="page-header"><span class="text-black">Cette section vous pr&eacute;sente l'ensemble des paiements en cours de traitement et en attente d'archivage.</span></p>
    </div>

    <div class="col-md-12">
        <div  id="message"></div>

            <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($bulletins)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th width="50">Date</th>
                                <th>D&eacute;signation</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Bureau de douane</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Nif</th>
                                <th>Agence</th>
                                <th width="50">Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-trash f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php
                        #Block last BL
                        foreach($bulletins as $row){
                            $agence =  (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                            $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr id="<?php echo trim($row->Id_0);?>">
                                <td width="5"><b><?= ++$i;  ?></b></span></td>
                                <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>

                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                 <td  width=""><?php echo(isset($services['DGDA'][$row->Office_6])) ? $services['DGDA'][$row->Office_6] : "-" ?></td>
                                <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                <td class="text-blue">
                                    <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?>
                                </td>
                                <td class="text-black"><?php echo $row->Nif_9; ?></td>
                                <td width="50"><b><?php echo(isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : "-"; ?></b></td>
                                <td width="50">
                                    <?php if($row->Customercode_35 !=""):?>
                                        <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                    <?php else:?>
                                            <?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?>
                                    <?php endif;?>
                                </td>
                                <td>
                                    <a style="cursor:pointer" onclick="initialize('<?php echo $row->Id_0; ?>', '<?php echo $row->Serie_7.''.$row->Number_8; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-red fa-trash f14"> </span></a>
                                </td>
                            </tr>
                        <?php
                            $paiements = $paiements + $row->Amount_12;
                            #$commissions = $commissions + $row->Commission_26;
                            if($row->Status_2==1 ||$row->Status_2==2 ) $urgent = $urgent + 1;
                        }
                        ?>
                        </tbody>
                    </table>
                    <?php else:?>
                        <div class="col-md-12">
                            <section id="cat_list" class="text-center pt-5 pb-5">
                                <span class="d-block"><span class="fa fa-flask text-black mystyle4"></span></span>
                                <span class="d-block f13 text-black p-1">Aucun paiement trouv&eacute;!</span>
                            </section>
                        </div>
                    <?php endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?>

    </div>

</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
});

$("#contenter").unbind().on("click", ".item", function(){

        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});


$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgi').html('<?php echo number_format($paiements_dgi,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

function initialize(id, obj)
{
    swal({
        title: "ARCHIVAGE",
        text: " Voulez-vous vraiment archiver ce bulletin : " + obj + "?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText:"Non",
        confirmButtonText: "Oui",
        closeOnConfirm: true,
        confirmButtonColor: "#c9302c"
    },function(isConfirm){
        if(isConfirm) {

            $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
            var url = '<?php echo base_url($module.'/taxsettings/save/initialiasebl'); ?>/' + id;
       
            $.ajax({
                type: 'GET',
                url: url,
                dataType: 'html',
                encode: true,
                success: function(result) {
                    $.get("<?php echo base_url($module.'/taxsettings/display/operations_dgda') ?>", function (data, status) {
                        $("#container").html(data);
                        $("#message").html('<div class="alert alert-success">Bulletin supprim&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    })
                },
                error: function(error) {
                    $("#container").html(data);
                    $("#message").html('<div class="alert alert-success">Bulletin supprim&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    });
}

</script>