<?php if(isset($recette->Id_0) && $recette->Id_0!='' && $recette->Id_0 !=0){$feuille='innovate'; $title = "Modifier une recette";}else{$feuille='innovate'; $title ="Nouvelle recette";}?>


        <div class="col-md-1"></div>
        <div class="col-md-9">
            <div id="loader"></div>
            <h1><?php echo $title; ?></h1>
            <p class="page-header">
                Veuillez renseigner toutes les informations pour ajouter une nouvelle recette. Nous vous en remercions.
            </p>
            <?php $chtml->box_body_opening('', true);?>
                <?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
                    <div class="box-body">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="Code_7">Code</label>
                                <?php echo form_input('Code_7', set_value('code', $recette->Code_7), 'class="form-control" required="required" maxlength="10"'); ?>
                            </div>    
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="Recette_6">Recette</label>
                                <?php echo form_input('Recette_6', set_value('Recette_6', $recette->Recette_6), 'class="form-control" required="required" maxlength="200"'); ?>
                                <input name="Id_0" type="hidden" value="<?php echo $recette->Id_0; ?>" />
                            </div>    
                         </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Type_4">Type</label>
                                <?php echo form_dropdown('Type_4', $types, $recette->Type_4, 'class="form-control"  required="required"'); ?>
                            </div>    
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Beneficiare_5">B&eacute;n&eacute;ficiaire</label>
                                <?php echo form_dropdown('Beneficiare_5', $beneficiaires, $recette->Beneficiare_5, 'class="form-control"  required="required"'); ?>
                            </div>    
                        </div>
                    </div>
                    <div id="continue" class="box-footer clearfix">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="buttonCloseModal" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
                        </div>
                    </div>
                <?php echo form_close(); ?>
            <?php $chtml->box_body_closing(); ?> 	  
        </div>
        <div class="col-md-2">
            <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
        </div>



<script type="text/javascript">

 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/settings/save'); ?>/taxe/<?php echo  $recette->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $recette->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($recette->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/recettes/settings'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/settings/display/recettes'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    
}

</script>

