<div class="col-md-12">
        <div class="col-md-4 pull-left">
                <h1>Configurations</h1>

        </div>
        <div class="col-md-8 pull-right">
                <ul class="nav navbar-nav pull-right">
                    
                    <li class="dropdown">
                            <a class="f14 bRight" onclick="pager('guichets','branches')" id="guichet" style="cursor: pointer; background-color:rgba(0,0,0,0.04);" class="dropdown-toggle" > 
                                <i class="fa fa-bank text-green f14"></i> <span class="f13" >Agences bancaires</span>
                            </a>
                    </li>
                    <li class="dropdown">
                            <a class="f14 bRight" onclick="pager('privileges','users')" id="users" > 
                                <i class="fa fa-lock text-green f18"></i> <span class="f13" >Utilisateurs</span>
                            </a>
                    </li>
                    <li class="dropdown">
                        <a class="f14 bRight" onclick="pager('recettes','settings')" id="recettes" > 
                            <i class="fa fa-plus-circle text-green f18"></i> <span class="f13" >Recettes</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a class="f14 bRight" onclick="pager('services','settings')" id="services" > 
                            <i class="fa fa-book text-green f18"></i> <span class="f13" >Services</span>
                        </a>
                    </li>
<!--                    <li class="dropdown">
                        <a class="f14 bRight" onclick="pager('beneficiaries','settings')" id="beneficiaries" > 
                            <i class="fa fa-cloud text-green f18"></i> <span class="f13" >Beneficiaires</span>
                        </a>
                    </li>-->
                    <li class="dropdown">
                        <a class="f14 bRight" onclick="pager('villes','settings')" id="villes" > 
                            <i class="fa fa-folder-open text-green f18"></i> <span class="f13" >Villes</span>
                        </a>
                    </li>
                </ul>
        </div>
        <div class="col-md-12" style="margin-top:-8px;">
        <h5 class="page-header"><span class="text-gray" >Cette section vous pr&eacute;sente les configurations &agrave; faire.</span></h5>
        </div>
</div>
<div class="col-md-12 no-padding">
        <div id="loader" class="col-md-12"></div>
        <div id="pager">
                
        </div>
</div>



<script type="text/javascript">
 
var view = '<?= isset($view) ? $view : ""; ?>'

var controller = '<?= isset($controller) ? $controller : ""; ?>'

if(view !="")
{
    pager(view,controller);
}
else
{
    pager("guichets", "branches");
}
function pager(tab, application) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module); ?>/'+application+'/display/' + tab +'/settings';
        $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
              
                if(tab=='guichets')
                {
                    $("#guichet").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
                else if(tab=='prepayments')
                {
                    $("#prepayments").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#guichet").css('background-color', '');
                    $("#regle").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
                else if(tab=='regles')
                {
                    $("#regle").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
                else if(tab=='privileges')
                {
                    $("#users").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
		else if(tab=='recettes')
                {
                    $("#recettes").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
		else if(tab=='services')
                {
                    $("#services").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#villes").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
					
                }
		else if(tab=='beneficiaries')
                {
                    $("#beneficiaries").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#villes").css('background-color', '');
					
                }
		else if(tab=='villes')
                {
                    $("#villes").css('background-color', 'rgba(0,0,0,0.04)');
                    $("#regle").css('background-color', '');
                    $("#guichet").css('background-color', '');
                    $("#prepayments").css('background-color', '');
                    $("#users").css('background-color', '');
                    $("#recettes").css('background-color', '');
                    $("#services").css('background-color', '');
                    $("#beneficiaries").css('background-color', '');
                }
				
                
        });
}
</script>


