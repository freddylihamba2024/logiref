<?php if(isset($referentiel->Id_0) && $referentiel->Id_0!='' && $referentiel->Id_0 !=0){$feuille='innovate'; $title = "Modifier un Param&egrave;tre";}else{$feuille='innovate'; $title ="Param&egrave;tre";}?>

    <div class="col-md-1"></div>
    <div class="col-md-9">
        <div id="loader"></div>
        <h1><?php echo $title; ?></h1>
        <p class="page-header">
            Veuillez renseigner toutes les informations pour ajouter un nouveau service. Nous vous en remercions.
        </p>
        <?php $chtml->box_body_opening('', true);?>
            <?php echo form_open('', array('id' => 'mainform', 'class' => $feuille)); ?>
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Category_3">Param&egrave;tre</label>
                            <?php echo form_dropdown('Category_3', $referentiels, $referentiel->Category_3, 'class="form-control"  required="required"'); ?>
                            <input name="Id_0" type="hidden" value="<?php echo $referentiel->Id_0; ?>" />
                        </div>    
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Option_4">Nom de la ville ou la province</label>
                            <?php echo form_input('Option_4', set_value('Option_4', $referentiel->Option_4), 'class="form-control" placeholder="" required="required" maxlength="10"'); ?>
                        </div>    
                    </div>
                   
                </div>
                <div id="continue" class="box-footer clearfix">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="buttonCloseModal" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
                    </div>
                </div>
            <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 	  
    </div>
    <div class="col-md-2">
        <a id="cancel" class="btn btn-app no-border pull_left" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>



<script type="text/javascript">

 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/settings/save'); ?>/parametre/<?php echo $referentiel->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $referentiel->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($referentiel->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
    
    var from = '<?= isset($from) ? $from : ""; ?>'   
    
    if(from !="")
    {
        $.get("<?php echo base_url($module.'/settings/display/settings/villes/settings'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    else
    {
        $.get("<?php echo base_url($module.'/settings/display/villes'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    }
    
}

</script>




