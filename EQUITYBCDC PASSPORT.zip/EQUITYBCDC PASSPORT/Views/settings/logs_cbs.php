 <?php if(!empty($logs)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th width="10px">#</th>
                <th width="">Date</th>
                <th width="">Nombre des paiements</th>
                <th width="">Retour</th>
                <th width="150px">Montant</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $i = 0;
            foreach($logs as $row){
            ?>
            <tr>
                <td><?php echo ++$i; ?></td>
                <td><?php echo $row->Journee_12; ?></td>
                <td><?php echo $row->Nombrepaiement_7; ?></td>
                <td><?php echo $row->Retourcbs_15; ?></td>
                <td><?php echo $row->Devise_9.' '.number_format($row->Montant_8,2,","," "); ?></td>
            </tr>
            <?php } ?>
        </tbody>    
    </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter min-height-20pct">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucune int&eacute;gration trouv&eacute;e!</b></h4>
        </div>
    </section>
<?php endif;?>

