<?php if(!empty($logs)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th width="10px">#</th>
                <th width="">Date</th>
                <th width="">Journ&eacute;e</th>
                <th width="">Designation</th>
                <th width="150px">Montant</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $i = 0;
            foreach($logs as $row){
            ?>
                <tr>
                    <td><?php echo ++$i; ?></td>
                    <td><?php echo $row->Date_1; ?></td>
                    <td><?php echo $row->Journee_13; ?></td>
                    <td><?php echo $row->Designation_14; ?></td>
                    <td><?php echo 'CDF '.number_format($row->Montant_8,2,","," "); ?></td>
                </tr>
            <?php } ?>
        </tbody>    
    </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter min-height-20pct">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucune int&eacute;gration trouv&eacute;e!</b></h4>
        </div>
    </section>
<?php endif;?>

