<div  id="pager">
    <div class="col-md-12">
        <h2 class="text-blue">Logs des int&eacute;grations</h2>
        <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente les logs des diff&eacute;rentes int&eacute;grations.</span></h5>
    </div>
    <div class="col-md-12" id='alert'><?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?></div>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-12 no-padding">
                <div class="col-md-4">
                    <?php $chtml->box_body_opening("", false); ?>
                        <div class="col-md-12 no-padding">
                            <ul class="nav nav-pills nav-stacked">
                                <li id=''><a onclick="view('sydonia')" ><i class="fa fa-minus"></i>Int&eacute;grations SYDONIA</a></li>
                                <li id=''><a onclick="view('isys')"><i class="fa fa-minus"></i>Int&eacute;grations ISYS</a></li>
                            </ul>
                        </div>
                    <?php $chtml->box_body_closing(); ?>
                </div>
                <div class="col-md-4">
                    <?php $chtml->box_body_opening("", false); ?>
                        <div class="col-md-12 no-padding">
                            <ul class="nav nav-pills nav-stacked">
                                <li id=''><a onclick="action()" ><i class="fa fa-minus"></i>Int&eacute;grations CBS</a></li>
                                <li id=''><a onclick="action()"><i class="fa fa-minus"></i>Int&eacute;grations RTGS</a></li>
                            </ul>
                        </div>
                    <?php $chtml->box_body_closing(); ?>
                </div>
                <div class="col-md-4">
                    
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" >
function view(which)
{
        if(which === 'sydonia')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/settings/display/sydonia'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                });
        }
        if(which === 'isys')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/settings/display/isys'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                });
        }
        if(which === 'cbs')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/settings/display/rtgs'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                });
        }
        if(which === 'rtgs')
        {
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                $.get("<?php echo base_url($module.'/settings/display/cbs'); ?>", function (data, status) {
                   $("#loader").html('');
                   $("#pager").html(data);
                });
        }
}

function action()
{
        $("#alert").html('<div class="alert alert-warning"> D&eacute;sol&eacute;, ce type de rapport n\'est pas encore disponible ! Merci.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
}
</script>
