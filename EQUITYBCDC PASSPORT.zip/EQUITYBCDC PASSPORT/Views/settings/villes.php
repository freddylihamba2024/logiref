<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
    <div class="col-md-10">

        <div class="col-md-12 <?= $title; ?>" >
                <h1>Entit&eacute;s administratives</h1>
                <h5 class="page-header"><span class="text-gray">Ce r&eacute;f&eacute;rentiel des administratifs est mis &agrave; automatiquement et synchronis&eacute; avec le r&eacute;f&eacute;rentiel de la Banque Central du Congo.</span></h5>
        </div>

        <div class="col-md-12">
            <div id="loader"></div>
        </div>
        <div class="col-md-12">
            <?php $chtml->box_body_opening('', true); ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-blue">
                            <th>Entit&eacute;</th>
                            <th>Nom</th>
                            <th>Maker</th>
                            <th>Checker</th>
                            <th width="80">Validation</th>
                            <th><span class="fa fa-fw fa-edit f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($villes)): ?>
                            <?php foreach($villes as $row){ ?>
                                <tr>
                                    <td><b><?php echo $row->Category_3; ?></b></td>
                                    <td><?php echo $row->Option_4; ?></td>
                                    <td><?php echo (isset($users[$row->Makerid_6]))? $users[$row->Makerid_6] :' - ';?></td>
                                    <td><?php echo (isset($users[$row->Checkerid_8]))? $users[$row->Checkerid_8] :' - ';?></td>
                                    <td width="80">
                                            <?php if($row->Checkerid_8==0){ ?>
                                              <span class="text-red"> En attente </span>
                                            <?php }else {?>
                                              <?php echo $row->Validation_7;?>
                                            <?php } ?>
                                    </td>
                                    <td width="15" align="right">
                                            <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2){ ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                            <?php }else {?>
                                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                            <?php } ?>
                                    </td>
                                </tr>
                                <?php } ?>
                        <?php endif;?>
                        <?php if(!empty($provinces)): ?>
                            <?php foreach($provinces as $row){ ?>
                                <tr>
                                    <td><b><?php echo $row->Category_3; ?></b></td>
                                    <td><?php echo $row->Option_4; ?></td>
                                    <td><?php echo (isset($users[$row->Makerid_6]))? $users[$row->Makerid_6] :' - ';?></td>
                                    <td><?php echo (isset($users[$row->Checkerid_8]))? $users[$row->Checkerid_8] :' - ';?></td>
                                    <td width="80">
                                            <?php if($row->Checkerid_8==0){ ?>
                                              <span class="text-red"> En attente </span>
                                            <?php }else {?>
                                              <?php echo $row->Validation_7;?>
                                            <?php } ?>
                                    </td>
                                    <td width="15" align="right">
                                            <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2){ ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                            <?php }else {?>
                                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                            <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php endif;?>
                    </tbody>    
                </table>
            <?php $chtml->box_body_closing(); ?> 
        </div>
    </div>
    <div class="col-md-2">
        <div class="col-md-12 <?= $title; ?>">
            <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
            <br/><br/>
        </div>
    </div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/settings/display/referentiel'); ?>", function (data, status) {    
           $("#loader").html('');
           $("#container").html(data);
        });
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/settings/display/referentiel'); ?>/' + id +'/<?php echo $from ?>';
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
      });
}

</script>

