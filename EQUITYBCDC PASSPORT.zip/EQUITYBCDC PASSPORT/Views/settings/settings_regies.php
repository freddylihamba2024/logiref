<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div id="pager" class="content">
    <div class="col-md-10">
        <div class="<?= isset($props) ? $props : "" ?>">
            <h1><i class="fa fa-key f35 text-green"></i>&nbsp;&nbsp;<span class="text-blue">Plateformes des r&eacute;gies</span></h1>
            <?php $chtml->box_body_opening('', true); ?>
                    <table  class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th>Syst&egrave;me</th>
                                <th></th>
                                <th width="10px"><span class="fa fa-fw fa-edit f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td >Sydinia</td>
                                <td width="5"></td>
                                <td width="25" align="right">
                                   <a style="cursor:pointer" onclick="sydonia()" ><span class="fa fa-fw text-green fa-cog f14"> </span></a>
                                </td>
                            </tr>
                        </tbody>    
                    </table>
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>
</div>

<script type="text/javascript">
//************************************************************

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

//What to show or not
$('#GroupEditBox').css( "display", "none");
$('.direct-chat-msg').css("display", "none");

function sydonia()
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module.'/settings/display/sydonia_account'); ?>", function(data, status) {
        $("#loader").html('');
        $("#container").html(data);
        });
}

</script>
