<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div id="pager" class="content">
    <div class="col-md-10">
        <div id="loader"></div>
        <div>
            <h1><i class="fa fa-cog f35 text-green"></i>&nbsp;&nbsp;<span class="text-blue">Les adresses IP bloqu&eacute;es</span></h1>
            <?php $chtml->box_body_opening('', true); ?>
                    <?php if(!empty($list)): ?>
                    <table  class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th width="2%">#</th>
                                <th width="20%">Date</th>
                                <th width="20%">Nom de l'utilisateur</th>
                                <th>adresse ip</th>
                                <th width="3%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                    $i=1;
                                    foreach($list as $row){
                            ?>
                            <tr id="<?php echo trim($row->Id_0); ?>">
                                <td><?php echo $i++; ?></td>
                                <td><?php echo $row->Date_1; ?></td>
                                <td width=""><?= isset($users[$row->Userid_9]) ? $users[$row->Userid_9] : "Utilisateur inconnu"; ?></td>
                                <td><?php echo $row->Ip_7; ?></td>
                                <td width="" align="right">
                                   <a style="cursor:pointer" onclick="remove('<?php echo $row->Id_0; ?>', '<?php echo $row->Ip_7; ?>')" type="button" class="btn-xs btn-success" >D&eacute;bloquer</a>
                                </td>
                            </tr>
                            <?php 
                                    }
                            ?>
                        </tbody>    
                    </table>
                    <?php else: ?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            Aucune adresse trouv&eacute;e !<br/>
                            </div>
                        </section>
                    <?php endif;?>
                    
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>
</div>

<script type="text/javascript">
//************************************************************

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

function remove(id, obj){
    var cHtml = '<div class="alert alert-warning text-black" style="width:96%; position:absolute;display:block; z-index:10000"> Voulez-vous vraiment d&eacute;bloquer cette adresse ip : "' + obj + '"?<br/> <button class="btn btn-primary btn-flat" type="button" id="delYes">Oui</button> <button class="btn btn-gray btn-flat" type="button" id="delNo">Non</button><br/><br/></div>';
    var dHtml = $("#"+ id ).html();
    $("#"+ id ).html('');
    $("#"+ id ).html(cHtml);
    $("#delYes").click(function(){
          $("#"+ id ).html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
          var url = '<?php echo base_url($module.'/settings/save/delete'); ?>/' + id;
          $.get(url, {object:'ipadress'}, function(data, status){
              $("#"+ id ).html('');
              $("#loader").html(data);
              $('#' + id ).remove();
              
              $.get("<?php echo base_url($module.'/settings/display/ipaddress') ?>", function (data, status) {
                    $("#container").html(data);
                    $("#loader").html('<div class="alert alert-success">Adresse ip d&eacute;bloqu&eacute;e avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                })
          });
    });
    $("#delNo").click(function(){
          $("#"+ id ).html('');
          $("#"+ id ).html(dHtml);
    });
}

</script>
