<?php

if($identifiants->Id_0 != "")
{
        $action = "Modifier";
}
else
{
        $action = "Enregistrer";
}

?>
<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="loader"></div>
    <h1>Configuration de la connexion &agrave; isys</h1>
    <span class="page-header">
    </span>
    <?php $chtml->box_body_opening('', true);?>
        <div class="col-md-3 center padding-20 bRight">
            <div class="col-md-12 center">
                <p class="page-header">
                    <br/><br/>Remplissez les champs recquis respectivement par votre identifiant et mot de passe de votre compte isys
                </p> 
            </div>
        </div>
        <div class="col-md-9">
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                <div class="box-body">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="year">Identifiant</label> 
                            <?php echo form_input('identifiant',$identifiants->Login_7, 'class="form-control"  required = "required"'); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="year">Mot de passe</label> 
                            <?php echo form_password('password',$identifiants->Password_8, 'class="form-control"  required = "required"'); ?>
                        </div>
                    </div>
                </div>
                <div id="details" class="col-md-12"></div>
                <div class="box-footer clearfix">
                    <div class="col-md-12">
                        <button type="submit" id='envoyer' class="btn btn-primary pull-left" ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php echo $action;?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp; Quitter &nbsp;</button>
                    </div>
                </div>
            <?php echo form_close(); ?>
        </div>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="col-md-1">
    <a id="close" class="btn btn-app no-border pull_right" href="#"><span class="fa fa-fw fa-times text-gray f40"></span></a>
</div>

<script type="text/javascript">
$("#mainform").submit(function(event){
    
    event.preventDefault();

        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/settings/save/account_isys'); ?>/<?php echo $identifiants->Id_0; ?>';
        var data = $(this).serialize();
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#loader').html(result);
                },
                error:function(error){
                        alert('ERROR!' + error);
                }
        });
});

$("#close").click(function(){
    quit();
});

$("#cancel").click(function(){
    quit();
});
function quit(){
    
        $.get("<?php echo base_url($module.'/settings/display/settings_bcc'); ?>", function(data, status){
        $("#loader").html('');
        $("#container").html(data);
        });
}
</script>