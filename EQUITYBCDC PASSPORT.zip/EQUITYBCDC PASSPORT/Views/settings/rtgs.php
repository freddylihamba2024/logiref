<div class="col-md-11">
     <div class="col-md-12">
            <?php $chtml->box_body_opening("", true); ?>
                <div class="statistic-box no-border">
                    <div class="col-sm-6 col-xs-12">
                        <h1>Int&eacute;grations RTGS</h1>
                    </div>
                    <div class="col-sm-2 col-xs-3">
                        <div class="description-block">
                            <a  style="cursor: pointer" onclick="action('sites')" class="bg-default text-gray">
                                <b><br/><br/><span id="total" class="description-percentage f30 blue"></span></b>
                                <span class="description-text text-gray"></span>
                            </a>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-2 col-xs-3">
                        <div class="description-block">
                            <a  style="cursor: pointer" onclick="action('stores')" class="bg-default text-yellow">
                                <b><br/><br/><span id="deadline" class="description-percentage f30 ">  </span></b>
                                <span class="description-text text-yellow"></span>
                            </a>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-2 col-xs-3">
                        <div class="description-block">
                            <a  style="cursor: pointer" onclick="action('stores')" class="bg-default ">
                                <b><br/><br/><span id="deadline" class="description-percentage f30 ">  </span></b>
                                <span class="description-text text-blue"></span>
                            </a>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-12 col-xs-3">
                        <form role="form" id="filter" class="form-inline pull-right  bg-white col-md-12 former-10-normal">
                            <div class="col-md-6">
                                <div class="form-group">  
                                    <div class="input-group">
                                        <span class="input-group-addon"><b>Statut </b></span><?php echo form_dropdown('Status_2', $sites=array(), '', 'class="form-control" '); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <div class="input-daterange input-group">
                                        <span class="input-group-addon">Initi&eacute;e entre le</span>
                                        <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                        <span class="input-group-addon">et le</span>
                                        <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <button class="btn btn-bitbucket" style="margin-bottom:4px;" type="submit">Extraire <i class="fa fa-fw fa-search text-gray"></i></button><br/>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-12 col-xs-3">
                        <h5 class="page-header">
                        </h5>
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>
    <div class="col-md-12">
        <div id="loader"></div>
    </div>
    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($logs)): ?>
                <div id="list">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th width="10px">#</th>
                                <th width="">Date</th>
                                <th width="">Journ&eacute;e</th>
                                <th width="80px">B&eacute;n&eacute;ficiare</th>
                                <th width="">Type recette</th>
                                <th width="">Designation</th>
                                <th width="150px">Montant</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i = 0;
                            foreach($logs as $row){
                            ?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row->Date_1; ?></td>
                                    <td><?php echo $row->Journee_12; ?></td>
                                    <td><?php echo $row->Beneficiaire_9; ?></td>
                                    <td><?php echo $row->Typerecette_11; ?></td>
                                    <td><?php echo $row->Designation_13; ?></td>
                                    <td><?php echo 'CDF '.number_format($row->Contrevaleur_15,2,","," "); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>    
                    </table>
                </div>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter min-height-20pct">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Aucune int&eacute;gration trouv&eacute;e!</b></h4>
                    </div>
                </section>
            <?php endif;?>
        <?php $chtml->box_body_closing(); ?>
    </div>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$('#datepicker1').datepicker({
        format: 'yyyy-mm-dd'
});

$('#datepicker2').datepicker({
        format: 'yyyy-mm-dd'
});


$("#filter").submit(function(e){
        e.preventDefault();
        $("#list").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var data = $(this).serialize();
        var url = '<?php echo base_url($module.'/settings/display/filter_rtgs'); ?>'; 
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                        $('#list').html(result);
                    },
                    error:function(error){
                        alert('ERROR:'+error);
                    }

        });
});
</script>
