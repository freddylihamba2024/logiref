<?php if(!empty($logs)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th width="10px">#</th>
                <th width="">Date</th>
                <th width="">Statut</th>
                <th width="150px">Montant</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $i = 0;
            foreach($logs as $row){
            ?>
                <tr>
                    <td><?php echo ++$i; ?></td>
                    <td><?php echo $row->Integration_16; ?></td>
                    <td><?php echo(isset($status[$row->Error_14]))? $status[$row->Error_14] :' - '; ?></td>
                    <td><?php echo 'CDF '.number_format($row->Amount_12,2,","," "); ?></td>
                </tr>
            <?php } ?>
        </tbody>    
    </table>
<?php else: ?>
    <section>
        <div class="row fontawesome-icon-list  f14 tCenter min-height-20pct">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <h4 align="center"><b>Aucune int&eacute;gration trouv&eacute;e!</b></h4>
        </div>
    </section>
<?php endif;?>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});
</script>