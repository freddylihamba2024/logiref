        <?php $userid = $this->session->userdata["user_id"]; ?>
    <?php $usertype = $this->session->userdata["user_type"];?>

    <div class="col-md-10">
        <div class="col-md-12 <?= $title; ?>" >
            <h1><span class="text-blue">R&eacute;f&eacute;rentiel des recettes</span></h1>
            <h5 class="page-header">
                Ce r&eacute;f&eacute;rentiel des recettes (taxes et autres) est mis &agrave; automatiquement et synchronis&eacute; avec le r&eacute;f&eacute;rentiel de la Banque Central du Congo.
            </h5>
        </div>

        <div class="col-md-12">
            <div id="loader"></div>
        </div>
        <div class="col-md-12">
                <?php if(!empty($recettes)): ?>
                    <?php $chtml->box_body_opening('', true); ?>
                        <table id="table" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-blue">
                                    <th width="20">#</th>
                                    <th width="100">B&eacute;n&eacute;ficiaires</th>
                                    <th>Recette</th>
                                    <th width="250">Type</th>
                                    <th>Maker</th>
                                    <th>Checker</th>
                                    <th width="80">Validation</th>
                                    <th width="20"><span class="fa fa-fw fa-edit f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            foreach($recettes as $row){
                            ?>
                                <tr>
                                    <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD' || $row->Type_4=='PROPRE' || $row->Type_4=='RFPROPD' )  echo '<span class="text-blue">'.$row->Code_7.'</span>'; else echo ''.$row->Code_7.''; ?></span></td>
                                    <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$row->Beneficiare_5.'</span>'; else echo ''.$row->Beneficiare_5.''; ?></span></td>
                                    <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$row->Recette_6.'</span>'; else echo ''.$row->Recette_6.''; ?></span></td>
                                    <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$types[$row->Type_4].'</span>'; else echo ''.$types[$row->Type_4].''; ?></span></td>

                                    <td><?php echo (isset($users[$row->Makerid_8]))? $users[$row->Makerid_8] :' - ';?></td>
                                    <td><?php echo (isset($users[$row->Checkerid_10]))? $users[$row->Checkerid_10] :' - ';?></td>
                                    <td width="80">
                                            <?php if($row->Checkerid_10==0){ ?>
                                              <span class="text-red"> En attente </span>
                                            <?php }else {?>
                                              <?php echo $row->Validation_9;?>
                                            <?php } ?>
                                    </td>
                                    <td width="15" align="right">
                                            <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2){ ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                            <?php }else {?>
                                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                            <?php } ?>
                                    </td>

                                </tr>
                            <?php } ?>
                            </tbody>    
                        </table>
                    <?php $chtml->box_body_closing(); ?> 
                <?php else: ?>
                    <section>
                        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            <h4 align="center"><b>Aucune Recette ajout&eacute;e.</b></h4>
                            Veuillez renseigner les information pour enregistrer une recette.
                            <br/>
                        </div>
                    </section>
                <?php endif;?>
            </div>
    </div>
    <div class="col-md-2">
        <div class="col-md-12 <?= $title; ?>">
            <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
            <br/><br/>
        </div>
    </div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#add").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/settings/display/recette'); ?>", function (data, status) {
           $("#loader").html('');
           $("#container").html(data);
        });
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      var url = '<?php echo base_url($module.'/settings/display/recette'); ?>/' + id +'/<?php echo $from ?>';
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#container").html(data);
      });
}
</script>
