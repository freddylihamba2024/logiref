<?php $maker = $encaissement->Makerid_9;
$feuille = '';
$infos = $Infos = json_decode($encaissement->Notereference_30, true);
$disabled = "disabled"; ?>


<?php if ($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11, 2, ",", " "); ?>
<?php if ($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28, 2, ",", " "); ?>
<?php if ($_SESSION['Logiref_role'] == 4 && $maker == $userid && $encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == 0) $feuille = ''; ?>

<?php
if (isset($_SESSION['Bank_rates'])) :
    $taux = json_decode($_SESSION['Bank_rates'], true);
else :
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if (!isset($infos['totalMontant'])) {
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = $encaissement->Devise_12;
}
?>

<?php echo form_open('', array('id' => 'form', 'class' => $view)); ?>
<style>label {min-width: 150px !important; }</style>
<?php $chtml->box_body_opening('', true); ?>
<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
<input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
<?php $chtml->box_body_opening('', true); ?>

<div class="box-body">
    <div class="row">
        <div class="col-md-12">
            <h2 class=" f20  w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" id="loader"></div>
    </div>

    <!------------------------- Beneficiare  ------------------------------>
    <div class="row">
        <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15" class="f12">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" required="required"  '); ?>
                <?php if($encaissement->Id_0 !=NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-7 ">
            <div class="input-group flex-nowrap" id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16" class="f12"><div id="ServiceId">Service recouvrement</div></label> 
                </span>

                <div class="overflow-hidden flex-grow-1">
                    <span id="slist"><?php echo form_dropdown('Service_16', $services, $encaissement->Service_16 , 'class="form-control chosen-select" id="service"  required="required" '); ?></span>
                </div>
            </div>
        </div> 
    </div> 
    <!-------------------------  Titre de perception  ------------------------------>
    <div class="row">
        <div class="col-md-12"><br/><label class="f12 text-black"><b>Partie 2 : Titre de paiement</b></label><br/></div>
    </div>
    <div class="row">
        <div class="col-md-5  small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26" class="f12"><div id="TitreId">Num&eacute;ro</div></label> 
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-7  small-box">
           <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25" class="f12">Document</label> 
                </span>
                <?php echo form_input('Notetype_25', set_value('Notetype_25', $documents[5]), 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                <input type="hidden" name="Notetype_25" value="5">
            </div>
        </div>
    </div>
    <div class="row"><div id="bl" class="col-md-12"></div></div>
    <div class="row">
        <div class="col-md-5  small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27" class="f12">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-7  small-box">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17" class="f12">Nature paiement</label> 
                </span>
                <?php echo form_dropdown('Typerecette_17', $recettes, 'AMRA', 'class="form-control bg-gray" id="recette" disabled required="required" '); ?>
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17; ?>" />
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard" class="f12">Référence AMR-A</label> 
                </span>
                <?php if(isset($Infos['reference_amr_b']) && $Infos['reference_amr_b'] !="") : ?>
                    <?php echo form_input("Infos[reference_amr_a]", set_value("Infos[reference_amr_a]", $Infos['reference_amr_a']), ' class="form-control"  required="required" '); ?>
                <?php else : ?>
                    <?php echo form_input("Infos[reference_amr_a]", set_value("Infos[reference_amr_a]", ''), ' class="form-control"  required="required" '); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28" class="f12">Montant AMR-A</label> 
                </span>
                <?php if(isset($encaissement->Notemontant_28) && $encaissement->Notemontant_28 != ""): ?>
                    <?php echo form_input('Notemontant_28', set_value('Notemontant_28', $encaissement->Notemontant_28), ' id="montant_amr_a" class="form-control" required="required"'); ?>
                <?php else: ?>
                    <?php echo form_input('Notemontant_28', set_value('Notemontant_28', 0), ' id="montant_amr_a" class="form-control" required="required"'); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php if(isset($encaissement->Notedevise_29) && $encaissement->Notedevise_29 !=""): ?>
                    <?php echo form_dropdown('Notedevise_29', array(''=>'', 'CDF'=>'CDF'), $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
                <?php else: ?>
                    <?php echo form_dropdown('Notedevise_29', array(''=>'', 'CDF'=>'CDF'), '', 'class="form-control" id="deviseNote"  required="required"'); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard" class="f12">Référence AMR-B</label> 
                </span>
                <?php if(isset($Infos['reference_amr_b']) && $Infos['reference_amr_b'] !="") : ?>
                    <?php echo form_input("Infos[reference_amr_b]", set_value("Infos[reference_amr_b]", $Infos['reference_amr_b']), ' class="form-control"  required="required" '); ?>
                <?php else : ?>
                    <?php echo form_input("Infos[reference_amr_b]", set_value("Infos[reference_amr_b]", ''), ' class="form-control"  required="required" '); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28" class="f12">Montant AMR-B</label> 
                </span>
                <?php if(isset($Infos['montant_amr_b']) && $Infos['montant_amr_b'] !=""): ?>
                    <?php echo form_input("Infos[montant_amr_b]", set_value("Infos[montant_amr_b]", $Infos['montant_amr_b']), ' id="montant_amr_b" class="form-control" required="required"'); ?>
                <?php else: ?>
                    <?php echo form_input("Infos[montant_amr_b]", set_value("Infos[montant_amr_b]", "0"), ' id="montant_amr_b" class="form-control" required="required"'); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php if(isset($Infos['devise_amr_b']) && $Infos['devise_amr_b'] !=""): ?>
                    <?php echo form_dropdown("Infos[devise_amr_b]", array(''=>'', 'CDF'=>'CDF'), $Infos['devise_amr_b'], 'class="form-control" id="devise_amr_b"  required="required"'); ?>
                <?php else: ?>
                    <?php echo form_dropdown("Infos[devise_amr_b]", array(''=>'', 'CDF'=>'CDF'), '', 'class="form-control" id="devise_amr_b"  required="required"'); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Infos[Motif]" class="f12">Motif de paiement</label> 
                </span>
                <?php if(isset($Infos['Motif']) && $Infos['Motif'] !=""): ?>
                    <?php echo form_input("Infos[Motif]", set_value("Infos[Motif]", $Infos['Motif']), ' id="" class="form-control" required="required" '); ?>
                <?php else: ?>
                    <?php echo form_input("Infos[Motif]", set_value("Infos[Motif]", ''), ' id="" class="form-control" required="required" '); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Total" class="f12">Montant total</label> 
                </span>
                <?php if(isset($Infos['total_montant_amr']) && $Infos['total_montant_amr'] !=""): ?>
                    <?php echo form_input("Infos[total_montant_amr]", set_value('Infos[total_montant_amr]', $Infos['total_montant_amr']), 'class="form-control " id="total_montant_amr" required="required"'); ?>
                <?php else: ?>
                    <?php echo form_input("Infos[total_montant_amr]", set_value('Infos[total_montant_amr]', ''), 'class="form-control " id="total_montant_amr" required="required"'); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php if(isset($Infos['total_devise_amr']) && $Infos['total_devise_amr'] !=""): ?>
                    <?php echo form_dropdown("Infos[total_devise_amr]", array(''=>'', 'CDF'=>'CDF'), $Infos['total_devise_amr'], 'class="form-control"  required="required" id="total_devise_amr"'); ?>
                <?php else: ?>
                    <?php echo form_dropdown("Infos[total_devise_amr]", array(''=>'', 'CDF'=>'CDF'), '', 'class="form-control"  required="required" id="total_devise_amr"'); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!------------------------- Payment  ------------------------------>
    <div class="row">
        <div class="col-md-5"><br /><span class="f12 text-black"><b>Partie 3 : Client, Assujetti ou Contribuable.</b></span></div>
        <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><span id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span  id="accountname"></span></span></div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Nif_13" class="f12">Num&edot;ro imp&ocirc;t</label> 
                </span>
                <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div> 
        <div class="col-md-7 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Designation_14" class="f12">D&eacute;signation</label> 
                </span>
                <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard" class="f12">Ech&eacute;ance</label> 
                </span>
                <?php if(isset($Infos['standard']) && $Infos['standard'] !="") : ?>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $Infos['standard']), ' class="form-control" id="datepicker3" required="required" maxlength="25"'); ?>
                <?php else : ?>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", ''), ' class="form-control" id="datepicker3" required="required" maxlength="25"'); ?>
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-7 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Taux_41" class="f12">Taux de change</label> 
                </span>
                <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 small-box">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Mode_19" class="f12">Mode de paiement</label> 
                </span>
                <?php echo form_dropdown('Mode_19', $modes, isset($encaissement->Mode_19) ? $encaissement->Mode_19 : '', 'class="form-control" required="required" id="modeId"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                   <label for="Datevaleur_31" class="f12">Date paiement</label>
                </span>
                <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Reference_32" class="f12">R&eacute;f&eacute;rence de l&apos;OP</label>
                </span>
                <?php echo form_input('Reference_32', set_value('Reference_32', isset($encaissement->Reference_32) ? $encaissement->Reference_32 : ''), 'class="form-control"'); ?>
            </div>
        </div> 
        <div class="col-md-5 small-box">
            <div class="input-group"> 
                <span class="input-group-addon">
                    <label for="Compte_33" class="f12"><div id="compteLabel">Compte du client</div></label> 
                </span>
                <?php echo form_input('Compte_33', set_value('Compte_33',  isset($encaissement->Compte_33) ? $encaissement->Compte_33 : '' ), 'class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Commission_23" class="f12"><div id="commiision">Commission</div></label>
                </span>
                <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" required="required"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Total" class="f12">Total à payer + TVA</label> 
                </span>
                <?php if(isset($Infos['totalMontant']) && $Infos['totalMontant'] !="") : ?>
                    <?php echo form_input("Infos[totalMontant]", set_value('Infos[totalMontant]', $Infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
                <?php else:  ?>
                    <?php echo form_input("Infos[totalMontant]", set_value('Infos[totalMontant]', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                <?php endif;  ?>
            </div>
        </div>
        <div class="col-md-2 small-box">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Devise_34', array(''=>'', 'CDF'=>'CDF'), isset($encaissement->Devise_34) ? $encaissement->Devise_34 : '', 'class="form-control"  required="required" id="compteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Devise_24', array(''=>'', 'CDF'=>'CDF'), $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                    <?php echo form_dropdown("Infos[totalDevise]", array(''=>'', 'CDF'=>'CDF'), 'CDF', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
            </div>
        </div>
    </div>
    <!------------------------- Repartitions  ------------------------------>
    <div class="row>"
        <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
    </div>
    <div class="row">
        <div id="Comptabilisation" class="col-md-12"></div>

    </div>

    <!-------------------------  END  ------------------------------>
</div>
<div class="box-footer clearfix">
    <div class="row">
        <div id="createPaiement" class="col-md-12">
        <!-------------------------  No valider  ------------------------------>
        <?php if ($encaissement->Checkerid_10 == 0 && ($maker == $userid || $_SESSION['Logiref_role'] != 4)) : ?>
            <?php if ($_SESSION['Logiref_role'] != 5) { ?>
                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Valider";
                  else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php } ?>
            <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>
        
        <!-------------------------  Valider  ------------------------------>
        <?php if ($encaissement->Checkerid_10 > 0 && ($maker == $userid || $_SESSION['Logiref_role'] != 4)) : ?>
            <button type="submit" disabled="" class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Valider";
              else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" disabled="" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;~Supprimer ce paiement&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>
        <?php if ($encaissement->Checkerid_10 > 0) { ?>
            <button type="button" id="print" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
        <?php } ?>
        
        <a id="" type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
    </div>

    </div>
</div>

<?php $chtml->box_body_closing(); ?>
<?php echo form_close(); ?>

<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript" charset="utf-8">
    var ref = '<?php echo $encaissement->Id_0; ?>';

    var controller = '<?php echo isset($controller) ? $controller : ""; ?>';
    var from = '<?php echo isset($from) ? $from : ""; ?>';

    var montant_total = '';

    $("#contenter").on("click", "#close_form", function() {
        close_form();
    });
    
    get_accountname();

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
        todayHighlight: true,
        format: 'mm-yyyy'
    });
    
    
    $("#pager").on("change", "#quota_dgi", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_onem", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_inpp", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_inss", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_tresor", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $("#pager").on("change", "#montant_hologramme", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $("#pager").on("change", "#montant_sonas", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $('#montantNote').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_dgi", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_syntell", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_utsch", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_rtnc", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $('#recetteMontant').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#commission').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#montantNote').change(function(){
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        
        $('#montantNote').val(note);
        $('#recetteMontant').val(note);
        
        if(note !="")
        {
            
            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                note = note.toFixed(2);
                $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#rate_code').val('TTB');
                note = note.toFixed(2);
                $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');
            commission();
        }
    });

    $('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(devise == 'USD')
            {
                note = note * taux;
                note = note.toFixed(2);
                if(note) $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#rate_code').val('TTB');
                note = note.toFixed(2);
                if(note) $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');

            commission();
        }
        
    });

    $('#recetteMontant').change(function(){
    
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);
        
        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                    $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else
            {
                    var commissions = $("#commission").val();

                    if(commissions !='0' && commissions !='')
                    {
                            commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                            if(deviseNote=='USD')
                            {
                                montant = montant * taux;

                                montant = commissions + montant + (commissions *0.16);
                                montant = montant.toFixed(2);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                montant = montant.toFixed(2);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }
                    else
                    {
                            if(recetteDevise == 'USD')
                            {
                                montant = montant * taux;
                                montant = montant.toFixed(2);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                            else
                            {
                                montant = montant.toFixed(2);
                                $('#montantTotal').val(montant.toLocaleString());
                            }
                    }

                    $('#info').html('');
                    commission();
            } 
        }
    });

    $('#recetteDevise').change(function() {
        commission();
    });

    $('#service').change(function() {
        commission();
    });

    $('#commission').change(function() {
        var commissions = $("#commission").val();
        if (commissions != '0' && commissions != '') {
            commissions = parseFloat($("#commission").val());
            if (montant_total != '0' && montant_total != '') {
                montant_total = parseFloat($('#montantTotal').val());

                montant_total += commissions;
                montant_total = montant_total.toFixed(2);
                $('#montantTotal').val(montant_total);
            } else {
                var montant = $('#recetteMontant').val();
                montant = parseFloat(montant);
                montant += commissions;
                montant = montant.toFixed(2);
                $('#montantTotal').val(montant);
            }
        } else if (commissions == '0' || commissions == '') {
            var montant = $('#recetteMontant').val();
            montant = montant.toFixed(2);
            $('#montantTotal').val(montant);
        }
    });


    $("#pager").on("change", "#recette", function() {
        commission();

        var recette = $('#recette option:selected').val();
        if (recette === 'IPRIER' || recette === 'IRPPDR11') {
            $("#DGICotisation").css('display', '');
        } else {
            $("#DGICotisation").css('display', 'none');
        }
    });



    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $('#loader').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        
        var data = $(this).serialize();
        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();

        if (mode == '7' || mode == '8') {
                get_account_balance(data);
            
        } else {
                get_account_balance(data);
        }
    });
    
    $("#compteId").change(function() {
        
        var bank = '<?php echo $bank; ?>';
        
        if(bank == '@boa')
        {
            var compte = $(this).val();

            if (compte.length < 18) 
            {
                $("#accountname").removeClass('text-black');
                $("#accountname").removeClass('text-green');
                $("#accountname").addClass('text-red');
                $("#accountname").text('Numéro de compte invalide');
                $("#compteId").val('');
            } 
            else 
            {
                get_accountname();
            }
        }
        else
        {
            get_accountname();
        }
        
    });

    $("#compteDevise").change(function() {
        get_accountname();
    });

    $("#cancel").click(function() {
        location.reload(true);
    });

    function commission() {
        $('#loader').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var commission = $("#commission").val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();

        if (montant !== '' && devise !== '' && service !== '') {
            var url = '<?php echo base_url('admin/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    mode: mode,
                    regie: regie,
                    service: service,
                    recette: recette,
                    devise: devise,
                    montant: montant,
                    guichet: guichet
                },
                dataType: 'html',
                encode: true,
                success: function(reponse) {
                    var result = JSON.parse(reponse);

                    if (commission == '' || commission == '0') {
                        $("#commission").val(result[0]);
                        $("#commissionDevise").val(result[1]);
                        montant = result[2].toFixed(2);
                        $("#montantTotal").val(result[2]);
                    }

                },
                error: function(error) {
                    $('#bl').html('');
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }

    function get_account_balance(data)
    {
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();

        var url = '<?php echo base_url('branch/taxaccounts/data/get_account_balance'); ?>';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_compte : devise_compte, balance : balance}, 
            dataType    : 'html',  
            encode          : true,
            success: function(reponse)
            {
                if(reponse == '200')
                {
                    submiter(data);
                }
                else if(reponse == '300')
                {
                    $('#loader').html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette d&eacute;claration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(reponse == '405')
                {
                    $('#loader').html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $('#loader').html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion &agrave; synergie, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                
                $("#enregistrer").prop('disabled', false);
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    
    function get_accountname() {
        
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La requête a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }


    function submiter(data) {
        
        $('#loader').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxdeclaration/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) : ?>'
        
        $('#enregistrer').prop("disabled", true);
        scrollUP();
        message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php endif; ?>'
        
        var core_banking = '<?php echo $core_banking; ?>';
        
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {
                
                '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) : ?>'
                    if (result.code == "E300") {
                        $("#loader-sub-menu").html('');
                        $('#loader').html('<div class="alert aDanger text-white">L\'envoi des &eacute;critures &agrave; '+core_banking+' fait avec succ&egrave;s, mais les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; &agrave; un probl&eacute;me du d&eacute;saccord commercial ou administratif ou du chapitre d\'un compte. Allez dans le menu regularisation pour regulariser ce paiement. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code == "E404") {
                        $("#loader-sub-menu").html('');
                        $('#loader').html('<div class="alert aDanger text-white">L\'envoi des &eacute;critures &agrave; '+core_banking+' fait avec succ&egrave;s, mais les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; au probl&eacute;me de compte fermé, chapitre non autorisé ou sens du compte incorrect. Allez dans le menu regularisation pour regulariser ce paiement!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code == "E411") {
                        $("#loader-sub-menu").html('');
                        $('#loader').html('<div class="alert aDanger text-white"> L\'envoi des &eacute;critures &agrave; '+core_banking+' fait avec succ&egrave;s. Mais '+core_banking+' a retourn&eacute; une r&eacute;ponse partielle par rapport au lot des &eacute;critures envoy&eacute;es. Allez dans le menu regularisation pour regulariser ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code == "E405") {
                        $("#loader-sub-menu").html('');
                        $('#loader').html('<div class="alert aWarning text-white">Aucune &eacute;criture envoy&eacute;e &agrave; '+core_banking+' pour ce paiement d&ucirc; au probl&egrave;me d\'informations manquantes.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result.code == "E412") {
                        $("#loader-sub-menu").html('');
                        $('#loader').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;. Allez dans le menu regularisation pour regulariser ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } 
                    else if (result.message) 
                    { 
                        $('#loader').html('<div class="alert aDanger text-white">'+result.message+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                        $('#step2').remove;
                        $("#step-2").removeClass('bg-green-active');
                        $("#step-2").addClass('bg-gray');
                        $("#step-3").removeClass('bg-gray');
                        $("#step-3").addClass('bg-green-active');

                        var url = '<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/' + result.id;
                        
                        $.get(url, function(data, status) {
                            $('#loader').html(message);
                            $("#pager").html(data);
                        })
                    }
                '<?php else: ?>'
                    if (result === "E300") {
                        $("#loader-sub-menu").html('');
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">D&eacute;saccord commercial ou administratif. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result === "E406") {
                        $("#loader-sub-menu").html('');
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result === "E411") {
                        $("#loader-sub-menu").html('');
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else if (result === "E412") {
                        $("#loader-sub-menu").html('');
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Ce paiement a un probl&egrave;me, veuillez conctater votre administrateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } 
                    else if(result === "E305")
                    {
                        $("#loader-sub-menu").html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;. Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else {
                        $('#step2').remove;
                        $("#step-2").removeClass('bg-green-active');
                        $("#step-2").addClass('bg-gray');
                        $("#step-3").removeClass('bg-gray');
                        $("#step-3").addClass('bg-green-active');

                        var url = '<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/' + result;
                        $.get(url, function(data, status) {
                            $("#loader-sub-menu").html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#pager").html(data);
                        })
                    }
                '<?php endif; ?>'
            },
            error: function(error) {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    $("#closePanel").click(function() {
    
        if(controller)
        {
            closeView(controller, from);
        }
        else
        {
            location.reload();
        }

    });

    function closeView(controller, display) {
        if (controller != '' && display != '') {
            $.get("<?php echo base_url($module . '/' . $controller . '/display/' . $from); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#container").html(data);
            });
        } else {
            <?php if ($_SESSION['Logiref_role'] == 4) { ?>

                close_form();

            <?php } else { ?>

                location.reload();

            <?php } ?>
        }
    }

    function close_form() {
        $.get("<?php echo base_url($module . '/taxreports/display/' . $previous_menu); ?>", function(data, status) {
            $("#loader-sub-menu").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');

            $("#close").removeClass('hidden');
            $("#close_form").addClass('hidden');

        });
    }
    
    function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript" charset="utf-8">
    
  
    
    $("#print").click(function() {

        $('#enregistrer').prop("disabled", true);
        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    });

    $("#schema").click(function() {

        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/schema'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    });

    $("#delete").click(function() {
       var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
    
        swal({
                title: "SUPPRESSION",
                text: "Etes-vous sûr de vouloir supprimer cette ligne ?",
                type: "warning",
                showCancelButton: true,
                cancelButtonText:"Non",
                confirmButtonText: "Oui",
                closeOnConfirm: true,
                confirmButtonColor: "#c9302c"
            },function(isConfirm){
                if(isConfirm) {
                    var url = '<?php echo base_url($module . '/taxdeclaration/save/delete'); ?>/' + reference + '/' + recette;

                    $.ajax({
                        type: 'GET',
                        url: url,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                            $("#loader-sub-menu").html('');
                            $('#loader-sub-menu').html(result);

                            $('#enregistrer').prop("disabled",true);
                            $('#save').prop("disabled",true);
                            $('#delete').prop("disabled",true);
                        },
                        error: function(error) {
                            $('#loader-sub-menu').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    });
                }
            });
    });

    <?php if (isset($encaissement->Id_0) && $encaissement->Id_0 != '' && $encaissement->Id_0 != 0) { ?>
        var mode = $('#modeId').val();
        if (mode === '7' || mode == '8') {
            $("#compteId").prop('disabled', '');
            $("#compteDevise").prop('disabled', '');
        }
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
    <?php } ?>

    function comptabilisation(ref) {
        
        var url = '<?php echo base_url($module . '/taxcomptabilisation/display/get_details_dgi_amr_b'); ?>/' + ref;
        $.get(url, function(data, status) {
            $("#Comptabilisation").html(data);
        });
    }
    
    
</script>