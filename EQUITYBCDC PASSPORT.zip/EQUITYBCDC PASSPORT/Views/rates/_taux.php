<?php

    $reset_form = isset($reset) ? $reset : 0;  
 
    if(isset($usd) && $usd != 0):
        $usd = number_format($usd,4,"."," "); 
    else:
        $usd = ''; 
    endif;

    if(isset($eur) && $eur != 0):
        $eur = number_format($eur,4,"."," ");
    else:
        $eur = ''; 
    endif;

    if(isset($rand) && $rand != 0):
        $rand = number_format($rand,4,"."," ");
    else:
        $rand = ''; 
    endif;

    if(isset($pound) && $pound != 0):
        $pound = number_format($pound,4,"."," ");
    else:
        $pound = ''; 
    endif;

?>

<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <div class="" id="loader-page"></div>
        <h1  style="color: #0073B7;font-size: 25px;font-weight: 400;line-height: 35px;text-align: left;">
            <?php echo 'Taux de change'; ?>
        </h1>
        <p class="page-header">Publier un nouveau taux </p>
        <div id="msg">
            <?php echo $msg; ?>
        </div>

        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>

        <?php $chtml->box_body_opening('', true); ?>

            <div class="row">
                <div class="col-md-12 small-box">
                    <div class="form-group row">
                            <label for="usd" class="col-sm-2 col-form-label">DOLLARS</label>
                            <div class="col-sm-10">
                            <?php echo form_input('usd', set_value('usd', $usd),  'class="form-control input-require" placeholder= "0.0000"  id="usd" maxlength="86"'); ?>
                            </div>
                    </div>
                    <div class="form-group row">
                            <label for="eur" class="col-sm-2 col-form-label">EUROS</label>
                            <div class="col-sm-10">
                            <?php echo form_input('eur', set_value('eur', $eur), 'class="form-control input-require" placeholder= "0.0000"  id="euro" maxlength="86"'); ?>
                            </div>
                    </div>
                    <div class="form-group row">
                            <label for="rand" class="col-sm-2 col-form-label">RANDS</label>
                            <div class="col-sm-10">
                            <?php echo form_input('rand', set_value('rand', $rand), 'class="form-control input-require" placeholder= "0.0000"  id="rand" maxlength="86"'); ?>
                            </div>
                    </div>
                    <div class="form-group row">
                            <label for="pound" class="col-sm-2 col-form-label">POUND</label>
                            <div class="col-sm-10">
                            <?php echo form_input('pound', set_value('pound', $pound), 'class="form-control input-require" placeholder= "0.0000"  id="pound" maxlength="86"'); ?>
                            </div>
                    </div>
                    <div>
                        <input type='hidden' value='<?php echo $is_checker; ?>' name='is_checker' />
                        <input type='hidden' value='<?php echo $action; ?>' name='action' />
                        <input type='hidden' value='' name='id_taux' id="id_taux" />
                        <input type="hidden" name="jeton" value="erwtw" id="jeton">
                    </div>
                </div>
            </div>
        <?php $chtml->box_body_closing(); ?>

        <?php if($action != ''): ?>
            <div id="continue" class="row mt-3">
                <div class="col-md-12 ">
                    <button type="submit" class="btn btn-primary pull-left">&nbsp;&nbsp;<?php echo $action; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        <?php endif; ?>  

        <?php echo form_close(); ?>
    </div>
</div>
<style>
  .input-active {
        border-color: green !important;
  }
  .input-require {
        border-color: red !important;
  }
</style>
<script type="text/javascript">

    $('#usd, #euro, #rand, #pound').each(function() {
        let hasValue = $(this).val().trim().length > 0;
        $(this).toggleClass('input-active', hasValue)
               .toggleClass('input-require', !hasValue);
    });

    $('#usd, #euro, #rand, #pound').on('input', function() {
        if ($(this).val().length > 0) {
            // Si l'input n'est pas vide, bordure verte
            $(this).removeClass('input-require');
            $(this).addClass('input-active');
        } else {
            // Si l'input est vide, bordure rouge
            $(this).removeClass('input-active');
            $(this).addClass('input-require');
        }
    });

    $(document).ready(function() {
        $('.input-require').on('input', function() {
            let val = $(this).val();
            val = val.replace(/,/g, '.');
            val = val.replace(/[^0-9.]/g, '');

            // Ne garder qu'un seul point
            let parts = val.split('.');
            if (parts.length > 2) {
                val = parts[0] + '.' + parts.slice(1).join('');
            }

            // Limiter à 4 chiffres après le point
            if (parts.length === 2) {
                parts[1] = parts[1].substring(0, 4);
                val = parts[0] + '.' + parts[1];
            }

            $(this).val(val);
        });
    });

    $('#mainform').submit(function(event) {

            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            $("#loader-page").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

            var url = '<?php echo base_url($module.'/taxrates/save/'); ?>taux<?php echo $id > 0 ? '/'.$id : ''; ?>';

            var data = $(this).serialize();
            var cid = "<?= isset($id) ? $id : $reset_form; ?>";

            var session = "<?= isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : 0; ?>";
            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){

                        $('#loader-page').html('');
                        get_csrf();

                        result = JSON.parse(result);

                        $('#id_taux').val(result.id);
                        $('#loader-page').html('');
                        $('#loader-page').html(result.msg);

                        if(session == "3")
                        {
                            $('#msg').html('');
                        }
                    },
                    error:function(error){
                        get_csrf();
                        alert('ERROR!' + error);
                    }
            });
    });

</script>