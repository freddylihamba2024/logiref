
<?php
    if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates']!==0){
        $bank = json_decode($_SESSION['Bank_rates'], true);
        $usd = $bank['Dollar_4'];
        $eur = $bank['Euro_5'];
        $rand = $bank['Rand_6'];
        $pound = $bank['Pound_7'];
    }
    else {
        $usd = $eur = $rand = $pound = 0.0;
    }
?>

<div class="row">
    <div class="col-md-12">
        <h1 class="f30 text-blue">Taux de change</h1>
        <p class="page-header"><span class="f12 text-black">Publier les nouveaux taux de change ici.</span></p>
    </div>
    <div class="col-md-12">
                <div id="loader" class="col-md-12"></div>
                <?php if($_SESSION['Logiref_role']==2):?>
                <div class="row">
                    <div class="col-md-12">
                        <?php $chtml->box_body_opening("", true); ?>
                        <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => '')) ?>
                        <div class="statistic-box no-border">
                            <div class="row">
                                <div class="col-sm-5 col-xs-5" >
                                    <div class="input-group">
                                        <span class="input-group-addon"><label for="project">Agence</label></span> 
                                        <?php echo form_dropdown('agence',$agences, '', 'class="form-control" id="project"'); ?>
                                    </div>
                                </div>
                                <div class="col-sm-5 col-xs-6 no-padding">
                                    <div class="input-daterange input-group">
                                        <span class="input-group-addon">Du</span>
                                        <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y/m/d') ?>" id="datepicker1" type="text">
                                        <span class="input-group-addon">Au</span>
                                        <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y/m/d') ?>"  id="datepicker2" type="text">
                                    </div>
                                </div>
                                <div class="col-sm-2 col-xs-2">
                                    <button type="submit" class="btn btn-success pull-right"><i class="fa fa-search"></i>&nbsp;&nbsp;Filtrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
                <?php endif;?>
                <div class="row">
                    <div class="col-md-12">
                        <?php /*$chtml->box_body_opening('', false); ?>
                            <div class="col-md-4 bRight">
                                <div class="statistic-box rounded  mTop10 padding5 border">
                                    <ul class="list-group clear-list m-t">
                                        <li class="list-group-item fist-item">
                                            <span class="pull-right">
                                                <span class="label label-success text-white" >CDF <?php echo number_format($usd,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-dollar text-black"></i> <span class="f12 text-black">Dollars</span>
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                            <span class="label label-info text-white" >CDF <?php echo number_format($eur,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-euro text-black"></i> <span class="f12 text-black">Euros</span>
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                                <span class="label label-danger text-white">CDF <?php echo  number_format($pound,2,","," "); ?></span>
                                            </span>
                                            <i class="fa fa-fw fa-gbp text-black"></i> <span class="f12 text-black">Pounds </span>
                                        </li>
                                        <li class="list-group-item">
                                            <span class="pull-right">
                                                <span class="label label-warning text-white">CDF <?php echo number_format($rand,2,","," "); ?></span>
                                            </span>
                                            <span class="text-black"><b>&nbsp;R</b></span> <span class="f12 text-black">Rands</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>-->
                            <div class="col-md-8 no-padding">
                                <div class="">
                                    <div class="box-body margin padding">
                                        <canvas id="lineChart" class="d-block" height="150" width="436"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php $chtml->box_body_closing();*/ ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12" id="content">
                        <?php if(!empty($taux)): ?>
                            <?php $chtml->box_body_opening('', true); ?>
                                <table id="<?php echo(count($taux) > 10)? "table" :"";?>" class="table table-hover table-striped">
                                    <thead>
                                        <tr class="bg-gray f12">
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Agence</th>
                                            <th>Dollar</th>
                                            <th>Euro</th>
                                            <th >Pound</th>
                                            <th >Rand</th>
                                            <th>Validation</th>
                                            <th>Publi&eacute; par</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($taux as $row):?>
                                        <tr>
                                            <td class="f12" width="5"><?php echo $row->Id_0; ?></td>
                                            <td class="f12" width="150"><?php echo $row->Date_1; ?></td>
                                            <td class="f12" >
                                                <?php if($row->Status_2==1) echo '<b>'. ucfirst(strtolower($agences[$row->Agence_8])).'</b>'; else echo '<span class="text-red">'.ucfirst(strtolower($agences[$row->Agence_8])).'</span>'; ?>
                                            </td>
                                            <td class="f12" width="110"><?php echo 'CDF '.number_format($row->Dollar_4,2,","," "); ?></td>
                                            <td class="f12" width="110"><?php echo 'CDF '.number_format($row->Euro_5,2,","," "); ?></td>
                                            <td class="f12" width="110"><?php echo 'CDF '.number_format($row->Pound_7,2,","," "); ?></td>
                                            <td class="f12" width="110"><?php echo 'CDF '.number_format($row->Rand_6,2,","," "); ?></td>
                                            <td class="f12" class="text-blue">
                                                <?php if (isset($row->Checkerid_11) && $row->Checkerid_11 != '0'): ?> 
                                                    <?php echo isset($users[$row->Checkerid_11]) ? $users[$row->Checkerid_11] : 'Auto'; ?>
                                                <?php elseif ($row->Agence_8==$_SESSION['Logiref_agence'] && $row->Checkerid_11==0 && $_SESSION['Logiref_role']==3): ?> 
                                                    <a id="Validate" class="btn btn-warning" href="#" class="text-green"> Confirmer </a>
                                                <?php else: ?> 
                                                    <span  class=""> En attente </span>
                                                <?php endif;?>
                                            </td>
                                            <td class="text-green">

                                                <?php echo isset($users[$row->Makerid_10]) ? $users[$row->Makerid_10] : 'Auto'; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php $chtml->box_body_closing(); ?>
                        <?php else: ?>
                        <section id="cat_list" class="text-center marginTop150">
                                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                                <span class="d-block f14 text-black p-2"> Aucune r&eacute;gularisation trouv&eacute;e !</span>
                        </section>


                        <?php endif;?>
                    </div>
                </div>
                </div><br><br>
                </div>

    </div></br></br>
</div>
<script type="text/javascript">
$('#table').DataTable({
    "paging": true,
    "lengthChange": false,
    "searching": false,
    "ordering": true,
    "info": true,
    "autoWidth": false,
    "pageSize": 50,
    "aaSorting":[[ 0, 'desc' ]]
});

var lineData = {
        labels: [<?php echo $chart['months']; ?>],
        datasets: [
            {
                label: "Dollars",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(7,122,19,255)",
                pointBackgroundColor: "rgba(7,122,19,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Dollar']; ?>]
            },
            {
                label: "Euros",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(16,188,234,255)",
                pointBackgroundColor: "rgba(16,188,234,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Euro']; ?>]
            },
            {
                label: "Pounds",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(180,15,11,255)",
                pointBackgroundColor: "rgba(180,15,11,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Pound']; ?>]
            },
            {
                label: "Rands",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(253,126,15,255)",
                pointBackgroundColor: "rgba(251,101,21,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Rand']; ?>]
            }
        ]
    };
    var lineOptions = 
    {
        responsive: true
    };

    var ctx = document.getElementById("lineChart").getContext("2d");
    new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});

$("#add").click(function(){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
    <?php if($_SESSION['Logiref_role']==4): ?>
          $.get("<?php echo base_url($module.'/rates/display'); ?>/taux/", function(data, status){
              $("#loader").html('');
              $("#pager").html(data);
          });
    <?php else: ?>
          $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    <?php endif; ?>
      
});

$("#Validate").click(function(){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
    $.get("<?php echo base_url($module.'/rates/display'); ?>/taux/", function(data, status){
          $("#loader").html('');
          $("#container").html(data);
    });
});

function view(id){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
      
}

$("#mainform").on('submit', function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
    <?php if($_SESSION['Logiref_role']!=4): ?>
        var url = '<?php echo base_url($module.'/rates/display/taux_filter'); ?>';
    <?php else: ?>
        $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    <?php endif; ?>
    var data = new FormData(this);
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        contentType : false,
        cache       : false,
        processData :false,
        success: function (result) {
            $('#loader').html('');
            $("#content").html(result);
        },
        error: function (error) {
            alert('ERROR!' + error);
        }
       });      
});

 //Datepicker
    $('#data_5 .input-daterange').datepicker({
            keyboardNavigation: false,
            forceParse: false,
            autoclose: true
        });
    $('#datepicker1').datepicker({
        format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
        format: 'yyyy-mm-dd'
    });
    
</script>


