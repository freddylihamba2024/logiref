<?php
if ($compte->Id_0 > 0):
    if ($_SESSION['Logiref_role'] == 1) $title = "Modifier";
    if ($_SESSION['Logiref_role'] == 2) $title = "Valider";
else
    $title = 'Nouveau compte';
endif;
?>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="w-100" id="loader-page"></div>
        <h2><strong><?php echo $title; ?></strong></h2>
        <p class="page-header"></p>
        <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
        <?= csrf_field() ?>
        <?php $chtml->box_body_opening('', true); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Compte_6">Num&eacute;ro de compte</label>
                    <?php echo form_input('Compte_6', set_value('Compte_6', $compte->Compte_6), 'class="form-control" required="required" placeholder="Ex: 4601000130308" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="Agenceid_15">Code agence</label>
                    <?php echo form_input('Agenceid_15', set_value('Agenceid_15', $compte->Agenceid_15), 'class="form-control" required="required" placeholder="Ex: 01019" maxlength="5"'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="Devise_8">Devise</label>
                    <?php echo form_dropdown('Devise_8', $devises, $compte->Devise_8, 'class="form-control"  required="required"'); ?>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Type_4">Type de compte</label>
                    <?php echo form_dropdown('Type_4', $types, $compte->Type_4, ' id="Type1" class="form-control" required="required"'); ?>
                    <input name="Id_0" type="hidden" value="<?php echo $compte->Id_0; ?>" />
                </div>
            </div>
            
            <div class="col-md-6" >
                <div id="AIP" class="form-group" style="display: none;">
                    <label for="Beneficiaires1">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires1', $beneficiaires, $compte->Beneficiaires_5, ' id="aip2" class="form-control" '); ?>
                </div>
                <div id="BKC" class="form-group">
                    <label for="Beneficiaires2">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires2', $banque['BKC'], $compte->Beneficiaires_5, ' id="bkc2" class="form-control" '); ?>
                </div>
                <div id="RGF" class="form-group">
                    <label for="Beneficiaires3">B&eacute;n&eacute;ficiaire</label>
                    <?php echo form_dropdown('Beneficiaires3', $banque['RGF'], $compte->Beneficiaires_5, ' id="rgf3" class="form-control" '); ?>
                </div>
            </div>
            
            <div class="col-md-6" id="service_id">
                <div class="form-group">
                    <label for="service">Service/Bureau</label>
                    <?php echo form_dropdown('service', $services, $compte->Serviceid_16, ' class="chosen-select form-control" '); ?>
                </div>
            </div>
            
            <div class="col-md-6" id="SID" style="display: none;">
                <div id="SID1" class="form-group" style="display: none;">
                    <label for="service">Service</label>
                    <?php echo form_dropdown('service_dir1', $services_direction['DGI'], $compte->Serviceid_16, ' class="chosen-select form-control" '); ?>
                </div>

                <div id="SID2" class="form-group" style="display: none;">
                    <label for="service">Service</label>
                    <?php echo form_dropdown('service_dir2', $services_direction['DGRAD'], $compte->Serviceid_16, ' class="chosen-select form-control" '); ?>
                </div>

                <div id="SID3" class="form-group" style="display: none;">
                    <label for="service">Bureau</label>
                    <?php echo form_dropdown('service_dir3', $services_direction['DGDA'], $compte->Serviceid_16, ' class="chosen-select form-control" '); ?>
                </div>
            </div>
            
            <div class="col-md-6 hidden" id="servicetype_id">
                <div class="form-group">
                    <label for="service">Catégorie de service</label>
                    <span><?php echo form_dropdown('service1', $service_types, $compte->Serviceid_16, '  class="form-control" '); ?></span>
                </div>
            </div>
            
            <div class="col-md-6" id="recette_id">
                <div class="form-group"  id="rct">
                    <label for="recette">Recette</label>
                    <?php echo form_dropdown('recette', $recettes, $compte->Recette_13, ' id="recette" class="form-control" '); ?>
                </div>
                
                <div class="form-group" id="rct1" style="display: none;">
                    <label for="recette">Recette</label>
                    <?php echo form_dropdown('recette1', $recettes['DGI'], $compte->Recette_13, ' id="recette" class="form-control" '); ?>
                </div>
                <div class="form-group"  id="rct2" style="display: none;">
                    <label for="recette">Recette</label>
                    <?php echo form_dropdown('recette2', $recettes['DGRAD'], $compte->Recette_13, ' id="recette" class="form-control" '); ?>
                </div>
                <div class="form-group"  id="rct3" style="display: none;">
                    <label for="recette">Recette</label>
                    <?php echo form_dropdown('recette3', $recettes['DGDA'], $compte->Recette_13, ' id="recette" class="form-control" '); ?>
                </div>
            </div>
            
            <div class="col-md-6" id="nif">
                <div class="form-group">
                    <label for="nif">Num&eacute;ro imp&ocirc;t</label>
                    <span><?php echo form_input('nif', $compte->Nif_17, ' id="nif" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="csydonia">
                <div class="form-group">
                    <label for="comptesydonia">Compte SYDONIA</label>
                    <span><?php echo form_input('comptesydonia', $compte->Comptesydonia_18, ' id="comptesydonia" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="clt">
                <div class="form-group">
                    <label for="clt">Num&eacute;ro importateur</label>
                    <span><?php echo form_input('clt', '', ' id="clt" class="form-control" '); ?></span>
                </div>
            </div>
            <div class="col-md-6" id="agence_id">
                <div class="form-group">
                    <label for="agence">Agence bancaire</label>
                    <?php echo form_dropdown('agence', $guichets, $compte->Agence_12, ' id="agence" class="form-control" '); ?>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="banque">Banque [ <span class="text-danger">Requise</span> <input type="checkbox" class="check" name="nivellement" value="<?= 1 ?>"> ]</label>
                    <?php echo form_dropdown('banque', $banques['BKC'], $compte->Bank_21, ' id="bank" class="form-control required="required" '); ?>
                </div>
            </div>
        </div>
        <div id="continue" class="row">
            <div class="col-md-12">
                <button type="submit" id="save" class="btn btn-primary pull-left"  <?= ($compte->Checkerid_11 > 0)? 'disabled':"" ?>><i class="fa fa-save"></i>&nbsp;&nbsp;<?php echo ($_SESSION['Logiref_role'] == 1) ? 'Enregistrer..':'Valider..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
        <?php echo form_close(); ?>
    </div>
    <div class="col-md-2">
    </div>
</div>
<br><br>

<script type="text/javascript">
    onload();
    inload();

    function inload()
    {
        var isOfregie= '<?php echo $compte->Beneficiaires_5; ?>';

        if(isOfregie ==="DGI" )
        {
                $('#service_id').css( "display", "none");
                $("#service_id").prop('required', false);

                $('#servicetype_id').removeClass('hidden');
                $('#servicetype_id').css( "display", "");
                $("#servicetype_id").prop('required', true);
                
                $('#SID').css( "display", "none");

        }
        else
        {
                $('#servicetype_id').css( "display", "none");
                $('#service_id').css( "display", "");

                $("#service_id").prop('required', true);
                $("#servicetype_id").prop('required', false);
        }

    }

    function onload() 
    {
        var isOfType = '<?php echo $compte->Type_4; ?>';
        if (isOfType === "CPI" || isOfType === "CPB" || isOfType === "CPO" || isOfType === "CFC" || isOfType === "CTC") 
        {
            $("#BKC").css("display", "none");
            $("#RGF").css("display", "none");
            $("#AIP").css("display", "");

            $("#aip2").prop('required', true);
            $("#bkc2").prop('required', false);
            $("#rgf3").prop('required', false);
        } 
        else if (isOfType === "CPT" || isOfType === "CGU" || isOfType === "CSC") 
        {
            $("#RGF").css("display", "");
            $("#BKC").css("display", "none");
            $("#AIP ").css("display", "none");

            $("#rgf3").prop('required', true);
            $("#bkc2").prop('required', false);
            $("#aip2 ").prop('required', false);
        } 
        else if (isOfType === "CSO" || isOfType === "CPS" || isOfType === "CTR" || isOfType === "CAC") 
        {
            $("#BKC").css("display", "");
            $("#RGF").css("display", "none");
            $("#AIP ").css("display", "none");

            $("#bkc2").prop('required', true);
            $("#rgf3").prop('required', false);
            $("#aip2 ").prop('required', false);
        } 
        else 
        {
            $("#BKC").css("display", "");
            $("#AIP").css("display", "none");
            $("#RGF").css("display", "none");

            $("#bkc2").prop('required', true);
            $("#aip2").prop('required', false);
            $("#rgf3").prop('required', false);
        }
    };

    $("#Type1").change(function() {

        var isOfType = $('#Type1 option:selected').attr('value');

        if (isOfType === "CAC") 
        {
            $("#BKC").css("display", "");
            $("#RGF").css("display", "none");
            $("#AIP").css("display", "none");

            $("#aip2").prop('required', true);
            $("#bkc2").prop('required', false);
            $("#rgf3").prop('required', false);
        } 
        else if (isOfType === "CPI" || isOfType === "CPB" || isOfType === "CPO" || isOfType === "CFC" || isOfType === "CTC") 
        {
            $("#BKC").css("display", "none");
            $("#RGF").css("display", "none");
            $("#AIP").css("display", "");

            $("#aip2").prop('required', true);
            $("#bkc2").prop('required', false);
            $("#rgf3").prop('required', false);


        } 
        else if (isOfType === "CFB") 
        {
            $("#bkc2").prop('required', true);
            $("#aip2").prop('required', false);
            $("#rgf3").prop('required', false);

            $("#BKC").css("display", "");
            $("#AIP").css("display", "none");
            $("#RGF").css("display", "none");

        } 
        else if (isOfType === "CPT" || isOfType === "CSC") 
        {
            $("#aip2").prop('required', false);
            $("#bkc2").prop('required', false);
            $("#rgf3").prop('required', true);

            $("#RGF").css("display", "");
            $("#BKC").css("display", "none");
            $("#AIP").css("display", "none");

        } 
        else if (isOfType === "CCV" || isOfType === "CPU" || isOfType === "TVA" || isOfType === "CSO" || isOfType === "CPS" || isOfType === "CTR") 
        {
            $("#BKC").css("display", "");
            $("#RGF").css("display", "none");
            $("#AIP").css("display", "none");

            $("#bkc2").prop('required', true);
            $("#aip2").prop('required', false);
            $("#rgf3").prop('required', false);
        } 
        else if (isOfType === "CGU") 
        {
            $("#aip2").prop('required', false);
            $("#bkc2").prop('required', false);
            $("#rgf3").prop('required', true);

            $("#RGF").css("display", "");
            $("#BKC").css("display", "none");
            $("#AIP").css("display", "none");

        } 
        else 
        {
            $("#BKC").css("display", "");
            $("#RGF").css("display", "none");
            $("#AIP").css("display", "none");

            $("#bkc2").prop('required', true);
            $("#aip2").prop('required', false);
            $("#rgf3").prop('required', false);

        }

    });

    $("#recette").change(function() {

        var recette = $('#recette option:selected').attr('value');

        if (recette != "") {
            $('#regie').prop('disabled', true);
        } else {
            $('#regie').prop('disabled', false);
        }
    });
    
    $("#rgf3").change(function(){
    
        var regie = $('#rgf3 option:selected').attr('value');
        
        if(regie == 'DGI')
        {
                $('#servicetype_id').css( "display", "");
                $('#servicetype_id').removeClass('hidden');
                
                $("#service_id").css("display", "none");
                //$('#service_id').addClass('hidden');
                                
                $("#clt").css("display", "none");
                $("#clt").addClass("hidden");
                
                $("#SID").css("display", "");
                $("#SID1").css("display", "");
                
                $("#rct").css("display", "none");
                $("#rct1").css("display", "");
                
        }
        else if (regie == "DGRAD")
        {
                $('#servicetype_id').css( "display", "none");
                $('#servicetype_id').addClass('hidden');
                
                $('#recette_id').css( "display", "");
                $('#recette_id').removeClass('hidden');
                
                $("#clt").css("display", "none");
                $("#clt").addClass("hidden");
                
                $("#SID").css("display", "");
                $("#SID1").css("display", "none");
                $("#SID2").css("display", "");
                
                $("#rct").css("display", "none");
                $("#rct1").css("display", "none");
                $("#rct2").css("display", "");
                
                $("#agence_id").removeClass("col-md-6");
                $("#agence_id").addClass("col-md-12");
                
        }
        else if (regie == "DGDA")
        {
                $('#servicetype_id').css( "display", "none");
                $('#servicetype_id').addClass('hidden');
                
                $('#recette_id').css( "display", "");
                $('#recette_id').removeClass('hidden');
                
                $("#clt").css("display", "none");
                $("#clt").addClass("hidden");
                
                $("#SID").css("display", "");
                $("#SID1").css("display", "none");
                $("#SID2").css("display", "none");
                $("#SID3").css("display", "");
                
                $("#rct").css("display", "none");
                $("#rct1").css("display", "none");
                $("#rct2").css("display", "none");
                $("#rct3").css("display", "");
                
                $("#agence_id").removeClass("col-md-6");
                $("#agence_id").addClass("col-md-12");
        }
        else
        {
                alert(regie)
                $('#service_id').css("display", "none");
                $('#servicetype_id').css("display", "none");
                $('#recette_id').css("display", "none");
                
                
                $("#clt").css("display", "");
                $("#clt").removeClass("hidden");
                
                $("#SID").css("display", "none");
                $("#SID1").css("display", "none");
                $("#SID2").css("display", "none");
                $("#SID3").css("display", "");
                
                $("#rct").css("display", "none");
                $("#rct1").css("display", "none");
                $("#rct2").css("display", "none");
                $("#rct3").css("display", "none");
                
                $("#agence_id").removeClass("col-md-12");
                $("#agence_id").addClass("col-md-6");
        }
    });


    $(".check").click(function() {
        
        var isChecked = $(this).is(':checked');
        if (isChecked == true)
        {
            $("#bank").prop("required", true);
            
        }

        if (isChecked == false)
        {
            $("#bank").prop("required", false);
            
        }
    
    });
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        $("#loader-page").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxaccounts/save'); ?>/compte<?php echo $compte->Id_0 > 0 ? '/'.$compte->Id_0 : ''; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $compte->Id_0; ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $('#loader-page').html('');
                $('#loader-page').html(result);
                $('#save').prop("disabled", true);
                <?php if ($compte->Id_0 == '') { ?>
                    // $("#mainform").trigger('reset');
                <?php } else { ?>
                    $('#save').prop("disabled", true);
                <?php } ?>
            },
            error: function(error) {
                alert('ERROR!' + error);
            }
        });
    });

    $("#cancel").click(function() {
        closeModal();
    });

    $("#buttonCloseModal").click(function() {
        closeModal();
    });

    function closeModal() {
        var from = '<?= isset($from) ? $from : ""; ?>'
        $("#loader-page").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        if (from != "") {
            $.get("<?php echo base_url($module . '/taxsettings/display/settings/comptes/accounts'); ?>", function(data, status) {
                $("#loader-page").html('');
                $("#container").html(data);
            });
        } else {
            $.get("<?php echo base_url($module . '/taxaccounts/display/comptes'); ?>", function(data, status) {
                $("#loader-page").html('');
                $("#container").html(data);
            });
        }
    }
</script>