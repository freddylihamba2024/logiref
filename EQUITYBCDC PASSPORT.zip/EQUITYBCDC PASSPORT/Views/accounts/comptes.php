<?php $userid = $session->userdata['user_id'] ?>
<?php $usertype = $session->userdata['user_type'] ?>

<div class="row">
    <div class="col-md-12">
        <div id="loader1"></div>
    </div>

    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-content">
                <div class="d-flex justify-content-between border-bottom">
                    <div>
                        <h2 class="text-dark"><b>Gestionssssssssss des comptes bancaires</b></h2>
                        <h5 class=""><span class="text-gray">Consultation de la liste des comptes bancaires</span></h5>
                    </div>
                    <a id="add" href="#"><span class="fa fa-fw fa-plus-circle fa-5x text-success"></span></a>
                </div>
                <div>
                    <div class="col-sm-12 mt-3">
                        <?php echo form_open('', array('id' => 'filter', 'class' => 'margin')); ?>
                            <div class="row mt-3">
                                <div class="col-md-2 p-1">
                                    <div class="form-group">
                                        <b>AGENCE </b><br /><?php echo form_dropdown('agence', $agences, '', 'class="form-control" id="agence" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-2 p-1">
                                    <div class="form-group">
                                        <b>TYPE</b><br /><?php echo form_dropdown('type', $types, '', 'class="form-control" id="type" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-3 p-1">
                                    <div class="form-group">
                                        <b>TAXES</b><br /><?php echo form_dropdown('taxe', $recettes, '', 'class="form-control" id="type" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-2 p-1">
                                    <div class="form-group">
                                        <b>BUREAU</b><br /><?php echo form_dropdown('bureau', $services, '', 'class="form-control" id="type" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-1 p-1">
                                    <div class="form-group">
                                        <b>DEVISE </b><br /><?php echo form_dropdown('devise', $devises, '', 'class="form-control" id="devise" '); ?>
                                    </div>
                                </div>
                                <div class="col-md-2 p-1" align="right">
                                    <br /><button class="btn btn-block btn-secondary d-flex gap-2 align-items-center justify-content-center" type="submit"> <i class="fa fa-fw fa-refresh text-gray"></i> <span>Filtrer</span></button><br />
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
        <div id="list">
            <?php  if (empty($comptes)) $comptes = $lastestComptes; ?>
            <?php if (!empty($comptes)) : ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-blue">
                            <th>#</th>
                            <th>Agence</th>
                            <th width="50">Type</th>
                            <th width="50">Taxe</th>
                            <th width="150">Compte</th>
                            <th width="50">Devise</th>
                            <th width="50">B&eacute;n&eacute;ficiaire</th>
                            <th>Maker</th>
                            <th>Checker</th>
                            <th width="100">Validation</th>
                            <th><span class="fa fa-fw fa-edit f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($comptes as $row) : ?>
                            <tr>
                                <td width="5"><?php echo $i; ?></td>
                                <td><?php echo  (isset($guichets[$row->Agence_12])) ? $guichets[$row->Agence_12] : ""; ?></td>
                                <td width="50"><?php echo ' ' . $row->Type_4; ?></td>
                                <td>
                                    <?php if ($row->Type_4 == 'CAC') :?>
                                        <b><?php echo $row->Numimportateur_23 ?></b>
                                    <?php else :?>
                                        <span class="text-red"><?php echo $row->Recette_13 ?></span>
                                    <?php endif; ?>
                                </td>
                                <td width="150">
                                    <?php if (($row->Type_4 != 'CAC' || $row->Type_4 != 'CPI') && $row->Agenceid_15 != ""): ?> 
                                        <b><?php echo $row->Agenceid_15. '-'?></b>;
                                    <?php elseif($row->Agenceid_15 != "") :?> 
                                        <span class="text-red"><?php echo $row->Agenceid_15 . '-'?></span> 
                                    <?php endif; ?>
                                    <?php 
                                        if ($row->Compte_6 != '') echo $row->Compte_6; 
                                        if ($row->Clef_7 != '') echo '-' . $row->Clef_7;
                                    ?>
                                </td>
                                <td class="bleu" width="50"><?php echo $row->Devise_8; ?></td>
                                <td width="50"><?php echo ' ' . $row->Beneficiaires_5; ?></td>
                                <td>
                                    <?php echo (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - '; ?></td>
                                <td>
                                    <?php if ($row->Checkerid_11 == 0): ?>
                                        <span class="text-red"> - </span>
                                    <?php else: ?>
                                        <?php echo (isset($users[$row->Checkerid_11])) ? $users[$row->Checkerid_11] : ' - '; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row->Checkerid_11 == 0): ?>
                                        <span class="text-red"> En attente </span>
                                    <?php else: ?>
                                        <?php echo $row->Validation_10; ?>
                                    <?php endif; ?>
                                </td>
                                <td width="25" align="right">
                                    <?php if ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2): ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                                    <?php else: ?>
                                        <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php endif;?>
                                </td>
                            </tr>
                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <section id="cat_list" class="text-center marginTop150">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                    <span class="d-block f14 text-black p-2">Le compte est vide!</span>        
                </section>
            <?php endif; ?>
        </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
</div>
<br><br>
<script type="text/javascript">
    
    $("#table").DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    //Add a member
    $("#add").click(function() {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

        $("#loader1").html('<div class="alert alert-warning">D&eacute;sol&eacute! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    });

    function view(id) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxaccounts/display/compte'); ?>/' + id + '/<?php echo $from ?>';
        $.get(url, function(data, status) {
            $("#loader1").html('');
            $("#container").html(data);
        });
    }


    $("#filter").submit(function(event) {
        alert($('input[name="csrf_name"]').val());
        event.preventDefault();
        $("#list").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxaccounts/display/filter'); ?>';
        var data = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $('#list').html('');
                $("#list").html(result);
                get_csrf();
            },
            error: function(error) {
                alert('ERROR!' + error);
                get_csrf();
            }
        });
    });

</script>