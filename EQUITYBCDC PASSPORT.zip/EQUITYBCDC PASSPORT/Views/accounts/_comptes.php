<?php if (!empty($comptes)) : ?>
    <table id="tableREN" class="table table-hover table-striped">
        <thead>
            <tr class="bg-blue">
                <th>#</th>
                <th>Agence</th>
                <th width="50">Type</th>
                <th width="50">Taxe</th>
                <th width="150">Compte</th>
                <th width="50">Devise</th>
                <th width="50">B&eacute;n&eacute;ficiaire</th>
                <th>Maker</th>
                <th>Checker</th>
                <th width="100">Validation</th>
                <th><span class="fa fa-fw fa-edit f14"></span></th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach ($comptes as $row): ?>
                <tr>
                    <td width="5"><?php echo $i; ?></td>
                    <td><?php echo (isset($guichets[$row->Agence_12])) ? $guichets[$row->Agence_12]:""; ?></td>
                    <td width="50"><?php echo ' ' . $row->Type_4; ?></td>
                    <td>
                        <?php if ($row->Type_4 == 'CAC') :?>
                            <b><?php echo $row->Numimportateur_25 ?></b>;
                        <?php else:?> 
                            <span class="text-red"><?php echo $row->Recette_13 ?></span> 
                        <?php endif; ?>
                    </td>
                    <td width="150">
                        <?php if (($row->Type_4 != 'CAC' || $row->Type_4 != 'CPI') && $row->Agenceid_15 != ""): ?> 
                            <b><?php echo $row->Agenceid_15. "-" ?></b>
                        <?php elseif($row->Agenceid_15 != ""): ?>
                            <span class="text-red"><?php $row->Agenceid_15. '-' ?> </span>
                        <?php endif; ?>
                        <?php 
                            if ($row->Compte_6 != '') echo $row->Compte_6; 
                            if ($row->Clef_7 != '') echo '-' . $row->Clef_7; 
                        ?>
                    </td>
                    <td class="bleu" width="50"><?php echo $row->Devise_8; ?></td>
                    <td width="50"><?php echo ' ' . $row->Beneficiaires_5; ?></td>
                    <td>
                        <?php echo (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - '; ?></td>
                    <td>
                        <?php if ($row->Checkerid_11 == 0): ?>
                            <span class="text-red"> - </span>
                        <?php else: ?>
                            <?php echo (isset($users[$row->Checkerid_11])) ? $users[$row->Checkerid_11] : ' - '; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($row->Checkerid_11 == 0): ?>
                            <span class="text-red"> En attente </span>
                        <?php else: ?>
                            <?php echo $row->Validation_10; ?>
                        <?php endif; ?>
                    </td>
                    <td width="25" align="right">
                        <?php if ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2): ?>
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                        <?php else: ?>
                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php $i++; endforeach; ?>
        </tbody>
    </table>
<?php else : ?>
    <section id="cat_list" class="text-center marginTop150">
        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
        <span class="d-block f14 text-black p-2">Le compte est vide!</span>        
    </section>
<?php endif; ?>
<br><br>