<?php  $total=0; $quittance = json_decode($payment->Quittance_12); ?>
<?php if($payment->Status_2 != 1): $disabled = 'disabled'; $className = "btn-default"; else: $disabled = ''; $className = "btn-primary"; endif;?>
<div id="messages" class="col-md-12"></div>
<div class="">
    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => 'view')); ?>
        <div class="box-body no-padding">
            <input type="hidden" name="Paiementid" value="<?php echo $payment->Id_0; ?>">
            <input type="hidden" name="Account" value="<?php echo $this->session->userdata['account_id']; ?>">
            <input type="hidden" name="User" value="<?php echo $this->session->userdata['user_id']; ?>">
            <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
            <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
            <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
            <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
            <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
            <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
            <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
            <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
            <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25; ?>" />
            <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
            <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
            <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
            <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
            <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
            <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
            <input type="hidden" name="Infos[Nifdeclarant]" value="" />
            <input type="hidden" name="Infos[agence]" value="<?= isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
            <input type="hidden" name="Infos[taxesPaid]" value="<?= isset($taxes) ? $taxes : ""; ?>" />
            <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
            <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28; ?>" />
            <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Notedevise_29; ?>" />
            <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27; ?>" />
            <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13; ?>" />
            <div class="no-padding">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Bureau</label></span>
                        <?php echo $services['DGDA'][$payment->Office_8];?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Code du Declarant</label></span>
                        <?php echo $payment->Declarant_16;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Bulletin</label></span>
                        <?php echo $payment->Serial_9.' '.$payment->Number_10;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Date de liquidation</label></span>
                        <?php echo $payment->DateL_11;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Montant total</label></span>
                        <?php echo '<span class="text-black">'.number_format($payment->Amount_18,4,","," ").' CDF</span>'; ?>
                    </div>
                </div>
                <div class="col-md-6 bLeft">
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Importateur</label></span>
                        <?php echo $payment->Designation;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Num&eacute;ro imp&ocirc;t</label></span>
                        <?php echo $payment->Nif_15;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">R&eacute;f&eacute;rence du compte</label></span>
                        <?php echo $payment->AccountRef_14;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Quittance</label></span>
                        <?php echo $quittance->serQuit.' '.$quittance->numQuit;?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon"><label for="bureau">Date de quittance</label></span>
                        <?php echo $quittance->datQuit;?>
                    </div>
                </div>
                <div class="">
                    <br/><br/>
                </div>
            </div>
            <div class="">
                <br/><br/>
            </div>
            <?php if($payment->Status_2 != 1):?>
                <div class="no-padding">
                    <table id="table" class="table table-stripped table-hover">
                        <thead class="tScroll">
                            <tr class="bg-gray-active">
                                <th width="4%">#</th>
                                <th >B&eacute;n&eacute;ficiaires</th>
                                <th >Recette</th>
                                <th class="right" align='right'>Montant</th>
                            </tr>
                        </thead>
                        <tbody class="tScroll">
                            <tr class="tScroll">
                                <td width="4%"> <?php echo ++$i; ?></td>
                                <td><?php echo '<span class="text-green">DGDA</span>'; ?></td>
                                <td>Recette tr&eacute;sor (ISYS-R&eacute;gies)</td>
                                <td align='right'><?php echo '<span class="text-green">'.number_format($infos['amountDGDA'],2,","," ").' CDF</span>'; ?></span></td>
                            </tr>
                            <tr class="tScroll">
                                <td width="4%"> <?php echo ++$i; ?></td>
                                <td><?php echo '<span class="text-green">DGRAD</span>'; ?></td>
                                <td>Recette tr&eacute;sor (ISYS-R&eacute;gies)</td>
                                <td align='right'><?php echo '<span class="text-green">'.number_format($infos['amountDGRAD'],2,","," ").' CDF</span>'; ?></span></td>
                            </tr>
                            <tr class="tScroll">
                                <td width="4%"> <?php echo ++$i; ?></td>
                                <td><?php echo '<span class="text-blue">DGDA</span>'; ?></td>
                                <td>Fond propres (montant total)</td>
                                <td align='right'><?php echo '<span class="text-blue">'.number_format($infos['amountPRDGDA'],2,","," ").' CDF</span>'; ?></span></td>
                            </tr>
                            <?php 
                            foreach($infos['amountSERVICES'] as $entity=>$amount){
                            ?>
                            <tr class="tScroll">
                                <td width="4%"> <?php echo ++$i; ?></td>
                                <td><?php echo '<span class="text-blue">'.$entity.'</span>'; ?></td>
                                <td>Fond propres (montant total)</td>
                                <td align='right'><?php echo '<span class="text-blue">'.number_format($amount,2,","," ").' CDF</span>'; ?></span></td>
                            </tr>
                            <?php $total = $total + $amount; ?>
                            <?php } ?>
                            <tr class="tScroll">
                                <td width="4%">[+]</td>
                                <td><b>TOTAL</b></td>
                                <td align='right'><?php $total = $total + $infos['amountPRDGDA'] + $infos['amountDGRAD'] + $infos['amountDGDA']; ?></td>
                                <td  align='right' ><b><?php echo number_format($total,2,","," ").' CDF'; ?></b></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php else:?>
            <div class="no-padding">
                <div class="col-md-12"><br/><label>D&eacute;tails du paiement </label><br/></div>
                <div id="details" class="col-md-12">
                    <table id="table" class="table table-hover table-striped fixed_header">
                        <thead class="tScroll">
                            <tr class="bg-blue">
                                <th width="">B&eacute;n&eacute;ficiaire</th>
                                 <th width="">Taxe code</th>
                                <th width="">Description</th>
                                <th width="" align='right' class="center">Montant</th>
                            </tr>
                        </thead>
                        <tbody class="fixed_header tScroll">
                            <?php foreach($infos['taxesPaid'] as $taxe) :?>
                                <tr class="<?php if(!isset($beneficiaires[$taxe->taxeCode])){ echo "text-red";}?> tScroll">
                                    <td><?php echo (isset($beneficiaires[$taxe->taxeCode]))? $beneficiaires[$taxe->taxeCode]:$taxe->taxeCode ;?></td>
                                    <td><?php echo $taxe->taxeCode;?></td>
                                    <td><?php echo $taxe->taxeDescription;?></td>
                                    <td  class="right" align='right'><?php echo 'CDF '.number_format($taxe->taxeAmount,2,","," ");?></td>
                                </tr>
                            <?php $total = $total + $taxe->taxeAmount; endforeach;  ?>
                            <tr class="tScroll">
                                <td>[+]</td>
                                <td></td>
                                <td><b>TOTAL</b></td>
                                <td align="right"><b><?php echo number_format($total,2,","," ").' CDF'; ?></b></td>
                            </tr>
                        </tbody>    
                    </table>
                </div>
            </div>
            <?php endif;?>
            <div class=""><br/>_ _ _ _ _ _ _ <br/></div>
            <div  id="Comptabilisation" class="tScroll" ></div>
        </div>
        <div class="box-footer clearfix" id="block">
            <button id="confirmform" type="submit" class="btn <?php echo $className; ?> pull-left" <?php echo $disabled; ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    <?php echo form_close(); ?>
</div>
<script type="text/javascript">
var ref = '<?php echo $encaissement->Logirefid_4; ?>'; 
var id = '<?php echo $payment->Id_0; ?>';
var status = '<?php echo $payment->Status_2; ?>';

if(status !== 1){
        comptabilisation(ref);
}
$("#mainform").submit(function(event){
        event.preventDefault();
        var data = $(this).serialize();
        submiter(data);
});

function submiter(data){
        $("#messages").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/confirmprepayment'); ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        $('#messages').html('');
                        if(result === "E406")
                        {
                                $('#loader').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else 
                        {
                                $('#messages').html('<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#confirmform').prop("disabled",true);
                                comptabilisation(result.logiref_4);
                                $('#line'+id).remove();
                                $('#block').html();
                               
                        }
                        
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
}   
    
    
function comptabilisation(ref){
        $("#message").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank/display/comptabilisation'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}
   
</script>