<?php  



?>

<div class="col-md-12">
</div>
<div class="col-md-12">
    <?php $chtml->box_body_opening('', false);?>
        <div class="col-md-12">
            <?php if(!empty($prepayments)): ?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                           <table class="table no-margin table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th width="10px">#</th>
                                        <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                        <th width="200px">Declarant</th>
                                        <th width="100px" class="center">Nombre des bulletins</th>
                                        <th width="100px" class="center">Montant total</th>
                                        <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i =1; foreach($prepayments as $office => $payments): ?>
                                    <tr class="bg-gray">
                                        <td colspan="6" class="bold">
                                            <h4> <?php echo $services['DGDA'][$office]; ?></h4>
                                        </td>
                                    </tr>
                                        <?php $i =1;  foreach($payments as $payment): ?>
                                            <tr  id="line<?php echo $payment->Id_0;?>">
                                                <td width=""><?php echo $i;?></td>
                                                <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                                <td width=""><?php echo $payment->Declarant_16;?></td>
                                                <td width="" class="center"><?php echo $payment->total; ?></td>
                                                <td width="" class="text-blue center"><?php echo 'CDF '.number_format($payment->amounts,2,","," "); ?></td>
                                                <td style="text-align:center;">
                                                    <a style="cursor: pointer" onclick="edit('<?php echo $office; ?>','<?php echo $payment->AccountRef_14; ?>')"> 
                                                        <i class="fa fa-fw fa-edit text-green f20"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php $i++; endforeach;?>

                                    <?php  endforeach; ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="col-md-12">
                    <section id="cat_list" class="text-center marginTop150">
                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                        <span class="d-block f14 text-black p-2"><b>Aucun prépaiement trouv&eacute;!</b></span>        
                    </section>
                </div>
            <?php endif;?>
        </div>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="modal fade" id="modal">
    <div class="modal-dialog">
        <div class="modal-content tScroll">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">D&eacute;tails du paiement</h4>
            </div>
            <div id="modal-pager" class="modal-body">
              <p>One fine body&hellip;</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
        <!-- /.modal-dialog -->
</div>

<script type="text/javascript">


function edit(office, reference)
{
        var csrf = $('input[name="csrf_name"]').val();
        
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/traitement'); ?>/';
        
        $.ajax({
                        type        : 'GET', 
                        url         : url, 
                        data        : { office : office, compte : reference, csrf_name:csrf}, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(reponse)
                        {
                                $("#loader").html('');
                                $('#pager').html(reponse); 
                                $("#step-1").removeClass('bg-green-active');
                                $("#step-1").addClass('bg-gray');
                                $("#step-2").removeClass('bg-gray');
                                $("#step-2").addClass('bg-green-active');
                            
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  

}



</script>

