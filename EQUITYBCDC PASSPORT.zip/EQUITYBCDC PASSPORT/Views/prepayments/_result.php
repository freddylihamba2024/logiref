<div id="loader"></div>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    <div class="col-md-12">
        <div class="row">
            <div class="container mt-5 mb-5">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
                        <h4 class="card-title">Opération réussie</h4>
                        
                        <?php if($action == 'traiter'): ?>
                            <p class="card-text">Le débit du compte client et la génération du fichier fait avec succès, veuillez cliquer sur le bouton [envoyer] pour envoyer le fichier d'intégration.</p>
                        <?php else : ?>
                            <p class="card-text">La génération du fichier a été fait avec succès, veuillez cliquer sur le bouton [envoyer] pour envoyer le fichier d'intégration.</p>
                        <?php endif; ?>
                            
                        <button type="button" id="send_file" class="btn btn-success">Envoyer le fichier</button>&nbsp;&nbsp;
                        <button type="button" id="download" class="btn btn-primary" disabled>Télécharger le fichier</button><br/><br/><br/><br/>
                        <?php foreach($lot_id as $row): ?>
                            <input type="hidden" name="lot_id[]" value="<?php echo $row ?>" >
                        <?php endforeach; ?>
                    </div>
                    <br/><br/><br/><br/>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script type="text/javascript">
    
$("#send_file").click(function(){
    send_file();
});

$("#download").click(function(){
    var path = '<?= isset($file_lines->Pathexcel_8) ? $file_lines->Pathexcel_8 : '' ?>'
    
    if(path != '')
    {
        download_file(path);
    }
    else
    {
        $('#loader1').html('<div class="alert alert-warning">Echec du téléchargement du fichier, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
});
    
function send_file()
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    
    var data = $("#mainform").serialize();
    var url = '<?php echo base_url($module.'/taxprepayments'); ?>/data/send_file';
    
    $("#send_file").prop('disabled', true);
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode          : true,
        success: function(result){

            if(result == '200')
            {
                $("#download").prop('disabled', false);
                $('#loader1').html('<div class="alert alert-success">Bravo, fichier envoy&eacute; avec succ&egrave;s, veuillez cliquer sur téléchqrger pour visquliser le fichier envoyé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result == '404')
            {
                $('#loader1').html('<div class="alert alert-warning">Alerte: Echec! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result == 'E202')
            {
                $('#loader1').html('<div class="alert alert-danger">Alerte: Probl&egrave;me de connexion au serveur FTP.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result == 'E444')
            {
                $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi du fichier! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
            else if(result == 'E300')
            {
                $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi... fichier non trouv&eacute;! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        },
        error:function(error){
            $('#loader1').html('<div class="alert aWarning text-white">Une erreur est survenu lors de l\'enregistrement des écritures à inclure dans le fichier, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}
    
function download_file(buffer) {
    var link = document.createElement('a');
    link.href = '<?php echo base_url()?>' + buffer;
    link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}    
    
</script>