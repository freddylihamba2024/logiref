<div class="col-md-12">

</div>

<div class="col-md-12">
    <?php $chtml->box_body_opening('', false);?>
        <div class="col-md-12">
            <?php if(!empty($prepayments)): ?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin table-bordered">
                                <thead class='bg-blue'>
                                    <tr>
                                        <th width="10px">#</th>
                                        <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                        <th width="200px">Declarant</th>
                                        <th width="100px" class="center">Nombre des bulletins</th>
                                        <th width="100px" class="center">Montant total</th>
                                        <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i =1; foreach($prepayments as $office => $payments): ?>
                                    <tr class="bg-gray">
                                        <td colspan="6" class="bold">
                                            <h4> <?php echo $services['DGDA'][$office]; ?></h4>
                                        </td>
                                    </tr>
                                        <?php $i =1;  foreach($payments as $payment): ?>
                                            <tr  id="line<?php echo $payment->Id_0;?>">
                                                <td width=""><?php echo $i;?></td>
                                                <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                                <td width=""><?php echo $payment->Declarant_16;?></td>
                                                <td width="" class="center"><?php echo $payment->total; ?></td>
                                                <td width="" class="text-blue center"><?php echo 'CDF '.number_format($payment->amounts,2,","," "); ?></td>
                                                <td style="text-align:center;">
                                                    <a style="cursor: pointer" onclick="edit('<?php echo $office; ?>','<?php echo $payment->AccountRef_14; ?>')"> 
                                                        <i class="fa fa-fw fa-edit text-green f20"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php $i++; endforeach;?>
                                    <?php  endforeach; ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <h4 align="center"><b>Ce lot des prepaiements est d&eacute;j&agrave; extrait !</b></h4>
                        <br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    <?php $chtml->box_body_closing(); ?> 
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    var lot = '<?php echo $lot; ?>'; 


    function edit(office,reference)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module.'/taxprepayments/display/traitement'); ?>/';

        $.ajax({
            type        : 'GET', 
            url         : url, 
            data        : { office : office,  compte : reference}, 
            dataType    : 'html', 
            encode          : true,
            success: function(reponse)
            {
                    $("#loader1").html('');
                    $('#pager').html(reponse); 
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });  
    }
    
    $("#quit").click(function() {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/start'); ?>", function(data, status) {
            $("#loader1").html('');
            $("#pager").html(data);
            
            $("#close").addClass('d-none');
            $("#cancels").removeClass('d-none');
        });
    });



</script>

