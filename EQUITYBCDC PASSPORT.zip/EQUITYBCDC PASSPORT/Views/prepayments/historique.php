<div class="col-md-12 animated fadeInRight">
    <div class="mail-box">
        <?php if (!empty($prepaiement_logs)): ?><br/><br/>
            <table class="table table-hover table-mail">
                <tbody>
                    <?php
                    foreach ($prepaiement_logs as $key => $row):
                        ?>
                        <tr class="unread">
                            <td class="check-mail">
                                <i class=" fa fa-archive"></i> 
                            </td>
                            <td class="mail-ontact"><a href="#">Prépaiement extrait par  <b><?php echo isset($users[$row->Userid_4]) ? $users[$row->Userid_4] : " Automatisation"; ?></a></td>
                            <td class="mail-subject"><a href="#"></a></td>
                            <td class=""></td>
                            <td class="text-right mail-date"> 
                                <?php
                                $date = new DateTime($row->Date_1);
                                echo $date->format('H:i:s');
                                ?> 
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="box-footer clearfix">
                <div class="row">
                    <div class="col-md-12">
                        <button type="button" id="buttonCloseModal" class="btn btn-warning"><i class="fa fa-times"></i> Retour </button>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="col-md-12" style="height: 400px; display: flex; justify-content: center; align-items: center;">
                <section id="cat_list" class="text-center">
                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></span></br>
                    <span class="d-block p-2 f14 text-black">Aucun prépaiement trouv&eacute;!</span>        
                </section>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    $("#buttonCloseModal").click(function () {
        $.get("<?php echo base_url($module . '/taxsettings/display/settings/comptes/accounts'); ?>", function (data, status) {
            $("#loader-page").html('');
        });
    })

    $("#buttonCloseModal").click(function () {
        $("#loader-sub-menu").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/start'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');
            $("#sub-menu").html(data);
        });

    });
</script>