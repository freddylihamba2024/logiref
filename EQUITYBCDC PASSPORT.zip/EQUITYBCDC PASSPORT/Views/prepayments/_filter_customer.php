<div class="box-body box-solid no-padding">
    <div class="col-md-12 no-padding">
        <div class="box-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class='bg-gray'>
                        <tr>
                            <th width="5px">#</th>
                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                            <th width="150px">Bureau</th>
                            <th width="100px">Declarant</th>
                            <th width="100px" class="center">Nombre des bulletins</th>
                            <th width="150px" class="center">Montant total</th>
                            <th width="10px" class="align-middle"  style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach($prepayments as $customer => $payments): ?>
                        <tr>
                            <td class="align-middle" width=""><?php echo $i; ?></td>
                            <td class="align-middle" width=""><?php echo $customer; ?></td>

                            <?php 
                            // Initialisation des variables pour stocker les données collectées
                            $offices = '';
                            $declarants = '';
                            $totals = '';
                            $amounts = '';
                            $editLinks = '';

                            foreach($payments as $payment):
                                // Collecte des informations dans des variables HTML
                                $offices .= '<li>' . $services['DGDA'][$payment->Office_8] . '</li>';
                                $declarants .= '<li>' . $payment->Declarant_16 . '</li>';
                                $totals .= '<li>' . $payment->total . '</li>';
                                $amounts .= '<li>' . 'CDF ' . number_format($payment->amounts, 2, ",", " ") . '</li>';

                            endforeach;
                            ?>

                            <td class="align-middle pl-3" width=""><ul><?php echo $offices; ?></ul></td>
                            <td class="align-middle pl-3" width=""><ul><?php echo $declarants; ?></ul></td>
                            <td class="align-middle pl-3" width=""><ul><?php echo $totals; ?></ul></td>
                            <td class="align-middle pl-3" width=""><ul><?php echo $amounts; ?></ul></td>
                            <td class="align-middle" width="">
                                <a style="cursor: pointer" onclick="edit('<?php echo $customer; ?>', 'Customer', '<?php echo $payment->Office_8; ?>')"> 
                                    <i class="fa fa-fw fa-edit text-blue f20"></i> 
                                </a>
                            </td>
                        </tr>
                        <?php $i++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>