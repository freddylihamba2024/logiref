<div id="pager">
    <div class="col-md-12">
        <div id="loader1">
            <?php
            
            if($total_instruction > 1000)
            {
                    echo '<div class="alert aWarning text-white">Le lot de prépaiement sélectionnés contient plus de 1000 écritures comptables, veuillez séléctionner un lot de moins de 1000 écritures comptables s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
            }
            
            ?>
        </div>
        
        <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="col-md-12">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4">
                                        <label for="office">Compte Guichet unique</label>
                                    </div>
                                    <div class="col-md-8">
                                        <b>:</b>  <?php echo isset($compte_guichet_unique) ? $compte_guichet_unique : ""; ?>
                                        <input type='hidden' name='cGuichet' value='<?php echo $compte_guichet_unique ?>'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4">
                                        <label for="office">Nbre de prépaiements</label>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($total_bulletin > 1): ?>
                                            <b>:</b> <?php echo $total_bulletin." bulletins"; ?>
                                        <?php else: ?>
                                            <b>:</b> <?php echo $total_bulletin." bulletin"; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-group col-md-12 no-padding">
                                    <div class="col-md-4">
                                        <label for="office">Nbre d'instructions</label>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($total_instruction > 0): ?>
                                            <b>:</b> <?php echo $total_instruction." ecritures"; ?>
                                        <?php else: ?>
                                            <b>:</b> <?php echo $total_instruction." ecriture"; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Montant total du lot</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> <span id="total_amount"><?php echo $total_amount; ?></span> CDF
                                    <input type="hidden" id="lot_amount" value="<?php echo $total_amount; ?>" name="total_amount"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Commission</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> 0,00 CDF
                                   <input type="hidden" id="Commission" value="0" name="commission"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">TVA</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> 0,00 CDF
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            
                <div class="box-footer clearfix">
                    <div class="col-md-12 p-0">
                        <br/>
                        <button type="submit" id="treat" class="btn btn-primary" disabled><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="save" class="btn btn-success" <?php if($total_instruction > 1000) echo '' ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;Créer le fichier&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="action" value="" id="action">
                        <input type="hidden" name="account_reference" value="<?= $prepayment->AccountRef_9; ?>" >
                        <input type="hidden" name="Compte_33" value="<?= $prepayment->Account_15; ?>" >
                    </div>
                </div>
            
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
            <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead class='bg-gray'>
                        <tr class="bg-blue">
                            <th width="5px">#</th>
                            <th width="10px">Date</th>
                            <th width="200px">Bureau</th>
                            <th width="100px">N° imp&ocirc;t</th>
                            <th width="20px">Bulletin</th>
                            <th width="160px">Montant</th>
                            <th width="10px" class="" ><i class="fa fa-edit f20"></i></th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $i=1; foreach($prepayments_list as $compte=>$value) : ?>
                                <tr class="bg-gray">
                                    <td colspan="7" class="bold">
                                        <span class="f15"><b><?php echo isset($compte) ? "Compte sydonia ".$compte : ""; ?></b></span>
                                    </td>
                                </tr>
                                <input type="hidden" value="<?php echo isset($value[0]->Lot_19) ? $value[0]->Lot_19 : "" ?>" name="lot_id[]"/>
                                <?php foreach($value as $row) :?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td  width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));?></td>
                                    <td  width=""><?php echo isset($services['DGDA'][$row->Office_8]) ? $services['DGDA'][$row->Office_8] : "";?></td>
                                    <td  width=""><?php echo $row->Nif_15;?></td>
                                    <td><?php echo $row->Serial_9.''.$row->Number_10; ?></td>
                                    <td ><?php echo 'CDF'.' '.number_format($row->Amount_18,2,","," ");?></td>
                                    <td width="10px">
                                        <a style="cursor: pointer" onclick="view_bulletin('<?php echo $row->Id_0; ?>', '')"> 
                                            <i class="fa fa-edit f20"></i> 
                                        </a>
                                    </td>
                                </tr>
                                <?php $i++; endforeach;?>
                        <?php endforeach;?>
                        <input type="hidden" value="" name="instruction_file_id" id="instruction_file_id"/>
                        
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo form_close(); ?>
        <?php $chtml->box_body_closing(); ?> 
    </div>
    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-custom-width">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">

    $("#contenter").on("click", "#close_form", function(){
        close_form();
    });

    get_accountname();
    
    $("#treat").click(function(){
       $("#action").val('traiter');
    });

    $("#save").click(function(){
       $("#action").val('save');
    });
    
    $("#portail").click(function(){

           $("#save").prop('disabled', false);
           $("#treat").prop('disabled', true);
           $("#action").val('save');
    });
    $("#virmul").click(function(){

           $("#treat").prop('disabled', false);
           $("#save").prop('disabled', true);
           $("#action").val('traiter');
    });
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'traiter')
        {   
            debit_customer(data);
        }
        else if(action == 'save')
        {
            save_integration_sftp(data);
        }
    });
    
    $("#close").click(function(){
           close_form();
    });
    
    
    function debit_customer(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments'); ?>/save/debit_client';
        $("#treat").prop('disabled', true);
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        $('#loader').html(result)
                        
                        if(result.code=='E407')
                        {
                            $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#repartition').prop("disabled",false);
                            $('#valider').prop("disabled",true);
                        }
                         
                        else if(result.code =='200')
                        {
                            $('#loader1').html('<div class="alert alert-info"> Traitement fait avec succ&egrave;s, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            //$("#save").prop('disabled', false);
                            //$("#treat").prop('disabled', true);
                            //$('#close').prop("disabled",false);
                            var data = $('#mainform').serialize();
                            save_instructions_offline(data);
                        }
                        else if(result.code =='E500')
                        {
                            $('#loader1').html('<div class="alert alert-info"> Vous avez d&eacute;j&agrave; trait&eacute; ce lot des bulletins, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#save").prop('disabled', false);
                            $("#treat").prop('disabled', true);
                            $('#close').prop("disabled",false);
                        }
                        else if(result.code =='E501')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#close').prop("disabled",false);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E502')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#close').prop("disabled",false);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E503')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#close').prop("disabled",false);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E301')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Probl&eacute;me de connexion &agrave; amplitude, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#close').prop("disabled",false);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E302')
                        {
                                $('#loader1').html('<div class="alert alert-danger">Le d&eacute;bit du compte du client s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E303')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est fait partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E304')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est fait partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E305')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#verify').removeClass('d-none');
                        }
                        else if(result.code =='E306')
                        {
                                $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#treat").prop('disabled', true);
                                $('#verify').removeClass('d-none');
                        }
                },
                error:function(error){
                    $('#loaders').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse du corebanking est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
    }

    function save_integration_sftp(data)
    {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taxprepayments'); ?>/save/integration_sftp';
            //$("#save").prop('disabled', true)
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                        
                        $("#loader1").html('');
                        
                        if(result === "E407")
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, le type d\'intégration n\'est pas défini !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(isNaN(result)==true)
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result > 0) 
                        {
                                create_file(result);
                        }
                        else
                        {
                                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }

                    },
                    error:function(error){
                        $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'a pas été créé, veuillez réessayer s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }
    
    function create_file(id)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = $("#mainform").serialize();
        var url = '<?php echo base_url($module.'/taxprepayments'); ?>/data/create_file_xml/'+id;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){

                $("#loader1").html('');
                
                if(result == '200')
                {
                    result_treatment(id)
                }
                else if(isNaN(result)==true)
                {
                    $('#loader1').html('<div class="alert aWarning">La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '405' || result == '406')
                {
                    $('#loader1').html('<div class="alert alert-warning">Alerte: La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '500')
                {
                    $('#loader1').html('<div class="alert alert-danger">Alerte: Le formatage du fichier créé n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result == '501')
                {
                    $('#loader1').html('<div class="alert alert-danger">Alerte: L\'enregistrement du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error){
                $('#loader1').html('<div class="alert aWarning">La création du fichier n\'a pas abouti, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    

    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '<?php echo $compte_guichet_unique; ?>';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function result_treatment(id)
    {
        var data = $('#mainform').serialize();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var url = '<?php echo base_url($module.'/taxprepayments/display/result_integration_xml'); ?>/'+id;

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-2").removeClass('bg-green-active');
                $("#step-2").addClass('bg-gray');
                $("#step-3").removeClass('bg-gray');
                $("#step-3").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    

    function view_bulletin(id) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/preview_details_tax'); ?>/'+id;
        $.get(url, function (data, status) {
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
    }
    
    
    
    function close_form()
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module.'/taxreports/display/prepayments'); ?>", function (data, status) {
           $("#loader1").html('');
           $("#pager").html(data);
           $("#pager").addClass('content');

           $("#close").removeClass('hidden');
           $("#close_form").addClass('hidden');

        });
    }

</script>
