<div class="col-md-12">
    <div class="row">
        <div class="col-md-6 no-padding">
            <h1 class="f30 text-blue">Pr&eacute;paiements</h1>
            <p class="page-header">Extraction et traitement  des pr&eacute;paiements</p>     
        </div>

        <div class="col-md-6 no-padding">
        </div>
    </div>

    <div id="loader1"></div>
    <div id="pager">
        <?php if ($step == 1 || $step == 2): ?>
            <?php $this->load->view('_prepayments'); ?>
        <?php elseif ($step == 3): ?>
            <?php $this->load->view('_step_3'); ?>
        <?php else: ?>
            <div class="row">
                <div  class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'col-md-12 mt-3 mb-3'; ?>">
                    <div class="row">
                        <div class="col-md-1">
                            <div id="step-1" title="" class="bRound <?php
                            if ($step == 0) {
                                echo 'bg-green-active';
                            } else {
                                echo 'bg-gray';
                            }
                            ?> center pull-right">1</div>
                        </div>
                        <div class="col-md-3 pt-2">
                            <div class="pull-left f12 text-black">Lots à traiter<br/></div>
                        </div>
                        <div class="col-md-1">
                            <div id="step-2" title="" class="bRound <?php
                            if ($step == 2 || $step == 1) {
                                echo 'bg-green-active';
                            } else {
                                echo 'bg-gray';
                            }
                            ?> center pull-right">2</div>
                        </div>
                        <div class="col-md-3 pt-2">
                            <div class="pull-left f12 text-black">Lots sélectionnés<br/></div>
                        </div>
                        <div class="col-md-1">
                            <div id="step-3" title="" class="bRound <?php
                            if ($step == 3) {
                                echo 'bg-green-active';
                            } else {
                                echo 'bg-gray';
                            }
                            ?> center pull-right">3</div>
                        </div>
                        <div class="col-md-3 pt-2">
                            <div class="pull-left f12 text-black">Résultat<br/></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div id="list">

                        <?php if (!empty($prepayments)): ?>
                            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                            <?php $chtml->box_body_opening('', false); ?>

                            <div class="box-body box-solid no-padding">
                                <div class="col-md-12 no-padding">
                                    <div class="box-body">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-striped" id="table">
                                                <thead class='bg-gray'>
                                                    <tr>
                                                        <th width="5px">#</th>
                                                        <th width="100px">R&eacute;f&eacute;rence du compte</th>
                                                        <th width="150px">Bureau</th>
                                                        <th width="100px">Declarant</th>
                                                        <th width="100px" class="center">Nbre des bulletins</th>
                                                        <th width="150px" class="center">Montant total</th>
                                                        <th width="50px" class="center">Date</th>
                                                        
                                                        <!-------------------------  Verification of integration mode  ------------------------------>
                                                        <!-------------------------  Web service validation or SFTP    ------------------------------>
                                                        <?php if(isset($options['DGDA']['breakdown-accounting-by-web-service-validation'])){ ?>
                                                            <th width="10px" class="align-middle"  style="text-align:center;"><i class="fa fa-list f20"></i></th>
                                                        <?php }if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){ ?>
                                                            <th width="10px" class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'center'; ?>"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check d-none f16"></i></th>
                                                        <?php } ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $i = 1;
                                                    foreach ($prepayments as $payments):
                                                        ?>
                                                        <tr>
                                                            <td class="align-middle" width=""><?php echo $i; ?></td>
                                                            <td class="center" width=""><?php echo $payments->AccountRef_9; ?></td>

                                                            <?php
                                                                $bureaux = json_decode($payments->Office_7, true);
                                                                $offices = '';

                                                                if (isset($bureaux) && is_array($bureaux)) 
                                                                {
                                                                    foreach ($bureaux as $bureau) 
                                                                    {
                                                                        $office = isset($services['DGDA'][$bureau]) ? $services['DGDA'][$bureau] : '';

                                                                        $offices .= '<li>' . $office . '</li>';
                                                                    }
                                                                }
                                                                elseif (is_string($bureaux)) 
                                                                {
                                                                    $office = isset($services['DGDA'][$bureaux]) ? $services['DGDA'][$bureaux] : '';
                                                                    $offices .= '<li>' . $office . '</li>';
                                                                }
                                                                else 
                                                                {
                                                                    $office = isset($services['DGDA'][$payments->Office_7]) ? $services['DGDA'][$payments->Office_7] : '';
                                                                    $offices .= '<li>' . $office . '</li>';
                                                                }
                                                            ?>

                                                            <td class="center" width=""><ul><?php echo $offices; ?></ul></td>
                                                            <td class="center" width=""><?php echo $payments->Declarant_8; ?></td>
                                                            <td class="center" width=""><?php echo $payments->Declarations_10; ?></td>
                                                            <td class="center" width=""><?php echo $payments->Amout_12; ?></td>

                                                            <td class="center" width=""><?php echo strftime('%d-%m-%Y', strtotime($payments->Date_1)); ?></td>

                                                            <!-------------------------  Verification of integration mode  ------------------------------>
                                                            <!-------------------------  Web service validation or SFTP    ------------------------------>
                                                            <?php if(isset($options['DGDA']['breakdown-accounting-by-web-service-validation'])){ ?>
                                                                <td style="text-align:center;">
                                                                    <a style="cursor: pointer" onclick="edit('<?php echo $payments->Id_0; ?>')"> 
                                                                        <i class="fa fa-list text-blue f20"></i> 
                                                                    </a>
                                                                </td>
                                                            <?php } if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){ ?>
                                                                <td style="text-align:center;" class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'center'; ?>">
                                                                    <input type="checkbox" class="text-blue" id='' onclick="select_payments()" value="<?php echo $payments->Lot_11; ?>" name="batch[]" />
                                                                </td>
                                                            <?php } ?>
                                                        </tr>
                                                        <?php
                                                        $i++;
                                                    endforeach;
                                                    ?>
                                                </tbody>

                                            </table>
                                            <div  class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'col-md-12 no-padding'; ?>">
                                                <button type="button" id="suivant" disabled="" class="btn btn-primary mt-3 pull-right"><i class="fa fa-arrow-circle-right"></i> Suivant <span id="index"></span>&nbsp;&nbsp;</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $chtml->box_body_closing(); ?>
                        <?php echo form_close(); ?>
                        </div>
                    <?php else: ?>
                        <?php $chtml->box_body_opening(); ?> 
                        <section id="cat_list" class="text-center marginTop150">
                            <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                            <span class="d-block f14 text-black p-2">Aucun pr&eacute;paiement à traiter pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                        </section>
                        <?php $chtml->box_body_closing(); ?> 
                    <?php endif; ?>
                </div>
            </div>
<?php endif; ?>
    </div>
</div>


<script type="text/javascript">

    $('#dateDebut').datepicker({
        format: 'yyyy-mm-dd'
    });

    $('#dateFin').datepicker({
        format: 'yyyy-mm-dd'
    });

    $("#extractform").submit(function (event) {
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
    });

    $("#cancel").click(function () {
        location.reload(true);
    });
    
    $('#checkall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', 'checked');
        $('.check').removeClass("hidden");
        $('#checkall').addClass("d-none");
        $('#uncheckall').removeClass("d-none");

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;
        $("#suivant").prop("disabled",false);


        $("#submit").removeClass("disabled");
        $("#submit").prop("disabled",false);
        $("#index").html('('+ index+')');
    });

    $('#uncheckall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', '');
        $('.check').addClass("hidden");
        $('#checkall').removeClass("d-none");
        $('#uncheckall').addClass("d-none");

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;
        $("#suivant").prop("disabled",true);

        $("#submit").removeClass("btn-primary");
        $("#submit").addClass("btn-success");
        $("#submit").prop("disabled",true);
        $("#index").html('');

    });
    
    $("#_historique").on('click', function (e) {
        e.preventDefault();
         $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/historique'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');
            $("#general_block").addClass('d-none');
            $("#prepayment_block").removeClass('d-none');
            $("#sub-menu").html(data);
            $("#title").html('Bulletin des prépaiements (DGDA)');
            $("#sub-title").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
            $("#title-prepayment").html('Bulletin des prépaiements (DGDA)');
            $("#sub-title-prepayment").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
        });
    });


    function edit(param, item, param1 = null)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = '';
        var url = '';
        if (item == "Customer")
        {
            url = '<?php echo base_url($module . '/taxprepayments/display/treatment_customer'); ?>/';
            data = {compte: param, office: param1};
        }
        if (item == "Office")
        {
            url = '<?php echo base_url($module . '/taxprepayments/display/treatment_office'); ?>/';
            data = {office: param};
        }

        $.ajax({
            type: 'GET',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (reponse)
            {
                $("#loader-sub-menu").html('');
                $("#general_block").removeClass('d-none');
                $("#prepayment_block").addClass('d-none');
                $('#pager').html(reponse);

            },
            error: function (error)
            {
                $("#loader-sub-menu").html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    }

    function filter(which)
    {
        $("#alert").html('');

        $("#loader-sub-menu").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module . '/taxprepayments/display/prepayments_filter'); ?>/" + which, function (data, status) {
            $("#loader-sub-menu").html('');
            $("#list").html(data);
        });
    }


    $("#historique").click(function () {

        $("#loader-sub-menu").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/historique'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');

            $("#list").html(data);
        });
    });


    function edit(id)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxprepayments/display/prepayment'); ?>/' + id;

        $.ajax({
            type: 'GET',
            url: url,
            dataType: 'html',
            encode: true,
            success: function (reponse)
            {
                $("#loader1").html('');
                $('#list').html(reponse);
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active')

            },
            error: function (error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    }

    $("#suivant").click(function () {

        var data = $('#mainform').serialize();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxprepayments/display/__prepayment'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active');

            },
            error: function (error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    function action(which)
    {
        $("#alert").html('');

        $("#loader1").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module . '/taxprepayments/display/prepayments_filter'); ?>/" + which, function (data, status) {
            $("#loader1").html('');
            $("#list").html(data);
        });
    }

    function select_payments()
    {
        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;

        if (index > 0)
        {
            $("#suivant").prop("disabled",false);
            $("#index").html('(' + index + ')');
        } else if (index <= 0)
        {
            $('#checkall').removeClass("hidden");
            $('#uncheckall').addClass("hidden");

            $("#suivant").prop("disabled",true);
            $("#index").html('');
        }
    }


</script>