<?php
$total_amount = 0;
$codebank = '';
$declarant = '';

?>

<div id="pager">
    <div class="col-md-12 p-0">
        <div id="loader1"><?php echo ""; ?></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
        <?php $chtml->box_body_opening('', true); ?>
        <div class="col-md-12 p-0">
            <div class="box-body">
                <input type="hidden" id="Npaiements" value="<?php echo count($prepayments); ?>" name="Npaiements"/>
                <input type="hidden"  value="<?php echo (isset($office)) ? $office : ''; ?>" name="Office"/>
                <input type="hidden" value='<?php echo htmlspecialchars(json_encode($prepayments), ENT_QUOTES, 'UTF-8'); ?>' name="Prepayments" id="Prepayments"/>

                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header">Traitement des bulletins  pr&eacute;pay&eacute;s</h2>
                    <br/>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Bureau</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($services['DGDA'][$office]) ? $services['DGDA'][$office] : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Banque</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="code_bank"></span>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;clarant</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="declarant"></span>
                                    <input type="hidden" id="Declarant" value="<?php echo $declarant ?>" name="Declarant"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Montant total du lot</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="total_amount"></span> CDF
                                    <input type="hidden" id="lot_amount" value="0" name="total_amount"/>
                                </div>
                            </div>

                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte Guichet unique</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b>  <?php echo isset($cguichet) ? $cguichet : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Total à payer</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="topaid"> </span> <?php echo "CDF"; ?>
                                    <input type="hidden" id="tota_to_paid" name="tota_to_paid"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div class="col-md-12">
                    <br/>
                    <button type="submit" id="treat" class="btn btn-primary" ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" id="start_auto_debit" class="btn btn-default" disabled="disabled"><i class="fa fa-archive"></i>&nbsp;&nbsp;Reserver&nbsp;&nbsp;</button>
                    <button type="submit" id="verify_failed" class="btn btn-danger d-none" ><i class="fa fa-history"></i>&nbsp;&nbsp;Vérifier les <span id="failedCount">0</span> échec(s)&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit" id="save" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp; 
                    <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  

                    <input type="hidden" name="action" value="" id="action">
                    <input type="hidden" name="logirefid" value="" id="logirefid">
                    <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                    <input type="hidden" name="transaction_id" value="" id="transaction_id">
                    <input type="hidden" name="error_code" value="" id="error_code">
                    <input type="hidden" name="data_office" value="" id="data_office">
                </div>
            </div>
        </div>
        <?php if(isset($options['DGDA']['prepayment-fee-deduction-current-account'])): ?>
            <div class="row">
                <div class="col-md-12">
                    <br/>
                    <label class="f12 w-300 page-header"><h5> Informations additionnelles : Paie les frais&nbsp;&nbsp;[ <span  style="" class="text-danger">Requis</span> <input type="checkbox" class="check" name="Infos[fees]" value="<?= 1 ?>"> ]</h5></label><br/>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
                <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th width="">#</th>
                            <th width="50px">Date</th>
                            <th width="200px">Bureau</th>
                            <th width="150px">Compte SYDONIA</th>
                            <th width="100px">Declarant</th>
                            <th width="200px" class="center">Nbre bulletins</th>
                            <th width="150px" class="">Montant total</th>
                            <th width="" class="text-center">Statuts</th>
                            <th colspan="" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $i = 1;foreach ($prepayments as $oKey => $payments): ?>
                            <tr>
                                <?php $j = 0; foreach ($payments as $payment):?>
                                    <?php $compte_prepaid = (isset($comptes_ps[$payment->AccountRef_14]['CPS']['CDF'])) ? $comptes_ps[$payment->AccountRef_14]['CPS']['CDF'] : ''; ?>

                                    <?php if(isset($options['DGDA']['prepayment-fee-deduction-current-account'])): ?>
                                        <tr>
                                            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>

                                                <td colspan="1" class="text-blue text-right"><b><span id="accountname<?= $payment->AccountRef_14; ?>">Compte de pr&eacute;paiement</span></b></td>
                                                <td colspan="2" class=""><input id="account<?= $payment->AccountRef_14 ?>" type="text" name="account[<?= $payment->AccountRef_14; ?>]" value="<?= $compte_prepaid ?>" data-id-account ="<?= $payment->AccountRef_14; ?>" class="form-control" readonly /></td>
                                                <input id="account_balance<?= $payment->AccountRef_14 ?>" type="hidden" value="" name="account_balance[<?= $payment->AccountRef_14; ?>]" />

                                                <td colspan="1" class="text-blue text-right"><b><span id="labelNumber<?php echo $payment->AccountRef_14; ?>">Code client</span></b></td>
                                                <td colspan="1">
                                                    <input id="customerNumber<?php echo $payment->AccountRef_14 ?>" name="customerNumber[<?php echo $payment->AccountRef_14; ?>]" type="text" value="<?= ""  ?>" data-id-customercode="<?php echo $payment->AccountRef_14; ?>" class="form-control customer-code"  placeholder="E.g: 123456" maxlength="7"   />
                                                </td>
                                                <td colspan="1" class="text-blue text-right"><b><span id="account_c_name<?php echo $payment->AccountRef_14; ?>">Compte pour les frais</span></b></td>
                                                <td colspan="2" class=""><input id="bank_accountc<?php echo $payment->AccountRef_14 ?>" name="Customer_current_account[<?php echo $payment->AccountRef_14; ?>]" type="text" value="<?= ""  ?>" data-id-compte ="<?php echo $payment->AccountRef_14; ?>" class="form-control compte_current" placeholder="E.g: 023102253130013300000"   /></td>
                                                <input type="hidden" name="accountc_name[<?php echo $payment->AccountRef_14; ?>]" id="accountc_name<?php echo $payment->AccountRef_14 ?>" value="">
                                                <input type="hidden" name="account_balance_fees[<?php echo $payment->AccountRef_14 ?>]" id="account_balance_fees<?php echo $payment->AccountRef_14 ?>" value="0" >
                                                <!-- <td colspan="1"  class="text-blue text-right"><b>Devise</b></td> -->
                                                <td colspan="1" class="">
                                                    <select  name="Devise_account_c[<?php echo $payment->AccountRef_14; ?>]" data-id-devise ="<?php echo $payment->AccountRef_14; ?>" class="form-control devise_account_c"  id="Devise_account_c<?php echo $payment->AccountRef_14; ?>" >
                                                        <option value="" disabled selected hidden>E.g: Sélectionner devise</option>
                                                        <option value="CDF" >CDF</option>
                                                        <option value="USD" >USD</option>
                                                    </select>
                                                </td>
                                            <?php else: ?>

                                                <td colspan="1" class="text-blue text-right"><b><span id="accountname<?= $payment->AccountRef_14; ?>">Compte de pr&eacute;paiement</span></b></td>
                                                <td colspan="2" class=""><input id="account<?= $payment->AccountRef_14 ?>" type="text" name="account[<?= $payment->AccountRef_14; ?>]" value="<?= $compte_prepaid ?>" data-id-account ="<?= $payment->AccountRef_14; ?>" class="form-control" readonly /></td>
                                                <input id="account_balance<?= $payment->AccountRef_14 ?>" type="hidden" value="" name="account_balance[<?= $payment->AccountRef_14; ?>]" />

                                                <td colspan="1" class="text-blue text-right"><b><span id="account_c_name<?php echo $payment->AccountRef_14; ?>">Compte pour les frais</span></b></td>
                                                <td colspan="2" class=""><input id="bank_accountc<?php echo $payment->AccountRef_14 ?>" name="Customer_current_account[<?php echo $payment->AccountRef_14; ?>]" type="text" value="<?= ""  ?>" data-id-compte ="<?php echo $payment->AccountRef_14; ?>" class="form-control compte_current" /></td>
                                                <input type="hidden" name="accountc_name[<?php echo $payment->AccountRef_14; ?>]" id="accountc_name<?php echo $payment->AccountRef_14 ?>" value="">
                                                <input type="hidden" name="account_balance_fees[<?php echo $payment->AccountRef_14 ?>]" id="account_balance_fees<?php echo $payment->AccountRef_14 ?>" value="0" >
                                                <td colspan="2"  class="text-blue text-right"><b>Devise</b></td>
                                                <td colspan="1" class="">
                                                    <select  name="Devise_account_c[<?php echo $payment->AccountRef_14; ?>]" data-id-devise ="<?php echo $payment->AccountRef_14; ?>" class="form-control devise_account_c"  id="Devise_account_c<?php echo $payment->AccountRef_14; ?>" >
                                                        <option value=""></option>
                                                        <option value="CDF" >CDF</option>
                                                        <option value="USD" >USD</option>
                                                    </select>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php else: ?>
                                        <td colspan="2" class="text-blue text-right"><b><span id="accountname<?= $payment->AccountRef_14; ?>">Compte de pr&eacute;paiement</span></b></td>
                                        <td colspan="3" class=""><input id="account<?= $payment->AccountRef_14 ?>" type="text" name="account[<?= $payment->AccountRef_14; ?>]" value="<?= $compte_prepaid ?>" data-id-account ="<?= $payment->AccountRef_14; ?>" class="form-control" readonly /></td>
                                        <input id="account_balance<?= $payment->AccountRef_14 ?>" type="hidden" value="" name="account_balance[<?= $payment->AccountRef_14; ?>]" />
                                        <td colspan="1">CDF</td>
                                        <td colspan="3"></td>
                                    <?php endif; ?>
                                    <tr id="line<?php echo $j; ?>" >
                                        <td width=""><?php echo $i; ?></td>
                                        <td width="50px"><?php echo strftime('%d-%m-%Y', strtotime($payment->Date_1)); ?></td>
                                        <td width=""><?php echo $services['DGDA'][$oKey]; ?></td>
                                        <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                        <td width=""><?php echo $payment->Declarant_16; ?></td>
                                        <td width="" class="center"><?php echo $payment->total; ?></td>
                                        <td width="" class="text-blue"><?php echo 'CDF ' . number_format($payment->amounts, 2, ",", " "); ?></td>
                                        <td class="text-center">
                                            <span id="prepayment_result<?php echo $j; ?>" class='text-yellow bold'>En attente</span>
                                        </td>
                                        <td class="text-right">
                                            <!-- <button type="button" style="cursor: pointer;color: white;" class="btn btn-sm btn-success debit_client" disabled="disabled" id="debit_client<= $payment->Lot_19 ?>" data-index="<= $j ?>" onclick="debit_client('<= $payment->AccountRef_14 ?>','<= $payment->Lot_19 ?>','<= $j ?>')" data-id-debit ="<php echo $payment->AccountRef_14; ?>">Débiter</button> -->
                                            <button class="btn btn-sm btn-primary debit_client d-none" id="debit_client<?= $payment->Lot_19 ?>" data-account-ref="<?= $payment->AccountRef_14 ?>" data-lot-id="<?= $payment->Lot_19?>" onclick="debit_client('<?= $payment->AccountRef_14 ?>','<?= $payment->Lot_19 ?>','<?= $j ?>')" >Débiter</button>
                                            <button type="button" style="cursor: pointer;color: white;" class="btn btn-sm btn-danger verify_transaction d-none" id="verify_transaction<?= $payment->Lot_19 ?>" onclick="verify_transaction('<?= $payment->AccountRef_14 ?>','<?= $payment->Lot_19 ?>','<?= $j ?>')" data-id-verify ="<?php echo $payment->AccountRef_14; ?>">vérifier</button>
                                            <a style="cursor: pointer" id="bl_view<?= $payment->Lot_19 ?>" onclick="view_bulletin('<?php echo $payment->AccountRef_14; ?>', '<?php echo $oKey; ?>')"> 
                                                <i class="fa fa-edit f20"></i> 
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                        $total_amount += $payment->amounts;
                                        $codebank = $payment->CodeBank_13;
                                        $declarant = $payment->Declarant_16;

                                        $data_accountref[$j] = $payment->AccountRef_14;
                                    ?>
                                    <input type="hidden" name="tota_to_paid[<?= $payment->Lot_19 ?>]"  value="<?= $payment->amounts ?>" id="tota_to_paid<?= $payment->AccountRef_14 ?>" data-paid="<?= $payment->AccountRef_14 ?>">
                                    <input type="hidden" name="transaction_id[<?= $payment->Lot_19 ?>]"  value="" id="transaction_id<?= $payment->Lot_19 ?>" data-lot="<?= $payment->Lot_19 ?>">
                                <?php $j++; $i++; endforeach;?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>    
                </table>
            </div>
        </div>
<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>
    </div>
    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    // Déclaration des variables globales pour CSRF, compteur et données diverses
    let csrfName = '<?= csrf_token() ?>';
    let csrfHash = '<?= csrf_hash() ?>';

    let counter = 0;
    let i = 1;
    let data_office = '';

    let filteredButtons = [];

    let failedDebits = []; 
    let noAccountRefs = [];
    let successfulVerifications = 0;

    // Initialisation des montants et affichage dans le DOM
    let total_amount = '<?php echo $total_amount ?>';
    $("#total_amount").html(total_amount.toLocaleString());
    $("#lot_amount").val(total_amount);
    $("#topaid").html(total_amount.toLocaleString());
    $("#tota_to_paid").val(total_amount);

    // Affichage des infos générales comme code banque et déclarant
    let code_bank = '<?php echo $codebank ?>';
    $("#code_bank").html(code_bank);
    $("#declarant").html('<?php echo $declarant ?>');

    $("#contenter").on("click", "#close_form", function () {
        close_form();
    });

    // Fonction appelée lorsqu’on clique sur le bouton "Traiter"
    $("#treat").click(function () {
        $("#loader-sub-menu").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let valid_refs = [];
        let all_refs = [];
        let count_no_account = 0;
        let count_insufficient = 0;

        $("input[name^='account[']").each(function (index) {
            let ref = $(this).data('id-account');
            let val = $(this).val().trim();

            if (ref) {
                all_refs.push(ref);
                let result_span = $("#" + escapeID("prepayment_result" + index));

                if (val !== '') {
                    let balance_input = $("#account_balance" + escapeID(ref));
                    let balance = parseFloat(balance_input.val()) || 0;

                    let to_pay_input = $("#tota_to_paid" + escapeID(ref));
                    let to_pay = parseFloat(to_pay_input.val()) || 0;

                    if (balance >= to_pay) {
                        valid_refs.push(ref);
                        result_span.removeClass('text-red').addClass('text-yellow').html('En attente');
                    } else {
                        count_insufficient++;
                        balance = balance.toLocaleString();
                        result_span.removeClass('text-yellow').addClass('text-red').html("Solde insuffisant (" + balance + ")");
                    }
                } else {
                    count_no_account++;
                    result_span.removeClass('text-yellow').addClass('text-red').html("Compte pr&eacute;payement manquant");
                }
            }
        });

        let raw = $("#Prepayments").val();
        let prepayments = {};

        try {
            prepayments = JSON.parse(raw);
        } catch (e) {
            prepayments = {};
        }

        let filtered = {};

        valid_refs.forEach(ref => {
            Object.entries(prepayments).forEach(([office, items]) => {
                if (items[ref] !== undefined) {
                    if (!filtered[office]) filtered[office] = {};
                    filtered[office][ref] = items[ref];
                }
            });
        });

        if (valid_refs.length > 0) {
            $("#Prepayments").val(JSON.stringify(filtered));
            $("#action").val('traiter');
        } else {
            let message = "Aucun prépaiement à traiter.";
            if (count_no_account > 0 && count_insufficient > 0) {
                message += `Le traitement est interrompu : <b>${count_no_account}</b> ligne(s) n'ont pas de compte de prépaiement configuré, et <b>${count_insufficient}</b> ligne(s) présentent un solde insuffisant.`;
            } else if (count_no_account > 0) {
                message += "Le traitement est interrompu : certains paiements n'ont pas de compte de prépaiement configuré.";
            } else if (count_insufficient > 0) {
                message += "Le traitement est interrompu : les comptes prépaiements configurés n'ont pas suffisamment de fonds.";
            }

            $("#loader-sub-menu").html(`
                <div class="alert aDanger text-white">
                    ${message}
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                </div>
            `);
            $("#Prepayments").val('');
            $("#action").val('');
        }
    });

    $("#save").click(function () {
        $("#action").val('save');
    });

    // Soumission du formulaire principal, déclenche le traitement si demandé
    $("#pager").on("submit", "#mainform", function (event) {

        event.preventDefault();

        let data = $(this).serialize();
        let action = $('#action').val();

        if (action == 'traiter')
        {
            treatment(data);
        }
    });

    // Événements à l'initialisation du DOM (changement de compte, devise, client)
    $(document).ready(function () {
        $(".compte_current").on("change", function () {
            let account_ref = $(this).data("id-compte"); 
            get_account_fees_name(account_ref);
        });

        $(".devise_account_c").on("change", function () {
            let account_ref = $(this).data("id-devise"); 
            get_account_fees_name(account_ref);
        });

        $(".customer-code").on("change", function () {
            let account_ref = $(this).data("id-customercode"); 
            get_customeraccounts(account_ref);
        });

        // Vérification des transactions échouées
        $("#verify_failed").on("click", function () {
            $("#verify_failed").prop("disabled", true);
            verify_failed_transactions();
        });
    });

    // Lancement automatique du débit client après clic
    $(document).ready(function () {
        $("#start_auto_debit").on("click", function () {
            $("#start_auto_debit").prop("disabled", true);
            filteredButtons = [];

            $(".debit_client").each(function (index) {
                let $btn = $(this);
                let accountRef = $btn.data("account-ref");

                // Utiliser escapeID pour cibler les champs en toute sécurité
                let inputSelector = "input[name='account[" + accountRef + "]']";
                let escapedSelector = escapeID(inputSelector);
                let $input = $(escapedSelector);

                //let val = $input.val().trim();
                let val = $input.val();

                if (val !== "") {
                    filteredButtons.push({ btn: $btn, index: index });
                } else {
                    let resultId = escapeID("prepayment_result" + index);
                    $(`#${resultId}`).removeClass("text-yellow").addClass("text-red").html("Compte pr&eacute;paiement manquant");

                    $btn.addClass("d-none");
                }
            });

            debit_all_clients(0);
        });
    });

    // Ajout ou retrait dynamique des champs requis selon le choix de frais
    $(document).ready(function () {
        $('input[name="Infos[fees]"]').change(function () {
            let isChecked = $(this).prop('checked');

            $('.customer-code, .compte_current, .devise_account_c').each(function () {
                
                const $element = $(this);
                const id = $element.data('id-customercode') || $element.data('id-compte') || $element.data('id-devise');

                if (isChecked) {
         
                    $element.prop('required', true);

                    if ($element.hasClass('customer-code')) {
                        $element.attr('name', 'customerNumber[' + id + ']');
                    }
                    if ($element.hasClass('compte_current')) {
                        $element.attr('name', 'Customer_current_account[' + id + ']');
                    }
                    if ($element.hasClass('devise_account_c')) {
                        $element.attr('name', 'Devise_account_c[' + id + ']');
                    }

                } else {
                   
                    $element.prop('required', false);
                    $element.removeAttr('name');
                }
            });
        });

        if ($('input[name="Infos[fees]"]').prop('checked')) {
            $('input[name="Infos[fees]"]').trigger('change');
        }
    });

    // Bouton de fermeture du formulaire
    $("#close").click(function () {
        close_form();
    });

    // Sauvegarde séquentielle des données après clic
    $("#save").click(function () {
        $(this).prop("disabled", true);
        start_sequential_save();
    });

    // Vérification automatique des comptes prépaiement après chargement
    $(document).ready(function() {
        setTimeout(function() {
            check_missing_prepayment_accounts();
        }, 2000); 

    });

    // Chargement automatique (get_accountname) des noms de compte client lors du chargement de la page
    $(document).ready(function () {

        // Étape 1: Récupérer tous les account_ref dans un tableau
        let accountRefs = [];
        $("input[name^='account[']").each(function () {
            let ref = $(this).data('id-account');
            if (ref) {
                accountRefs.push(ref);
            }
        });

        // Étape 2: Fonction pour traiter un seul compte à la fois
        function process_account(index) {
            if (index >= accountRefs.length) {
                console.log("Tous les comptes ont été traités.");
                return;
            }

            let accountRef = accountRefs[index];
            console.log("Traitement du compte:", accountRef);

            // On sélectionne l'input avec name="account[ref]"
            let $input = $("input[name='account[" + accountRef + "]']");
            if ($input.length === 0) {
                console.warn("Champ introuvable pour", accountRef);
                process_account(index + 1);
                return;
            }

            let compte = $input.val();
            let devise = 'CDF';
            let csrf = $('input[name="csrf_name"]').val();

            if (compte !== '' && devise !== '') {
                $("#" + escapeID("accountname" + accountRef)).html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>',
                    data: {
                        compte: compte,
                        devise: devise,
                        csrf_name: csrf
                    },
                    dataType: 'json',
                    success: function (reponse) {
                        let el = $("#" + escapeID("accountname" + accountRef));
                        el.removeClass('text-black text-green text-red');

                        if (reponse.code === '404') {
                            el.addClass('text-red').html('Ce compte n&apos;existe pas');
                        } else if (reponse.code === '406') {
                            el.addClass('text-red').html('Probl&egrave;me de connexion au corebanking!');
                        } else if (reponse.code === '405') {
                            el.addClass('text-red').html('Le format de compte n\'est pas valide');
                        } else if (reponse.currency == null && reponse.account_name == null) {
                            el.addClass('text-red').html('Probl&egrave;me de connexion au corebanking');
                        } else if (reponse.currency !== devise) {
                            el.addClass('text-red').html('Devise du compte incorrecte');
                        } else {
                            el.addClass('text-green').html(reponse.account_name);

                            $("#" + escapeID("account_name" + accountRef)).val(reponse.account_name);
                            $("#" + escapeID("account_currency" + accountRef)).val(reponse.currency);
                            $("#" + escapeID("account_balance" + accountRef)).val(reponse.balance);
                        }

                        process_account(index + 1);
                    },
                    error: function () {
                        $("#loader-sub-menu").html('<div class="alert alert-warning">La récupération des informations du compte a échoué. Veuillez vérifier votre connexion.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                        process_account(index + 1);
                    }
                });
            } else {
                process_account(index + 1);
            }
        }

        // Démarrer le traitement séquentiel
        process_account(0);
    });

    // Gestion de changement de compte bancaire pour frais (dropdown)
    $(document).on('change', '[id^="bank_accountc"]', function (){
        const $this = $(this);
        const account_ref = $this.data('id-compte');

        $("#account_c_name" + account_ref).html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $this.find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#account_c_name' + account_ref).html('Compte &agrave; d&eacute;biter pour les frais');
            $('#accountc_name' + account_ref).val('');
            $('#Devise_account_c' + account_ref).val('');
            $('#account_balance_fees' + account_ref).val('');
            $('#account_type' + account_ref).val('');
            $('#compteDevise' + account_ref).val('').trigger('change');

            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        setTimeout(function () {
            $('#account_c_name' + account_ref).removeClass().addClass('text-green').html(name);
            $('#accountc_name' + account_ref).val(name);
            $('#Devise_account_c' + account_ref).val(currency);
            $('#account_balance_fees' + account_ref).val(balance);
            $('#account_type' + account_ref).val(type);

            if (currency) {
                $('#Devise_account_c' + account_ref).val(currency).prop('disabled', true);

                // Supprime tout champ hidden existant pour cet account_ref
                $('input[name="Devise_account_c[' + account_ref + ']"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la devise
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_account_c[' + account_ref + ']',
                    value: currency
                }).appendTo('form');
            }
        }, 2000);
    });

    // Fonction pour récupérer les comptes clients à partir du numéro
    function get_customeraccounts(account_ref) 
    {
        const customer_number = $('#customerNumber' + account_ref).val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';
        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            $('#labelNumber' + account_ref).removeClass().addClass('text-red').html("Le numéro est requis");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $('#labelNumber' + account_ref).html(loader_img);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                // Pour insérer dans le bon endroit
                const container = $('#bank_accountc' + account_ref).parent(); 

                if (reponse.code == "200") {

                    const mapped_currency = {
                        '976': 'CDF',
                        '840': 'USD'
                    };

                    const select = $('<select>', {
                        id: 'bank_accountc' + account_ref,
                        name: 'Customer_current_account[' + account_ref + ']',
                        class: 'form-control form-control-md compte_current',
                        required: true,
                        'data-id-compte': account_ref 
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {
                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            select.append($('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type
                            }));
                        }
                    });

                    // Remplacement de l'ancien champ (input ou select)
                    $('#bank_accountc' + account_ref).replaceWith(select);

                    select.trigger('change');

                    $("#labelNumber"+account_ref).html('Code client');

                } else {
                   
                    const input = $('<input>', {
                        id: 'bank_accountc' + account_ref,
                        name: 'Customer_current_account[' + account_ref + ']',
                        type: 'text',
                        'data-id-compte': account_ref,
                        class: 'form-control compte_current',
                        required: true
                    });

                    $('#bank_accountc' + account_ref).replaceWith(input);

                    let message = "Une erreur est survenue.";
                    switch (reponse.code) {
                        case '404':
                            message = "Ce numéro n'existe pas";
                            break;
                        case '405':
                            message = "Le format du numéro n'est pas valide";
                            break;
                        case '406':
                            message = "Problème de connexion à " + core_banking;
                            break;
                    }

                    $('#labelNumber' + account_ref).removeClass().addClass('text-red').html(message);
                }
            },
            error: function () {
                $('#loader-sub-menu').html(
                    '<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'
                );
            }
        });
    }

    // Traitement principal des paiements
    function treatment(data)
    {
        $("#loader1").html('');
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $("#treat").prop('disabled', true);
        $('#close').prop("disabled", true);
        $('#save').prop("disabled", true);
        scrollUP();

        let url = '<?php echo base_url($module . '/taxprepayments/save/batch_office'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                  
                var result = JSON.parse(result);

                if (result.code == 'E200')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info"> Traitement fait avec succ&egrave;s, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#save").prop('disabled', true);

                    $("#start_auto_debit").prop("disabled", false);
                    $("#start_auto_debit").removeClass("btn-default");
                    $("#start_auto_debit").addClass("btn-primary");

                    $('#close').prop("disabled", false);

                    $(".debit_client").prop('disabled', false);
                    $(".verify_transaction").prop('disabled', false);

                    $('#logirefid').val(result.reference);
                    
                    data_office = JSON.stringify(result.office);
                    console.log(data_office);
             
                    scrollUP();

                } 
                else if (result.code == 'E401')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-danger"> Votre requête a rencontré un problème. Veuillez réessayer..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#save").prop('disabled', false);
                    $('#close').prop("disabled", false);

                    //$('#bulletin_id').val(result.id);
                    //$('#logirefid').val(result.reference);
                    scrollUP();
                }
            },
            error: function (error) {
                $("#loader-sub-menu").html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    // Sauvegarde ligne par ligne avec appels AJAX séquentiels
    function start_sequential_save() 
    {
        $("#loader1").html('');
        $("#loader-sub-menu").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let accounts_ref = JSON.parse('<?php echo json_encode($data_accountref); ?>');
        let dataOffice = JSON.parse(data_office);
        let csrf = $('input[name="csrf_name"]').val();

        let total = accounts_ref.length;

        function process_line(index) {

            if (index >= total) {
                $("#loader-sub-menu").html('<div class="alert aSuccess text-white">Tous les paiements ont été enregistrés avec succès.</div>');
                
                $("#save").prop("disabled", true);
                $("#start_auto_debit").prop("disabled", true);
                return;
            }

            let account_ref = accounts_ref[index];

            if (!dataOffice.hasOwnProperty(account_ref)) {
                // Passer cette ligne si pas trouvée dans dataOffice
                process_line(index + 1);
                return;
            }

            let selectedData = dataOffice[account_ref];

            let url = '<?php echo base_url($module . '/taxprepayments/save/comptant'); ?>';
            let data = {
                account_reference: account_ref,
                Compte_33: selectedData.Compte_client,
                Office: selectedData.Office,
                logirefid: selectedData.Logirefid,
                csrf_name: csrf
            };

            $("#prepayment_result" + index).html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

            $.ajax({
                type: 'POST',
                url: url,
                data: data,
                dataType: 'html',
                success: function (result) {
                    if (result === 'E500' || isNaN(result)) {
                        $("#prepayment_result" + index).html('<span class="text-green bold">D&eacute;j&agrave; Enregistr&eacute;e</span>');
                        $("#prepayment_result" + index).removeClass('text-yellow').addClass('text-success');

                        process_line(index + 1);

                    } else if (parseInt(result) > 0) {

                        $("#prepayment_result" + index).html('<span class="text-green bold">Enregistr&eacute;e</span>');
                        $("#prepayment_result" + index) .removeClass('text-yellow').addClass('text-success');

                        process_line(index + 1);

                    } else {
                        // Échec, on arrête et on active le bouton de vérification
                        $("#prepayment_result" + index).html('<span class="text-danger bold">Non Enregistr&eacute;e</span>');
                        $("#prepayment_result" + index).removeClass('text-yellow').addClass('text-danger');

                        //$("#loader-sub-menu").html('<div class="alert alert-warning">Erreur à la ligne ' + (index + 1) + '. Cliquez sur Vérifier pour relancer cette ligne.</div>');

                        //$("#save").prop("disabled", true);
                    }
                },
                error: function () {
                    $("#prepayment_result" + index).html('<span class="text-danger bold">Erreur est survenue</span>');
                    $("#prepayment_result" + index).removeClass('text-yellow').addClass('text-danger');

                    $("#loader-sub-menu").html('<div class="alert alert-danger">Erreur réseau à la ligne ' + (index + 1) + '.</div>');

                    $("#save").prop("disabled", true);
                }
            });
        }

        // Lancer depuis la 1ère ligne
        process_line(0);
    }

    // Fonction récursive pour débiter tous les clients filtrés
    function debit_all_clients(index = 0) 
    {
        $("#loader1").html('');
        const total = filteredButtons.length;

        if (index >= total) {
            $("#start_auto_debit").prop("disabled", true);

            // Vérifie s'il reste des échecs réels (pas juste des comptes manquants)
            const nonAccountFailures = failedDebits.filter(f => !f.missing_account);

            if (nonAccountFailures.length > 0) {
                $("#verify_failed").removeClass("d-none");
                $("#failedCount").text(nonAccountFailures.length);
            } else {
                $("#verify_failed").addClass("d-none");
                $("#save").prop("disabled", false); // Activer si tous les échecs sont dus à comptes manquants
            }

            console.log("Tous les paiements terminés.");
            return;
        }

        const buttonData = filteredButtons[index];
        const button = buttonData.btn;
        const j = buttonData.index;

        const lot_id = button.data("lot-id");
        const account_ref = button.data("account-ref");

        const percent = Math.round(((index + 1) / total) * 100);
        $("#autoDebitProgress").css("width", percent + "%").text(percent + "%");

        debit_client(account_ref, lot_id, j, function(success) {
            setTimeout(() => debit_all_clients(index + 1), 300);
        });
    }

    // Fonction qui débite un seul client
    function debit_client(account_ref, lot_id, j, callback = null) 
    {
        const resultId = escapeID("prepayment_result" + j);
        const inputSelector = "input[name='account[" + CSS.escape(account_ref) + "]']";
        const $input = $(inputSelector);

        // Vérifie si le compte prépaiement est vide
        if ($input.length === 0 || !$input.val() || $input.val().trim() === "") {
            $("#" + resultId)
                .removeClass("text-yellow")
                .addClass("text-red")
                .html("Impossible de réserver : compte prépaiement manquant");

            $(`#debit_client${lot_id}`).addClass("d-none");

            // Échec marqué comme lié au compte manquant
            failedDebits.push({
                account_ref: account_ref,
                lot_id: lot_id,
                index: j,
                missing_account: true
            });

            if (callback) callback(false);
            return;
        }

        $("#loader-sub-menu").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $("#" + resultId).html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let prepayment = (data_office !== null && data_office !== "") ? JSON.parse(data_office) : "";
        let logirefID = (prepayment !== null && prepayment[account_ref] !== undefined) ? prepayment[account_ref].Logirefid : lot_id;

        let postData = { logirefid: logirefID, designation: $("#Declarant").val() };
        postData[csrfName] = csrfHash;

        let url = '<?php echo base_url($module . '/taxprepayments/display/debit_client'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: postData,
            dataType: 'html',
            encode: true,
            success: function (result) {
                const res = JSON.parse(result);
                $("#loader-sub-menu").html(res["msg"]);

                if (res['code'] === 'E200') {
                    $("#save").prop('disabled', false);
                    $("#treat").prop('disabled', true);
                    $(`#debit_client${lot_id}`).prop('disabled', true);
                    $("#" + resultId).html('<i class="fa fa-check text-green"></i>');

                    if (callback) callback(true);

                } else {
                    // Échec réel (compte présent mais refus ou erreur serveur)
                    failedDebits.push({
                        account_ref: account_ref,
                        lot_id: lot_id,
                        index: j,
                        missing_account: false
                    });

                    $("#" + resultId).html('<i class="fa fa-times text-danger"></i>');
                    $(`#debit_client${lot_id}`).addClass('d-none');
                    $(`#transaction_id${lot_id}`).val(res["transaction_id"]);

                    if (callback) callback(true);
                }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert alert-warning">Erreur réseau. Veuillez vérifier votre connexion.<button type="button" class="close" data-dismiss="alert">×</button></div>');

                if (callback) callback(false);
            }
        });
    }

    // Vérification des transactions échouées, une à une
    function verify_failed_transactions(index = 0) 
    {
        if (failedDebits.length === 0) {
            console.log("Aucune ligne en échec à vérifier.");
            return;
        }

        if (index >= failedDebits.length) {
            console.log("Vérification terminée.");

            if (successfulVerifications === failedDebits.length) {
                // Toutes les lignes ont été vérifiées avec succès
                $("#save").prop("disabled", false);
            }

            $("#verify_failed").addClass("d-none");
            return;
        }

        const item = failedDebits[index];
        verify_transaction(item.account_ref, item.lot_id, item.index, function () {
            setTimeout(() => verify_failed_transactions(index + 1), 200);
        });
    }

    // Vérifie une transaction unique et met à jour l'affichage
    function verify_transaction(account_ref,logirefid,j, callback = null) 
    {
        $(`#prepayment_result${j}`).html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let prepayment = (data_office!==null || data_office!=="") ? JSON.parse(data_office) : "";
        let logirefID = (prepayment!==null || prepayment!=="") ? prepayment[account_ref].Logirefid : logirefid;
        let transact_id = $(`input[data-lot='${logirefid}']`).val();

        let postData = {logirefid: logirefID, transaction_id: transact_id, designation: $("#Declarant").val()};
        postData[csrfName] = csrfHash;

        let url = '<?php echo base_url($module . '/taxprepayments/display/verify_transaction'); ?>';

        $.ajax({
            type: 'POST',
            url: url,
            data: postData,
            dataType: 'html',
            encode: true,
            success: function (result) {
                var res = JSON.parse(result);
                
                $("#loader-sub-menu").html(res["msg"]);

                if (res['code'] === 'E200' || res['code'] === 'E500') {

                    // on compte les succès
                    successfulVerifications++; 

                    $(`#debit_client${logirefid}`).prop('disabled', true);
                    //$(`#verify_transaction${logirefid}`).prop('disabled', true).addClass("d-none");
                    //$(`#bl_view${logirefid}`).removeClass("d-none");
                    $(`#prepayment_result${j}`).html('<i class="fa fa-check text-green"></i>');
                } else {
                    $(`#prepayment_result${j}`).html('<i class="fa fa-times text-danger"></i>');
                    $(`#verify_transaction${logirefid}`).removeClass('d-none');
                }

                // callback pour next
                if (callback) callback();
            },
            error: function (error) {
                $(`#prepayment_result${j}`).html('');
                $("#loader-sub-menu").html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    // Affichage d’un bulletin dans un modal
    function view(id) 
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxprepayments/display/edit'); ?>/' + id + '/view';
        $.get(url, function (data, status) {
            $("#loader-sub-menu").html('');
            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }

    // Récupération du nom du compte pour les frais associés
    function get_account_fees_name(account_ref)
    {
        var chtml = $("#account_c_name"+account_ref).html();
        var compte = $('#bank_accountc'+account_ref).val();
        var devise = $('#Devise_account_c'+account_ref+' option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
		
	    var core_banking = '<?php echo $core_banking; ?>';
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#account_c_name"+account_ref).html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).removeClass('text-green');
                            $("#account_c_name"+account_ref).addClass('text-red');
                            $("#account_c_name"+account_ref).html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).removeClass('text-green');
                            $("#account_c_name"+account_ref).addClass('text-red');
                            $("#account_c_name"+account_ref).html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).removeClass('text-green');
                            $("#account_c_name"+account_ref).addClass('text-red');
                            $("#account_c_name"+account_ref).html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).removeClass('text-green');
                            $("#account_c_name"+account_ref).addClass('text-red');
                            $("#account_c_name"+account_ref).html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#account_c_name"+account_ref).removeClass('text-green');
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).addClass('text-red');
                            $("#account_c_name"+account_ref).html('Devise du compte incorrecte');

                            $('#Devise_account_c'+account_ref).val('');
                    }
                    else
                    {
                            $("#account_c_name"+account_ref).removeClass('text-black');
                            $("#account_c_name"+account_ref).addClass('text-green');
                            $("#account_c_name"+account_ref).html(reponse.account_name);
                            $("#accountc_name"+account_ref).val(reponse.account_name);

                            $("#account_currency"+account_ref).val(reponse.currency);
                            $("#account_balance_fees"+account_ref).val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#account_c_name").html('.');
        }
    }

     // Vérifie s’il manque des comptes prépaiement
    function check_missing_prepayment_accounts() {
        let missing_refs = [];

        $("input[name^='account[']").each(function() {
            let ref = $(this).data('id-account');
            let value = $(this).val().trim();

            if (ref && value === '') {
                missing_refs.push(ref);
            }
        });

        if (missing_refs.length > 0) {
            let refs_text = missing_refs.join(', ');

            let message = `<div class="alert aWarning text-white">
                Le compte de prépaiement pour les clients <strong>${refs_text}</strong> n'est pas paramétré, veuillez contacter votre administrateur à cet effet.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
            </div>`;

            $("#loader1").html(message);
        }
    }

    // Affichage des bulletins pour un compte et un bureau
    function view_bulletin(account, office)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxprepayments/display/_bulletins'); ?>/';
        $.get(url, {compte: account, office: office}, function (data, status) {
            $("#loader-sub-menu").html('');
            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }

    function close_form()
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module . '/taxprepayments/display/prepaymentlist'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');
            $("#container").html(data);
        });
    }

    function format_amount(amount)
    {
        amount = amount.replace(/ /g, "");
        amount = amount.replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        return amount;
    }

    // Fonction utilitaire pour échapper les caractères spéciaux dans un ID CSS
    function escapeID(id) 
    {
        if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
            return CSS.escape(id);
        }
        // Fallback pour anciens navigateurs (échappe les caractères spéciaux)
        return id.replace(/([!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~])/g, '\\$1');
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader1").offset().top
        }, 20);
    }
</script>
