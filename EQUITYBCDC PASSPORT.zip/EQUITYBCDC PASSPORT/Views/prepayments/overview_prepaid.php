<div class="row">
    <div class="col-md-12">
        <div id="loader1"></div>
        <div class="col-md-12 no-padding">
            <h1>Pr&eacute;paiements</h1>
            <p class="page-header">Extraction et traitement  des pr&eacute;paiements</p>     
        </div>
        <div id="loader"></div>
        <div id="pager">
            <?php if($step == 1 || $step == 2 ):?>
                <?php $this->load->view('_prepayments'); ?>
            <?php elseif($step == 3):?>
                <?php $this->load->view('_step_3'); ?>
            <?php else:?>
                <div class="row">
                    <div class="col-md-12 mt-3 mb-3">
                        <div class="row">
                            <div class="col-md-1">
                                <div id="step-1" title="" class="bRound <?php if($step == 0){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">1</div>
                            </div>
                            <div class="col-md-3 pt-2">
                                <div class="pull-left f12 text-black">Lots à traiter<br/></div>
                            </div>
                            <div class="col-md-1">
                                <div id="step-2" title="" class="bRound <?php if($step == 2 || $step == 1){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">2</div>
                            </div>
                            <div class="col-md-3 pt-2">
                                <div class="pull-left f12 text-black">Lots sélectionnés<br/></div>
                            </div>
                            <div class="col-md-1">
                                <div id="step-3" title="" class="bRound <?php if($step == 3){ echo 'bg-green-active';}else{ echo 'bg-gray';}?> center pull-right">3</div>
                            </div>
                            <div class="col-md-3 pt-2">
                                <div class="pull-left f12 text-black">Résultat<br/></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <?php if(!empty($prepayments)): ?>
                        <?php $chtml->box_body_opening('', false);?>
                            <div id="list">
                                <div class="box-body box-solid no-padding">
                                    <div class="col-md-12 no-padding">
                                        <div class="box-body">
                                            <div class="table-responsive">
                                                <table class="table no-margin table-bordered">
                                                    <thead class='bg-blue'>
                                                        <tr>
                                                            <th width="10px">#</th>
                                                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                                            <th width="200px">Declarant</th>
                                                            <th width="100px" class="center">Nombre des bulletins</th>
                                                            <th width="100px" class="center">Montant total</th>
                                                            <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                                                            <th width="10px" style="text-align:center;"><i class="fa fa-check-square-o f20"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i =1; foreach($prepayments as $office => $payments): ?>
                                                        <tr class="bg-gray">
                                                            <td colspan="7" class="bold">
                                                                <h4> <?php echo $services['DGDA'][$office]; ?></h4>
                                                            </td>
                                                        </tr>
                                                            <?php $i =1;  foreach($payments as $payment): ?>
                                                                <tr  id="line<?php echo $payment->Id_0;?>">
                                                                    <td width=""><?php echo $i;?></td>
                                                                    <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                                                    <td width=""><?php echo $payment->Declarant_16;?></td>
                                                                    <td width="" class="center"><?php echo $payment->total; ?></td>
                                                                    <td width="" class="text-blue center"><?php echo 'CDF '.number_format($payment->amounts,2,","," "); ?></td>
                                                                    <td style="text-align:center;">
                                                                        <a style="cursor: pointer" onclick="edit('<?php echo $office; ?>','<?php echo $payment->AccountRef_14; ?>')"> 
                                                                            <i class="fa fa-fw fa-edit text-green f20"></i> 
                                                                        </a>
                                                                    </td>
                                                                    <td style="text-align:center;">
                                                                        <input type="checkbox">
                                                                    </td>
                                                                </tr>
                                                            <?php $i++; endforeach;?>
                                                        <?php  endforeach; ?> 
                                                    </tbody>
                                                </table>
                                                <div class="col-md-12 no-padding">
                                                    <button type="button" class="btn btn-danger mt-3 pull-right"><i class="fa fa-arrow-circle-right"></i> Suivant</button>
                                               </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $chtml->box_body_closing(); ?> 
                        <?php else: ?>
                            <?php if(!empty($processed) ): ?>
                                <?php $chtml->box_body_opening(); ?> 
                                    <section id="cat_list" class="mt-5 mb-5 text-center ">
                                       <span class="d-block"><i class="fa fa-fw fa-thumbs-up text-green mystyle4" ></i></span></br>
                                       <span class="d-block f14 text-black p-2"><b>Tous les pr&eacute;paiments extraits ont &eacute;t&eacute; trait&eacute;s!</b></span>        
                                    </section>
                                <?php $chtml->box_body_closing(); ?> 
                            <?php else: ?> 
                                <?php $chtml->box_body_opening(); ?> 
                                    <section id="cat_list" class="mt-5 mb-5 text-center ">
                                       <span class="d-block"><i class="fa fa-flask text-gray mystyle4" ></i></span></br>
                                       <span class="d-block f14 text-black p-2"><b>Aucun pr&eacute;paiement n&apos;a &eacute;t&eacute; extrait aujourd&apos;hui !</b></span>        
                                    </section>
                                <?php $chtml->box_body_closing(); ?> 
                            <?php endif; ?>

                        <?php endif; ?>
                    </div>
                </div>
            <?php endif;?>
        </div>
    </div>
</div>

<script type="text/javascript">
    //$(".select2").select2(); 

    $('#dateDebut').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#dateFin').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#extractform").submit(function(event){
            event.preventDefault();
            var data = $(this).serialize();
            next_step(data);
    });

    function next_step(data)
    {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $('#sub').prop("disabled", true);
            $('#buttonCloseModal').prop("disabled", true);
            var button = $('#sub').html();
            $('#sub').html('<span>T&eacute;l&eacute;chargement...</span>');
            var url = '<?php echo base_url($module.'/taxprepayments/display/extractList'); ?>';
            $.ajax({
                   type        : 'POST', 
                   url         : url, 
                   data        : data, 
                   dataType    : 'html', 
                   encode      : true,
                   success: function(result){
                            $('#sub').prop("disabled", false);
                            $('#sub').html(button);
                            $('#loader1').html('');

                            if(result === "E404")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: serveur SYDONIA n\'est  pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E36")
                            {
                                $('#loader1').html('<div class="alert alert-danger">Alerte: Mot de passe incorrect !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E37")
                            {
                                $('#loader1').html('<div class="alert alert-danger">Alerte: Date d&eacute;but incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E38")
                            {
                                $('#loader1').html('<div class="alert alert-danger">Alerte: Date fin incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result.code === "E404")
                            {
                                    $('#loader1').html('<div class="alert alert-warning">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E405")
                            {
                                    $('#loader1').html('<div class="alert alert-warning">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result.code === "E406")
                            {
                                    $('#loader1').html('<div class="alert alert-warning">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E39")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Aucun pr&eacute;paiement trouv&eacute!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }   
                            else if(result === "E501")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Aucune quittance disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E502")
                            {
                                $('#loader1').html('<div class="alert alert-info">Ce lot des pr&eacute;paiements a d&eacute;j&agrave; &eacute;t&eacute; extrait, v&eacute;rifiez sur la liste ou consultez la liste des p&eacute;paiements d&eacute;j&agrave; trait&eacute;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E514")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Aucune r&eacute;ponse de SYDONIA ressayez plutard!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E43")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: Votre code banque n\'est pas autoris&eacute;, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else if(result === "E000")
                            {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $('#buttonCloseModal').prop("disabled", '');
                            }
                            else 
                            {

                                $("#pager").html(result);

                                $("#cancels").addClass('d-none');
                                $("#close").removeClass('d-none');

                            }
                   },
                   error:function(error){
                       $('#loader1').html('<div class="alert alert-warning">L\'extraction a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       $('#sub').prop("disabled", false);
                       $('#sub').html(button);
                   }
           });

    }

    function edit(office, reference, item = NULL)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module.'/taxprepayments/display/traitement'); ?>/'+item;

        $.ajax({
            type        : 'GET', 
            url         : url, 
            data        : { office : office, compte : reference}, 
            dataType    : 'html', 
            encode      : true,
            success: function(reponse)
            {
                $("#loader1").html('');
                $('#pager').html(reponse); 

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });  

    }
    
    function edit(office, reference)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module.'/taxprepayments/display/traitement'); ?>/';

        $.ajax({
            type        : 'GET', 
            url         : url, 
            data        : { office : office, compte : reference}, 
            dataType    : 'html', 
            encode      : true,
            success: function(reponse)
            {
                $("#loader1").html('');
                $('#pager').html(reponse); 

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });  

    }
    
    function action(which) 
    {
        $("#alert").html('');
  
        $("#loader1").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        $.get("<?php echo base_url($module . '/taxprepayments/display/prepayments_filter'); ?>/" +which, function(data, status) {
            $("#loader1").html('');
            $("#list").html(data);
        });
    }


    $("#cancel").click(function() {
        location.reload(true);
    });
    

</script>