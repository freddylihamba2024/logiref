<div class="box-body box-solid no-padding">
    <div class="col-md-12 no-padding">
        <div class="box-body">
            <div class="table-responsive">
                <table class="table no-margin table-bordered">
                    <thead class='bg-blue'>
                        <tr>
                            <th width="10px">#</th>
                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                            <th width="200px">Declarant</th>
                            <th width="100px" class="center">Nombre des bulletins</th>
                            <th width="100px" class="center">Montant total</th>
                            <th width="10px" style="text-align:center;"><i class="fa fa-edit f20"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i =1; foreach($prepayments as $office => $payments): ?>
                        <tr class="bg-gray">
                            <td colspan="6" class="bold">
                                <h4> <?php echo $services['DGDA'][$office]; ?></h4>
                            </td>
                        </tr>
                            <?php $i =1;  foreach($payments as $payment): ?>
                                <tr  id="line<?php echo $payment->Id_0;?>">
                                    <td width=""><?php echo $i;?></td>
                                    <td width=""><?php echo $payment->AccountRef_14; ?></td>
                                    <td width=""><?php echo $payment->Declarant_16;?></td>
                                    <td width="" class="center"><?php echo $payment->total; ?></td>
                                    <td width="" class="text-blue center"><?php echo 'CDF '.number_format($payment->amounts,2,","," "); ?></td>
                                    <td style="text-align:center;">
                                        <a style="cursor: pointer" onclick="edit('<?php echo $office; ?>','<?php echo $payment->AccountRef_14; ?>')"> 
                                            <i class="fa fa-fw fa-edit text-green f20"></i> 
                                        </a>
                                    </td>
                                </tr>
                            <?php $i++; endforeach;?>
                        <?php  endforeach; ?> 
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>