<div class="row">
    <div class="col-md-12">
        <div id="loader1"></div>
        <div class="row">
            <div class="col-md-12"><br/>
                <div id="loader"></div>
            </div>
        </div>
        <div id="pager">
            <div class="row">
                <div class="col-md-12">
                    <?php $chtml->box_body_opening('', false); ?>
                    <div>
                        <div id="list">
                            <?php if (!empty($prepayments)): ?>
                                <div class="box-body box-solid no-padding">
                                    <div class="col-md-12 no-padding">
                                        <div class="box-body">
                                            <div class="table-responsive">
                                                <table class="table table-hover table-striped">
                                                    <thead class='bg-gray'>
                                                        <tr>
                                                            <th width="5px">#</th>
                                                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                                            <th width="150px">Bureau</th>
                                                            <th width="100px">Declarant</th>
                                                            <th width="100px" class="center">Nombre des bulletins</th>
                                                            <th width="150px" class="center">Montant total</th>
                                                            <th width="10px"  style="text-align:left;"><i class="fa fa-edit f20"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; foreach($prepayments as $customer => $payments): ?>
                                                        <tr>
                                                            <td class="align-middle" width=""><?php echo $i; ?></td>
                                                            <td class="align-middle" width=""><?php echo $customer; ?></td>

                                                            <?php 
                                                            # Initialisation des variables pour stocker les données collectées
                                                            $offices = '';
                                                            $declarants = '';
                                                            $totals = '';
                                                            $amounts = '';
                                                            $editLinks = '';

                                                            foreach($payments as $payment):
                                                                # Collecte des informations dans des variables HTML
                                                                $offices .= '<li>' . $services['DGDA'][$payment->Office_8] . '</li>';
                                                                $declarants .= '<li>' . $payment->Declarant_16 . '</li>';
                                                                $totals .= '<li>' . $payment->total . '</li>';
                                                                $amounts .= '<li>' . 'CDF ' . number_format($payment->amounts, 2, ",", " ") . '</li>';

                                                            endforeach;
                                                            ?>

                                                            <td class="align-middle pl-3" width=""><ul><?php echo $offices; ?></ul></td>
                                                            <td class="align-middle pl-3" width=""><ul><?php echo $declarants; ?></ul></td>
                                                            <td class="align-middle pl-3" width=""><ul><?php echo $totals; ?></ul></td>
                                                            <td class="align-middle pl-3" width=""><ul><?php echo $amounts; ?></ul></td>
                                                            <td class="align-middle" width="">
                                                                <a style="cursor: pointer" onclick="edit('<?php echo $customer; ?>', 'Customer', '<?php echo $payment->Office_8; ?>')"> 
                                                                    <i class="fa fa-fw fa-edit text-blue f20"></i> 
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php $i++; endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php if (!empty($processed)): ?>
                                    <section>
                                        <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 10vh; padding-top: 5%;">
                                            <i class="fa fa-fw fa-thumbs-up text-green mystyle4"></i><br/>
                                            <h5 align="center"><b>Tous les pr&eacute;paiments extraits ont &eacute;t&eacute; trait&eacute;s!</b></h5>
                                            <br/>
                                        </div>
                                    </section>
                                <?php else: ?> 
                                    <section id="cat_list" class="text-center ">
                                        <br/><br/><br/><br/><br/><br/><br/><br/>                                                 
                                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br></span>
                                        <span class="d-block f14 text-black p-2"><b>Aucun pr&eacute;paiement n&apos;a &eacute;t&eacute; extrait aujourd&apos;hui !</b></span><br/>        
                                    </section>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $chtml->box_body_closing(); ?> 
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    //$(".select2").select2(); 

    $('#dateDebut').datepicker({
        format: 'yyyy-mm-dd'
    });

    $('#dateFin').datepicker({
        format: 'yyyy-mm-dd'
    });

    $("#extractform").submit(function (event) {
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
    });

    $("#_historique").on('click', function (e) {
        e.preventDefault();
         $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/historique'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');
            $("#general_block").addClass('d-none');
            $("#prepayment_block").removeClass('d-none');
            $("#sub-menu").html(data);
            $("#title").html('Bulletin des prépaiements (DGDA)');
            $("#sub-title").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
            $("#title-prepayment").html('Bulletin des prépaiements (DGDA)');
            $("#sub-title-prepayment").html('Ce formulaire vous permet de récupérer les bulletins des prépaiements.');
        });
    });

    $("#cancel").click(function () {
        location.reload(true);
    });

    $("#historique").click(function () {

        $("#loader-sub-menu").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get("<?php echo base_url($module . '/taxprepayments/display/historique'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');

            $("#list").html(data);
        });
    });

    function edit(param, item, param1 = null)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = '';
        var url = '';
        if (item == "Customer")
        {
            url = '<?php echo base_url($module . '/taxprepayments/display/treatment_customer'); ?>/';
            data = {compte: param, office: param1};
        }
        if (item == "Office")
        {
            url = '<?php echo base_url($module . '/taxprepayments/display/treatment_office'); ?>/';
            data = {office: param};
        }

        $.ajax({
            type: 'GET',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (reponse)
            {
                $("#loader-sub-menu").html('');
                $("#general_block").removeClass('d-none');
                $("#prepayment_block").addClass('d-none');
                $('#pager').html(reponse);

            },
            error: function (error)
            {
                $("#loader-sub-menu").html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    }

    function filter(which)
    {
        $("#alert").html('');

        $("#loader-sub-menu").html('<img   align="middle"   height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module . '/taxprepayments/display/prepayments_filter'); ?>/" + which, function (data, status) {
            $("#loader-sub-menu").html('');
            $("#list").html(data);
        });
    }

    function next_step(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $('#sub').prop("disabled", true);
        $('#buttonCloseModal').prop("disabled", true);
        var button = $('#sub').html();
        $('#sub').html('<span>T&eacute;l&eacute;chargement...</span>');
        var url = '<?php echo base_url($module . '/taxprepayments/display/extractList'); ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
                $("#loader-sub-menu").html('');
                $("#list").html(result);

                if (result === "E404")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA n\'est  pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E36")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Mot de passe incorrect !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E37")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Date d&eacute;but incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E38")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-danger">Alerte: Date fin incorrecte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result.code === "E404")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E405")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: Vous n&apos;avez pas l&apos;autorisation d&apos;utiliser SYDONIA Via Webservice, Contactez votre administrateur...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result.code === "E406")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: serveur SYDONIA 41.215.253.190 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (result === "E39")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucun pr&eacute;paiement trouv&eacute!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E501")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucune quittance disponible!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E502")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info">Ce lot des pr&eacute;paiements a d&eacute;j&agrave; &eacute;t&eacute; extrait, v&eacute;rifiez sur la liste ou consultez la liste des p&eacute;paiements d&eacute;j&agrave; trait&eacute;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E514")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Aucune r&eacute;ponse de SYDONIA ressayez plutard!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E43")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: Votre code banque n\'est pas autoris&eacute;, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else if (result === "E000")
                {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">Alerte: Rassurez-vous que vous identifiants SYDONIA sont configur&eacute;s et sont corrects...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#buttonCloseModal').prop("disabled", '');
                } else
                {

                    $("#list").html(result);

                }
            },
            error: function (error) {
                $("#loader-sub-menu").html('<div class="alert alert-warning">L\'extraction a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#sub').prop("disabled", false);
                $('#sub').html(button);
            }
        });
    }
</script>
