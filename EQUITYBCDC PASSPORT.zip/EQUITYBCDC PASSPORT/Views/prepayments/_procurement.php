<?php
$label01 = '--------';
$valeur01 = '';
$devise01 = '';

?>
<div class="col-md-1"></div>
<div class="col-md-10">
    <div id="message1"></div>
    <h1>Approvisionnement de compte de pr&eacute;paiement</h1>
    <span class="page-header">
        Effectuer un approvisionnement
    </span>
    <style>label {min-width: 150px !important;}</style>
    <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="box-body">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Accountsydonia">Compte sydonia</label> 
                    </span>
                    <?php echo form_input('Accountsydonia', set_value('Accountsydonia',''), 'class="form-control" required="required" maxlength="86"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                       <label for="libofpayement">Libel&eacute; du paiement</label>
                    </span>
                    <?php echo form_input('libofpayement', set_value('libofpayement', ''), ' id="libofpayement" class="form-control" maxlength="10"  required="required" '); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode">Mode de paiement</label> 
                    </span>
                    <?php echo form_dropdown('Mode', $modes, '', 'class="form-control" required="required" id="modeId"'); ?>
                </div>
            </div> 
            <div class="col-md-7">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Service">Bureau de la douane</label> 
                    </span>
                    <?php echo form_dropdown('Service', $services, '', 'class="form-control" id="service"  required="required" '); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant pay&eacute;</label> 
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', ''), 'class="form-control" id="recetteMontant" required="required"'); ?>
                </div>
                <div class="input-group"> 
                    <span class="input-group-addon">
                        <label for="Compte_33"><div id="compteLabel"><?php echo $label01; ?></div></label> 
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33', $valeur01), 'class="form-control" disabled="" id="compteId"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_12', $devises, '', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_34', $devises, $devise01, 'class="form-control"  required="required" disabled="" id="compteDevise"'); ?>
                </div>
            </div>
        </div>
         <div  class="box-footer clearfix">
                <div id="createPaiement" class="col-md-12">
                    <button type="submit" id='enregistrer' class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <a type="button" class="btn btn-warning" href=""><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="col-md-1"></div>
<script type="text/javascript"  charset="utf-8">
$('#modeId').change(function(){
    var mode = $('#modeId').val();
    if(mode === '7' || mode === '8'){
        $("#compteId").prop('disabled',''); 
        $("#compteDevise").prop('disabled',''); 
        $("#compteLabel").html('Compte &agrave; d&eacute;biter'); 
        $("#compteId").prop('placeholder','E.g: 0000100002000030000400005'); 
        $("#compteId").val('');
    }else{
        $("#compteId").prop('disabled','disabled'); 
        $("#compteDevise").prop('disabled','disabled');
        $("#compteLabel").html('---------');
          $("#compteId").prop('placeholder',''); 

    }
});

$("#mainform").submit(function(e){
    e.preventDefault();
    $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxprepayments/display/setprocurement'); ?>';
    var data = $(this).serialize();
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){
                    $('#loader').html('');
                    if(result === "E404" || result === "E22")
                    {
                            $('#message1').html('<div class="alert alert-danger text-white">ERREUR 404! Impossible de confirmer ce paiement dans sydonia. Veuillez renseigner des informations valide ou contacter votre administrateur!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E405")
                    {
                            $('#message1').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E406")
                    {
                            $('#message').html('<div class="alert alert-danger text-white">ERREUR 405! Impossible de prendre en compte toutes les taxes du BL. Veuillez contacter votre administrateur pour configurer les taxes manquantes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34")
                    {
                            $('#message1').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result === "E34x")
                    {
                            $('#message1').html('<div class="alert alert-warning text-white">Avertissement:confirmer ce paiement a deja &eacute;t&eacute; confirmer dans sydonia. V&eacute;rifiez les informations renseign&eacute;es!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $('#message1').html('<div class="alert alert-success text-white">Bravo! Op&eacute;ration effectu&eacute;e avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#mainform").reset();
                    }
            },
            error:function(error){
                alert('ERROR!' + error);
            }
    });
});
</script>
