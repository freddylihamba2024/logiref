<?php
// Convertir les valeurs en entier pour éviter les erreurs de comparaison de type
$values = array_map('intval', $paiement_result);

$has300 = in_array(300, $values);
$has200 = in_array(200, $values);
?>

<div id="loader"></div>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    <div class="col-md-12">
        <div class="row">
            <div class="container mt-5 mb-5">
                <div class="card text-center">
                    <div class="card-body">
                        <?php if ($has300 && $has200): ?>
                            <!-- Échec partiel -->
                            <i class="fa fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                            <h4 class="card-title">Opération échouée partiellement</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a été faite partiellement, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>

                        <?php elseif ($has300): ?>
                            <!-- Échec total -->
                            <i class="fa fa-times-circle fa-3x text-danger mb-3"></i>
                            <h4 class="card-title">Opération échouée</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a échoué, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>

                        <?php elseif ($has200): ?>
                            <!-- Succès total -->
                            <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
                            <h4 class="card-title">Opération réussie</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a été faite avec succès, 
                                <!-- veuillez cliquer sur le bouton [Générer la quittance] pour télécharger la quittance. -->
                            </p>
                            <!-- <button type="button" id="quittance" class="btn btn-primary">Générer la quittance</button> -->
                            <br/><br/><br/><br/>
                        <?php else: ?>
                            <!-- Échec total -->
                            <i class="fa fa-times-circle fa-3x text-danger mb-3"></i>
                            <h4 class="card-title">Opération échouée</h4>
                            <p class="card-text">
                                La validation du lot de bulletins a échoué, 
                                veuillez trouver ces bulletins dans le menu régularisation pour les régulariser.
                            </p>
                        <?php endif; ?>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script type="text/javascript"> 
    
</script>