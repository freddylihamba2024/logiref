<?php 

$total_amount = 0;

if($account !='')
{
        $error_message = '';
}
else
{
        $error_message = '<div class="alert alert-warning">Le compte de prépaiement pour ce cleint n\'est pas paramétré, veuillez contacter votre administrateur à cet effet.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        
}
echo '<pre>'; var_dump($prepayments); die;
?>

<div id="pager">
    <div class="col-md-12">
        <div id="loader1"><?php echo $error_message; ?></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $chtml->box_body_opening('', true);?>
        <div class="col-md-12">
                
                <div class="box-body">
                    <input type="hidden" id="Npaiements" value="<?php echo count($prepayments);?>" name="Npaiements"/>
                    <input type="hidden"  value="<?php echo (isset($object_info->Office_8)) ? $object_info->Office_8 : '';?>" name="Office"/>
                    <input type="hidden"  value="<?php echo (isset($object_info->Declarant_16)) ? $object_info->Declarant_16 : '';?>" name="Declarant"/>
                    <input type="hidden"  value="<?php echo (isset($object_info->Nif_15)) ? $object_info->Nif_15 : '';?>" name="Nif"/>
                    <div class="col-md-12">
                        <h2 class=" f20 w-300 page-header">Traitement des bulletins  pr&eacute;pay&eacute;s</h2>
                        <br/>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Bureau</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($object_info->Office_8) ? $services['DGDA'][$object_info->Office_8] : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Banque</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($object_info->CodeBank_13) ? $object_info->CodeBank_13 : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;clarant</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($object_info->Declarant_16) ? $object_info->Declarant_16 : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;signation</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $designation; ?>
                                    <input type="hidden" id="designation" name="designation"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte du client</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="cCompte"><?php if($account !='') echo $account.' CDF'; else echo ''; ?></span>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Intitul&eacute; du compte</label>
                                    <input type="hidden" value="" id="account_name" name="account_name"/>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="accountname"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Montant total du lot</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> <span id="total_amount"></span> CDF
                                    <input type="hidden" id="lot_amount" value="0" name="total_amount"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Commission</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> 0,00 CDF
                                   <input type="hidden" id="Commission" value="0" name="Commission"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">TVA</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b> 0,00 CDF
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Mode de paiement</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> OP
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte Guichet unique</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b>  <?php echo isset($cguichet) ? $cguichet : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Total à payer</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="topaid"> </span> <?php echo "CDF"; ?>
                                    <input type="hidden" id="tota_to_paid" name="tota_to_paid"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-md-12">
                    <br/>
                    <input type="radio" name="choice" value="2" id="virmul" style="background-color: green !important" checked> Virement multiple.<br>
                    <input type="radio" name="choice" value="1" id="portail" style="background-color: green !important"> Int&eacute;gration par portail. (Par autorisatioin)<br>
                </div>
                <div class="box-footer clearfix">
                    <div class="col-md-12">
                        <br/>
                        <button type="submit" id="treat" class="btn btn-primary" <?php if($error_message !='') echo 'disabled'; ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="verify" class="btn btn-success d-none"><i class="fa fa-external-link " ></i>&nbsp;&nbsp;V&eacute;rifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="save" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="action" value="" id="action">
                        <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Annuler&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="account_reference" value="<?= $account_reference; ?>" >
                        <input type="hidden" name="Compte_33" value="<?= $account; ?>" >
                        <input type="hidden" name="action" value="" id="action">
                        <input type="hidden" name="logirefid" value="" id="logirefid">
                        <input type="hidden" name="bulletin_id" value="" id="bulletin_id">
                        <input type="hidden" name="transaction_id" value="" id="transaction_id">
                        <input type="hidden" name="error_code" value="" id="error_code">
                    </div>
                </div>
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
            <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th>#</th>
                            <th width="250px">Date</th>
                            <th width="100px">Num&eacute;ro imp&ocirc;t</th>
                            <th width="200px">Bulletin</th>
                            <th class="right" width="">Montant</th>
                            <th><span class="fa fa-fw fa-folder f14"></span></th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $i=1; foreach($prepayments as $row) :?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td  width="150px"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));?></td>
                                <td  width="200px"><?php echo $row->Nif_15;?></td>
                                <td><?php echo $row->Serial_9.''.$row->Number_10; ?></td>
                                <td ><?php echo 'CDF'.' '.number_format($row->Amount_18,2,","," ");?></td>
                                <td width="25" class="center">
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                </td>
                            </tr>
                        <?php
                        
                        $total_amount = $total_amount + $row->Amount_18;
                        $i++;
                        endforeach;?>
                    </tbody>    
                </table>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>
    </div>
    <div class="modal fade" id="modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">D&eacute;tail du bulletin</h4>
                </div>
                <div id="modal-pager" class="modal-body">
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    //var lot = '<?php //echo $lot; ?>';
    var total_amount = '<?php echo $total_amount ?>';
    $("#total_amount").html(total_amount.toLocaleString());
    $("#lot_amount").val(total_amount);
    $("#topaid").html(total_amount.toLocaleString());
    $("#tota_to_paid").val(total_amount);

    $("#contenter").on("click", "#close_form", function(){

           close_form();
    });

    get_accountname();
    
    function view(id) {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module.'/taxprepayments/display/edit'); ?>/'+id+'/view';
        $.get(url, function (data, status) {
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
    }

    $("#portail").click(function(){

           $("#save").prop('disabled', false);
           $("#treat").prop('disabled', true);
           $("#action").val('save');
    });
    $("#virmul").click(function(){

           $("#treat").prop('disabled', false);
           $("#save").prop('disabled', true);
           $("#action").val('traiter');
    });

    $("#treat").click(function(){

       $("#action").val('traiter');

    });

    $("#verify").click(function(){

       $("#action").val('verify');

    });

    $("#save").click(function(){

       $("#action").val('save');

    });

    $("#pager").on("submit", "#mainform", function(event){

           event.preventDefault();

           var data = $(this).serialize();
           var action = $('#action').val();

           if(action == 'traiter')
           {
               reservation(data);
           }
           else if(action == 'save')
           {
               submiter(data);
           }
           else if(action == 'verify')
           {
               verify(data);
           }
    });

    function submiter(data){
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

           var url = '<?php echo base_url($module.'/taxprepayments/save/comptant'); ?>';
           $('#save').prop("disabled",true);
           scrollUP();

           $.ajax({
                   type        : 'POST', 
                   url         : url, 
                   data        : data, 
                   dataType    : 'html',
                   encode          : true,
                   success: function(result){

                           if(result=='E500')
                           {
                                   $('#loader1').html('<div class="alert alert-info">Ce lot de pr&eacute;paiement est d&eacute;j&agrave; enregistr&eacute;, veuillez v&eacute;rifier dans la liste de pr&eacute;paiements enregistr&eacute;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                           }
                           else if(isNaN(result)==true)
                           {
                                   $('#loader1').html('<div class="alert alert-info">L\'enregistrement a pris beaucoup de temps, allez v&eacute;rifier le statut de ce lot de paiement dans le menu pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                           }
                           else if(result > 0)
                           {
                                   $('#loader1').html('<div class="alert alert-success">Bravo! paiements encaiss&eacute;s avec succ&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                           }
                           else
                           {
                                   $('#loader1').html('');
                                   $('#loader1').html('<div class="alert alert-info">L\'enregistrement a pris beaucoup de temps, allez v&eacute;rifier le statut de ce lot de paiement dans le menu pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                           }
                   },
                   error:function(error){
                       $('#loader1').html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                   }
           });
    }

    $("#balance").css('background-color','#00cc33');

    $("#close").click(function(){
           close_form();
    });

    $("#bank_account").change(function(){
       get_accountname(); 
    });

    $("#account_devise").change(function(){
       get_accountname(); 
    });


    function next_step(data)
    {
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $('#envoyer').prop("disabled", true);
        var button = $('#envoyer').html();
        $('#envoyer').html('<span>Chargement...</span>');
        var url = '<?php echo base_url($module.'/taxprepayments/display/edit/'.$account_reference); ?>';
        $.ajax({
                  type        : 'POST', 
                  url         : url, 
                  data        : data, 
                  dataType    : 'html', 
                  encode      : true,
                  success: function(result){
                           $('#loader1').html('');
                           $("#pager").html(result);
                  },
                   error:function(error)
                   {
                       $("#step-2").removeClass('bg-green-active');
                       $("#step-2").addClass('bg-gray');
                       $("#step-3").removeClass('bg-gray');
                       $("#step-3").addClass('bg-green-active');
                       $('#loader1').html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       $('#envoyer').prop("disabled", false);
                       $('#envoyer').html(button);
                   }
          });
    }
    
    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '<?php echo $account; ?>';
        var devise = 'CDF';
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; synergie');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }



    function reservation(data)
    {
           $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

           //$("#treat").prop('disabled', true);
           $('#close').prop("disabled",true);
           var url = '<?php echo base_url($module.'/taxprepayments/display/reservation'); ?>';
           $('#save').prop("disabled",true);
           scrollUP();

           $.ajax({
                   type        : 'POST', 
                   url         : url, 
                   data        : data, 
                   dataType    : 'html',
                   encode          : true,
                   success: function(result){
                           
                           var result = JSON.parse(result); 
                           if(result.code =='E200')
                           {
                                   $('#loader1').html('<div class="alert alert-info"> Traitement fait avec succ&egrave;s, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#save").prop('disabled', false);
                                   $("#treat").prop('disabled', true);
                                   $('#close').prop("disabled",false);
                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   scrollUP();
                           }
                           else if(result.code =='E500')
                           {
                                    $('#loader1').html('<div class="alert alert-info"> Vous avez d&eacute;j&agrave; trait&eacute; ce lot des bulletins, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#save").prop('disabled', false);
                                    $("#treat").prop('disabled', true);
                                    $('#close').prop("disabled",false);
                                    
                                    $('#bulletin_id').val(result.id);
                                    $('#logirefid').val(result.reference);
                                    scrollUP();
                           }
                           else if(result.code =='E501')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                    $('#close').prop("disabled",false);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E502')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#close').prop("disabled",false);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E503')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Vous avez d&eacute;j&agrave; d&eacute;bit&eacute; ce client pour ce lot des bulltins  mais amplitude n\'avait pas retourn&eacute; une r&eacute;ponse, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#close').prop("disabled",false);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E301')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Probl&eacute;me de connexion &agrave; amplitude, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#close').prop("disabled",false);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E302')
                           {
                                   $('#loader1').html('<div class="alert alert-danger">Le d&eacute;bit du compte du client s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E303')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est fait partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E304')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est fait partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la r&eacute;servation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E305')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                           else if(result.code =='E306')
                           {
                                   $('#loader1').html('<div class="alert alert-danger"> Le d&eacute;bit s\'est faite partiellement, veuillez cliquer sur le bouton [v&eacute;rifier] pour finaliser la transaction.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                   $("#treat").prop('disabled', true);
                                   $('#verify').removeClass('d-none');

                                   $('#bulletin_id').val(result.id);
                                   $('#logirefid').val(result.reference);
                                   $('#error_code').val(result.code);
                                   $('#transaction_id').val(result.transaction_id);
                                   scrollUP();
                           }
                   },
                   error:function(error){
                       $('#loader1').html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                   }
           });
    }

    function verify(data)
    {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

           var url = '<?php echo base_url($module.'/taxprepayments/display/verify'); ?>';

           $("#verify").prop('disabled', true);

           $.ajax({
                   type        : 'POST', 
                   url         : url, 
                   data        : data, 
                   dataType    : 'html', 
                   encode      : true,
                   success: function(result){
                       $('#loader1').html('');

                       if(result =='E200')
                       {
                               $('#loader1').html('<div class="alert alert-info text-white"> Le d&eacute;bit du compte du client fait avec succès, veuillez cliquer sur le bouton [enregistrer] pour passer &agrave l&apos;&eacute;tape suivante.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               $("#envoyer").removeClass('btn-default');
                               $("#envoyer").addClass('btn-success');
                               $("#save").prop('disabled', false);
                               scrollUP();
                       }
                       else if(result =='E304')
                       {

                               $('#loader1').html('<div class="alert alert-danger text-white"> Le d&eacute;bit du compte du client n\'a pas &eacute;t&eacute; fait. Il se pose un probl&egrave;me avec le compte du client, veuillez v&eacute;rifier le probl&egrave;me dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               scrollUP();
                       }
                       else
                       {

                               $('#loader1').html('<div class="alert alert-danger text-white"> Le d&eacute;bit du compte du client a &eacute;t&eacute; int&eacute;gr&eacute; partiellement, veuillez v&eacute;rifier dans amplitude.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                               scrollUP();
                       }

                   },
                   error:function(error)
                   {
                       $('#loader1').html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                       scrollUP();
                   }
           });
    }

    function close_form()
    {
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

           $.get("<?php echo base_url($module.'/taxreports/display/prepayments'); ?>", function (data, status) {
               $("#loader1").html('');
               $("#pager").html(data);
               $("#pager").addClass('content');

               $("#close").removeClass('hidden');
               $("#close_form").addClass('hidden');

           });
    }

</script>
