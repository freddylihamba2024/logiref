<?php

$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");
$recieptDate = explode("/",$bulletin->DateL_11);

?>

<?php $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid'];?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="message"></div>
    <div id="message1"></div>
    <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                
                <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />
                
                <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />
                
                <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                <input type="hidden" name="Sydonia_49" value="<?php echo $encaissement->Sydonia_49; ?>" />
                <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
                
                <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                
                <div class="row">
                    <div class="col-md-12">
                        <br/><br/>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Bureau</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;clarant</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Declarant_16; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;signation</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Designation_14.' / '.$encaissement->Nif_13; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Mode de paiement</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php  echo $modes[$encaissement->Mode_19]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Intitul&eacute; du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Num&eacute;ro du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Serial_9.' '.$bulletin->Number_10; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Ann&eacute;e du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $recieptDate[2]; ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total(BL)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Montant_11.' CDF '; ?>
                            </div>
                        </div> 
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Commission</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Commission_23,2,","," ").' '.$encaissement->Devise_24;?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Total,2,","," ").' CDF'; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte client(&agrave; d&eacute;biter)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Devise du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?= isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b> <?= isset($encaissement->Taux_41 ) ? $encaissement->Taux_41 : ""; ?> CDF
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte Guichet Unique</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b>  <span class="<?php if($encaissement->CGU=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $encaissement->CGU; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 bTop">
                        <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                    </div>
                </div>
                <div class="row"><div class="col-md-12"><br></div></div>
                <div class="row">
                    <div class="col-md-12">
                        <table id="table" class="table table-hover table-striped">
                            <thead >
                                <tr class="bg-blue">
                                    <th width="250px">Libell&eacute;</th>
                                    <th width="100px">Op&eacute;ration</th>
                                    <th width="200px">Source</th>
                                    <th width="200px">D&eacute;stination</th>
                                    <th class="right" width="">Montant</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <?php foreach($integrations as $row) :?>
                                    <?php if($row->Operation_8 == 'C'):?>
                                    <tr>
                                        <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                        <td  width="100px"><?php echo $row->Operation_8;?></td>
                                        <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                        <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                        <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                    </tr>
                                    <?php else:?>
                                    <tr>
                                        <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                        <td  width="100px"><?php echo $row->Operation_8;?></td>
                                        <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                        <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                        <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                    </tr>
                                    <?php endif;?>
                                <?php endforeach;?>
                            </tbody>    
                        </table>
                    </div>
                </div>
            </div>
            <div class="box-footer clearfix">
            </div>
        <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">
   
var ref = '<?php echo(isset($bulletin->MessageKey_7))? $bulletin->MessageKey_7 :''?>';
        
$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});

$("#print_attestation").click(function(){
       
        var bl = '<?php echo $encaissement->Sydonia_44; ?>';
        
        var url = '<?php echo base_url($module.'/taximpression/display/attestationbl'); ?>/' + bl;
        
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#schema").click(function(){

        var bl = '<?php echo $encaissement->Sydonia_49; ?>';
        
        var url = '<?php echo base_url($module.'/taximpression/display/schema_prepayment'); ?>/' + bl;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});


$("#closePanel").click(function(){
   
   location.reload(true);
    
});
function submiter(data){
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/save/comptant'); ?>';
        
        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert alert-success text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>'
            var url = '<?php echo base_url($module.'/taxprepayments/save/validate'); ?>';
            scrollUP();
            $('#confirm').prop("disabled",true);
            $("#loader").html('');
            message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php else: ?>'
            scrollUP();
            $('#confirm').prop("disabled",true);
            $("#loader").html('');
        '<?php endif; ?>'
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){
                        
                        if(result.code=='200' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);

                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                                
               
                                if(ref !="")
                                {
                                    var url = '<?php echo base_url($module.'/prepayments'); ?>/display/prepaymentsAck';
                                    $.ajax({
                                        type        : 'POST', 
                                        url         : url, 
                                        data        : {messageskeys : ref, message : 'OK', id : result.id}, 
                                        dataType    : 'html', 
                                        encode          : true,
                                        success: function(result){
                                            if(result =='41')
                                            {
                                                $('#message1').html('');
                                                $("#message1").html('<div class="alert alert-info">Bravo! Transaction cl&ocirc;tur&eacute;e avec succ&egrave;s...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(result =='42')
                                            {
                                                $('#message1').html('');
                                                $("#message1").html('<div class="alert aDanger text-white">Desol&eacute;! L&apos;accus&eacute; de recption a &eacute;chou&eacute;, essayez plutard...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(result =='E404')
                                            {
                                                $('#message1').html('');
                                                $("#message1").html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }
                                            else if(result =='E401')
                                            {
                                                $('#message1').html('');
                                                $("#message1").html('<div class="alert aWarning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                            }

                                        },
                                        error:function(error){
                                            
                                            $("#message").html('<div class="alert aWarning text-white">Alerte: l&apos;evoi automatique de l&apos;accus&eacute; n&apos;a pas abouti! pri&egrave;re de le faire au menu des p&eacute;-paiements valid&eacute;s...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        }
                                    });
                                }
                        }
                        else if(result.code=='300' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);

                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s mais quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(result.code=='404' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);

                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s sauf que quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(result.code=='202' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);

                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s mais il y a eu aucune r&eacute;ponse d\'amplitude par rapport aux &eacute;critures envoy&eacute;es, veuillez trouver ce paiement dans le menu regularisation afin de v&eacute;rifier l\'int&eacute;gration de toutes les &eacute;critures.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(result.code=='411' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);
                                
                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s, Mais l\'int&eacute;gration s\'est fait partiellement dans amplitude, veuillez trouver ce paiement dans le menu regularisation pour le regulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else if(result.code=='405' && result.id > 0)
                        {
                                $("#step-2").removeClass('bg-green-active');
                                $("#step-2").addClass('bg-gray');
                                $("#step-3").removeClass('bg-gray');
                                $("#step-3").addClass('bg-green-active');
                                $('#print_quittance').prop("disabled",false);
                                $('#schema').prop("disabled",false);
                                $('#quittance').prop("disabled",false);
                                
                                var url = '<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/' + result.id;
                                $.get(url, function(data, status){
                                    $('#message').html('');
                                    $('#loader').html('<div class="alert aWarning text-white">Aucune &eacute;criture envoy&eacute;e &agrave; amplitude pour ce paiement d&ucirc; au probl&egrave;me d\'informations manquantes.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                    $("#pager").html(data);
                                });
                        }
                        else
                        {
                                $('#message').html('');
                                $('#loader').html('<div class="alert aDanger text-white">Paiement non valid&eacute;, un probl&grave;me est survenu. Veuillez v&eacute;rifier dans amplitude la situation des transactions de ce paiement avant de le refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        
                },
                error:function(error){
                    $('#message').html('');
                    $('#loader').html('<div class="alert aWarning text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s. Le d&eacute;lai de temps de r&eacute;ponse est d&eacute;pass&eacute;, veuillez v&eacute;rifier l\'int&eacute;gration de chaque &eacute;criture dans le sch&eacute;ma comptable s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}


function closeView()
{
        $.get("<?php echo base_url($module.'/taxreports/display/nvalidated'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
}

</script>
