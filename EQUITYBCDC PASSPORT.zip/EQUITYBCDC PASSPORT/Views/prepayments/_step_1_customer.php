<?php 

$total_amount = 0;

if($account !='')
{
        $error_message = '';
}
else
{
        $error_message = '<div class="alert alert-warning">Le compte de prépaiement pour ce cleint n\'est pas paramétré, veuillez contacter votre administrateur à cet effet.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        
}

?>

<div id="pager">
    <div class="col-md-12 p-0">
        <div id="loader1"><?php echo $error_message; ?></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => 'innovate')); ?>
        <?php $chtml->box_body_opening('', true);?>
        <div class="col-md-12">
                <div class="box-body">
                    <input type="hidden" id="frais_bcc" value="<?php echo $frais_bcc;?>" name="frais_bcc"/>
                    <input type="hidden" id="Npaiements" value="<?php echo $nbr_total;?>" name="Npaiements"/>
                    <input type="hidden"  value="<?php echo (isset($object_info->Declarant_16)) ? $object_info->Declarant_16 : '';?>" name="Declarant"/>
                    <input type="hidden"  value="<?php echo (isset($object_info->Nif_15)) ? $object_info->Nif_15 : '';?>" name="Nif"/>
                    <div class="col-md-12 p-0">
                        <h2 class=" f20 w-300 page-header">Traitement des bulletins  pr&eacute;pay&eacute;s</h2>
                        <br/>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Référence SYDONIA</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($account_reference) ? $account_reference : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Banque</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($object_info->CodeBank_13) ? $object_info->CodeBank_13 : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;clarant</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo isset($object_info->Declarant_16) ? $object_info->Declarant_16 : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">D&eacute;signation</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <?php echo $designation; ?>
                                    <input type="hidden" id="designation" value="<?php echo $designation; ?>" name="designation"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte de pr&eacute;paiement</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="cCompte"><?php if($account !='') echo $account.' CDF'; else echo ''; ?></span>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Intitul&eacute; du compte</label>
                                    <input type="hidden" value="" id="account_name" name="account_name"/>
                                    <input type="hidden" value="" name="account_type" id="account_type"  />
                                    <input type="hidden" name="prepaid_balance" id="prepaid_balance" value="" >
                                    <input type="hidden" name="branch_code" value="" id="branch_code">

                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="accountname"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Montant total du lot</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> <span id="total_amount"></span> CDF
                                    <input type="hidden" id="lot_amount" value="0" name="total_amount"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Commission</label>
                                </div>
                                <div class="col-md-8">
                                   <b>:</b>  <?php echo number_format($commission,2,","," ")  ?>  CDF
                                   <input type="hidden" id="Commission" value="<?php echo $commission ?>" name="Commission"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">TVA</label>
                                </div>
                                <div class="col-md-8">
                                    <?php $tva = $commission * 0.16; ?>
                                   <b>:</b> <?php echo number_format($tva,2,","," ")  ?> CDF
                                   <input type="hidden" id="Tva" value="<?php echo $tva ?>" name="Tva"/>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Mode de paiement</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b> OP
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Compte Guichet unique</label>
                                </div>
                                <div class="col-md-8">
                                    <b>:</b>  <?php echo isset($cguichet) ? $cguichet : ""; ?>
                                </div>
                            </div>
                            <div class="input-group col-md-12 no-padding">
                                <div class="col-md-4 no-padding">
                                    <label for="office">Total à payer</label>
                                </div>
                                <div class="col-md-8">
                                    <?php if (isset($tota_to_paid) && $tota_to_paid > 0): ?>
                                         <b>:</b> <span id="total_amount"></span> <?php echo number_format($tota_to_paid,2,","," ")  ?> CDF
                                        <input type="hidden" id="tota_to_paid" value="<?php echo $tota_to_paid ?> " name="tota_to_paid"/>
                                    <?php else: ?>
                                        <b>:</b> <span id="topaid"> </span> <?php echo "CDF"; ?>
                                        <input type="hidden" id="tota_to_paid" name="tota_to_paid"/>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(isset($options['DGDA']['prepayment-fee-deduction-current-account'])): ?>
                        <div class="row"><div class="col-md-12"><br/><label class="f12 w-300 page-header"><h5>Partie : Informations additionnelles [Compte courant pour le prélèvement des frais]</h5></label><br/></div></div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                </br><label>Paie les frais&nbsp;&nbsp;<input type="checkbox" name="Infos[fees]" value="<?= 1 ?>" id="fees"></label>
                            </div>
                        </div>

                        <div id="accountc_panel" class="row d-none">
                            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                                <div class="form-group col-md-4 d-flex  no-padding">
                                    <label for="customerNumber" class="col-md-4 col-form-label">N° du client</label>
                                    <div class="col-md-8">
                                        <span style="display: block; font-size: 0.9em; margin-top: -25px;">
                                            <span id="labelNumber">.</span>
                                        </span>
                                        <?php echo form_input('Infos[customercode]', set_value('Customernumber', ''), 'class="form-control" id="customerNumber" maxlength="7" placeholder="E.g: 123456" '); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 d-flex  no-padding">
                                    <label for="bank_accountc" id="" class="col-md-3 col-form-label">Compte &agrave; d&eacute;biter</label>
                                    <div class="col-md-8">
                                        <span id="acccountname" style="display: block; font-size: 0.9em; margin-top: -25px;">
                                            <span id="account_c_name">.</span>
                                        </span>
                                        <input type="text" name="Customer_current_account" id="bank_accountc" class="form-control" placeholder="E.g: 0000100002000030000400005" >
                                        <input type="hidden" name="Infos[accountc_name]" id="accountc_name" value="">
                                        <input type="hidden" name="account_balance_fees" id="account_balance_fees" value="0" >
                                        <input type="hidden" name="internal_accountc" id="internal_accountc" value="">
                                        <input type="hidden" name="Infos[feesbcc]" value="<?php echo $frais_bcc;?>" id="feesbcc"/>
                                    </div>
                                </div>
                                <div class="form-group col-md-2 d-flex no-padding">
                                    <label for="Devise_account_c" class="col-md-3 col-form-label">Devise</label>
                                    <div class="col-md-8">
                                        <span id="" style="display: block; font-size: 0.9em; margin-top: -25px;">
                                            <span id="">.</span>
                                        </span>
                                        <?php echo form_dropdown('Devise_account_c', $devises, "", 'class="form-control" id="Devise_account_c"'); ?>
                                        <input type="hidden" name="Devise_account_c" value="" id="currency_c">
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="form-group col-md-6 d-flex  no-padding">
                                    <label for="bank_accountc" id="" class="col-md-4 col-form-label">Compte &agrave; d&eacute;biter pour les frais</label>
                                    <div class="col-md-8">
                                        <span id="acccountname" style="display: block; font-size: 0.9em; margin-top: -25px;">
                                            <span id="account_c_name">.</span>
                                        </span>
                                        <input type="text" name="Customer_current_account" id="bank_accountc" class="form-control" placeholder="E.g: 0000100002000030000400005">
                                        <input type="hidden" name="accountc_name" id="accountc_name" value="">
                                        <input type="hidden" name="account_balance_fees" id="account_balance_fees" value="0" >
                                        <input type="hidden" name="account_type" value="" id="account_type">
                                        <input type="hidden" name="internal_accountc" id="internal_accountc" value="">
                                        <input type="hidden" name="Infos[feesbcc]" value="<?php echo $frais_bcc;?>" id="feesbcc"/>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 d-flex no-padding">
                                    <label for="Devise_account_c" class="col-md-4 col-form-label">Devise du compte</label>
                                    <div class="col-md-8">
                                        <?php echo form_dropdown('Devise_account_c', $devises, "", 'class="form-control" id="Devise_account_c"'); ?>
                                        <input type="hidden" name="Devise_account_c" value="" id="currency_c">
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="box-footer clearfix">
                    <div class="col-md-12 p-0">
                        <br/>
                        <button type="submit" id="treat" class="btn btn-primary" <?php if($error_message !='') echo 'disabled'; ?> ><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="verify" class="btn btn-danger d-none" ><i class="fa fa-history"></i>&nbsp;&nbsp;Vérifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="submit" id="save" class="btn btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;  
                        <input type="hidden" name="action" value="" id="action">
                        <button type="button" id="close" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp; 

                        <input type="hidden" name="account_reference" value="<?= $account_reference; ?>" >
                        <input type="hidden" name="Compte_33" value="<?= $account; ?>" >
                        <input type="hidden" name="Infos[total_fees]" id="fees_amount" value="<?= $fees_amount ?>" >
                        <input type="hidden" name="action" value="" id="action">
                        <input type="hidden" name="logirefid" value="" id="logirefid">
                        <input type="hidden" name="transaction_id" value="" id="transaction_id">
                        <input type="hidden" name="error_code" value="" id="error_code">
                    </div>
                </div>
        </div>
        <div class="col-md-12 bTop">
            <div class="col-md-12">
            <br/><label>Liste des bulletins</label><br/>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead class='bg-gray'>
                        <tr>
                            <th width="5px">#</th>
                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                            <th width="150px">Bureau</th>
                            <th width="100px">Declarant</th>
                            <th width="100px" class="center">Nombre des bulletins</th>
                            <th width="150px" class="center">Montant total</th>
                            <th width="10px" style="text-align:left;" ><i class="fa fa-edit f20"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $all_ids = [];  $i = 1; foreach($prepayments as $payments): ?>
                            
                        <tr>
                            <td width=""><?php echo $i; ?></td>
                            <td width=""><?php echo $account_reference; ?></td>
                            <td width=""><?php echo $services['DGDA'][$payments->Office_8]; ?></td>
                            <td width=""><ul><?php echo $payments->Declarant_16; ?></ul></td>
                            <td width=""><ul><?php echo $payments->total; ?></ul></td>
                            <td width=""><ul><?php echo $payments->amounts; ?></ul></td>
                            <td width="">
                                <a style="cursor: pointer" onclick="view_bulletin('<?php echo $account_reference; ?>', '<?php echo $payments->Office_8; ?>')"> 
                                    <i class="fa fa-edit f20"></i> 
                                </a>
                            </td>
                        </tr>
                        <input type="hidden" value="<?php echo $payments->Office_8;?>" name="Office"/>

                        <?php 
                            $total_amount = $total_amount + $payments->amounts; 
                            $all_ids = array_merge($all_ids, $payments->ids);  
                        ?>
                        <?php $i++; endforeach;  ?>
                        <input type="hidden" value="<?php echo implode(',', $all_ids); ?>" name="Ids"/>
                    </tbody>
                </table>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?> 
        <?php echo form_close(); ?>
    </div>
    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    //var lot = '<?php //echo $lot; ?>';

    let csrfName = '<?= csrf_token() ?>';
    let csrfHash = '<?= csrf_hash() ?>';

    var fees = false;
    var total_amount = '<?php echo $total_amount ?>';
    $("#total_amount").html(total_amount.toLocaleString());
    $("#lot_amount").val(total_amount);
    
    '<?php if (isset($tota_to_paid) && $tota_to_paid == 0): ?>';
    $("#topaid").html(total_amount.toLocaleString());
    $("#tota_to_paid").val(total_amount);
    '<?php endif; ?>';

    $("#contenter").on("click", "#close_form", function(){
        close_form();
    });

    get_accountname();
    
    $("#treat").click(function(){
       $("#action").val('traiter');
    });
    
    $("#verify").click(function(){
       $("#action").val('verify');
    });

    $("#save").click(function(){
       $("#action").val('save');
    });

    '<?php if(isset($options['DGDA']['prepayment-fee-deduction-current-account'])): ?>';

        if(!$("#fees").prop("checked"))
        {
            $("#bank_accountc, #Devise_account_c, #accountc_name, #currency_c, #internal_accountc").removeAttr("name").prop("required", false);
            $("#bank_accountc, #Devise_account_c, #accountc_name, #currency_c").val('');
            $("#account_c_name").html('.');

            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                $("#customerNumber").val('').prop("required", false).removeAttr("name");
            <?php endif; ?>

            $("#fees").val(0);
        }
    '<?php endif; ?>';

    $("#fees").change(function(){

        if($(this).prop("checked") == true)
        {
            fees = true;
            $("#fees").val(1);
            $("#accountc_panel").removeClass("d-none")

            $("#accountc_name").attr("name", "Infos[accountc_name]");
            $("#currency_c").attr("name", "Devise_account_c");
            $("#internal_accountc").attr("name", "internal_accountc");

            $("#bank_accountc").attr("name", "Customer_current_account").prop("required", true);
            $("#Devise_account_c").attr("name", "Devise_account_c").prop("required", true);

            '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>'
                $("#customerNumber").attr("name", "Infos[customercode]").prop("required", true);
            '<?php endif; ?>';
        }
        else
        {
            $('#loader-sub-menu').html('');
            $("#accountc_panel").addClass("d-none");

            fees = false;
            $("#fees").val(0);

            $("#bank_accountc, #Devise_account_c, #accountc_name, #currency_c, #internal_accountc").removeAttr("name").prop("required", false);
            $("#bank_accountc, #Devise_account_c, #accountc_name, #currency_c").val('');
            $("#account_c_name").html('.');

            <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                $("#customerNumber").val('').prop("required", false).removeAttr("name");
            <?php endif; ?>

            const account_html = '<input type="text" name="Customer_current_account" id="bank_accountc" class="form-control" placeholder="E.g: 0000100002000030000400005">'
            const currency = `<?php echo form_dropdown('Devise_account_c', $devises, "", 'class="form-control" id="Devise_account_c"'); ?>`;

            $('#bank_accountc').replaceWith(account_html);
            $('#Devise_account_c').replaceWith(currency);
        }
    });

    $("#pager").on("submit", "#mainform", function(event){
        event.preventDefault();

        var data = $(this).serialize(); 
        data += '&' + encodeURIComponent(csrfName) + '=' + encodeURIComponent(csrfHash); 

        var action = $('#action').val();

        if(action == 'traiter')
        {
                var verify_prepaid = verify_prepaid_account_balance();

                if(verify_prepaid)
                {
                        '<?php if(isset($options['DGDA']['prepayment-fee-deduction-current-account'])): ?>';
                        var verify_fees = verify_account_balance_fees();
                        '<?php endif; ?>';

                        if(fees)
                        {
                                if(verify_fees)
                                {
                                        treatment(data);
                                }
                                else
                                {
                                        $('#loader-sub-menu').html('<div class="alert aDanger text-white">Le solde du compte courant du client est insuffisant pour le pr&eacute;levement des frais.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                        }
                        else
                        {
                                treatment(data);
                        }
                }
                else
                {
                        $('#loader-sub-menu').html('<div class="alert aDanger  text-white">Le solde du compte de pr&eacute;paiement n\'a pas assez de provision pour payer les bulletins de pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        }
        else if(action == 'save')
        {
            submiter(data);
        }
        else if(action == 'verify')
        {
            verify(data);
        }
    });

    $("#balance").css('background-color','#00cc33');

    $("#close").click(function(){
           close_form();
    });

    $("#bank_accountc").change(function(){
       get_account_fees_name(); 
    });

    $("#Devise_account_c").change(function(){
       get_account_fees_name(); 
    });

    '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>';
        $("#customerNumber").change(function(){
            var customer_number = $(this).val();

            if (customer_number.length <= '7')
            {
                get_customeraccounts()
            }
        });
    '<?php endif; ?>';

    $(document).on('change', '#bank_accountc', function () {

        $("#account_c_name").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $(this).find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#account_c_name').html('.');
            $('#accountc_name, #Devise_account_c, #account_balance_fees, #account_type').val('');
            $('#compteDevise').val('').trigger('change');
            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        // Ajoute un délai avant d'afficher les infos
        setTimeout(function () {
            $('#account_c_name').removeClass().addClass('text-green').html(name);
            $('#accountc_name').val(name);
            $('#Devise_account_c').val(currency);
            $('#account_balance_fees').val(balance);
            $('#account_type').val(type);

            if (currency) {
                $('#Devise_account_c').val(currency);
                $('#Devise_account_c').prop('disabled', true);

                // Supprime tout champ hidden existant pour éviter les doublons
                $('input[name="Devise_account_c"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_account_c',
                    id: 'currency_c',
                    value: currency
                }).appendTo('form');
            }
        }, 2000);
    });

    function get_customeraccounts()
    {
            const customer_number = $('#customerNumber').val();
            const csrf = $('input[name="csrf_name"]').val();
            const core_banking = '<?php echo $core_banking; ?>';

            const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

            if (!customer_number) {
                $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
                return;
            }

            const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
            $("#labelNumber").html(loader_img);

            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    customer_number: customer_number,
                    csrf_name: csrf
                },
                dataType: 'json',
                encode: true,
                success: function (reponse) {

                    if (reponse.code == "200")
                    {
                        const mapped_currency = {
                            '976': 'CDF',
                            '840': 'USD'
                        };

                        let select = $('<select>', {
                            id: 'bank_accountc',
                            name: 'Customer_current_account',
                            class: 'form-control form-control-md',
                            required: true
                        });

                        select.append('<option value="">Sélectionnez un compte du client</option>');

                        $.each(reponse, function (index, account) {
                            if (!isNaN(index)) {

                                const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                                const option_text = `${account.accountNumber} - (${currency_label})`;

                                select.append($('<option>', {
                                    value: account.accountNumber,
                                    text: option_text,
                                    'data-name': account.name,
                                    'data-currency': account.currencyCode,
                                    'data-balance': account.balance,
                                    'data-type': account.type
                                }));
                            }
                        });

                        // Remplace l'élément actuel (input ou select)
                        if ($('#bank_accountc').prop('tagName') === 'SELECT') {
                            $('#bank_accountc').replaceWith(select);
                        } else {
                            $('#bank_accountc').replaceWith(select);
                        }

                        // Déclenche le changement
                        select.trigger('change');

                        $("#labelNumber").html('.');

                    } else{

                        const input_html = '<input type="text" name="Customer_current_account" id="bank_accountc" class="form-control" placeholder="E.g: 0000100002000030000400005">'

                        $('#bank_accountc').replaceWith(input_html);

                        $("#labelNumber").html('.');

                        if (reponse.code === '404') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                            return;
                        } else if (reponse.code === '405') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                            return;
                        } else if (reponse.code === '406') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                            return;
                        }
                    }
                },
                error: function () {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
    }
    
    function treatment(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        //$("#treat").prop('disabled', true);
        $('#close').prop("disabled",true);

        var url = '<?php echo base_url($module.'/taxprepayments/save/batch_customer'); ?>';
        $('#save').prop("disabled",true);

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html',
            encode          : true,
            success: function(result){

                $("#loader-sub-menu").html(result);
                var result = JSON.parse(result); 

                $('#logirefid').val(result.reference);

	                if(result.code =='E200' || result.code =='E500')
	                {
	                    var data = $('#mainform').serialize();
	                    
                        <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])) : ?>
                            get_reservation(data);
                        <?php else: ?>
                            get_reservation_debit_account(data);
                        <?php endif; ?>
                        
	                }
	                else if(result.code =='E401')
	                {
	                    $("#loader-sub-menu").html('<div class="alert alert-danger"> Votre requête a rencontré un problème. Veuillez réessayer..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
	                    $("#save").prop('disabled', false);
                    $('#close').prop("disabled",false);
                }
             },
             error:function(error){
                 $("#loader-sub-menu").html('<div class="alert alert-warning">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
             }
        });
    }

    function submiter(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module.'/taxprepayments/save/comptant'); ?>';
        $('#save').prop("disabled",true);

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html',
            encode          : true,
            success: function(result){

                if(result=='E500')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info">Ce lot de pr&eacute;paiement est d&eacute;j&agrave; enregistr&eacute;, veuillez v&eacute;rifier dans la liste de pr&eacute;paiements enregistr&eacute;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(isNaN(result)==true)
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">L\'enregistrement a pris beaucoup de temps, allez v&eacute;rifier le statut de ce lot de paiement dans le menu pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result > 0)
                {
                    $("#loader-sub-menu").html('<div class="alert aSuccess text-white">Bravo! paiements encaiss&eacute;s avec succ&eacute;s!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $("#loader-sub-menu").html('');
                    $("#loader-sub-menu").html('<div class="alert aWarning" aWarning text-white>L\'enregistrement a pris beaucoup de temps, allez v&eacute;rifier le statut de ce lot de paiement dans le menu pr&eacute;paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error:function(error){
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le traitement a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function get_reservation_debit_account(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/debit_client'); ?>';

    //$("#treat").prop('disabled', true);

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode      : true,
        success: function(result){
            $('#loader-sub-menu').html('');
            $('#close').prop("disabled",false);

            if(result.code=='E407')
            {
                $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $('#reserve').prop("disabled",true);
                $('#valider').prop("disabled",true);
            }
            else
            {
                if(result.code == 'E200' || result.code == 'E500')
                {
                    $("#loader-sub-menu").html('<div class="alert alert-info"> Traitement fait avec succ&egrave;s, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#save").prop('disabled', false);
                    
                }
                else
                {
                    $("#loader-sub-menu").html(result.msg);
                    $('#verify').removeClass('d-none');
                    $("#treat").prop('disabled',true);

                    $('#error_code').val(result.code);
                    $('#transaction_id').val(result.transaction_id);
                    //$('#logirefid').val(result.reference);
                }
            } 
        },
        error:function(error)
        {
            $("#loader-sub-menu").html('<div class="alert aWarning text-white">La r&eacute;servation a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        });
    }

    function get_reservation(data)
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/reservation'); ?>';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result){
                $('#loader-sub-menu').html('');
                $('#close').prop("disabled",false);

                if(result.code=='E407')
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de réservation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#reserve').prop("disabled",true);
                    $('#valider').prop("disabled",true);
                }
                else
                {
                    if(result.code == 'E200')
                    {
                        $("#loader-sub-menu").html('<div class="alert alert-info"> Traitement fait avec succ&egrave;s, veuillez cliquer sur le bouton [enregistrer] pour g&eacute;n&eacute;rer les &eacute;critures de ce lot des bulletins.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $("#save").prop('disabled', false);
                    }
                    else
                    {
                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">La réservation n\'a pas abouti complètement (code: '+result.code+'), veuillez cliquer sur le bouton [vérifier].<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#verify').removeClass('d-none');
                        $("#treat").prop('disabled',true);

                        $('#error_code').val(result.code);
                        $('#transaction_id').val(result.transaction_id);
                    }
                }
            },
            error:function(error)
            {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La réservation a pris beaucoup de temps, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function verify(data)
	    {
	        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments'); ?>/display/verify_transaction';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result){
                $("#loader-sub-menu").html('');

                if(result.code =='E407')
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white">Désolé, l\'option de verification n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#repartition').prop("disabled",true);
                    $('#valider').prop("disabled",true);
                }
                else if(result.code =='E200')
                {
                    $("#loader-sub-menu").html(result.msg);
                    $("#save").prop('disabled',false);
                    $("#verify").prop('disabled',true);
                }
                else
                {
                    $('#loader-sub-menu').html(result.msg);
                }
            },
            error:function(error)
            {
                $('#loader-sub-menu').html('<div class="alert alert-warning text-white">La v&eacute;rification a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function get_accountname() 
    {
        var chtml = $("#accountname").html();
        var compte = '<?php echo $account; ?>';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#prepaid_balance").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_account_fees_name()
    {
        var chtml = $("#account_c_name").html();
        var compte = $('#bank_accountc').val();
        var devise = $('#Devise_account_c option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
		
	    var core_banking = '<?php echo $core_banking; ?>';
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#account_c_name").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").removeClass('text-green');
                            $("#account_c_name").addClass('text-red');
                            $("#account_c_name").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").removeClass('text-green');
                            $("#account_c_name").addClass('text-red');
                            $("#account_c_name").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").removeClass('text-green');
                            $("#account_c_name").addClass('text-red');
                            $("#account_c_name").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").removeClass('text-green');
                            $("#account_c_name").addClass('text-red');
                            $("#account_c_name").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#account_c_name").removeClass('text-green');
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").addClass('text-red');
                            $("#account_c_name").html('Devise du compte incorrecte');

                            $('#Devise_account_c').val('');
                    }
                    else
                    {
                            
                            $("#account_c_name").removeClass('text-black');
                            $("#account_c_name").addClass('text-green');
                            $("#account_c_name").html(reponse.account_name);
                            $("#accountc_name").val(reponse.account_name);

                            $("#account_currency").val(reponse.currency);
                            $("#account_balance_fees").val(reponse.balance);
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#account_c_name").html('.');
        }
    }

    function verify_account_balance_fees()
    {
            var account_balance_fees = parseFloat($("#account_balance_fees").val().split(' ').join('').split(',').join('.'));
            var fees_amount = parseFloat($("#fees_amount").val().split(' ').join('').split(',').join('.'));

            if(fees_amount > account_balance_fees)
            {
                    return false;
            }
            else
            {
                    return true;
            }
    }

    function verify_prepaid_account_balance()
    {
        var prepaid_balance = parseFloat($("#prepaid_balance").val().split(' ').join('').split(',').join('.'));

        var prepaid_amount = '<?php echo $total_amount ?>';
        prepaid_amount = parseFloat(prepaid_amount.split(' ').join('').split(',').join('.'));
        
        if(prepaid_amount > prepaid_balance)
        {
                return false;
        }
        else
        {
                return true;
        }
    }

    function view_bulletin(account, office) 
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments/display/_bulletins'); ?>/';
        
        $.get(url, {compte: account, office:office}, function (data, status) {
            $("#loader-sub-menu").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
    }
    
    function close_form()
    {
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module.'/taxprepayments/display/prepaymentlist'); ?>", function (data, status) {
            $("#loader-sub-menu").html('');
            $("#container").html(data);
        });
    }

</script>
