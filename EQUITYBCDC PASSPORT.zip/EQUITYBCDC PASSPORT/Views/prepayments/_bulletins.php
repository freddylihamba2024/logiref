<div id="pager">
    <div class="col-md-12">
        <div id="loader1"></div>
        <?php $chtml->box_body_opening('', true);?>
        
        <div class="col-md-12">
            <div class="box-body">
                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header">Liste des bulletins</h2>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <?php if(!empty($prepayments)): ?>
            <div class="col-md-12">
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th width="5px">#</th>
                            <th width="10px">Date</th>
                            <th width="200px">Bureau</th>
                            <th width="100px">N° imp&ocirc;t</th>
                            <th width="20px">Bulletin</th>
                            <th width="160px">Montant</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        
                        <?php $i=1; foreach($prepayments as $row) : ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td  width=""><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1));?></td>
                                <td  width=""><?php echo isset($services['DGDA'][$row->Office_8]) ? $services['DGDA'][$row->Office_8] : "";?></td>
                                <td  width=""><?php echo $row->Nif_15;?></td>
                                <td><?php echo $row->Serial_9.''.$row->Number_10; ?></td>
                                <td ><?php echo 'CDF'.' '.number_format($row->Amount_18,2,","," ");?></td>
                            </tr>
                        <?php $i++; endforeach;?>
                    </tbody>    
                </table>
            </div>
            <?php else: ?>
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun bulletin trouvé!</b></span>        
                </section>
            <?php endif; ?>
        </div>
        <?php $chtml->box_body_closing(); ?> 
    </div>
</div>

