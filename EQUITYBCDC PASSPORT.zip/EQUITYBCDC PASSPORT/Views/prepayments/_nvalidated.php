<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', true); ?> 
<div id="list"  class="col-md-12">
    <?php if (!empty($payments)): ?>
        <table id="table" class="table no-margin table-striped table-bordered">
            <thead class='bg-blue'>
                <tr>
                    <th width="10px">#</th>
                    <th width="80px">Traitement</th>
                    <th width="200px">Bureau</th>
                    <th width="50px">Declarant</th>
                    <th width="150px">R&eacute;f&eacute;rence du compte</th>
                    <th width="100px" class="center">Montant du lot</th>
                    <th width="100px" class="center">Nbre de bulletins</th>
                    <th id="all"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check hidden f16"></i></th>
                </tr>
            </thead>
            <tbody>
                <?php   
                    $i = 1;
                    foreach($payments as $row):

                    $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                ?>
                    <tr  id="line<?php echo $row->Id_0;?>">
                        <td width=""><?php echo $i;?></td>
                        <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                        </td>
                        <td width=""><?php echo(isset($services['DGDA'][$row->Office_7]))? $services['DGDA'][$row->Office_7]:''; ?></td>
                        <td width=""><?php echo $row->Declarant_8;?></td>
                        <td width=""><?php echo $row->AccountRef_9; ?></td>
                        <td width="" class="center"><?php echo 'CDF '.number_format($row->Total_14,2,","," ") ?></td>
                        <td width="" class="center"><?php echo $row->Declarations_10; ?></td>
                        <td width="25">
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Total_14; ?>')" value="<?php echo $row->Lot_11; ?>" name="batch[]" />
                        </td>
                    </tr>
                <?php $i++; endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="col-md-12">
            <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></br>
                <span class="d-block f14 text-black p-2"><b>Aucun lot &agrave; importer !</b><</span>        
            </section>
        </div>
    <?php endif; ?> 
</div>
<div  class="box-footer clearfix col-md-12">
    <div id="createPaiement" class="col-md-12 no-padding">
        <button type="submit" id="submit"  name="submit" class="btn btn-success pull-left disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;<span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
        <button type="button" id="uploadExcel" class="btn btn-default" disabled><i class="fa  fa-file-excel-o"></i>&nbsp;&nbsp;Envoyer le fichier&nbsp;&nbsp;</button>&nbsp;&nbsp;
    </div>
</div>
<?php $chtml->box_body_closing(); ?>
<?php echo form_close(); ?>

<script type="text/javascript">
    
    $('#checkall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', 'checked');
        $('.check').removeClass("hidden");
        $('#checkall').addClass("hidden");
        $('#uncheckall').removeClass("hidden");

        $('.input_val').prop('disabled', false);
        $('.input_val1').prop('disabled', false);
        $('.input_val2').prop('disabled', false);

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;


        $("#submit").removeClass("disabled");
        $("#submit").prop("disabled",false);
        $("#index").html('('+ index+')');
    });

    $('#uncheckall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', '');
        $('.check').addClass("hidden");
        $('#checkall').removeClass("hidden");
        $('#uncheckall').addClass("hidden");

        $('.input_val').prop('disabled', true);
        $('.input_val1').prop('disabled', true);
        $('.input_val2').prop('disabled', true);

        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;

        $("#submit").removeClass("btn-primary");
        $("#submit").addClass("btn-success");
        $("#submit").prop("disabled",true);
        $("#index").html('');

    });

    $("#uploadExcel").click(function(){

            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

            $("#uploadExcel").prop('disabled', true);
            var btn = $("#uploadExcel").html();
            if(ref !=='')
            {

                var data = $("#mainform").serialize();
                var url = '<?php echo base_url($module.'/taxprepayments'); ?>/data/export_to_excel/'+ref;

                $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : data, 
                            dataType    : 'html', 
                            encode          : true,
                            success: function(result){

                                $("#loader1").html('');
                                var $allInputs = $("#table").find("input[type = 'checkbox']"); 
                                for(var i = 0; i < $allInputs.length ; i++)
                                {
                                        $($allInputs[i]).prop('disabled',true);
                                }

                                if(result == '200')
                                {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-success">Bravo: Fichier envoy&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#uploadExcel").html(btn);
                                }
                                else if(result == '404')
                                {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Echec! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#uploadExcel").prop('disabled', false);
                                        $("#uploadExcel").html(btn);
                                }
                                else if(result == 'E202')
                                {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-danger">Alerte: Probl&egrave;me de connexion au serveur FTP.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#uploadExcel").prop('disabled', false);
                                        $("#uploadExcel").html(btn);
                                }
                                else if(result == 'E444')
                                {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi du fichier! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#uploadExcel").prop('disabled', false);
                                        $("#uploadExcel").html(btn);
                                }
                                else if(result == 'E300')
                                {
                                        scrollUP();
                                        $('#loader1').html('<div class="alert alert-warning">Alerte: Echec de l&apos;envoi... fichier non trouv&eacute;! r&eacute;essayez.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#uploadExcel").prop('disabled', false);
                                        $("#uploadExcel").html(btn);
                                }



                            },
                            error:function(error){
                                alert('ERROR:'+error);
                            }
                });

            }

    });

    $("#mainform").submit(function(event){
            event.preventDefault();
            
            $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

            var url = '<?php echo base_url($module.'/taxprepayments'); ?>/save/instructions';
            var data = $(this).serialize();
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                        $("#loader1").html('');
                        if(result === "202")
                        {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: erreur fatal E202...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "400")
                        {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: Aucune instrcution n&apos;a &eacute;t&eacute; trouv&eacute;e!...rassurez-vous que les paiements s&eacute;l&eacute;ctionn&eacute;es ne sont pas valid&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "501")
                        {
                                $('#loader1').html('<div class="alert alert-warning">Alerte: erreur fatal E501...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                ref = result;
                                $('#loader1').html('');

                                $("#uncheckall").prop('disabled',true);
                                $("#checkall").prop('disabled',true);

                                $("#sendXML").removeClass('btn-default');
                                $("#sendXML").addClass('btn-primary');

                                $("#uploadExcel").removeClass('btn-default');
                                $("#uploadExcel").addClass('btn-success');

                                $('#sendXML').prop('disabled', false);
                                $('#uploadExcel').prop('disabled', false);
                                $('#submit').prop('disabled', true);
                                $("#loader1").html('<div class="alert alert-info">Bravo! enregistrement eff&eacute;ctu&eacute; avec succ&egrave;s...!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }

                    },
                    error:function(error){
                        $('#loader1').html('<div class="alert alert-warning">Alerte: Pas de connexion internet...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    });

    function reverser(id, regie, devise)
    {
            var $checedInputs = $('#table').find("input:checked");
            var index = $checedInputs.length;

            if(index > 0)
            {
                    $('#t'+id+''+regie).prop('disabled', false);
                    $('#r'+id+''+regie).prop('disabled', false);

                    $("#submit").removeClass("disabled");
                    $("#submit").prop("disabled",false);
                    $("#index").html('('+ index+')');
            }
            else if(index <= 0)
            {
                    $('#checkall').removeClass("hidden");
                    $('#uncheckall').addClass("hidden");

                    $('#t'+id+''+regie).prop('disabled', true);
                    $('#r'+id+''+regie).prop('disabled', true);

                    $("#submit").removeClass("btn-primary");
                    $("#submit").addClass("btn-success");
                    $("#submit").prop("disabled",true);
                    $("#index").html('');

                    regie = "";
                    devise = "";
            }
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader1").offset().top
        }, 20);
    }
</script>
