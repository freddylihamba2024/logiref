<!-- Nouvelle section  -->
<div id="loader"></div>

<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    
    <div class="row">
        <div class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'col-12 d-flex justify-content-end'; ?>">
            <button class=" btn btn-success  no-border no-radius no-margin" type="submit" id='valider' disabled><i class="fa fa-save text-white"></i> <span class="text-white">Débiter le compte du client</span> </button>&nbsp;&nbsp;&nbsp;
            <button class=" btn btn-primary no-border no-radius no-margin" type="submit" id='repartition'><i class="fa fa-archive text-white"></i> <span class="text-white">Répartition</span> </button>&nbsp;&nbsp;&nbsp;
            <button class=" btn bg-gray no-border no-radius no-margin" type="button" id="cancel"><i class="fa fa-fw fa-times f18"></i> </button>
            <input type="hidden" value="" id="action">
        </div>
    </div>
    <br/><br/>
    
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Bureau</label>
                        </div>
                        <div class="col-md-8">
                            <?php 
                                    $bureaux = json_decode($prepayment->Office_7, true);
                                    
                                    if(isset($bureaux) && is_array($bureaux))
                                    {
                                            foreach ($bureaux as $bureau)
                                            {
                                                    $office = $bureau;
                                            }
                                    }
                                    else
                                    {
                                            $office = $prepayment->Office_7;
                                    }
                            ?>
                            <b>:</b> <?php echo isset($services['DGDA'][$office]) ? $services['DGDA'][$office] : "-"; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">D&eacute;clarant</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo $prepayment->Declarant_8; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Référence SYDONIA</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo $prepayment->AccountRef_9; ?>
                           <input type="hidden" name="lot_id[]" value="<?php echo $prepayment->Lot_11 ?>">
                           <input type="hidden" name="id" value="<?= $prepayment->Id_0 ?>" />
                           <input type="hidden" name="object" value="prepayment" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Intitul&eacute; du compte</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <span id="accountname"></span>
                           <input type="hidden" value="" id="account_name" name="account_name"/>
                           <input type="hidden" name="branch_code" value="" id="branch_code">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Compte de pr&eacute;paiement</label>

                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= $prepayment->Account_15; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Devise du compte</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?= "CDF"; ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Montant total</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo $prepayment->Amout_12.' CDF '; ?>
                        </div>
                    </div> 
                </div>
                
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total commission</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($prepayment->Commission_13,2,","," ").' CDF';?>
                           <input name="commission_value" value="0" id="commission_value" type="hidden" disabled="disabled" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total TVA</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($prepayment->Commission_13 * 0.16,2,","," ").' CDF';?>
                           <input name="commission_value" value="0" id="commission_value" type="hidden" disabled="disabled" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total frais BCC</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($prepayment->Commission_13,2,","," ").' CDF';?>
                           <input name="commission_value" value="0" id="commission_value" type="hidden" disabled="disabled" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Total &agrave; payer</label>
                        </div>
                        <div class="col-md-8">
                           <b>:</b> <?php echo number_format($prepayment->Total_14,2,","," ").' CDF'; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-group col-md-12">
                        <div class="col-md-4">
                            <label for="office">Compte Guichet Unique</label>
                        </div>
                        <div class="col-md-8">
                          <b>:</b>  <?php echo $cguichet; ?>
                          <input name="account_value" value="<?= $cguichet; ?>" type="hidden" id="account_value" disabled="disabled" />
                          <input name="account_devise" value="CDF" type="hidden" id="account_devise" disabled="disabled" />
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <?php $j =0; $k = 0; foreach($prepayments as $row): ?>
        <input name="paimentid[]" type="hidden" value="<?php echo $row->Id_0; ?>">
        <?php 
            if($k % 10 == 0)
            { 
                   $j++; 
            }
            $k++;
        ?>
        <input type="hidden" value="<?= $row->Id_0 ?>" id="paiement_treated" name="paiement_treated[<?= $j ?>][]">
    <?php endforeach; ?>
    <input type="hidden" value="" id="Sydonia_49" name="Sydonia_49">
    <input type="hidden" value="" id="Sydonia_49_next" name="Sydonia_49_next">
    <input type="hidden" value="" id="index" name="index">
    <input type="hidden" value="0" id="iteration" name="iteration">
    <input type="hidden" value="<?= $prepayment->Lot_11 ?>" id="" name="lot">
    <input type="hidden" value="<?= $prepayment->Id_0 ?>" id="" name="batchid">
</div>
<br/><br/>
<div class="col-md-12 bTop">
    <div class="col-md-12">
    <br/><label>Liste des bulletins</label><br/>
    </div>
</div>
<div class="col-md-12">
    <div id="paiementslist">
        <div class="col-md-12" id="table_view">
            <?php if(!empty($prepayments)): ?>
            <table id="dataTable" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-gray">
                        <th></th>
                        <th width="50">Date</th>
                        <th>D&eacute;signation</th>
                        <th>B&eacute;n&eacute;ficiaire</th>
                        <th>Recette</th>
                        <th>Montant</th>
                        <th class="text-center">Message</th>
                        <th class="text-center">Statut</th>
                        <th width="30" class="text-center" >action</th>
                    </tr>
                </thead>
                <tbody>
                <?php

                #Block last Prepayments
                foreach($prepayments as $row){ 
                    $agence =  (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - ';
                    $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                    $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                ?>
                    <tr>
                        <td width="5"><b>#</b></span></td>
                        <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                        </td>
                        <td class="text-blue"><?php if(isset($row->Designation_21) && $row->Designation_21 !=" ") echo $row->Designation_21;  else echo "Bulletin de liquidation / ".$row->Nif_15; ?></td>
                        <input type="hidden" name="designation" value="<?php if(isset($row->Designation_21) && $row->Designation_21 !=" ") echo $row->Designation_21;  else echo $row->Nif_15; ?>" >
                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                        <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?></td>
                        <td class="text-blue">
                            <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                        </td>
                        <td class="text-center"><span class='text-yellow bold'>Bulletin en attente de validation</span></td>
                        <td class="text-center"><span id="corebanking_result<?php echo $row->Id_0; ?>" class="fa fa-fw text-gray fa-question f20"></span></td>
                        <td class="text-center">
                            <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                        </td>
                    </tr>
                <?php 

                } 
                ?>

                </tbody>    
            </table>
            <?php else:?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun paiement trouv&eacute;!<br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    </div>
</div>
<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="width: 75%; max-width: 1000px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title">D&eacute;tail des bulletins</h4>
            </div>
            <div class="modal-body" id="modal-pager"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
            </div>
        </div>
    </div>
</div>


<!-- Session script  -->    

<script type="text/javascript"  charset="utf-8">

    $('#table').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "pageSize": 50,
    });

    <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])): ?>
        $("#valider").prop("disabled", false);
        $("#repartition").prop("disabled", true);
    <?php else :  ?>
        $("#valider").prop("disabled", true);
        $("#repartition").prop("disabled", false);
    <?php endif; ?>

    
    // Initialize DataTables
    let table = $('#dataTable').DataTable();
    var last_value = false;
    
    $('#valider').click(function(){
    
        $('#action').val('valider');
    
    });
    $('#repartition').click(function(){

        $('#action').val('repartition');
    });
    
    $("#cancel").click(function(){
        location.reload(true);
    });
    
    get_accountname();
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        var data = $(this).serialize();

        var action = $('#action').val();

        if(action == 'repartition')
        {
                const paiementid = gatherPaiementid();
                
                repartition(0, data, paiementid);
        }
        else
        {
                <?php if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])) : ?>
                    cancel_reservation(data)
                <?php else: ?>   
                    debit_customer(data); 
                <?php endif; ?>
                
        }
    });
    
    function gatherPaiementid() {
        const paiementid = [];
        $('input[name="paimentid[]"]').each(function(index) {
            paiementid.push({
                id: $(this).val()
            });
        });
        return paiementid;
    }

    function cancel_reservation(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        
        var url = '<?php echo base_url($module.'/taxaccounts/data/cancel_reservation'); ?>';

        $("#valider").prop('disabled',true);
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result){

                $("#loader").html('');

                if(result.code =='E407')
                {
                    $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option d\'annulation de réservation n\'est pas paramétrée pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#repartition').prop("disabled",true);
                    $('#valider').prop("disabled",true);
                }
                else if(result.code =='200')
                {
                    debit_customer(data)
                }
                else if(result.code =='E411')
                {
                    $("#loader").html('<div class="alert aDanger text-white"> L\'extourne a &eacute;t&eacute; faite partiellement, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $("#loader").html('<div class="alert aDanger text-white"> L\'une de transactions ou toutes les transactions de cette extourne ne sont pas pass&eacute;es, veuillez allez dans le menu regularisation pour finaliser l&pos;opeacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }

            },
            error:function(error)
            {
                $("#loader").html('<div class="alert aWarning text-white">L\'extourne a pris beaucoup de temps, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function debit_customer(data)
    {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taxprepayments'); ?>/save/debit_client';
        $('#valider').prop("disabled",true);
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json',
                encode          : true,
                success: function(result){

                        $('#loader').html('')

                        if(result.code=="E407")
                        {
                            $('#loader').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#repartition').prop("disabled",false);
                            $('#valider').prop("disabled",true);
                        }
                        else if(result.code=="200" || result.code=="E200")
                        {
                            $('#loader').html('<div class="alert aSuccess text-white">Bravo! la validation du lot de pr&eacute;paiement extrait est faite avec succ&egrave;s, veuillez cliquer sur le bouton [repartition] pour émarger les prépaiements.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $('#repartition').prop("disabled",false);
                            $('#valider').prop("disabled",true);
                        }
                        else if(result.code === "E405")
                        {
                            $('#loader').html('<div class="alert aDanger text-white">Un problème est survenu lors du débit du comote client, veuillez refaire s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E162")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E463")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E411")
                        {
                            $('#loader').html('<div class="alert aWarning text-black" style="width:96%; position:absolute;display:block; z-index:10000"> L\'envoi des &eacute;critures au corebanking fait avec succ&egrave;s mais il n\'y a eu aucun retour de Finacle, veuillez v&eacute;rifier le d&eacute;bit du montant total de pr&eacute;paiment dans le compte de pr&eacute;paiement dans Finacle. Si la transaction est d&eacute;j&agrave; pass&eacute;e cliquez sur le bouton [Oui] puis cliquez sur le bouton [Valider en lot] sinon cliquez sur le bouton [Non] pour refaire la validation de l\'extraction.<button class="btn btn-primary btn-flat" type="button" id="delYes">Oui</button> <button class="btn btn-gray btn-flat" type="button" id="delNo">Non</button><br/><br/></div>');
                            $("#delYes").click(function(){
                                $('#valider').prop("disabled",false);
                                $('#loader').html('');
                            });
                            $("#delNo").click(function(){
                                $('#validerExtract').prop("disabled",false);
                                $('#loader').html('');
                            });
                        }
                        else if(result.code === "E3238")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "W0205")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E397")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "AD3")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "E9999")
                        {
                            $('#loader').html('<div class="alert aWarning text-black" style="width:96%; position:absolute;display:block; z-index:10000"> L\'envoi des &eacute;critures &agrave; Finacle fait avec succ&egrave;s mais il n\'y a eu aucun retour de Finacle, veuillez v&eacute;rifier le d&eacute;bit du montant total de pr&eacute;paiment dans le compte de pr&eacute;paiement dans Finacle. Si la transaction est d&eacute;j&agrave; pass&eacute;e cliquez sur le bouton [Oui] puis cliquez sur le bouton [Valider en lot] sinon cliquez sur le bouton [Non] pour refaire la validation de l\'extraction.<button class="btn btn-primary btn-flat" type="button" id="delYes">Oui</button> <button class="btn btn-gray btn-flat" type="button" id="delNo">Non</button><br/><br/></div>');
                            $("#delYes").click(function(){
                                $('#valider').prop("disabled",false);
                                $('#loader').html('');
                            });
                            $("#delNo").click(function(){
                                $('#validerExtract').prop("disabled",false);
                                $('#loader').html('');
                            });
                        }
                        else if(result.code === "ERR002")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "ERR003")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result.code === "P83")
                        {
                            $('#loader').html('<div class="alert aDanger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $('#loader').html('<div class="alert aWarning text-black" style="width:96%; position:absolute;display:block; z-index:10000"> L\'envoi des &eacute;critures &agrave; Finacle fait avec succ&egrave;s mais il n\'y a eu aucun retour de Finacle, veuillez v&eacute;rifier le d&eacute;bit du montant total de pr&eacute;paiment dans le compte de pr&eacute;paiement dans Finacle. Si la transaction est d&eacute;j&agrave; pass&eacute;e cliquez sur le bouton [Oui] puis cliquez sur le bouton [Valider en lot] sinon cliquez sur le bouton [Non] pour refaire la validation de l\'extraction.<button class="btn btn-primary btn-flat" type="button" id="delYes">Oui</button> <button class="btn btn-gray btn-flat" type="button" id="delNo">Non</button><br/><br/></div>');
                            $("#delYes").click(function(){
                                $('#valider').prop("disabled",false);
                                $('#loader').html('');
                            });
                            $("#delNo").click(function(){
                                $('#validerExtract').prop("disabled",false);
                                $('#loader').html('');
                            });
                        }

                },
                error:function(error){
                    $('#loaders').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse Finacle est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
    }
    
    function repartition(index, data, paiementid)
    {
        $("#loader").html('');
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        
        var url = '<?php echo base_url($module.'/taxprepayments'); ?>/save/validate';
        
        $('#valider').prop("disabled",true);
        $('#repartition').prop("disabled",true);
        
        if(paiementid[index] !== undefined)
        {
            $('#Sydonia_49').val(paiementid[index].id);
        }
		
		if (index === paiementid.length - 1) 
		{
			// On est sur le dernier élément
			last_value = true;
			$('#Sydonia_49_next').val(paiementid[index].id);
			$('#index').val(index);
		} 
		else 
		{
			$('#Sydonia_49_next').val(paiementid[index + 1].id);
			$('#index').val(index + 1);
		}
        
        if((index) % 10 === 0)
        {
            var iteration = $('#iteration').val();
            iteration = parseInt(iteration, 10);
            iteration = iteration + 1;

            $('#iteration').val(iteration);
        }
       
        if(paiementid[index+1] !== undefined)
        {
            $("#corebanking_result"+paiementid[index].id).html('<img align="middle" height="18px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $("#corebanking_result"+paiementid[index].id).removeClass('fa fa-fw text-gray fa-question f20');
        }
        
        var data = $('#mainform').serialize();
        
        setTimeout(function() {
            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                    
                    if(last_value)
                    {
                        result_treatment();
                    }
                    else
                    {
                        // Détruire l'ancienne instance de DataTable
                        if ($.fn.DataTable.isDataTable('#dataTable')) {
                            table.destroy();
                            $('#dataTable').empty(); // Nettoyer l'ancien contenu du tableau
                        }
                        $("#table_view").html(result);
                    }
                        
                    if(last_value==false)
                    {
                        repartition(index+1, data, paiementid);
                    }
                },
                error:function(error){
                    $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;, veuillez trouver ce paiement soit dans la liste des paiements non valid&eacute; soit dans le menu r&eacute;gularisation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }, 1000);
    }
    
    function result_treatment()
    {
        var data = $('#mainform').serialize();
        var url = '<?php echo base_url($module.'/taxprepayments/display/__result'); ?>';

        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data,
            dataType    : 'html', 
            encode      : true,
            success: function(result)
            {
                $("#loader1").html('');
                $('#list').html(result);
                $("#step-2").removeClass('bg-green-active');
                $("#step-2").addClass('bg-gray');
                $("#step-3").removeClass('bg-gray');
                $("#step-3").addClass('bg-green-active');

            },
            error:function(error)
            {
                $('#loader1').html('<div class="alert alert-warning">Une erreur est survenue lors du chargement de la page, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }  
        });
    }
    
    function get_accountname() {
  
        var chtml = $("#accountname").html();
        var compte = '<?php echo $prepayment->Account_15; ?>';
        var devise = 'CDF';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking!');
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion au corebanking');
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);

                            // Vérifier si branch_code existe avant de l'utiliser
                            if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                                $("#branch_code").val(reponse.branch_code);
                            }
                    }
                },
                error: function(error) {
                    $('#loader1').html('<div class="alert alert-warning">La récupération des informations du compte a pris beaucoup de temps, veuillez checker votre connexion, puis réessayez !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function viewPrepayment(id)
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
        '<?php endif; ?>'

        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get(url, function(data, status){
            $("#loader1").html('');

            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }
   
</script>
    



