<div id="loader"></div>
<?php echo form_open('', array('id' => 'mainform2', 'class' => '')); ?>
<?php $chtml->box_body_opening('', false); ?>
<div class="">
    <div class="col-md-12 p-0">
        <div class="row">
            <div class="container mt-5 mb-5">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa fa-check-circle fa-3x text-success mb-3"></i>
                        <h4 class="card-title">Opération réussie</h4>
                        <p class="card-text">La génération du fichier a été fait avec succès, veuillez cliquer sur le bouton [envoyer] pour envoyer le fichier d'intégration.</p>
                        <button type="button" id="send_file" class="btn btn-success">Envoyer le fichier</button>&nbsp;&nbsp;
                        <button type="button" id="download" class="btn btn-primary" disabled>Télécharger le fichier</button>&nbsp;&nbsp;
                        <input type="hidden" name="integrationid" value="<?= isset($integration->Id_0) ? $integration->Id_0 : '' ?>" >
                        <input type="hidden" name="path" value="<?= isset($integration->Path_12) ? $integration->Path_12 : '' ?>" >
                        <?php foreach($batch_reference as $row){ ?>
                            <input name="batch_reference[]" type="hidden" value="<?php echo $row; ?>">
                        <?php } ?>
                    </div>
                    <br/><br/><br/><br/>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 
<?php echo form_close(); ?>

<script type="text/javascript">
    
$("#send_file").click(function(){
    send_file();
});

$("#download").click(function(){
    var path = '<?= isset($integration->Path_12) ? $integration->Path_12 : '' ?>';
    
    if(path != '')
    {
        download_file(path);
    }
    else
    {
        $('#loader1').html('<div class="alert alert-warning">Echec du téléchargement du fichier, veuillez réessayer s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
});

function send_file()
{
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    
    var data = $("#mainform2").serialize();
    var url = '<?php echo base_url($module.'/taxprepayments'); ?>/data/send_file_integration';
    
    $("#send_file").prop('disabled', true);
    
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode          : true,
        success: function(result){

            $("#loader1").html(result.msg);
            
            if(result.code == '200')
            {
                $("#download").prop('disabled', false);
            }
        },
        error:function(error){
            $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'est pas envoyé, veuillez réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });
}
    
function download_file(buffer) {
    var link = document.createElement('a');
    link.href = '<?php echo base_url()?>' + buffer;
    link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}    
    
</script>