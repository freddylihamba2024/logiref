<div class="col-md-12">
    <?php if(!empty($prepayments)): ?>
        <div>
            <div id="list">
                <div class="box-body box-solid no-padding">
                    <div class="col-md-12 no-padding">
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <thead class='bg-gray'>
                                        <tr>
                                            <th width="5px">#</th>
                                            <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                            <th width="150px">Bureau</th>
                                            <th width="100px">Declarant</th>
                                            <th width="100px" class="center">Nombre des bulletins</th>
                                            <th width="150px" class="center">Montant total</th>
                                            <th width="10px"  style="text-align:left;"><i class="fa fa-edit f20"></i></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; foreach($prepayments as $customer => $payments): ?>
                                        <tr>
                                            <td class="align-middle" width=""><?php echo $i; ?></td>
                                            <td class="align-middle" width=""><?php echo $customer; ?></td>

                                            <?php 
                                            # Initialisation des variables pour stocker les données collectées
                                            $offices = '';
                                            $declarants = '';
                                            $totals = '';
                                            $amounts = '';
                                            $editLinks = '';

                                            foreach($payments as $payment):
                                                # Collecte des informations dans des variables HTML
                                                $offices .= '<li>' . $services['DGDA'][$payment->Office_8] . '</li>';
                                                $declarants .= '<li>' . $payment->Declarant_16 . '</li>';
                                                $totals .= '<li>' . $payment->total . '</li>';
                                                $amounts .= '<li>' . 'CDF ' . number_format($payment->amounts, 2, ",", " ") . '</li>';

                                            endforeach;
                                            ?>

                                            <td class="align-middle pl-3" width=""><ul><?php echo $offices; ?></ul></td>
                                            <td class="align-middle pl-3" width=""><ul><?php echo $declarants; ?></ul></td>
                                            <td class="align-middle pl-3" width=""><ul><?php echo $totals; ?></ul></td>
                                            <td class="align-middle pl-3" width=""><ul><?php echo $amounts; ?></ul></td>
                                            <td class="align-middle" width="">
                                                <a style="cursor: pointer" onclick="edit('<?php echo $customer; ?>', 'Customer', '<?php echo $payment->Office_8; ?>')"> 
                                                    <i class="fa fa-fw fa-edit text-blue f20"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                        <?php $i++; endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
            <?php if(!empty($processed) ): ?>
                 <section>
                    <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 10vh; padding-top: 5%;">
                        <i class="fa fa-fw fa-thumbs-up text-green mystyle4"></i><br/>
                        <h5 align="center"><b>Tous les pr&eacute;paiments extraits ont &eacute;t&eacute; trait&eacute;s!</b></h5>
                        <br/>
                    </div>
                </section>
            <?php else: ?> 
                <section id="cat_list" class="text-center ">
                    <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun pr&eacute;paiement n&apos;a &eacute;t&eacute; extrait aujourd&apos;hui !</b></span>        
                </section>
            <?php endif; ?>
    <?php endif;?>
</div>
