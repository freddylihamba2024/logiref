<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper" style="min-height: 100vh">
    <!--- Le loader est chargé ici --->
    <div class="w-100 d-flex justify-content-center align-items-center mt-3"></div>

    <!--- Le congenu en Ajax seront charché ici par defaut ---->
    <div class="container-fluid" id="container" style="margin-top: 30px">
    </div>
</div>