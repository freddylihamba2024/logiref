<?php #$chtml->right_side_content_opening()?>
       <div class="row" id="container">
               <div class="col-md-3"> </div>

                <div class="col-md-6">
                    <div class="col-md-12" style="padding-top: 30%;">
                        <div class="col-md-12 padding-20 text-center">

                              <h4>Sorry! Access denied!</h4>
                              <span><i class="fa fa-fw fa-ban f100 text-red"></i> <br/><br/></span>
                              <span class='text-gray'>Please contact the administrator of your iKwook account to grant you access to this section</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3"> </div>
        </div>
<?php #$chtml->right_side_content_closing()?>