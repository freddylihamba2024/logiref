<?php
    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $validated = 0;
    $suspend = 0;
    $regulate = 0;
    $i = 0;
?>
<div id="pager" class="col-md-12">
    <div class="col-md-12">
        <div class="col-md-12">
            <h2 class="text-blue f30">Les paiements DGRK et DGPEK</h2>
            <p class="page-header" class="f12 text-black"><span class="f12 text-black">Cette section présente les rapports des paiements DGRK et DGPEK effectués en agence.</span></p>
        </div>
    </div>

    <br/>

    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
            <div class="statistic-box no-border no-padding">
                <div class="col-sm-12 mt-2">
                    <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Référence</b></span><?php echo form_input('Noteid_26', set_value('Noteid_26', ''), ' id="noteid" class="form-control"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 border-left">
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Status </b></span><?php echo form_dropdown('Status_2', $status, '', ' id="" class="form-control" style="height:auto;"'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">Initi&eacute;e entre le</span>
                                    <input class="form-control" name="start" value="" id="datepicker1" type="text">
                                    <span class="input-group-addon">et le</span>
                                    <input class="form-control" name="end" value=""  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-bitbucket bg-blue-active pull-right"> <i class="fa fa-fw fa-search text-gray"></i></button>&nbsp;&nbsp;&nbsp;
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        <?php $chtml->box_body_closing(); ?>

        <div id="loader1" class="col-md-12"></div>

        <?php $chtml->box_body_opening('', true); ?>
            <div class="col-md-12 no-padding" id="filterResult">
                <?php if (!empty($encaissements)): ?>
                    <table id="table_pagence" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray f12">
                                <th>#</th>
                                <th>Date</th>
                                <th width="">Status</th>
                                <th width="10">R&eacute;gie</th>
                                <th>Recette</th>
                                <th>Client</th>
                                <th width="">Note</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th>Agences</th>
                                <th>Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $paiements = 0;
                            $commissions = 0;
                            $suspend = 0;
                            $urgent = 0;
                            $i=0;

                            foreach ($encaissements as $row):
                                $infos = json_decode($row->Notereference_30);
                                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                            ?>
                                <tr>
                                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                    <td><?php echo $row->Datevaleur_31 ?></td>
                                    <td width="10%"><span class="badge <?php echo $colors[$row->Status_2]; ?>"><?php echo $status[$row->Status_2];?></span></td>
                                    <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                                    <td><b><?php echo $row->Typerecette_17; ?></b></td>
                                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                    <td><b><?php echo strtoupper($row->Noteid_26); ?></b></td>
                                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>
                                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                    <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                    <?php if($row->Checkerid_10==0): ?>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')): ?>
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                            <?php else : ?>
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                            <?php endif; ?>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                        </td>
                                    <?php else: ?>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php
                                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                    $suspend = $suspend + 1;
                                if (($row->Status_2 == 2 OR $row->Status_2 == 3) && $row->Checkerid_10 > 0)
                                    $validated = $validated + 1;
                                if ($row->Status_2 >= 4)
                                    $regulate = $regulate + 1;
                            endforeach;
                            ?>

                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="col-md-12">
                        <section id="cat_list" class="text-center pt-5 pb-5">
                            <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
                            <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
                        </section>
                    </div>
                <?php endif; ?>
            </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
</div>

<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">

    get_payments();
    $("#CloseModal").click(function(){
        get_payments();
    });

    function get_payments()
    {
        $("#loader1").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/taxreports/display/passport_agence'); ?>/", function(data, status){
                $("#loader1").html('');
                $("#panel").html(data);
        });
    }

    $('#paiements').html('<?php echo number_format(count($encaissements) ,0,","," "); ?>');
    $('#paiements').addClass('text-blue');
    $('#validated').html('<?php echo number_format($validated,0,","," "); ?>');
    $('#validated').addClass('text-green');
    $('#attente').html('<?php echo number_format($suspend,0,","," "); ?>');
    $('#attente').addClass('text-yellow');
    $('#regulate').html('<?php echo number_format($regulate,0,","," "); ?>');
    $('#regulate').addClass('text-red');

    $('#table_pagence').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50,
    });

    $('#noteid').on('input', function() {
        var currentText = $(this).val();
        var upperText = currentText.toUpperCase();
        $(this).val(upperText);
    });

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $("#searchform").submit(function(e){
        e.preventDefault();

        $("#loader1").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

        var url = '<?php echo base_url($module.'/taxreports/display/filter_passport_agence'); ?>';
        var data = $(this).serialize();

        $.ajax({
            type        : 'POST',
            url         : url,
            data        : data,
            dataType    : 'html',
            encode          : true,
            success: function(result){
                $('#loader').html('');
                $('#filterResult').html(result);
            },
            error:function(error){
                alert('ERROR!' + error);
            }
        });
    });

    function view(id, regie)
    {
        var url ='';
        var controller = 'reports';
        var from = '<?php echo $display; ?>';

       if(regie === 'DGPEK')
        {
            '<?php if($_SESSION['Logiref_role'] !=4): ?>'
                var url ="<?php echo base_url($module.'/taxdgpek/display/preview'); ?>/"  + id;
            '<?php else :?>'
                var url ="<?php echo base_url($module.'/taxdgpek/display/edit'); ?>/"  + id;
            '<?php endif; ?>'

        }
        else if(regie === 'DGRK')
        {
            '<?php if($_SESSION['Logiref_role'] !=4): ?>'
                var url ="<?php echo base_url($module.'/taxdgrk/display/preview'); ?>/"  + id;
            '<?php else :?>'
                var url ="<?php echo base_url($module.'/taxdgrk/display/edit'); ?>/"  + id;
            '<?php endif; ?>'

        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        $.get(url, function(data, status){
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('d-none');
            $("#form").removeClass('d-none');
        });

        $("#loader1").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        $.get(url,{ controller : controller, from : from}, function(data, status){
            $("#loader1").html('');
            $("#pager").html(data);
        });
    }

    function print_payment(pid) {

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
    }

</script>