<?php //var_dump($members);die;?>
<div class="row">
    <div class="col-md-12 p-3">
        <div id="loader"></div>
            <?php if(!empty($members)): ?>
            <div class="ibox bg-white">
                    <div class="ibox-title border-bottom">
                        <h2 class="text-blue">Liste des utilisateurs</h2>
                    </div>
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                            <div class="row">
                                <div class="col-md-9 no-padding small-box">
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('agence', $guichets, '', ' id="" class="form-control" '); ?>
                                        </div>
                                </div><br>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-bitbucket ml-4 pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>
                                    <button type="button" class="btn btn-success ml-1 pull-right text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>
                                    <button type="button" class="btn btn-bitbucket pull-right text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                    <div class="col-lg-12 table-responsive" id="filterResult">
                            <input type="hidden" id="nbre" value="<?= count($_SESSION["members"]) ?>"/>
                            <table class="table table-striped bg-white" id="table">
                                    <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">
                                        <th>#</th>
                                        <th>Nom complet</th>
                                        <th width="150px">Role</th>
                                        <th>Agence</th>
                                        <th width="100px">Statut</th>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $i =0;
                                        foreach($members as $row){
                                        ?>
                                          <?php if(isset($users[$row->Userid_13])):?>
                                          <tr>
                                              <td width="5"><?php echo ++$i; ?></td>
                                              <td width="250"><b><?php if(isset($users[$row->Userid_13])) echo $users[$row->Userid_13]; ?></b></td>
                                              <td class="bleu"><?php echo $roles[$row->Role_4];?></td>
                                              <td width="150"><?php if(isset($agences[$row->Agence_7])) echo $agences[$row->Agence_7];?></td>
                                              <td>
                                                  <span class="badge <?php echo $statutColor[$row->Status_2]?>">
                                                      <?php echo $statut[$row->Status_2]; ?>
                                                  </span>
                                              </td>
                                          </tr>
                                          <?php endif;?>
                                        <?php } ?>
                                    </tbody>
                                    <input type="hidden" name = "members" value='<?php echo(!empty($members))? json_encode($members): '';?>'>

                            </table>
                    </div>
            <?php else: ?> 
                <section id="cat_list" class="text-center marginTop150">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
                </section>
            <?php endif; ?>
            </div>

    </div>
</div>


<script type="text/javascript">
    $('#table').DataTable({
        pageLength: 10,
        responsive: true,
        "bLengthChange": false,
        "bFilter": false,
        paging: true,
        searching: false
    });
    
    users();


    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/user_filter'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }

            });
    });



    $("#print").click(function(){

            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/taximpression/display/print_users'); ?>';
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            print(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });
    });

    function users()
    {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>"/>');
            var url = '<?php echo base_url($module.'/taxreports/display/user_filter'); ?>';
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#page").html(data);
            });
    }

    function print(buffer)
    {
            window.open('<?php echo base_url()?>'+buffer);
    }
    
    $("#export").click(function(){
        var nbre = $("#nbre").val();
        if(nbre > 0){
            $("#error").addClass('d-none');
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taximpression/display/export_users'); ?>';
            window.open(url);
            $("#loader").empty();
        }
        else{
            $("#error").removeClass('d-none').show();
        }
    });

</script>