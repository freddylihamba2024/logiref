<input type="hidden" id="nbre" value="<?= count($_SESSION["bulletins"]) ?>"/>
<?php if(!empty($bulletins)): ?>
    <div class="table-responsive">
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-aqua text-white">
                    <th width="10px">#</th>
                    <th width="150">Date</th>
                    <th width="50px">Ann&eacute;e</th>
                    <th >Num&eacute;ro BL</th>
                    <th >Bureau</th>
                    <th >Agence</th>
                    <th >Montant</th>
                    <th width="">Num&eacute;ro imp&ocirc;t</th>
                    <th >Cr&eacute;&eacute; par</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $i = 0;
                    foreach($bulletins as $row){
                ?>
                    <tr>
                        <td><?php echo ++$i; ?></td>
                        <td><?php echo $row->Date_1; ?></td>
                        <td><?php echo $row->Year_5; ?></td>
                        <td><?php echo $row->Serie_7."".$row->Number_8 ?></td>
                        <td><?php echo $row->Office_6 ?></td>
                        <td><?php echo isset($agences[$row->Agence_32]) ? $agences[$row->Agence_32] : "-"; ?></td>
                        <td><?php echo 'CDF '.number_format($row->Amount_12,2,","," "); ?></td>
                        <td><?php echo $row->Nif_9; ?></td>
                        <td><?php echo isset($users[$row->User_15]) ? $users[$row->User_15] : "-"; ?></td>
                    </tr>
                <?php 
                    } 
                ?>
            </tbody>    
        </table>
        <input type="hidden" name = "bulletins" value='<?php echo(!empty($bulletins))? json_encode($bulletins): '';?>'>
    </div>
<?php else: ?>
    <section class="m-5">
        <h4 align="center">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <b>Aucun rapport trouv&eacute; !</b>
        </h4>
    </section>
<?php endif; ?>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">

    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });
    
    $('#table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            paging: true,
            searching: false
        });
</script>

