<!--<div class="row">-->
    <div class="col-md-12 p-0">
        <div id="loader"></div>
            <?php if(!empty($comptes)): ?>
            <div class="ibox bg-white">
                    <div class="ibox-title border-bottom">
<!--                        <h2 class="text-blue">Listes des comptes</h2>-->
                    </div>
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                        <div class="row">
                            <div class="col-md-3 no-padding small-box">
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('agence', $agences, '', 'class="form-control" id="agence" '); ?>
                                </div>
                            </div><br>
                            <div class="col-md-3 no-padding  small-box">
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Types</b></span><?php echo form_dropdown('type', $types, '', 'class="form-control" id="type" '); ?>
                                </div>
                            </div><br>
                            <div class="col-md-3 no-padding  small-box">
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Taxe</b></span><?php echo form_dropdown('taxe', $recettes, '', 'class="form-control" id="taxe" '); ?>
                                </div>
                            </div><br>
                            <div class="col-md-1">
<!--                                <button type="button" class="btn btn-bitbucket text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>-->
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>

                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn btn-success text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>

                            </div>
                                   
                        </div> 
                        
                    </div>
                    <div class="col-lg-12 table-responsive" id="filterResult">
                    <input type="hidden" name="comptes" value='<?php echo(!empty($comptes))? json_encode($comptes): '';?>'>

                            <table class="table table-hover table-striped" id="table">
                                    <thead class="bg-gray f12">
                                        <th>#</th>
                                        <th>Agence</th>
                                        <th width="50">Type</th>
                                        <th width="50">Devise</th>
                                        <th width="150">Compte</th>
                                        <th width="50">B&eacute;n&eacute;ficiaire</th>
                                        <th with="">Recette</th>
                                        <th>Maker</th>
                                        <th>Checker</th>
                                        <th width="100">Validation</th>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; foreach($comptes as $row){ ?>
                                        <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                            <td><?php if(isset($guichets[$row->Agence_12])) echo $guichets[$row->Agence_12];?></td>
                                        <td width="50"><?php echo ' '.$row->Type_4;?></td>
                                        <td class="bleu" width="50"><?php echo $row->Devise_8;?></td>
                                        <td width="150"><?php if($row->Type_4!='CAC' || $row->Type_4!='CPI') echo '<b>'.$row->Agenceid_15.'</b>'; else echo '<span class="text-red">'.$row->Agenceid_15.'</span>'; ?><?php if($row->Compte_6!='') echo '-'.$row->Compte_6;?><?php if($row->Clef_7!='') echo '-'.$row->Clef_7;?></span></td>
                                        <td width="50"><?php echo ' '.$row->Beneficiaires_5;?></td>
                                        <td width="50"><?php echo ' '.$row->Recette_13;?></td>
                                        <td>
                                            <?php echo(isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';?></td>
                                        <td>
                                            <?php if($row->Checkerid_11==0){ ?>
                                              <span class="text-red"> - </span>
                                            <?php }else {?>
                                             <?php echo(isset($users[$row->Checkerid_11]))?$users[$row->Checkerid_11]:' - ';?>
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <?php if($row->Checkerid_11==0){ ?>
                                              <span class="text-red"> En attente </span>
                                            <?php }else {?>
                                              <?php echo $row->Validation_10;?>
                                            <?php } ?>
                                        </td>
                                        </tr>
                                       <?php $i++; } ?>
                                    </tbody>
                            </table>
                    </div>
            <?php else: ?> 
                <section id="cat_list" class="text-center marginTop150">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
                </section>
            <?php endif; ?>
            </div> 
    </div>
<!--</div>-->


    <script type="text/javascript">

        $('#table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            paging: true,
            searching: false
        });

        $("#mainform").submit(function(e)
        {
                e.preventDefault();
                $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                var data = $(this).serialize();
                var url = '<?php echo base_url($module.'/taxreports/display/account_filter'); ?>'; 
                $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : data, 
                            dataType    : 'html', 
                            encode      : true,
                            success: function(result){
                                $('#loader').html('');
                                $('#page').html(result);
                            },
                            error:function(error){
                                alert('ERROR:'+error);
                            }

                });
        });

        $("#print").click(function(){

                var data = $("#mainform").serialize();
                var url = '<?php echo base_url($module.'/taximpression/display/print_comptes'); ?>';
                $.ajax({
                            type        : 'POST', 
                            url         : url, 
                            data        : data, 
                            dataType    : 'html', 
                            encode      : true,
                            success: function(result){

                                print(result);

                            },
                            error:function(error){
                                alert('ERROR:'+error);
                            }
                });

        });

       
$("#export").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taximpression'); ?>/display/export_comptes';

         $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
         $.get(url, function(data, status){
            $("#loader").html('');
            print(data);

        });
});
    
function print(buffer) 
{
    var link = document.createElement('a');
    link.href = '<?php echo base_url()?>' + buffer;
    link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
    </script>


