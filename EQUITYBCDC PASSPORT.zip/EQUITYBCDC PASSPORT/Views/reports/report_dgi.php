
<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] != 4): ?>

<div class="row">
    <div class="col-md-12">
        <div id="message"></div><br/>
    </div>
</div>
<div class="row" style="margin-top: -25px;">
    <div class="col-md-12">
        <div class="ibox bg-white">
            <div class="ibox-title border-bottom">
                <h2 class="text-blue m-2">DGI...</h2>
            </div>
            <!-- FORMULAIRE -->
            <div class="col-md-12">
            <div class="col-md-12">
                <?= form_open('', ['id' => 'searchform', 'class' => 'margin']); ?>
                <div class="row pr-0 pl-0">
                    <div class="col-md-3">
                        <label><b>Recette</b></label>
                        <select name="Typerecette_17" class="form-control">

                            <option value="" selected disabled>-- Sélectionner --</option>

                            <?php foreach ($recettes as $group => $options): ?>

                                <optgroup label="<?= $group; ?>">

                                    <?php foreach ($options as $key => $value): ?>

                                        <option value="<?= $key; ?>">
                                            <?= $value; ?>
                                        </option>

                                    <?php endforeach; ?>

                                </optgroup>

                            <?php endforeach; ?>

                        </select>
                    </div>
                    <div class="col-md-2">
                        <label><b>Utilisateur</b></label>
                        <?= form_dropdown('user', $users, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-2">
                        <label><b>Agence</b></label>
                        <?= form_dropdown('guichet', $guichets, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-3">
                        <label><b>Période</b></label>
                        <div class="input-daterange input-group">
                            <span class="input-group-addon">De</span>
                            <input class="form-control" name="start" type="text" id="datepicker1" >
                            <span class="input-group-addon">à</span>
                            <input class="form-control" name="end" type="text" id="datepicker2">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" id="search" class="btn text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>
                            <!-- <button class="btn btn-primary">Extraire</button> -->
                            <button id="export" class="btn btn-success" <?= (empty($encaissements) || empty($encaissements_from_reporting) ? "disabled": "")?>>Exporter</button>
                        </div>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>

            <!-- TABLE -->
            <div class="col-md-12" id="filterResult">
                <?php if (!empty($encaissements) || !empty($encaissements_from_reporting) || !empty($encaissements_immatriculation)): ?>
                    <div class="col-lg-12 table-responsive">
                        <table class="table table-hover table-striped" id="table">
                            <thead class="bg-gray f12">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Recette</th>
                                    <th>Service</th>
                                    <th>Client</th>
                                    <th>Montant</th>
                                    <th>Agences</th>
                                    <th>Saisi</th>
                                    <th>Validé</th>
                                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0; ?>

                                <!-- ENCAISSEMENTS -->
                                <?php foreach ($encaissements as $row): ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                                        <td><b><?= $i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                            <?= htmlspecialchars($row->Date_1) ?>
                                        </td>
                                        <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                                        <td><?= htmlspecialchars($row->Service_16) ?></td>
                                        <td class="text-blue">
                                            <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA")
                                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13)
                                                : htmlspecialchars($row->Designation_14) ?>
                                        </td>
                                        <td class="text-blue">
                                            <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                                        </td>
                                        <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                                        <td>
                                            <?php if ($row->Checkerid_10 == 0): ?>
                                                <span class="text-red">En attente</span>
                                            <?php else: ?>
                                                <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a onclick="view('<?= $row->Id_0 ?>', '<?= $row->Beneficaire_15 ?>')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                                <!-- ENCAISSEMENTS FROM REPORTING -->
                                <?php foreach ($encaissements_from_reporting as $row): ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                                        <td><b><?= $i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                            <?= htmlspecialchars($row->Date_1) ?>
                                        </td>
                                        <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                                        <td><?= htmlspecialchars($row->Service_16) ?></td>
                                        <td class="text-blue">
                                            <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA")
                                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13)
                                                : htmlspecialchars($row->Designation_14) ?>
                                        </td>
                                        <td class="text-blue">
                                            <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                                        </td>
                                        <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                                        <td>
                                            <?php if ($row->Checkerid_10 == 0): ?>
                                                <span class="text-red">En attente</span>
                                            <?php else: ?>
                                                <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a onclick="view('<?= $row->Id_0 ?>', '<?= $row->Beneficaire_15 ?>')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                                <!-- ENCAISSEMENTS IMMATRICULATION -->
                                <?php foreach ($encaissements_immatriculation as $row): ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                                        <td><b><?= $i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                            <?= htmlspecialchars($row->Date_1) ?>
                                        </td>
                                        <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                                        <td><?= htmlspecialchars($row->Service_16) ?></td>
                                        <td class="text-blue">
                                            <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA")
                                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13)
                                                : htmlspecialchars($row->Designation_14) ?>
                                        </td>
                                        <td class="text-blue">
                                            <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                                        </td>
                                        <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                                        <td>
                                            <?php if ($row->Checkerid_10 == 0): ?>
                                                <span class="text-red">En attente</span>
                                            <?php else: ?>
                                                <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a onclick="view('<?= $row->Immatriculation_57 ?>', 'DGI_IMMATRICULATION')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="col-lg-12 table-responsive mt-5 mb-5">
                        <section class="text-center mt-5">
                            <span class="fa fa-flask text-gray mystyle4"></span><br>
                            <b>Aucun enregistrement trouvé !</b>
                        </section>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    //Datepicker
    $('#datepicker1').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": false,
        "info": false,
        "autoWidth": false,
        "pageSize": 50
    });

    $("#searchform").submit(function(e){

        e.preventDefault();
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxreports/display/filterresult/tresor'); ?>';
        var data = $(this).serialize();
        scrollUP()
        $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){
                            $('#message').html('');
                            $("#export").removeAttr("disabled");
                            $('#filterResult').html(result);
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    });

    function view(id, regie)
    {
            var url ='';
            var controller = 'taxreports';
            var from = '<?php echo $display; ?>';

            if(regie === 'DGI')
            {
                 var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
            }

            if(regie === 'DGI_IMMATRICULATION')
            {
                 var url ="<?php echo base_url($module.'/taximmatriculation/display/preview'); ?>/"  + id  ;
            }
            else if(regie === 'DGRAD')
            {
                 var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
            }

            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
             $.get(url,{ controller : controller, from : from}, function(data, status){
                $("#message").html('');
                $("#container").html(data);
            });
    }

    $("#export").click(function (e) {
        e.preventDefault();

        $("#message").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let url  = "<?= base_url($module . '/taximpression/display/export_report_dgi'); ?>";
        let data = $("#searchform").serialize();
        scrollUP()
        $.ajax({
            url: url,
            type: "POST",
            data: data,
            xhrFields: {
                responseType: 'blob'
            },
            success: function (blob, status, xhr) {

                $("#message").html('');

                // Récupération du nom du fichier depuis le header
                let disposition = xhr.getResponseHeader('Content-Disposition');
                let filename = "report_paiement_dgi.xlsx";

                if (disposition && disposition.indexOf('filename=') !== -1) {
                    filename = disposition
                        .split('filename=')[1]
                        .replace(/"/g, '');
                }

                // Téléchargement forcé
                let url = window.URL.createObjectURL(blob);
                let a = document.createElement('a');

                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();

                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            },
            error: function () {
                $("#message").html('');
                alert("Erreur lors de l’export");
            }
        });
    });

    function print(buffer)
    {
        var link = document.createElement('a');
        link.href = '<?php echo base_url()?>' + buffer;
        link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#message").offset().top
        }, 20);
    }

</script>