    <input type="hidden" id="nbre" value="<?= count($_SESSION["members"]) ?>"/>
    <?php if(!empty($members)): ?>
        <div class="table-responsive">
            <table id="table" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-aqua text-white">
                        <th>#</th>
                        <th>Nom complet</th>
                        <th width="150px">Role</th>
                        <th>Agence</th>
                        <th width="100px">Statut</th>
                    </tr>
                </thead>
                <tbody>
                  <?php 
                  $i =0;
                  foreach($members as $row){
                  ?>
                    <?php if(isset($users[$row->Userid_13])):?>
                    <tr>
                        <td width="5"><?php echo ++$i; ?></td>
                        <td width="250"><b><?php if(isset($users[$row->Userid_13])) echo $users[$row->Userid_13]; ?></b></td>
                        <td class="bleu"><?php echo $roles[$row->Role_4];?></td>
                        <td width="150"><?php if(isset($agences[$row->Agence_7])) echo $agences[$row->Agence_7];?></td>
                        <td>
                            <span class="badge <?php echo $statutColor[$row->Status_2]?>">
                                <?php echo $statut[$row->Status_2]; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endif;?>
                  <?php } ?>
                </tbody> 
                <input type="hidden" name = "members" value='<?php echo(!empty($members))? json_encode($members): '';?>'>
            </table>
        </div>
    <?php else: ?>
        <section class="m-5">
            <h4 align="center">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <b>Aucun utilisateur trouv&eacute; !</b>
            </h4>
        </section>
    <?php endif; ?>

    <script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
    
    <script type="text/javascript">   
        $('#datepicker1').datepicker({
                format: 'yyyy-mm-dd'
        });

        $('#datepicker2').datepicker({
                format: 'yyyy-mm-dd'
        });

        $('#table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            paging: true,
            searching: false
        });
    </script>