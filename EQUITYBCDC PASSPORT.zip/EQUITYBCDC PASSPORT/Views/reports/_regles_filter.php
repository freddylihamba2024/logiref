    <!--<input type="hidden" name = "regles" value='<?php echo(!empty($regles))? json_encode($regles): '';?>'>-->
    <?php if(!empty($regles)): ?>
    <div class="table-responsive">
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-aqua text-white">
                    <th>#</th>
                    <th>Priorit&eacute;</th>
                    <th>B&eacute;n&eacute;ficiaire</th>
                    <th>Indice</th>
                    <th>Service</th>
                    <th>Recette</th>
                    <th>Guichet</th>
                    <th>Min</th>
                    <th>Max</th>
                    <th>Validation</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($regles as $row){ ?>
                <tr>
                    <td width="5"><?php echo $row->Id_0; ?></td>
                    <td class="<?php if($row->Priorite_4 == 1){ echo 'bg-gray';}elseif($row->Priorite_4 == 2){echo 'bg-green';}elseif($row->Priorite_4 == 3){echo 'bg-blue';}elseif($row->Priorite_4 == 4){echo 'bg-orange';}elseif($row->Priorite_4 == 5){echo 'bg-yellow';}elseif($row->Priorite_4 == 6){echo 'bg-red';} ?> " align="center"><b>P<?php echo $row->Priorite_4; ?></b></td>
                    <td><?php if($row->Beneficiaire_5=='' or $row->Beneficiaire_5=='0') echo 'TOUS'; else echo ' '.$row->Beneficiaire_5;?></td>
                    <td class="bleu"><b><?php echo $row->Value_9.' '.$row->Unite_10;?></b></td>
                    <td><?php if($row->Service_6=='') echo 'TOUS'; else echo ' '.$services[$row->Beneficiaire_5][$row->Service_6];?></td>
                    <td><?php if($row->Recette_7=='') echo 'TOUTES'; else echo ' '.$row->Recette_7;?></td>
                    <td><?php if($row->Guichet_8=='') echo 'TOUS'; else echo ' '.$guichets[$row->Guichet_8];?></td>
                    <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Min_11,2,","," ");?></td>
                    <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Max_12,2,","," ");?></td>
                    <td>
                        <?php if($row->Checkerid_15==0){ ?>
                          <span class="text-red"> En attente </span>
                        <?php }else {?>
                          <?php echo $row->Validation_16;?>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            </tbody>    
        </table>
    </div>
    <?php else: ?>
        <section class="m-5">
            <h4 align="center">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <b>Aucune r&egrave;gle n'est enregistr&eacute;e !</b>
            </h4>
        </section>
    <?php endif;?>

    <script type="text/javascript">
       $('#table').DataTable({
                pageLength: 10,
                responsive: true,
                "bLengthChange": false,
                "bFilter": false,
                paging: true,
                searching: false
            }); 
    </script>