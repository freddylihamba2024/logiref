<?php 
$total = 0; 
$infos = $encaissementBl->Notereference_30;
$mode = $encaissementBl->Mode_19; 
$CFBdevise = $encaissementBl->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissementBl->Devise_34;
$cCompte = $encaissementBl->CGU;
$taux = $encaissementBl->Taux_41;
$commission = $encaissementBl->Commission_23;
$montant = number_format($encaissementBl->Montant_11,2,","," ");


?>

<?php $userid = $this->session->userdata["user_id"];  $Infos = $encaissementBl->Notereference_30; $idBL = $Infos['Paiementid'];?>
<?php if(isset($encaissementBl->Id_0) && $encaissementBl->Id_0!='' && $encaissementBl->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissementBl->Montant_11 > 0) $encaissementBl->Montant_11 = number_format($encaissementBl->Montant_11,2,","," "); ?>
<?php if($encaissementBl->Notemontant_28 > 0) $encaissementBl->Notemontant_28 = number_format($encaissementBl->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissementBl->Makerid_9==$userid && $encaissementBl->Status_2==1 && $encaissementBl->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissementBl->Notereference_30) && $encaissementBl->Notereference_30 !="")$infos= $encaissementBl->Notereference_30;?>
<?php

if($encaissementBl->Id_0!=NULL) 
{
        if($encaissementBl->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissementBl->Commission_23;
                $devise01 = $encaissementBl->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissementBl->Compte_33;
                $devise01 = $encaissementBl->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="message"></div>
    <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissementBl->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissementBl->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissementBl->Logirefid_4; ?>" />
                
                <input type="hidden" name="Makerid_9" value="<?php echo $encaissementBl->Makerid_9 ; ?>" />
                <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                <input type="hidden" name="Montant_11" value="<?php echo $encaissementBl->Montant_11 ; ?>" />
                <input type="hidden" name="Devise_12" value="<?php echo $encaissementBl->Devise_12; ?>" />
                <input type="hidden" name="Nif_13" value="<?php echo $encaissementBl->Nif_13 ; ?>" />
                <input type="hidden" name="Designation_14" value="<?php echo $encaissementBl->Designation_14; ?>" />
                <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissementBl->Beneficaire_15; ?>"  id="regies" />
                <input type="hidden" name="Service_16" value="<?php echo $encaissementBl->Service_16; ?>"  id="service" />
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissementBl->Typerecette_17;?>"   id="recette" />
                <input type="hidden" name="Mode_19" value="<?php echo $encaissementBl->Mode_19; ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissementBl->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissementBl->Guichet_21; ?>" id="guichetId" />
                <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissementBl->Contrevaleur_22 ; ?>" />
                <input type="hidden" name="Commission_23" value="<?php echo $encaissementBl->Commission_23; ?>" />
                <input type="hidden" name="Devise_24" value="<?php echo $encaissementBl->Devise_24; ?>" />
                <input type="hidden" name="Notetype_25" value="<?php echo $encaissementBl->Notetype_25 ; ?>" />
                <input type="hidden" name="Noteid_26" value="<?php echo $encaissementBl->Noteid_26; ?>" />
                <input type="hidden" name="Notedate_27" value="<?php echo $encaissementBl->Notedate_27 ; ?>" />
                <input type="hidden" name="Notemontant_28" value="<?php echo $encaissementBl->Notemontant_28 ; ?>" />
                <input type="hidden" name="Notedevise_29" value="<?php echo $encaissementBl->Notedevise_29; ?>" />
                
                <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissementBl->Notereference_30); ?>" />
                <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissementBl->Datevaleur_31; ?>" />
                <input type="hidden" name="Reference_32" value="<?php echo $encaissementBl->Reference_32 ; ?>" />
                <input type="hidden" name="Compte_33" value="<?php echo $encaissementBl->Compte_33 ; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissementBl->Devise_34 ; ?>" />
                
                <input type="hidden" name="Taux_41" value="<?php echo $encaissementBl->Taux_41; ?>" />
                <input type="hidden" name="Sydonia_44" value="<?php echo $encaissementBl->Sydonia_44; ?>" />
                <input type="hidden" name="Tresor_45" value="<?php echo $encaissementBl->Tresor_45; ?>" />
                
                <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                
                <div class="col-md-12 no-padding">
                    <div class="col-md-12">
                        <br/><br/>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Bureau</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $services['DGDA'][$encaissementBl->Service_16]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;clarant</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Agent_10; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;signation</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissementBl->Designation_14.' / '.$encaissementBl->Nif_13; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Mode de paiement</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php  echo $modes[$encaissementBl->Mode_19]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Intitul&eacute; du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Num&eacute;ro du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Serie_7.' '.$bulletin->Number_8; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Ann&eacute;e du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Year_5; ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total(BL)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissementBl->Montant_11.' CDF '; ?>
                               <input name="amount_value" value="<?= $encaissementBl->Montant_11; ?>" id="amount_value" type="hidden" disabled="disabled" />
                            </div>
                        </div> 
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Commission</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissementBl->Commission_23,2,","," ").' '.$encaissementBl->Devise_24;?>
                               <input name="commission_value" value="<?= $encaissementBl->Commission_23; ?>" id="commission_value" type="hidden" disabled="disabled" />
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissementBl->Total,2,","," ").' CDF'; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte client(&agrave; d&eacute;biter)</label>
                                
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?=isset($encaissementBl->Compte_33 ) ? $encaissementBl->Compte_33 : ""; ?>
                               <input name="account_value" value="<?= $encaissementBl->Compte_33; ?>" type="hidden" id="account_value" disabled="disabled" />
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Devise du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?= isset($encaissementBl->Devise_34 ) ? $encaissementBl->Devise_34 : ""; ?>
                               <input name="account_devise" value="<?= $encaissementBl->Devise_34; ?>" type="hidden" id="account_devise" disabled="disabled" />
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b> <?= isset($encaissementBl->Taux_41 ) ? $encaissementBl->Taux_41 : ""; ?> CDF
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte Guichet Unique</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b>  <span class="<?php if($encaissementBl->CGU=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $encaissementBl->CGU; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 bTop">
                    <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                </div>
                <div class="col-md-12"><br></div>
                <div class="col-md-12">
                    <?php if(!empty($lines)): ?>
                        <table class="table table-hover table-striped">
                            <thead >
                              <tr class="bg-blue">
                                <th width="" align="left">Sens</th>
                                <th align="">D&eacute;bit</th>
                                <th align="">Cr&eacute;dit</th>
                                <th align="">Montant</th>
                                <th align="">Designation</th>
                                <th width="" align="left">N&ordm; amplitude</th>
                                <th width="" align="left">Statut</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i=2;
                                foreach($lines as $row){
                                    $infos = json_decode($row->Details_23, true);
                                    $num_event = $infos['Num_evenement'];
                                ?>
                                    <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                                        <td><?php echo $row->Operation_8; ?></td>
                                        <?php if($row->Operation_8 == "V"):?>
                                            <td  <?php if($row->Compte_9=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_9; ?></td>
                                            <td  <?php if($row->Compte_13=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_13; ?></td>
                                        <?php else :?>
                                            <td><?php echo '-'; ?></td>
                                            <td <?php if($row->Compte_9=='00000000000000000000000') echo 'color:red'; ?>"><?php echo $row->Compte_9; ?></td>
                                        <?php endif;?>
                                        <td><?php echo $row->Devise_11." ". number_format($row->Montant_10,2,","," "); ?></td>
                                        <td><?php echo $row->Libelle_12; ?></td>
                                        <td><?= isset($cbs_return[$row->Id_0]['Num_evenement']) ? $cbs_return[$row->Id_0]['Num_evenement'] : ""; ?></td>
                                        <td><?php if(isset($cbs_return[$row->Id_0]['code']) && $cbs_return[$row->Id_0]['code'] =='200'){ echo "Int&eacute;gr&eacute;"; } elseif(isset($cbs_return[$row->Id_0]['code']) && $cbs_return[$row->Id_0]['code'] =='404'){ echo "Non int&eacute;gr&eacute;"; } elseif(isset($cbs_return[$row->Id_0]['code']) && $cbs_return[$row->Id_0]['code'] =='300'){ echo "En attente"; } else{ echo "Inconnu"; } ?></td>
                                    </tr>
                                <?php 
                                $i++; 
                                } ?>
                            </tbody>    
                        </table>
                    <?php endif;?>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div id="createPaiement" class="col-md-12">
                  <button id="closePanel" type="button" class="btn btn-warning" ><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(); ?> 
</div>