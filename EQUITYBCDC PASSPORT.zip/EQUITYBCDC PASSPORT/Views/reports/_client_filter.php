<input type="hidden" id="nbre" value="<?= (count($_SESSION["bulletins"]) > 0 || count($_SESSION["encaissements"]) > 0)?1:0 ?>"/>
<?php if(!empty($encaissements) || !empty($bulletins)): ?>
<div class="table-responsive">
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-aqua text-white">
                <th></th>
                <th>Date</th>
                <th>Client</th>
                <th>B&eacute;n&eacute;ficiaire</th>
                <th>Service</th>
                <th>Recette</th>
                <th>Montant</th>
                <th>Commissions</th>
                <th>Op&eacute;rateur</th>
            </tr>
        </thead>
        <tbody>

        <?php 
        #Block last BL
        foreach($bulletins as $row){ 
            $agence =  (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
            $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        ?>
            <tr>
                <td width="5"><b>#</b></span></td>
                <td  width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-black"';?> >
                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                </td>
                <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                <td width=""><b><?php echo $row->Office_6 ?></b></td>
                <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                <td class="text-blue">
                    <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                </td>
                <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
            </tr>
        <?php 
            } 
        ?>
        <?php  

            foreach($encaissements as $row){ 
                $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        ?>
            <tr>
                <td width="5"><b>#</b></span></td>
                <td width="50" <?php echo 'class="text-black"';?>>
                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                </td>
                <td class="text-blue" width="50"><?php echo $row->Designation_14; ?></td>
                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                <td><?php echo $beneficiaires[$row->Service_16]; ?></td>
                <td><?php echo $row->Typerecette_17; ?></td>
                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                      <br/>
                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                    <?php endif;?>
                </td>
                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
            </tr>
        <?php 
        } 
        ?>
        </tbody>    
    </table>
    <input type="hidden" name = "encaissements" value='<?php echo(!empty($encaissements))? json_encode($encaissements): '';?>'>
</div>
<?php else: ?>
    <section class="m-5">
        <h4 align="center">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            <b>Aucun rapport trouv&eacute; !</b>
        </h4>
    </section>
<?php endif; ?>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });
    
    $('#table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            paging: true,
            searching: false
        });
</script>