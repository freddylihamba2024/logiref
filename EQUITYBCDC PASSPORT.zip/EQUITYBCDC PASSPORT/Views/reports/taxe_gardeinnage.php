<?php

$total_general_paiements = 0;
?>

<?php if($_SESSION['Logiref_role']==4): ?>

    
<div class="row">
    
    <div class="col-lg-12 p-3">
        <div id="loader"></div>
        <?php if(!empty($encaissements)): ?>
            <div class="ibox bg-white">
                <div class="ibox-title border-bottom">
                    <h2 class="text-blue">R&eacute;lev&eacute; des encaissements DGRAD/Taxe gardiennage</h2>
                </div>
                <div class="col-sm-12">
                            <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                            
                            <div class="row">
                                <div class="col-md-5 no-padding  small-box">
                                    <div class="input-group input-daterange ">
                                        <span class="input-group-addon">Initi&eacute;e entre le</span>
                                        <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                    </div>
                                </div>
                                <div class="col-md-5 no-padding  small-box"></div>
                                <div class="col-md-1">
                                    <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>

                                </div>
                                <div class="col-md-1">
                                    <button  class="btn btn-default" id="print" type="button"> <i class="fa fa-print text-gray"></i></button>&nbsp;&nbsp;<br/>
                                </div>


                                
                            </div>
                            <?php echo form_close(); ?>
                </div>
                <div class="col-lg-12 table-responsive" id="filterResult">
                            <table class="table table-striped bg-white" id="table">
                                    <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">
                                        <tr class="bg-gray">
                                                <th with="12">N&SmallCircle;</th>
                                                <th>Date</th>
                                                <th>NOM ou RAISON SOCIALE</th>
                                                <th with="150">NUMERO IMP&Ocirc;T</th>
                                                <th with="150">NATURE DE L'IMP&Ocirc;T</th>
                                                <th with="150">MONTANT PAYE EN CDF</th>
                                                <th with="150">N&ordm; NOTE DE PERCEPTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php  foreach($encaissements as $row): ?>
                                                <tr class="<?php echo $i++; ?>">
                                                        <td><?php echo $row->Id_0; ?></td>
                                                        <td><?php echo strftime('%d-%m-%Y', strtotime($row->Datevaleur_31)) ; ?></td>
                                                        <td><?php echo $row->Designation_14; ?></td>
                                                        <td><?php echo $row->Nif_13; ?></td>
                                                        <td><?php echo $row->Typerecette_17; ?></td>
                                                        <td><?php echo number_format($row->Montant_11,2,","," "); ?></td>
                                                        <td><?php echo $row->Noteid_26;?></td>
                                                </tr>
                                                <?php $total_general_paiements += $row->Montant_11; ?>
                                        <?php endforeach; ?>
                                                <tr>
                                                        <td colspan="2" style="text-align: right;"><b>Total</b></td>
                                                        <td colspan="2"></td>
                                                        <td colspan="3">
                                                                <b><span class="text-red"><?php echo number_format($total_general_paiements,2,","," "). ' CDF ';?></span></b>
                                                        </td>
                                                </tr>
                                    </tbody>
                            </table>
                </div>
            </div>
        <?php else: ?>
            <section id="cat_list" class="text-center ">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
            </section>
        <?php endif;?>
    </div>
    
</div>

		

<?php else :?>
		
    <div class="row">
        
        <div class="col-md-12 p-3">
        <div id="loader"></div>
            <?php if(!empty($encaissements)): ?>
                <div class="ibox bg-white">
                        <div class="ibox-title border-bottom">
                            <h2 class="text-blue">R&eacute;lev&eacute; des encaissements DGRAD/Taxe gardiennage</h2>
                        </div>
                        <div class="col-sm-12">
                                    <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>

                                    <div class="row">
                                        <div class="col-md-5 no-padding  small-box">
                                            <div class="input-group input-daterange ">
                                                <span class="input-group-addon">Initi&eacute;e entre le</span>
                                                <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                            </div>
                                        </div>
                                        <div class="col-md-5 no-padding  small-box"></div>
                                        <div class="col-md-1">
                                            <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>

                                        </div>
                                        <div class="col-md-1">
                                            <button  class="btn btn-default" id="print" type="button"> <i class="fa fa-print text-gray"></i></button>&nbsp;&nbsp;<br/>
                                        </div>



                                    </div>
                                    <?php echo form_close(); ?>
                        </div>
                        <div class="col-lg-12 table-responsive" id="filterResult">
                            <table class="table table-striped bg-white" id="table">
                                    <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">
                                        <tr class="bg-gray">
                                                <th with="12">N&SmallCircle;</th>
                                                <th>Date</th>
                                                <th>NOM ou RAISON SOCIALE</th>
                                                <th with="150">NUMERO IMP&Ocirc;T</th>
                                                <th with="150">NATURE DE L'IMP&Ocirc;T</th>
                                                <th with="150">MONTANT PAYE EN CDF</th>
                                                <th with="150">N&ordm; NOTE DE PERCEPTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php  foreach($encaissements as $row): ?>
                                                <tr class="<?php echo $i++; ?>">
                                                        <td><?php echo $row->Id_0; ?></td>
                                                        <td><?php echo strftime('%d-%m-%Y', strtotime($row->Datevaleur_31)) ; ?></td>
                                                        <td><?php echo $row->Designation_14; ?></td>
                                                        <td><?php echo $row->Nif_13; ?></td>
                                                        <td><?php echo $row->Typerecette_17; ?></td>
                                                        <td><?php echo number_format($row->Montant_11,2,","," "); ?></td>
                                                        <td><?php echo $row->Noteid_26;?></td>
                                                </tr>
                                                <?php $total_general_paiements += $row->Montant_11; ?>
                                        <?php endforeach; ?>
                                                <tr>
                                                        <td colspan="2" style="text-align: right;"><b>Total</b></td>
                                                        <td colspan="2"></td>
                                                        <td colspan="3">
                                                                <b><span class="text-red"><?php echo number_format($total_general_paiements,2,","," "). ' CDF ';?></span></b>
                                                        </td>
                                                </tr>
                                    </tbody>
                            </table>
                        </div>
                </div>
            <?php else: ?>
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
                </section>
            <?php endif;?>
        </div>
      
    </div>

 <?php endif;?>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$("#print").prop("disabled", true);
$("#searchform").submit(function(e){
    e.preventDefault();
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filter_taxegardiennage'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){
                    $('#message').html('');
                    $("#print").prop("disabled", false);
                    $('#filterResult').html(result);
                    
            },
            error:function(error){
                alert('ERROR!' + error);
            }
        });
    
});
    
    
    
$("#print").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        
        var url = '<?php echo base_url($module.'/taximpression/display/print_paiements_taxegardiennage'); ?>';
        var data = $("#searchform").serialize();
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){
                $("#loader").html('');
                print(result);
            },
            error:function(error){
                alert('ERROR:'+error);
            }
        });
        
//        $.get(url, function(data, status){
//            $("#loader").html('');
//            print(data);
//        });
        
});

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

function print(buffer)
{
    var w = window.open('<?php echo base_url()?>'+buffer);
}

</script>
