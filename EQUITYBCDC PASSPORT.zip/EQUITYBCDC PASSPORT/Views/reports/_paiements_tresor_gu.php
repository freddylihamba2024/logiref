<?php if (!empty($encaissements) || !empty($encaissements_from_reporting)): ?>
<div class="col-lg-12 table-responsive">
    <table class="table table-hover table-striped" id="table">
        <thead class="bg-gray f12">
            <th>#</th>
            <th>Date</th>
            <th>Bulletin</th>
            <th>Régie</th>
            <th>Service</th>
            <th>Recette</th>
            <th>Importateur</th>
            <th>Quitt</th>
            <th>Montant BL</th>
            <th>Taxe payée</th>
        </thead>
        <tbody>
            <?php $i = 0; ?>

            <!-- ENCAISSEMENTS -->
            <?php foreach ($encaissements as $row): 
                $Infos = json_decode($row->Notereference_30, true);
            ?>
                <tr>
                    <td><b><?= ++$i ?></b></td>
                    <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                        <?= $row->Datevaleur_31 ?>
                    </td>
                    <td><?= $row->Noteid_26 ?></td>
                    <td><?= $row->Beneficaire_15 ?></td>
                    <td><?= $services[$row->Service_16] ?? '' ?></td>
                    <td><?= $row->Typerecette_17 ?></td>
                    <td><?= $row->Designation_14 ?></td>
                    <td class="text-blue"><?= $Infos['quittanceid'] ?? '-' ?></td>
                    <td><b>CDF <?= number_format($row->Notemontant_28, 2, ',', ' ') ?></b></td>
                    <td><b>CDF <?= number_format($row->Montant_11, 2, ',', ' ') ?></b></td>
                </tr>
            <?php endforeach; ?>

            <!-- ENCAISSEMENTS FROM REPORTING -->
            <?php foreach ($encaissements_from_reporting as $row): 
                $Infos = json_decode($row->Notereference_30, true);
            ?>
                <tr>
                    <td><b><?= ++$i ?></b></td>
                    <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                        <?= $row->Datevaleur_31 ?>
                    </td>
                    <td><?= $row->Noteid_26 ?></td>
                    <td><?= $row->Beneficaire_15 ?></td>
                    <td><?= $services[$row->Service_16] ?? '' ?></td>
                    <td><?= $row->Typerecette_17 ?></td>
                    <td><?= $row->Designation_14 ?></td>
                    <td class="text-blue"><?= $Infos['quittanceid'] ?? '-' ?></td>
                    <td><b>CDF <?= number_format($row->Notemontant_28, 2, ',', ' ') ?></b></td>
                    <td><b>CDF <?= number_format($row->Montant_11, 2, ',', ' ') ?></b></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
    <section class="text-center mt-5">
        <span class="fa fa-flask text-gray mystyle4"></span><br>
        <b>Aucun enregistrement trouvé !</b>
    </section>
<?php endif; ?>

<script type="text/javascript"  charset="utf-8">

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });
</script>

