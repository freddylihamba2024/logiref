<?php 

$paiements = 0;
$paiements_dgda = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
$disabled = (($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) ? "disabled":"";
?>
<div class="row">
    <div id="pager"  class="col-md-12"> 
        <div class="row">
            <div class="col-md-12">

                <div  id="loader1"></div>

                <?php $chtml->box_body_opening('', true); ?>
                    <div class="col-md-12">
                        <?php echo form_open('', array('id' => 'search_form', 'class' => '')); ?>
                        <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><b>Utilisateur</b></label>
                                        <?php echo form_dropdown('user', $users,'', ' id="users" class="form-control select2" '.$disabled ); ?>

                                    </div>    
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><b>Recette</b></label>
                                        <?php echo form_dropdown('Typerecette_17', $recettes,'', ' id="recette" class="form-control select2" '); ?>
                                    </div>    
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for=""><b>P&eacute;riode</b></label>
                                        <div class="input-daterange input-group">
                                            <span class="input-group-addon">De </span>
                                            <input class="form-control" name="start" value="" id="datepicker1" type="text">
                                            <span class="input-group-addon"> à </span>
                                            <input class="form-control" name="end" value=""  id="datepicker2" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label for="">&nbsp;&nbsp;</label><br/>
                                        <button type="button" id="search" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i> </button>

                                        <!-- <button type="submit" class="btn btn-primary" style="">Extraire</button> -->
                                    </div>
                                </div>
                        </div> 
                        <?php echo form_close(); ?>
                    </div>
                    <hr/>
                    <br>
                    <div id="paiementslist">
                        <?php if(!empty($encaissements) || !empty($encaissements_batch)  || !empty($bulletins)): ?>
                            <table id="table" class="table table-hover table-striped">
                                <thead>
                                    <tr style="background-color: #d2d6de;">
                                        <th></th>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>B&eacute;n&eacute;ficiaire</th>
                                        <th>Recette</th>
                                        <th>Montant</th>
                                        <th>Commissions</th>
                                        <th>Op&eacute;rateur</th>
                                        <th><span class="fa fa-fw fa-tasks f14"></span></th>
                                        <th><span class="fa fa-fw fa-folder f14"></span></th>
                                        <th><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php  foreach($encaissements as $row):
                                        $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                        $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                        $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                    ?>
                                        <tr>
                                            <td width="5"><b><?= ++$i; ?></b></span></td>
                                            <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                            </td>
                                            <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                            <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                            <td><?php echo $row->Typerecette_17; ?></td>
                                            <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                                <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                                    <br/>
                                                    <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                                <?php endif;?>
                                            </td>
                                            <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                            <td width="25">
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                            </td>
                                            <?php if($row->Checkerid_10==0): ?>
                                                <td width="25">
                                                    <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']): ?>
                                                        <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                                    <?php elseif($_SESSION['Logiref_role']==4 && $row->Makerid_9==$userid): ?>
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                                    <?php else: ?>
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                    <?php endif; ?>
                                                </td>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                </td>
                                            <?php else: ?>
                                                <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>
                                                    <td width="25">
                                                        <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="reverser('<?php echo $row->Id_0;?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                                    </td>
                                                <?php else: ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                    </td>
                                                <?php endif; ?>
                                                <td width="25">
                                                    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                                        <a class="cursor-pointer" onclick="" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span></a>
                                                    <?php else: ?>
                                                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?> 
                                        </tr>
                                    <?php 
                                            $paiements = $paiements + $row->Contrevaleur_22;
                                            $commissions = $commissions + $row->Commission_23;
                                            if($row->Status_2==1) $suspend = $suspend + 1;

                                        endforeach;
                                    ?>

                                    <?php
                                        #Block DGRAD (BATCH)
                                        foreach ($encaissements_batch as $row) :
                                            $guichet = (isset($guichets[$row->Guichet_25])) ? $guichets[$row->Guichet_25] : ' - ';
                                            $operateur = (isset($users[$row->Creator_4])) ? $users[$row->Creator_4] : ' - ';
                                            $dateTime = new DateTime($row->Date_1);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                    ?>
                                            <tr class="">
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td  width="80" <?php
                                                if ($row->Status_2 == 3)
                                                    echo 'class="text-green"';
                                                elseif ($deadline > gmdate('Y-m-d'))
                                                    echo 'class="text-black"';
                                                elseif ($deadline == gmdate('Y-m-d'))
                                                    echo 'class="text-orange"';
                                                elseif ($deadline < gmdate('Y-m-d'))
                                                    echo 'class="text-red"';
                                                ?> >
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php echo $row->Designation_12; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_7; ?></b></td>
                                                <td>
                                                    <span class="badge badge-secondary">Lot des notes (<?= $row->Nombrepaiements_26 ?>)</span>
                                                </td>
                                                <td class="text-blue">
                                                    <?php echo $row->Devise_14 . ' ' . number_format($row->Montant_13, 2, ",", " "); ?> 
                                                </td>
                                                <td class="text-black"><?php echo $row->Devise_16 . ' ' . number_format($row->Commission_15, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <?php if ($row->Status_2 == 1):?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php elseif ($_SESSION['Logiref_role'] == 4 && $row->Creator_4 == $userid) :?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php else: ?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php else: ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>', '<?php echo $row->Status_2; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <?php 
                                                            $validation_date = $row->Validation_31 ?? null; 
                                                            if ($validation_date) 
                                                            {
                                                                $validationDateObj = new DateTime($validation_date);
                                                                $now = new DateTime();
                                                            }
                                                        ?>
                                                        <?php if ($row->Status_2 == 2 && (($now->format('Y-m-d') === $validationDateObj->format('Y-m-d')) || $row->Printattestation_35 == 0)): ?>
                                                            <a class="cursor-pointer" onclick="print_batch('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        <?php else : ?>
                                                            <a class="cursor-pointer"><span class="fa fa-fw text-muted fa-file-pdf-o f14"> </span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                    <?php endforeach;?>

                                    <!-- Bulletins -->
                                    <?php foreach ($bulletins as $row):
                                                $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                                $dateTime = new DateTime($row->Integration_16);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                                $results = json_decode($row->Results_13);
                                                                    
                                                if (isset($results->receiptDate)) $recieptDate = explode("/", $results->receiptDate);
                                                else $recieptDate[2] = date('Y');

                                                $receiptNumber = isset($results->receiptNumber)?$results->receiptNumber:"";
                                                $receiptSerial = isset($results->receiptSerial)?$results->receiptSerial:"" ;
                                                $nodeid = $recieptDate[2] . '' . $receiptSerial . '' .$receiptNumber ; 
                                        ?>
                                        <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                            <td width="50" 
                                                <?php
                                                if ($row->Status_2 == 4)
                                                    echo 'class="text-green"';
                                                elseif ($deadline > gmdate('Y-m-d'))
                                                    echo 'class="text-black"';
                                                elseif ($deadline == gmdate('Y-m-d'))
                                                    echo 'class="text-orange"';
                                                elseif ($deadline < gmdate('Y-m-d'))
                                                    echo 'class="text-red"';
                                                ?>
                                            >
                                                <?php echo $row->Integration_16; ?>
                                            </td>
                                            <td class="text-blue"><?=  ($row->Designation_23 == "") ? "Bulletin de liquidation / " . $row->Nif_9 : $row->Designation_23;?></td>
                                            <td width="20"><b><?= "DGDA" ?></b></td>
                                            <td><?= 'L' . '' . $row->Number_8; ?></td>
                                            <td class="text-blue"><?='CDF ' . number_format($row->Amount_12, 2, ",", " "); ?> </td>
                                            <td class="text-black"><?php echo $row->Devise_27.' '.number_format($row->Commission_26,2,","," "); ?></td>
                                            <td><?= (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - '; ?></td>
                                            <td width="25">
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                            </td>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                            <td width="25">
                                                <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                                    <a class="cursor-pointer" onclick="" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span></a>
                                                <?php else: ?>
                                                    <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                </tbody> 
                            </table>
                        <?php else:?>
                            <div class="col-md-12">
                                <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                        <span class="d-block p-2 f14 text-black">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>

                                </section>
                            </div>
                        <?php endif;?>
                    </div>
                <?php $chtml->box_body_closing(); ?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
$(".select2").select2();

$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgda').html('<?php echo number_format($paiements_dgda,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});

$("#contenter").unbind().on("click", ".item", function(){
        
        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});
    
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
});


$("#search").on("click", function(e){
    e.preventDefault();
    $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

    var url = '<?php echo base_url($module.'/taxreports/display/validatepayment/'); ?>'+ null +'/filter';
    var data = $("#search_form").serialize(); 

    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode          : true,
        success: function(result){
            $('#loader1').html('');
            $('#paiementslist').html(result);
        },
        error:function(error){
            alert('ERROR!' + error);
        }
    });
});


function view(id, regie)
{
        var url ='';
        if(regie === 'DGDA')
        {
             var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGI')
        {
             var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGRAD')
        {
             var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
        }

        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url,{previous_menu:"pending"}, function(data, status){
            $("#loader1").html('');
            $("#pager").html(data);

        });
}

    function view_batch(id, regie = null, statuse=null)
    {
        if (regie === 'DGRAD')
        {
            if (statuse == 2)
            {
                var url = "<?php echo base_url($module . '/taxnotes/display/preview_batch'); ?>/" + id;
            }
            else
            {
                var url = "<?php echo base_url($module . '/taxnotes/display/edit_batch'); ?>/" + id;
            }
        }

        
        $("#message").html('<img  align="middle" stylee="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {previous_menu: "nvalidated"}, function (data, status) {
            $("#message").html('');
            $("#pager").html(data);
        });
    }

function printQuittance(file)
{
        var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
        
}

function print_payment(pid){

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}

function print_batch(pid){

    let base = '<?php echo base_url($module . "/taximpression/display/attestation"); ?>';
    let param = 'batch'

    // Vérifier si param n'est pas null
    var url =  base + '/' + pid + '/' + param;

    // Ouvrir la fenêtre d’impression
    var w = window.open(url, "_blank");

    if (w) {
        // Vérifier que la fenêtre s'est bien ouverte
        $(w).on("load", function () {
            try {
                // Lancer l'impression automatiquement
                w.print();

                $('#message').html('<div class="alert aSuccess text-white">Bravo! Attestation générée et impression lancée...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

            } catch (e) {
                // Si une erreur survient, on réactive le bouton
                $("#print").prop("disabled", false);

                $('#message').html('<div class="alert aDanger text-white"> Error : Erreur lors de la génération du PDF. Veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

        // Gestion du cas où la fenêtre est fermée trop tôt
        var checkClosed = setInterval(function () {
            if (w.closed) {
                clearInterval(checkClosed);
                $("#print").prop("disabled", false);
            }
        }, 1000);

    } else {
        // Si le popup a été bloqué
        $("#print").prop("disabled", false);
        
        $('#message').html('<div class="alert aWarning text-white"> Information : Le navigateur a bloqué la génération de l’attestation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
        
}
</script>


