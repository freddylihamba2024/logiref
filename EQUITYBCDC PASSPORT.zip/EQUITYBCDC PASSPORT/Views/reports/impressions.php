
<div class="row">
        <div class="col-md-12">
                <div class="row">
                        <div class="col-md-12 ">
                                <h2 class="f30 text-blue">Les preuves des paiements</h2>
                                <p class="page-header"><span class="f12 text-black">Cette sections vous permet de sélectionner la preuve de paiement à imprimer.</span></p>     
                        </div>
                </div>
               
                <div class="row">
                        <div class="col-md-12 p-0" id="">
                                <div class="col-md-12 p-0">
                                        <div class="box-body">
                                                <?php $chtml->box_body_opening("", true);?>
                                                <div class="row">
                                                        <div class="col-md-12">
                                                                <div class="form-group">
                                                                        <label for="type" class="f12 text-black">Selectionner la preuve de paiement</label>
                                                                        <?php echo form_dropdown('type', $impressions, "", 'class="form-control default-width" id="type" '); ?>
                                                                </div>
                                                        </div>
                                                </div>
                                                <?php $chtml->box_body_closing(); ?>
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col-md-12 p-0" id="">
                        <div class="col-md-12 p-0">
                            <div class="box-body" id="sub-menu">
                                <div id="loader-sub-menu">
                                    <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block p-2 "><span class="fa fa-ban text-navy mystyle4" ></span></br>
                                            <span class="d-block p-2 f12 text-black">Aucune preuve de paiement sélectionnée. Veuillez en choisir un pour procéder à l'impression.</span>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
</div>

<script type="text/javascript">
    
    $('#type').change(function(){
        var type = $('#type option:selected').val();
        
        if(type != '')
        {
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            action(type);
        }
    });
    
    
    function action(which) {
        
         if (which === 'attestation') {
            $.get("<?php echo base_url($module.'/taxreports/display/validatepayment'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'quitance') {
            $.get("<?php echo base_url($module . '/taxreports/display/quittancepaid'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
       
     }
    

</script>