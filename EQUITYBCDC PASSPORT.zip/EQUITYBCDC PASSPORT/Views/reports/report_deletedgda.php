
<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] != 4): ?>
 
<div class="row">
    <div class="col-md-12">
        <div id="message"></div><br/>
    </div>
</div>
<div class="row" style="margin-top: -25px;">
    <div class="col-lg-12">
        <div class="ibox bg-white">
            <div class="ibox-title border-bottom">
                <h2 class="text-blue">Paiements DGDA archivés</h2>
            </div>
            <!-- FORMULAIRE -->
            <div class="col-sm-12">
                <?= form_open('', ['id' => 'searchform', 'class' => 'margin']); ?>
                <div class="row">
                    <div class="col-md-3">
                        <label><b>Bureau</b></label>
                        <?= form_dropdown('Office', $offices, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-2">
                        <label><b>Utilisateur</b></label>
                        <?= form_dropdown('user', $users, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-5">
                        <label><b>Période</b></label>
                        <div class="input-daterange input-group">
                            <span class="input-group-addon">De</span>
                            <input class="form-control" name="start" type="text" id="datepicker1" >
                            <span class="input-group-addon">à</span>
                            <input class="form-control" name="end" type="text" id="datepicker2">
                        </div>
                    </div>
                    <!-- <div class="col-md-2">
                        <label><b>Agence</b></label>
                        <= form_dropdown('Agence', $guichets, '', 'class="form-control"'); ?>
                    </div> -->
                    <div class="col-md-2">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" id="search" class="btn text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>
                            <!-- <button class="btn btn-primary">Extraire</button> -->
                            <button id="export" class="btn btn-success" <?= (empty($bulletins) ? "disabled": "")?>>Exporter</button>
                        </div>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>

            <!-- TABLE -->
            <div id="filterResult">
                <?php if (!empty($bulletins)): ?>
                    <div class="col-lg-12 table-responsive">
                        <table class="table table-striped bg-white" id="table">
                            <thead class="bg-gray f12">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Service</th>
                                    <th>BL</th>
                                    <!-- <th>Quittance</th> -->
                                    <th>Client</th>
                                    <th>Montant</th>
                                    <th>Agences</th>
                                    <th>Saisi</th>
                                    <th>Supprimé</th>
                                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0; ?>

                                <!-- BULLETINS -->
                                <?php  foreach ($bulletins as $row): 
                                    $operateur = $users[$row->User_15] ?? ' - ';
                                    $dateTime  = new DateTime($row->Deletion_48);
                                    $deadline  = date('Y-m-d', strtotime("+1 day", $dateTime->format('U')));
                                    $results   = json_decode($row->Results_13);

                                    $recieptDate   = isset($results->receiptDate) ? explode("/", $results->receiptDate) : [null, null, date('Y')];
                                    $receiptNumber = $results->receiptNumber ?? "";
                                    $receiptSerial = $results->receiptSerial ?? "";
                                    $nodeid        = $recieptDate[2] . $receiptSerial . $receiptNumber;

                                    if ($row->Status_2 == 4) {
                                        $dateClass = "text-green";
                                    } elseif ($deadline > gmdate('Y-m-d')) {
                                        $dateClass = "text-black";
                                    } elseif ($deadline == gmdate('Y-m-d')) {
                                        $dateClass = "text-orange";
                                    } else {
                                        $dateClass = "text-red";
                                    }
                                ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                                        <td><b><?= $i ?></b></td>
                                        <td class="<?= $dateClass ?>"><?= htmlspecialchars($row->Deletion_48) ?></td>
                                        <td><?= htmlspecialchars($services[$row->Office_6] ?? '') ?></td>
                                        <td><?= 'L' . $row->Number_8 ?></td>
                                        <!-- <td><= htmlspecialchars($nodeid) ?></td> -->
                                        <td class="text-blue">
                                            <?= $row->Designation_23 === "" 
                                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_9) 
                                                : htmlspecialchars($row->Designation_23) ?>
                                        </td>
                                        <td class="text-blue">CDF <?= number_format($row->Amount_12, 2, ",", " ") ?></td>
                                        <td><?= htmlspecialchars($guichets[$row->Agence_32] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($operateur) ?></td>
                                        <td><?= htmlspecialchars($users[$row->Deletedby_49] ?? ' - ') ?></td>
                                        <td>
                                            <a onclick="view('<?= $row->Id_0 ?>', 'DGDA')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <section class="text-center mt-5">
                        <span class="fa fa-flask text-gray mystyle4"></span><br>
                        <b>Aucun enregistrement fait!</b>
                    </section>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    $("#searchform").submit(function (e) {
        e.preventDefault();
        $("#message").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxreports/display/report_deletedgda/'); ?>'+ null+ '/filter';
        var data = $(this).serialize();
        alert(url)
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#message').html('');
                $("#export").removeAttr("disabled");
                $('#filterResult').html(result);
            },
            error: function (error) {
                alert('ERROR!' + error);
            }
        });
    });

    function view(id)
    {
        var url = "<?php echo base_url($module . '/taxbulletin/display/preview'); ?>/" + id;
        var controller = 'reports';
        var view = '<?php echo $display; ?>';
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {controller: controller, view: view}, function (data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });
    }

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $("#export").click(function (e) {
        e.preventDefault();

        $("#message").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let url  = "<?= base_url($module . '/taximpression/display/export_deleted_dgda'); ?>";
        let data = $("#searchform").serialize();

        $.ajax({
            url: url,
            type: "POST",
            data: data,
            xhrFields: {
                responseType: 'blob'
            },
            success: function (blob, status, xhr) {

                $("#message").html('');

                // Récupération du nom du fichier depuis le header
                let disposition = xhr.getResponseHeader('Content-Disposition');
                let filename = "report_paiement_dgda.xlsx";

                if (disposition && disposition.indexOf('filename=') !== -1) {
                    filename = disposition
                        .split('filename=')[1]
                        .replace(/"/g, '');
                }

                // Téléchargement forcé
                let url = window.URL.createObjectURL(blob);
                let a = document.createElement('a');

                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();

                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            },
            error: function () {
                $("#message").html('');
                alert("Erreur lors de l’export");
            }
        });
    });

    function print(buffer)
    {
        var link = document.createElement('a');
        link.href = '<?php echo base_url() ?>' + buffer;
        link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>