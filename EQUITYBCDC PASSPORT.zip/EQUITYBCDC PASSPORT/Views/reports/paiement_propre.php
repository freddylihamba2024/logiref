<?php
$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;
?>

<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] != 4): ?>

<div class="row">
    <div class="col-md-12">
        <div id="message"></div><br/>
    </div>
</div>

<div class="row" style="margin-top: -25px;">
    <div class="col-lg-12">
        <div class="ibox bg-white">
            <div class="ibox-title border-bottom">
                <h2 class="text-blue">Guichet unique Propre</h2>
            </div>

            <!-- FORMULAIRE -->
            <div class="col-sm-12">
                <?= form_open('', ['id' => 'searchform', 'class' => 'margin']); ?>
                <div class="row">
                    <div class="col-md-1">
                        <label><b>Régie</b></label>
                        <?= form_dropdown('Regie', $beneficiaires, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-2">
                        <label><b>Bureau</b></label>
                        <?= form_dropdown('Office', $offices, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-2">
                        <label><b>Recette</b></label>
                        <?= form_dropdown('Recette', $recettes, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-3">
                        <label><b>Période</b></label>
                        <div class="input-daterange input-group">
                            <span class="input-group-addon">De</span>
                            <input class="form-control" name="start" type="text" id="datepicker1">
                            <span class="input-group-addon">à</span>
                            <input class="form-control" name="end" type="text" id="datepicker2">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label><b>Agence</b></label>
                        <?= form_dropdown('Agence', $guichets, '', 'class="form-control"'); ?>
                    </div>
                    <div class="col-md-2">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" id="search" class="btn text-white bg-blue-active">
                                <i class="fa fa-fw fa-refresh"></i>
                            </button>
                            <button id="export" class="btn btn-success" <?= (empty($encaissements) && empty($encaissements_from_reporting) ? "disabled" : "") ?>>Exporter</button>
                        </div>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>

            <!-- TABLE -->
            <div id="result">
                <?php if (!empty($encaissements) || !empty($encaissements_from_reporting)): ?>
                <div class="col-lg-12 table-responsive">
                    <table class="table table-hover table-striped" id="table">
                        <thead class="bg-gray f12">
                            <th>#</th>
                            <th>Date</th>
                            <th>Bulletin</th>
                            <th>Régie</th>
                            <th>Service</th>
                            <th>Recette</th>
                            <th>Importateur</th>
                            <th>Quitt</th>
                            <th>Montant BL</th>
                            <th>Taxe payée</th>
                        </thead>
                        <tbody>
                            <?php $i = 0; ?>

                            <!-- ENCAISSEMENTS STANDARD -->
                            <?php foreach ($encaissements as $row): 
                                $Infos = json_decode($row->Notereference_30, true);
                            ?>
                                <tr>
                                    <td><b><?= ++$i ?></b></td>
                                    <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                        <?= $row->Datevaleur_31 ?>
                                    </td>
                                    <td><?= $row->Noteid_26 ?></td>
                                    <td><?= $row->Beneficaire_15 ?></td>
                                    <td><?= $services[$row->Service_16] ?? '' ?></td>
                                    <td><?= $row->Typerecette_17 ?></td>
                                    <td><?= $row->Designation_14 ?></td>
                                    <td class="text-blue"><?= $Infos['quittanceid'] ?? '-' ?></td>
                                    <td><b>CDF <?= number_format($row->Notemontant_28, 2, ',', ' ') ?></b></td>
                                    <td><b>CDF <?= number_format($row->Montant_11, 2, ',', ' ') ?></b></td>
                                </tr>
                            <?php endforeach; ?>

                            <!-- ENCAISSEMENTS FROM REPORTING -->
                            <?php foreach ($encaissements_from_reporting as $row): 
                                $Infos = json_decode($row->Notereference_30, true);
                            ?>
                                <tr>
                                    <td><b><?= ++$i ?></b></td>
                                    <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                        <?= $row->Datevaleur_31 ?>
                                    </td>
                                    <td><?= $row->Noteid_26 ?></td>
                                    <td><?= $row->Beneficaire_15 ?></td>
                                    <td><?= $services[$row->Service_16] ?? '' ?></td>
                                    <td><?= $row->Typerecette_17 ?></td>
                                    <td><?= $row->Designation_14 ?></td>
                                    <td class="text-blue"><?= $Infos['quittanceid'] ?? '-' ?></td>
                                    <td><b>CDF <?= number_format($row->Notemontant_28, 2, ',', ' ') ?></b></td>
                                    <td><b>CDF <?= number_format($row->Montant_11, 2, ',', ' ') ?></b></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <section class="text-center mt-5">
                        <span class="fa fa-flask text-gray mystyle4"></span><br>
                        <b>Aucun enregistrement trouvé !</b>
                    </section>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php endif; ?>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">

//Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });


    $("#contenter").on("click", ".item", function () {

        var id = $(this).attr('data-id-item');
        $("#form_paiement").removeClass('hidden');
        $("#close").addClass('hidden');
        $("#cancel").addClass('hidden');

    });


    $("#searchform").submit(function (e) {
        e.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxreports/display/filter_gu_prpores'); ?>';
        var data = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#message').html('');
                $("#export").removeAttr("disabled");
                $('#result').html(result);
            },
            error: function (error) {
                alert('ERROR!' + error);
            }
        });

    });


    $('#regie').change(function () {

        var regie = $('#regie option:selected').val();
        if (regie != "")
        {
            shower(regie);

        }
    });

    $("#print").click(function () {

        var data = $("#searchform").serialize();
        var url = '<?php echo base_url($module . '/taximpression/display'); ?>/print_gu_paiements_propres';
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {

                //$('#page').html(result);
                print(result);

            },
            error: function (error) {
                alert('ERROR:' + error);
            }
        });

    });

    $("#export").click(function (e) {
        e.preventDefault();

        $("#message").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let url  = "<?= base_url($module . '/taximpression/display/export_gu_paiements_propres'); ?>";
        let data = $("#searchform").serialize();


        $.ajax({
            url: url,
            type: "POST",
            data: data,
            xhrFields: {
                responseType: 'blob'
            },
            success: function (blob, status, xhr) {

                $("#message").html('');

                // Récupération du nom du fichier depuis le header
                let disposition = xhr.getResponseHeader('Content-Disposition');
                let filename = "report_paiement_propres.xlsx";

                if (disposition && disposition.indexOf('filename=') !== -1) {
                    filename = disposition
                        .split('filename=')[1]
                        .replace(/"/g, '');
                }

                // Téléchargement forcé
                let url = window.URL.createObjectURL(blob);
                let a = document.createElement('a');

                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();

                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            },
            error: function () {
                $("#message").html('');
                alert("Erreur lors de l’export");
            }
        });
    });

    function shower(regie)
    {
        var url = '<?php echo base_url($module . '/reports'); ?>/display/dropdowns/' + regie;
        $.post(url, function (data, status) {
            $("#rlist").html(data);
        });

    }

    function print(buffer)
    {
        var link = document.createElement('a');
        link.href = '<?php echo base_url() ?>' + buffer;
        link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>

