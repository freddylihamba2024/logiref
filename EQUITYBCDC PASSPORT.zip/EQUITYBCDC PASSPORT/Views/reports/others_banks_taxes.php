<?php 

$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;

$encaissements = [];
?>
<div class="row">
    <div class="col-md-12">
    
        <?php $chtml->box_body_opening('', true); ?>
        <div class="statistic-box no-border no-padding">
            <div class="row">
                <div class="col-md-8 no-margin">
                    <h1>Taxes &agrave; envoyer vers les autres banques </h1>
                    <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente le rapport des taxes &agrave; envoyer vers les autres banques.</span></h5>
                </div>
                <div class="col-md-4 " style="float: right;">    
            </div>
            </div>
            <div >
                <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                    <div class="row">
                        <div class="col-md-4 col-sm-6 col-xs-12 small-box">
                            <div class="input-group">
                                    <span class="input-group-addon">
                                        <label><div id="rlist">Recette</div></label>
                                    </span>
                                    <?php echo form_dropdown('Recette', $recettes, '', ' id="recette" class="form-control"'); ?>
                            </div>
                        </div>
                        <div class="col-md-5 small-box">
                            <div class="form-group">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">Initi&eacute;e entre le</span>
                                    <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                    <span class="input-group-addon">et le</span>
                                    <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-default " type="button" id="print">Imprimer 
                            <i class="fa fa-print text-gray"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-bitbucket pull-right bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
        <div class="col-md-12 no-padding" id="filterResult">
            <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($taxes)): ?>

            <div  class="table-responsive">
                <table class="table table-hover table-striped ">
                    <thead>
                        <tr  class="bg-aqua-active">
                                <th width="250px">Libell&eacute;</th>
                                <th width="100px">Montant</th>
                                <th width="200px">Frais bcc</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($taxes as $key=>$row){
                            
                            $agence_src= $_SESSION['Logiref_guichet'];
                        ?>
                            <tr class="bg-gray">
                                <td colspan="3" class="bold">
                                    <span class="f15"><b><?php echo $key.'  -  '; ?></b> </span><span class="f15"><b><?php echo isset($beneficiaries[$key][$agence_src]) ? $beneficiaries[$key][$agence_src].'  -  ' : ''; ?></b></span><span class="f15"><b><?php echo isset($comptes[$key]['CDF']) ? $comptes[$key]['CDF'] : ''; ?></b></span>
                                </td>
                                
                            <?php foreach($row as $line) {
                                
                                $frais_bcc = $line->Montant_10 * 0.001;
                                
                            ?>
                                <tr>
                                    <td  width="250px"><?php echo $line->Libelle_12; ?></td>
                                    <td  width="100px"><?php echo $line->Montant_10; ?></td>
                                    <td  class=""><?php echo $frais_bcc; ?></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="col-md-12">
                <section id="cat_list" class="text-center marginTop150">
                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                    <span class="d-block p-2 f14 text-black">Aucune taxe trouv&eacute;e !</span>            
                </section>
            </div>
                
            <?php endif;?>
        </div>
        <?php $chtml->box_body_closing(); ?>
</div>
</div>        


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

$("#contenter").on("click", ".item", function(){
    
    var id = $(this).attr('data-id-item');
    $("#form_paiement").removeClass('hidden');
    $("#close").addClass('hidden');
    $("#cancel").addClass('hidden');
    
});   

function view(id, regie){
    var url ='';
    if(regie === 'DGI')
    {
         var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id;
    }
    else if(regie === 'DGRAD')
    {
         var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id;
    }
          
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}


$("#searchform").submit(function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filter_others_taxes'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#filterResult').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
    
});
$('#regie').change(function(){
        var regie = $('#regie option:selected').val();

        if(regie != "")
        {
               shower(regie);

        }
    
});
    
function shower(regie)
{
        var url = '<?php echo base_url($module.'/reports'); ?>/display/dropdowns/' +regie;
        $.post(url,function(data, status){
            $("#rlist").html(data);
        });
        
}
$("#print").click(function(){

var data = $("#searchform").serialize();
var url = '<?php echo base_url($module.'/taximpression/display'); ?>/print_others_taxes';
$.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode      : true,
            success: function(result){
               
               //$('#page').html(result);
               var w = window.open(url);
                
            },
            error:function(error){
                alert('ERROR:'+error);
            }
});

});

function print(buffer)
{
    alert(buffer)
var w = window.open();
}
</script>


