<div class="row mb-5">
    <div id="loader"></div>
    <div class="col-md-11">
        <?php 
            $chtml->box_body_opening("", true);
            echo form_open('', array('id' => 'mainform', 'class' => '')); 
        ?>
                
                <div class="statistic-box no-border">
                    <div class="row">
                        <div class="col-sm-10 col-xs-12">
                            <h2>Listes des r&egrave;gles de commissions</h2>
                            <h5 class="page-header"><!--<span class="text-gray">Cette section vous pr&eacute;sente la liste des r&egrave;gles des commissions de votre agence.</span>--></h5>
                        </div>
                        <!--<div class="col-sm-2 col-xs-3">
                            <div class="description-block ">
                                <a  style="cursor: pointer" onclick="action('sites')" class="bg-default text-gray">
                                    <b><br/><br/><span id="total" class="description-percentage f30 blue"></span></b>
                                    <span class="description-text text-gray"></span>
                                </a>
                            </div><!-- /.description-block -->
                        <!--</div>
                        <div class="col-sm-2 col-xs-3">
                            <div class="description-block">
                                <a  style="cursor: pointer" onclick="action('stores')" class="bg-default text-yellow">
                                    <b><br/><br/><span id="deadline" class="description-percentage f30 "> </span></b>
                                    <span class="description-text text-yellow"></span>
                                </a>
                            </div><!-- /.description-block -->
                        <!--</div>
                        <div class="col-sm-2 col-xs-3">
                            <div class="description-block">
                                <a  style="cursor: pointer" onclick="action('stores')" class="bg-default ">
                                    <b><br/><br/><span id="deadline" class="description-percentage f30 ">  </span></b>
                                    <span class="description-text text-blue"></span>
                                </a>
                            </div><!-- /.description-block -->
                        <!--</div>-->
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-5 col-xs-12 small-box">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <label><b>R&eacute;gie</b></label> 
                                </span>
                                <?php echo form_dropdown('regie',$regies['RGF'], '', 'class="form-control" '); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-bitbucket ml-4 pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>
                            <button type="button" class="btn btn-success ml-1 pull-right text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>
                            <button type="button" class="btn btn-bitbucket pull-right text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>
                        </div>
                    </div>
                </div>
                <input type="hidden" name = "regles" value='<?php echo(!empty($regles))? json_encode($regles): '';?>'>
        <?php 
            echo form_close(); 
        ?>
        
        <div id="page">
            <?php if(!empty($regles)): ?>
                <div class="table-responsive">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-aqua text-white">
                                <th>#</th>
                                <th>Priorit&eacute;</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Indice</th>
                                <th>Service</th>
                                <th>Recette</th>
                                <th>Guichet</th>
                                <th>Min</th>
                                <th>Max</th>
                                <th>Validation</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($regles as $row){ ?>
                            <tr>
                                <td width="5"><?php echo $row->Id_0; ?></td>
                                <td class="<?php if($row->Priorite_4 == 1){ echo 'bg-gray';}elseif($row->Priorite_4 == 2){echo 'bg-green';}elseif($row->Priorite_4 == 3){echo 'bg-blue';}elseif($row->Priorite_4 == 4){echo 'bg-orange';}elseif($row->Priorite_4 == 5){echo 'bg-yellow';}elseif($row->Priorite_4 == 6){echo 'bg-red';} ?> " align="center"><b>P<?php echo $row->Priorite_4; ?></b></td>
                                <td><?php if($row->Beneficiaire_5=='' or $row->Beneficiaire_5=='0') echo 'TOUS'; else echo ' '.$row->Beneficiaire_5;?></td>
                                <td class="bleu"><b><?php echo $row->Value_9.' '.$row->Unite_10;?></b></td>
                                <td><?php if($row->Service_6=='') echo 'TOUS'; else echo ' '.$services[$row->Beneficiaire_5][$row->Service_6];?></td>
                                <td><?php if($row->Recette_7=='') echo 'TOUTES'; else echo ' '.$row->Recette_7;?></td>
                                <td><?php if($row->Guichet_8=='') echo 'TOUS'; else echo ' '.$guichets[$row->Guichet_8];?></td>
                                <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Min_11,2,","," ");?></td>
                                <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Max_12,2,","," ");?></td>
                                <td>
                                    <?php if($row->Checkerid_15==0){ ?>
                                      <span class="text-red"> En attente </span>
                                    <?php }else {?>
                                      <?php echo $row->Validation_16;?>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>    
                    </table>
                </div>
            <?php else: ?>
                <section class="m-5">
                    <h4 align="center">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <b>Aucune r&egrave;gle n'est enregistr&eacute;e !</b>
                    </h4>
                </section>
            <?php endif;?>
        </div>
        <?php $chtml->box_body_closing(); ?>
    </div> 
    <div class="col-md-1">
        <a href="<?php echo base_url($module.'/taxreports/set/rapport'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

<script type="text/javascript">
    
    $('#table').DataTable({
        pageLength: 10,
        responsive: true,
        "bLengthChange": false,
        "bFilter": false,
        paging: true,
        searching: false
    });
   

    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/regles_filter'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }

            });
    });



    $("#print").click(function(){

            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/taximpression/display/print_regles'); ?>';

            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){


                            print(result);

                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });

    });

    function print(buffer)
    {
        var w = window.open('<?php echo base_url()?>'+buffer);
    }
    
    $("#export").click(function(){
        var nbre = $("#nbre").val();
        if(nbre > 0){
            $("#error").addClass('d-none');
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taximpression/display/export_regles'); ?>';
            window.open(url);
            $("#loader").empty();
        }
        else{
            $("#error").removeClass('d-none').show();
        }
    });
</script>