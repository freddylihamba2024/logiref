<?php 

$paiements = 0;
$paiements_dgi = 0;
#$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
    <div class="col-md-12">
            <h1 class="f30 text-blue">Pr&eacute;-paiements valid&eacute;s</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements  valid&eacutes.</span></p>
    </div>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 height90">
                        <h5 class="card-title f12 text-black width200">Total Prépaiement</h5>
                        <p class="text-blue f18"> <b>CDF <span id="paiements_dgi"></span></b></p>
                        <!--<p class="text-blue f18"> <b>USD <span id="paiements_dgi"></span></b></p>-->
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 height90">
                        <h5 class="card-title f12 text-black width200">Total Commission</h5>
                        <p class="text-green f18"><b>CDF <span id="paiements"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 height90">
                        <h5 class="card-title f12 text-black width200">Nombre des paiements</h5>
                        <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('attente')"><b ><span id="attente"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                    </div>
                </div>
            </div>
         
        </div><br>
    </div><br>
 
<!--    <div class="col-md-12">
        <div  id="message"></div>     
            <?php //$chtml->box_body_opening('', true);?>
                <div id="paiementslist">
                    <?php //if(!empty($prepayments)): ?>
                            
                    <div class="col-lg-12 table-responsive " id="paiementslist">
                        <table class="table table-striped bg-white" id="table">
                            <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">

                            </thead>
                        </table>
                    </div>
                    <table id="table" class="table table-hover table-striped">
                        <thead >
                            <tr class="bg-gray f12">
                                <th class="f12"></th>
                                <th class="f12" width="50">Date</th>
                                <th class="f12">D&eacute;signation</th>
                                <th class="f12">R&eacute;f&eacute;rence</th>
                                <th class="f12">Recette</th>
                                <th class="f12">Montant</th>
                                <th class="f12" width="50">Op&eacute;rateur</th>
                                <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        
                        #Block last Prepayments
                        //foreach($prepayments as $row){ 
                            //$agence =  (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - ';
                            //$operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                            //$dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        //?>
                            <tr>
                                <td width="5"><b><?//= ++$i;  ?></b></span></td>
                                <td  width="80" <?php //if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                    <?php //echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php //if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                                <td width="20"><b><?php //echo $row->AccountRef_14; ?></b></td>
                                <td><?php //echo $row->Serial_9.'-'.$row->Number_10; ?><br>
                                    <span class="text-gray">Bulletin pr&eacute;pay&eacute;</span>
                                </td>
                                <td class="text-blue">
                                    <?php //echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                                </td>
                                <td width="50"><?php //echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>

                                <td width="25">
                                    <a class="cursor-pointer" onclick="viewPrepayment('<?php //echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                </td>
                                <td width="25">
                                    <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                </td>
                               
                            </tr>
                        <?php 
                           
                        //} 
                        ?>
                            
                        
                        </tbody>    
                    </table>
                    <?php //else:?>
                    <div class="col-md-12">
                        <section id="cat_list" class="text-center marginTop150">
                                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                                <span class="d-block f14 text-black p-2">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                        </section>
                    </div>
                    <?php //endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?> 
    </div>   -->



      <div class="row">
                <div class="col-md-12 p-0">
                    <?php $chtml->box_body_opening('', false); ?>
                    <div id="list">
                    <?php if (!empty($prepayments)): ?>
                        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                            <div class="box-body box-solid no-padding">
                                <div class="col-md-12 p-0">
                                    <div class="box-body">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-striped">
                                                <thead class='bg-gray'>
                                                    <tr>
                                                        <th width="5px">#</th>
                                                        <th width="150px">R&eacute;f&eacute;rence du compte SYDONIA</th>
                                                        <th width="150px">Bureau</th>
                                                        <th width="100px">Declarant</th>
                                                        <th width="100px" class="center">Nombre des bulletins</th>
                                                        <th width="150px" class="center">Montant total</th>
                                                        <th width="10px"  style="text-align:left;"><i class="fa fa-edit f20"></i></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; foreach($prepayments as $customer => $payments): ?>
                                                    <tr>
                                                        <td class="align-middle" width=""><?php echo $i; ?></td>
                                                        <td class="align-middle" width=""><?php echo $customer; ?></td>

                                                        <?php 
                                                        # Initialisation des variables pour stocker les données collectées
                                                        $offices = '';
                                                        $declarants = '';
                                                        $totals = '';
                                                        $amounts = '';
                                                        $editLinks = '';

                                                        foreach($payments as $payment):
                                                            # Collecte des informations dans des variables HTML
                                                            $offices .= '<li>' . $services['DGDA'][$payment->Office_8] . '</li>';
                                                            $declarants .= '<li>' . $payment->Declarant_16 . '</li>';
                                                            $totals .= '<li>' . $payment->total . '</li>';
                                                            $amounts .= '<li>' . 'CDF ' . number_format($payment->amounts, 2, ",", " ") . '</li>';

                                                        endforeach;
                                                        ?>

                                                        <td class="align-middle pl-3" width=""><ul><?php echo $offices; ?></ul></td>
                                                        <td class="align-middle pl-3" width=""><ul><?php echo $declarants; ?></ul></td>
                                                        <td class="align-middle pl-3" width=""><ul><?php echo $totals; ?></ul></td>
                                                        <td class="align-middle pl-3" width=""><ul><?php echo $amounts; ?></ul></td>
                                                        <td class="align-middle" width="">
                                                            <a style="cursor: pointer" onclick="edit('<?php echo $customer; ?>', 'Customer', '<?php echo $payment->Office_8; ?>')"> 
                                                                <i class="fa fa-fw fa-edit text-blue f20"></i> 
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <?php $i++; endforeach; ?>
                                                </tbody>
                                            </table>
                                            <div  class="<?php echo ($_SESSION['Logiref_role'] == 4) ? 'd-none' : 'col-md-12 no-padding'; ?>">
                                                <button type="button" id="suivant" class="btn btn-primary mt-3 pull-right disabled"><i class="fa fa-arrow-circle-right"></i> Suivant <span id="index"></span>&nbsp;&nbsp;</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                    <?php $chtml->box_body_closing(); ?>
                    <?php else: ?>
                    <?php $chtml->box_body_opening(); ?> 
                        <section id="cat_list" class="text-center marginTop150">
                            <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                            <span class="d-block f14 text-black p-2">Aucun pr&eacute;paiement à traiter pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                        </section>
                    <?php $chtml->box_body_closing(); ?> 
                    <?php endif; ?>
                </div>
        </div>
</div>


<script type="text/javascript">

$("#contenter").unbind().on("click", ".item", function(){
        
        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});


$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgi').html('<?php echo number_format($paiements_dgi,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

function view_process(id, regie, param)
{
    if(param == 1)
    {
        var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id;
    }
    else
    {
        var url ="<?php echo base_url($module.'/taxbulletin/display/step_1_process'); ?>/"  + id;
    }
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}
    
function view(id, regie)
{
    var url ='';
    if(regie === 'DGDA')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGI')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxdeclaration/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
    }
    else if(regie === 'DGRAD')
    {
        '<?php if($_SESSION['Logiref_role'] !=4): ?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id;
        '<?php else :?>'
            var url ="<?php echo base_url($module.'/taxnotes/display/edit'); ?>/"  + id;
        '<?php endif; ?>'
        
         
    }
          
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url,{previous_menu:"nvalidated"}, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function view_manual(id, regie)
{
    
    var url ="<?php echo base_url($module.'/taxothers/display/preview'); ?>/"  + id;
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function viewPrepayment(id)
{
    '<?php if($_SESSION['Logiref_role'] !=4): ?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php else :?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php endif; ?>'
        
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function print_payment(pid){

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}

</script>