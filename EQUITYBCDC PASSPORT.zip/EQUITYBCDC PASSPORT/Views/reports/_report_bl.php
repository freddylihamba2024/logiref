<div class="row mb-5">
    <div id="loader"></div>
    <div class="col-md-11">
        <?php 
            $chtml->box_body_opening("", true);
            echo form_open('', array('id' => 'mainform', 'class' => '')); 
        ?>
            <div class="statistic-box no-border">
                <div class="row">
                    <div class="col-sm-10 col-xs-12">
                        <h2>Relev&eacute; des bulletins de liquidations</h2>
                        <h5 class="page-header"><!--<span class="text-gray">Cette section vous pr&eacute;sente la liste des bulletins de liquidations.</span>--></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-5 col-sm-4 col-xs-12 small-box">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <b>Agence </b>
                            </span>
                            <?php echo form_dropdown('agence', $agences, '', 'class="form-control" '); ?>
                        </div>
                    </div>
                    
                    <div class="col-md-5 small-box">
                        <div class="input-daterange input-group">
                            <span class="input-group-addon">Initi&eacute;e entre le</span>
                            <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                            <span class="input-group-addon">et le</span>
                            <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                        </div>
                    </div>
                    <div class="col-md-2" >
                        <button type="button" class="btn btn-bitbucket text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>
                        <button type="button" class="btn btn-success text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>
                        <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>
                    </div>
                </div>
                <input type="hidden" name = "bulletins" value='<?php echo(!empty($bulletins))? json_encode($bulletins): '';?>'>
            </div>
        
            <?php
                echo form_close(); 
            ?>
        
            <div id="page" class="mt-5">
                <input type="hidden" id="nbre" value="<?= count($_SESSION["bulletins"]) ?>"/>
                <?php if(!empty($bulletins)): ?>
                    <div id="list">
                        <div class="table-responsive">
                            <table id="table" class="table table-hover table-striped">
                                <thead>
                                    <tr class="bg-aqua text-white">
                                        <th width="10px">#</th>
                                        <th width="150">Date</th>
                                        <th width="50px">Ann&eacute;e</th>
                                        <th >Num&eacute;ro BL</th>
                                        <th >Bureau</th>
                                        <th >Agence</th>
                                        <th >Montant</th>
                                        <th width="">Num&eacute;ro imp&ocirc;t</th>
                                        <th >Cr&eacute;&eacute; par</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 0;
                                    foreach($bulletins as $row){
                                    ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $row->Date_1; ?></td>
                                            <td><?php echo $row->Year_5; ?></td>
                                            <td><?php echo $row->Serie_7."".$row->Number_8 ?></td>
                                            <td><?php echo $row->Office_6 ?></td>
                                            <td><?php echo isset($agences[$row->Agence_32]) ? $agences[$row->Agence_32] : "-"; ?></td>
                                            <td><?php echo 'CDF '.number_format($row->Amount_12,2,","," "); ?></td>
                                            <td><?php echo $row->Nif_9; ?></td>
                                            <td><?php echo isset($users[$row->User_15]) ? $users[$row->User_15] : "-"; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>    
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <section class="m-5">
                        <h4 align="center">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            <b>Aucun rapport trouv&eacute; !</b>
                        </h4>
                    </section>
                <?php endif;?>
            </div>
        <?php 
            $chtml->box_body_closing(); 
        ?>
    </div>
    <div class="col-md-1">
        <a href="<?php echo base_url($module.'/taxreports/set/rapport'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>

<script type="text/javascript">

    $('.table').DataTable({
        pageLength: 20,
        responsive: true,
        "bLengthChange": false,
        "bFilter": false,
        "bLengthChange": false,
    });

    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/bl_filter'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }

            });
    });

    $("#print").click(function(){
        
        var data = $("#mainform").serialize();
        var url = '<?php echo base_url($module.'/taximpression/display/print_bl'); ?>';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                        print(result);
                    },
                    error:function(error){
                        alert('ERROR:'+error);
                    }
        });

    });

    function print(buffer)
    {
        window.open('<?php echo base_url()?>'+buffer);
    }
    
    $("#export").click(function(){
        var nbre = $("#nbre").val();
        if(nbre > 0){
            $("#error").addClass('d-none');
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taximpression/display/export_bl'); ?>';
            window.open(url);
            $("#loader").empty();
        }
        else{
            $("#error").removeClass('d-none').show();
        }
    });

</script>





