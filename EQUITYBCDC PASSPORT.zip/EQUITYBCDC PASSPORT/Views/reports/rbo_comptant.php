<?php 

$paiements = 0;
$paiements_dgi = 0;
#$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
    <div class="col-md-12">
            <h1>Liste des paiements comptabilis&eacute;s (RBO)</h1>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements comptabilis&eacute;s </span></h5>
    </div>
    <div class="col-md-12">
        <div  id="message"></div>
        
            <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($bulletins)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th width="50">Date</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Agence</th>
                                <th width="50">Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        <?php 
                        
                        #Block last BL
                        foreach($bulletins as $row){ 
                            $agence =  (isset($guichets[$row->Agence_14]))? $guichets[$row->Agence_14] :' - ';
                            
                            $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            
                            $bl_info = json_decode($row->Bulletin_9); 
                        ?>
                            <tr>
                                <td width="10"><b><?= ++$i;  ?></b></span></td>
                                <td  width="" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td width=""><b><?php echo 'DGDA'; ?></b></td>
                                <td>
                                    <?php if($row->Type_13 == 'batch'): ?>
                                        <strong>Bulletin en lot</strong>
                                    <?php else :?>
                                        <strong>BL <?php echo isset($bl_info->serial) ? $bl_info->serial. ' '.$bl_info->number : ""; ?></strong>
                                    <?php endif;?>
                                    
                                </td>
                                <td class="text-blue">
                                    <?php echo $bl_info->currency. ' '.number_format($bl_info->amount,2,","," "); ?> 
                                </td>
                                <td class="text-black"><?php echo $agence; ?></td>
                                <td width="">
                                    <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                    
                                </td>
                                <td width="">
                                    <?php if($row->Lock_12 == 0): ?>
                                            <?php if($row->Type_13 == 'batch'): ?>
                                                <span><a style="cursor: pointer" onclick="view_batch(<?php echo $row->Paiementid_11; ?>)"><i class="fa fa-fw fa-pencil f14 text-blue f18"></i></a></span>
                                            <?php else: ?>
                                                <span><a style="cursor: pointer" onclick="view(<?php echo $row->Id_0; ?>)"><i class="fa fa-fw fa-pencil f14 text-blue f18"></i></a></span>
                                            <?php endif; ?>
                                    <?php else : ?>
                                        <?php if($row->Lock_12 == $userid): ?>
                                                <?php if($row->Type_13 == 'batch'): ?>
                                                    <span><a style="cursor: pointer" onclick="view_batch(<?php echo $row->Paiementid_11; ?>)" ><i class="fa fa-fw fa-pencil f14 text-blue f18"></i></a></span>
                                                <?php else: ?>
                                                    <span><a style="cursor: pointer" onclick="view(<?php echo $row->Id_0; ?>)" ><i class="fa fa-fw fa-pencil f14 text-blue f18"></i></a></span>
                                                <?php endif; ?>
                                        <?php else : ?>
                                                <span><a style="cursor: pointer" onclick="" href="#"><i class="fa fa-lock font-action-edit text-yellow f18"></i></a></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php 
                            $paiements = $paiements + $bl_info->amount;
                            #$commissions = $commissions + $row->Commission_26;
                            if($row->Status_2==1 ||$row->Status_2==2 ) $urgent = $urgent + 1;
                        } 
                        ?>


                        </tbody>    
                    </table>
                    <?php else:?>
                        <div class="col-md-12">
                                <section id="cat_list" class="text-center marginTop150">
                                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                    <span class="d-block p-2 f14 text-black">Aucun paiement trouv&eacute;!</span>
                                </section>
                        </div>
                    <?php endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?>
        
    </div>
    
</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
});

$("#contenter").unbind().on("click", ".item", function(){
        
        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});


$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgi').html('<?php echo number_format($paiements_dgi,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');
    
function view(id)
{
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');

    var url = '<?php echo base_url('rbo/taxbulletin/display/step_1_process'); ?>/'+id;

    $.get(url, function (data, status) {

        if(data == '0')
        {
            $("#message").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
        }
        else
        {
            $("#message").html('');
            $("#fullscreen").html(data);
        }
    });
}

function view_batch(id)
{
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');

    var url = '<?php echo base_url('rbo/taxbulletin/display/batch_step_1_process'); ?>/'+id;

    $.get(url, function (data, status) {

        if(data == '0')
        {
            $("#message").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
        }
        else
        {
            $("#message").html('');
            $("#pager").addClass('content');
            $("#pager").html(data);
        }
    });
    }
</script>