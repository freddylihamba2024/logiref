<?php
$paiements = 0;
$paiements_dgi = 0;
#$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2">
                        <h5 class="card-title ">Total paiements DGI-DGRAD</h5>
                        <p class="text-blue f18"> <b>CDF <span id="paiements_dgi"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2">
                        <h5 class="card-title">Total paiements DGDA</h5>
                        <p class="text-blue"> <b>CDF <span id="paiements"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2">
                        <h5 class="card-title ">Paiements en attente DGI- DGRAD</h5>
                        <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('attente')"><b ><span id="attente"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 ">
                        <h5 class="card-title">Paiements en attente DGDA</h5>
                        <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('urgents')"><b ><span id="urgent"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h1>Liste des paiements non valid&eacute;s</h1>
        <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements non valid&eacutes.</span></h5>
    </div>
    <div class="col-md-12">
        <div  id="message"></div>
<?php $chtml->box_body_opening('', true); ?>
        <div id="paiementslist">
        <?php if (!empty($bulletins)): ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th></th>
                            <th width="50">Date</th>
                            <th>D&eacute;signation</th>
                            <th>B&eacute;n&eacute;ficiaire</th>
                            <th>Recette</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th width="50">Op&eacute;rateur</th>
                            <th><span class="fa fa-fw fa-pencil f14"></span></th>
                            <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>

    <?php
    #Block last BL
    foreach ($bulletins as $row) {
        $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
        $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
        $dateTime = new DateTime($row->Date_1);
        $date = $dateTime->format('U');
        $deadline = date('Y-m-d', strtotime("+1 day", $date));
        ?>
                            <tr>
                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                <td  width="80" <?php if ($row->Status_2 == 4) echo 'class="text-green"';
                    elseif ($deadline > gmdate('Y-m-d')) echo 'class="text-black"';
                    elseif ($deadline == gmdate('Y-m-d')) echo 'class="text-orange"';
                    elseif ($deadline < gmdate('Y-m-d')) echo 'class="text-red"'; ?> >
        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php if ($row->Designation_23 == "") echo "Bulletin de liquidation / " . $row->Nif_9;
        else echo $row->Designation_23; ?></td>
                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                <td class="text-blue">
                                    <?php echo'CDF ' . number_format($row->Amount_12, 2, ",", " "); ?> 
                                </td>
                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                <td width="50">
                                    <?php if ($row->Customercode_35 != ""): ?> 
                                    <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                <?php else: ?> 
                                        <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                    <?php endif; ?> 
                                </td>
                                    <?php if ($row->Status_2 == 1) { ?>
                                    <td width="25">
                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_32 == $_SESSION['Logiref_agence']) { ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_9) && $row->Makerid_9 == $this->session->userdata['user_id'])) { ?>
                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                            <?php else: ?>
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                            <?php endif; ?>
                                        <?php } else { ?>
                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                <?php else: ?>
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                <?php endif; ?>
                                    <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                    <?php } else { ?>
                                    <td width="25">
                                        <?php if ($row->Lot_22 == "saisi"): ?>
                                            <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php else: ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php endif; ?>
                                    </td>
                                    <td width="25">
                                        <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . $row->Pdfcontent_18)): ?>
                                            <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                    <?php else: ?>
                                            <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                <?php endif; ?>
                                    </td>
                            <?php } ?>
                            </tr>
        <?php
    }
    ?>

                    </tbody>    
                </table>
<?php else: ?>
                <div class="col-md-12">
                    <section id="cat_list" class="text-center marginTop150">
                        <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                            <span class="d-block p-2 f14 text-black"> Aucun paiement trouv&eacute;!</span>
                            </div>
                    </section>
                </div>
<?php endif; ?>
        </div>
<?php $chtml->box_body_closing(); ?>

    </div>

</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
                                                $('#table').DataTable({
                                                    "paging": true,
                                                    "lengthChange": true,
                                                    "searching": true,
                                                    "ordering": true,
                                                    "info": true,
                                                    "autoWidth": false
                                                });

                                                $("#contenter").unbind().on("click", ".item", function () {

                                                    $("#close").addClass('hidden');
                                                    $("#close_form").removeClass('hidden');
                                                });


                                                $('#paiements').html('<?php echo number_format($paiements, 2, ",", " "); ?>');
                                                $('#paiements_dgi').html('<?php echo number_format($paiements_dgi, 2, ",", " "); ?>');
                                                $('#attente').html('<?php echo $suspend; ?>');
                                                $('#urgent').html('<?php echo $urgent; ?>');

                                                function view(id, regie)
                                                {
                                                    var url = '';
                                                    if (regie === 'DGDA')
                                                    {
                                                        '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
                                                            var url = "<?php echo base_url($module . '/taxbulletin/display/preview'); ?>/" + id;
                                                            '<?php else : ?>'
                                                            var url = "<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/" + id;
                                                            '<?php endif; ?>'
                                                    }
                                                    else if (regie === 'DGI')
                                                    {
                                                        '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
                                                            var url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
                                                            '<?php else : ?>'
                                                            var url = "<?php echo base_url($module . '/taxdeclaration/display/edit'); ?>/" + id;
                                                            '<?php endif; ?>'
                                                    }
                                                    else if (regie === 'DGRAD')
                                                    {
                                                        '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
                                                            var url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
                                                            '<?php else : ?>'
                                                            var url = "<?php echo base_url($module . '/taxnotes/display/edit'); ?>/" + id;
                                                            '<?php endif; ?>'


                                                    }

                                                    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                                                    $.get(url, {previous_menu: "paiements_rbo"}, function (data, status) {
                                                        $("#message").html('');
                                                        $("#pager").html(data);
                                                        $("#form").addClass('hidden');
                                                        $("#form").removeClass('hidden');
                                                    });
                                                }

                                                function view_manual(id, regie)
                                                {

                                                    var url = "<?php echo base_url($module . '/taxothers/display/preview'); ?>/" + id;
                                                    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                                                    $.get(url, function (data, status) {
                                                        $("#message").html('');
                                                        $("#pager").html(data);
                                                        $("#form").addClass('hidden');
                                                        $("#form").removeClass('hidden');
                                                    });
                                                }

                                                function viewPrepayment(id)
                                                {
                                                    '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
                                                        var url = "<?php echo base_url($module . '/taxprepayments/display/preview'); ?>/" + id;
                                                        '<?php else : ?>'
                                                        var url = "<?php echo base_url($module . '/taxprepayments/display/preview'); ?>/" + id;
                                                        '<?php endif; ?>'

                                                    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                                                    $.get(url, function (data, status) {
                                                        $("#message").html('');
                                                        $("#pager").html(data);
                                                        $("#form").addClass('hidden');
                                                        $("#form").removeClass('hidden');
                                                    });
                                                }

                                                function verification(id, regie)
                                                {
                                                    if (regie === 'DGI')
                                                    {
                                                        var url = "<?php echo base_url($module . '/taxdeclaration/display/rbo_verification'); ?>/" + id;
                                                    }
                                                    else if (regie === 'DGRAD')
                                                    {
                                                        var url = "<?php echo base_url($module . '/taxnotes/display/rbo_verification'); ?>/" + id;
                                                    }

                                                    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
                                                    $.get(url, {previous_menu: "paiements_rbo"}, function (data, status) {
                                                        $("#message").html('');
                                                        $("#pager").html(data);
                                                        $("#form").addClass('hidden');
                                                        $("#form").removeClass('hidden');
                                                    });
                                                }

                                                function print_payment(pid) {

                                                    var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + pid;
                                                    //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
                                                    // window.print();
                                                    var w = window.open(url);

                                                    $(w).ready(function () {
                                                        w.print();
                                                    });

                                                }

</script>
