<?php

    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $commissions = 0;
    $suspend = 0;
    $urgent = 0;
    $i = 0;

?>

<div id="pager"  class="col-md-12">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span class="">Total paiements</span><br/><br/>
                        <p class="text-blue f18"> <b>CDF <span id="paiements"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span class="">Total commissions</span><br/><br/>
                        <p class="text-green f18"><b>CDF <span id="commissions"></span></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements en attente</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer" onclick="filter('attente')" ><b><span id="attente"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements urgents</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer" onclick="filter('urgents')" ><b><span id="urgent"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8">
            <h1>Paiements valid&eacutes</h1>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements valid&eacutes.</span></h5>
    </div>
    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
    <div class="col-md-4 center bLeft">

    </div>
    <div class="col-md-12">
        <div  id="loader"></div>

            <?php $chtml->box_body_opening('', true); ?>
            <div id="paiementslist">
                    <?php if(!empty($encaissements)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th>Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-tasks f14"></span></th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php  foreach($encaissements as $row){ 
                                $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                <tr>
                                    <td width="5"><b>#</b></span></td>
                                    <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                    <td><?php echo $row->Typerecette_17; ?></td>
                                    <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                          <br/>
                                          <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                    </td>
                                    <?php if($row->Checkerid_10==0){ ?>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                               <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                            <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')){ ?>
                                               <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                            <?php }else { ?>
                                               <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                            <?php } ?>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                        </td>
                                    <?php }else{ ?>
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                                            <td width="25">
                                                <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="reverser('<?php echo $row->Id_0;?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                            </td>
                                        <?php }else{ ?>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                            </td>
                                        <?php } ?>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php 
                                    $paiements = $paiements + $row->Contrevaleur_22;
                                    $commissions = $commissions + $row->Commission_23;
                            } 
                            ?>
                        </tbody>
                    </table>
                    <?php else:?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                Aucun paiement trouv&eacute;!<br/>
                            </div>
                        </section>
                    <?php endif;?>
                </div>
            </div>
            <?php $chtml->box_body_closing(); ?>

    </div>
    <?php echo form_close(); ?>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
    $('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
    $('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
    $('#attente').html('<?php echo number_format($suspend,2,","," "); ?>');
    $('#urgent').html('<?php echo number_format($urgent,2,","," "); ?>');
        
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50,
    });

    function view(id, regie)
    {
            var url ='';
            if(regie === 'DGRAD')
            {
                var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
            }

            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);

            });
    }

    function printQuittance(file)
    {
            var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
            //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
            // window.print();
            var w = window.open(url);

    }

    function print_payment(pid){

            var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
            //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
            // window.print();
            var w = window.open(url);

            $(w).ready(function(){
                w.print();
            });

    }
</script>