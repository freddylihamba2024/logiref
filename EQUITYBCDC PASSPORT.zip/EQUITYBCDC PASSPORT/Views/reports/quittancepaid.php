<?php 

$paiements = 0;
$paiements_dgda = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>

<div class="row">
    <div id="pager"  class="col-md-12"> 
<!--    <div class="row">
        <div class="col-md-12">
            <h1 class="text-blue f30">Liste des paiements valid&eacutes</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements valid&eacutes.</span></p>
        </div>
    
    </div>-->
    
    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="col-md-4 center bLeft">

        </div>
        <div class="row">
            <div class="col-md-12">
                <div  id="loader"></div>

                <?php $chtml->box_body_opening('', true); ?>
                    <div id="paiementslist">
                        <?php if(!empty($bulletins)): ?>
                            <table id="table" class="table table-hover table-striped">
                                <thead>
                                    <tr style="background-color: #d2d6de;">
                                        <th></th>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>B&eacute;n&eacute;ficiaire</th>
                                        <th>Recette</th>
                                        <th>Montant</th>
                                        <th>Commissions</th>
                                        <th>Op&eacute;rateur</th>
                                        <th><span class="fa fa-fw fa-tasks f14"></span></th>
    <!--                                    <th><span class="fa fa-fw fa-folder f14"></span></th>-->
                                        <th><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($bulletins as $row){ 
                                        $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                                        $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                        $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                        $results = json_decode($row->Results_13);
                                        $recieptDate = explode("/",$results->receiptDate);
                                        $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                                    ?>
                                       <tr>
                                            <td width="5"><b><?= ++$i; ?></b></span></td>
                                            <td width="50" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                            </td>
                                            <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                            <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                            <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                            <td class="text-blue">
                                                <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                            </td>
                                            <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                            <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                            <td width="25">
                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" class="item"><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                            </td>
                                            <?php if($row->Status_2!=3){ ?>
                                                <td width="25">
                                                    <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                                       <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->Year_5."".$row->Serie_7."".$row->Number_8; ?>" name="bulletins[]" />
                                                    <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$userid){ ?>
                                                       <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                                    <?php } ?>
    <!--                                                   <a class="cursor-pointer" onclick="view('<?php //echo $row->Id_0; ?>','DGDA')" id="item<?php //echo $row->Id_0; ?>" data-id-item="<?php //echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>-->
                                                    <?php //} ?>
                                                </td>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                </td>
                                            <?php }else{ ?>
                                                 <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>
                                                    <td width="25">
                                                        <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="reverser('<?php echo $row->Id_0;?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                                                    </td>
                                                <?php endif;?>
    <!--                                                <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php //echo $row->Id_0; ?>','DGDA')" id="item<?php //echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                    </td>-->
                                                <?php //} ?>
                                                <td width="25">
                                                    <?php if(isset($row->Pdfcontent_18) && $row->Pdfcontent_18 !=""):?>
                                                        <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    <?php else: ?>
                                                       <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php 
                                            $paiements_dgda = $paiements_dgda + $row->Amount_12;
                                            #$commissions = $commissions + $row->Commission_26;
                                            if($row->Status_2 == 3) $urgent = $urgent + 1;
                                    } 
                                    ?>

                                </tbody> 
                            </table>
                        <?php else:?>
                        <div class="col-md-12">
                            <section id="cat_list" class="text-center marginTop150">
                                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                    <span class="d-block p-2 f14 text-black">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                               
                            </section>
                        </div>
                        <?php endif;?>
                    </div>
                <?php $chtml->box_body_closing(); ?>

            </div>
        </div>
    <?php echo form_close(); ?>
</div>

</div>
<script type="text/javascript">
$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgda').html('<?php echo number_format($paiements_dgda,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

$("#contenter").unbind().on("click", ".item", function(){
        
        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});
    
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
});

function view(id, regie)
{
        var url ='';
        if(regie === 'DGDA')
        {
             var url ="<?php echo base_url($module.'/taxbulletin/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGI')
        {
             var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGRAD')
        {
             var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
        }

        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get(url,{previous_menu:"pending"}, function(data, status){
            $("#loader").html('');
            $("#pager").html(data);

        });
}

function printQuittance(file)
{
        var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);
        
}

function print_payment(pid){

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}
</script>
