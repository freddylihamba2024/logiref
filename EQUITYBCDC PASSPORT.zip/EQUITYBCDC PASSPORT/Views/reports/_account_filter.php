<?php if(!empty($comptes)): ?>
    <div class="table-responsive">
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-aqua text-white">
                    <th>#</th>
                    <th>Agence</th>
                    <th width="50">Type</th>
                    <th width="50">Devise</th>
                    <th width="150">Compte</th>
                    <th width="50">B&eacute;n&eacute;ficiaire</th>
                    <th with="">Recette</th>
                    <th>Maker</th>
                    <th>Checker</th>
                    <th width="100">Validation</th>
                    <!--<th><span class="fa fa-fw fa-edit f14"></span></th>-->
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; foreach($comptes as $row){ ?>
                    <tr>
                        <td width="5"><?php echo $i; ?></td>
                        <td><?php if(isset($guichets[$row->Agence_12])) echo $guichets[$row->Agence_12];?></td>
                        <td width="50"><?php echo ' '.$row->Type_4;?></td>
                        <td class="bleu" width="50"><?php echo $row->Devise_8;?></td>
                        <td width="150"><?php if($row->Type_4!='CAC' || $row->Type_4!='CPI') echo '<b>'.$row->Agenceid_15.'</b>'; else echo '<span class="text-red">'.$row->Agenceid_15.'</span>'; ?><?php if($row->Compte_6!='') echo '-'.$row->Compte_6;?><?php if($row->Clef_7!='') echo '-'.$row->Clef_7;?></span></td>
                        <td width="50"><?php echo ' '.$row->Beneficiaires_5;?></td>
                        <td width="50"><?php echo ' '.$row->Recette_13;?></td>
                        <td>
                            <?php echo(isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';?></td>
                        <td>
                            <?php if($row->Checkerid_11==0){ ?>
                              <span class="text-red"> - </span>
                            <?php }else {?>
                             <?php echo(isset($users[$row->Checkerid_11]))?$users[$row->Checkerid_11]:' - ';?>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if($row->Checkerid_11==0){ ?>
                              <span class="text-red"> En attente </span>
                            <?php }else {?>
                              <?php echo $row->Validation_10;?>
                            <?php } ?>
                        </td>
                        <!--<td width="25" align="right">
                            <?php if($_SESSION['Logiref_role']==1 || $_SESSION['Logiref_role']==2){ ?>
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw fa-pencil f14 text-orange"> </span></a>
                            <?php }else {?>
                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                            <?php } ?>
                        </td>-->
                    </tr>
                <?php $i++;} ?>
            </tbody>    
        </table>
    </div>
<?php else: ?>
    <section id="cat_list">
        <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 10px;">
        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            Aucun compte trouv&eacute;!<br/>
        </div>
    </section>
<?php endif;?>

<script type="text/javascript">
        $('#table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            paging: true,
            searching: false
        });
</script>