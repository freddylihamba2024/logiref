<?php
$paiements = 0;
$paiements_dgi = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>

<div class="col-md-12 pl-0 pr-0" id="loader"></div>
<div id="pager">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <div>
                <?php if ($_SESSION['Logiref_role'] == 2 && isset($options['ALL']['client-exchange-rate-override'])): ?>
                    <h1 class="text-blue f30">Paiements en attente de validation de taux</h1>
                <?php else: ?>
                    <h1 class="text-blue f30">Liste des paiements non valid&eacute;s</h1>
                <?php endif; ?>
                <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements non valid&eacutes.</span></p>
            </div>

        </div>
    </div>

    <div class="tab_container">
        <div class="tabs">
            <div class="tab tab-active" onclick="openTab(event, 'paiements_agence')">
                Paiements en Agence
            </div>
            <div class="tab" onclick="openTab(event, 'paiements_enligne')">
                Paiements en Ligne
            </div>
        </div>
        <div class="tab-item-container">
            <!-- tab-item for paiements en agence -->
            <div class="tab-item" id="paiements_agence">
                <div class="row">
                    <div class="col-md-12">
                        <div id="message"></div>
                        <?php $chtml->box_body_opening('', true); ?>
                            <div class="row mb-3">
                                <div class="col-md-12 text-right">
                                    <input type="text" id="searchInput" onkeyup="filterTable()"
                                        class="form-control d-inline-block p-2 rounded shadow-sm"
                                        placeholder="🔍 Rechercher..."
                                        style="max-width: 150px; font-size: 14px; border: 1px solid #ced4da;">
                                </div>
                            </div>
                            <div id="paiementslist">
                                <?php if (!empty($encaissements_immatriculation_agence)): ?>
                                    <table id="table" class="table table-hover table-striped">
                                        <thead>
                                            <tr class="bg-gray f12">
                                                <th class="f12">#</th>
                                                <th class="f12" width="50">Date</th>
                                                <th class="f12">D&eacute;signation</th>
                                                <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                                <th class="f12">Recette</th>
                                                <th class="f12">Montant</th>
                                                <th class="f12">Commissions</th>
                                                <th class="f12" width="50">Op&eacute;rateur</th>
                                                <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                                <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            #Block DGI Plaque d'immatriculation
                                            foreach ($encaissements_immatriculation_agence as $row) {
                                                $guichet = (isset($guichets[$row->Guichet_32])) ? $guichets[$row->Guichet_32] : ' - ';
                                                $operateur = (isset($users[$row->Makerid_35])) ? $users[$row->Makerid_35] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 3)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Requerant_9 ?></td>
                                                    <td width="20"><b><?php echo "DGI" ?></b></td>
                                                    <td><?php
                                                        echo "<span class='text-muted'>" . $row->Reference_6 . "</span><br/>" . $row->Article_23;
                                                        ?></td>
                                                    <td class="text-blue"><?php echo $row->Devise_11 . ' ' . number_format($row->Amount_10, 2, ",", " "); ?>
                                                    </td>
                                                    <td class="text-black"><?php echo $row->Devise_15 . ' ' . number_format($row->Commission_14, 2, ",", " "); ?></td>
                                                    <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                    <?php if ($row->Status_2 == 2 && $row->Checkerid_36 == 0) { ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation', '<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_35 == $userid) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation', '<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation', '<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation', '<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation', '<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        </td>
                                                    <?php } ?>
                                                </tr>
                                            <?php
                                                if ($row->Status_2 == 1 && $row->Checkerid_36 == 0)
                                                    $suspend = $suspend + 1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="col-md-12">
                                        <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block  "><span class="fa fa-flask text-gray mystyle4"></span></span></br>
                                            <span class="d-block f14 text-black p-2">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                                        </section>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
            </div>

            <!-- tab-item for paiements en ligne -->
            <div class="tab-item d-none" id="paiements_enligne">
                <div class="row">
                    <div class="col-md-12">
                        <div id="message"></div>
                        <?php $chtml->box_body_opening('', true); ?>
                        <div class="row mb-3">
                                <div class="col-md-12 text-right">
                                    <input type="text" id="searchInput" onkeyup="filterTable()"
                                        class="form-control d-inline-block p-2 rounded shadow-sm"
                                        placeholder="🔍 Rechercher..."
                                        style="max-width: 150px; font-size: 14px; border: 1px solid #ced4da;">
                                </div>
                            </div>
                            <div id="paiementslist">
                                <?php if (!empty($encaissements_immatriculation_enligne)): ?>
                                    <table id="table" class="table table-hover table-striped">
                                        <thead>
                                            <tr class="bg-gray f12">
                                                <th class="f12">#</th>
                                                <th class="f12" width="50">Date</th>
                                                <th class="f12">D&eacute;signation</th>
                                                <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                                <th class="f12">Recette</th>
                                                <th class="f12">Montant</th>
                                                <th class="f12">Commissions</th>
                                                <th class="f12" width="50">Op&eacute;rateur</th>
                                                <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                                <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            #Block DGI Plaque d'immatriculation en ligne
                                            foreach ($encaissements_immatriculation_enligne as $row) {
                                                $guichet = (isset($guichets[$row->Guichet_32])) ? $guichets[$row->Guichet_32] : ' - ';
                                                $operateur = (isset($users[$row->Makerid_35])) ? $users[$row->Makerid_35] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 3)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Requerant_9 ?></td>
                                                    <td width="20"><b><?php echo "DGI" ?></b></td>
                                                    <td><?php
                                                        echo "<span class='text-muted'>" . $row->Reference_6 . "</span><br/>" . $row->Article_23;
                                                        ?></td>
                                                    <td class="text-blue"><?php echo $row->Devise_11 . ' ' . number_format($row->Amount_10, 2, ",", " "); ?>
                                                    </td>
                                                    <td class="text-black"><?php echo $row->Devise_15 . ' ' . number_format($row->Commission_14, 2, ",", " "); ?></td>
                                                    <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                    <?php if ($row->Status_2 == 2 && $row->Checkerid_36 == 0) { ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation'','<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_35 == $userid) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation'','<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation'','<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation'','<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGI_immatriculation'','<?php echo $row->ValidateBySiop_39; ?>', '<?php echo $row->Typerecette_16; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        </td>
                                                    <?php } ?>
                                                </tr>
                                            <?php
                                                if ($row->Status_2 == 1 && $row->Checkerid_36 == 0)
                                                    $suspend = $suspend + 1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="col-md-12">
                                        <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block  "><span class="fa fa-flask text-gray mystyle4"></span></span></br>
                                            <span class="d-block f14 text-black p-2">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                                        </section>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br/><br/>

<script type="text/javascript">

    function view(id, regie, siop, recette = null) {
        var role = "<?php echo $_SESSION['Logiref_role']; ?>";
        var url = '';

        if (role === "3" && siop === "1"){
            var url = "<?php echo base_url($module . '/taximmatriculation/display/preview'); ?>/" + id;
        }
        else {
            var url = "<?php echo base_url($module . '/taximmatriculation/display/edit'); ?>/" + id;
        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {
            previous_menu: "nvalidated"
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('d-none');
            $("#form").removeClass('d-none');
        });
    }

    function print_payment(pid) {

        var url = '<?php echo base_url($module . '/taximpression/display/attestation_immatriculation'); ?>/' + pid;
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    }

    function openTab(event, tabContentId) {
        $('.tab').removeClass('tab-active');
        $(".tab-item").addClass('d-none');

        event.currentTarget.classList.add('tab-active');
        $("#" + tabContentId + "").removeClass('d-none');
    }

    function filterTable() {
        var input = document.getElementById("searchInput");
        var filter = input.value.toLowerCase();
        var table = document.getElementById("table");
        var tr = table.getElementsByTagName("tr");

        for (var i = 1; i < tr.length; i++) { // Commence à partir de 1 pour ignorer l'en-tête
            var td = tr[i].getElementsByTagName("td");
            var showRow = false;

            for (var j = 0; j < td.length; j++) {
                if (td[j] && td[j].textContent.toLowerCase().indexOf(filter) > -1) {
                    showRow = true;
                    break;
                }
            }
            tr[i].style.display = showRow ? "" : "none";
        }
    }

</script>