<div class="row" style="margin-top: -50px;">
        <div class="col-md-12">
                <div class="row">
                        <div class="col-md-12 ">
                                <h2 class="f30 text-blue">Rapport des paiements</h2>
                                <p class="page-header"><span class="f12 text-black">Cette sections vous permet de sélectionner le rapport à consulter.</span></p>     
                        </div>
                </div>
<!--                <div class="row">
                    <div class="col-md-12 p-0">
                            <div id="loader-sub-menu"></div><br/>
                    </div>
                </div>-->
                <div class="row">
                        <div class="col-md-12 p-0" id="">
                                <div class="col-md-12 p-0">
                                        <div class="box-body">
                                                <?php $chtml->box_body_opening("", true);?>
                                                <div class="row">
                                                        <div class="col-md-12">
                                                                <div class="form-group">
                                                                        <label for="type" class="f12 text-black">Selectionner le type des rapports</label>
                                                                        <?php echo form_dropdown('type', $reports, "", 'class="form-control default-width" id="type" '); ?>
                                                                </div>
                                                        </div>
                                                </div>
                                                <?php $chtml->box_body_closing(); ?>
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col-md-12 p-0" id="">
                        
                        <div class="col-md-12 p-0">
                            <div id="loader-sub-menu">
                            </div>
                            <div class="box-body" id="sub-menu">
                                    <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block p-2 "><span class="fa fa-ban fa-4x text-navy mystyle4" ></span></br>
                                            <span class="d-block p-2 f12 text-black">Aucun rapport des paiements sélectionné.</span>
                                    </section>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
</div>

<script type="text/javascript">
    
    $('#type').change(function(){
        var type = $('#type option:selected').val();
        
        if(type != '')
        {
            action(type);
        }
    });
    
    
    function action(which) {
         $("#loader-sub-menu").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
         if (which === 'declaration'){
            $.get("<?php echo base_url($module.'/taxreports/display/report_dgi'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'IPRIER') {
            $.get("<?php echo base_url($module . '/taxreports/display/report_iprier'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === 'Plaques') {
            $.get("<?php echo base_url($module . '/taxreports/display/report_plaques'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'note_perception') {
            $.get("<?php echo base_url($module . '/taxreports/display/report_dgrad'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'gardienage') {
            $.get("<?php echo base_url($module . '/taxreports/display/taxe_gardeinnage'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'dgda') {
            $.get("<?php echo base_url($module . '/taxreports/display/report_paydgda'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
        if (which === 'deleted_dgda') {
            $.get("<?php echo base_url($module . '/taxreports/display/report_deletedgda'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }

         if (which === 'tresor') {
            $.get("<?php echo base_url($module . '/taxreports/display/paiement_tresor'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
        if (which === 'propre') {
           $.get("<?php echo base_url($module . '/taxreports/display/paiement_propre'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
         if (which === 'fondpropre') 
         {
            $.get("<?php echo base_url($module . '/taxreports/display/fond_propre'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
         }
         if (which === 'users') 
         {
            $.get("<?php echo base_url($module . '/taxreports/display/report_users'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
        }
       
        if(which === 'commissions')
        {
            $.get("<?php echo base_url($module.'/taxreports/display/commissions'); ?>", function (data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
            });
        }
        
        if(which === 'prepaids')
        {
            $.get("<?php echo base_url($module.'/taxreports/display/report_prepayments'); ?>", function (data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
            });
        }
        if(which === 'prepaid')
        {
            $.get("<?php echo base_url($module.'/taxreports/display/pay_prepayments'); ?>", function (data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
            });
        }
        if(which === 'newtax')
        {
            $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_newtax'); ?>", function (data, status) {
               $("#loader").html('');
               $("#sub-menu").html(data);
            });
        }
        if(which === 'espece')
        {
            $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_espece'); ?>", function (data, status) {
               $("#loader").html('');
               $("#sub-menu").html(data);
            });
        }
         if(which === 'reversepayment')
        {
            $.get("<?php echo base_url($module.'/taxreports/display/reverses'); ?>", function (data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
            });
        }
        if(which === 'noreverse')
        {
            $.get("<?php echo base_url($module.'/taxreports/display/penalities'); ?>", function (data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
            });
        }
        if(which === 'latereverse')
        {
            $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/latereverse'); ?>", function (data, status) {
               $("#loader").html('');
               $("#sub-menu").html(data);
            });
        }
        

     }
    

</script>