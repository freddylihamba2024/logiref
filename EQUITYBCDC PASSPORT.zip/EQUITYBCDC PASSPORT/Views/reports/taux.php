<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<?php 
if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates']!==0){
    $bank = json_decode($_SESSION['Bank_rates'], true);
    $usd = $bank['Dollar_4'];
    $eur = $bank['Euro_5'];
    $rand = $bank['Rand_6'];
    $pound = $bank['Pound_7'];
}else {
    $usd = $eur = $rand = $pound = 0.0;    
}
?>


<div id="pager" class="col-md-12">
        <div class="col-md-1">

        </div>

        <div class="col-md-12">
            <div class="col-md-12">
                    <h1 class="f30 text-blue">Tauxss de change</h1>
                    <p class="page-header"><span class="f12 text-black">Publier les nouveaus taux de change ici.</span></p>
            </div>
            
            <div id="loader" class="col-md-12"></div>

            <?php if($_SESSION['Logiref_role']==2){ ;?>
                <div class="col-md-12">
                    <?php $chtml->box_body_opening("", true); ?>
                    <?php echo form_open_multipart('', array('id' => 'mainform', 'class' => '')) ?>
                    <div class="statistic-box no-border">
                            <div class="col-sm-5 col-xs-5" >
                                <div class="input-group">
                                    <span class="input-group-addon"><label for="project">Agence</label></span> 
                                    <?php echo form_dropdown('agence',$agences, '', 'class="form-control" id="project"'); ?>
                                </div>
                            </div>
                            <div class="col-sm-5 col-xs-6 no-padding">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">Du</span>
                                    <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y/m/d') ?>" id="datepicker1" type="text">
                                    <span class="input-group-addon">Au</span>
                                    <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y/m/d') ?>"  id="datepicker2" type="text">
                                </div>
                            </div>
                            <div class="col-sm-2 col-xs-2">
                                    <button type="submit" class="btn btn-success pull-right"><i class="fa fa-search"></i>&nbsp;&nbsp;Filtrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            </div>
                    </div>
                    <?php echo form_close(); ?>
                    <?php $chtml->box_body_closing(); ?>
                </div>
            <?php }?>

            <div class="col-md-12">
                <?php $chtml->box_body_opening('', false); ?>
                    <div class="col-md-4">
                        <div class="statistic-box" style="margin-top:10px;">
                                <ul class="list-group clear-list m-t">
                                    <li class="list-group-item fist-item">
                                        <span class="pull-right">
                                            <span class="label label-success" style="color:white !important;">CDF <?php echo number_format($usd,2,","," "); ?></span>
                                        </span>
                                        <i class="fa fa-fw fa-dollar text-black"></i> Dollars
                                    </li>
                                    <li class="list-group-item">
                                        <span class="pull-right">
                                           <span class="label label-info" style="color:white !important;">CDF <?php echo number_format($eur,2,","," "); ?></span>
                                        </span>
                                        <i class="fa fa-fw fa-euro text-black"></i>Euros
                                    </li>
                                    <li class="list-group-item">
                                        <span class="pull-right">
                                            <span class="label label-danger" style="color:white !important;">CDF <?php echo  number_format($pound,2,","," "); ?></span>
                                        </span>
                                        <i class="fa fa-fw fa-gbp text-black"></i>Pounds
                                    </li>
                                    <li class="list-group-item">
                                        <span class="pull-right">
                                            <span class="label label-warning" style="color:white !important;">CDF <?php echo number_format($rand,2,","," "); ?></span>
                                        </span>
                                        <span class="text-black"><b>&nbsp;R</b></span> Rands
                                    </li>
                                </ul>
                        </div>
                    </div>
                    <div class="col-md-8 no-padding">
                        <div class="bLeft">
                            <div class="box-body margin padding">
                                <canvas id="lineChart" height="165" style="display: block; width: 436px; height: 165px;" width="436"></canvas>
                            </div>
                        </div>
                    </div>

                <?php $chtml->box_body_closing(); ?>
            </div>
            <div class="col-md-12" id="content">
                <?php if(!empty($taux)): ?>
                <?php $chtml->box_body_opening('', true); ?>
                    <table id="<?php echo(count($taux) > 10)? "table" :"";?>" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th>#</th>
                                <th>Date</th>
                                <th>Agence</th>
                                <th>Dollar</th>
                                <th>Euro</th>
                                <th>Pound</th>
                                <th>Rand</th>
                                <th>Validation</th>
                                <th>Publi&eacute; par</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        foreach($taux as $row){
                        ?>
                            <tr>
                                <td width="5"><?php echo $row->Id_0; ?></td>
                                <td width="150"><?php echo $row->Date_1; ?></td>
                                <td>
                                    <?php if($row->Status_2==1) echo '<b>'. ucfirst(strtolower($agences[$row->Agence_8])).'</b>'; else echo '<span class="text-red">'.ucfirst(strtolower($agences[$row->Agence_8])).'</span>'; ?>
                                </td>
                                <td width="110"><?php echo 'CDF '.number_format($row->Dollar_4,2,","," "); ?></td>
                                <td width="110"><?php echo 'CDF '.number_format($row->Euro_5,2,","," "); ?></td>
                                <td width="110"><?php echo 'CDF '.number_format($row->Pound_7,2,","," "); ?></td>
                                <td width="110"><?php echo 'CDF '.number_format($row->Rand_6,2,","," "); ?></td>
                                <td class="text-blue">
                                    <?php 
                                    if (isset($users[$row->Checkerid_11])) echo $users[$row->Checkerid_11]; 
                                    elseif ($row->Agence_8==$_SESSION['Logiref_agence'] && $row->Checkerid_11==0 && $_SESSION['Logiref_role']==3) echo '<a id="Validate" class="btn btn-warning" href="#" class="text-green"> Confirmer </a>';
                                    else echo '<span  class="text-red"> En attente </span>'; 
                                    ?>
                                </td>
                                <td class="text-green">
                                    <?php 
                                        echo $users[$row->Makerid_10]; 
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>    
                    </table>

                <?php $chtml->box_body_closing(); ?>
                <?php else: ?>
                    <section id="cat_list">
                        <h4 class="page-header" align="center"><b></b></h4>
                        <div class="row fontawesome-icon-list f14 tCenter">
                            <span class="fa fa-warning text-gray mystyle4"></span>
                            <br/><br/>
                            Aucun taux enregistr&eacute; pour ce mois en cours !
                            <br/><br/>
                        </div>
                    </section>
                <?php endif;?>
            </div>    
        </div>
        
        <div class="col-md-1">
        </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chartJs/Chart.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "aaSorting":[[ 0, 'desc' ]]
});

var lineData = {
        labels: [<?php echo $chart['months']; ?>],
        datasets: [
            {
                label: "Dollars",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(7,122,19,255)",
                pointBackgroundColor: "rgba(7,122,19,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Dollar']; ?>]
            },
            {
                label: "Euros",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(16,188,234,255)",
                pointBackgroundColor: "rgba(16,188,234,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Euro']; ?>]
            },
            {
                label: "Pounds",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(180,15,11,255)",
                pointBackgroundColor: "rgba(180,15,11,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Pound']; ?>]
            },
            {
                label: "Rands",
                backgroundColor: "rgba(220,220,220,0.5)",
                borderColor: "rgba(253,126,15,255)",
                pointBackgroundColor: "rgba(251,101,21,255)",
                pointBorderColor: "#fff",
                data: [<?php echo $chart['Rand']; ?>]
            }
        ]
    };
    var lineOptions = 
    {
        responsive: true
    };

    var ctx = document.getElementById("lineChart").getContext("2d");
    new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});

$("#add").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      <?php if($_SESSION['Logiref_role']==4){ ?>
            $.get("<?php echo base_url($module.'/bank/display'); ?>/taux/", function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
            });
      <?php }else { ?>
            $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
      <?php } ?>
      
});

$("#Validate").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/bank/display'); ?>/taux/", function(data, status){
            $("#loader").html('');
            $("#fullscreen").html(data);
      });
});

function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      
}

$("#mainform").on('submit', function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    <?php if($_SESSION['Logiref_role']!=4){ ?>
    var url = '<?php echo base_url($module.'/bank/display/taux_filter'); ?>';
    <?php }else { ?>
            $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
    <?php } ?>
    var data = new FormData(this);
    $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'html', 
        encode      : true,
        contentType : false,
        cache       : false,
        processData :false,
        success: function (result) {
            $('#loader').html('');
            $("#content").html(result);
        },
        error: function (error) {
            alert('ERROR!' + error);
        }
       });      
});

 //Datepicker
    $('#data_5 .input-daterange').datepicker({
            keyboardNavigation: false,
            forceParse: false,
            autoclose: true
        });
    $('#datepicker1').datepicker({
        format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
        format: 'yyyy-mm-dd'
    });
    
</script>


