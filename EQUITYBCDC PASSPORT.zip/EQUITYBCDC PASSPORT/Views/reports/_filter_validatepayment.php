<?php 

$paiements = 0;
$paiements_dgda = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>

<?php if(!empty($encaissements) || !empty($bulletins)): ?>
<table id="table" class="table table-hover table-striped">
    <thead>
        <tr style="background-color: #d2d6de;">
            <th></th>
            <th>Date</th>
            <th>Client</th>
            <th>B&eacute;n&eacute;ficiaire</th>
            <th>Recette</th>
            <th>Montant</th>
            <th>Commissions</th>
            <th>Op&eacute;rateur</th>
            <th><span class="fa fa-fw fa-tasks f14"></span></th>
            <th><span class="fa fa-fw fa-folder f14"></span></th>
            <th><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
        </tr>
    </thead>
    <tbody>

        <?php  foreach($encaissements as $row):
            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        ?>
            <tr>
                <td width="5"><b><?= ++$i; ?></b></span></td>
                <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                </td>
                <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                <td><?php echo $row->Typerecette_17; ?></td>
                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                        <br/>
                        <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                    <?php endif;?>
                </td>
                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                <td width="25">
                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                </td>
                <?php if($row->Checkerid_10==0){ ?>
                    <td width="25">
                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$userid){ ?>
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                        <?php }else { ?>
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                        <?php } ?>
                    </td>
                    <td width="25">
                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                    </td>
                <?php }else{ ?>
                    <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                        <td width="25">
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="reverser('<?php echo $row->Id_0;?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                        </td>
                    <?php }else{ ?>
                        <td width="25">
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                        </td>
                    <?php } ?>
                    <td width="25">
                        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                            <a class="cursor-pointer" onclick="" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span></a>
                        <?php else: ?>
                            <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                        <?php endif; ?>
                    </td>
                <?php } ?> 
            </tr>
        <?php 
                $paiements = $paiements + $row->Contrevaleur_22;
                $commissions = $commissions + $row->Commission_23;
                #var_dump($paiements);die;
                #var_dump($commissions);die;
                if($row->Status_2==1) $suspend = $suspend + 1;
                #var_dump($row->Status_2);die;

            endforeach;
        ?>

        <!-- Bulletins -->
        <?php foreach ($bulletins as $row):
                    $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                    $dateTime = new DateTime($row->Integration_16);
                    $date = $dateTime->format('U');
                    $deadline = date('Y-m-d', strtotime("+1 day", $date));
                    $results = json_decode($row->Results_13);
                                        
                    if (isset($results->receiptDate)) $recieptDate = explode("/", $results->receiptDate);
                    else $recieptDate[2] = date('Y');

                    $receiptNumber = isset($results->receiptNumber)?$results->receiptNumber:"";
                    $receiptSerial = isset($results->receiptSerial)?$results->receiptSerial:"" ;
                    $nodeid = $recieptDate[2] . '' . $receiptSerial . '' .$receiptNumber ; 
            ?>
            <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                <td width="5"><b><?php echo ++$i; ?></b></span></td>
                <td width="50" 
                    <?php
                    if ($row->Status_2 == 4)
                        echo 'class="text-green"';
                    elseif ($deadline > gmdate('Y-m-d'))
                        echo 'class="text-black"';
                    elseif ($deadline == gmdate('Y-m-d'))
                        echo 'class="text-orange"';
                    elseif ($deadline < gmdate('Y-m-d'))
                        echo 'class="text-red"';
                    ?>
                >
                    <?php echo $row->Integration_16; ?>
                </td>
                <td class="text-blue"><?=  ($row->Designation_23 == "") ? "Bulletin de liquidation / " . $row->Nif_9 : $row->Designation_23;?></td>
                <td width="20"><b><?= "DGDA" ?></b></td>
                <td><?= 'L' . '' . $row->Number_8; ?></td>
                <td class="text-blue"><?='CDF ' . number_format($row->Amount_12, 2, ",", " "); ?> </td>
                <td class="text-black"><?php echo $row->Devise_27.' '.number_format($row->Commission_26,2,","," "); ?></td>
                <td><?= (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - '; ?></td>
                <td width="25">
                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                </td>
                <td width="25">
                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                </td>
                <td width="25">
                    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                        <a class="cursor-pointer" onclick="" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span></a>
                    <?php else: ?>
                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>

    </tbody> 
</table>
<?php else:?>
<div class="col-md-12">
    <section id="cat_list" class="text-center marginTop150">
            <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
            <span class="d-block p-2 f14 text-black">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>

    </section>
</div>
<?php endif;?>

<script type="text/javascript">

$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgda').html('<?php echo number_format($paiements_dgda,2,","," "); ?>');
$('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
</script>


