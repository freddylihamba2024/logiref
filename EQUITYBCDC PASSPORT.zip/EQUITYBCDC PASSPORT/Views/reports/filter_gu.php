<?php $chtml->box_body_opening('', true); ?>
<?php if (!empty($encaissements) || !empty($encaissements_from_reporting)): ?>
    <div class="col-md-12 no-padding">
        <table class="table table-hover table-striped " id="table">
            <thead>
                <tr class="bg-aqua-active">
                    <th width="5">#</th>
                    <th width="">Date</th>
                    <th width="10">R&eacute;gie</th>
                    <th width="">Client</th>
                    <th width="">Recette</th>
                    <th width="">Service</th>
                    <th width="">Montant</th>
                    <th width="">Commissions</th>
                    <th width="">Guichet</th>
                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                </tr>
            </thead>
            <tbody >

                <!-- encaissements -->
                <?php
                $paiements = 0;
                $commissions = 0;
                $suspend = 0;
                $urgent = 0;

                foreach ($encaissements as $row) {
                    ?>
                    <tr>
                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                        <td <?php if ($row->Datevaleur_31 !== gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Datevaleur_31; ?></td>
                        <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                        <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                        <td><?php echo $row->Typerecette_17; ?></td>
                        <td><?php echo $services[$row->Service_16]; ?></td>
                        <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?></td>
                        <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                        <td><?php echo '<span  class="text-blue">' . $guichets[$row->Guichet_21] . '</span>'; ?></td>
                        <?php if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) { ?>
                            <td width="20">
                                <?php
                                if ($_SESSION['Logiref_role'] == 3 && $row->Agence_20 == $_SESSION['Logiref_agence']) {
                                    echo '<span  class="text-red"> En attente </span>';
                                    ?>
                                <?php } else { ?>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Sydonia_44; ?>')" ><span class="fa fa-fw text-green fa-folder f14"> </span></a>
                                <?php } ?>
                            </td>
                        <?php } else { ?>
                            <td width="25">
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Sydonia_44; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            </td>
                        <?php } ?>
                    </tr>
                    <?php
                    $paiements = $paiements + $row->Contrevaleur_22;
                    $commissions = $commissions + $row->Commission_23;
                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                        $suspend = $suspend + 1;
                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d'))
                        $urgent = $urgent + 1;
                }
                ?>


                <!-- encaissements from reporting -->
                <?php
                $paiements = 0;
                $commissions = 0;
                $suspend = 0;
                $urgent = 0;

                foreach ($encaissements_from_reporting as $row) {
                    ?>
                    <tr>
                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                        <td <?php if ($row->Datevaleur_31 !== gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Datevaleur_31; ?></td>
                        <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                        <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                        <td><?php echo $row->Typerecette_17; ?></td>
                        <td><?php echo $services[$row->Service_16]; ?></td>
                        <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?></td>
                        <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                        <td><?php echo '<span  class="text-blue">' . $guichets[$row->Guichet_21] . '</span>'; ?></td>
                        <?php if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) { ?>
                            <td width="20">
                                <?php
                                if ($_SESSION['Logiref_role'] == 3 && $row->Agence_20 == $_SESSION['Logiref_agence']) {
                                    echo '<span  class="text-red"> En attente </span>';
                                    ?>
                                <?php } else { ?>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Sydonia_44; ?>')" ><span class="fa fa-fw text-green fa-folder f14"> </span></a>
                                <?php } ?>
                            </td>
                        <?php } else { ?>
                            <td width="25">
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Sydonia_44; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            </td>
                        <?php } ?>
                    </tr>
                    <?php
                    $paiements = $paiements + $row->Contrevaleur_22;
                    $commissions = $commissions + $row->Commission_23;
                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                        $suspend = $suspend + 1;
                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d'))
                        $urgent = $urgent + 1;
                }
                ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <section id="cat_list">

        <div class="row fontawesome-icon-list pTop50 f14 tCenter">
            <span class="fa fa-warning text-gray mystyle4"></span>
            <br/><br/>
            Aucun paiement trouv&eacute;
            <br/><br/>
        </div>
    </section>
<?php endif; ?>
<?php $chtml->box_body_closing(); ?>
<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });
</script>

