
<div id="pager" class="col-md-12">
    <div class="col-md-12">
        <div class="col-md-12">
            <h2 class="text-blue f30">Les paiements des passports</h2>
            <p class="page-header" class="f12 text-black"><span class="f12 text-black">Cette section présente les rapports des paiements de passeports effectués en ligne et en agence.</span></p>
        </div>
    </div>

    <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>
        <div class="col-md-12">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="card-body p-2 height90">
                                <span class="card-title f12 text-black width200">Total paiements </span><br/><br/>
                                <p class="f18 text-blue"><a style="cursor:pointer" ><b><span id="paiements"></span></b> <span class="fa fa-fw text-blue fa-filter"> </span></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="card-body p-2 height90">
                                <span class="card-title f12 text-black width200">Paiements succès</span><br/><br/>
                                <p class="text-green f18"><a style="cursor:pointer" ><b><span id="validated"></span></b> <span class="fa fa-fw text-green fa-filter"> </span></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="card-body p-2 height90">
                                <span class="card-title f12 text-black width200">Paiements initié</span><br/><br/>
                                <p class="f18"><a style="cursor:pointer" onclick="filter('attente')" ><b><span id="attente"></span></b> <span class="fa fa-fw text-yellow fa-filter"> </span></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="card-body p-2 height90">
                                <span class="card-title f12 text-black width200">Paiements à problème</span><br/><br/>
                                <p class="f18"><a style="cursor:pointer" onclick="filter('regulate')" ><b><span id="regulate"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <br/>

    <div class="col-md-12">
        <div id="loader1" class="col-md-12"></div>
        <div class="col-md-12">
            <div class="btn-group" role="group" aria-label="Choix mode">
                <button type="button" class="btn btn-light text-success rounded-0 border border-bottom-0 font-weight-bold" onclick="pager('passport_agence')" id="agence">
                    <i class="fa fa-file-zip-o"></i> En agence
                </button>

                <button type="button" class="btn btn-light text-primary border border-bottom-0 rounded-0" onclick="pager('passport_online')" id="online">
                    <i class="fa fa-check"></i> En ligne
                </button>
            </div>
        </div>

        <div id="panel" class="col-md-12">

        </div>
    </div>
</div>

<?php echo form_close(); ?>
<script type="text/javascript">

    get_payments();
    $("#CloseModal").click(function(){
        get_payments();
    });

    function get_payments()
    {
        $("#loader1").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/taxreports/display/passport_agence'); ?>/", function(data, status){
                $("#loader1").html('');
                $("#panel").html(data);
        });
    }

    function pager(tab) {
        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module); ?>/taxreports/display/' + tab ;

        $.get(url, function(data, status){
            $("#loader").html('');
            $("#panel").html(data);

            if(tab=='passport_agence')
            {
                $("#agence").css('background-color', 'rgba(0,0,0,0.04)');
                $("#online").css('background-color', '');
                $("#initialized").html("Paiements initié");
            }
            else if(tab=='passport_online')
            {
                $("#online").css('background-color', 'rgba(0,0,0,0.04)');
                $("#agence").css('background-color', '');
                $("#initialized").html("Paiements [Réference non reconnue]");
            }
        });
    }
</script>