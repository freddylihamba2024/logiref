<?php if (!empty($encaissements)): ?>
    <table id="filterResult" class="table table-hover table-striped">
        <thead>
            <tr class="bg-aqua-active">
                <th>#</th>
                <th>Date</th>
                <th>Art.Budgetaire</th>
                <th>Client</th>
                <th>Montant</th>
                <th>Commissions</th>
                <th>Agences</th>
                <th><span class="fa fa-fw fa-folder f14"></span></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $paiements = 0;
            $commissions = 0;
            $suspend = 0;
            $urgent = 0;

            foreach ($encaissements as $row) {
                $infos = json_decode($row->Notereference_30);

                #$infos->QuotasComite;
                #var_dump($infos);die;
                ?>
                <tr>
                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                    <!--<td <?php //if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"';          ?>><?php //echo $row->Date_1;          ?></td>-->
                    <td><?php echo $row->Datevaleur_31 ?></td>
                    <td><b><?php echo $row->Typerecette_17; ?></b></td>
                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>

                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>

                    <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>

                    <td width="25">
                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                    </td>
                </tr>
                <?php
                $paiements = $paiements + $row->Contrevaleur_22;
                $commissions = $commissions + $row->Commission_23;
                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                    $suspend = $suspend + 1;
                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d'))
                    $urgent = $urgent + 1;
            }
            ?>

        </tbody>
    </table>
<?php else: ?>
    <div class="col-md-12">
        <section id="cat_list" class="text-center pt-5 pb-5">
            <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
            <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
        </section>
    </div>
<?php endif; ?>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
    $("#searchform").submit(function (e) {
        e.preventDefault();
        $("#loader").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxreports/display/filter_passport'); ?>';
        var data = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#loader').html('');
                $('#filterResult').html(result);
            },
            error: function (error) {
                alert('ERROR!' + error);
            }
        });
    });

    function view(id, regie)
    {
        var url = '';
        var controller = 'reports';
        var from = '<?php echo $display; ?>';

        if (regie === 'DGI')
        {
            var url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
        } else if (regie === 'DGRAD')
        {
            var url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
        }

        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {controller: controller, from: from}, function (data, status) {
            $("#loader").html('');
            $("#container").html(data);

        });
    }

    function print_payment(pid)
    {
        var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function () {
            w.print();
        });
    }


    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $("#export").click(function () {
        $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taximpression'); ?>/display/export_passports';
        window.open(url);

    });

</script>