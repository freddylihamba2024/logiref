<?php
    $paiements = 0;
    $paiements_dgi = 0;
    $suspend = 0;
    $urgent = 0;
    $i = 0;
?>

<div class="col-md-12 pl-0 pr-0" id="loader"></div>
<div id="pager">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <div>
                <?php if ($_SESSION['Logiref_role'] == 2 && isset($options['ALL']['client-exchange-rate-override'])): ?>
                    <h1 class="text-blue f30">Paiements en attente de validation de taux</h1>
                <?php else: ?>
                    <h1 class="text-blue f30">Liste des paiements non valid&eacute;s</h1>
                <?php endif; ?>
                <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements non valid&eacutes.</span></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements DGI-DGRAD</h5>
                            <p class="text-blue f18"> <b>CDF <span id="paiements_dgi"></span></b></p>
                            <!--<p class="text-blue f18"> <b>USD <span id="paiements_dgi"></span></b></p>-->
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements DGDA</h5>
                            <p class="text-green f18"><b>CDF <span id="paiements"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Paiements en attente DGI- DGRAD</h5>
                            <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('attente')"><b><span id="attente"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Paiements en attente DGDA</h5>
                            <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('urgents')"><b><span id="urgent"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                        </div>
                    </div>
                </div>
            </div><br>
        </div><br>
    </div>
    <div class="tab_container">
        <div class="tabs">
            <div class="tab tab-active" onclick="openTab(event, 'paiements_agence')">
                Paiements en Agence
            </div>
            <div class="tab" onclick="openTab(event, 'paiements_rbo')">
                Paiements en Ligne
            </div>
        </div>
        <div class="tab-item-container">
            <!-- tab-item for paiements en agence -->
            <div class="tab-item" id="paiements_agence">
                <div class="row">
                    <div class="col-md-12">
                        <div id="message"></div>
                        <?php $chtml->box_body_opening('', true); ?>
                        <div class="row mb-3">
                            <div class="col-md-12 text-right">
                                <input type="text" id="searchInput" onkeyup="filterTable()"
                                    class="form-control d-inline-block p-2 rounded shadow-sm"
                                    placeholder="🔍 Rechercher..."
                                    style="max-width: 150px; font-size: 14px; border: 1px solid #ced4da;">
                            </div>
                        </div>
                        <div id="paiementslist">
                            <?php if (!empty($encaissements) || !empty($encaissements_batchs) || !empty($bulletins) || !empty($prepayments) || !empty($bulletins_batchs) || !empty($bulletins_batchs_rbo) || !empty($encaissements_permis)): ?>
                                <table id="table" class="table table-hover table-striped">
                                    <thead>
                                        <tr class="bg-gray f12">
                                            <th class="f12">#</th>
                                            <th class="f12" width="50">Date</th>
                                            <th class="f12">D&eacute;signation</th>
                                            <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                            <th class="f12">Recette</th>
                                            <th class="f12">Montant</th>
                                            <th class="f12">Commissions</th>
                                            <th class="f12" width="50">Op&eacute;rateur</th>
                                            <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                            <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        #Block last BL
                                        foreach ($bulletins as $row) {

                                            $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
                                            $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                            $dateTime = new DateTime($row->Date_1);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                        ?>
                                            <tr class="f12">
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                                if ($row->Status_2 == 4)
                                                                    echo 'class="text-green"';
                                                                elseif ($deadline > gmdate('Y-m-d'))
                                                                    echo 'class="text-black"';
                                                                elseif ($deadline == gmdate('Y-m-d'))
                                                                    echo 'class="text-orange"';
                                                                elseif ($deadline < gmdate('Y-m-d'))
                                                                    echo 'class="text-red"';
                                                                ?>>
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php
                                                                        if ($row->Designation_23 == "")
                                                                            echo "Bulletin de liquidation / " . $row->Nif_9;
                                                                        else
                                                                            echo $row->Designation_23;
                                                                        ?></td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                                <td class="text-blue">
                                                    <?php echo 'CDF ' . number_format((float) $row->Amount_12, 2, ",", " "); ?>
                                                </td>
                                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <?php if ($row->Status_2 == 1) { ?>
                                                    <td width="25">
                                                        <?php
                                                        if ($row->Agence_32 == $_SESSION['Logiref_guichet']) {
                                                            $bl_details = json_decode($row->Results_13);

                                                            $data = 0;
                                                            if (!empty($bl_details))
                                                                $data = 1;
                                                        ?>
                                                            <a style="cursor:pointer" onclick="view_process('<?php echo $row->Id_0; ?>', 'DGDA', <?= $data ?>)"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } elseif ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_32 == $_SESSION['Logiref_agence']) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_9) && $row->Makerid_9 == $userid)) { ?>
                                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                                <a class="cursor-pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php else: ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                                            <?php endif; ?>
                                                        <?php } else { ?>
                                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                                <a class="cursor-pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php else: ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php endif; ?>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php } else { ?>
                                                    <td width="25">
                                                        <?php if ($row->Lot_22 == "saisi"): ?>
                                                            <a class="cursor-pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php else: ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . $row->Pdfcontent_18)): ?>
                                                            <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        <?php else: ?>
                                                            <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                        <?php
                                            $paiements = $paiements + (float) $row->Amount_12;
                                            if ($row->Status_2 == 1 || $row->Status_2 == 2)
                                                $urgent = $urgent + 1;
                                        }
                                        ?>

                                        <?php
                                        #Block last BL Batchs
                                        foreach ($bulletins_batchs as $row):
                                            $agence = (isset($guichets[$row->Agence_24])) ? $guichets[$row->Agence_24] : ' - ';
                                            $operateur = (isset($users[$row->User_13])) ? $users[$row->User_13] : ' - ';
                                            $dateTime = new DateTime($row->Date_1);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            $bulletin = json_decode($row->Bulletins_22);

                                            $bl_list = json_decode($row->Bulletins_22, true);
                                            $total_bl = isset($bl_list['years']) ? count($bl_list['years']) : 0;
                                        ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                                if ($row->Status_2 == 4)
                                                                    echo 'class="text-green"';
                                                                elseif ($deadline > gmdate('Y-m-d'))
                                                                    echo 'class="text-black"';
                                                                elseif ($deadline == gmdate('Y-m-d'))
                                                                    echo 'class="text-orange"';
                                                                elseif ($deadline < gmdate('Y-m-d'))
                                                                    echo 'class="text-red"';
                                                                ?>>
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue">
                                                    <?php
                                                    if ($row->Designation_15 == "")
                                                        echo "Lot des bulletins / " . $row->Nif_8;
                                                    else
                                                        echo $row->Designation_15;
                                                    ?>
                                                </td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td>
                                                    <span class="badge badge-secondary">Lot de bulletins (<?= $total_bl ?>)</span>
                                                </td>
                                                <td class="text-blue">
                                                    <?php echo 'CDF ' . number_format($row->Amount_11, 2, ",", " "); ?>
                                                </td>
                                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_20, 2, ",", " "); ?></td>
                                                <td width="50">
                                                    <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                </td>
                                                <?php if ($row->Status_2 == 1) : ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_24 == $_SESSION['Logiref_agence']): ?>
                                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php elseif ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_28) && $row->Makerid_28 == $this->session->userdata['user_id'])): ?>
                                                            <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php //echo $row->Id_0; 
                                                                                                                                                                                            ?>" class="item"><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                                            <!-- <a style="cursor: pointer" onclick="edit('<?php echo $row->Id_0; ?>', '<?php echo $row->Status_2; ?>', '<?php echo $row->Lot_14; ?>')"> 
                                                                <i class="fa fa-pencil text-blue f14"></i>
                                                            </a> -->
                                                        <?php else: ?>
                                                            <!-- <a style="cursor: pointer" onclick="edit('<?php echo $row->Id_0; ?>', '<?php echo $row->Status_2; ?>', '<?php echo $row->Lot_14; ?>')"> 
                                                                <i class="fa fa-pencil  text-blue f14"></i>
                                                            </a> -->
                                                            <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php else : ?>
                                                    <td width="25">
                                                        <!-- <a style="cursor: pointer" onclick="edit('<?php echo $row->Id_0; ?>', '<?php echo $row->Status_2; ?>', '<?php echo $row->Lot_14; ?>')"> 
                                                            <i class="fa fa-pencil text-blue f14"></i>
                                                        </a> -->
                                                        <a style="cursor:pointer" onclick="preview_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . "")): ?>
                                                            <a style="cursor:pointer" onclick="printQuittance('<?php echo ""; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        <?php else: ?>
                                                            <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; ?>

                                        <?php $i = 1;
                                        foreach ($prepayments as $customer => $payments): ?>
                                            <tr>
                                                <?php
                                                # Initialisation des variables pour stocker les données collectées
                                                //$offices = '';
                                                $declarants = '';
                                                $totals = 0;
                                                $amounts = 0;
                                                $editLinks = '';
                                                $operateur = '';
                                                $lot_id = '';
                                                $comm = isset($commissions[$customer]) ? $commissions[$customer] : 0;

                                                foreach ($payments as $payment):
                                                    $operateur = (isset($users[$payment->Creator_4])) ? $users[$payment->Creator_4] : ' - ';
                                                    $amounts += $payment->amounts;
                                                    $totals +=  $payment->total;

                                                    $lot_id = $payment->Lot_19;
                                                endforeach;
                                                ?>

                                                <td width=""><?php echo $i; ?></td>
                                                <td colspan="2" width=""><?php echo $customer; ?></td>
                                                <td width="" width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td width="">
                                                    <span class="badge badge-secondary">Bulletin pr&eacute;pay&eacute; (<?= $totals . " Bls"; ?>)</span>
                                                </td>
                                                <td width=""><?php echo 'CDF ' . number_format($amounts, 2, ",", " "); ?></td>
                                                <td width=""><?php echo 'CDF ' . number_format($comm, 2, ",", " "); ?></td>
                                                <td width=""><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <td width="">
                                                    <a style="cursor: pointer" onclick="edit('<?php echo $customer; ?>', '<?php echo $lot_id; ?>', '<?php echo $payment->Office_8; ?>')">
                                                        <i class="fa fa-fw fa-pencil f14"></i>
                                                    </a>
                                                </td>
                                                <td width="25">
                                                    <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                </td>
                                            </tr>
                                        <?php $i++;
                                        endforeach; ?>

                                        <?php
                                        #Block DGI et DGRAD
                                        foreach ($encaissements as $row) {
                                            $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                            $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                            $dateTime = new DateTime($row->Datevaleur_31);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                        ?>
                                            <!-- <tr class="<= ($_SESSION['Logiref_role'] == 3 && isset($options['ALL']['client-exchange-rate-override']) && ($row->Tauxflag_58 ?? ' ') == "1") ? "bg-info" : ""; ?>"> -->
                                            <tr class="">
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                                if ($row->Status_2 == 3)
                                                                    echo 'class="text-green"';
                                                                elseif ($deadline > gmdate('Y-m-d'))
                                                                    echo 'class="text-black"';
                                                                elseif ($deadline == gmdate('Y-m-d'))
                                                                    echo 'class="text-orange"';
                                                                elseif ($deadline < gmdate('Y-m-d'))
                                                                    echo 'class="text-red"';
                                                                ?>>
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                <td><?php
                                                    if ($row->Beneficaire_15 == "DGI")
                                                        echo $row->Typerecette_17;
                                                    elseif ($row->Beneficaire_15 == "DGRAD")
                                                        echo $row->Noteid_26;
                                                    ?></td>
                                                <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?>
                                                    <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                        <br />
                                                        <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <?php if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) { ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_20 == $_SESSION['Logiref_agence']) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_9 == $userid) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } else { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php } else { ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                        <?php
                                            $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                            if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                                $suspend = $suspend + 1;
                                        }
                                        ?>

                                        <?php
                                        #Block DGRAD (BATCH)
                                        foreach ($encaissements_batchs as $row) :
                                            $guichet = (isset($guichets[$row->Guichet_25])) ? $guichets[$row->Guichet_25] : ' - ';
                                            $operateur = (isset($users[$row->Creator_4])) ? $users[$row->Creator_4] : ' - ';
                                            $dateTime = new DateTime($row->Date_1);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                        ?>
                                            <tr class="">
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                                if ($row->Status_2 == 3)
                                                                    echo 'class="text-green"';
                                                                elseif ($deadline > gmdate('Y-m-d'))
                                                                    echo 'class="text-black"';
                                                                elseif ($deadline == gmdate('Y-m-d'))
                                                                    echo 'class="text-orange"';
                                                                elseif ($deadline < gmdate('Y-m-d'))
                                                                    echo 'class="text-red"';
                                                                ?>>
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php echo $row->Designation_12; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_7; ?></b></td>
                                                <td>
                                                    <span class="badge badge-secondary">Lot des notes (<?= $row->Nombrepaiements_26 ?>)</span>
                                                </td>
                                                <td class="text-blue">
                                                    <?php echo $row->Devise_14 . ' ' . number_format($row->Montant_13, 2, ",", " "); ?>
                                                </td>
                                                <td class="text-black"><?php echo $row->Devise_16 . ' ' . number_format($row->Commission_15, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <?php if ($row->Status_2 == 1): ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php elseif ($_SESSION['Logiref_role'] == 4 && $row->Creator_4 == $userid) : ?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php else: ?>
                                                            <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php else: ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view_batch('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_7; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; ?>

                                        <?php
                                        #Block DGRAD Permis
                                        foreach ($encaissements_permis as $row) {
                                            $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                            $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                            $dateTime = new DateTime($row->Datevaleur_31);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                        ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                                if ($row->Status_2 == 3)
                                                                    echo 'class="text-green"';
                                                                elseif ($deadline > gmdate('Y-m-d'))
                                                                    echo 'class="text-black"';
                                                                elseif ($deadline == gmdate('Y-m-d'))
                                                                    echo 'class="text-orange"';
                                                                elseif ($deadline < gmdate('Y-m-d'))
                                                                    echo 'class="text-red"';
                                                                ?>>
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                <td><?php
                                                    if ($row->Beneficaire_15 == "DGI")
                                                        echo $row->Typerecette_17;
                                                    elseif ($row->Beneficaire_15 == "DGRAD")
                                                        echo $row->Noteid_26;
                                                    ?></td>
                                                <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?>
                                                    <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                        <br />
                                                        <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <?php if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) { ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_20 == $_SESSION['Logiref_agence']) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_9 == $userid) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php } else { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php } else { ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                        <?php
                                            $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                            if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                                $suspend = $suspend + 1;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="col-md-12">
                                    <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4"></span></span></br>
                                        <span class="d-block f14 text-black p-2">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                                    </section>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
            </div>

            <!-- tab-item for paiements en ligne -->
            <div class="tab-item d-none" id="paiements_rbo">
                <div class="row">
                    <div class="col-md-12">
                        <div id="message"></div>
                        <?php $chtml->box_body_opening('', true); ?>
                            <div id="paiementslist">
                                <?php if (!empty($encaissements_rbo) || !empty($bulletins_rbo) || !empty($bulletins_batchs_rbo) || !empty($encaissements_permis_online)): ?>
                                    <table id="table" class="table table-hover table-striped">
                                        <thead>
                                            <tr class="bg-gray">
                                                <th>#</th>
                                                <th width="50">Date</th>
                                                <th>D&eacute;signation</th>
                                                <th>B&eacute;n&eacute;ficiaire</th>
                                                <th>Recette</th>
                                                <th>Montant</th>
                                                <th>Commissions</th>
                                                <th width="50">Op&eacute;rateur</th>
                                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                                                <th>Note</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            #Block last BL
                                            foreach ($bulletins_rbo as $row):
                                                $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
                                                $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 4)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue">
                                                        <?php
                                                        if ($row->Designation_23 == "")
                                                            echo "Bulletin de liquidation / " . $row->Nif_9;
                                                        else
                                                            echo $row->Designation_23;
                                                        ?>
                                                    </td>
                                                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                    <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                                    <td class="text-blue">
                                                        <?php echo 'CDF ' . number_format($row->Amount_12, 2, ",", " "); ?>
                                                    </td>
                                                    <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                                    <td width="50">
                                                        <?php if ($row->Customercode_35 != ""): ?>
                                                            <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                                        <?php else: ?>
                                                            <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if ($row->Status_2 == 1) : ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_32 == $_SESSION['Logiref_agence']): ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php elseif ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_9) && $row->Makerid_9 == $this->session->userdata['user_id'])): ?>
                                                                <?php if ($row->Lot_22 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if ($row->Lot_22 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php else : ?>
                                                        <td width="25">
                                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                                <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php else: ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . $row->Pdfcontent_18)): ?>
                                                                <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                            <?php else: ?>
                                                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <?php if (!isset($row->Pdfcontent_18) || $row->Pdfcontent_18 != null): ?>
                                                                <a style="cursor:pointer" href="<?php echo base_url() . $row->Pdfcontent_18; ?>"><span class="fa fa-fw text-red fa-file f14"> </span></a>
                                                            <?php else : ?>
                                                                <span class="fa fa-fw text-gray fa-file f14"> </span>
                                                            <?php endif; ?>
                                                        </td>

                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; ?>


                                            <?php
                                            #Block last BL Batchs
                                            foreach ($bulletins_batchs_rbo as $row):
                                                $agence = (isset($guichets[$row->Agence_24])) ? $guichets[$row->Agence_24] : ' - ';
                                                $operateur = (isset($users[$row->User_13])) ? $users[$row->User_13] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                                $bulletin = json_decode($row->Bulletins_22);
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 4)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue">
                                                        <?php
                                                        if ($row->Designation_15 == "")
                                                            echo "Lot des bulletins / " . $row->Nif_8;
                                                        else
                                                            echo $row->Designation_15;
                                                        ?>
                                                    </td>
                                                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                    <td>
                                                        <span class="badge badge-secondary">Lot de bulletins</span>
                                                    </td>
                                                    <td class="text-blue">
                                                        <?php echo 'CDF ' . number_format($row->Amount_11, 2, ",", " "); ?>
                                                    </td>
                                                    <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_20, 2, ",", " "); ?></td>
                                                    <td width="50">
                                                        <?php if ($row->Customercode_27 != ""): ?>
                                                            <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                                        <?php else: ?>
                                                            <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if ($row->Status_2 == 1) : ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_24 == $_SESSION['Logiref_agence']): ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php elseif ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_28) && $row->Makerid_28 == $this->session->userdata['user_id'])): ?>
                                                                <?php if ($row->Lock_33 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if ($row->Lock_33 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php else : ?>
                                                        <td width="25">
                                                            <?php if ($row->Lock_33 == "saisi"): ?>
                                                                <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php else: ?>
                                                                <a style="cursor:pointer" onclick="view_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . "")): ?>
                                                                <a style="cursor:pointer" onclick="printQuittance('<?php echo ""; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                            <?php else: ?>
                                                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php
                                            endforeach;
                                            ?>


                                            <?php
                                            #Block DGI et DGRAD
                                            foreach ($encaissements_rbo as $row):
                                                $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                                $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                                $dateTime = new DateTime($row->Datevaleur_31);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 3)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                    <td>
                                                        <?php
                                                        if ($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17;
                                                        elseif ($row->Beneficaire_15 == "DGRAD") echo $row->Noteid_26;
                                                        ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?>
                                                        <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                            <br />
                                                            <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                    <td width="50">
                                                        <?php if ($row->Customercode_51 != ""): ?>
                                                            <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                                        <?php else: ?>
                                                            <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] != 4): ?>
                                                            <?php if ($row->Status_2 == 6): ?>
                                                                <a style="cursor:pointer" onclick="verification('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')"><span class="fa fa-fw  text-green fa-pencil f14"> </span></a>
                                                            <?php else : ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                            <?php endif; ?>
                                                        <?php else : ?>
                                                            <?php if ($row->Status_2 == 6): ?>
                                                                <a style="cursor:pointer" onclick="verification('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')"><span class="fa fa-fw text-yellow fa-folder-open f14"> </span></a>
                                                            <?php else : ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">

                                                        <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" href="<?php echo base_url() . $row->Notefile_52; ?>"><span class="fa fa-fw text-red fa-file f14"> </span></a>
                                                    </td>

                                                </tr>
                                                <?php
                                                $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) $suspend = $suspend + 1;
                                                ?>
                                            <?php endforeach; ?>

                                            <?php
                                            #Block DGRAD Permis
                                            foreach ($encaissements_permis_online as $row) {
                                                $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                                $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                                $dateTime = new DateTime($row->Datevaleur_31);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td width="80" <?php
                                                                    if ($row->Status_2 == 3)
                                                                        echo 'class="text-green"';
                                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                                        echo 'class="text-black"';
                                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                                        echo 'class="text-orange"';
                                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                                        echo 'class="text-red"';
                                                                    ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                    <td><?php
                                                        if ($row->Beneficaire_15 == "DGI")
                                                            echo $row->Typerecette_17;
                                                        elseif ($row->Beneficaire_15 == "DGRAD")
                                                            echo $row->Noteid_26;
                                                        ?></td>
                                                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?>
                                                        <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                            <br />
                                                            <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                    <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                    <?php if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) { ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_20 == $_SESSION['Logiref_agence']) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_9 == $userid) { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else { ?>
                                                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGRAD_Permis', '<?php echo $row->Typerecette_17; ?>')"><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        </td>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        </td>
                                                    <?php } ?>
                                                    <td width="25"></td>
                                                </tr>
                                            <?php
                                                $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                                    $suspend = $suspend + 1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="col-md-12">
                                        <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4"></span></br>
                                            <span class="d-block p-2 f14 text-black"> Aucun paiement trouv&eacute;!</span>
                                        </section>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br/><br/>

<script type="text/javascript">
    $("#contenter").unbind().on("click", ".item", function() {

        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
    });

    $('#paiements').html('<?php echo number_format($paiements, 2, ",", " "); ?>');
    $('#paiements_dgi').html('<?php echo number_format($paiements_dgi, 2, ",", " "); ?>');
    $('#attente').html('<?php echo $suspend; ?>');
    $('#urgent').html('<?php echo $urgent; ?>');

    function view_process(id, regie, param) {
        if (param == 1) {
            var url = "<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/" + id;
        } else {
            var url = "<?php echo base_url($module . '/taxbulletin/display/step_1_process'); ?>/" + id;
        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {
            param: param
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function view(id, regie, recette = null) {
        var url = '';
        if (regie === 'DGDA') {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
            var url = "<?php echo base_url($module . '/taxbulletin/display/preview'); ?>/" + id;
            '<?php else : ?>'
            var url = "<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/" + id;
            '<?php endif; ?>'
        } else if (regie === 'DGI') {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
            var url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
            '<?php else : ?>'
            var url = "<?php echo base_url($module . '/taxdeclaration/display/edit'); ?>/" + id;
            '<?php endif; ?>'

        } else if (regie === 'DGRAD') {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
            var url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
            '<?php else : ?>'
            var url = "<?php echo base_url($module . '/taxnotes/display/edit'); ?>/" + id;
            '<?php endif; ?>'
        } else if (regie === 'DGRAD_Permis') {
            var url = "<?php echo base_url($module . '/taxpermis/display/preview'); ?>/" + id;
        }

        // console.log(url);

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {
            previous_menu: "nvalidated"
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function view_batch(id, regie = null) {
        if (regie === 'DGRAD') {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
            var url = "<?php echo base_url($module . '/taxnotes/display/preview_batch'); ?>/" + id;
            '<?php else : ?>'
            var url = "<?php echo base_url($module . '/taxnotes/display/edit_batch'); ?>/" + id;
            '<?php endif; ?>'
        } else {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
            var url = "<?php echo base_url($module . '/taxbulletin/display/preview_batch'); ?>/" + id;
            '<?php else : ?>'
            var url = "<?php echo base_url($module . '/taxbulletin/display/preview_batch'); ?>/" + id;
            '<?php endif; ?>'
        }


        $("#message").html('<img  align="middle" stylee="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {
            previous_menu: "nvalidated"
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function preview_batch(id) {
        var url = "<?php echo base_url($module . '/taxbulletin/display/batch_confirmation_from_operator'); ?>/" + id;

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {
            previous_menu: "nvalidated"
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function view_manual(id, regie) {
        var url = "<?php echo base_url($module . '/taxothers/display/preview'); ?>/" + id;
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function viewPrepayment(id) {
        '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
        var url = "<?php echo base_url($module . '/taxprepayments/display/preview'); ?>/" + id;
        '<?php else : ?>'
        var url = "<?php echo base_url($module . '/taxprepayments/display/preview'); ?>/" + id;
        '<?php endif; ?>'

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function print_payment(pid) {

        var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    }

    function edit(param, lotid, param1 = null) {
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var data = '';
        var url = '';

        var url = '<?php echo base_url($module . '/taxprepayments/display/treatment_process'); ?>/';
        var data = {
            compte: param,
            office: param1,
            lotid: lotid
        };

        $.ajax({
            type: 'GET',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(reponse) {
                $("#message").html('');
                $("#general_block").removeClass('d-none');
                $("#prepayment_block").addClass('d-none');
                $('#pager').html(reponse);

            },
            error: function(error) {
                $("#message").html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    }

    function verification(id, regie) {
        var url = '';

        if (regie === 'DGI') {
            url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
        } else if (regie === 'DGRAD') {
            url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get(url, {
            previous_menu: "paiements_rbo"
        }, function(data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('d-none');
            $("#form").removeClass('d-none');
        });
    }

    $(document).ready(function(e) {

    });

    function openTab(event, tabContentId) {
        $('.tab').removeClass('tab-active');
        $(".tab-item").addClass('d-none');

        event.currentTarget.classList.add('tab-active');
        $("#" + tabContentId + "").removeClass('d-none');
    }

    function filterTable() {
        var input = document.getElementById("searchInput");
        var filter = input.value.toLowerCase();
        var table = document.getElementById("table");
        var tr = table.getElementsByTagName("tr");

        for (var i = 1; i < tr.length; i++) { // Commence à partir de 1 pour ignorer l'en-tête
            var td = tr[i].getElementsByTagName("td");
            var showRow = false;

            for (var j = 0; j < td.length; j++) {
                if (td[j] && td[j].textContent.toLowerCase().indexOf(filter) > -1) {
                    showRow = true;
                    break;
                }
            }
            tr[i].style.display = showRow ? "" : "none";
        }
    }
</script>