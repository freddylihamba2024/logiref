<div class="col-md-12 no-padding">
        <?php $chtml->box_body_opening('', true); ?>
        <div class="statistic-box no-border no-padding">
            <div class="col-md-12 no-margin">
                <h1>
                    Rapports des regularisations effectu&eacute;es 
                </h1>
                <h5 class="page-header">Cette section vous pr&eacute;sente les rapports des regularisations effectu&eacute;es .</h5>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>

        <div id="loader" class="col-md-12"></div>

        <div class="col-md-12 no-padding" id="filterResult">
            <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($regularisations)): ?>
            <table id="table" class="table table-bordered table-hover table-stripedR">
                <thead>
                    <tr class="bg-gray">
                        <th with="12">N&SmallCircle;</th>
                        <th>Libell&eacute;</th>
                        <th with="150">Montant</th>
                        <th with="150">D&eacute;bit</th>
                        <th with="150">Cr&eacute;dit</th>
                        <th with="150">Date</th>
                        <th with="150">Op&eacute;rateur</th>
                        <th with="150">type</th>
                    </tr>
                </thead>
                <tbody>
                <?php  foreach($regularisations as $row){ ?>
                        <tr >
                            <td><?php echo $row->Id_0; ?></td>
                            <td><?php echo $row->Libelle_12; ?></td>
                            <td><?php echo number_format($row->Montant_10,2,","," "); ?></td>
                            <td><?php echo $row->Compte_9; ?></td>
                            <td><?php echo $row->Compte_13; ?></td>
                            <td><?php echo $row->Date_1; ?></td>
                            <td><?php echo $users[$row->Makerid_16]; ?></td>
                            <td><?php echo $row->Action_21; ?></td>
                        </tr>
                <?php };?>
                </tbody>    
            </table>
            <?php else:?>
                <section id="cat_list" class="text-center" style="height: 250px;">
                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4 fa-5x" ></span></br>
                    <span class="d-block p-2 "> Aucune r&eacute;gularisation trouv&eacute;e !</span>
                </section>
                
            <?php endif;?>
            <?php $chtml->box_body_closing(); ?>
        </div>  
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$("#searchform").submit(function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filterresult/tresor'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#filterResult').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

function view(id, regie)
{
        var url ='';
        var controller = 'reports';
        //var from = '<?php //echo $display; ?>';
        
        if(regie === 'DGI')
        {
             var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
        }
        else if(regie === 'DGRAD')
        {
             var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
        }

        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
         $.get(url,{ controller : controller, from : from}, function(data, status){
            $("#loader").html('');
            $("#container").html(data);

        });
}

function print_payment(pid)
{
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
}


//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

</script>

