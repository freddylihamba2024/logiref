<?php
$paiements_dgi = 0;
$paiements_dgrad = 0;
$paiements_dgda = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>
<div id="pager"  class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-blue f30">Liste des paiements valid&eacutes</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements valid&eacutes.</span></p>
        </div>

    </div>
    <div class="row">

        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements DGI</h5>
                            <p class="text-blue f18"> <b>CDF <span id="paiements_dgi"></span></b></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements DGRAD</h5>
                            <p class="text-blue f18"> <b>CDF <span id="paiements_dgrad"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements DGDA</h5>
                            <p class="text-blue f18"> <b>CDF <span id="paiements_dgda"></span></b></p>
                        </div>
                    </div>  
                </div>

                <!--                <div class="col-md-3 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="card-body p-2 height90">
                                            <h5 class="card-title f12 text-black width200">Paiements DGI- DGRAD  &agrave; importer</h5>
                                            <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('attente')"><b ><span id="attente"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="card-body p-2 height90">
                                            <h5 class="card-title f12 text-black width200">Paiements DGDA &agrave; importe</h5>
                                            <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('urgents')"><b ><span id="urgent"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                                        </div>
                                    </div>
                                </div>-->
            </div><br>
        </div><br>
    </div><br>
    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>

    <div class="tab_container">
        <div class="tabs">
            <div class="tab tab-active" data_target='#paiements_agence' onclick="openTab(event, 'paiements_agence')">
                Paiements en Agence
            </div>
            <div class="tab" data_target='#paiements_pending_rbo' onclick="openTab(event, 'paiements_pending_rbo')">
                Paiements en Ligne
            </div>
        </div>
        <div class="tab-content">

        </div>
        <div class="tab-item-container">
            <!-- tab-item for paiements en agence -->
            <div class="tab-item" id="paiements_agence">
                <div class="row">
                    <div class="col-md-12">
                        <div  id="loader"></div>

                        <?php $chtml->box_body_opening('', true); ?>
                        <div id="paiementslist">
                            <?php if (!empty($encaissements) || !empty($bulletins) || !empty($prepayments)): ?>
                                <table id="table" class="table table-hover table-striped">
                                    <thead>
                                        <tr style="background-color: #d2d6de;">
                                            <th></th>
                                            <th>Date</th>
                                            <th>Client</th>
                                            <th>B&eacute;n&eacute;ficiaire</th>
                                            <th>Recette</th>
                                            <th>Montant</th>
                                            <th>Commissions</th>
                                            <th>Op&eacute;rateur</th>
                                            <th><span class="fa fa-fw fa-tasks f14"></span></th>
                                            <th><span class="fa fa-fw fa-folder f14"></span></th>
                                            <th><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach ($bulletins as $row) {
                                            $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
                                            $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                            $dateTime = new DateTime($row->Integration_16);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            $results = json_decode($row->Results_13);
                                            $recieptDate = explode("/", $results->receiptDate);
                                            $nodeid = $recieptDate[2] . '' . $results->receiptSerial . '' . $results->receiptNumber;
                                            ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="50" <?php
                                                if ($row->Status_2 == 2)
                                                    echo 'class="text-green"';
                                                elseif ($deadline > gmdate('Y-m-d'))
                                                    echo 'class="text-black"';
                                                elseif ($deadline == gmdate('Y-m-d'))
                                                    echo 'class="text-orange"';
                                                elseif ($deadline < gmdate('Y-m-d'))
                                                    echo 'class="text-red"';
                                                ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php
                                                    if ($row->Designation_23 == "")
                                                        echo "Bulletin de liquidation / " . $row->Nif_9;
                                                    else
                                                        echo $row->Designation_23;
                                                    ?></td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                                <td class="text-blue">
                                                    <?php echo'CDF ' . number_format($row->Amount_12, 2, ",", " "); ?> 
                                                </td>
                                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                                <td><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" class="item"><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                                </td>
                                                <?php if ($row->Status_2 != 3) { ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_20 == $_SESSION['Logiref_agence']) { ?>
                                                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0; ?>' onclick="validate('<?php echo $row->Id_0; ?>')" value="<?php echo $row->Year_5 . "" . $row->Serie_7 . "" . $row->Number_8; ?>" name="bulletins[]" />
                                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_9 == $userid) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                                        <?php } else { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php } else { ?>
                                                    <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) { ?>
                                                        <td width="25">
                                                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0; ?>' onclick="reverser('<?php echo $row->Id_0; ?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                        </td>
                                                    <?php } ?>
                                                    <td width="25">
                                                        <?php if (isset($row->Pdfcontent_18) && $row->Pdfcontent_18 != ""): ?>
                                                            <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                        <?php else: ?>
                                                            <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                            <?php
                                            $paiements_dgda = $paiements_dgda + $row->Amount_12;
                                            #$commissions = $commissions + $row->Commission_26;
                                            if ($row->Status_2 == 3)
                                                $urgent = $urgent + 1;
                                        }
                                        ?>

                                        <?php
                                        foreach ($encaissements as $row) {
                                            $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                            $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                            $dateTime = new DateTime($row->Datevaleur_31);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                            ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td width="80" <?php
                                                if ($row->Status_2 == 2)
                                                    echo 'class="text-green"';
                                                elseif ($deadline > gmdate('Y-m-d'))
                                                    echo 'class="text-black"';
                                                elseif ($deadline == gmdate('Y-m-d'))
                                                    echo 'class="text-orange"';
                                                elseif ($deadline < gmdate('Y-m-d'))
                                                    echo 'class="text-red"';
                                                ?>>
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?= isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                <td><?php echo $row->Typerecette_17; ?></td>
                                                <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?> 
                                                    <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                        <br/>
                                                        <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                <td><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <td width="25">
                                                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                                </td>
                                                <?php if ($row->Checkerid_10 == 0) { ?>
                                                    <td width="25">
                                                        <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_20 == $_SESSION['Logiref_agence']) { ?>
                                                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0; ?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                                        <?php } else if ($_SESSION['Logiref_role'] == 4 && $row->Makerid_9 == $userid) { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                                        <?php } else { ?>
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php } else { ?>
                                                    <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) { ?>
                                                        <td width="25">
                                                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0; ?>' onclick="reverser('<?php echo $row->Id_0; ?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                                        </td>
                                                    <?php } ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                            <?php
                                            $commissions = $commissions + $row->Commission_23;
                                            if ($row->Beneficaire_15 == "DGRAD")
                                                $paiements_dgrad = $paiements_dgrad + $row->Contrevaleur_22;
                                            if ($row->Beneficaire_15 == "DGI")
                                                $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                            if ($row->Status_2 == 1)
                                                $suspend = $suspend + 1;
                                            #var_dump($row->Status_2);die;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="col-md-12">
                                    <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                            <span class="d-block p-2 f14 text-black">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                                    </section>
                                 </div>

                            <?php endif; ?>
                            </div>
                        <?php $chtml->box_body_closing(); ?>
                        </div>
                    </div>
                </div>

                <!-- tab-item for paiements en ligne -->
                <div class="tab-item d-none" id="paiements_pending_rbo">
                    <div class="row">
                        <div class="col-md-12">
                            <div  id="message"></div>
                            <?php $chtml->box_body_opening('', true); ?>
                            <div id="paiementslist">
                                <?php if (!empty($bulletins_rbo) || !empty($encaissements_rbo)): ?>
                                    <table id="table" class="table table-hover table-striped">
                                        <thead>
                                            <tr class="bg-gray">
                                                <th width="50">Date</th>
                                                <th>D&eacute;signation</th>
                                                <th>B&eacute;n&eacute;ficiaire</th>
                                                <th>Recette</th>
                                                <th>Montant</th>
                                                <th>Commissions</th>
                                                <th width="50">Op&eacute;rateur</th>
                                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            #Block last BL
                                            foreach ($bulletins_rbo as $row) {
                                                $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
                                                $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                                ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td  width="80" <?php
                                                    if ($row->Status_2 == 4)
                                                        echo 'class="text-green"';
                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                        echo 'class="text-black"';
                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                        echo 'class="text-orange"';
                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                        echo 'class="text-red"';
                                                    ?> >
                                                             <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php
                                                        if ($row->Designation_23 == "")
                                                            echo "Bulletin de liquidation / " . $row->Nif_9;
                                                        else
                                                            echo $row->Designation_23;
                                                        ?></td>
                                                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                    <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                                    <td class="text-blue">
                                                        <?php echo'CDF ' . number_format($row->Amount_12, 2, ",", " "); ?> 
                                                    </td>
                                                    <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                                    <td width="50">
                                                        <?php if ($row->Customercode_35 != ""): ?> 
                                                            <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                                        <?php else: ?> 
                                                            <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                        <?php endif; ?> 
                                                    </td>
                                                    <?php if ($row->Status_2 == 1) { ?>
                                                        <td width="25">
                                                            <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2 && $row->Agence_32 == $_SESSION['Logiref_agence']) { ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php } else if ($_SESSION['Logiref_role'] == 4 && (isset($row->Makerid_9) && $row->Makerid_9 == $this->session->userdata['user_id'])) { ?>
                                                                <?php if ($row->Lot_22 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-blue fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php } else { ?>
                                                                <?php if ($row->Lot_22 == "saisi"): ?>
                                                                    <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php else: ?>
                                                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                                <?php endif; ?>
                                                            <?php } ?>
                                                        </td>
                                                        <td width="25">
                                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                        </td>
                                                    <?php } else { ?>
                                                        <td width="25">
                                                            <?php if ($row->Lot_22 == "saisi"): ?>
                                                                <a style="cursor:pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php else: ?>
                                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td width="25">
                                                            <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . $row->Pdfcontent_18)): ?>
                                                                <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                            <?php else: ?>
                                                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                            <?php endif; ?>
                                                        </td>

                                                    <?php } ?>
                                                </tr>
                                                <?php
                                            }
                                            ?>

                                            <?php
                                            #Block DGI et DGRAD
                                            foreach ($encaissements_rbo as $row):
                                                $guichet = (isset($guichets[$row->Guichet_21])) ? $guichets[$row->Guichet_21] : ' - ';
                                                $operateur = (isset($users[$row->Makerid_9])) ? $users[$row->Makerid_9] : ' - ';
                                                $dateTime = new DateTime($row->Datevaleur_31);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                                ?>
                                                <tr>
                                                    <td width="5"><b><?= ++$i; ?></b></span></td>
                                                    <td  width="80" <?php
                                                    if ($row->Status_2 == 3)
                                                        echo 'class="text-green"';
                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                        echo 'class="text-black"';
                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                        echo 'class="text-orange"';
                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                        echo 'class="text-red"';
                                                    ?> >
                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                    <td>
                                                        <?php
                                                        if ($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17;
                                                        elseif ($row->Beneficaire_15 == "DGRAD") echo $row->Noteid_26;
                                                        ?>
                                                    </td>
                                                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ",", " "); ?> 
                                                        <?php if ($row->Devise_12 == "USD" || $row->Devise_12 == "EUR" || $row->Devise_12 == "ZAF") : ?>
                                                            <br/>
                                                            <span class="text-gray"><?php echo 'CDF ' . number_format($row->Contrevaleur_22, 2, ",", " "); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-black"><?php echo $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                                                    <td width="50">
                                                        <?php if($row->Customercode_51 !=""):?> 
                                                            <?php echo '<span  class="badge label-upcoming"> Rawbank online</span>'; ?>
                                                        <?php else:?> 
                                                            <?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?>
                                                        <?php endif;?> 
                                                    </td>
                                                    <td width="25">
                                                        <?php  if($row->Status_2 == 6): ?>
                                                            <a style="cursor:pointer" onclick="verification('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>

                                                        <?php else : ?>
                                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <a style="cursor:pointer" href="<?php echo base_url().$row->Notefile_52; ?>"><span class="fa fa-fw text-red fa-file f14"> </span></a>
                                                    </td>

                                                </tr>
                                                <?php
                                                    if ($row->Beneficaire_15 == "DGRAD")
                                                            $paiements_dgrad = $paiements_dgrad  + $row->Contrevaleur_22;
                                                    if ($row->Beneficaire_15 == "DGI")
                                                            $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) $suspend = $suspend + 1;
                                                ?>
                                            <?php endforeach;?>

                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="col-md-12">
                                        <section id="cat_list" class="text-center marginTop150">
                                            <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                                <span class="d-block p-2 f14 text-black"> Aucun paiement trouv&eacute;!</span>

                                        </section>
                                     </div>

                                <?php endif; ?>
                                 </div>
                            <?php $chtml->box_body_closing(); ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <?php echo form_close(); ?>
        </div>
        <script type="text/javascript">

            $('#paiements_dgrad').html('<?php echo number_format($paiements_dgrad, 2, ",", " "); ?>');
            $('#paiements_dgda').html('<?php echo number_format($paiements_dgda, 2, ",", " "); ?>');
            $('#paiements_dgi').html('<?php echo number_format($paiements_dgi, 2, ",", " "); ?>');
            $('#commissions').html('<?php echo number_format($commissions, 2, ",", " "); ?>');
            $('#attente').html('<?php echo $suspend; ?>');
            $('#urgent').html('<?php echo $urgent; ?>');

            $("#contenter").unbind().on("click", ".item", function () {

                $("#close").addClass('d-none');
                $("#close_form").removeClass('d-none');
            });

            $('#table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "pageSize": 50,
            });

            function view(id, regie)
            {
                var url = '';
                if (regie === 'DGDA')
                {
                    var url = "<?php echo base_url($module . '/taxbulletin/display/preview'); ?>/" + id;
                }
                else if (regie === 'DGI')
                {
                    var url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
                }
                else if (regie === 'DGRAD')
                {
                    var url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
                }

                $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
                $.get(url, {previous_menu: "pending"}, function (data, status) {
                    $("#loader").html('');
                    $("#pager").html(data);

                });
            }

            function printQuittance(file)
            {
                var url = '<?php echo base_url('api/endpoints/sydonia'); ?>/' + file;
                //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
                // window.print();
                var w = window.open(url);

            }

            function print_payment(pid) {

                var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + pid;
                //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
                // window.print();
                var w = window.open(url);

                $(w).ready(function () {
                    w.print();
                });

            }

            $(document).ready(function (e) {
//                $('.tab-content').html($("#paiements_agence")[0].innerHTML);

//                $(".tab").on('click', function (e) {
//                    $('.tab-content').html('');
//                    $('.tab').removeClass('tab-active');
//
//                    var target = $(this).attr('data_target');
//                    event.currentTarget.classList.add('tab-active');
//                    $('.tab-content').html($(`${target}`)[0].innerHTML);
//                });
            });

            function openTab(event, tabContentId) {
                $('.tab').removeClass('tab-active');
                $(".tab-item").addClass('d-none');
                event.currentTarget.classList.add('tab-active');
                $("#" + tabContentId + "").removeClass('d-none');
            }
        </script>