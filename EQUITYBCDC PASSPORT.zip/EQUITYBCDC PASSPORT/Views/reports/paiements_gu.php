<?php 
$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;
?>
 <?php echo form_open_multipart('', array('id' => 'searchform', 'class' => '')); ?>
<div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
    <div class="statistic-box no-border no-padding" id="table">
            <div class="col-md-12 no-margin">
                <h1>Guichet unique(DGDA)</h1>
                <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente le rapport des paiements du guichet unique(DGDA).</span></h5>
            </div>
            <div class="col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">  
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Bureau </b></span><span id="slist"><?php echo form_dropdown('Office', $offices, '', ' id="Office" class="form-control" '); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-5 ">
                            <div class="form-group">
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">Initi&eacute;e entre le</span>
                                    <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                    <span class="input-group-addon">et le</span>
                                    <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-bitbucket pull-right"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 border-left">
                           <button class="btn btn-default" type="button" id="print">Imprimer <i class="fa fa-print text-gray"></i></button>
                        </div>
                    </div>
                
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
        <div id="message" class="col-md-12"></div>

        <div class="col-md-12 no-padding" id="filterResult">
           
            <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($bulletins)): ?>
                <div  class="table-responsive">
                    <table class="table table-hover table-striped ">
                        <thead>
                            <tr  class="bg-aqua-active">
                                <th width="5">#</th>
                                <th width="">Date</th>
                                <th width="">Bulletin</th>
                                <th width="">Service</th>
                                <th width="">Importateur</th>
                                <th width="">Bordereau</th>
                                <th with="">Quitt</th>
                                <th with="">Devise</th>
                                <th width="">Situation OP ou Caisse</th>
                                <th width="">Situation GU</th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ++$i; foreach ($bulletins as $row){
                                
                                $result = (isset($row->Results_13) && $row->Results_13 !="")? json_decode($row->Results_13) : '';
                            ?>
                            <input type="hidden" id="paiements" name="paiements[]" value="<?php echo $row->Id_0;?>"  />
                            <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                <td width="5"><b><?php echo $row->Id_0; ?></b></span></td>
                                <td <?php if($row->Integration_16 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Integration_16; ?></td>
                                <td><?php echo $row->Serie_7.$row->Number_8; ?></td>
                                <td class=""><?php echo $services[$row->Office_6]; ?></td>
                                <td><?php echo $row->Designation_23; ?></td>
                                <td><?php echo $row->Reference_19 ; ?></td>
                                <td class=""><?php echo (isset($row->Results_13) && $row->Results_13 !="")? $result->receiptSerial.$result->receiptNumber : ''; ?></td>
                                <td><?php echo 'CDF'; ?></td>
                                <td><b><?php echo number_format($row->Amount_25,2,","," "); ?></b></td>
                                <td><b><?php echo number_format($row->Amount_12,2,","," "); ?></b></td>
                                <td>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <section id="cat_list">

                    <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                        <span class="fa fa-warning text-gray mystyle4"></span>
                        <br/><br/>
                        Aucun paiement trouv&eacute;
                        <br/><br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
        <?php $chtml->box_body_closing(); ?>
</div>
<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">

//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

  


$("#searchform").submit(function(e){
    e.preventDefault();
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filter_paiements_gu'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode      : true,
                success: function(result){
                        $('#message').html('');
                        $('#filterResult').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
    
});


$("#print").click(function(){
        
        var data = $("#searchform").serialize();
        var paiements = $("#paiements").val();
      
        if(paiements != "")
        {
                get_print(data);
        }
        else
        {
                alert('Empty paiements');
        }
       
});

function view(id)
{
    var url ="<?php echo base_url($module.'/taxreports/display/gu_bulletin'); ?>/"  + id;
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}


function get_print(data)
{
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taximpression/display'); ?>/print_paiements_gu';
        $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode      : true,
                    success: function(result){
                       
                        //$('#filterResult').html(result);
                        print(result);
                        $("#message").html('');
                        
                    },
                    error:function(error){
                        alert('ERROR:'+error);
                    }
        });
}

function print(buffer)
{
    var w = window.open('<?php echo base_url()?>'+buffer);
}

$('#table').DataTable({
    "paging": true,
    "lengthChange": false,
    "searching": false,
    "ordering": true,
    "info": true,
    "autoWidth": false,
    "pageSize": 50
});

</script>

