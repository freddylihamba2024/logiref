<?php
$paiements = 0;
$paiements_dgi = 0;
$suspend = 0;
$urgent = 0;
$i = 0;
?>
<div class="col-md-12 pl-0 pr-0" id="loader"></div>
<div id="pager">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <div>
                <h1 class="text-blue f30">Liste des paiements en cours du traitement</h1>
                <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiementsen cours des traitements.</span></p> 
            </div>

        </div>
    </div>
    <div class="tab_container">
        <div class="tab-item-container">
            <div class="tab-item" id="paiements_agence">
                <div class="row">
                    <div class="col-md-12">
                        <div  id="message"></div>
                        <?php $chtml->box_body_opening('', true); ?>
                        <div class="row mb-3">
                            <div class="col-md-12 text-right">
                                <input type="text" id="searchInput" onkeyup="filterTable()"
                                       class="form-control d-inline-block p-2 rounded shadow-sm"
                                       placeholder="🔍 Rechercher..."
                                       style="max-width: 150px; font-size: 14px; border: 1px solid #ced4da;">
                            </div>
                        </div>
                        <div id="paiementslist">
                            <?php if (!empty($bulletins) || !empty($bulletins_batchs)): ?>
                                <table id="table" class="table table-hover table-striped">
                                    <thead >
                                        <tr class="bg-gray f12">
                                            <th class="f12">#</th>
                                            <th class="f12" width="50">Date</th>
                                            <th class="f12">D&eacute;signation</th>
                                            <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                            <th class="f12">Recette</th>
                                            <th class="f12">Montant</th>
                                            <th class="f12">Commissions</th>
                                            <th class="f12" width="50">Op&eacute;rateur</th>
                                            <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                            <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        #Block last BL
                                        foreach ($bulletins as $row) :

                                            $agence = (isset($guichets[$row->Agence_32])) ? $guichets[$row->Agence_32] : ' - ';
                                            $operateur = (isset($users[$row->User_15])) ? $users[$row->User_15] : ' - ';
                                            $dateTime = new DateTime($row->Date_1);
                                            $date = $dateTime->format('U');
                                            $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                        ?>
                                            <tr class="f12">
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td  width="80" <?php
                                                    if ($row->Status_2 == 4)
                                                        echo 'class="text-green"';
                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                        echo 'class="text-black"';
                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                        echo 'class="text-orange"';
                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                        echo 'class="text-red"';
                                                    ?> 
                                                >
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php
                                                    if ($row->Designation_23 == "")
                                                        echo "Bulletin de liquidation / " . $row->Nif_9;
                                                    else
                                                        echo $row->Designation_23;
                                                    ?>
                                                </td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td><?php echo $row->Serie_7 . '-' . $row->Number_8; ?></td>
                                                <td class="text-blue">
                                                    <?php echo 'CDF ' . number_format((float) $row->Amount_12, 2, ",", " "); ?> 
                                                </td>
                                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_26, 2, ",", " "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?></td>
                                                <td width="25">
                                                    <?php if ($row->Lot_22 == "saisi"): ?>
                                                        <a class="cursor-pointer" onclick="view_manual('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    <?php else: ?>
                                                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    <?php endif; ?>
                                                </td>
                                                <td width="25">
                                                    <?php if (file_exists(base_url('api/endpoints/sydonia') . '/' . $row->Pdfcontent_18)): ?>
                                                        <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    <?php else: ?>
                                                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php
                                                $paiements = $paiements + (float) $row->Amount_12;
                                                if ($row->Status_2 == 1 || $row->Status_2 == 2)
                                                    $urgent = $urgent + 1;
                                            ?>
                                        <?php endforeach; ?>

                                        <?php
                                            #Block last BL Batchs
                                            foreach ($bulletins_batchs as $row):
                                                $agence = (isset($guichets[$row->Agence_24])) ? $guichets[$row->Agence_24] : ' - ';
                                                $operateur = (isset($users[$row->User_13])) ? $users[$row->User_13] : ' - ';
                                                $dateTime = new DateTime($row->Date_1);
                                                $date = $dateTime->format('U');
                                                $deadline = date('Y-m-d', strtotime("+1 day", $date));
                                                $bulletin= json_decode($row->Bulletins_22);

                                                $bl_list = json_decode($row->Bulletins_22, true); 
                                                $total_bl = isset($bl_list['years']) ? count($bl_list['years']) : 0;
                                        ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i; ?></b></span></td>
                                                <td  width="80" <?php
                                                    if ($row->Status_2 == 4)
                                                        echo 'class="text-green"';
                                                    elseif ($deadline > gmdate('Y-m-d'))
                                                        echo 'class="text-black"';
                                                    elseif ($deadline == gmdate('Y-m-d'))
                                                        echo 'class="text-orange"';
                                                    elseif ($deadline < gmdate('Y-m-d'))
                                                        echo 'class="text-red"';
                                                    ?> 
                                                >
                                                    <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue">
                                                    <?php
                                                    if ($row->Designation_15 == "")
                                                        echo "Lot des bulletins / " . $row->Nif_8;
                                                    else
                                                        echo $row->Designation_15;
                                                    ?>
                                                </td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td>
                                                    <span class="badge badge-secondary">Lot de bulletins (<?= $total_bl ?>)</span>
                                                </td>
                                                <td class="text-blue">
                                                    <?php echo'CDF ' . number_format($row->Amount_11, 2, ",", " "); ?> 
                                                </td>
                                                <td class="text-black"><?php echo 'CDF ' . number_format($row->Commission_20, 2, ",", " "); ?></td>
                                                <td width="50">
                                                    <?php echo '<span  class="text-gray"> ' . $operateur . '</span>'; ?>
                                                </td>
                                                <td width="25">
                                                    <a style="cursor:pointer" onclick="preview_batch('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                </td>
                                                <td width="25">
                                                    <?php if (file_exists(base_url('api/endpoints/sydonia') . '/'."" )): ?>
                                                        <a style="cursor:pointer" onclick="printQuittance('<?php echo ""; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                    <?php else: ?>
                                                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach;?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="col-md-12">
                                    <section id="cat_list" class="text-center marginTop150">
                                        <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                                        <span class="d-block f14 text-black p-2">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                                    </section>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php $chtml->box_body_closing(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br/><br/>

<script type="text/javascript">

    $("#contenter").unbind().on("click", ".item", function () {

        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
    });

    $('#paiements').html('<?php echo number_format($paiements, 2, ",", " "); ?>');
    $('#paiements_dgi').html('<?php echo number_format($paiements_dgi, 2, ",", " "); ?>');
    $('#attente').html('<?php echo $suspend; ?>');
    $('#urgent').html('<?php echo $urgent; ?>');


    function view(id, regie, recette = null)
    {
        var url = '';
        if (regie === 'DGDA')
        {
            '<?php if ($_SESSION['Logiref_role'] != 4): ?>'
                var url = "<?php echo base_url($module . '/taxbulletin/display/preview'); ?>/" + id;
            '<?php else : ?>'
                var url = "<?php echo base_url($module . '/taxbulletin/display/edit'); ?>/" + id;
                '<?php endif; ?>'
        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {previous_menu: "nvalidated"}, function (data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function preview_batch(id)
    {
        //var url = "<?php echo base_url($module . '/taxbulletin/display/batch_confirmation_from_operator'); ?>/" + id;
        var url = "<?php echo base_url($module . '/taxbulletin/display/batch_treatments_current'); ?>/" + id;
        
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, {previous_menu: "nvalidated"}, function (data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function view_manual(id, regie)
    {
        var url = "<?php echo base_url($module . '/taxothers/display/preview'); ?>/" + id;
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function (data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }

    function filterTable()
    {
        var input = document.getElementById("searchInput");
        var filter = input.value.toLowerCase();
        var table = document.getElementById("table");
        var tr = table.getElementsByTagName("tr");

        for (var i = 1; i < tr.length; i++) {  // Commence à partir de 1 pour ignorer l'en-tête
            var td = tr[i].getElementsByTagName("td");
            var showRow = false;

            for (var j = 0; j < td.length; j++) {
                if (td[j] && td[j].textContent.toLowerCase().indexOf(filter) > -1) {
                    showRow = true;
                    break;
                }
            }
            tr[i].style.display = showRow ? "" : "none";
        }
    }

</script>