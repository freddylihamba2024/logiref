    <input type="hidden" name = "data" value='<?php echo(!empty($data))? json_encode($data): '';?>'>
    <input type="hidden" id="nbre" value="<?= count($_SESSION["agences"]) ?>"/>
    <?php if (!empty($agences)): ?>
        <div class="table-response">
            <table id="table" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-aqua text-white">
                        <th width="5">#</th>
                        <th>Date</th>
                        <th width="30%">Agence</th>
                        <th class="text-center">Nbre de paiements</th>
                        <th>Montant</th>
                        <th>Commissions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php                                   
                        $i = 1;
                        foreach($agences as $row){
                        if($i==1){
                    ?>
                        <tr>
                            <td width="2%"><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                            <td width="20%"><?php echo $row->Date_1 ?></td>
                            <td><?php echo $row->Nom_4; ?></td>
                            <td class="text-center" ><?php if(isset($data[$row->Id_0]['nombre'])) echo $data[$row->Id_0]['nombre']; else echo 0;?></td>
                            <td><?php if(isset($data[$row->Id_0]['paiement'])) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," ");  else echo 0; ?></td>
                            <td><?php if(isset($data[$row->Id_0]['commission'])) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
                        </tr>

                    <?php 
                        }
                    $i++;
                        } ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <section class="m-5">
            <h4 align="center">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <b>Aucun rapport trouv&eacute pour cette p&eacute;riode !</b>
            </h4>
        </section>
    <?php endif; ?>
<script type="text/javascript">

    $('.table').DataTable({
        pageLength: 10,
        responsive: true,
        "bLengthChange": false,
        "bFilter": false,
        paging: true,
        searching: true,

    });

    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });

</script>