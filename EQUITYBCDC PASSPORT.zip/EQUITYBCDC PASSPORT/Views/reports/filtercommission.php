<?php 
$equivalence =0;
$calcul =0;
$tva = 0.16;
if(isset($_SESSION['Bank_rates'])){
    $bank = json_decode($_SESSION['Bank_rates'], true);
    $usd = $bank['Dollar_4'];
    $eur = $bank['Euro_5'];
    $rand = $bank['Rand_6'];
    $pound = $bank['Pound_7'];
}
?>

<div class="col-md-12 no-padding" id="">
            <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($paiement)): ?>
            <table id="" class="table table-hover table-striped">
                <thead>
                    <tr class="bg-aqua-active">
                        <th>#</th>
                        <th>Date</th>
                        <th>Client</th>
                        <th>Commission</th>
                        <th>Taxe sur valeur ajoute&eacute;</th>
                        <th>Guichet</th>
                        
                    </tr>
                </thead>
                <tbody >
                <?php 
                    $i = 1;
                    foreach($paiement as $row){
                    ?>
                        <tr>
                            <td width="2"><?php echo $i; ?></td>
                            <td width="100"><?php echo $row->Datevaleur_31; ?></td>
                            <td width="150"><?php echo $row->Designation_14; ?></td>
                            <td class="text-black" width="100"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?>
                                <?php if($row->Devise_24 == "USD") :
                                    $equivalence = $row->Commission_23*$usd;
                                ?>
                                    <br/>
                                    <span class="text-gray"><?php echo 'CDF '.number_format($equivalence,2,","," "); ?></span>
                                <?php endif;?>
                            </td>
                            <td width="150"><?php $calcul = $row->Commission_23*$tva; ?>
                                    <span><?php echo 'CDF '.number_format($calcul,2,","," "); ?></span>
                            </td>
                            <td width="150"><?=  isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] :"-"; ?></td>
                            
                        </tr>
                    <?php 
                        $i++;
                    } 
                    ?>

                </tbody>
            </table>
            <?php else:?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                    <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun paiement trouv&eacute;!<br/>
                    </div>
                </section>
            <?php endif;?>
            <?php $chtml->box_body_closing(); ?>
        </div>

