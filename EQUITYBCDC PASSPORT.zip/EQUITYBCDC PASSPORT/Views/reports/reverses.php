<?php 

$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>



<div class="row">
    <div class="col-md-1"></div>    
    <div class="col-md-10 p-3">
        <div id="loader"></div>
        <?php if(!empty($encaissements)): ?>
            <div class="ibox bg-white">
                    <div class="ibox-title border-bottom">
                        <h2 class="text-blue">Reversés...</h2>
                    </div>
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                            <div class="row">
                                    <div class="col-md-4 no-padding small-box">
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>B&eacute;n&eacute;ficiaire</b></span><?php echo form_dropdown('Beneficaire_15', $regies, '', ' id="" class="form-control" '); ?>
                                        </div>
                                    </div><br>
                                    <div class="col-md-4 no-padding  small-box">
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('guichet', $guichets, '', ' id="recette" class="form-control" '); ?>
                                        </div>
                                    </div><br>
                                    <div class="col-md-4 no-padding  small-box">
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>User</b></span><?php echo form_dropdown('user', $users, '', ' id="" class="form-control" '); ?>
                                        </div>
                                    </div><br>
                                   
                            </div><br>
                            <div class="row">
                                <div class="col-md-9 no-padding  small-box">
                                    <div class="input-group input-daterange ">
                                        <span class="input-group-addon">Initi&eacute;e entre le</span>
                                        <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                        <span class="input-group-addon">et le</span>
                                        <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>

                                </div>
                                <div class="col-md-1">
<!--                                    <button  class="btn btn-danger text-white" id="print" type="button"> <i class="fa fa-print"></i></button>&nbsp;&nbsp;<br/>-->
                                </div>

                                <div class="col-md-1">
                                    <button type="button" class="btn btn-success text-white bg-blue-active" id="excell"><i class="fa fa-file-excel-o"></i></button>&nbsp;&nbsp;<br/>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                    <div class="col-lg-12 table-responsive" id="filterResult">
                            <table class="table table-hover table-striped" id="table">
                                    <thead class="bg-gray f12" >
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>B&eacute;n&eacute;ficiaire</th>
                                        <th>Recette</th>
                                        <th>Montant</th>
                                        <th>Agence</th>
                                        <th>Op&eacute;rateur</th>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $paiements = 0;
                                            $commissions = 0;
                                            $suspend = 0;
                                            $urgent = 0;

                                            foreach ($encaissements as $row){
                                
                                        ?>
                                        <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                                <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($row->Datevaleur_31 > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($row->Datevaleur_31 ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($row->Datevaleur_31 < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                    <?php echo $row->Datevaleur_31; ?>
                                                </td>
                                                <td class="text-blue"><?php if($row->Designation_14 =="" && $row->Beneficaire_15 =="DGDA") echo "Bulletin de liquidation / ".$row->Nif_13; else echo $row->Designation_14; ?></td>
                                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                                <?php if($row->Beneficaire_15=="DGRAD" && ($row->Sydonia_44 == "0" || $row->Sydonia_49 == "0")){?>
                                                    <td><?php echo $row->Typerecette_17." ".$row->Noteid_26; ?></td>
                                                <?php } else{?>
                                                    <td><?php echo $row->Typerecette_17; ?></td>
                                                <?php } ?>
                                                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                                      <br/>
                                                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                                    <?php endif;?>
                                                </td>
<!--                                                <td class="text-black"><?php e//cho $days." "."jours"; ?></td>
                                                <td><?php //$penalite =$row->Montant_11*0.03*$days ?>
                                                    <span class="text-red"><?php //echo 'CDF '.number_format($penalite,2,","," "); ?></span>
                                                </td>-->
                                                <td><?php echo isset($guichets[$row->Guichet_21])?$guichets[$row->Guichet_21]: "" ; ?></td>
                                                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                        </tr>
                                        <?php 
                                            $paiements = $paiements + $row->Contrevaleur_22;
                                            $commissions = $commissions + $row->Commission_23;
                                            if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                                            if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
                                            } 
                                       ?>
                                    </tbody>
                            </table>
                       </div>
        <?php else: ?> 
            <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                <span class="d-block f14 text-black p-2"><b>Aucun paiement revers&eacute;!</b></span>        
            </section>
        <?php endif; ?>
    </div>
    
</div>
<!--    <div class="col-md-1">
        <a href="<?php //echo base_url($module.'/taxreports/set/reports'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>-->

</div>





<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$("#searchform").submit(function(e){
    
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filter_reverses'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#filterResult').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});


 $("#excell").click(function(){
        //alert("tres");
            var url = '<?php echo base_url($module.'/taximpression'); ?>/display/reverses';
            
             $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
             $.get(url, function(data, status){
                $("#loader").html('');
                print(data);

            });
    });
    
    function print(buffer) 
    {
        var link = document.createElement('a');
        link.href = '<?php echo base_url()?>' + buffer;
        link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>
