<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold; position: absolute">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RAPPORT DES BULLETINS DE LIQUIDATION
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Ann&eacute;</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Num&eacute;ro BL</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Bureau</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Agence</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Montant</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Num&eacute;ro imp&ocirc;t</b></td>
    </tr>

    <?php 
        $i=2;
        foreach($bulletins as $row)
        {
            
    ?>
            <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                <td width="15%" style="font-size:1.1em;"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                <td width="15%" style="font-size:1.1em;"><?php echo "2019"; ?></td>
                <td width="15%" style="font-size:1.1em;"><?php echo "L10"; ?></td>
                <td style="font-size:1.1em;"><?php echo $row->Bureau_11; ?></td>
                <td style="font-size:1.1em;"><?php echo "Kapela"; ?></td>
                <td width="15%" style="font-size:1.1em;"><?php echo number_format($row->Amount_14,2,","," "); ?> </td>
                <td><?php echo $row->Nifimportateur_10; ?></td>
            </tr>
    <?php 
        $i++;   
        }
    ?>
    

</table>



