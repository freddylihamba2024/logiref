<?php 

$userid = $this->session->userdata["user_id"];
$usertype = $this->session->userdata["user_type"];
$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>


<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <?php $chtml->box_body_opening('', true); ?>
        <div class="col-md-12"  id="content">
                <div id="paiementslist">
                    <?php if(!empty($encaissements)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Retard</th>
                                <th>Penalit&eacute;</th>
                                <th>Agence</th>
                                <th>Op&eacute;rateur</th>
                            </tr>
                        </thead>
                        <tbody>
                        
                        <?php  foreach($encaissements as $row){ 
                            $penalite=0;
                            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                            
                            $date1 = $row->Datevaleur_31;
                            $date2 = gmdate('Y-m-d');
                            $diff = abs(strtotime($date2) - strtotime($date1));

                            $years = floor($diff / (365*60*60*24));
                            $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                            $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                        ?>
                            <tr>
                                <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($row->Datevaleur_31 > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($row->Datevaleur_31 ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($row->Datevaleur_31 < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                    <?php echo $row->Datevaleur_31; ?>
                                </td>
                                <td class="text-blue"><?php if($row->Designation_14 =="" && $row->Beneficaire_15 =="DGDA") echo "Bulletin de liquidation / ".$row->Nif_13; else echo $row->Designation_14; ?></td>
                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                <?php if($row->Beneficaire_15=="DGRAD" && ($row->Sydonia_44 == "0" || $row->Sydonia_49 == "0")){?>
                                    <td><?php echo $row->Typerecette_17." ".$row->Noteid_26; ?></td>
                                <?php } else{?>
                                    <td><?php echo $row->Typerecette_17; ?></td>
                                <?php } ?>
                                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                      <br/>
                                      <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                    <?php endif;?>
                                </td>
                                <td class="text-black"><?php echo $days." "."jours"; ?></td>
                                <td><?php $penalite =$row->Montant_11*0.03*$days ?>
                                    <span class="text-red"><?php echo 'CDF '.number_format($penalite,2,","," "); ?></span>
                                </td>
                                <td><?php echo isset($guichets[$row->Agence_20])?$guichets[$row->Agence_20]: "" ; ?></td>
                                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>

                            </tr>
                        <?php 
                                $paiements = $paiements + $row->Contrevaleur_22;
                                $commissions = $commissions + $row->Commission_23;
                        } 
                        ?>
                        </tbody>    
                    </table>
                    <?php else:?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                Aucun paiement trouv&eacute;!<br/>
                            </div>
                        </section>
                    <?php endif;?>
                </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
        <?php echo form_close(); ?>

