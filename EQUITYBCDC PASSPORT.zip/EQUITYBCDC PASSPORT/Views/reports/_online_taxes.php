<?php
    $userid = $this->session->userdata["user_id"];
    $usertype = $this->session->userdata["user_type"];
    $paiements = 0;
    $validated = 0;
    $suspend = 0;
    $regulate = 0;
    $notreated = 0;
    $i = 0;
    /* * *
    [
    ''=>'',
    '1' => 'Initialisé' (Status=0),
    '2' => 'Valid&eacute;' (Status= 1 & Chekerid>0),
    '3' => 'Regularisation Finacle' (Status= 5),
    '4' => 'Regularisation Logirad' (Status= 6),
    '5' => 'Failed' (Status=1 & Chekerid=0, Mauvaise réference OMNI),
    '6' => 'Reversé'
    ]
    * ** */
?>

<div id="pager"  class="col-md-12"> 
    <?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2): ?>
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements validés</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer"  ><b>CDF <span id="validated"></span></b></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements en attente</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer"  ><b>CDF <span id="attente"></span></b></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span>Paiements non traités</span><br/><br/>
                        <p class="f18"><a style="cursor:pointer" ><b>CDF <span id="nottreated"></span></b></a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="small-box bg-white">
                    <div class="inner">
                        <span class="">Total commissions</span><br/><br/>
                        <p class="text-green f18"><b>CDF <span id="commissions"></span></b></p>
                    </div>
                </div>
            </div>
        </div>

        <?php $chtml->box_body_opening('', true); ?>
        <div class="statistic-box no-border no-padding">
            <div class="col-md-12 no-margin">
                <h1>Paiement en ligne</h1>
                <h5 class="page-header"></h5>
                <!-- <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente le rapport des paiements passepports en agence.</span></h5> -->
            </div>
            <div class="col-sm-12 mt-2">
                <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                <div class="row">
                    <!--                <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="form-group">  
                                            <div class="input-group">
                                                <span class="input-group-addon"><b>Référence </b></span><?php echo form_input('Noteid_26', set_value('Noteid_26', ''), ' id="noteid" class="form-control"'); ?>
                                            </div>
                                        </div>
                                    </div>-->
                    <div class="col-md-4 col-sm-3 col-xs-12 border-left">
                        <div class="form-group">  
                            <div class="input-group">
                                <span class="input-group-addon"><b>Status </b></span><?php echo form_dropdown('Status', ['' => '', '3' => 'Valid&eacute;', '5' => 'En regularisation', '1' => 'Non traité', '2' => 'Bulletins enregistrés'], '', ' id="" class="form-control"'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <div class="input-daterange input-group">
                                <span class="input-group-addon">Initi&eacute;e entre le</span>
                                <input class="input-sm form-control" name="start" value="" id="datepicker1" type="text">
                                <span class="input-group-addon">et le</span>
                                <input class="input-sm form-control" name="end" value=""  id="datepicker2" type="text">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn btn-bitbucket pull-right"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>

        <div id="loader1" class="col-md-12"></div>

        <?php $chtml->box_body_opening('', true); ?>
        <div class="col-md-12 no-padding" id="filterResult">
            <?php if (!empty($bulletins)): ?>
                <div  class="table-responsive">
                    <table class="table table-hover table-striped ">
                        <thead>
                            <tr  class="bg-aqua-active">
                                <th width="5">#</th>
                                <th width="">Date</th>
                                <th>Statut</th>
                                <th width="">Bulletin</th>
                                <th width="">Service</th>
                                <th width="">Importateur</th>
                                <th width="">Bordereau</th>
                                <th with="">Quitt</th>
                                <th with="">Devise</th>
                                <th width="">Situation OP ou Caisse</th>
                                <th width="">Situation GU</th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $paiements = 0;
                            $commissions = 0;
                            $suspend = 0;
                            $urgent = 0;
                            $i = 0;
                            ?>

                            <?php
                            ++$i;
                            foreach ($bulletins as $row):

                                $result = (isset($row->Results_13) && $row->Results_13 != "") ? json_decode($row->Results_13) : '';
                                ?>
                            <input type="hidden" id="paiements" name="paiements[]" value="<?php echo $row->Id_0; ?>"  />
                            <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                <td width="5"><b><?php echo $row->Id_0; ?></b></span></td>
                                <td <?php if ($row->Integration_16 !== gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Integration_16; ?></td>
                                <td>
                                    <?php if ($row->Status_2 == "2" && $row->Results_13 != ""): ?>
                                        <span class="badge badge-dark">Enregistré</span>
                                    <?php elseif ($row->Status_2 == "5" OR $row->Status_2 == "6") : ?>
                                        <span class="badge badge-warning">En regularisation</span>
                                    <?php elseif ($row->Status_2 == "1" && $row->Results_13 == ""): ?>
                                        <span class="badge badge-danger">Non traité</span>
                                    <?php elseif ($row->Status_2 == "3" && $row->Results_13 == ""): ?>
                                        <span class="badge badge-success">Validé</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row->Serie_7 . $row->Number_8; ?></td>
                                <td class=""><?php echo $offices['DGDA'][$row->Office_6]; ?></td>
                                <td><?php echo $row->Designation_23; ?></td>
                                <td><?php echo $row->Reference_19; ?></td>
                                <td class=""><?php echo (isset($row->Results_13) && $row->Results_13 != "") ? $result->receiptSerial . $result->receiptNumber : ''; ?></td>
                                <td><?php echo 'CDF'; ?></td>
                                <td><b><?php echo number_format($row->Amount_25, 2, ",", " "); ?></b></td>
                                <td><b><?php echo number_format($row->Amount_12, 2, ",", " "); ?></b></td>
                                <td>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                </td>
                            </tr>

                            <?php
                            $commissions = $commissions + $row->Commission_26;

                            if ($row->Status_2 == 3 && $row->Results_13 != "")
                                $validated = $validated + $row->Amount_25;
                            if ($row->Status_2 == 5 || $row->Status_2 == 6)
                                $regulate = $regulate + $row->Amount_25;
                            if ($row->Status_2 == 1 && $row->Results_13 == "")
                                $notreated = $notreated + $row->Amount_25;

                        endforeach;
                        ?>

                        </tbody>
                    </table>
                <?php else: ?>
                    <section id="cat_list">
                        <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                            Aucun paiement trouv&eacute;!<br/>
                        </div>
                    </section>
                <?php endif; ?>
            </div>
        </div> 
        <?php $chtml->box_body_closing(); ?>
    <?php endif; ?>
</div>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    $('#paiements').html('<?php echo number_format(count($bulletins), 0, ",", " "); ?>');
    $('#commissions').html('<?php echo number_format($commissions, 0, ",", " "); ?>');
    $('#validated').html('<?php echo number_format($validated, 0, ",", " "); ?>');
    $('#attente').html('<?php echo number_format($regulate, 0, ",", " "); ?>');
    $('#nottreated').html('<?php echo number_format($notreated, 0, ",", " "); ?>');

    $('#table_ponline').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50,
    });

    $('#noteid').on('input', function () {
        var currentText = $(this).val();
        var upperText = currentText.toUpperCase();
        $(this).val(upperText);
    });

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $("#searchform").submit(function (e) {
        e.preventDefault();

        $("#loader1").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        var url = '<?php echo base_url($module . '/taxreports/display/filter_online_taxes'); ?>';
        var data = $(this).serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (result) {
                $('#loader1').html('');
                $('#filterResult').html(result);
            },
            error: function (error) {
                alert('ERROR!' + error);
            }
        });
    });

    function view(id)
    {
        var url = "<?php echo base_url($module . '/taxreports/display/gu_bulletin'); ?>/" + id;
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function (data, status) {
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('d-none');
            $("#form").removeClass('d-none');
        });
    }

    function print_payment(pid) {
        var url = '<?php echo base_url($module . '/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function () {
            w.print();
        });
    }
</script>