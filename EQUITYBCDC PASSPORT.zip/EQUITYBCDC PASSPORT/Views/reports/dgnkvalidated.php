<?php

    $userid = $_SESSION["userdata"]["user_id"];
    $usertype = $_SESSION["userdata"]["user_type"];
    $paiements = 0;
    $commissions = 0;
    $suspend = 0;
    $urgent = 0;
    $i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager">
    <div class="col-md-12">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <div>
                <h1 class="text-blue f30">Liste des paiements valid&eacute;s</h1>
                <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble des paiements valid&eacutes.</span></p>
            </div>

        </div>
    </div>

    <div class="col-md-12">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box p-2 bg-white">
                        <div class="inner">
                            <span class="">Total paiements</span><br/><br/>
                            <p class="text-blue f18"> <b>CDF <span id="paiements"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box p-2 bg-white">
                        <div class="inner">
                            <span class="">Total commissions</span><br/><br/>
                            <p class="text-green f18"><b>CDF <span id="commissions"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box p-2 bg-white">
                        <div class="inner">
                            <span>Paiements en attente</span><br/><br/>
                            <p class="f18"><a style="cursor:pointer" onclick="filter('attente')" ><b><span id="attente"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="small-box p-2 bg-white">
                        <div class="inner">
                            <span>Paiements urgents</span><br/><br/>
                            <p class="f18"><a style="cursor:pointer" onclick="filter('urgents')" ><b><span id="urgent"></span></b> <span class="fa fa-fw text-red fa-filter"> </span></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12 pt-3">
            <div id="message"></div>
            <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($encaissements)) : ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th width="50">Date</th>
                                <th>D&eacute;signation</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th width="50">Op&eacute;rateur</th>
                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php
                        #Block DGRK et DGPEK
                        foreach($encaissements as $row)
                        {
                            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        ?>
                            <tr>
                                <td width="5"><b>#</b></span></td>
                                <td  width="80" <?php if($row->Status_2==3) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-BLACKS"'; ?> >
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                <td><?php if($row->Beneficaire_15 == "DGRK") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGPEK")echo $row->Noteid_26 ; ?></td>
                                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?>
                                    <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                    <br/>
                                    <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                    <?php endif;?>
                                </td>
                                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                <td width="50"><?php echo '<span  class="text-muted"> '.$operateur.'</span>'; ?></td>
                                <?php if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                                    <td width="25">
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$_SESSION["userdata"]["user_id"]){ ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                        <?php }else { ?>
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                        <?php } ?>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                    </td>
                                <?php }else{ ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                    </td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php
                            $paiements = $paiements + $row->Contrevaleur_22;
                            $commissions = $commissions + $row->Commission_23;
                            if($row->Status_2==1 && $row->Checkerid_10==0 && $deadline < gmdate('Y-m-d')) $suspend = $suspend + 1;
                            if($row->Status_2==1 && $row->Checkerid_10==0 && $deadline ==gmdate('Y-m-d')) $urgent = $urgent + 1;
                        }
                        ?>

                        </tbody>
                    </table>
                    <?php else:?>
                        <div class="col-md-12">
                            <section id="cat_list" class="text-center marginTop150">
                                <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                    <span class="d-block p-2 f14 text-black"> Aucun paiement trouv&eacute;!</span>
                                    </div>
                            </section>
                        </div>
                    <?php endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>
    </div>

</div>


<script type="text/javascript">

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": false,
        "info": false,
        "autoWidth": false,
        "pageSize": 20
    });

    $('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
    $('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
    $('#attente').html('<?php echo $suspend; ?>');
    $('#urgent').html('<?php echo $urgent; ?>');

    function view(id, regie)
    {
        var url ='';

        if(regie === 'DGPEK')
        {
            '<?php if($_SESSION['Logiref_role'] !=4): ?>'
                var url ="<?php echo base_url($module.'/taxdgpek/display/preview'); ?>/"  + id;
            '<?php else :?>'
                var url ="<?php echo base_url($module.'/taxdgpek/display/edit'); ?>/"  + id;
            '<?php endif; ?>'

        }
        else if(regie === 'DGRK')
        {
            '<?php if($_SESSION['Logiref_role'] !=4): ?>'
                var url ="<?php echo base_url($module.'/taxdgrk/display/preview'); ?>/"  + id;
            '<?php else :?>'
                var url ="<?php echo base_url($module.'/taxdgrk/display/edit'); ?>/"  + id;
            '<?php endif; ?>'

        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        $.get(url, function(data, status){
            $("#message").html('');
            $("#pager").html(data);
            $("#form").addClass('d-none');
            $("#form").removeClass('d-none');
        });
    }

    function print_payment(pid){

            var url = '<?php echo base_url($module.'/taximpression/display/attestation_dgnk'); ?>/' + pid;
            //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
            // window.print();
            var w = window.open(url);

            $(w).ready(function(){
                w.print();
            });

    }
</script>