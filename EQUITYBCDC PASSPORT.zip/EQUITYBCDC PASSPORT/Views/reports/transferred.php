<?php
    $paiements = 0;
    $commissions = 0;
    $suspend = 0;
    $urgent = 0;
?>

<div id="pager"  class="col-md-12">
    <div class="col-md-12">
        <div class="statistic-box no-border">
            <div class="col-md-12 pl-0 pr-0">
                <h2 class="f30 text-blue">Paiements revers&eacute;s</h2>
                <p class="page-header"><span class="text-black" >Cette section vous pr&eacute;sente l'ensemble des paiements revers&eacute;s.</span></p>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div id="loader1"></div>
        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($encaissements)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th class="f12"></th>
                                <th class="f12">Revers&eacute; par</th>
                                <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                <th class="center f12">Nombre de paiements</th>
                                <th class="f12">Montant</th>
                                <th class="f12">Date</th>
                                <th class="f12"><span class="fa fa-fw fa-folder f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            foreach($encaissements as $row)
                            {
                        ?>
                            <tr>
                                <td class="f12"><b>#</b></td>
                                <td class="f12"><?= isset($users[$row->Makerid_7]) ? $users[$row->Makerid_7] : ""; ?></td>
                                <td class="f12"><?php echo $row->Beneficiaire_10; ?></td>
                                <td class="center f12"><?php echo $row->Nombrepaiement_22; ?></td>
                                <td class="f12">
                                    <?php
                                            if($row->Devise_9 == ""):
                                                echo 'CDF '.number_format($row->Contrevaleur_16,2,","," "); ?>
                                    <?php
                                            else:
                                                echo $row->Devise_9.' '.number_format($row->Contrevaleur_16,2,","," ");

                                            endif;
                                    ?>
                                </td>
                                <td class="f12"><?php echo $row->Date_1 ?></td>
                                <td class="f12"><a class="cursor-pointer" onclick="view('<?php echo $row->Filepath_24; ?>')" ><span class="fa fa-file-excel-o text-green f14"> </span></a></td>
                            </tr>
                        <?php
                            }
                        ?>
                        </tbody>
                    </table>
                    <?php else:?>
                        <div class="col-md-12">
                            <section id="cat_list" class="text-center mb-5 mt-5">
                                    <span class="d-block p-2 "><span class="fa fa-flask text-black mystyle4" ></span></br>
                                    <span class="d-block p-2 f14 text-black">Aucun reversement effectu&eacute;!</span>
                                </div>
                            </section>
                        </div>
                    <?php endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?>
        <?php echo form_close(); ?>
    </div>
</div>
<br/><br/>

<script type="text/javascript">
    $("#table").DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": false,
        "autoWidth": false,
        "pageSize": 50,
        "language": {
            "paginate": {
                "next": "<i class='fa fa-chevron-right'></i>",
                "previous": "<i class='fa fa-chevron-left'></i>"
            },
            "search": "Rechercher :",
            "lengthMenu": "Afficher _MENU_ entrées",
            "zeroRecords": "Aucun enregistrement trouvé",
            "infoEmpty": "Aucune donnée disponible",
            "infoFiltered": "(filtré à partir de _MAX_ total des enregistrements)"
        }
    });

    function view(filepath) {

        const link = document.createElement('a');

        // Vérification de l'existence du fichier
        fetch(filepath, { method: 'HEAD' }).then(response => {
            if (response.ok) {
                // Si le fichier existe, procéder au téléchargement
                link.href = filepath;
                link.download = filepath.split('/').pop();
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
            else {
                // Si le fichier n'existe pas
                $("#loader1").html("<div class='alert alert-warning'>Le fichier n'existe pas ou est inaccessible..<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button></div>");
            }
        })
        .catch(() => {
            // Gestion des erreurs en cas de problème de connexion
            $("#loader1").html("<div class='alert alert-warning'>Erreur lors de l'exportation du fichier...<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button></div>");
        });
    }

</script>