
<?php 

$paiements = 0;
$commissions = 0;
$suspend = 0;
$urgent = 0;
?>
<div class="col-lg-12 table-responsive" id="filterResult">

    
    <?php if(!empty($encaissements)): ?>
            <table class="table table-hover table-striped" id="table">
                <thead class="bg-gray f12" >
                    <th>#</th>
                    <th>Date</th>
                    <th>Client</th>
                    <th>B&eacute;n&eacute;ficiaire</th>
                    <th>Recette</th>
                    <th>Montant</th>
                    <th>Retard</th>
                    <th>Penalit&eacute;</th>
                    <th>Agence</th>
                    <th>Op&eacute;rateur</th>
                </thead>
                <tbody>
                    <?php  foreach($encaissements as $row){ 
                        $penalite=0;
                        $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                        $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';

                        $date1 = $row->Datevaleur_31;
                        $date2 = gmdate('Y-m-d');
                        $diff = abs(strtotime($date2) - strtotime($date1));

                        $years = floor($diff / (365*60*60*24));
                        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                    ?>
                    <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                        <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($row->Datevaleur_31 > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($row->Datevaleur_31 ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($row->Datevaleur_31 < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                            <?php echo $row->Datevaleur_31; ?>
                        </td>
                        <td class="text-blue"><?php if($row->Designation_14 =="" && $row->Beneficaire_15 =="DGDA") echo "Bulletin de liquidation / ".$row->Nif_13; else echo $row->Designation_14; ?></td>
                        <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                        <?php if($row->Beneficaire_15=="DGRAD" && ($row->Sydonia_44 == "0" || $row->Sydonia_49 == "0")){?>
                            <td><?php echo $row->Typerecette_17." ".$row->Noteid_26; ?></td>
                        <?php } else{?>
                            <td><?php echo $row->Typerecette_17; ?></td>
                        <?php } ?>
                        <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                            <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                              <br/>
                              <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                            <?php endif;?>
                        </td>
                        <td class="text-black"><?php echo $days." "."jours"; ?></td>
                        <td><?php $penalite =$row->Montant_11*0.03*$days ?>
                            <span class="text-red"><?php echo 'CDF '.number_format($penalite,2,","," "); ?></span>
                        </td>
                        <td><?php echo isset($guichets[$row->Guichet_21])?$guichets[$row->Guichet_21]: "" ; ?></td>
                        <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                    </tr>
                    <?php 
                        $paiements = $paiements + $row->Contrevaleur_22;
                        $commissions = $commissions + $row->Commission_23;
                        } 
                    ?>
                </tbody>
        </table>
    <?php else: ?> 
            <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                <span class="d-block f14 text-black p-2"><b>Aucun paiement en retard de versement!</b></span>        
            </section>
    <?php endif; ?>



        
</div>