<div class="col-md-12 no-padding" id="filterResult">
    <input type="hidden" value='<?php echo(!empty($bulletins))? json_encode($bulletins): '';?>' name="paiements" />
    <?php $chtml->box_body_opening('', true); ?>
    <?php if(!empty($bulletins)): ?>
        <div  class="table-responsive">
            <table class="table table-hover table-striped ">
                <thead>
                    <tr  class="bg-aqua-active">
                        <th width="5">#</th>
                        <th width="">Date</th>
                        <th width="10">Bulletin</th>
                        <th width="">Service</th>
                        <th width="">Importateur</th>
                        <th width="">Bordereau</th>
                        <th with="">Quitt</th>
                        <th with="">Devise</th>
                        <th width="">Montant du bulletin</th>
                        <th width="">Montant pay&eacute;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ++$i; foreach ($bulletins as $row){

                        $result = json_decode($row->Results_13);
                    ?>
                    <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                        <td <?php if($row->Integration_16 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Integration_16; ?></td>
                        <td><?php echo $row->Serie_7.$row->Number_8; ?></td>
                        <td class="text-blue"><?php echo $services[$row->Office_6]; ?></td>
                        <td><?php echo $row->Designation_23; ?></td>
                        <td><?php echo $row->Reference_19 ; ?></td>
                        <td class="text-blue"><?php echo $result->receiptSerial.$result->receiptNumber; ?></td>
                        <td><?php echo 'CDF'; ?></td>
                        <td><b><?php echo number_format($result->declarationsPaid->amountToBePaid,2,","," "); ?></b></td>
                        <td><b><?php echo number_format($row->Amount_12,2,","," "); ?></b></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <section id="cat_list">

            <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                <span class="fa fa-warning text-gray mystyle4"></span>
                <br/><br/>
                Aucun paiement trouv&eacute;
                <br/><br/>
            </div>
        </section>
    <?php endif;?>
</div>
       



