<?php if (!empty($encaissements) || !empty($encaissements_from_reporting)): ?>
    <div class="col-lg-12 table-responsive">
        <table class="table table-hover table-striped" id="table">
            <thead class="bg-gray f12">
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Recette</th>
                    <th>Service</th>
                    <th>Client</th>
                    <th>Montant</th>
                    <th>Agences</th>
                    <th>Saisi</th>
                    <th>Validé</th>
                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 0; ?>

                <!-- ENCAISSEMENTS -->
                <?php foreach ($encaissements as $row): ?>
                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                        <td><b><?= $i ?></b></td>
                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                            <?= htmlspecialchars($row->Date_1) ?>
                        </td>
                        <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                        <td><?= htmlspecialchars($row->Service_16) ?></td>
                        <td class="text-blue">
                            <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA") 
                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13) 
                                : htmlspecialchars($row->Designation_14) ?>
                        </td>
                        <td class="text-blue">
                            <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                        </td>
                        <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                        <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                        <td>
                            <?php if ($row->Checkerid_10 == 0): ?>
                                <span class="text-red">En attente</span>
                            <?php else: ?>
                                <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a onclick="view('<?= $row->Id_0 ?>', '<?= $row->Beneficaire_15 ?>')">
                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <!-- ENCAISSEMENTS FROM REPORTING -->
                <?php foreach ($encaissements_from_reporting as $row): ?>
                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                        <td><b><?= $i ?></b></td>
                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                            <?= htmlspecialchars($row->Date_1) ?>
                        </td>
                        <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                        <td><?= htmlspecialchars($row->Service_16) ?></td>
                        <td class="text-blue">
                            <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA") 
                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13) 
                                : htmlspecialchars($row->Designation_14) ?>
                        </td>
                        <td class="text-blue">
                            <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                        </td>
                        <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                        <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                        <td>
                            <?php if ($row->Checkerid_10 == 0): ?>
                                <span class="text-red">En attente</span>
                            <?php else: ?>
                                <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a onclick="view('<?= $row->Id_0 ?>', '<?= $row->Beneficaire_15 ?>')">
                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <section class="text-center mt-5">
        <span class="fa fa-flask text-gray mystyle4"></span><br>
        <b>Aucun enregistrement trouvé !</b>
    </section>
<?php endif; ?>

<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });
</script>