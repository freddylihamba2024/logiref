<div class="row mb-5">
    <div id="loader"></div>
    <div class="col-md-11">
        <?php 
            $chtml->box_body_opening("", true); 
            echo form_open('', array('id' => 'mainform', 'class' => '')); 
        ?>
                <div class="statistic-box no-border">
                    <input type="hidden" name = "encaissements" value='<?php echo(!empty($encaissements))? json_encode($encaissements): '';?>'>
                    <input type="hidden" name = "bulletins" value='<?php echo(!empty($bulletins))? json_encode($bulletins): '';?>'>
                    <div class="row">
                        <div class="col-sm-10 col-xs-12">
                            <h2>Retard de reversement</h2>
                            <h5 class="page-header"><!--<span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des paiements non revers&eacute;s avant la dur&eacute; fix&eacute;e.</span>--></h5>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-5 col-xs-12 small-box">
                            <div class="input-group">
                                
                            </div>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-bitbucket ml-4 pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>
                            <button type="button" class="btn btn-success ml-1 pull-right text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>
                            <button type="button" class="btn btn-bitbucket pull-right text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>
                        </div>
                    </div>
                </div>
        <?php 
            echo form_close(); 
        ?>
        
        <div id="page" class="mt-2">
            <div class="col-md-12 no-padding" id="content">
                <div id="paiementslist">
                    <?php if(!empty($encaissements) || !empty($bulletins)): ?>
                    <div class="table-responsive">
                        <table id="table" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-aqua text-white">
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th>B&eacute;n&eacute;ficiaire</th>
                                    <th>Recette</th>
                                    <th>Montant</th>
                                    <th>Commissions</th>
                                    <th>Op&eacute;rateur</th>
                                    <th><span class="fa fa-fw fa-tasks f14"></span></th>
                                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                                    <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $commissions = 0;
                                $paiements = 0;
                                foreach($bulletins as $row){ 
                                    $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                                    $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                    $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                    $results = json_decode($row->Results_13);
                                    $recieptDate = explode("/",$results->receiptDate);
                                    $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                            ?>
                                <tr>
                                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                    <td width="50" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                    <td><?php echo '-'; ?></td>
                                    <td class="text-blue">
                                        <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                    </td>
                                    <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                    </td>
                                    <?php if($row->Status_2!=3){ ?>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                            <?php }else { ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green  fa-folder-open f14"></span></a>
                                            <?php } ?>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                        </td>
                                    <?php }else{ ?>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                        </td>
                                        <td width="25">
                                            <?php if(file_exists(base_url('api/endpoints/sydonia/quittances').'/'.$row->Pdfcontent_18)):?>
                                                <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                            <?php else: ?>
                                            <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                            <?php endif; ?>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php 
                                }
                                foreach($encaissements as $row){ 
                                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                <tr>
                                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                    <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                    <td><?php echo $row->Typerecette_17; ?></td>
                                    <td class="text-blue">
                                        <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                        <br/>
                                        <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                    </td>
                                    <?php if($row->Checkerid_10==0){ ?>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                            <?php }else { ?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green  fa-folder-open f14"></span></a>
                                            <?php } ?>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                        </td>
                                    <?php }else{ ?>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php 
                                    $paiements = $paiements + $row->Contrevaleur_22;
                                    $commissions = $commissions + $row->Commission_23;
                                }
                            ?>
                            </tbody>    
                        </table>
                    </div>
                    <?php else: ?>
                        <section class="m-5">
                            <h4 align="center">
                                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                <b>Aucun rapport trouv&eacute; !</b>
                            </h4>
                        </section>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
    <div class="col-md-1">
        <a href="<?php echo base_url($module.'/taxreports/set/rapport'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>


<script type="text/javascript">
    $('#table').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "pageSize": 50,
    });

    function view(id, regie)
    {
            var url ='';
            if(regie === 'DGDA')
            {
                 var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id  ;
            }
            else if(regie === 'DGI')
            {
                 var url ="<?php echo base_url($module.'/taxdeclaration/display/preview'); ?>/"  + id  ;
            }
            else if(regie === 'DGRAD')
            {
                 var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;
            }

            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);

            });
    }

    function print_payment(pid)
    {
            var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + pid;
            //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
            // window.print();
            var w = window.open(url);

            $(w).ready(function(){
                w.print();
            });
    }
    
    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/filter_penalites'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }

            });
    });

    $("#print").click(function(){

            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/taximpression/display/print_penalites'); ?>';
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){


                          print(result);

                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });


    });


    function print(buffer)
    {
        var w = window.open('<?php echo base_url()?>'+buffer);
    }
    
    $("#export").click(function(){
            $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taximpression/display/export_penalites'); ?>';
            window.open(url);
    });

</script>


