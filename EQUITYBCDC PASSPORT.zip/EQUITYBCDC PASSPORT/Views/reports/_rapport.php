<div id="pager">
    <div class="row">
        <div class="col-md-12 no-padding">
            <h2>Types de rapports</h2>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente les diff&eacute;rents types de rapports sur les op&eacute;rations effectu&eacute;es.</span></h5>
        </div>
        <div class="col-md-12 no-padding" id='alert'>
            <?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?>
        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="row">
                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a onclick="view('agence')" ><i class="fa fa-minus"></i> Liste des recettes globales par agence</a></li>
                                        <li id=''><a onclick="view('user')"><i class="fa fa-minus"></i> Liste des utilisateurs</a></li>
                                        <li id=''><a onclick="view('client')"><i class="fa fa-minus"></i> Liste des paiements des clients</a></li>
                                    </ul>-->
                                    
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="view('agence')">
                                                    <div class="float-left"><a onclick="view('agence')" class="btn btn-success text-white m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des recettes globales par agence
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="view('user')">
                                                    <div class="float-left"><a onclick="view('user')" class="btn btn-success text-white m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des utilisateurs
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="view('client')">
                                                    <div class="float-left"><a onclick="view('client')" class="btn btn-success text-white m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des paiements des clients
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>

                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a onclick="view('bl')" style="cursor:pointer" ><i class="fa fa-minus"></i>Relev&eacute; des bulletins de liquidations</a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Liste des paiements par virement/versement interne </a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Liste des op&eacute;rations par client par p&eacute;riode</a></li>
                                    </ul>-->
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="view('bl')">
                                                    <div class="float-left"><a onclick="view('bl')" style="cursor:pointer" class="btn btn-success text-white m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Relev&eacute; des bulletins de liquidations
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des paiements par virement/versement interne
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des op&eacute;rations par client par p&eacute;riode
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>
                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a href="#" style="cursor:pointer" onclick="action('agence')"><i class="fa fa-minus"></i> Bordereau de versement BCC par agence</a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Evolution graphique des recettes mensuelles</a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Evolution graphique de l'activit&eacute; p&eacute;riodique </a></li>
                                    </ul>-->
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="action('agence')">
                                                    <div class="float-left"><a href="#" style="cursor:pointer" onclick="action('agence')" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Bordereau de versement BCC par agence
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Evolution graphique des recettes mensuelles
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Evolution graphique de l'activit&eacute; p&eacute;riodique
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a href="#" style="cursor:pointer" onclick="action()" ><i class="fa fa-minus"></i> Liste des op&eacute;rations comptabilis&eacute;es </a></li>
                                        <li id=''><a href="#" style="cursor:pointer" onclick="action()"><i class="fa fa-minus"></i> Liste des op&eacute;rations en attente de comptabilisation </a></li>
                                        <li id=''><a href="#" style="cursor:pointer" onclick="action()"><i class="fa fa-minus"></i> Annexe au bordereau de versement BCC </a></li>
                                    </ul>-->
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" style="cursor:pointer" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des op&eacute;rations comptabilis&eacute;es
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" style="cursor:pointer" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des op&eacute;rations en attente de comptabilisation
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" style="cursor:pointer" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Annexe au bordereau de versement BCC
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>
                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Reconciliation amplitude/sydonia/middleware</a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Liste des anomalies/ecarrts entre les 3 syst&egrave;mes</a></li>
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i> Liste des donn&eacute;es pr&eacute;par&eacute;es pour ISYS-REGIES</a></li>
                                    </ul>-->
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Reconciliation amplitude/sydonia/middleware
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des anomalies/ecarrts entre les 3 syst&egrave;mes
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des donn&eacute;es pr&eacute;par&eacute;es pour ISYS-REGIES
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>
                        <div class="col-md-4">
                            <?php $chtml->box_body_opening("", false); ?>
                                <div class="col-md-12 no-padding">
                                    <!--<ul class="nav nav-pills nav-stacked">
                                        <li id=''><a href="#" onclick="action()"><i class="fa fa-minus"></i>Rapport de conciliation entre comptabilistaion et &nbsp;&nbsp;&nbsp;&nbsp;encaissement</a></li>
                                        <li id=''><a href="#" onclick="action()" style="cursor:pointer" onclick="action()"><i class="fa fa-minus"></i> Liste des donn&eacute;es pr&eacute;par&eacute;es des emargements IB &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;et EB pour ISYS</a></li>
                                    </ul>-->
                                    <table class="table rapport mb-0">
                                        <tbody>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Rapport de conciliation entre comptabilistaion et encaissement
                                                </td>
                                            </tr>
                                            <tr>
                                                <td onclick="action()">
                                                    <div class="float-left"><a href="#" onclick="action()" class="btn btn-danger m-r-sm"><i class="fa fa-clipboard"></i></a></div>
                                                    Liste des donn&eacute;es pr&eacute;par&eacute;es des emargements IB et EB pour ISYS
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php $chtml->box_body_closing(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type='text/javascript'>
    function view(which){
        if(which === 'agence')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_agence'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
            });
        }

        if(which === 'client')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_clients'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
            });
        }

        if(which === 'user')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_users'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
            });
        }

        if(which === 'bl')
        {
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.get("<?php echo base_url($module.'/taxreports/display/report_bl'); ?>", function (data, status) {
               $("#loader").html('');
               $("#pager").html(data);
            });
        }
    }

    function action()
    {
        $("#alert").html('<div class="alert alert-warning"> D&eacute;sol&eacute;, ce type de rapport n\'est pas encore disponible ! Merci.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
    }
</script>