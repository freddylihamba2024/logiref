<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold">
            RAPPORT DES RECETTES GLOBALES PAR AGENCE
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Agence</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Nbre de paiements</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Montant</b></td>
        <td style="border-bottom:1px solid black; font-size:1.1em;"><b>Commissions</b></td>
    </tr>

    <?php 
        
        $i=2;
        foreach($agences as $row)
        {
            
    ?>
            <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                <td width="20%" style="font-size:1.1em;"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                <td width="15%" style="font-size:1.1em;"><?php echo $row->Nom_4; ?></td>
                <td style="font-size:1.1em;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if(isset($data[$row->Id_0]['nombre'])) echo $data[$row->Id_0]['nombre']; else echo 0;?></td>
                <td style="font-size:1.1em;"><?php if(isset($data[$row->Id_0]['paiement'])) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," ");  else echo 0; ?></td>
                <td style="font-size:1.1em;"><?php if(isset($data[$row->Id_0]['commission'])) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
            </tr>
    <?php 
        $i++;   
        }
    ?>
    

</table>
