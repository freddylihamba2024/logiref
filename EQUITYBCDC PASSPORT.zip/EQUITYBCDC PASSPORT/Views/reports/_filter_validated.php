<?php

    $paiements = 0;
    $paiements_dgrad = 0;
    $suspend = 0;
    $urgent = 0;
    $paiements_dgi = 0;
    $paiements_dgi_usd = 0;
    $paiements_dgrad_usd = 0;
    $paiements_dgda_usd = 0;

    $i = 0;

?>

<?php if(!empty($encaissements) || !empty($bulletins) || !empty($prepayments)): ?>
<table id="table" class="table table-hover table-striped">
    <thead  class="bg-gray">
        <tr>
            <th></th>
            <th class="f12">Date</th>
            <th class="f12">Client</th>
            <th class="f12">B&eacute;n&eacute;ficiaire</th>
            <th class="f12">Recette</th>
            <th class="f12">Montant</th>
            <th class="f12">Commissions</th>
            <th class="f12">Op&eacute;rateur</th>
            <th class="f12"><span class="fa fa-fw fa-tasks f14"></span></th>
            <!-- <th class="f12"><span class="fa fa-fw fa-folder f14"></span></th> -->
            <th><a style="cursor:pointer; color:black"><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check d-none f16"></i></a></th>
            <th class="f12"><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($bulletins)): ?>
            <?php
            # Block las BL
            foreach($bulletins as $row):
                $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - '; 
                $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                $results = json_decode($row->Results_13);
                $recieptDate = explode("/",$results->receiptDate);
                $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
            ?>
            <tr>
                <td width="5"><b>#</b></span></td>
                <td  width="50" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                </td>
                <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                <td class="text-blue">
                    <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                </td>
                <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                <td width="25">
                    <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                </td>
                <?php if($row->Status_2!=3){ ?>
                    <td width="25">
                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                        <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->Year_5."".$row->Serie_7."".$row->Number_8; ?>" name="bulletins[]" />
                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                        <?php }else { ?>
                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                        <?php } ?>
                    </td>
                    <td width="25">
                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                    </td>
                <?php }else{ ?>
                    <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                        <td width="25">
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_12; ?>')" value="<?php echo $row->Id_0; ?>" name="bulletins[]" />
                            <input type='hidden' disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_12; ?>' name="total_dgda[]" />
                            <input type='hidden' disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                        </td>
                    <?php }else{ ?>
                        <td width="25">
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>','DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                        </td>
                    <?php } ?>
                    <td width="25">
                        <?php if(isset($row->Pdfcontent_18) && $row->Pdfcontent_18 !=""):?>
                            <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                        <?php else: ?>
                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                        <?php endif; ?>
                    </td>
                <?php } ?>
            </tr>
            <?php
                    //$paiements_dgda = $paiements_dgda + $row->Amount_12;
                    //$commissions = $commissions + $row->Commission_26;
                    //if(isset($row->Devise_29) && $row->Devise_29=='CDF') $paiements_cdf = $paiements_cdf + $row->Amount_12;
                endforeach;
            ?>
        <?php endif; ?>

        <?php if(!empty($prepayments)): ?>
            <?php
            #Block last prepayment
            foreach($prepayments as $row):
                $agence = (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - '; 
                $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
            ?>
                <tr>
                    <td width="5"><b>#</b></span></td>
                    <td width="50" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                    </td>
                    <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                    <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?></td>
                    <td class="text-blue">
                        <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                    </td>
                    <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                    <td width="25">
                        <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                    </td>
                    <?php if($row->Status_2!=3){ ?>
                        <td width="25">
                            <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_30==$_SESSION['Logiref_agence']){ ?>
                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                                <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="total_prepayments[]" />
                                <input type='hidden' class="input_val" disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                            <?php }else if($_SESSION['Logiref_role']==4 && $row->Creator_4==$this->session->userdata['user_id']){ ?>
                            <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"></span></a>
                            <?php }else { ?>
                            <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                            <?php } ?>
                        </td>
                        <td width="25">
                            <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"></span></a>
                        </td>
                    <?php }else{ ?>
                        <?php if($_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                            <td width="25">
                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.'DGDA';?>' onclick="reverser('<?php echo $row->Id_0;?>', 'DGDA', 'CDF', '<?php echo $row->Amount_18; ?>')" value="<?php echo $row->Id_0; ?>" name="prepayments[]" />
                                <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.'DGDA';?>' value='<?php echo $row->Amount_18; ?>' name="total_prepayments[]" />
                                <input type='hidden' class="input_val" disabled="disabled" id='r<?php echo $row->Id_0.'DGDA';?>' value='DGDA' name="regie" />
                            </td>
                        <?php }else{ ?>
                            <td width="25">
                                <a class="cursor-pointer" onclick="view_prepayment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                            </td>
                        <?php } ?>
                        <td width="25">
                            <?php if(isset($row->Pdfcontent_18) && $row->Pdfcontent_18 !=""):?>
                                <a class="cursor-pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                            <?php else: ?>
                                <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                            <?php endif; ?>
                        </td>
                    <?php } ?>
                </tr>
            <?php
                // $paiements = $paiements + $row->Amount_18;
                // $commissions = $commissions + $row->Commission_24;
                // if(isset($row->Devise_29) && $row->Devise_29=='CDF') $paiements_cdf = $paiements_cdf + $row->Amount_18;
                endforeach;
            ?>
        <?php endif; ?>


        <?php if(!empty($encaissements)): ?>
            <?php
                foreach($encaissements as $row):
                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
            ?>
                <tr>
                    <td width="5"><b>#</b></span></td>
                    <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                    </td>
                    <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                    <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                    <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                        <br/>
                        <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                        <?php endif;?>
                    </td>
                    <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                    <td width="25">
                        <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                    </td>
                    <?php if($row->Checkerid_10==0){ ?>
                        <td width="25">
                            <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                            <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                            <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                            <?php }else { ?>
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                            <?php } ?>
                        </td>
                        <td width="25">
                            <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                        </td>
                    <?php }else{ ?>
                        <?php if( $_SESSION['Logiref_role']==4 || $_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                            <td width="25">
                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' onclick="reverser('<?php echo $row->Id_0;?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Devise_12;?>', '<?php echo $row->Contrevaleur_22; ?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                <input type='hidden' disabled="disabled" id='t<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Montant_11; ?>' name="total[]" />
                                <input type='hidden' value='<?php echo $row->Devise_12; ?>' name="devise_paiement" />
                                <input type='hidden' disabled="disabled" id='r<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Beneficaire_15;?>' name="regie" />
                            </td>
                        <?php }else{ ?>
                            <td width="25">
                                <a class="cursor-pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                            </td>
                        <?php } ?>
                        <td width="25">
                            <a class="cursor-pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                        </td>
                    <?php } ?>
                </tr>
            <?php 
                if($row->Beneficaire_15 =="DGRAD")
                {
                    $paiements_dgrad = $paiements_dgrad + $row->Contrevaleur_22;
                }
                elseif($row->Beneficaire_15 =="DGI")
                {
                    $paiements_dgi = $paiements_dgi + $row->Contrevaleur_22;
                }
                //    $paiements = $paiements + $row->Contrevaleur_22;
                //    $commissions = $commissions + $row->Commission_23;
                //    if($row->Devise_12=='CDF') $paiements_cdf = $paiements_cdf + $row->Montant_11;
                if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGRAD") $paiements_dgrad_usd = $paiements_dgrad_usd + $row->Montant_11;
                if($row->Devise_12=='USD' && $row->Beneficaire_15 =="DGI") $paiements_dgi_usd = $paiements_dgi_usd + $row->Montant_11;

                endforeach;
            ?>
        <?php endif; ?>
    </tbody>    
</table>
<?php else:?>
    <div class="col-md-12">
        <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                <span class="d-block f14 text-black p-2">Aucun paiement trouv&eacute;!</span>
        </section>
    </div>
<?php endif;?>

<script type="text/javascript">


$('#checkall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', 'checked');
    $('.check').removeClass("hidden");
    $('#checkall').addClass("hidden");
    $('#uncheckall').removeClass("hidden");
    
    $('#regie_all').prop('disabled', false);
    
    $('.input_val').prop('disabled', false);
    
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;

    
    $("#submit").removeClass("disabled");
    $("#submit").prop("disabled",false);
    $("#index").html('('+ index+')');
});

$('#uncheckall').on("click", function() {
    var checked = $(this).prop('checked');
    $('#table').find('input:checkbox').prop('checked', '');
    $('.check').addClass("d-none");
    $('#checkall').removeClass("d-none");
    $('#uncheckall').addClass("d-none");
    
    $('#regie_all').prop('disabled', true);
    
    $('.input_val').prop('disabled', true);
    
    var $checedInputs = $('#table').find("input:checked");
    var index = $checedInputs.length;
    
    $("#submit").removeClass("btn-primary");
    $("#submit").addClass("btn-success");
    $("#submit").prop("disabled",true);
    $("#index").html('');
    
});
</script>
