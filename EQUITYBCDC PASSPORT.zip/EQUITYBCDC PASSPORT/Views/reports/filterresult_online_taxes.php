<?php
    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $validated = 0;
    $suspend = 0;
    $regulate = 0;
    $notreated = 0;
    $i = 0;
?>
<?php if (!empty($bulletins)): ?>
    <div  class="table-responsive">
        <table class="table table-hover table-striped ">
            <thead>
                <tr  class="bg-aqua-active">
                    <th width="5">#</th>
                    <th width="">Date</th>
                    <th>Statut</th>
                    <th width="">Bulletin</th>
                    <th width="">Service</th>
                    <th width="">Importateur</th>
                    <th width="">Bordereau</th>
                    <th with="">Quitt</th>
                    <th with="">Devise</th>
                    <th width="">Situation OP ou Caisse</th>
                    <th width="">Situation GU</th>
                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                </tr>
            </thead>
             <tbody>
                        <?php
                        $paiements = 0;
                        $commissions = 0;
                        $suspend = 0;
                        $urgent = 0;
                        $i = 0;
                        ?>

                        <?php
                        ++$i;
                        foreach ($bulletins as $row):

                            $result = (isset($row->Results_13) && $row->Results_13 != "") ? json_decode($row->Results_13) : '';
                            ?>
                        <input type="hidden" id="paiements" name="paiements[]" value="<?php echo $row->Id_0; ?>"  />
                        <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                            <td width="5"><b><?php echo $row->Id_0; ?></b></span></td>
                            <td <?php if ($row->Integration_16 !== gmdate('Y-m-d') || $row->Date_1!==gmdate('Y-m-d'))

								echo 'class="text-red"'; ?>>

							<?php
							if($row->Status_2==1):
								echo $row->Date_1;
								else:
								echo $row->Integration_16;
							endif;
							?>
							</td>
                            <td>
                                <?php if ($row->Status_2 == "2" && $row->Results_13 != ""): ?>
                                    <span class="badge badge-dark">Enregistré</span>
                                <?php elseif ($row->Status_2 == "5" OR $row->Status_2 == "6") : ?>
                                    <span class="badge badge-warning">En regularisation</span>
                                <?php elseif ($row->Status_2 == "1" && $row->Results_13 == ""): ?>
                                    <span class="badge badge-danger">Non traité</span>
									<?php elseif ($row->Status_2 == "1" && $row->Results_13 != ""): ?>
                                    <span class="badge badge-danger">Validation non abouti</span>
                                <?php elseif ($row->Status_2 == "3" && $row->Results_13 != ""): ?>
                                    <span class="badge badge-success">Validé</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $row->Serie_7 . $row->Number_8; ?></td>
                            <td class=""><?php echo isset($offices['DGDA'][$row->Office_6])?$offices['DGDA'][$row->Office_6]:"Unknown office"; ?></td>
                            <td><?php echo $row->Designation_23; ?></td>
                            <td><?php echo $row->Reference_19; ?></td>
                            <td class=""><?php echo (isset($row->Results_13) && $row->Results_13 != "") ? $result->receiptSerial . $result->receiptNumber : ''; ?></td>
                            <td><?php echo 'CDF'; ?></td>
                            <td><b><?php echo number_format($row->Amount_25, 2, ",", " "); ?></b></td>
                            <td><b><?php echo number_format($row->Amount_12, 2, ",", " "); ?></b></td>
                            <td>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            </td>
                        </tr>

                        <?php
                        $commissions = $commissions + $row->Commission_26;

                        if ($row->Status_2 == 3 && $row->Results_13 != "")
                            $validated = $validated + $row->Amount_25;
                        if ($row->Status_2 == 5 || $row->Status_2 == 6)
                            $regulate = $regulate + $row->Amount_25;
                        if ($row->Status_2 == 1 && $row->Results_13 == "")
                            $notreated = $notreated + $row->Amount_25;

                    endforeach;
                    ?>

                    </tbody>
                </table>
            <?php else: ?>
                <section id="cat_list">
                    <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun paiement trouv&eacute;!<br/>
                    </div>
                </section>
            <?php endif; ?>
</div>
<script type="text/javascript">
    $('#paiements').html('<?php echo number_format(count($bulletins), 0, ",", " "); ?>');
    $('#commissions').html('<?php echo number_format($commissions, 0, ",", " "); ?>');
    $('#validated').html('<?php echo number_format($validated, 0, ",", " "); ?>');
    $('#attente').html('<?php echo number_format($regulate, 0, ",", " "); ?>');
    $('#nottreated').html('<?php echo number_format($notreated, 0, ",", " "); ?>');
</script>
