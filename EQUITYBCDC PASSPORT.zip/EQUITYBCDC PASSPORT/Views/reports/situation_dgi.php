<?php

    $cpt = $comptes['DGI']['CPT']['CDF'];

    $cso = isset($comptes[$bank]['CSO']['CDF'])?$comptes[$bank]['CSO']['CDF']:"";
    $tva = isset($comptes[$bank]['TVA']['CDF'])?$comptes[$bank]['TVA']['CDF']:"";
    $cfb = isset($comptes[$bank]['CFB']['CDF'])?$comptes[$bank]['CFB']['CDF']:"";
    

    $total_debit_caisse = 0;
    $total_debit_op = 0;
    $total_debit_cpt = 0;

    $total_credit_cpt = 0;
    $total_credit_cso = 0;
    $total_credit_cfb = 0;
    $total_credit_tva = 0;

    $codes = array();
    $colors = array(); 
    $references = array();

    if(!empty($encaissements))
    {
            foreach ($encaissements as $instruction)
            {
                if(isset($events[$instruction->Paiementid_4][$instruction->Id_0]))
                {
                    isset($events[$instruction->Paiementid_4][$instruction->Id_0]['code']) ? $codes[$instruction->Id_0] = $events[$instruction->Paiementid_4][$instruction->Id_0]['code'] : $codes[$instruction->Id_0] = 0; 
                    isset($events[$instruction->Paiementid_4][$instruction->Id_0]['Num_evenement']) ? $references[$instruction->Id_0] = $events[$instruction->Paiementid_4][$instruction->Id_0]['Num_evenement'] : $references[$instruction->Id_0] = '';       

                    if($codes[$instruction->Id_0] == 200)
                    {
                            // OP ou Caisse
                            if($instruction->Mode_15 == 5)
                            {
                                    $total_debit_caisse += $instruction->Montant_10;
                            }
                            else
                            {
                                    $total_debit_op += $instruction->Montant_10;
                            }
                            //CPT Debit
                            if($instruction->Compte_9 == $cpt)
                            {
                                    $total_debit_cpt += $instruction->Montant_10;
                            }
                            //CPT credit
                            if($instruction->Compte_13 == $cpt)
                            {
                                    $total_credit_cpt += $instruction->Montant_10;
                            }
                            //Credit CSO
                            if($instruction->Compte_13 == $cso)
                            {
                                    $total_credit_cso += $instruction->Montant_10;
                            }
                            //Credit Commission
                            if($instruction->Compte_13 == $cfb)
                            {
                                    $total_credit_cfb += $instruction->Montant_10;
                            }
                            //Credit TVA
                            if($instruction->Compte_13 == $tva)
                            {
                                    $total_credit_tva += $instruction->Montant_10;
                            }
                            $colors[$instruction->Id_0] = '';
                    }
                    else
                    {
                           $colors[$instruction->Id_0] = 'text-red';
                    }
                }
                else
                {
                        $codes[$instruction->Id_0] = 0; 
                        $references[$instruction->Id_0] = '';
                        $colors[$instruction->Id_0] = 'text-red';
                }
            }
    }

?>

<div class="box-body">
        <!--<h2>SITUATION JOURNALIERE DE LA DGI </h2>-->
        <?php $chtml->box_body_opening("", true); ?>
                <div class="statistic-box no-border">
                        <div class="row">
                            <div class="col-sm-6 col-xs-6">
                                <div class="description-block" >
                                    <div class="row">
                                        <div class="col-md-12"><span class="f14"><b>Total d&eacute;bit</b></span></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 description-block ">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_debit_caisse,2,","," "); ?></span><br/>
                                            <span class="text-green">Caisse</span><br/>
                                        </div>
                                        <div class="col-md-4 description-block border-left">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_debit_op,2,","," "); ?></span><br/>
                                            <span class="text-green">Clients (OP/OV)</span><br/>
                                        </div>
                                        <div class="col-md-4 description-block border-left">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_debit_cpt,2,","," "); ?></span><br/>
                                            <span class="text-green">Tansitoire DGI</span><br/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-6 border-left">
                                <div class="description-block" >
                                    <div class="row">
                                        <div class="col-md-12"><span class="f14"><b>Total cr&eacute;dit</b></span></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 description-block ">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_credit_cpt,2,","," "); ?></span><br/>
                                            <span class="text-primary">Transitoire DGI</span><br/>
                                        </div>
                                        <div class="col-md-3 description-block border-left">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_credit_cso,2,","," "); ?></span><br/>
                                            <span class="text-primary">SUSPENS</span><br/>
                                        </div>
                                        <div class="col-md-3 description-block border-left">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_credit_cfb,2,","," "); ?></span><br/>
                                            <span class="text-primary">CFB</span><br/>
                                        </div>
                                        <div class="col-md-3 description-block border-left">
                                            <span class="f11"><?php echo 'CDF '.number_format($total_credit_tva,2,","," "); ?></span><br/>
                                            <span class="text-primary">TVA</span><br/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-xs-12 center">
                                <p class="page-header"></p>
                                <h4 class="text-blue"></h4>
                            </div>
                        </div>
                </div>
        <?php $chtml->box_body_closing(); ?>
        <br/>
        <?php $chtml->box_body_opening('', true); ?>
                <div class="row">
                    <div class="col-sm-12 col-xs-12">
                        <h4>RAPPORT DES OPERATIONS DU <?php echo gmdate('d-m-Y');?> | AGENCE: <?php echo strtoupper($guichets[$_SESSION['Logiref_guichet']]);?></h4>
                        <p class="page-header"></p>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php if(!empty($encaissements)): ?>
                        <table id="table" class="table table-striped bg-white">
                            <thead>
                                <tr class="bg-gray f12">
                                    <th with="12">N&SmallCircle;</th>
                                    <th>Libell&eacute;</th>
                                    <th with="150">Montant</th>
                                    <th with="150">D&eacute;bit</th>
                                    <th with="150">Cr&eacute;dit</th>
                                    <th>Evenement</th>
                                    <th with="150">Statut</th>
                                    <th with="150">Date</th>
                                    <th with="150">Op&eacute;rateur</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php  foreach($encaissements as $row){ ?>
                                    <tr class="<?php echo $colors[$row->Id_0]; ?>">
                                        <td><?php echo $row->Id_0; ?></td>
                                        <td><?php echo $row->Libelle_12; ?></td>
                                        <td><?php echo number_format($row->Montant_10,2,","," "); ?></td>
                                        <td><?php echo $row->Compte_9; ?></td>
                                        <td><?php echo $row->Compte_13; ?></td>
                                        <td><?php echo $references[$row->Id_0]; ?></td>
                                        <td>
                                            <?php if($codes[$row->Id_0] == 200):?>
                                                <span class="text-green">Int&eacute;gr&eacute;</span>
                                            <?php elseif($codes[$row->Id_0] != 200 && $codes[$row->Id_0] > 0):?>
                                                <span>Insuffisance</span>
                                            <?php else: ?>
                                                <span>Statut Inconnu</span>
                                            <?php endif;?>
                                        </td>
                                        <td><?php echo $row->Date_1; ?></td>
                                        <td><?php echo $users[$row->Makerid_16]; ?></td>
                                    </tr>
                            <?php };?>
                            </tbody>    
                        </table>
                    <?php else: ?>
                        <section id="cat_list" class="text-center">
                            <span class="d-block p-2 pb-1"><span class="fa fa-warning text-gray mystyle4" ></span></span>
                            <span class="d-block p-2 "><b>Aucune information suppl&eacute;mentaire trouv&eacute;e</b></span>
                        </section>
                    <?php endif;?>
                </div>
        <?php $chtml->box_body_closing(); ?>
</div>
        
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": true,
      "bLengthChange": true,
});
</script>
