<?php if (!empty($bulletins) || !empty($bulletins_from_reporting)): ?>
    <div class="col-lg-12 table-responsive">
        <table class="table table-striped bg-white" id="table">
            <thead class="bg-gray f12">
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Service</th>
                    <th>BL</th>
                    <th>Quittance</th>
                    <th>Client</th>
                    <th>Montant</th>
                    <th>Agences</th>
                    <th>Saisi</th>
                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 0; ?>

                <!-- BULLETINS -->
                <?php foreach ($bulletins as $row): 
                    $operateur = $users[$row->User_15] ?? ' - ';
                    $dateTime  = new DateTime($row->Integration_16);
                    $deadline  = date('Y-m-d', strtotime("+1 day", $dateTime->format('U')));
                    $results   = json_decode($row->Results_13);

                    $recieptDate   = isset($results->receiptDate) ? explode("/", $results->receiptDate) : [null, null, date('Y')];
                    $receiptNumber = $results->receiptNumber ?? "";
                    $receiptSerial = $results->receiptSerial ?? "";
                    $nodeid        = $recieptDate[2] . $receiptSerial . $receiptNumber;

                    if ($row->Status_2 == 4) {
                        $dateClass = "text-green";
                    } elseif ($deadline > gmdate('Y-m-d')) {
                        $dateClass = "text-black";
                    } elseif ($deadline == gmdate('Y-m-d')) {
                        $dateClass = "text-orange";
                    } else {
                        $dateClass = "text-red";
                    }
                ?>
                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                        <td><b><?= $i ?></b></td>
                        <td class="<?= $dateClass ?>"><?= htmlspecialchars($row->Integration_16) ?></td>
                        <td><?= htmlspecialchars($offices['DGDA'][$row->Office_6] ?? '') ?></td>
                        <td><?= 'L' . $row->Number_8 ?></td>
                        <td><?= htmlspecialchars($nodeid) ?></td>
                        <td class="text-blue">
                            <?= $row->Designation_23 === "" 
                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_9) 
                                : htmlspecialchars($row->Designation_23) ?>
                        </td>
                        <td class="text-blue">CDF <?= number_format($row->Amount_12, 2, ",", " ") ?></td>
                        <td><?= htmlspecialchars($guichets[$row->Agence_32] ?? '-') ?></td>
                        <td><?= htmlspecialchars($operateur) ?></td>
                        <td>
                            <a onclick="view('<?= $row->Id_0 ?>', 'DGDA')">
                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <!-- BULLETINS FROM REPORTING -->
                <?php foreach ($bulletins_from_reporting as $row): 
                    $operateur = $users[$row->User_15] ?? ' - ';
                    $dateTime  = new DateTime($row->Integration_16);
                    $deadline  = date('Y-m-d', strtotime("+1 day", $dateTime->format('U')));
                    $results   = json_decode($row->Results_13);

                    $recieptDate   = isset($results->receiptDate) ? explode("/", $results->receiptDate) : [null, null, date('Y')];
                    $receiptNumber = $results->receiptNumber ?? "";
                    $receiptSerial = $results->receiptSerial ?? "";
                    $nodeid        = $recieptDate[2] . $receiptSerial . $receiptNumber;

                    if ($row->Status_2 == 4) {
                        $dateClass = "text-green";
                    } elseif ($deadline > gmdate('Y-m-d')) {
                        $dateClass = "text-black";
                    } elseif ($deadline == gmdate('Y-m-d')) {
                        $dateClass = "text-orange";
                    } else {
                        $dateClass = "text-red";
                    }
                ?>
                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                        <td><b><?= $i ?></b></td>
                        <td class="<?= $dateClass ?>"><?= htmlspecialchars($row->Integration_16) ?></td>
                        <td><?= htmlspecialchars($offices['DGDA'][$row->Office_6] ?? '') ?></td>
                        <td><?= 'L' . $row->Number_8 ?></td>
                        <td><?= htmlspecialchars($nodeid) ?></td>
                        <td class="text-blue">
                            <?= $row->Designation_23 === "" 
                                ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_9) 
                                : htmlspecialchars($row->Designation_23) ?>
                        </td>
                        <td class="text-blue">CDF <?= number_format($row->Amount_12, 2, ",", " ") ?></td>
                        <td><?= htmlspecialchars($guichets[$row->Agence_32] ?? '-') ?></td>
                        <td><?= htmlspecialchars($operateur) ?></td>
                        <td>
                            <a onclick="view('<?= $row->Id_0 ?>', 'DGDA')">
                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <section class="text-center mt-5">
        <span class="fa fa-flask text-gray mystyle4"></span><br>
        <b>Aucun enregistrement fait!</b>
    </section>
<?php endif; ?>
<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });
</script>