 <?php if (!empty($encaissements) || !empty($encaissements_from_reporting) || !empty($encaissements_immatriculation)): ?>
        <div class="col-lg-12 table-responsive">
            <table class="table table-hover table-striped" id="table">
                <thead class="bg-gray f12">
                    <th>#</th>
                    <th>Date</th>
                    <th>Régie</th>
                    <th>Client</th>
                    <th>Recette</th>
                    <th>Service</th>
                    <th>Montant</th>
                    <th>Contre-valeur</th>
                    <th>Commissions</th>
                    <th><span class="fa fa-fw fa-folder f14"></span></th>
                </thead>
                <tbody>
                    <?php 
                    $i=0; 
                    $paiements = $commissions = $suspend = $urgent = 0;

                    // ENCAISSEMENTS
                    foreach ($encaissements as $row):
                    ?>
                        <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer">
                            <td><b><?= ++$i ?></b></td>
                            <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>"><?= $row->Datevaleur_31 ?></td>
                            <td><b><?= $row->Beneficaire_15 ?></b></td>
                            <td class="text-blue"><?= $row->Designation_14 ?></td>
                            <td><?= $row->Typerecette_17 ?></td>
                            <td><?= $services[$row->Service_16] ?? '' ?></td>
                            <td class="text-blue"><?= $row->Devise_12 . ' ' . number_format($row->Montant_11,2,',',' ') ?></td>
                            <td class="text-gray"><?= 'CDF '.number_format($row->Contrevaleur_22,2,',',' ') ?></td>
                            <td class="text-black"><?= $row->Devise_24 . ' ' . number_format($row->Commission_23,2,',',' ') ?></td>
                            <td>
                                <a style="cursor:pointer" onclick="view('<?= $row->Id_0 ?>','<?= $row->Beneficaire_15 ?>')">
                                    <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $paiements += $row->Contrevaleur_22;
                        $commissions += $row->Commission_23;
                        if($row->Status_2==1 && $row->Checkerid_10==0) $suspend++;
                        if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !== gmdate('Y-m-d')) $urgent++;
                    endforeach;

                    // ENCAISSEMENTS FROM REPORTING
                    foreach ($encaissements_from_reporting as $row):
                    ?>
                        <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer">
                            <td><b><?= ++$i ?></b></td>
                            <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>"><?= $row->Datevaleur_31 ?></td>
                            <td><b><?= $row->Beneficaire_15 ?></b></td>
                            <td class="text-blue"><?= $row->Designation_14 ?></td>
                            <td><?= $row->Typerecette_17 ?></td>
                            <td><?= $services[$row->Service_16] ?? '' ?></td>
                            <td class="text-blue"><?= $row->Devise_12 . ' ' . number_format($row->Montant_11,2,',',' ') ?></td>
                            <td class="text-gray"><?= 'CDF '.number_format($row->Contrevaleur_22,2,',',' ') ?></td>
                            <td class="text-black"><?= $row->Devise_24 . ' ' . number_format($row->Commission_23,2,',',' ') ?></td>
                            <td>
                                <a style="cursor:pointer" onclick="view('<?= $row->Id_0 ?>','<?= $row->Beneficaire_15 ?>')">
                                    <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $paiements += $row->Contrevaleur_22;
                        $commissions += $row->Commission_23;
                        if($row->Status_2==1 && $row->Checkerid_10==0) $suspend++;
                        if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !== gmdate('Y-m-d')) $urgent++;
                    endforeach;
                    ?>

                    <!-- ENCAISSEMENTS IMMATRICULATION -->
                    <?php foreach ($encaissements_immatriculation as $row): ?>
                        <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer" id="<?= ++$i ?>">
                            <td><b><?= $i ?></b></td>
                            <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>">
                                <?= htmlspecialchars($row->Date_1) ?>
                            </td>
                            <td><b class="text-blue"><?= htmlspecialchars($row->Typerecette_17) ?></b></td>
                            <td><?= htmlspecialchars($row->Service_16) ?></td>
                            <td class="text-blue">
                                <?= ($row->Designation_14 === "" && $row->Beneficaire_15 == "DGDA")
                                    ? "Bulletin de liquidation / " . htmlspecialchars($row->Nif_13)
                                    : htmlspecialchars($row->Designation_14) ?>
                            </td>
                            <td class="text-blue">
                                <?= htmlspecialchars($row->Devise_12) . ' ' . number_format($row->Montant_11, 2, ",", " ") ?>
                            </td>
                            <td><?= htmlspecialchars($guichets[$row->Guichet_21] ?? '-') ?></td>
                            <td><?= htmlspecialchars($users[$row->Makerid_9] ?? '-') ?></td>
                            <td>
                                <?php if ($row->Checkerid_10 == 0): ?>
                                    <span class="text-red">En attente</span>
                                <?php else: ?>
                                    <?= htmlspecialchars($users[$row->Checkerid_10] ?? '-') ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a onclick="view('<?= !empty($row->Immatriculation_57) ? $row->Immatriculation_57 : $row->Immatriculation_52 ?>', 'DGI_IMMATRICULATION')">
                                    <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <section class="text-center mt-5">
            <span class="fa fa-flask text-gray mystyle4"></span><br>
            <b>Aucun enregistrement trouvé !</b>
        </section>
    <?php endif; ?>
<script type="text/javascript">
    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": false,
        "info": false,
        "autoWidth": false,
        "pageSize": 50
    });
</script>
