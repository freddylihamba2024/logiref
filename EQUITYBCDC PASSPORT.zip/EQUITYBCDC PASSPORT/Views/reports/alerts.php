<?php 

$user_id = $this->session->userdata['user_id'];

?>

<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
    <div class="col-md-12">
            <h1>Liste des alertes</h1>
            <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente l'ensemble des alertes des paiements effectu&eacute;s sur la RB0.</span></h5>
    </div>
    
    <div class="col-md-12">
        <div  id="message"></div>
        
            <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <?php if(!empty($alerts)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th></th>
                                <th width="50">Date</th>
                                <th>Adresse email</th>
                                <th>Code erreur</th>
                                <th>Message</th>
                                <th><span class="fa fa-fw fa-pencil f14"></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        <?php 
                        foreach($alerts as $row){ 
                        ?>
                            <tr>
                                <td width="5"><b><?= ++$i;  ?></b></span></td>
                                <td  width="80">
                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                </td>
                                <td class="text-blue"><?php echo $row->Customeremail_10 ?></td>
                                <td ><b><?php echo $row->Errocode_8; ?></b></td>
                                <td><?php echo $row->Message_7; ?></td>
                                <?php if($row->Lock_12 == $user_id):?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-edit f14"></span></a>
                                    </td>
                                <?php else : ?>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="" href="#" ><span class="fa fa-lock font-action-edit text-yellow f18"></span></a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php 
                        } 
                        ?>
                        </tbody>    
                    </table>
                    <?php else:?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                Aucune alerte trouv&eacute;e !<br/>
                            </div>
                        </section>
                    <?php endif;?>
                </div>
            <?php $chtml->box_body_closing(); ?>
        
    </div>
    
</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
});

function view(id)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');

    var url = '<?php echo base_url($module.'/taxbulletin/display/step_1_process'); ?>/'+id;

    $.get(url, function (data, status) {

        if(data == '0')
        {
            $("#loader").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
        }
        else
        {
            $("#loader").html('');
            $("#fullscreen").html(data);
        }
    });
}

</script>