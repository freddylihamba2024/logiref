<div class="row">
    <div class="col-md-12 p-3">
        <div id="loader"></div>
        <?php if(!empty($agences)): ?>
            <div class="ibox bg-white">
                    <div class="ibox-title border-bottom">
                        <h2 class="text-blue">Liste des recettes globales par agence</h2>
                    </div>
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>
                            <div class="row">
                                    <div class="col-md-5 no-padding small-box">
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('agence', $agence, '', ' id="" class="form-control" '); ?>
                                        </div>
                                    </div><br>
                                    <div class="col-md-6 no-padding  small-box">
                                        <div class="input-group input-daterange ">
                                            <span class="input-group-addon">Initi&eacute;e entre le</span>
                                            <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                            <span class="input-group-addon">et le</span>
                                            <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                        </div>
                                    </div>
                                   <div class="col-md-1">
                                        <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>

                                    </div>
                                    <!--<div class="col-md-1">
                                        <button  class="btn btn-danger text-white" id="print" type="button"> <i class="fa fa-print"></i></button>&nbsp;&nbsp;<br/>
                                    </div>

                                    <div class="col-md-1">
                                        <button type="button" class="btn btn-success text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>&nbsp;&nbsp;<br/>
                                    </div>-->
                                    
                            </div>
                          
                        <?php echo form_close(); ?>
                </div>
                <input type="hidden" id="nbre" value="<?= count($_SESSION["agences"]) ?>"/>
                <div class="col-lg-12 table-responsive" id="filterResult">
                            <table class="table table-striped bg-white" id="table">
                                <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">
                                    <th></th>
                                    <th>Date</th>
                                    <th>Agence</th>
                                    <th>Nbre de paiements</th>
                                    <th>Montant</th>
                                    <th>Commissions</th>
                                      
                                </thead>
                                <tbody>
                                    <?php 
                                        foreach ($agences as $row){
                                    ?>
                                    <tr class="list-contact" data-id="<?=$row->Id_0?>" style="cursor: pointer" id="<?php echo ++$i; ?>">
                                        <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                        <td width="20%"><?php echo $row->Date_1 ?></td>
                                        <td><?php echo $row->Nom_4; ?></td>
                                        <td class="text-center" ><?php if(isset($data[$row->Id_0]['nombre'])) echo $data[$row->Id_0]['nombre']; else echo 0;?></td>
                                        <td><?php if(isset($data[$row->Id_0]['paiement'])) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," ");  else echo 0; ?></td>
                                        <td><?php if(isset($data[$row->Id_0]['commission'])) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
                                    </tr>
                                    <?php 
                                        } 
                                   ?>
                                    
                                </tbody>
                            </table>
                </div>
                
            </div>
        
        <?php else: ?> 
            <section id="cat_list" class="text-center marginTop150">
                <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
            </section>
        <?php endif; ?>
    </div>
    </div>
</div>



<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">
    $('.table').DataTable({
        pageLength: 10,
        responsive: true,
        "bLengthChange": false,
        "bFilter": false,
        paging: true,
        searching: false

    });

    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/agence_filter'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }

            });
    });

    $("#print").click(function(){

            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/taximpression/display/print_recettes'); ?>';
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){

                           //$('#page').html(result);
                            print(result);

                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });

    });

    
    
    
    $("#export").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/taximpression'); ?>/display/export_agences';

         $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
         $.get(url, function(data, status){
            $("#loader").html('');
            print(data);

        });
    });
    
    function print(buffer) 
    {
        var link = document.createElement('a');
        link.href = '<?php echo base_url()?>' + buffer;
        link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>


