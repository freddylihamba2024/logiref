<?php 
$equivalence =0;
$calcul =0;
$tva = 0.16;
if(isset($_SESSION['Bank_rates'])){
    $bank = json_decode($_SESSION['Bank_rates'], true);
    $usd = $bank['Dollar_4'];
    $eur = $bank['Euro_5'];
    $rand = $bank['Rand_6'];
    $pound = $bank['Pound_7'];
}
?>

<div class="row">
    <div class="col-md-1"></div>

    <div class="col-md-10 no-padding">
            <?php $chtml->box_body_opening('', true); ?>
                <div class="statistic-box no-border no-padding">
                    <div class="col-md-12 no-margin">
                        <h1>
                            Rapports des Commissions et TVA.
                        </h1>
                        <h5 class="page-header">Cette section vous pr&eacute;sente les commissions et les TVA percues sur les taxes.</h5>
                    </div>
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">  
                                        <div class="input-group">
                                            <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('guichet', $guichets, '', ' id="" class="form-control" '); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-daterange input-group">
                                            <span class="input-group-addon">Initi&eacute;e entre le</span>
                                            <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                            <span class="input-group-addon">et le</span>
                                            <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <button type="submit" class="btn btn-bitbucket pull-right"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                                </div>
                                <div class="col-md-2">
                                    <button type="submit"id="export" class="btn btn-success  pull-right" style="margin-left: 35px;">Exporter</button>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
            <div id="loader" class="col-md-12"></div>

            <div class="col-md-12 no-padding" id="filterCommission">
                <?php $chtml->box_body_opening('', true); ?>
                    <?php if(!empty($paiement)): ?>
                    <table id="" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-aqua-active">
                                <th>#</th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>Commission</th>
                                <th>Taxe sur valeur ajoute&eacute;</th>
                                <th>Guichet</th>

                            </tr>
                        </thead>
                        <tbody >
                        <?php 
                            $i = 1;
                            foreach($paiement as $row){
                            ?>
                                <tr>
                                    <td width="2"><?php echo $i; ?></td>
                                    <td width="100"><?php echo $row->Datevaleur_31; ?></td>
                                    <td width="150"><?php echo $row->Designation_14; ?></td>
                                    <td class="text-black" width="100"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?>
                                        <?php if($row->Devise_24 == "USD") :
                                            $equivalence = $row->Commission_23*$usd;
                                        ?>
                                            <br/>
                                            <span class="text-gray"><?php echo 'CDF '.number_format($equivalence,2,","," "); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td width="150"><?php $calcul = $row->Commission_23*$tva; ?>
                                            <span><?php echo 'CDF '.number_format($calcul,2,","," "); ?></span>
                                    </td>
                                    <td width="150"><?=  isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] :"-"; ?></td>

                                </tr>
                            <?php 
                                $i++;
                            } 
                            ?>

                        </tbody>
                    </table>
                    <?php else:?>
                        <section id="cat_list">
                            <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                                Aucun paiement trouv&eacute;!<br/>
                            </div>
                        </section>
                    <?php endif;?>
                <?php $chtml->box_body_closing(); ?>
            </div>  
    </div>
    <div class="col-md-1">
        <a href="<?php echo base_url($module.'/taxreports/set/rapport'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
    
</div><!-- comment -->


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});

$("#searchform").submit(function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxreports/display/filtercommission'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#filterCommission').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#export").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/impression'); ?>/display/export_commission';
        window.open(url);
        
});

</script>

