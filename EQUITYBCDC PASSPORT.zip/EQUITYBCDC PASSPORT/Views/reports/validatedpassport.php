<?php

    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $commissions = 0;
    $suspend = 0;
    $urgent = 0;
    $paiements_cdf = 0;
    $paiements_usd = 0;
    $i = 0;
?>

<div id="pager"  class="col-md-12">
        <div class="col-md-12">
                <h1 class="text-blue f30">Liste des paiements en attente de reversement</h1>
                <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente les paiements en attente de reversement.</span></p>
        </div>

        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total paiements</h5>
                            <p class="text-blue f18"> <b>CDF <span id="paiements"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Total commissions</h5>
                            <p class="text-green f18"><b>CDF <span id="commissions"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Paiements en CDF</h5>
                            <p class="text-blue f18"><b>CDF <span id="paiement_cdf"></span></b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body p-2 height90">
                            <h5 class="card-title f12 text-black width200">Paiements en USD</h5>
                            <p class="text-blue f18"><b>USD <span id="paiement_usd"></span></b></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br/>

        <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
        <div class="col-md-12 no-padding mt-3 mb-3">
            <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2): ?>
                <div class="row">
                    <div class="col-md-1">
                        <div id="step-1" title="" class="bRound bg-green-active center pull-right">1</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left">S&eacute;l&eacute;ction des paiements<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-2" title="" class="bRound bg-gray center pull-right">2</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left">Int&eacute;gration des paiements<br/></div>
                    </div>
                    <div class="col-md-1">
                        <div id="step-3" title="" class="bRound bg-gray center pull-right">3</div>
                    </div>
                    <div class="col-md-3 pt-2">
                        <div class="pull-left">Validation des paiements<br/></div>
                    </div>
                </div>
            <?php endif;?>
        </div>

        <br/>

        <div class="col-md-12 d-none" id="message">
            <div class="alert alert-warning">ISYS-REGIE n'est pas disponible pour l'instant.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>
        </div>
        <div class="col-md-12" id="loader"></div>
        <div class="col-md-12">
            <?php $chtml->box_body_opening('', true); ?>

            <div class="col-md-12"  id="content">
                    <br/>
                    <div id="paiementslist">
                        <?php if(!empty($encaissements)): ?>
                        <table id="table" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-gray">
                                    <th></th>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th>B&eacute;n&eacute;ficiaire</th>
                                    <th>Recette</th>
                                    <th>Montant</th>
                                    <th>Commissions</th>
                                    <th>Op&eacute;rateur</th>
                                    <th><span class="fa fa-fw fa-tasks f14"></span></th>
                                    <th><i id="checkall" class="glyphicon glyphicon-unchecked f16"></i><i id="uncheckall" class="glyphicon glyphicon-check d-none f16"></i></th>
                                    <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php
                            #Block DGI et DGRAD
                            foreach($encaissements as $row){
                                $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                <tr>
                                    <td width="5"><b>#</b></span></td>
                                    <td width="80" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                     <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                                    <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                          <br/>
                                          <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                    <td width="25">
                                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-yellow fa-file f14"> </span></a>
                                    </td>
                                    <?php if($row->Checkerid_10==0){ ?>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                                               <input type="checkbox" class="text-blue" id='p<?php echo $row->Id_0;?>' value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                            <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')){ ?>
                                               <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                                            <?php }else { ?>
                                               <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                                            <?php } ?>
                                        </td>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                        </td>
                                    <?php }else{ ?>
                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2){ ?>
                                            <td width="25">
                                                <input type="checkbox" class="text-blue checkboxes" id='p<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' onclick="reverser('<?php echo $row->Id_0;?>', '<?php echo $row->Beneficaire_15; ?>', '<?php echo $row->Devise_12;?>', '<?php echo $row->Contrevaleur_22; ?>')" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                                                <input type='hidden' class="input_val" disabled="disabled" id='t<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Montant_11; ?>' name="total[]" />
                                                <input type='hidden' class="input_val" value='<?php echo $row->Devise_12; ?>' name="devise_paiement" />
                                                <input type='hidden' class="input_val" disabled="disabled" id='r<?php echo $row->Id_0.''.$row->Beneficaire_15;?>' value='<?php echo $row->Beneficaire_15;?>' name="regie" />
                                            </td>
                                        <?php }else{ ?>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                                            </td>
                                        <?php } ?>
                                        <td width="25">
                                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php
                                    $paiements = $paiements + $row->Contrevaleur_22;
                                    $commissions = $commissions + $row->Commission_23;
                                    if($row->Devise_12=='CDF') $paiements_cdf = $paiements_cdf + $row->Montant_11;
                                    if($row->Devise_12=='USD') $paiements_usd = $paiements_usd + $row->Montant_11;
                            }
                            ?>
                            </tbody>
                        </table>
                        <?php else:?>
                            <div class="col-md-12">
                                <section id="cat_list" class="text-center pt-5 pb-5">
                                    <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
                                    <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
                                </section>
                            </div>
                        <?php endif;?>
                    </div>
            </div>
            <div  class="box-footer clearfix col-md-12">
                <div id="createPaiement" class="col-md-12 no-padding">
                    <button type="submit" id="submit"  name="submit" class="btn btn-success pull-left disabled"><i class="fa fa-save"></i>&nbsp;&nbsp;Confirmer la s&eacute;l&eacute;ction <span id="index"></span>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="submit"id="export" class="btn btn-primary" disabled><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;Exporter en excel&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <input type="hidden" id="action" value="">
                    <button type="button" id="cancel" class="btn btn-default" disabled><i class="fa fa-share-square-o"></i>&nbsp;&nbsp;Reverser automatiquement &nbsp;&nbsp;</button>&nbsp;&nbsp;

                    <input type='hidden' disabled="disabled" id="regie_all" value='all' name="regie" />
                </div>
            </div>

            <?php $chtml->box_body_closing(); ?>
        </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
    $('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
    $('#commissions').html('<?php echo number_format($commissions,2,","," "); ?>');
    $('#paiement_cdf').html('<?php echo number_format($paiements_cdf,2,","," "); ?>');
    $('#paiement_usd').html('<?php echo number_format($paiements_usd,2,","," "); ?>');

    $("#contenter").on("click", ".item", function(){

        var id = $(this).attr('data-id-item');
        $("#form_validated").removeClass('d-none');
        $("#close").addClass('d-none');
        $("#cancel").addClass('d-none');

    });

    $('#submit').click(function(){

        $('#action').val('submit');

    });

    $('#export').click(function(){
        
        $('#action').val('export');
        
    });

    $('#checkall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', 'checked');
        $('.check').removeClass("d-none");
        $('#checkall').addClass("d-none");
        $('#uncheckall').removeClass("d-none");
        
        $('#regie_all').prop('disabled', false);
        
        $('.input_val').prop('disabled', false);
        
        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;

        
        $("#submit").removeClass("disabled");
        $("#submit").prop("disabled",false);
        $("#index").html('('+ index+')');
    });

    $('#uncheckall').on("click", function() {
        var checked = $(this).prop('checked');
        $('#table').find('input:checkbox').prop('checked', '');
        $('.check').addClass("d-none");
        $('#checkall').removeClass("d-none");
        $('#uncheckall').addClass("d-none");
        
        $('#regie_all').prop('disabled', true);
        
        $('.input_val').prop('disabled', true);
        
        var $checedInputs = $('#table').find("input:checked");
        var index = $checedInputs.length;
        
        $("#submit").removeClass("btn-primary");
        $("#submit").addClass("btn-success");
        $("#submit").prop("disabled",true);
        $("#index").html('');
        
    });

    $('#mainform').submit(function(event) {
            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            
            var data = $(this).serialize();
            
            var action = $('#action').val();
            
            if(action == 'submit')
            {
                    submiter(data);
            }
            else
            {
                    export_to_excel(data);
            }
            
    });

    function submiter(data)
    {
            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxreversement'); ?>/display/start';
            
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : data, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(result){
                        $('#loader').html('');
                        $('#message').removeClass('d-none');
                        $('#export').prop('disabled', false);
                        $('#submit').prop('disabled', true);
                        $("#step-1").removeClass('bg-green-active');
                        $("#step-1").addClass('bg-gray');
                        $("#step-2").removeClass('bg-gray');
                        $("#step-2").addClass('bg-green-active');
                        $("#content").html(result);
                        
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    }

    function export_to_excel(data)
    {
    
            $('#export').prop('disabled', true);
            var url = '<?php echo base_url($module.'/taxreversement'); ?>/display/export';
            window.open(url);
    }

    function view(id, regie)
    {

            var url ="<?php echo base_url($module.'/taxnotes/display/preview'); ?>/"  + id  ;

            $("#loader").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            $.get(url, function(data, status){
                $("#loader").html('');
                $("#pager").html(data);

            });
    }


    function print_payment(pid)
    {
            var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
            //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
            // window.print();
            var w = window.open(url);

            $(w).ready(function(){
                w.print();
            });
    }

    function reverser(id, regie, devise)
    {
            var $checedInputs = $('#table').find("input:checked");
            var index = $checedInputs.length;

            if(index > 0)
            {
                    $('#t'+id+''+regie).prop('disabled', false);
                    $('#r'+id+''+regie).prop('disabled', false);

                    $("#submit").removeClass("disabled");
                    $("#submit").prop("disabled",false);
                    $("#index").html('('+ index+')');

            }
            else if(index <= 0)
            {
                    $('#checkall').removeClass("d-none");
                    $('#uncheckall').addClass("d-none");
                    
                    $('#t'+id+''+regie).prop('disabled', true);
                    $('#r'+id+''+regie).prop('disabled', true);
                    
                    $("#submit").removeClass("btn-primary");
                    $("#submit").addClass("btn-success");
                    $("#submit").prop("disabled",true);
                    $("#index").html('');

                    regie = "";
                    devise = "";
            }
    }


    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }

</script>