<style>
    .btn-gray {
    background-color: #d6d6d6 !important; /* Grise le bouton */
    border-color: #c2c2c2 !important; /* Ajuste la bordure */
    color: #808080 !important; /* Grise le texte */
    cursor: not-allowed; /* Change le curseur en symbole d'interdiction */
    pointer-events: none; /* Désactive l'interaction */
}
</style>

<div class="col-md-12" id="loader"></div>
<div id="pager">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-blue f30">Liste des paiements intégrés</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente l'ensemble de paiements intégrés par sftp.</span></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div id="list">

            <?php if(!empty($integrations)): ?>
             
            <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
            <?php $chtml->box_body_opening('', false);?>
            <div class="box-body box-solid no-padding">
                <div class="col-md-12 no-padding">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped" id="table">
                                <thead class='bg-blue'>
                                    <tr class="bg-gray f12">
                                        <th class="f12"></th>
                                        <th class="f12">Bureau</th>
                                        <th class="f12 text-center">B&eacute;n&eacute;ficiaire</th>
                                        <th class="f12 text-center">Nbre des bulletins</th>
                                        <th class="f12 text-center">Montant total</th>
                                        <th class="f12 text-center">Commission totale</th>
                                        <th class="f12 text-center">Statut</th>
                                        <th class="center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $i = 1; foreach($integrations as $row){ ?>
                                        <?php
                                         $payments= $row->Paymentid_11;
                                         $paiements_ids= implode(',', json_decode($payments));
                                       
                                        ?>
                                        <tr class="f12">
                                            <td width="5"><b><?= ++$i;  ?></b></span></td>
                                            <td ><?php echo $services['DGDA'][$row->Office_7]; ?></td>
                                            <td width="20"class="text-center"><b><?php echo 'DGDA'; ?></b></td>
                                            <td class="text-center"><?php echo $row->Nbtotal_14; ?></td>
                                            <td class="text-center">
                                                <?php echo'CDF '.number_format($row->Amount_8,2,","," "); ?> 
                                            </td>
                                            <td class="text-center"><?php echo 'CDF '.number_format($row->Commission_9,2,","," "); ?></td>
                                            <td class="text-center">
                                            <?php if($row->Status_2 == 2) : ?>
                                                <span id = "line<?php echo $row->Id_0 ?>" class="badge label-success f10"> Integré</span>
                                            <?php else : ?>
                                                <span id = "line<?php echo $row->Id_0 ?>"  class="badge label-upcoming f10"> Non integré</span>
                                                <span id = "newline<?php echo $row->Id_0 ?>" class="badge label-success f10 d-none"> Integré</span>
                                            <?php endif;?>
                                            </td>
                                            <td style="text-align:center;">
                                                <a 
                                                    id="btnr<?php echo $row->Id_0 ?>"
                                                    <?php if ($row->Status_2 == 2) echo 'disabled="true" onclick="return false;"'; ?> 
                                                    type="button" 
                                                    class="btn-xs btn-success text-white <?php if ($row->Status_2 == 2) echo 'disabled btn-gray'; ?>"
                                                    onclick="resend('<?php echo $row->Id_0; ?>', '<?php echo $row->Path_12; ?>')">
                                                    Renvoyer
                                                </a>&nbsp;
                                                <a href="#" onclick="export_data(event,'<?php echo $paiements_ids ?>')" class="btn-xs btn-dark">Exporter</a>
                                            </td>
                                        </tr>
                                    <?php 
                                    } 
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php $chtml->box_body_closing(); ?>
            <?php echo form_close(); ?>
            </div>
            <?php else: ?>
                <?php $chtml->box_body_opening(); ?> 
                    <section id="cat_list" class="mt-5 mb-5 text-center "><br/><br/><br/><br/><br/><br/>
                       <span class="d-block"><i class="fa fa-flask text-gray mystyle4" ></i></span>
                       <span class="d-block f14 text-black p-2">Aucun paiement intégré pour l'instant !</span><br/><br/><br/><br/><br/><br/><br/><br/>        
                    </section>
                <?php $chtml->box_body_closing(); ?> 
            <?php endif; ?>
        </div>   
    </div>
</div>

<script type="text/javascript">

    function resend(id, path)
    {
        var cHtml = '<img align="middle" height="18px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        var sHtml = $("#line" + id).html();

        var csrf = $('input[name="csrf_name"]').val();
        var data = {integrationid:id, path: path, csrf_name: csrf};
        
        $("#line" + id).removeClass('badge label-upcoming');
        $("#line" + id).html(cHtml);
        
        var url = '<?php echo base_url($module.'/taxbulletin'); ?>/data/send_file_integration';
        
        $.ajax({
        type        : 'POST', 
        url         : url, 
        data        : data, 
        dataType    : 'json', 
        encode          : true,
        success: function(result){

                if(result.code == '200')
                {
                        $("#line" + id).html('');
                        $("#line" + id).addClass('d-none');
                        $("#newline" + id).removeClass('d-none');
                        $("#btnr" + id).addClass('disabled btn-gray');
                }
                else
                {
                        $("#line" + id).html('');
                        $("#line" + id).html(sHtml);
                        $("#line" + id).css('color', 'red');
                }
            },
            error:function(error){
                $('#loader1').html('<div class="alert aWarning text-white">Alerte: Le fichier n\'est pas envoyé, veuillez réessayer s\il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }
    
    function export_data(ev,id){
        ev.preventDefault();
        
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';

        var csrf = $('input[name="csrf_name"]').val();
        
        var data = {paiement_ids : id, csrf_name: csrf};

        var url = '<?php echo base_url($module . '/taxreports/data/export_paiement_integrated'); ?>';
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {
                    $("#loader").html('');
                    if(result.code==200)
                    {
                          print(result.path);
                    }
                    else
                    {
                          $("#loader").html('<div class="alert aWarning text-white">Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
                    }
            },
            error: function (error) {
                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse amplitude est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse d\'amplitude, veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans amplitude!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

        
    }
    function print(buffer) 
    {
            var link = document.createElement('a');
            link.href = '<?php echo base_url()?>' + buffer;
            link.download = buffer.split('/').pop(); // Nom du fichier à télécharger
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
    }


</script>