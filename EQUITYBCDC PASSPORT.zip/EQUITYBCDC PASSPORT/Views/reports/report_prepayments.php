<?php $total_amount = 0; ?>
<div class="row">
    <div class="col-md-12">
        <div id="message"></div><br/>
    </div>
</div>
<?php if ($_SESSION['Logiref_role'] == 4) { ?>
    <div class="col-lg-12 p-0" style="margin-top: -35px;">
        <div class="ibox bg-white">

            <div class="ibox-title border-bottom">
                <!--                            <h2 class="text-blue">Pr&eacute;-paiement par client</h2>-->
            </div>
            <?php if (!empty($prepaids) || !empty($prepaids_from_reporting)): ?>
                <div class="col-sm-12">
                    <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for=""><b>Référence sydonia</b></label>

                            </div> 
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for=""><b>Bureau</b></label>
                                <?php echo form_dropdown('Recette', $services, '', ' id="recette" class="form-control" '); ?>

                            </div>    
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for=""><b>P&eacute;riode</b></label>
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">De </span>
                                    <input class="form-control" name="start" value="" id="datepicker1" type="text">
                                    <span class="input-group-addon"> à </span>
                                    <input class="form-control" name="end" value=""  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2 text-right d-flex align-items-center mt-2">
                            <div class="action-buttons">

                                <button type="submit" class="btn btn-primary" >Extraire</button>
                                <button type="submit"id="export" class="btn btn-success">Exporter</button>

                            </div>
                        </div>


                    </div>
                    <?php echo form_close(); ?>
                </div>

                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead class='bg-gray'>
                            <tr>
                                <th width="5px">#</th>
                                <th width="150px">R&eacute;f&eacute;rence SYDONIA</th>
                                <th width="150px">Bureau</th>
                                <th width="100px">Declarant</th>
                                <th width="100px" class="center">Nombre des BL</th>
                                <th width="150px" class="center">Montant total</th>
                                <th width="10px" class="" ><i class="fa fa-edit f20"></i></th>
                            </tr>
                        </thead>
                        <tbody>

                            <!-- prepayments -->
                            <?php
                            $i = 1;
                            foreach ($prepaids as $key => $payments):
                                ?>
            <?php foreach ($payments as $row): ?>
                                    <tr>
                                        <td width=""><?php echo $i; ?></td>
                                        <td width=""><?php echo $row->AccountRef_14; ?></td>
                                        <td width=""><?php echo $services['DGDA'][$row->Office_8]; ?></td>
                                        <td width=""><ul><?php echo $row->Declarant_16; ?></ul></td>
                                        <td width=""><ul><?php echo $row->total; ?></ul></td>
                                        <td width=""><ul><?php echo $row->amounts; ?></ul></td>
                                        <td width="">
                                            <a style="cursor: pointer" onclick="view_bulletin('<?php echo $row->AccountRef_14; ?>', '<?php echo $row->Office_8; ?>')"> 
                                                <i class="fa fa-edit f20"></i> 
                                            </a>
                                        </td>
                                    </tr>
                                <input type="hidden" value="<?php echo $row->Office_8; ?>" name="Office[]"/>

                                <?php $total_amount = $total_amount + $row->amounts; ?>
                            <?php endforeach; ?>
                            <?php
                            $i++;
                        endforeach;
                        ?>

                        <!-- prepayments from reporting-->
                        <?php
                        $i = 1;
                        foreach ($prepaids_from_reporting as $key => $payments):
                            ?>
            <?php foreach ($payments as $row): ?>
                                <tr>
                                    <td width=""><?php echo $i; ?></td>
                                    <td width=""><?php echo $row->AccountRef_14; ?></td>
                                    <td width=""><?php echo $services['DGDA'][$row->Office_8]; ?></td>
                                    <td width=""><ul><?php echo $row->Declarant_16; ?></ul></td>
                                    <td width=""><ul><?php echo $row->total; ?></ul></td>
                                    <td width=""><ul><?php echo $row->amounts; ?></ul></td>
                                    <td width="">
                                        <a style="cursor: pointer" onclick="view_bulletin('<?php echo $row->AccountRef_14; ?>', '<?php echo $row->Office_8; ?>')"> 
                                            <i class="fa fa-edit f20"></i> 
                                        </a>
                                    </td>
                                </tr>
                                <input type="hidden" value="<?php echo $row->Office_8; ?>" name="Office[]"/>

                                <?php $total_amount = $total_amount + $row->amounts; ?>
                            <?php endforeach; ?>
            <?php
            $i++;
        endforeach;
        ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?> 
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
                </section>
    <?php endif; ?>

        </div>
    </div>


    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal"><b>Exporter</b></button>

                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div class="col-lg-12 p-0" style="margin-top: -35px;">
        <div class="ibox bg-white">

            <div class="ibox-title border-bottom">
                <!--                            <h2 class="text-blue">Pr&eacute;-paiement par client</h2>-->
            </div>
    <?php if (!empty($prepaids) || !empty($prepaids_from_reporting)): ?>
                <div class="col-sm-12">
        <?php echo form_open('', array('id' => 'searchform', 'class' => 'margin')); ?>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for=""><b>Référence sydonia</b></label>

                            </div> 
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for=""><b>Bureau</b></label>
        <?php echo form_dropdown('Recette', $services, '', ' id="recette" class="form-control" '); ?>

                            </div>    
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for=""><b>P&eacute;riode</b></label>
                                <div class="input-daterange input-group">
                                    <span class="input-group-addon">De</span>
                                    <input class="input-sm form-control" name="start" value="<?php echo gmdate('Y-m-d') ?>" id="datepicker1" type="text">
                                    <span class="input-group-addon">à</span>
                                    <input class="input-sm form-control" name="end" value="<?php echo gmdate('Y-m-d') ?>"  id="datepicker2" type="text">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for=""><b>Agence</b></label>
        <?php echo form_dropdown('guichet', $guichets, '', ' id="recette" class="form-control" '); ?>

                            </div>    
                        </div>
                        <div class="col-md-2 text-right d-flex align-items-center mt-2">
                            <div class="action-buttons">

                                <button type="submit" class="btn btn-primary" >Extraire</button>
                                <button type="submit"id="export" class="btn btn-success">Exporter</button>

                            </div>
                        </div>


                    </div>
        <?php echo form_close(); ?>
                </div>

                <div class="col-md-12">
                    <table id="table" class="table table-hover table-striped">
                        <thead class='bg-gray'>
                            <tr>
                                <th width="5px">#</th>
                                <th width="150px">R&eacute;f&eacute;rence SYDONIA</th>
                                <th width="150px">Bureau</th>
                                <th width="100px">Declarant</th>
                                <th width="100px" class="center">Nombre des BL</th>
                                <th width="150px" class="center">Montant total</th>
                                <th width="10px" class="" ><i class="fa fa-edit f20"></i></th>
                            </tr>
                        </thead>
                        <tbody>

                            <!-- Encaissements -->
        <?php
        $i = 1;
        foreach ($prepaids as $key => $payments):
            ?>
            <?php foreach ($payments as $row): ?>
                                    <tr>
                                        <td width=""><?php echo $i; ?></td>
                                        <td width=""><?php echo $row->AccountRef_14; ?></td>
                                        <td width=""><?php echo $services['DGDA'][$row->Office_8]; ?></td>
                                        <td width=""><ul><?php echo $row->Declarant_16; ?></ul></td>
                                        <td width=""><ul><?php echo $row->total; ?></ul></td>
                                        <td width=""><ul><?php echo $row->amounts; ?></ul></td>
                                        <td width="">
                                            <a style="cursor: pointer" onclick="view_bulletin('<?php echo $row->AccountRef_14; ?>', '<?php echo $row->Office_8; ?>')"> 
                                                <i class="fa fa-edit f20"></i> 
                                            </a>
                                        </td>
                                    </tr>
                                <input type="hidden" value="<?php echo $row->Office_8; ?>" name="Office[]"/>

                <?php $total_amount = $total_amount + $row->amounts; ?>
                            <?php endforeach; ?>
                            <?php
                            $i++;
                        endforeach;
                        ?>

                        <!-- Encaissements from reporting -->
        <?php
        $i = 1;
        foreach ($prepaids_from_reporting as $key => $payments):
            ?>
            <?php foreach ($payments as $row): ?>
                                <tr>
                                    <td width=""><?php echo $i; ?></td>
                                    <td width=""><?php echo $row->AccountRef_14; ?></td>
                                    <td width=""><?php echo $services['DGDA'][$row->Office_8]; ?></td>
                                    <td width=""><ul><?php echo $row->Declarant_16; ?></ul></td>
                                    <td width=""><ul><?php echo $row->total; ?></ul></td>
                                    <td width=""><ul><?php echo $row->amounts; ?></ul></td>
                                    <td width="">
                                        <a style="cursor: pointer" onclick="view_bulletin('<?php echo $row->AccountRef_14; ?>', '<?php echo $row->Office_8; ?>')"> 
                                            <i class="fa fa-edit f20"></i> 
                                        </a>
                                    </td>
                                </tr>
                                <input type="hidden" value="<?php echo $row->Office_8; ?>" name="Office[]"/>

                        <?php $total_amount = $total_amount + $row->amounts; ?>
                    <?php endforeach; ?>
            <?php
            $i++;
        endforeach;
        ?>
                        </tbody>
                    </table>
                </div>
    <?php else: ?> 
                <section id="cat_list" class="text-center ">
                    <span class="d-block  "><span class="fa fa-flask text-gray mystyle4" ></span></span></br>
                    <span class="d-block f14 text-black p-2"><b>Aucun enregistrement fait!</b></span>        
                </section>
    <?php endif; ?>

        </div>
    </div>

    <div class="modal inmodal fade" id="modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">D&eacute;tail des bulletins  pr&eacute;pay&eacute;s</h4>
                </div>
                <div class="modal-body"  id="modal-pager" >

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><b>Fermer</b></button>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    function view_bulletin(account, office)
    {
        $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxreports/display/_bulletins'); ?>/';

        $.get(url, {compte: account, office: office}, function (data, status) {
            $("#message1").html('');
            $('#modal').modal('show');
            $("#modal-pager").html(data);
        });
    }

    function close_form()
    {
        $("#message1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        $.get("<?php echo base_url($module . '/taxreports/display/report_prepayments'); ?>", function (data, status) {
            $("#message1").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');

            $("#close").removeClass('hidden');
            $("#close_form").addClass('hidden');

        });
    }

</script>