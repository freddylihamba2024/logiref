<?php
    $paiements = 0;
    $dgi = 0;
    $dgda = 0;
    $dgrad = 0;
?>

<?php if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] != 4): ?>
    <div class="row">
        <div class="col-md-12" id="message1"></div>
    </div>

    <div class="row" style="margin-top: -35px;">
        <div class="col-lg-12">
            <div class="ibox bg-white">

                <!-- TITRE -->
                <div class="ibox-title border-bottom">
                    <h2 class="text-blue">Fonds propres - Autres encaissements</h2>
                </div>

                <!-- FORMULAIRE DE FILTRE -->
                <div class="col-sm-12">
                    <?= form_open('', ['id' => 'searchform', 'class' => 'margin']); ?>
                    <div class="row">
                        <div class="col-md-5">
                            <label><b>Institutions</b></label>
                            <?= form_dropdown('Beneficaire_15', $beneficiaires, '', 'class="form-control"'); ?>
                        </div>

                        <div class="col-md-5">
                            <label><b>Période</b></label>
                            <div class="input-daterange input-group">
                                <span class="input-group-addon">De</span>
                                <input class="form-control" name="start" type="text" id="datepicker1">
                                <span class="input-group-addon">à</span>
                                <input class="form-control" name="end" type="text" id="datepicker2">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label>&nbsp;</label>
                            <div>
                                <button type="submit" id="search" class="btn text-white bg-blue-active"><i class="fa fa-fw fa-refresh"></i></button>
                                <!-- <button class="btn btn-primary">Extraire</button> -->
                                <button id="export" class="btn btn-success" <?= (empty($encaissements) && empty($encaissements_from_reporting) ? "disabled" : "") ?>>Exporter</button>
                            </div>
                        </div>
                    </div>
                    <?= form_close(); ?>
                </div>

                <!-- TABLEAU -->
                <div class="col-lg-12 table-responsive" id="result">
                    <?php if (!empty($encaissements) || !empty($encaissements_from_reporting) || !empty($encaissements_immatriculation)): ?>
                        <table class="table table-hover table-striped" id="table">
                            <thead class="bg-gray f12">
                                <th>#</th>
                                <th>Date</th>
                                <th>Régie</th>
                                <th>Client</th>
                                <th>Recette</th>
                                <th>Service</th>
                                <th>Montant</th>
                                <th>Contre-valeur</th>
                                <th>Commissions</th>
                                <th><span class="fa fa-fw fa-folder f14"></span></th>
                            </thead>
                            <tbody>
                                <?php
                                $i = 0;
                                $paiements = $commissions = $suspend = $urgent = 0;

                                // ENCAISSEMENTS
                                foreach ($encaissements as $row):
                                ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer">
                                        <td><b><?= ++$i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>"><?= $row->Datevaleur_31 ?></td>
                                        <td><b><?= $row->Beneficaire_15 ?></b></td>
                                        <td class="text-blue"><?= $row->Designation_14 ?></td>
                                        <td><?= $row->Typerecette_17 ?></td>
                                        <td><?= $services[$row->Service_16] ?? '' ?></td>
                                        <td class="text-blue"><?= $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ',', ' ') ?></td>
                                        <td class="text-gray"><?= 'CDF ' . number_format($row->Contrevaleur_22, 2, ',', ' ') ?></td>
                                        <td class="text-black"><?= $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ',', ' ') ?></td>
                                        <td>
                                            <a style="cursor:pointer" onclick="view('<?= $row->Id_0 ?>','<?= $row->Beneficaire_15 ?>')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php
                                    $paiements += $row->Contrevaleur_22;
                                    $commissions += $row->Commission_23;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) $suspend++;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d')) $urgent++;
                                endforeach;

                                // ENCAISSEMENTS FROM REPORTING
                                foreach ($encaissements_from_reporting as $row):
                                ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer">
                                        <td><b><?= ++$i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>"><?= $row->Datevaleur_31 ?></td>
                                        <td><b><?= $row->Beneficaire_15 ?></b></td>
                                        <td class="text-blue"><?= $row->Designation_14 ?></td>
                                        <td><?= $row->Typerecette_17 ?></td>
                                        <td><?= $services[$row->Service_16] ?? '' ?></td>
                                        <td class="text-blue"><?= $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ',', ' ') ?></td>
                                        <td class="text-gray"><?= 'CDF ' . number_format($row->Contrevaleur_22, 2, ',', ' ') ?></td>
                                        <td class="text-black"><?= $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ',', ' ') ?></td>
                                        <td>
                                            <a style="cursor:pointer" onclick="view('<?= $row->Id_0 ?>','<?= $row->Beneficaire_15 ?>')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php
                                    $paiements += $row->Contrevaleur_22;
                                    $commissions += $row->Commission_23;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) $suspend++;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d')) $urgent++;
                                endforeach;
                                ?>

                                <?php foreach ($encaissements_immatriculation as $row) : ?>
                                    <tr class="list-contact" data-id="<?= $row->Id_0 ?>" style="cursor: pointer">
                                        <td><b><?= ++$i ?></b></td>
                                        <td class="<?= ($row->Datevaleur_31 !== gmdate('Y-m-d')) ? 'text-red' : '' ?>"><?= $row->Datevaleur_31 ?></td>
                                        <td><b><?= $row->Beneficaire_15 ?></b></td>
                                        <td class="text-blue"><?= $row->Designation_14 ?></td>
                                        <td><?= $row->Typerecette_17 ?></td>
                                        <td><?= $services[$row->Service_16] ?? '' ?></td>
                                        <td class="text-blue"><?= $row->Devise_12 . ' ' . number_format($row->Montant_11, 2, ',', ' ') ?></td>
                                        <td class="text-gray"><?= 'CDF ' . number_format($row->Contrevaleur_22, 2, ',', ' ') ?></td>
                                        <td class="text-black"><?= $row->Devise_24 . ' ' . number_format($row->Commission_23, 2, ',', ' ') ?></td>
                                        <td>
                                            <a style="cursor:pointer" onclick="view('<?= $row->Immatriculation_52 ?>','DGI_IMMATRICULATION')">
                                                <span class="fa fa-fw text-green fa-folder-open f14"></span>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                    $paiements += $row->Contrevaleur_22;
                                    $commissions += $row->Commission_23;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0) $suspend++;
                                    if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d')) $urgent++;

                                    ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <section class="text-center mt-5">
                            <span class="fa fa-flask text-gray mystyle4"></span><br>
                            <b>Aucun enregistrement trouvé !</b>
                        </section>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8">
    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });

    $('#table').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50
    });

    $("#contenter").on("click", ".item", function() {

        var id = $(this).attr('data-id-item');
        $("#form_paiement").removeClass('hidden');
        $("#close").addClass('hidden');
        $("#cancel").addClass('hidden');

    });

    $("#searchform").submit(function(e) {
        e.preventDefault();
        $("#message").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxreports/display/filterresult/propre'); ?>';
        var data = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $('#message1').html('');
                $("#export").removeAttr("disabled");
                $('#result').html(result);
            },
            error: function(error) {
                alert('ERROR!' + error);
            }
        });

    });

    $("#export").click(function(e) {
        e.preventDefault();

        $("#message").html('<img align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        let url = "<?= base_url($module . '/taximpression/display/export_fonds_propres'); ?>";
        let data = $("#searchform").serialize();

        $.ajax({
            url: url,
            type: "POST",
            data: data,
            xhrFields: {
                responseType: 'blob'
            },
            success: function(blob, status, xhr) {

                $("#message1").html('');

                // Récupération du nom du fichier depuis le header
                let disposition = xhr.getResponseHeader('Content-Disposition');
                let filename = "report_paiement_propres.xlsx";

                if (disposition && disposition.indexOf('filename=') !== -1) {
                    filename = disposition
                        .split('filename=')[1]
                        .replace(/"/g, '');
                }

                // Téléchargement forcé
                let url = window.URL.createObjectURL(blob);
                let a = document.createElement('a');

                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();

                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            },
            error: function() {
                $("#message1").html('');
                alert("Erreur lors de l’export");
            }
        });
    });


    function view(id, regie) {
        var url = '';
        if (regie === 'DGI') {
            var url = "<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/" + id;
        } 
        else if(regie=='DGI_IMMATRICULATION')
        {
            var url = "<?php echo base_url($module . '/taximmatriculation/display/preview'); ?>/" + id;
        }
        else if (regie === 'DGRAD') {
            var url = "<?php echo base_url($module . '/taxnotes/display/preview'); ?>/" + id;
        }

        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        $.get(url, function(data, status) {
            $("#message1").html('');
            $("#pager").html(data);
            $("#form").addClass('hidden');
            $("#form").removeClass('hidden');
        });
    }
</script>
