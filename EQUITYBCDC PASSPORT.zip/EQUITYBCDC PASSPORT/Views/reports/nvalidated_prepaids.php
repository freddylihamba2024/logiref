<?php 

$paiements = 0;
$paiements_dgi = 0;
#$commissions = 0;
$suspend = 0;
$urgent = 0;
$i = 0;

?>
<div class="col-md-12" id="loader"></div>
<div id="pager"  class="col-md-12"> 
   
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 height90">
                        <h5 class="card-title f12 text-black width200">Nombre de pr&eacute;paiement</h5>
                        <p class="text-blue f18"> <b>CDF <span id=""></span></b></p>
                        <!--<p class="text-blue f18"> <b>USD <span id="paiements_dgi"></span></b></p>-->
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body p-2 height90">
                        <h5 class="card-title f12 text-black width200">Pr&eacute;paiements en attente</h5>
                        <p class="text-green f18"><b>CDF <span id="paiements"></span></b></p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="card">
                     <div class="card-body p-2 height90">
                         <h5 class="card-title f12 text-black width200">Pr&eacute;paiements valid&eacute;</h5>
                        <p class="f18 text-blue"><a class="cursor-pointer" onclick="filter('urgents')"><b><span id="urgent"></span></b> <span class="fa fa-fw text-danger fa-filter fa-x"> </span></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h1 class="f30 text-black"><b>Liste des pr&eacute;-paiements non valid&eacute;s</b></h1>
            <h5 class="page-header"><span class="text-gray f15" >Cette section vous pr&eacute;sente l'ensemble des paiements non valid&eacutes.</span></h5>
    </div>
    <div class="col-md-12">
        <div  id="message"></div>     
            <?php $chtml->box_body_opening('', true);?>
                    <?php if(!empty($prepayments)): ?>
                           
                            <div class="col-lg-12 table-responsive " id="paiementslist">
                                <table class="table table-striped bg-white" id="table">
                                    <thead  class="text-blue rounded" style="border-radius: 20px !important;background-color: #EEF6F8;">
                                        <tr class="bg-gray f12">
                                            <th class="f12"></th>
                                            <th class="f12" width="50">Date</th>
                                            <th class="f12">D&eacute;signation</th>
                                            <th class="f12">B&eacute;n&eacute;ficiaire</th>
                                            <th class="f12">Recette</th>
                                            <th class="f12">Montant</th>
                                            <th class="f12">Commissions</th>
                                            <th class="f12" width="50">Op&eacute;rateur</th>
                                            <th class="f12"><span class="fa fa-fw fa-pencil f14"></span></th>
                                            <th class="f12"><span class="fa fa-fw text-danger fa-file-pdf-o f14"></span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                   
                                        <?php

                                        #Block last Prepayments
                                        foreach($prepayments as $row){ 
                                            $agence =  (isset($guichets[$row->Agence_30]))? $guichets[$row->Agence_30] :' - ';
                                            $operateur = (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ';
                                            $dateTime = new DateTime($row->Date_1); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                        ?>
                                            <tr>
                                                <td width="5"><b><?= ++$i;  ?></b></span></td>
                                                <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                                    <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                                </td>
                                                <td class="text-blue"><?php if($row->Designation_21 =="") echo "Bulletin de liquidation / ".$row->Nif_15; else echo $row->Designation_21; ?></td>
                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                <td><?php echo $row->Serial_9.'-'.$row->Number_10; ?><br>
                                                    <span class="text-gray">Bulletin pr&eacute;pay&eacute;</span>
                                                </td>
                                                <td class="text-blue">
                                                    <?php echo'CDF '.number_format($row->Amount_18,2,","," "); ?> 
                                                </td>
                                                <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_24,2,","," "); ?></td>
                                                <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                                <?php if($row->Status_2==1){ ?>
                                                    <td width="25">
                                                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_32==$_SESSION['Logiref_agence']){ ?>
                                                           <a class="cursor-pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php }else if($_SESSION['Logiref_role']==4 && (isset($row->Makerid_9) && $row->Makerid_9==$userid)){ ?>
                                                           <a class="cursor-pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                        <?php }else { ?>
                                                           <a class="cursor-pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item" ><span class="fa fa-fw text-green fa-pencil f14"></span></a>
                                                        <?php } ?>
                                                    </td>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                                    </td>
                                                <?php }else{ ?>
                                                    <td width="25">
                                                        <a class="cursor-pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-pencil f14"> </span></a>
                                                    </td>
                                                    <td width="25">
                                                        <span class="fa fa-fw text-gray fa-file-pdf-o f14"> </span>
                                                    </td>
                                                <?php } ?>
                                            </tr>
                                        <?php 

                                        } 
                                        ?>


                                    </tbody> 
                                </table>
                            </div>
                    <?php else:?>
                    <div>
                        <section id="cat_list" class="text-center marginTop150">
                                <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4" ></span></br>
                                <span class="d-block p-2 f14 text-black">Aucune information suppl&eacute;mentaire trouv&eacute;e</span>
                        </section>
                    </div>
                    <?php endif;?>
            <?php $chtml->box_body_closing(); ?> 
    
    
            <div class="col col-lg-4 mb-4">
            <div class="card text-center cursor-pointer">
                <div class="card-body">
                    <a href="<?php echo base_url('branch/taxreports/set/prepaids_step1'); ?>" class="text-blue">
                        <i class="fa fa-cogs fa-4x"></i>
                        <h3 class="card-title">Sftp</h3>
                    </a>
                </div>
            </div>
        </div>
    <?php //endif; ?>
</div>

        </div>   
</div>


<script type="text/javascript">

$("#contenter").unbind().on("click", ".item", function(){
        
        $("#close").addClass('hidden');
        $("#close_form").removeClass('hidden');
});


$('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
$('#paiements_dgi').html('<?php echo number_format($paiements_dgi,2,","," "); ?>');
$('#attente').html('<?php echo $suspend; ?>');
$('#urgent').html('<?php echo $urgent; ?>');

function view_process(id, regie, param)
{
    if(param == 1)
    {
        var url ="<?php echo base_url($module.'/taxbulletin/display/edit'); ?>/"  + id;
    }
    else
    {
        var url ="<?php echo base_url($module.'/taxbulletin/display/step_1_process'); ?>/"  + id;
    }
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}
 
function viewPrepayment(id)
{

    '<?php if($_SESSION['Logiref_role'] !=4): ?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php else :?>'
        var url ="<?php echo base_url($module.'/taxprepayments/display/preview'); ?>/"  + id;
    '<?php endif; ?>'
        
    $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
    $.get(url, function(data, status){
        $("#message").html('');
        $("#pager").html(data);
        $("#form").addClass('hidden');
        $("#form").removeClass('hidden');
    });
}

function print_payment(pid){

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}

</script>