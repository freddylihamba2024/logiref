<?php
    $userid = $_SESSION['userdata']['user_id'];
    $usertype = $_SESSION['userdata']['user_type'];
    $paiements = 0;
    $validated = 0;
    $suspend = 0;
    $regulate = 0;
    $i = 0;
?>
<?php if (!empty($encaissements)): ?>
    <table class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray f12">
                <th>#</th>
                <th>Date</th>
                <th width="">Status</th>
                <th width="10">R&eacute;gie</th>
                <th>Recette</th>
                <th>Client</th>
                <th width="">Note</th>
                <th>Montant</th>
                <th>Commissions</th>
                <th>Agences</th>
                <th>Op&eacute;rateur</th>
                <th><span class="fa fa-fw fa-folder f14"></span></th>
                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $paiements = 0;
            $commissions = 0;
            $suspend = 0;
            $urgent = 0;
            $i=0;

            foreach ($encaissements as $row):
                $infos = json_decode($row->Notereference_30);
                $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
            ?>
                <tr>
                    <td width="5"><b><?php echo ++$i; ?></b></span></td>
                    <td><?php echo $row->Datevaleur_31 ?></td>
                    <td width="10%"><span class="badge <?php echo $colors[$row->Status_2]; ?>"><?php echo $status[$row->Status_2];?></span></td>
                    <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                    <td><b><?php echo $row->Typerecette_17; ?></b></td>
                    <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                    <td><b><?php echo strtoupper($row->Noteid_26); ?></b></td>
                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>
                    <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>
                    <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                    <?php if($row->Checkerid_10==0): ?>
                        <td width="25">
                            <?php if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata('user_id')): ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                            <?php else : ?>
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-folder-open f14"></span></a>
                            <?php endif; ?>
                        </td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                        </td>
                    <?php else: ?>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-green fa-folder-open f14"></span></a>
                        </td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php
                if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                    $suspend = $suspend + 1;
                if (($row->Status_2 == 2 OR $row->Status_2 == 3) && $row->Checkerid_10 > 0)
                    $validated = $validated + 1;
                if ($row->Status_2 >= 4)
                    $regulate = $regulate + 1;
            endforeach;
            ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="col-md-12">
        <section id="cat_list" class="text-center pt-5 pb-5">
            <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
            <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
        </section>
    </div>
<?php endif; ?>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">

    $('#paiements').html('<?php echo number_format(count($encaissements) ,0,","," "); ?>');
    $('#paiements').addClass('text-blue');
    $('#validated').html('<?php echo number_format($validated,0,","," "); ?>');
    $('#validated').addClass('text-green');
    $('#attente').html('<?php echo number_format($suspend,0,","," "); ?>');
    $('#attente').addClass('text-yellow');
    $('#regulate').html('<?php echo number_format($regulate,0,","," "); ?>');
    $('#regulate').addClass('text-red');

    $('#table').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageSize": 50,
    });
</script>