<div class="row mb-5">
    <div id="loader"></div>
    <div class="col-md-11">
        
        <div class="col-md-12 alert alert-danger d-none alert-dismissible fade show" id="error" role="alert">
            <div class="d-flex justify-content-between">
                <p><strong>Erreur : </strong> <span id="error_message">Aucun rapport trouvé !</span></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        
        <?php
            $chtml->box_body_opening("", true);
            echo form_open('', array('id' => 'mainform', 'class' => '')); 
        ?>
            <div class="statistic-box no-border">
                <div class="row">
                    <div class="col-sm-10 col-xs-12">
                        <h2>Listes des paiements des clients</h2>
                        <h5 class="page-header"><!--<span class="text-gray">Cette section vous pr&eacute;sente la liste des recettes globales par agence.</span>--></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-5 col-sm-4 col-xs-12 small-box">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <b>Op&eacute;rateur </b>
                            </span>
                            <?php echo form_dropdown('operator', $operators, '', 'class="form-control" '); ?>
                        </div>
                    </div>
                    <div class="col-md-5 small-box">
                        <div class="form-group">
                            <div class="input-daterange input-group">
                                <span class="input-group-addon">Initi&eacute;e entre le</span>
                                <input class=" form-control" name="start" value="<?php echo gmdate('Y-m-d')?>" id="datepicker1" type="text">
                                <span class="input-group-addon">et le</span>
                                <input class=" form-control" name="end" value="<?php echo gmdate('Y-m-d')?>"  id="datepicker2" type="text">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-bitbucket text-white bg-blue-active" id="print"><i class="fa fa-print"></i></button>
                        <button type="button" class="btn btn-success text-white bg-blue-active" id="export"><i class="fa fa-file-excel-o"></i></button>
                        <button type="submit" class="btn btn-bitbucket pull-right text-white bg-blue-active"><i class="fa fa-fw fa-search"></i></button>
                    </div>
                </div>
            </div>
        <?php 
            echo form_close(); 
        ?>
            
        <div id="page">
            <input type="hidden" id="nbre" value="<?= (count($_SESSION["bulletins"]) > 0 || count($_SESSION["encaissements"]) > 0)?1:0 ?>"/>
            <?php if(!empty($encaissements) || !empty($bulletins)): ?>
                <div class="table-responsive">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-aqua text-white">
                                <th>No</th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Service</th>
                                <th>Recette</th>
                                <th>Montant</th>
                                <th>Commissions</th>
                                <th>Op&eacute;rateur</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php 
                            #Block last BL
                            foreach($bulletins as $row){ 
                                $agence =  (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                                $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                <tr>
                                    <td width="5"><b>#</b></span></td>
                                    <td  width="80" <?php if($row->Status_2==4) echo 'class="text-black"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-black"';?> >
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                    <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                    <td width=""><b><?php echo $row->Office_6 ?></b></td>
                                    <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                    <td class="text-blue">
                                        <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                    </td>
                                    <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                    <td width="50"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                </tr>
                            <?php 
                                } 
                            ?>
                            <?php  
                                foreach($encaissements as $row){ 
                                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                <tr>
                                    <td width="5"><b>#</b></span></td>
                                    <td width="50" <?php echo 'class="text-black"';?>>
                                        <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                    </td>
                                    <td class="text-blue" width="50"><?php echo $row->Designation_14; ?></td>
                                    <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                    <td><?php echo $beneficiaires[$row->Service_16]; ?></td>
                                    <td><?php echo $row->Typerecette_17; ?></td>
                                    <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                        <br/>
                                        <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                    <td><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                                </tr>
                            <?php 
                                } 
                            ?>
                        </tbody>    
                    </table>
                        
                    <input type="hidden" name = "encaissements" value='<?php echo(!empty($encaissements))? json_encode($encaissements): '';?>'>
                     
                </div>
            <?php else: ?>
                <section class="m-5">
                    <h4 align="center">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        <b>Aucun rapport trouv&eacute; !</b>
                    </h4>
                </section>
            <?php endif; ?>
        </div>
        <?php 
            $chtml->box_body_closing(); 
        ?>
    </div>
    <div class="col-md-1">
        <a href="<?php echo base_url($module.'/taxreports/set/rapport'); ?>" class="btn btn-app no-border pull_left"><span class="fa fa-fw fa-times text-gray f40"></span></a>
    </div>
</div>


<script type="text/javascript">

    $('#table').DataTable({
          "paging": true,
          "lengthChange": false,
          "order": [[5, "DESC" ]],
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "pageSize": 50,
    });



    $('#datepicker1').datepicker({
            format: 'yyyy-mm-dd'
    });

    $('#datepicker2').datepicker({
            format: 'yyyy-mm-dd'
    });

    $("#mainform").submit(function(e)
    {
            e.preventDefault();
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var data = $(this).serialize();
            var url = '<?php echo base_url($module.'/taxreports/display/client_filter'); ?>'; 
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            $('#loader').html('');
                            $('#page').html(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });
    });

    $("#print").click(function(){

            var data = $("#mainform").serialize();
            var url = '<?php echo base_url($module.'/taximpression/display/print_client'); ?>';
            $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : data, 
                        dataType    : 'html', 
                        encode      : true,
                        success: function(result){
                            print(result);
                        },
                        error:function(error){
                            alert('ERROR:'+error);
                        }
            });

    });

    function print(buffer)
    {
            window.open('<?php echo base_url()?>'+buffer);
    }
    
    $("#export").click(function(){
        var nbre = $("#nbre").val();
        if(nbre > 0){
            $("#error").addClass('d-none');
            $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            var url = '<?php echo base_url($module.'/taximpression/display/export_client'); ?>';
            window.open(url);
            $("#loader").empty();
        }
        else{
            $("#error").removeClass('d-none').show();
        }
    });
</script>



