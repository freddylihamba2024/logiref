<?php $userid = $this->session->userdata("user_id");?>
<?php $usertype = $this->session->userdata("user_type");?>
<div class="col-md-12">
    <div class="statistic-box no-border no-padding">
            <div class="col-md-12 <?= $title; ?>">
                <h1>Gestion des commissions</h1>
                <h5 class="page-header"><span class="text-gray">Trouvez ici la liste de toutes les commissions bancaires.</span></h5>
            </div>
            <div class="col-sm-12">
                <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
                    <div class="row">
                        
                        <div class="col-md-5">
                            <div class="form-group">  
                                <div class="input-group">
                                    <span class="input-group-addon"><b>Agences</b></span><?php echo form_dropdown('agence', $guichets, '', ' id="" class="form-control" '); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">  
                                <div class="input-group">
                                    <span class="input-group-addon"><b>R&eacute;gies</b></span><?php echo form_dropdown('regies', $regies, '', ' id="" class="form-control" '); ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-bitbucket pull-right"><i class="fa fa-fw fa-refresh"></i></button>&nbsp;&nbsp;&nbsp;
                        </div>
                        <!--<div class="col-md-1">
                            <a class="btn btn-default" href="#" id="print">Imprimer <i class="fa fa-print text-gray"></i></a>
                        </div>-->
                        <div class="col-md-1">
                            <button type="submit" id="export" class="btn btn-success">Exporter</button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    <div class="col-md-12">
        <?php $this->chtml->box_body_opening('', true); ?>
            <div id="paiementslist">
                <?php if(!empty($regles)): ?>
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-blue">
                                <th>#</th>
                                <th>Priorit&eacute;</th>
                                <th>B&eacute;n&eacute;ficiaire</th>
                                <th>Indice</th>
                                <th>Service</th>
                                <th>Recette</th>
                                <th>Guichet</th>
                                <th>Min</th>
                                <th>Max</th>
                                <th>Validation</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($regles as $row){ ?>
                            <tr>
                                <td width="5"><?php echo $row->Id_0; ?></td>
                                <td class="<?php if($row->Priorite_4 == 1){ echo 'bg-gray';}elseif($row->Priorite_4 == 2){echo 'bg-green';}elseif($row->Priorite_4 == 3){echo 'bg-blue';}elseif($row->Priorite_4 == 4){echo 'bg-orange';}elseif($row->Priorite_4 == 5){echo 'bg-yellow';}elseif($row->Priorite_4 == 6){echo 'bg-red';} ?> " align="center"><b>P<?php echo $row->Priorite_4; ?></b></td>
                                <td><?php if($row->Beneficiaire_5=='' or $row->Beneficiaire_5=='0') echo 'TOUS'; else echo ' '.$row->Beneficiaire_5;?></td>
                                <td class="bleu"><b><?php echo $row->Value_9.' '.$row->Unite_10;?></b></td>
                                <td><?php if($row->Service_6=='') echo 'TOUS'; else echo ' '.$services[$row->Beneficiaire_5][$row->Service_6];?></td>
                                <td><?php if($row->Recette_7=='') echo 'TOUTES'; else echo ' '.$row->Recette_7;?></td>
                                <td><?php if($row->Guichet_8=='') echo 'TOUS'; else echo ' '.$guichets[$row->Guichet_8];?></td>
                                <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Min_11,2,","," ");?></td>
                                <td class="bleu"><?php echo $row->Devise_13.' '.number_format($row->Max_12,2,","," ");?></td>
                                <td>
                                    <?php if($row->Checkerid_15==0){ ?>
                                      <span class="text-red"> En attente </span>
                                    <?php }else {?>
                                      <?php echo $row->Validation_16;?>
                                    <?php } ?>
                                </td>

                            </tr>
                        <?php } ?>
                        </tbody>    
                    </table>
                <?php else: ?>
                    <section id="cat_list">
                        <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucune r&egrave;gle n'est enregistr&eacute;e !<br/>
                        </div>
                    </section>
                <?php endif;?>
            </div>
        <?php $this->chtml->box_body_closing(); ?>
    </div>
</div>


<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#export").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module.'/impression'); ?>/display/export_commissions';

        window.open(url);

});

$("#searchform").submit(function(e){
    e.preventDefault();
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/reports/display/commissions_filter'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#paiementslist').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

</script>