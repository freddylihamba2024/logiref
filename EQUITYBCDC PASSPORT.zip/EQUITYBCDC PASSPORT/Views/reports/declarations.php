<div class="col-md-7">
    <h2 class="text-blue">Licence BCC (Emargement)</h2>
    <h5 class="page-header"><span class="text-gray">Cette section vous pr&eacute;sente toutes les licences BCC extraites depuis la douane.</span></h5>
</div>
<?php echo form_open('', array('id' => 'sendack', 'class' => 'innovate')); ?>
<div class="col-md-5">
    <br/>
    <div class="col-md-7 bLeft">
        <div class="form-group">
            <span class="input-group"><label for="message">Message</label></span> 
            <?php echo form_dropdown('message',$messages, '', 'class="form-control" id="message" required = "required"'); ?>
        </div>
    </div>
    <div class="col-md-5" id="ack" style="padding-left: 40px;">
        <div class="form-group">
             <span class="input-group"><label for="message">&nbsp;&nbsp;&nbsp;&nbsp;</label></span> 
            <button type="submit" id="submit" name="submit" disabled="disabled" class="btn btn-success  margin-bottom">Accuser r&eacute;ception <span class="Bold" id="index"></span> <i class="fa fa-check"></i></button>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div id="loader1"></div>
    <?php if (!empty($declarations)): ?>
    <?php $chtml->box_body_opening('', true); ?>  
        <table id="table" class="table no-margin table-striped table-bordered">
            <thead class='bg-blue'>
                <tr>
                    <th width="5">#</th>
                    <th width="30%">D&eacute;signation</th>
                    <th>Num&eacute;ro imp&ocirc;t</th>
                    <th>Nombre d'articles</th>
                    <th>Bureau</th>
                    <th>Code banque</th>
                    <th>Num&eacute;ro quittance</th>
                    <th width="5"><span class="fa fa-fw fa-tasks f14"></span></th>
                    <th width="5"><span class="fa fa-fw fa-check f14"></span></th>
                </tr>
            </thead>
            <tbody>
                <?php                                   
                    $i = 1;
                    foreach($declarations as $row){ 
                ?>
                    <tr>
                        <td width="2%"><span class="text-blue"><b><?php echo $i; ?></b></span></td>
                        <td width="20%"><?php echo $row->Designation_8 ?></td>
                        <td><?php echo $row->Nif_9 ?></td>
                        <td class="text-center" ><?php echo $row->Nombrearticles_14 ?></td>
                        <td><?php echo $row->Codebureau_10 ?></td>
                        <td><?php echo $row->Codebank_16?></td>
                        <td><?php echo $row->Numquittance_17 ?></td>
                        <td width="5%"> 
                            
                            <a style="cursor: pointer" onclick="view('<?php echo $row->Id_0; ?>')"> 
                                <i class="fa fa-fw text-yellow fa-folder-open-o f14"></i> 
                            </a>
                        </td>
                        <td width="5"> 
                            <?php if($row->Status_2 == 1): ?>
                                <span class="fa fa-fw text-gray fa-question-circle f14"></span>
                            <?php elseif($row->Status_2 == 2): ?>
                                <input type="checkbox" class="text-blue" id="d<?php echo $row->Id_0;?>"  onclick="validate('<?php echo $row->Id_0;?>')" value="<?php echo $row->Messagekey_7; ?>" name="messageskeys[<?php echo $row->Id_0;?>]" />
                            <?php elseif($row->Status_2 == 3): ?>
                                <span class="fa fa-fw text-blue fa-check-circle f14"></span>
                            <?php elseif($row->Status_2 == 4): ?>
                                <span class="fa fa-fw text-red fa-times-circle f14"></span>
                            <?php endif;?> 
                        </td>
                    </tr>


                <?php 
                $i++;
                    } ?>
            </tbody>
        </table>
    <?php $chtml->box_body_closing(); ?>
    <?php else: ?>
        <section>
            <div class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                <h4 align="center"><b>Aucune d&eacute;claration trouv&eacute; !</b></h4>
                <br/>
            </div>
        </section>
    <?php endif; ?> 
</div>
<?php echo form_close(); ?>
<div class="modal fade" id="modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Articles de la d&eacute;claration</h4>
          </div>
          <div id="modal-pager" class="modal-body">
            <p>One fine body&hellip;</p>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": false,
      "bLengthChange": false
});

function view(bId)
{
        var url = '<?php echo base_url($module.'/bank/display/declaration_detail'); ?>/' +bId ;
        $.get(url, function(data, status){
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        });
}

function validate(id)
{
    $("#d"+id).change(function()
        {
                var $checkedInputs = $('#table').find("input:checked");
                var index = $checkedInputs.length;
               
                if(index > 0)
                {
                        $("#ack").css("padding-left", '20px');
                        $("#submit").removeClass("btn-success");
                        $("#submit").prop("disabled",false);
                        $("#submit").addClass("btn-primary");
                        $("#index").html('('+ index+')');
                        

                }
                else if(index <= 0)
                {
                        $("#submit").removeClass("btn-primary");
                        $("#submit").addClass("btn-success");
                        $("#submit").prop("disabled",true);
                        $("#index").html('');
                        $("#ack").css("padding-left", '40px');
                }

        });
}

$('#sendack').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader1").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/bank'); ?>/display/declarationsAck';
        var data = $(this).serialize();
        var message = $("#message").val();
        if(message !== "")
        {
            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader1').html("");
                    if(result ==='41' || result ==='42')
                    {
                        $('#loader1').html('');
                        $("#loader1").html('<div class="alert alert-success text-white">Bravo! Transaction cl&ocirc;tur&eacute;e avec succ&egrave;s...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result ==='E404')
                    {
                        $('#loader1').html('');
                        $("#loader1").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(result ==='E401')
                    {
                        $('#loader1').html('');
                        $("#loader1").html('<div class="alert alert-warning text-white">Alerte: serveur SYDONIA 41.215.253.187 pas disponible...!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                   
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
            });
        }
        else
        {
                $("#loader1").html('<div class="alert alert-warning text-white">Alerte: Le champ message n\'est peut pas &ecirc;tre vide!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
        
});


</script>

