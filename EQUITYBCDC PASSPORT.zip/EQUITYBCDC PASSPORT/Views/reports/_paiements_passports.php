<div id="pager"  class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-blue f30">Rapports des paiements des passports</h1>
            <p class="page-header"><span class="f12 text-black">Cette section vous pr&eacute;sente les rapports des paiements des passports effectués en ligne et en agence.</span></p>
        </div>
    </div>

    <br/>

    <div class="tab_container">
        <div class="tabs">
            <div class="tab tab-active" onclick="openTab(event,'encaissements_agence')">Paiements en Agence</div>
            <div class="tab" onclick="openTab(event,'encaissements_online')">Paiements en Ligne</div>
        </div>

        <div id="message"></div>

        <?php $chtml->box_body_opening('', true); ?>
            <div class="tab-item-container">
                <div id="encaissements_agence" class="tab-item">
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform_agence', 'class' => '')); ?>
                        <div class="row">
                            <!--<div class="col-md-3">
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><b>Agence</b></span><?php echo form_dropdown('guichet', $guichets, '', ' id="" class="form-control" '); ?>
                                    </div>
                                </div>
                            </div>-->
                            <div class="col-md-9">
                                <div class="form-group">
                                    <div class="input-daterange input-group">
                                        <span class="input-group-addon">Initi&eacute;e entre le</span>
                                        <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d') ?>" id="datepicker1" type="text">
                                        <span class="input-group-addon">et le</span>
                                        <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d') ?>"  id="datepicker2" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-bitbucket bg-blue-active pull-right"> <i class="fa fa-fw fa-search text-gray"></i></button>&nbsp;&nbsp;&nbsp;
                            </div>
                            <div class="col-md-2">
                                <!--<button type="submit"id="export" class="btn btn-success pull-right" style="margin-left: 35px;">Exporter</button>-->
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                    <div class="col-md-12 no-padding" id="filterResult_agence">
                        <?php if (!empty($encaissements_agence)): ?>
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr class="bg-gray">
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Art.Budgetaire</th>
                                        <th>Client</th>
                                        <th>Montant</th>
                                        <th>Commissions</th>
                                        <th>Agences</th>
                                        <th><span class="fa fa-fw fa-folder f14"></span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $paiements = 0;
                                    $commissions = 0;
                                    $suspend = 0;
                                    $urgent = 0;
                                    $i=0;
                                    foreach ($encaissements_agence as $row) {
                                        $infos = json_decode($row->Notereference_30);

                                        #$infos->QuotasComite;
                                        #var_dump($infos);die;
                                        ?>
                                        <tr>
                                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                            <!--<td <?php //if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"';         ?>><?php //echo $row->Date_1;         ?></td>-->
                                            <td><?php echo $row->Datevaleur_31 ?></td>
                                            <td><b><?php echo $row->Typerecette_17; ?></b></td>
                                            <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                            <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>

                                            <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>

                                            <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>

                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                        </tr>
                                        <?php
                                        $paiements = $paiements + $row->Contrevaleur_22;
                                        $commissions = $commissions + $row->Commission_23;
                                        if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                            $suspend = $suspend + 1;
                                        if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d'))
                                            $urgent = $urgent + 1;
                                    }
                                    ?>

                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="col-md-12">
                                <section id="cat_list" class="text-center pt-5 pb-5">
                                    <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
                                    <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
                                </section>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div id="encaissements_online" class="tab-item d-none">
                    <div class="col-sm-12">
                        <?php echo form_open('', array('id' => 'searchform_online', 'class' => '')); ?>
                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <div class="input-daterange input-group">
                                        <span class="input-group-addon">Initi&eacute;e entre le</span>
                                        <input class="form-control" name="start" value="<?php echo gmdate('Y-m-d') ?>" id="datepicker3" type="text">
                                        <span class="input-group-addon">et le</span>
                                        <input class="form-control" name="end" value="<?php echo gmdate('Y-m-d') ?>"  id="datepicker4" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-bitbucket bg-blue-active pull-right"> <i class="fa fa-fw fa-search text-gray"></i></button>&nbsp;&nbsp;&nbsp;
                            </div>
                            <div class="col-md-2">
                                <!--<button type="submit"id="export" class="btn btn-success  pull-right" style="margin-left: 35px;">Exporter</button>-->
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>

                    <div class="col-md-12 no-padding" id="filterResult_online">
                        <?php if (!empty($encaissements_online)): ?>
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr class="bg-gray">
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Art.Budgetaire</th>
                                        <th>Client</th>
                                        <th>Montant</th>
                                        <th>Commissions</th>
                                        <th>Agences</th>
                                        <th><span class="fa fa-fw fa-folder f14"></span></th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                    $paiements = 0;
                                    $commissions = 0;
                                    $suspend = 0;
                                    $urgent = 0;
                                    $i = 0;
                                    foreach ($encaissements_online as $row) {
                                        $infos = json_decode($row->Notereference_30);
                                        ?>
                                        <tr>
                                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                                            <td <?php if ($row->Datevaleur_31 !== gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Datevaleur_31; ?></td>

                                            <td><b><?php echo $row->Typerecette_17; ?></b></td>
                                            <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                            <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Notemontant_28, 2, ",", " "); ?></td>

                                            <td class="text-blue"><?php echo $row->Devise_12 . ' ' . number_format($row->Commission_23, 2, ",", " "); ?></td>

                                            <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>

                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                                            </td>
                                        </tr>
                                        <?php
                                        $paiements = $paiements + $row->Contrevaleur_22;
                                        $commissions = $commissions + $row->Commission_23;
                                        if ($row->Status_2 == 1 && $row->Checkerid_10 == 0)
                                            $suspend = $suspend + 1;
                                        if ($row->Status_2 == 1 && $row->Checkerid_10 == 0 && $row->Datevaleur_31 !== gmdate('Y-m-d'))
                                            $urgent = $urgent + 1;
                                    }
                                    ?>

                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="col-md-12">
                                <section id="cat_list" class="text-center pt-5 pb-5">
                                    <span class="d-block"><span class="fa fa-flask text-gray mystyle4" ></span></span>
                                    <span class="d-block f13 text-black pb-2">Aucun paiement trouv&eacute;!</span>
                                </section>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php $chtml->box_body_closing(); ?>

    </div>

</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script type="text/javascript">

    function openTab(event, tabContentId) {
        $('.tab').removeClass('tab-active');
        $(".tab-item").addClass('d-none');

        event.currentTarget.classList.add('tab-active');
        $("#" + tabContentId + "").removeClass('d-none');
    }

    $("#searchform_agence").submit(function(e){
        e.preventDefault();
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxreports/display/filterresult_passports/agence'); ?>';
        var data = $(this).serialize();
        $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){
                            $('#message').html('');
                            $('#filterResult_agence').html(result);
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    });

    $("#searchform_online").submit(function(e){
        e.preventDefault();
        $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxreports/display/filterresult_passports/online'); ?>';
        var data = $(this).serialize();
        $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){
                            $('#message').html('');
                            $('#filterResult_online').html(result);
                    },
                    error:function(error){
                        alert('ERROR!' + error);
                    }
            });
    });


    function view(id, regie)
    {
            var url ='';
            var controller = 'reports';
            var from = '<?php echo $display; ?>';

            if(regie === 'DGRAD')
            {
                var url ="<?php echo base_url($module.'/taxpasseport/display/preview'); ?>/"  + id  ;
            }

            $("#message").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            $.get(url,{ controller : controller, from : from}, function(data, status){
                $("#message").html('');
                $("#pager").html(data);
            });
    }

    //Datepicker
    $('#datepicker1').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
    $('#datepicker4').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
</script>