<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div class="col-md-10 bRight">
    <div class="col-md-12">
        <?php $chtml->box_body_opening("", true); ?>
            <div class="statistic-box no-border">
                <div class="col-sm-8 col-xs-12">
                    <h1><i class="fa fa-book f35 text-green"></i>&nbsp;&nbsp;<span class="">R&eacute;f&eacute;rentiel des recettes</span></h1>
                    <h5 class="page-header">
                    </h5>
                </div>
                <div class="col-sm-2 col-xs-3">
                    <div class="description-block border-right">
                        <a  style="cursor: pointer" onclick="action('sites')" class="bg-default ">
                            <b><br/><br/><span id="total" class="description-percentage f30 blue"> </span></b>
                            <span class="description-text text-blue"></span>
                        </a>
                    </div><!-- /.description-block -->
                </div>
                <div class="col-sm-2 col-xs-3">
                    <div class="description-block">
                        <a  style="cursor: pointer" onclick="action('stores')" class="bg-default ">
                            <b><br/><br/><span id="deadline" class="description-percentage f30 orange"> </span></b>
                            <span class="description-text text-blue"></span>
                        </a>
                    </div><!-- /.description-block -->
                </div>
            </div>
        <?php $chtml->box_body_closing(); ?>
    </div>
    <div class="col-md-12">
        <div id="loader"></div>
    </div>
    <div class="col-md-12">
        <?php $chtml->box_body_opening('', true); ?>
            <?php if(!empty($recettes)): ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-blue">
                            <th width="10px">Code</th>
                            <th width="90px">B&eacute;n&eacute;ficiares</th>
                            <th>Recette</th>
                            <th width="10px">Type</th>
                            <th width="10px"><span class="fa fa-fw fa-edit f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach($recettes as $row){
                        ?>
                            <tr>
                                <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$row->Code_7.'</span>'; else echo ''.$row->Code_7.''; ?></span></td>
                                <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$row->Beneficiare_5.'</span>'; else echo ''.$row->Beneficiare_5.''; ?></span></td>
                                <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$row->Recette_6.'</span>'; else echo ''.$row->Recette_6.''; ?></span></td>
                                <td><?php if($row->Type_4=='TRESOR' || $row->Type_4=='RFTRESD') echo '<span class="text-blue">'.$types[$row->Type_4].'</span>'; else echo ''.$types[$row->Type_4].''; ?></span></td>
                                <td>
                                    <?php if($_SESSION['Logiref_role']==0){ ?>
                                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-orange fa-pencil f14"> </span></a>
                                    <?php }else {?>
                                    <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>    
                </table>
            <?php endif;?>
        <?php $chtml->box_body_closing(); ?> 	  
    </div>
</div>
<div class="col-md-2">
    <div class="col-md-12">
        <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
        <br/><br/>
    </div>
    <div class="col-md-12 bTop">
        <h4><br/></h4>
        <?php  ?>

        <?php ?>
        <br/><br/><br/>
    </div>
</div> 

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#add").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

$("#d-excel").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Fonctionnalit&eacute; pas encore disponible!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

$("#d-pdf").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Fonctionnalit&eacute; pas encore disponible!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});

$("#d-csv").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $("#loader").html('<div class="alert alert-warning text-white">Fonctionnalit&eacute; pas encore disponible!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});


function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
}
</script>
