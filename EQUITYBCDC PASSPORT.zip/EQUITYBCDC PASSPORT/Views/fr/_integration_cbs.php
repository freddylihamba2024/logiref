<?php 
$userid = $this->session->userdata["user_id"];
$usertype = $this->session->userdata["user_type"];
$paiements = 0;
$dgi = 0;
$dgda = 0;
$dgrad = 0;
?>

<div id="pager"  class="col-md-12"> 
        <div class="col-md-5">
                <h1>Paiements int&eacute;gr&eacute;s</h1>
               <p class="page-header">Cette section vous pr&eacute;sente les d&eacute;tails des paiements per&ccedil;us pour diff&eacute;rents b&eacute;n&eacute;ficiaires par rapport &agrave; une p&eacute;riode donn&eacute;e.</p>  
               <div id="loader"></div>
        </div>
       <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total paiements</span><br/><br/>
                            <p class="text-blue f16"> <b>CDF <span id="paiements"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span class="">Total DGI</span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgi"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGDA </span><br/><br/>
                            <p class="f14"><b>CDF <span id="dgda"></span></b></p>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="small-box bg-white">
                          <div class="inner">
                            <span>Total DGRAD</span><br/><br/>
                            <p class="f16"><b>CDF <span id="dgrad"></span></b></p>
                          </div>
                        </div>
                    </div>
                </div>
       </div>
        <div class="col-md-1" style="padding-left:1px;">
            <a id="Create" href="#"><span class="fa fa-fw fa-plus-circle <?php if($_SESSION['Logiref_role']!=3) echo 'text-gray';?> mystyle4"></span></a>
            <br/>
        </div>
</div>

<div class="col-md-12">
        <div class="col-md-12">
                <?php if(!empty($integrations)): ?>
                <?php $chtml->box_body_opening('', true); ?>
                <div id="paiementslist">
                    <table id="table" class="table table-hover table-striped">
                        <thead>
                            <tr class="bg-gray">
                                <th>#</th>
                                <th>Cr&eacute;&eacute; par</th>
                                <th class="center">Nombre de paiements</th>
                                <th>Montant</th>
                                <th>Date</th>
                                <th>Validation</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 

                        foreach($integrations as $row){
                        ?>
                            <tr>
                                <td ><b><?php echo ++$i; ?></b></td>
                                <td class=""><?= isset($users[$row->Makerid_5]) ? $users[$row->Makerid_5] : ""; ?></td>
                                <td class="center"><?php echo $row->Nombrepaiement_7; ?></td>
                                <td class="text-blue"><?php echo 'CDF '.number_format($row->Montant_8,2,","," "); ?></td>
                                <td><?php echo $row->Date_1 ?></td>
                                <td class="text-yellow"><?php echo $row->Isysvalidation_16." paiement(s) non valid&eacute;(s) sur ".$row->Nombrepaiement_7; ?></td>
                                <td class="text-center"><a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a></td>
                            </tr>
                        <?php 

                        } 
                        ?>
                        </tbody>    
                    </table>

                </div>
                <?php $chtml->box_body_closing(); ?>
        </div>
        <?php else: ?>
            <section id="cat_list">
                <h4 class="page-header" align="center"><b></b></h4>
                <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                    <span class="fa fa-warning text-gray mystyle4"></span>
                    <br/><br/>
                    Aucun paiement int&eacute;gr&eacute;
                    <br/><br/>
                </div>
            </section>
        <?php endif;?>
</div>


<script type="text/javascript">
    
    $(document).ready(function(){
        $.get("<?php echo base_url($module.'/bank/display/token_isys'); ?>", function(data, status){
        });
    });
    
    
    $('#paiements').html('<?php echo number_format($paiements,2,","," "); ?>');
    $('#dgi').html('<?php echo number_format($dgi,2,","," "); ?>');
    $('#dgrad').html('<?php echo number_format($dgrad,2,","," "); ?>');
    $('#dgda').html('<?php echo number_format($dgda,2,","," "); ?>');
    
    var print = "";
     $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        
        var url = '<?php echo base_url($module.'/bank/display/rapport_detailles'); ?>';
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(data){
                    $("#loader").html('');
                    $("#pager").html(data);
                    
                    print = 'details';
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    $("#Create").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $.get("<?php echo base_url($module.'/bank/display/new_integration'); ?>", function(data, status){
            $("#loader").html('');
            $("#container").html(data);
        });
    });
    
    function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      $.get("<?php echo base_url($module.'/bank/display/new_integration'); ?>/" + id, function(data, status){
        $("#loader").html('');
        $("#container").html(data);
      });
    }
    
    
</script>

