<div class="col-md-12">
    <div class="col-md-12"><div class="col-md-12"><h3>Sommaire: P&eacute;nalit&eacute;s vs Encaissements</h3></div></div>
    <div class="col-md-12">
        <div class="col-md-5">
            <?php $chtml->box_body_opening("", true); ?>
                <div class="statistic-box no-border text-blue">
                    <div class="col-sm-6 col-xs-6 no-padding">
                        <div class="description-block border-right">
                            <p class="f14"><span class="text-red"><b><?php  echo 'CDF '.number_format($penalties['Paiement_total'],2,","," "); ?></b></span></p>
                            <span class=" f13" >P&eacute;nalit&eacute;s en cours (<?php echo $penalties['Paiement'] ?> paiements)</span>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-6 col-xs-6">
                        <div class="description-block">
                            <p class="f14"><span class="text-orange"><b><?php echo 'CDF '.number_format($penalties['Total'],2,","," "); ?></b></p>
                            <span class=" f13" >Total de p&eacute;nalit&eacute;s</span>
                        </div><!-- /.description-block -->
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>
        <div class="col-md-7" style="padding-left:0px;">
            <?php $chtml->box_body_opening("", true); ?>
            <div class="statistic-box no-border text-orange">
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block border-right" >
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGI'],2,","," "); ?></b></span></p>
                            <span class="f12">P&eacute;nalit&eacute;s DGI</span>
                        </div>
                    </div>
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block border-right">
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGDA'],2,","," "); ?></b></span></p>
                            <span class="f12">P&eacute;nalit&eacute;s DGDA</span>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block">
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGRAD'],2,","," "); ?></b></span></p>
                            <span class="f12">P&eacute;nalit&eacute;s DGRAD</span>
                        </div><!-- /.description-block -->
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>

        <div class="col-md-12 no-padding">
                <div class="col-md-12 padding" id='alert'><?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?></div>

                <div class="col-md-12">
                    <?php $chtml->box_body_opening('', false); ?>
                        <div class="col-md-4">
                            <div class="statistic-box">
                                    <h4>Paiements en cours</h4>
                                    <ul class="list-group clear-list m-t">
                                        <?php
                                                $i = 0;
                                                foreach ($agences as $row) 
                                                {
                                        ?>
                                        <li class="list-group-item fist-item text-blue">
                                            <span class="pull-right">
                                                <span class="label label-default"><?php if(isset($data)) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," "); else echo 0;  ?></span>
                                            </span>
                                            <?php echo  ucfirst(strtolower($row->Nom_4)); ?>
                                        </li>
                                        <?php
                                                $i++;
                                                if($i==5)
                                                {
                                                    break;
                                                }
                                                }
                                        ?>
                                    </ul>
                            </div>
                        </div>
                        <div class="col-md-4 no-padding" style="margin-left:-40px;">
                                <div class="box-body margin padding">
                                      <canvas id="pieChart1"></canvas>
                                </div>
                                
                                <div style="margin-top:-20px; margin-left:130px;">
                                    <div><span class="label label-warning"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements annuels</span></div>
                                    <div><span class="label bg-green-gradient"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements mensuels</span></div>
                                    <div><span class="label label-info"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Paiements jounaliers</span></div>
                                </div><br/>
                                
                        </div>
                        <div class="col-md-4 no-padding">
                            <div class="bLeft">
                                <div class="box-body margin padding">
                                      <canvas id="pieChart"></canvas>
                                </div>
                            </div>
                            
                            <div style="margin-top:-20px; margin-left:130px;">
                                <div><span class="label bg-green"><?php echo " "; ?></span> <span class="f12 text-gray">&nbsp;Commissions annuelles</span></div>
                                <div><span class="label bg-aqua-active"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Commissions mensuelles</span></div>
                                <div><span class="label bg-blue"><?php echo " "; ?></span> <span class="f12" style="color:#605e5e;">&nbsp;Commissions jounali&egrave;res</span></div>
                            </div><br/>
                        </div>

                    <?php $chtml->box_body_closing(); ?>
                </div>
        </div>
        <div class="col-md-12">
            <?php if(!empty($agences)): ?>
            <?php $chtml->box_body_opening('', false); ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th>#</th>
                            <th>Agences BCC</th>
                            <th class="center">Paiements</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th>Penalit&eacute;s</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    foreach($agences as $row){
                    ?>
                        <tr>
                            <td width="20"><?php echo ++$i; ?></td>
                            <td class="text-blue" width="200"><?php echo  ucfirst(strtolower($row->Nom_4)); ?></td>
                            <td class="center"><?php if(isset($data)) echo $data[$row->Id_0]['nombre']; else echo 0;?></td> 
                            <td width="200"><?php if(isset($data)) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," "); else echo 0; ?>
                            <td class="text-green" width="200"><?php if(isset($data)) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
                            <td width="200"><?php if(isset($penalties['Agence'][$row->Id_0])) echo 'CDF '.number_format($penalties['Agence'][$row->Id_0],2,","," "); else echo 'CDF '.number_format("0",2,","," "); ?></</td>
                        </tr>
                    <?php 
                          
                    } 
                    ?>
                    </tbody>    
                </table>
            <?php $chtml->box_body_closing(); ?>
            <?php else: ?>
                <section id="cat_list">
                    <h4 class="page-header" align="center"><b></b></h4>
                    <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                        <span class="fa fa-warning text-gray mystyle4"></span>
                        <br/><br/>
                        Aucune information suppl&eacute;mentaire trouv&eacute;e
                        <br/><br/>
                    </div>
                </section>
            <?php endif;?>
        </div>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v2/plugins/chartjs/Chart.min.js'); ?>" type="text/javascript"></script>
<link href="<?php echo base_url('ikwook_bootstraps/v4'); ?>/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">

<script type="text/javascript">
//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_commission)) echo $pie_commission; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-


//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart1").get(0).getContext("2d");
    //alert('Ok');
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_paiement)) echo $pie_paiement; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-

</script>

