<div class="col-md-10">
    <h1>
        Les P&eacute;nalit&eacute;s
    </h1>
    <h5 class="page-header">
        Cette section vous pr&eacute;sente les diff&eacute;rentes penalit&eacute;s &agrave; payer.
    </h5>
</div>

<div class="col-md-12">
    <?php if(!empty($penalties)): ?>
    <?php $chtml->box_body_opening('', false); ?>
        <table id="table" class="table table-hover table-striped">
            <thead>
                <tr class="bg-gray">
                    <th>#</th>
                    <th>Date</th>
                    <th class="text-center">R&eacute;f&eacute;rence paiement</th>
                    <th class="text-center">P&eacute;nalit&eacute;</th>
                    <th class="text-center">Direction</th>
                    <th class="text-center">Guichet</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach($penalties as $row){
            ?>
                <tr>
                    <td ><?php echo ++$i; ?></td>
                    <td width="250"><?php echo  $row->Date_1; ?></td>
                    <td class="text-center" ><?php echo  $row->Paiement_4;?></td> 
                    <td class="text-center"><?php echo  $row->Penalite_6;?>
                    <td class="text-center"><?php echo  $row->Beneficiare_5;?></td>
                    <td class="text-center"><?php echo  $guichets[$row->Guichet_7]; ?></</td>
                </tr>
            <?php 

            } 
            ?>
            </tbody>    
        </table>
    <?php $chtml->box_body_closing(); ?>
    <?php else: ?>
        <section id="cat_list">
            <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                <br/>
                <span class="fa fa-warning text-gray mystyle4"></span>
                <br/><br/>
                Aucune penalit&eacute; trouv&eacute;e
                <br/><br/>
            </div>
        </section>
    <?php endif;?>
</div>

