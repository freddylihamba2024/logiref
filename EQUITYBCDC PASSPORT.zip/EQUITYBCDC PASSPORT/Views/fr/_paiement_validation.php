<?php echo form_open_multipart('', array('id' => 'form', 'class' => '')); ?>
<?php $chtml->box_body_opening('', true);?>
<div class="box-body">
    
    <table id="" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th width="20%">R&eacute;gies</th>
                <th width="20%">D&eacute;vise</th>
                <th width="20%">Montant</th>
                <th width="30%">Message validation</th>
                <th width="10%">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td width="20%">DGI</td>
                <td width="20%">CDF</td>
                <td width="20%"><?php echo number_format($datas['pay_dgi_cdf'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgi_cdf']; ?>' name="dgi_cdf" id="val1" />
                
                <?php foreach($datas['id_dgi_cdf'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key1" disabled="disabled" />
                <?php
                }
                ?>
                
                <input type='hidden' value='DGI' id="regie1" />
                <input type='hidden' value='CDF' id="devise1" />
                <td width="30%" class="<?php if($datas['dgi_cdf_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                          if($datas['dgi_cdf_paiement']==0 && $datas['dgi_cdf_number']==0)
                          { 
                        
                                echo "Aucun paiement &agrave; valider pour cette devise. ";
                        
                          }
                          elseif($datas['dgi_cdf_paiement']==0) 
                          {
                                echo "".$datas['dgi_cdf_number']." paiements non valid&eacute;s ";
                          }
                          else
                          {
                                echo "".$datas['dgi_cdf_paiement']." paiements valid&eacute;s sur ".$datas['dgi_cdf_paiement']." envoy&eacute;s";
                          }
                    ?>
                </td>
                <td width="10%"><a id="dgi_cdf" class="btn btn-success btn-xs reverser" href="#" data-btnid="1" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
            <tr>
                <td width="20%">DGI</td>
                <td width="20%">USD</td>
                <td width="20%"><?php echo number_format($datas['pay_dgi_usd'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgi_usd']; ?>' name="dgi_usd" id="val2" />
                
                <?php foreach($datas['id_dgi_usd'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key2" disabled="disabled"/>
                <?php
                }
                ?>
                
                <input type='hidden' value='DGI' id="regie2" />
                <input type='hidden' value='USD' id="devise2" />
                <td width="30%" class="<?php if($datas['dgi_usd_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                          if($datas['dgi_cdf_paiement']==0 && $datas['dgi_usd_number']==0)
                          { 
                        
                                echo "Aucun paiement &agrave; valider pour cette devise.";
                        
                          }
                          elseif($datas['dgi_cdf_paiement']==0)
                          { 
                        
                                echo "".$datas['dgi_usd_number']." paiements non valid&eacute;s ";
                        
                          }
                          else
                          {
                                echo "".$datas['dgi_usd_paiement']." paiements valid&eacute;s sur ".$datas['dgi_usd_paiement']." envoy&eacute;s";
                          }
                    ?>
                </td>
                <td width="10%"><a id="dgi_usd" class="btn btn-success btn-xs reverser" href="#" data-btnid="2" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
            <tr>
                <td width="20%">DGDA</td>
                <td width="20%">CDF</td>
                <td width="20%"><?php echo number_format($datas['pay_dgda_cdf'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgda_cdf']; ?>' name="dgda_cdf" id="val3" />
                
                <?php foreach($datas['id_dgda_cdf'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key3" disabled="disabled" />
                <?php
                }
                ?>
                
                <input type='hidden' value='DGDA' id="regie3" />
                <input type='hidden' value='CDF' id="devise3" />
                <td width="30%" class="<?php if($datas['dgda_cdf_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                        if($datas['dgda_cdf_paiement']==0 && $datas['dgda_cdf_number']==0)
                        { 

                              echo "Aucun paiement &agrave; valider pour cette devise. ";

                        }
                        elseif($datas['dgda_cdf_paiement']==0)
                        { 

                              echo "".$datas['dgda_cdf_number']." paiements non valid&eacute;s ";

                        }
                        else
                        {
                              echo "".$datas['dgda_cdf_paiement']." paiements valid&eacute;s sur ".$datas['dgda_cdf_paiement']." envoy&eacute;s";
                        }
                    ?>
                </td>
                <td width="10%"><a id="dgda_cdf" class="btn btn-success btn-xs reverser" href="#" data-btnid="3" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
            <tr>
                <td width="20%">DGDA</td>
                <td width="20%">USD</td>
                <td width="20%"><?php echo number_format($datas['pay_dgda_usd'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgda_usd']; ?>' name="dgda_usd" id="val4" />
                
                <?php foreach($datas['id_dgda_usd'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key4" disabled="disabled" />
                <?php
                }
                ?>
                
                <input type='hidden' value='DGDA' id="regie4" />
                <input type='hidden' value='USD' id="devise4" />
                <td width="30%" class="<?php if($datas['dgda_usd_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                          if($datas['dgda_usd_paiement']==0 && $datas['dgi_usd_number']==0)
                          { 
                        
                                echo "Aucun paiement &agrave; valider pour cette devise. ";
                        
                          }
                          elseif($datas['dgda_usd_paiement']==0)
                          { 
                        
                                echo "".$datas['dgi_usd_number']." paiements non valid&eacute;s ";
                        
                          }
                          else
                          {
                                echo "".$datas['dgi_usd_paiement']." paiements valid&eacute;s sur ".$datas['dgi_usd_paiement']." envoy&eacute;s";
                          }
                    ?>
                </td>
                <td width="10%"><a id="dgda_usd" class="btn btn-success btn-xs reverser" href="#" data-btnid="4" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
            <tr>
                <td width="20%">DGRAD</td>
                <td width="20%">CDF</td>
                <td width="20%"><?php echo number_format($datas['pay_dgrad_cdf'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgrad_cdf']; ?>' name="dgrad_cdf" id="val5" />
                
                <?php foreach($datas['id_dgrad_cdf'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key5" disabled="disabled" />
                <?php
                }
                ?>
                
                <input type='hidden' value='DGRAD' id="regie5" />
                <input type='hidden' value='CDF' id="devise5" />
                <td width="30%" class="<?php if($datas['dgrad_cdf_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                          if($datas['dgrad_cdf_paiement']==0 && $datas['dgrad_cdf_number']==0)
                          { 
                        
                                echo "Aucun paiement &agrave; valider pour cette devise. ";
                        
                          }
                          elseif($datas['dgrad_cdf_paiement']==0)
                          { 
                        
                                echo "".$datas['dgrad_cdf_number']." paiements non valid&eacute;s ";
                            
                          }
                          else
                          {
                                echo "".$datas['dgrad_cdf_paiement']." paiements valid&eacute;s sur ".$datas['dgrad_cdf_number']." envoy&eacute;s";
                          }
                    ?>
                </td>
                <td width="10%"><a id="dgrad_cdf" class="btn btn-success btn-xs reverser" href="#" data-btnid="5" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
            <tr>
                <td width="20%">DGRAD</td>
                <td width="20%">USD</td>
                <td width="20%"><?php echo number_format($datas['pay_dgrad_usd'],2,","," "); ?></td>
                <input type='hidden' value='<?php echo $datas['pay_dgrad_usd']; ?>' name="dgrad_usd" id="val6" />
                
                <?php foreach($datas['id_dgrad_usd'] as $line){
                ?>
                <input type='hidden' value='<?php echo $line; ?>' name="ids[]" class="key6" disabled="disabled" />
                <?php
                }
                ?>
                
                <input type='hidden' value='DGRAD' id="regie6" />
                <input type='hidden' value='USD' id="devise6" />
                <td width="30%" class="<?php if($datas['dgrad_usd_number'] !=0){ echo "text-yellow"; } ?>">
                    <?php 
                          if($datas['dgrad_usd_paiement']==0 && $datas['dgrad_usd_number']==0)
                          { 
                        
                                echo "Aucun paiement &agrave; valider pour cette devise. ";
                        
                          }
                          elseif($datas['dgrad_usd_paiement']==0)
                          { 
                        
                                echo "".$datas['dgrad_usd_number']." paiements non valid&eacute;s ";
                        
                          }
                          else
                          {
                                echo "".$datas['dgrad_usd_paiement']." paiements valid&eacute;s sur ".$datas['dgrad_usd_paiement']." envoy&eacute;s";
                          }
                    ?>
                </td>
                <td width="10%"><a id="dgrad_usd" class="btn btn-success btn-xs reverser" href="#" data-btnid="6" <?php if($_SESSION['Logiref_role']== 5) echo "disabled=disabled" ?> class="text-green"> Valider </a></td>
            </tr>
        </tbody>    
    </table>
    <input type='hidden' value='' name="amount" id="amount" />
    <input type='hidden' value='<?= isset($integration_id) ? $integration_id : "" ?>' name="integration_id" id="integration_id" />
    <input type='hidden' value='' name="btnid" id="btnid" />
</div>
<div id="footpage" class="box-footer clearfix">
    <div class="col-md-12 no-padding">
        <button type="submit" name="submit" disabled="disabled" class="btn btn-primary" id="btn_confirm">&nbsp;&nbsp;<i class="fa fa-save"></i>&nbsp; Confirmer&nbsp;&nbsp;</button>&nbsp;&nbsp;
    </div>
</div>
<?php echo form_close(); ?>
<?php $chtml->box_body_closing(); ?>

<script>
    
    var devise='';
    var regie='';

    $(".reverser").on("click",function(){
        var target = $(this).data("btnid");
        var amount = $('#val'+target).val();
        
        var btnid = $('#btnid').val();
        
        if(btnid !="" && btnid != target)
        {
            $("#integration_id").val('');
        }
        
        devise = $('#devise'+target).val();
        regie = $('#regie'+target).val();
        
        $("#amount").val(amount);
        $("#btnid").val(target);
        $(".key"+target).prop("disabled", '');
        $(".reverser").not(this).attr("disabled",true);
        $("#btn_confirm").prop("disabled",false);
        $("#btn_confirm").removeClass("btn-primary");
        $("#btn_confirm").addClass("btn-success");
        
    });
    
    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        
        var url = '<?php echo base_url($module.'/bank'); ?>/display/paiement_validation/validate/'+regie+'/'+devise;
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        
        
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode          : true,
                success: function(result){
                    
                    $('#message').html('');
                    $('#message').html(result.message);
                    
                    
                    var url = '<?php echo base_url($module.'/bank/display/paiement_validation'); ?>';
                    $.get(url, function(data, status){
                        
                        $("#bloc-2").html(data);
                        $("#integration_id").val(result.data);
                        $("#btnid").val(result.btnid);
                    });
                    
                    
                },
                error: function (error){
                    alert('ERROR!' + error);
                }
        });
    });
    
    
    
</script>