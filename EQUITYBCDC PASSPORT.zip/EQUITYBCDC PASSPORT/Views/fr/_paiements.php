<?php if(!empty($encaissements)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th></th>
                <th>Date</th>
                <th>Client</th>
                <th>Beneficiare</th>
                <th>Recette</th>
                <th>Montant</th>
                <th>Contre-valeur</th>
                <th>Commissions</th>
                <th>Guichet</th>
                <th><span class="fa fa-fw fa-folder f14"></span></th>
                <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
            </tr>
        </thead>
        <tbody>
        <?php 
        $paiements = 0;
        $commissions = 0;
        $suspend = 0;
        $urgent = 0;
        foreach($encaissements as $row){
            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
        ?>
            <tr>
                <td width="5"><b><?php echo ++$i; ?></b></span></td>
                <td width="50" <?php if($row->Status_2==2) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                    <?php echo $row->Date_1; ?>
                </td>
                <td class="text-blue"><?php echo $row->Designation_14; ?><br/><span class="text-gray"><?php echo $row->Nif_13; ?></span></td>
                <td width="150"><b><?php echo $beneficiaires[$row->Service_16]; ?></b></td>
                <td><?php echo $row->Typerecette_17; ?></td>
                <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?></td>
                <td class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></td>
                <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                <td><?php echo '<span  class="text-blue">'.$guichet.'<br/><span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                <?php if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                    <td width="25">
                        <?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2 && $row->Agence_20==$_SESSION['Logiref_agence']){ ?>
                           <input type="checkbox" class="text-blue" value="<?php echo $row->Id_0; ?>" name="paiements[]" />
                        <?php }else if($_SESSION['Logiref_role']==4 && $row->Makerid_9==$this->session->userdata['user_id']){ ?>
                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-edit f14"> </span></a>
                        <?php }else { ?>
                           <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder f14"> </span></a>
                        <?php } ?>
                    </td>
                    <td width="25">
                        <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                    </td>
                <?php }else{ ?>
                <td width="25">
                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                </td>
                <td width="25">
                    <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                </td>
                <?php } ?>
            </tr>
        <?php 
              $paiements = $paiements + $row->Contrevaleur_22;
              $commissions = $commissions + $row->Commission_23;
              if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
              if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
        } 
        ?>
        </tbody>    
    </table>
<?php else:?>
    <section id="cat_list">
        <div class="row fontawesome-icon-list min-height-20pct f14 tCenter" style="padding-top: 20px;">
            <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
            Aucun paiement trouv&eacute;!<br/>
        </div>
    </section>
<?php endif;?>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
    
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
});


</script>