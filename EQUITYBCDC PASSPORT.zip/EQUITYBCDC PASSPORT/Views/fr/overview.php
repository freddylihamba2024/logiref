<div class="col-md-12">
    <div class="col-md-9">
        <div class="col-md-5">
            <?php $chtml->box_body_opening("", true); ?>
                <div class="statistic-box no-border">
                    <div class="col-sm-6 col-xs-6 no-padding">
                        <div class="description-block border-right">
                            <p class="f14"><span style="color:#666"><b><?php  echo 'CDF '.number_format($penalties['Paiement_total'],2,","," "); ?></b></span></p>
                            <span class=" f13" >P&eacute;nalit&eacute;s(<?php echo $penalties['Paiement'] ?> paiements)</span>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-6 col-xs-6">
                        <div class="description-block">
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['Total'],2,","," "); ?></b></span></p>
                            <span class=" f13" >Total p&eacute;nalit&eacute;</span>
                        </div><!-- /.description-block -->
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>
        <div class="col-md-7" style="padding-left:0px;">
            <?php $chtml->box_body_opening("", true); ?>
            <div class="statistic-box no-border" style="min-height:69.5px;">
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block border-right" >
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGI'],2,","," "); ?></b></span></p>
                            <span class="f12">Total DGI</span>
                        </div>
                    </div>
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block border-right">
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGDA'],2,","," "); ?></b></span></p>
                            <span class="f12">Total DGDA</span>
                        </div><!-- /.description-block -->
                    </div>
                    <div class="col-sm-4 col-xs-4">
                        <div class="description-block">
                            <p class="f14"><span style="color:#666"><b><?php echo 'CDF '.number_format($penalties['DGRAD'],2,","," "); ?></b></span></p>
                            <span class="f12">Total DGRAD</span>
                        </div><!-- /.description-block -->
                    </div>
                </div>
            <?php $chtml->box_body_closing(); ?>
        </div>

        <div class="col-md-12 no-padding">
                <div class="col-md-12 padding" id='alert'><?php if(isset($alert1)) echo $alert1.''; ?><?php if(isset($alert2)) echo $alert2; ?></div>

                <div class="col-md-12">
                    <?php $chtml->box_body_opening('', false); ?>
                        <div class="col-md-4">
                            <div class="statistic-box">
                                    <h4>Paiements en cours</h4>
                                    <ul class="list-group clear-list m-t">
                                        <?php
                                                $i=0;
                                                foreach ($guichets as $row) 
                                                {
                                        ?>
                                        <li class="list-group-item fist-item">
                                            <span class="pull-right">
                                                <span class="label label-default"><?php if(isset($data)) echo number_format($data[$row->Id_0]['paiement'],2,","," ").' CDF'; else echo 0;  ?></span>
                                            </span>
                                            <?php echo  ucfirst(strtolower($row->Nom_4)); ?>
                                        </li>
                                        <?php
                                                    $i++;
                                                    if($i==5)
                                                    {
                                                        break;
                                                    }
                                                
                                                }
                                        ?>
                                    </ul>
                            </div>
                        </div>
                        <div class="col-md-4 no-padding" >
                                <div class="box-body margin padding">
                                    <canvas id="pieChart1"></canvas>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="col-md-1 no padding"></div>
                                    <div class="col-md-10">
                                        <div><span class="label label-warning"><?php echo " "; ?></span> <span class="f12" >&nbsp;Paiements Annuels</span></div>
                                        <div><span class="label bg-green-gradient" style="background-color: #7fffd4;"><?php echo " "; ?></span> <span class="f12">&nbsp;Paiements Mensuels</span></div>
                                        <div><span class="label label-info"><?php echo " "; ?></span> <span class="f12" >&nbsp;Paiements jounaliers</span></div>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div><br/>
                                
                        </div>
                        <div class="col-md-4 no-padding">
                            <div class="bLeft">
                                <div class="box-body margin padding">
                                    <canvas id="pieChart"></canvas>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                
                                <div class="col-md-12 no-padding">
                                    <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="label bg-green"><?php echo " "; ?></span> <span class="f12">&nbsp;Commissions Annuelles</span></div>
                                    <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="label bg-aqua-active"><?php echo " "; ?></span> <span class="f12">&nbsp;Commissions Mensuelles</span></div>
                                    <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="label bg-blue"><?php echo " "; ?></span> <span class="f12">&nbsp;Commissions jounali&egrave;res</span></div>
                                    <br/>
                                </div>
                                
                                
                            </div>
                        </div>
                    <?php $chtml->box_body_closing(); ?>
                </div>
        </div>
        <div class="col-md-12">
            
            <?php $chtml->box_body_opening('', false); ?>
                <?php if(!empty($data)): ?>
                <table id="table" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th>#</th>
                            <th>Guichet</th>
                            <th class="text-center">Paiements</th>
                            <th >Montant</th>
                            <th>Commissions</th>
                            <th>Penalit&eacute;s</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $i = 0;
                    foreach($guichets as $row){
                    ?>
                        <tr>
                            <td width="20"><b><?php echo ++$i; ?></b></span></td>
                            <td width="200"><?php echo $row->Nom_4; ?></td>
                            <td class="text-center" ><?php if(isset($data)) echo $data[$row->Id_0]['nombre']; else echo 0;?></td> 
                            <td width="200"><?php if(isset($data)) echo 'CDF '.number_format($data[$row->Id_0]['paiement'],2,","," ");  else echo 0; ?>
                            <td width="200"><?php if(isset($data)) echo 'CDF '.number_format($data[$row->Id_0]['commission'],2,","," "); else echo 0;?></td>
                            <td width="200"><?php if(isset($penalties['Guichet'][$row->Id_0])) echo 'CDF '.number_format($penalties['Guichet'][$row->Id_0],2,","," "); else echo 'CDF '.number_format("0",2,","," "); ?></</td>
                        </tr>
                    <?php 
                          
                    } 
                    ?>
                    </tbody>    
                </table>
                <?php else: ?>
                    <section id="cat_list">
                        <h4 class="page-header" align="center"><b></b></h4>
                        <div class="row fontawesome-icon-list pTop50 f14 tCenter">
                            <span class="fa fa-warning text-gray mystyle4"></span>
                            <br/><br/>
                            Aucune information suppl&eacute;mentaire trouv&eacute;e
                            <br/><br/>
                        </div>
                    </section>
                <?php endif;?>
            <?php $chtml->box_body_closing(); ?>
            
        </div>
    </div>
    <div class="col-md-3 bLeft" style='min-height:600px'>
            <div class="col-md-12" style='min-height:300px'>
                <h4>Alertes <i class="text-gray glyphicon glyphicon-bell f14"></i><br/></h4>
                <?php if(!empty($members)){ ?>
                    
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune alerte trouv&eacute;e !<br/><br/></span>
                <?php } ?>
            </div>
            <div class="col-md-12 bTop" style="display: block;">
                <h4>Insights<br/></h4>
                <?php if(!empty($members)){ ?>
                    
                <?php }else { ?>
                    <span class='f16 text-gray'>Aucune donn&eacute;e trouv&eacute;e !<br/><br/></span>
                <?php } ?>
            </div>
        </div> 
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v2/plugins/chartjs/Chart.min.js'); ?>" type="text/javascript"></script>
<link href="<?php echo base_url('ikwook_bootstraps/v4'); ?>/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">

<script type="text/javascript">
//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
    //alert('Ok');
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_commission)) echo $pie_commission; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-


//-------------
//- PIE CHART -
//-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart1").get(0).getContext("2d");
    //alert('Ok');
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [
      <?php if(isset($pie_paiement)) echo $pie_paiement; ?>                  
    ];
    var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 1,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: false,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
          //String - A tooltip template
          tooltipTemplate: "<%=value %> <%=label%> "
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.  
    pieChart.Doughnut(PieData, pieOptions);
//-----------------
//- END PIE CHART -
//-

</script>