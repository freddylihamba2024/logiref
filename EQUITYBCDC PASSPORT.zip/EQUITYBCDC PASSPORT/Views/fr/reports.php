<div class="col-md-12">
<?php $chtml->box_body_opening("", true);?>
     <?php echo form_open('', array('id' => 'searchform', 'class' => '')); ?>
        <div class="col-md-12">
            <h1>
                Rapports des paiements
            </h1>
            <h5 class="page-header">Cette section vous pr&eacute;sente les rapports des paiements.</h5>
        </div>
        <div class="col-md-3">
            <div class="col-md-11">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <label for="agence">Agence</label><br/>
                    <?php echo form_dropdown('agence', $agences, '', ' id="agences" class="form-control" required="required"'); ?>
                    <br/>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <label for="guichet">Guichet</label><br/>
                    <span id="slist"><?php echo form_dropdown('guichet', $guichets, '', ' id="guichet" class="form-control" '); ?></span>
                    <br/>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <label for="beneficiaire">B&eacute;n&eacute;ficiaire</label><br/>
                    <span id="slist"><?php echo form_dropdown('beneficiaire', $beneficiaires, '', ' id="guichet" class="form-control" '); ?></span>
                    <br/>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <label for="Du">Date du</label><br/>
                    <div class="input-group">
                        <?php echo form_input('Du', set_value('Du', ''), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <label for="Au">Au</label><br/>
                    <div class="input-group">
                        <?php echo form_input('Au', set_value('Au', ''), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <br/><br/>
                    <button type="submit" class="btn btn-success pull-left"><i class="fa fa-filter"></i>&nbsp;&nbsp;Filtrer&nbsp;&nbsp;</button>&nbsp;&nbsp;&nbsp;
                    <br/><br/>
                </div>
            </div>
        </div>
    
        <div class="col-md-9 bLeft">
        <?php if(!empty($encaissements)): ?>
            <div id="filterResult" class="table-responsive">
                <table id="tableR" class="table table-hover table-striped">
                    <thead>
                        <tr class="bg-gray">
                            <th></th>
                            <th>Date</th>
                            <th>R&eacute;gies</th>
                            <th>Service</th>
                            <th>Client</th>
                            <th>Montant</th>
                            <th>Contre-valeur</th>
                            <th>Commissions</th>
                            <th>Guichets</th>
                            <th><span class="fa fa-fw fa-folder f14"></span></th>
                        </tr>
                    </thead>
                    <tbody >
                    <?php 
                    $paiements = 0;
                    $commissions = 0;
                    $suspend = 0;
                    $urgent = 0;
                    foreach($encaissements as $row){
                    ?>
                        <tr>
                            <td width="5"><b><?php echo ++$i; ?></b></span></td>
                            <td <?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
                            <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                            <td><?php echo $services[$row->Service_16]; ?></td>
                            <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                            <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?></td>
                            <td class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></td>
                            <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                            <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
                            <?php if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                            <td width="20">
                                <?php if($_SESSION['Logiref_role']==3 && $row->Agence_20==$_SESSION['Logiref_agence']){
                                echo '<span  class="text-red"> En attente </span>';
                                ?>
                                <?php }else { ?>
                                   <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder f14"> </span></a>
                                <?php } ?>
                            </td>
                            <?php }else{ ?>
                            <td width="25">
                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                            </td>
                            <?php } ?>
                        </tr>
                    <?php 
                        $paiements = $paiements + $row->Contrevaleur_22;
                        $commissions = $commissions + $row->Commission_23;
                        if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                        if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
                    } 
                    ?>
                    </tbody>
                </table>
            </div>
        <?php else:?>
            <section>
                <div id="content" class="row fontawesome-icon-list  f14 tCenter" style="min-height: 50vh; padding-top: 20%;">
                    <i class="fa fa-fw fa-cubes text-gray mystyle4"></i><br/>
                    <span class="text-gray"> Cliquez sur un stock pour afficher les d&eacute;tails</span>
                </div>
            </section>
        <?php endif;?>
        </div>
<?php echo form_close(); ?>
<?php $chtml->box_body_closing(); ?>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
        $('.table').DataTable({
            pageLength: 10,
            responsive: true,
            "bLengthChange": false,
            "bFilter": false,
            "bLengthChange": false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'Rapport des paiements'},
                {extend: 'pdf', title: 'Rapport des paiements', orientation: 'landscape', pageSize : 'LEGAL'},
                {extend: 'print',
                 customize: function (win){
                        
                }
                }
            ]

        });
});

$("#searchform").submit(function(e){
    e.preventDefault();
    $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/bank/display/filterresult'); ?>';
    var data = $(this).serialize(); 
    $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        $('#filterResult').html(result);
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});
$("#agences").change(function(){
    
        $("#guichet").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        //$("#Standard01").type='text';
        var agence = $('#agences option:selected').val();
      
    
        var url = '<?php echo base_url($module.'/settings'); ?>/display/dropdowns/' + agence+ '/guichets';
        $.get(url, function(data, status){
                if(data!="")
                {
                    $("#guichet").html(data);
                }
        });
});

function view(id){
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/bank/display/encaissement'); ?>/' + id;
    $.get(url, {object:'reports'}, function(data, status){
        $("#loader").html('');
        $("#container").html(data);
    });
}

function print_payment(pid)
{
        var url = '<?php echo base_url($module.'/bank/data/printattestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
}


//Datepicker
$('#datepicker1').datepicker({
    todayHighlight: true,
    format: 'dd-mm-yyyy'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'dd-mm-yyyy'
});

</script>
