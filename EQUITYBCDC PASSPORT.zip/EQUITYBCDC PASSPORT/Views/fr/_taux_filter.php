<?php if(!empty($taux)): ?>
<?php $chtml->box_body_opening('', true); ?>
    <table id="<?php echo(count($taux) > 10)? "table" :"";?>" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th>#</th>
                <th>Date</th>
                <th>Agence</th>
                <th>Dollar</th>
                <th>Euro</th>
                <th>Pound</th>
                <th>Rand</th>
                <th>Validation</th>
                <th>Publi&eacute; par</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        foreach($taux as $row){
        ?>
            <tr>
                <td width="5"><?php echo $row->Id_0; ?></td>
                <td width="150"><?php echo $row->Date_1; ?></td>
                <td>
                    <?php if($row->Status_2==1) echo '<b>'. ucfirst(strtolower($agences[$row->Agence_8])).'</b>'; else echo '<span class="text-red">'.ucfirst(strtolower($agences[$row->Agence_8])).'</span>'; ?>
                </td>
                <td width="110"><?php echo 'CDF '.number_format($row->Dollar_4,2,","," "); ?></td>
                <td width="110"><?php echo 'CDF '.number_format($row->Euro_5,2,","," "); ?></td>
                <td width="110"><?php echo 'CDF '.number_format($row->Pound_7,2,","," "); ?></td>
                <td width="110"><?php echo 'CDF '.number_format($row->Rand_6,2,","," "); ?></td>
                <td class="text-blue">
                    <?php 
                    if (isset($users[$row->Checkerid_11])) echo $users[$row->Checkerid_11]; 
                    elseif ($row->Agence_8==$_SESSION['Logiref_agence'] && $row->Checkerid_11==0 && $_SESSION['Logiref_role']==3) echo '<a id="Validate" class="btn btn-warning" href="#" class="text-green"> Confirmer </a>';
                    else echo '<span  class="text-red"> En attente </span>'; 
                    ?>
                </td>
                <td class="text-green">
                    <?php 
                        echo $users[$row->Makerid_10]; 
                    ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>    
    </table>

<?php $chtml->box_body_closing(); ?>
<?php else: ?>
    <section id="cat_list">
        <h4 class="page-header" align="center"><b></b></h4>
        <div class="row fontawesome-icon-list pTop50 f14 tCenter">
            <span class="fa fa-warning text-gray mystyle4"></span>
            <br/><br/>
            Aucun taux enregistr&eacute; pour ce mois en cours !
            <br/><br/>
        </div>
    </section>
<?php endif;?>

