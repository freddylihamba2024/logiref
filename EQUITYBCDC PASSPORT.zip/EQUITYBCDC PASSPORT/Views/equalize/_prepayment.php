<?php 
$total = 0; 
$infos = $encaissement->Notereference_30;
$mode = $encaissement->Mode_19; 
$CFBdevise = $encaissement->Devise_24;
$pDevise = 'CDF';
$cDevise = $encaissement->Devise_34;
$cCompte = $encaissement->CGU;
$taux = $encaissement->Taux_41;
$commission = $encaissement->Commission_23;
$montant = number_format($encaissement->Montant_11,2,","," ");
?>

<?php $Infos = $encaissement->Notereference_30; $idBL = $Infos['Paiementid'];?>
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; $disabled = "disabled";}else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php 
        $Standard01=''; 
        $total = 0; 
        isset($Infos['taxesPaid']) ? $taxes = serialize($Infos['taxesPaid']) : $taxes = "";
        $taxes = str_replace("'", " ", $taxes);
?>
<?php if(isset($encaissement->Notereference_30) && $encaissement->Notereference_30 !="")$infos= $encaissement->Notereference_30;?>
<?php

if($encaissement->Id_0!=NULL) 
{
        if($encaissement->Mode_19 == 5)
        {
                $label01 = 'Commission';
                $valeur01 = $encaissement->Commission_23;
                $devise01 = $encaissement->Devise_24;
        }
        else
        {
                $label01 = 'Compte &agrave; d&eacute;biter';
                $valeur01 = $encaissement->Compte_33;
                $devise01 = $encaissement->Devise_34;
        }
}
else 
{
        $label01 = '--------';
        $valeur01 = '';
        $devise01 = '';
}
?>
<?php
    if ($_SESSION['userdata']['account_id'] == 45):
        $parts_account = explode('-', $encaissement->CGU);
        $branch_code = $parts_account[0] ?? "";
    endif;
?>
<div class=""></div>
<div  class="col-md-12">
    <div id="message"></div>
    <?php $chtml->box_body_opening('', true);?>
        <?php echo form_open('', array('id' => 'confirmform', 'class' => '')); ?>
            <div class="box-body">
                <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
                <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
                <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
                
                <input type="hidden" name="Makerid_9" value="<?php echo $encaissement->Makerid_9 ; ?>" />
                <input type="hidden" name="Checkerid_10" value="<?php echo $userid; ?>" />
                <input type="hidden" name="Montant_11" value="<?php echo $encaissement->Montant_11 ; ?>" />
                <input type="hidden" name="Devise_12" value="<?php echo $encaissement->Devise_12; ?>" />
                <input type="hidden" name="Nif_13" value="<?php echo $encaissement->Nif_13 ; ?>" />
                <input type="hidden" name="Designation_14" value="<?php echo $encaissement->Designation_14; ?>" />
                <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>"  id="regies" />
                <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>"  id="service" />
                <input type="hidden" name="Typerecette_17" value="<?php echo $encaissement->Typerecette_17;?>"   id="recette" />
                <input type="hidden" name="Mode_19" value="<?php echo $encaissement->Mode_19; ?>" />
                <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
                <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
                <input type="hidden" name="Contrevaleur_22" value="<?php echo $encaissement->Contrevaleur_22 ; ?>" />
                <input type="hidden" name="Commission_23" value="<?php echo $encaissement->Commission_23; ?>" />
                <input type="hidden" name="Devise_24" value="<?php echo $encaissement->Devise_24; ?>" />
                <input type="hidden" name="Notetype_25" value="<?php echo $encaissement->Notetype_25 ; ?>" />
                <input type="hidden" name="Noteid_26" value="<?php echo $encaissement->Noteid_26; ?>" />
                <input type="hidden" name="Notedate_27" value="<?php echo $encaissement->Notedate_27 ; ?>" />
                <input type="hidden" name="Notemontant_28" value="<?php echo $encaissement->Notemontant_28 ; ?>" />
                <input type="hidden" name="Notedevise_29" value="<?php echo $encaissement->Notedevise_29; ?>" />
                
                <input type="hidden" name="Notereference_30" value="<?php echo json_encode($encaissement->Notereference_30); ?>" />
                <input type="hidden" name="Datevaleur_31" value="<?php echo $encaissement->Datevaleur_31; ?>" />
                <input type="hidden" name="Reference_32" value="<?php echo $encaissement->Reference_32 ; ?>" />
                <input type="hidden" name="Compte_33" value="<?php echo $encaissement->Compte_33 ; ?>" />
                <input type="hidden" name="Devise_34" value="<?php echo $encaissement->Devise_34 ; ?>" />
                
                <input type="hidden" name="Taux_41" value="<?php echo $encaissement->Taux_41; ?>" />
                <input type="hidden" name="Sydonia_49" value="<?php echo $encaissement->Sydonia_49; ?>" />
                <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
                
                <input type="hidden" name="Infos[year]" value="<?= isset($infos['year']) ? $infos['year'] : ""; ?>" />
                <input type="hidden" name="Infos[number]" value="<?= isset($infos['number']) ? $infos['number'] : "" ; ?>" />
                <input type="hidden" name="Infos[quittance]" value="<?=  isset($infos['quittance']) ? $infos['quittance'] : ""; ?>" />
                <input type="hidden" name="Infos[amountDGDA]" value="<?= isset($infos['amountDGDA']) ? $infos['amountDGDA'] : ""; ?>" />
                <input type="hidden" name="Infos[serie]" value="<?= isset($infos['serie']) ? $infos['serie'] : ""; ?>" />
                <input type="hidden" name="Infos[bank]" value="<?= isset($infos['bank']) ? $infos['bank'] : ""; ?>" />
                <input type="hidden" name="Infos[Nifdeclarant]" value="" />
                <input type="hidden" name="Infos[agence]" value="<?php isset($infos['agence']) ? $infos['agence'] : ""; ?>" />
                <input type="hidden" name="Infos[taxesPaid]" value='<?php echo $taxes; ?>' />
                
                <div class="row">
                    <div class="col-md-12">
                        <br/><br/>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Bureau</label>
                            </div>
                            <div class="col-md-8">
                                <b>:</b> <?php echo $services['DGDA'][$encaissement->Service_16]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;clarant</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Declarant_16; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">D&eacute;signation</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Designation_14.' / '.$encaissement->Nif_13; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Mode de paiement</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php  echo $modes[$encaissement->Mode_19]; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Intitul&eacute; du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo (isset($infos['accountname']))? $infos['accountname']:"-"; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Num&eacute;ro du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $bulletin->Serial_9.' '.$bulletin->Number_10; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Ann&eacute;e du bulletin</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> 
                               <?php
                               
                               $dateLiq = explode('/',$bulletin->DateL_11);
                               echo $dateLiq[2]; 
                               
                               ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="col-md-6">
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Montant total(BL)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo $encaissement->Montant_11.' CDF '; ?>
                            </div>
                        </div> 
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Commission</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Commission_23,2,","," ").' '.$encaissement->Devise_24;?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Total &agrave; payer</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?php echo number_format($encaissement->Total,2,","," ").' CDF'; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte client(&agrave; d&eacute;biter)</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?=isset($encaissement->Compte_33 ) ? $encaissement->Compte_33 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Devise du compte</label>
                            </div>
                            <div class="col-md-8">
                               <b>:</b> <?= isset($encaissement->Devise_34 ) ? $encaissement->Devise_34 : ""; ?>
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Taux appliqu&eacute;</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b> <?= isset($encaissement->Taux_41 ) ? $encaissement->Taux_41 : ""; ?> CDF
                            </div>
                        </div>
                        <div class="input-group col-md-12 no-padding">
                            <div class="col-md-4 no-padding">
                                <label for="office">Compte Guichet Unique</label>
                            </div>
                            <div class="col-md-8">
                              <b>:</b>  <span class="<?php if($encaissement->CGU=='00000000000000000000000') echo 'text-red'; ?>"><?php echo $encaissement->CGU; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 bTop">
                        <br/><label>Sch&eacute;ma de comptabilisation (aper&ccedil;u)</label><br/>
                    </div>
                </div>
                
                <div class="row"><div class="col-md-12"><br></div></div>
                <div class="row">
                    <div class="col-md-12">
                        <table id="table" class="table table-hover table-striped">
                            <thead >
                                <tr class="bg-blue">
                                    <th width="250px">Libell&eacute;</th>
                                    <th width="100px">Op&eacute;ration</th>
                                    <th width="200px">Source</th>
                                    <th width="200px">D&eacute;stination</th>
                                    <th class="right" width="">Montant</th>
                                    <th width="15%">Action</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <?php foreach($integrations as $row) :?>
                                    <tr id="line<?php echo $row->Id_0;?>">
                                        <td  width="250px"><?php echo $row->Libelle_12;?></td>
                                        <td  width="100px"><?php echo $row->Operation_8;?></td>
                                        <td  class="<?php if(isset($row->Compte_9) && $row->Compte_9 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_9)? $row->Compte_9:'-'; ?></td>
                                        <td  class="<?php if(isset($row->Compte_13) && $row->Compte_13 =='00000000000000000000000') echo 'text-red'; ?>" width="200px"><?= isset($row->Compte_13)? $row->Compte_13:'-'; ?></td>
                                        <td ><?php echo $row->Devise_11.' '.number_format($row->Montant_10,2,","," ");?></td>
                                        <?php if($row->Status_2 ==1 || $row->Status_2 ==3){ ?>
                                            <td align="center" width="4%">
                                                <a id="btnr<?php echo $row->Id_0;?>" onclick="forcing('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-success text-white">R&eacute;ssayer</a>
                                                <a id="btnr_message<?php echo $row->Id_0;?>" href="#" onclick=""  class="d-none"><span class="text-green">Int&eacute;gr&eacute;</span></a>
                                                <a id="btnv<?php echo $row->Id_0;?>" onclick="verify('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-primary d-none text-white">V&eacute;rifier</a>
                                            </td>
                                        <?php }elseif($row->Status_2 ==2){ ?>
                                            <td align="center" width="4%">
                                                <a id="btnex<?php echo $row->Id_0;?>" onclick="returns('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-danger text-white" > Extourner</a>
                                                <a id="btnex_message<?php echo $row->Id_0;?>" href="#" onclick="" class="d-none"><span class=" text-green"> Extourn&eacute;</span></a>
                                                <a id="btnv<?php echo $row->Id_0;?>" onclick="verify_extourne('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-primary d-none text-white">V&eacute;rifier</a>
                                            </td>
                                        <?php }else{ ?>
                                            <td align="center" width="15%">
                                                <a id="btnv<?php echo $row->Id_0;?>" onclick="verify('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-primary text-white">V&eacute;rifier</a>
                                                <a id="btnr<?php echo $row->Id_0;?>" onclick="forcing('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-success d-none text-white">R&eacute;ssayer</a>
                                                <a id="btnr_message<?php echo $row->Id_0;?>" href="#" onclick="" class="d-none"><span class="text-green">Int&eacute;gr&eacute;</span></a>
                                                <a id="btnex<?php echo $row->Id_0;?>" onclick="returns('<?php echo $row->Id_0;?>')" type="button" class="btn-xs btn-danger d-none text-white" > Extourner</a>
                                                <a id="btnex_message<?php echo $row->Id_0;?>" href="#" onclick="" class="d-none"><span class=" text-green"> Extourn&eacute;</span></a>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                <?php endforeach;?>
                            </tbody>    
                        </table>
                    </div>
                </div>
            </div>
            <div class="box-footer clearfix">
                <div class="row">
                    <div id="createPaiement" class="col-md-12">
                        <button id="confirm"  type="submit" class="btn  btn-success  pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp; Valider &nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button id="closePanel" type="button" class="btn btn-warning" ><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    </div>
                </div>
            </div>
        <?php echo form_close(); ?>
    <?php $chtml->box_body_closing(); ?> 
</div>
<div class="">
</div>

<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script type="text/javascript"  charset="utf-8">

const core_banking = '<?php echo $core_banking ?>';

$('#confirmform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        submiter(data);
});



$("#closePanel").click(function(){
   
   $.get("<?php echo base_url($module.'/taxequalize/display/unequalized'); ?>", function(data, status){
        $("#loader").html('');
        $("#container").html(data);
    });
    
});
function submiter(data){
    
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
        
        var message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        var url ="<?php echo base_url($module.'/taxequalize/save/'); ?>/validate_prepayment<?php echo $encaissement->Sydonia_49 > 0 ? '/'.$encaissement->Sydonia_49 : ''; ?>";

        
        scrollUP();
        $('#confirm').prop("disabled",true);
        $("#loader").html('');
            
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E002")
                        {
                                $("#loader").html('');
                                $('#loader').html('<div class="alert aDanger text-white">Desol&eacute; l\'enregistrement a &eacute;chou&eacute; veuillez reprendre!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                var url ="<?php echo base_url($module.'/taxprepayments/display/'); ?>/preview<?php echo $encaissement->Sydonia_49 > 0 ? '/'.$encaissement->Sydonia_49 : ''; ?>";

                                $.get(url, function(data, status){
                                    $('#loader').html(message);
                                    $("#pager").html(data);
                                })
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

function forcing(id)
{
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" /></td></div>';
        var sHtml = $("#line"+id).html();
        
        var regie = '<?php echo $encaissement->Beneficaire_15;  ?>';
        var reference ='<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Sydonia_49; ?>';
        var branch_code = '<?php echo isset($branch_code) ? $branch_code : ""; ?>';
        var object = 'prepayment';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = { regie : regie,  reference : reference, designation : designation, paiementid : paiementid, branch_code:branch_code, object:object, action : 'forcing', csrf_name: csrf, object: object, transactionid: transactionid}; 
        $("#line"+id).html(cHtml);
        var url = '<?php echo base_url($module.'/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                        
                        if(result.response === "E300")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">L\'&eacute;criture n\'est pas int&eacute;gr&eacute;e d&ucirc; &agrave; un probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                        
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E405")
                        {
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Cette &eacute;criture ne peut pas &ecirc;tre int&eacute;gr&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E404")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E411")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave;  '+core_banking+' avec succ&egrave;s mais il y a eu aucun retour '+core_banking+', veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                    
                                    $("#btnr"+id).addClass('d-none');
                                    $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E200") 
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html(sHtml);
                                $("#btnr"+id).addClass('d-none');
                                $("#btnr_message"+id).removeClass('d-none');
                        }
                        else
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> L\'&eacute;criture a &eacute;t&eacute; envoy&eacute;e &agrave;  '+core_banking+' avec succ&egrave;s mais il y a eu aucun retour '+core_banking+', veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                    
                                    $("#btnr"+id).addClass('d-none');
                                    $("#btnv"+id).removeClass('d-none');
                                });
                        }
                },
                error:function(error){
                   
                    $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse  '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse '+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans  '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
       
}

function returns(id)
{
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" /></td></div>';
        var sHtml = $("#line"+id).html();
        $("#line_return"+id).removeClass('hidden');
        var returnHtml = $("#line_return"+id).html();
        $("#line_return"+id).addClass('hidden');
        var regie = '<?php echo $encaissement->Beneficaire_15;  ?>';
        var reference ='<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Sydonia_49; ?>';
        var branch_code = '<?php echo isset($branch_code) ? $branch_code : ""; ?>';
        var object = 'prepayment';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = { regie : regie,  reference : reference, designation : designation, paiementid : paiementid, branch_code:branch_code, object:object, action : 'reverse', csrf_name: csrf, object: object, transactionid: transactionid}; 
        $("#line"+id).html(cHtml);
        var url = '<?php echo base_url($module.'/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                        
                        if(result.response === "E300")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">Probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message, pour vous rassurer que l\'ecriture est extourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        
                                        $("#btnex"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E405")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Cette &eacute;criture ne peut pas &ecirc;tre extourn&eacute; faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E404")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnex"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E411")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">Probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message, pour vous rassurer que l\'ecriture est extourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        
                                        $("#btnex"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                        else if(result.response === "E200") 
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html(sHtml);
                                $("#btnex"+id).addClass('d-none');
                                $("#btnex_message"+id).removeClass('d-none');
                        }
                        else
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">Probl&egrave;me de connexion, veuillez cliquer sur le bouton v&eacute;rifier en fermant ce message, pour vous rassurer que l\'ecriture est extourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        
                                        $("#btnex"+id).addClass('d-none');
                                        $("#btnv"+id).removeClass('d-none');
                                });
                        }
                },
                error:function(error){
                   
                    $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse  '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function verify(id)
{
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" /></td></div>';
        var sHtml = $("#line"+id).html();
        var regie = '<?php echo $encaissement->Beneficaire_15;  ?>';
        var reference ='<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Sydonia_49; ?>';
        var branch_code = '<?php echo isset($branch_code) ? $branch_code : ""; ?>';
        var object = 'prepayment';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = { regie : regie,  reference : reference, designation : designation, paiementid : paiementid, branch_code:branch_code, object:object, action : 'verify', csrf_name: csrf, object: object, transactionid: transactionid}; 
        
        $("#line"+id).html(cHtml);
        
        var url = '<?php echo base_url($module.'/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                        
                        if(result.response === "E300")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> La transaction n\'est pas int&eacute;gr&eacute;e dans  '+core_banking+' veuillez cliquer sur le bouton r&eacute;essayer en fermant ce message pour int&eacute;grer cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).removeClass('d-none');
                                        $("#btnv"+id).addClass('d-none');
                                });
                        }
                        else if(result.response === "E405")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Cette &eacute;criture ne peut pas &ecirc;tre v&eacute;rifi&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E404")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Compte fermé, chapitre non autorisé, sens du compte incorrect. Le client devra contacter le gestionnaire de son compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E411")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">  '+core_banking+' n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E200") 
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; int&eacute;gr&eacute;e dans  '+core_banking+' !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                    
                                    $("#btnr_message"+id).removeClass('d-none');
                                    $("#btnv"+id).addClass('d-none');
                                });
                        }
                        else
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white">  '+core_banking+' n\'a retourn&eacute; aucune r&eacute;ponse par rapport &agrave; cette &eacute;criture  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div></td>');
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                });
                        }
                },
                error:function(error){
                   
                    $('#loader').html('<div class="alert alert-warning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse  '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

function verify_extourne(id)
{
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" /></td></div>';
        var sHtml = $("#line"+id).html();
        var regie = '<?php echo $encaissement->Beneficaire_15;  ?>';
        var reference ='<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Sydonia_49; ?>';
        var branch_code = '<?php echo isset($branch_code) ? $branch_code : ""; ?>';
        var object = 'prepayment';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = { regie : regie,  reference : reference, designation : designation, paiementid : paiementid, branch_code:branch_code, object:object, action : 'verify', csrf_name: csrf, object: object, transactionid: transactionid}; 
        
        $("#line"+id).html(cHtml);
        
        var url = '<?php echo base_url($module.'/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'json', 
                encode      : true,
                success: function(result){
                        
                        if(result.response === "E300")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Probl&eacute;me de connexion, veuillez v&eacute;rifier pour vous rassurer que la transaction est &eacute;xtourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).removeClass('d-none');
                                        $("#btnv"+id).addClass('d-none');
                                });
                        }
                        else if(result.response === "E405")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Cette &eacute;criture ne peut pas &ecirc;tre v&eacute;rifi&eacute;e faute des donn&eacute;es manquantes ou  non valides !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                });
                        }
                        else if(result.response === "E404")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Probl&eacute;me de connexion, veuillez v&eacute;rifier pour vous rassurer que la transaction est &eacute;xtourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).removeClass('d-none');
                                        $("#btnv"+id).addClass('d-none');
                                });
                        }
                        else if(result.response === "E411")
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Probl&eacute;me de connexion, veuillez v&eacute;rifier pour vous rassurer que la transaction est &eacute;xtourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).removeClass('d-none');
                                        $("#btnv"+id).addClass('d-none');
                                });
                        }
                        else if(result.response === "E200") 
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aSuccess text-white">L\'&eacute;criture est d&eacute;j&agrave; extourn&eacute;e dans  '+core_banking+' !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                
                                $("#delNo").click(function(){
                                    $("#line"+id).html(sHtml);
                                    
                                    $("#btnv"+id).addClass('d-none');
                                    $("#btnex_message"+id).removeClass('d-none');
                                });
                        }
                        else
                        {
                                $("#line"+id).html('');
                                $("#line"+id).html('<td colspan=8><div class="alert aDanger text-white"> Probl&eacute;me de connexion, veuillez v&eacute;rifier pour vous rassurer que la transaction est &eacute;xtourn&eacute; ou pas  !<button type="button" class="close" data-dismiss="alert" aria-hidden="true" id="delNo">x</button></div><td>');
                                $("#delNo").click(function(){
                                       
                                        $("#line"+id).html(sHtml);
                                        $("#btnr"+id).removeClass('d-none');
                                        $("#btnv"+id).addClass('d-none');
                                });
                        }
                },
                error:function(error){
                   
                    $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse  '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });
}

</script>