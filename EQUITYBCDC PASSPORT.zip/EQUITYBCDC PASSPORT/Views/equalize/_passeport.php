﻿<?php $userid = $encaissement->Makerid_9; $feuille=''; $infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>


<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $userid==$this->session->userdata("user_id") && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>
 

<?php if(isset($_POST['Reference_14']) && $_POST['Reference_14'] !='') {$reference = $_POST['Reference_14'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nif_17']) && $_POST['Nif_17'] !='') {$nif = $_POST['Nif_17'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else{ $designation = "";}?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        $infos['totalDevise'] = $encaissement->Devise_12;
}

$lecture_mode = ($encaissement->Typerecette_17 == "27421600") ? "ReadOnly": "";
$diabled= $lecture_mode != "" ? "disbaled": "";
$hidden = ($encaissement->Typerecette_17 == "27421600" && $encaissement->Status_2 == "7") ? "":"hidden";

?>

<?php if (isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == "27421600"): ?>
    <?php if ($encaissement->Status_2 == "7"): ?>
        <div id="loader2"><div class="alert alert-info text-white">Le paiement est en attente de confirmation dans LOGIRAD. Veuillez activer la case <b>[Confirmer à nouveau]</b>, puis cliquer sur <b>[Confirmer la note]</b> pour poursuivre le processus<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
    <?php endif ?>
    <?php if ($encaissement->Status_2 == "6"): ?>
        <div id="loader2"><div class="alert alert-info text-white">Le paiement est en attente de l'éclatement pour la comptabilisation des comptes des partenaires dans FINACLE. Veuillez cocher la case <b>[Valider à nouveau]</b>, puis cliquer sur <b>[Valider]</b> pour poursuivre le processus<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
    <?php endif ?>
<?php endif ?>
<div id="loader1"></div>
<div id="logirad-msg"></div>

<?php echo form_open('', array('id' => 'mainform', 'class' => 'view')); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <?php $chtml->box_body_opening('', true);?>

    <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                    <div id="loader"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label>
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', array('DGRAD'), 'DGRAD', ' class="form-control bg-gray" required="required"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="input-group" id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label>
                        </span>
                        <span id="slist"><?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control chosen-select" id="service" required="required" '); ?></span>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label>
                        </span>
                        <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25" required="required" ' .$lecture_mode); ?>
                    </div>
                </div>
                <div class="col-md-7">
                   <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notetype_25">Document</label>
                        </span>
                       <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                        <input type="hidden" name="Notetype_25" value="1">
                    </div>
                </div>
            </div>
            <div class="row"><div id="bl" class="col-md-12"></div></div>
            <div class="row">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notedate_27">Date &eacute;mission</label>
                        </span>
                        <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" ' .$lecture_mode); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
                <div class="col-md-7">
                     <div class="input-group" id="recette0">
                        <span class="input-group-addon">
                            <label for="Typerecette_17">Nature paiement</label>
                        </span>
                        <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="standard">Art. budg&eacute;taire</label>
                        </span>
                        <?php echo form_input("Infos[standard]", set_value("Infos[standard]", isset($infos['standard'])?$infos['standard']:""), ' class="form-control"  maxlength="25"'); ?>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notemontant_28">Montant de la note</label>
                        </span>
                        <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required"' .$lecture_mode); ?>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-5"><br/><label>Partie 3 : Client, Assujetti ou Contribuable </label><span id="info" class="text-red" style="padding-left:90px; "></span></div>
                <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?></span></label></div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif_13">Num&edot;ro imp&ocirc;t</label>
                        </span>
                        <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86"' .$lecture_mode); ?>
                    </div>
                </div>
                <div class="col-md-7">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Designation_14">D&eacute;signation</label>
                            </span>
                            <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"' .$lecture_mode); ?>
                        </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Mode_19">Mode de paiement</label>
                            </span>
                            <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Taux_41">Taux de change</label>
                            </span>
                            <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"' .$lecture_mode); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                               <label for="Datevaleur_31">Date paiement</label>
                            </span>
                            <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" ' .$lecture_mode); ?>
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                            </span>
                            <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control" required="required"' .$lecture_mode); ?>
                        </div>
                </div>
                <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Compte_33"><div id="compteLabel">Compte du client</div></label>
                            </span>
                            <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33 ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"' .$lecture_mode); ?>
                            <input type="hidden" name="Infos[accountname]" value="<?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?>" id="account_name">
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Montant_11">Montant &agrave; payer</label>
                            </span>
                            <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"' .$lecture_mode); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Commission_23"><div id="commiision">Commission</div></label>
                            </span>
                            <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission"' .$lecture_mode); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <label for="Total">Montant total</label>
                            </span>
                            <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"' .$lecture_mode); ?>
                        </div>
                </div>
                <div class="col-md-2">
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" style="padding-left:0px !important"></span>
                            <?php echo form_dropdown("Infos[totalDevise]", $devises, $infos['totalDevise'], 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                        </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12"><br/><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            </div>
            <div class="row">
                <div id="Comptabilisation" class="col-md-12">

                </div>
            </div>
    </div>
    <div class="box-footer clearfix">
        <div id="createPaiement" class="col-md-5">
            <!-------------------------  No valider  ------------------------------> 
            <button id="validate"  type="submit" disabled="disabled" class="btn  btn-primary  pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp; Valider &nbsp;&nbsp;</button>&nbsp;&nbsp;
            
            <?php //if ($encaissement->Typerecette_17 == "27421600" && $encaissement->Status_2 == "6") : ?>
                <button id="confirm"  type="submit" disabled="disabled" class="btn  btn-success <?= $hidden; ?>"><i class="fa fa-save"></i>&nbsp;&nbsp; Confirmer &nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php //endif; ?>

            <button id="save"  type="submit" class="btn  btn-success" disabled="disabled"><i class="fa fa-save"></i>&nbsp;&nbsp; Enregistrer &nbsp;&nbsp;</button>&nbsp;&nbsp;
            <a id="closePanel"  type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
            <input type="hidden" name="action" value="" id="action">
        </div>

        <div class="col-md-7">
            <?php if ($encaissement->Typerecette_17 == "27421600") : $status = $encaissement->Status_2;  ?>
                
                <?php if ($status == "5" || $status == "6"): ?>
                    <input type="hidden" name="Trans" value="<?= $status == "5" ? 'firstTrans' : ($status == "6" ? 'secondTrans' : '') ?>" id="">
                <?php endif; ?>

                <div class="col-md-4">
                    <label class="pull-left">
                        <input type="checkbox" <?= $status == 7 ? 'disabled' :'' ?> id="approbation_validate"  name="approbation" value="<?= 0 ?>"> Valider à nouveau
                    </label>
                </div>
                <div class="col-md-4">
                    <label class="pull-left">
                        <input type="checkbox" <?= $status != 7 ? 'disabled' :'' ?> id="approbation_confirm"  name="approbation" value="<?= 0 ?>"> Confirmer à nouveau
                    </label>
                </div>
                <div class="col-md-4">
                    <label class="pull-left">
                        <input type="checkbox" id="approbation_save"  name="approbation" value="<?= 0 ?>"> Enregistrer le paiement
                    </label>
                </div>
            <?php else: ?>
                <div class="col-md-6">
                    <label class="pull-left">
                        <input type="checkbox" id="approbation_validate"  name="approbation" value="<?= 0 ?>"> Valider le paiement de nouveau
                    </label>
                </div>
                <div class="col-md-6">
                    <label class="pull-left">
                        <input type="checkbox" id="approbation_save"  name="approbation" value="<?= 0 ?>" disabled> Enregistrer le paiement
                    </label>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?> 	  

<?php echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>
<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript"  charset="utf-8">

$("#validate").click(function(){
        $("#action").val('validate');
});

$("#save").click(function(){
        $("#action").val('save');
});

$("#confirm").click(function(){
        $("#action").val('confirm');
});

$("#approbation_confirm").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#validate").prop("disabled", true);
                $("#approbation_save").prop("checked", false);
                $("#approbation_validate").prop("checked", false);

                $("#confirm").prop("disabled", false);
        }
        else
        {
                $("#confirm").prop("disabled", true);
        }  
});

$("#approbation_validate").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#validate").prop("disabled", false);
                $("#approbation_save").prop("checked", false);
                $("#approbation_confirm").prop("checked", false);

                $("#save").prop("disabled", true);
        }
        else
        {
                $("#validate").prop("disabled", true);
        }  
});

$("#approbation_save").click(function(){
    
        if($(this).prop("checked")== true)
        {
                $("#save").prop("disabled", false);
                $("#approbation_validate").prop("checked", false);
                $("#approbation_confirm").prop("checked", false);
                $("#validate").prop("disabled", true);
        }
        else
        {
                $("#save").prop("disabled", true);
        } 
});

$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#message").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        //scrollUP();
        var data = $(this).serialize();
        //Verifier le BL dans Sydonia
        var action = $('#action').val();
        
        if(action == 'save')
        {
            submiter(data);
        }
        else if(action == 'validate')
        {
            validate(data);
        }
        else if(action == 'confirm')
        {
            confirm(data);
        }
        
});

function submiter(data){
    
    $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url ="<?php echo base_url($module.'/taxequalize/save/save_passport'); ?>/<?php echo $encaissement->Id_0; ?>";
    
    var  message = '<div class="alert alert-success text-white">Bravo! paiement enregistr&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
    scrollUP();
    
    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'html', 
            encode          : true,
            success: function(result){
                    $('#loader').html(result);
                    if(result === "E002")
                    {
                            $("#loader").html('');
                            $('#loader').html('<div class="alert alert-danger text-white">Desol&eacute;... Enregistrement a &eacute;chou&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            var url = '<?php echo base_url($module.'/notes/display/preview'); ?>/' + result;
                            $.get(url, function(data, status){
                                $('#loader').html(message);
                                $("#pager").html(data);
                            })
                    }
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
    });
    
}

function validate(data)
{
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxequalize/save/validate_passeport'); ?>/<?php echo $encaissement->Id_0; ?>';
       // $("#validate").prop("disabled", true);
        var message = '<div class="alert alert-success text-white">Bravo! paiement valid&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        var logirad_message = '<div class="alert alert-success text-white"> Paiement de la note de perception confirmé avec succès !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        
        scrollUP();
        
        $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result){

                    let pid = result.id;
                    let code = result.code;
                    let msg = result.message;

                    $('#loader').html('');
                    if(code === 200)
                    {
                            $('#step2').remove;
                            $("#step-2").removeClass('bg-green-active');
                            $("#step-2").addClass('bg-gray');
                            $("#step-3").removeClass('bg-gray');
                            $("#step-3").addClass('bg-green-active');

                            $('#print').prop("disabled",false);
                                
                            var url = '<?php echo base_url($module.'/passeport/display/preview'); ?>/' + pid;
                                
                            $.get(url, function(data, status){
                                $('#loader').html('<div class="alert alert-success text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#pager").html(data);
                            });
                    }
                    else if(code === "E162")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "E463")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "E411")
                    {
                            $("#message").html('');
                            $('#enregistrer').prop("disabled",false);
                            $('#loader').html('<div class="alert alert-danger text-white"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "E3238")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "W0205")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "E397")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "AD3")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "E9999")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "ERR002")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "ERR003")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code === "P83")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(code == "CP604" || code == "CP000" || code=="CP001" || code=="CP002" || code == "CP22"  || code == "CP404")
                    {
                            $("#message").html('');
                            $("#confirm_note").removeClass("hidden");

                            $('#loader').html('<div class="alert alert-info text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else 
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-danger text-white"> Probl&egrave;me de connexion &agrave; Finacle, veuillez trouver ce paiement dans le menu r&eacute;gularisation pour le r&eacute;gulariser.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
}

function confirm(data)
{
    $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
    var url = '<?php echo base_url($module.'/taxequalize/save/confirm_note'); ?>/<?php echo $encaissement->Id_0; ?>';

    scrollUP();

    $('#loader2').html('');
    $('#loader1').html('');
    $('#logirad-msg').html('');

    $.ajax({
            type        : 'POST', 
            url         : url, 
            data        : data, 
            dataType    : 'json', 
            encode      : true,
            success: function(result){
                    $('#loader').html('');
                    $('#logirad-message').html('');

                    let pid = result.id;
                    let code = result.code;
                    let msg = result.message;

                    $('#confirm').prop("disabled",true);

                    if(code === 200)
                    {
                            $('#step2').remove;
                            $("#step-2").removeClass('bg-green-active');
                            $("#step-2").addClass('bg-gray');
                            $("#step-3").removeClass('bg-gray');
                            $("#step-3").addClass('bg-green-active');

                            $('#print').prop("disabled",false);
                                
                            var url = '<?php echo base_url($module.'/taxpasseport/display/preview'); ?>/' + pid;
                                
                            $.get(url, function(data, status){
                                $('#loader').html('<div class="alert alert-success text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                $("#pager").html(data);
                            });
                    }
                    else if(code == "CP604" || code == "CP000" || code=="CP001" || code=="CP002" || code == "CP22"  || code == "CP404")
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-info text-white"> '+msg+'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                            $("#message").html('');
                            $('#loader').html('<div class="alert alert-success text-white">Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            },
            error:function(error)
            {
                $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
    });
    
}

$("#closePanel").click(function(){
   
    $.get("<?php echo base_url($module.'/taxequalize/display/unequalized'); ?>", function(data, status){
        $("#loader").html('');
        $("#container").html(data);
    });
    
});

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}

</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript"  charset="utf-8">
    
$("#delete").click(function(){

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        
        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText:"Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        },function(isConfirm){
            if(isConfirm) {
                var url = '<?php echo base_url($module.'/notes/save/delete'); ?>/'+reference;
                $.get(url, {recette:recette}, function (result, status) {
                    if(result > 0)
                    {
                        $('#loader').html('<div class="alert alert-success text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled",true);
                        $('#print').prop("disabled",true);
                        $('#schema').prop("disabled",true);
                        $('#delete').prop("disabled",true);
                    }
                    else
                    {
                        $('#loader').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    scrollUP();
                });
            }
        });
});
   
<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>

function comptabilisation(ref){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/taxequalize/display/get_details_passport'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

</script>


