<div class="box-body" style="margin-top: -35px;">  
    <?php $chtml->box_body_opening('', true); ?>
        <div class="row">
            <div class="col-sm-12 col-xs-12">
                    <h4>PAIEMENTS DGRAD</h4>
                    <p class="page-header"></p>
            </div>    
        </div>
        
        <div class="col-md-12 p-0">
            <?php if(!empty($encaissements)): ?>
                <table id="table" class="table table-striped bg-white">
                    <thead>
                        <tr class="bg-gray">
                            <th>#</th>
                            <th width="50">Date</th>
                            <th>D&eacute;signation</th>
                            <th>B&eacute;n&eacute;ficiaire</th>
                            <th>Recette</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th width="50">Op&eacute;rateur</th>
                            <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php  
                                foreach($encaissements as $row):
                                    $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
                                    $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
                                    $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                    <tr>
                                        <td width="5"><b><?= ++$i; ?></b></span></td>
                                        <td  width="80" <?php if($row->Status_2==3) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"'; ?> >
                                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                        </td>
                                        <td class="text-blue"><?php echo $row->Designation_14; ?></td>
                                        <td width="20"><b><?php echo $row->Beneficaire_15; ?></b></td>
                                        <td><?php if($row->Beneficaire_15 == "DGI") echo $row->Typerecette_17; elseif($row->Beneficaire_15 == "DGRAD")echo $row->Noteid_26 ; ?></td>
                                        <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                                            <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                                                <br/>
                                                <span class="text-muted"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                                            <?php endif;?>
                                        </td>
                                        <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                                        <td width="50" class="text-muted"><?php echo $operateur; ?></td>
                                        <?php  if($row->Status_2==1 && $row->Checkerid_10==0){ ?>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>','<?php echo $row->Beneficaire_15; ?>')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                            </td>
                                        <?php 
                                            }
                                            else{ 
                                        ?>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="print_payment('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                            </td>
                                        <?php
                                            }
                                        ?>
                                    </tr>
                            <?php 
                                endforeach; 
                            ?>
                    </tbody>    
                </table>
            <?php else: ?>
                <section id="cat_list" class="text-center">
                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4 fa-5x" ></span></span>
                    <span class="d-block p-2 "><b>Aucune information suppl&eacute;mentaire trouv&eacute;e</b></span>
                </section>
            <?php endif; ?>
        </div>
    <?php $chtml->box_body_closing(); ?>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": true,
      "bLengthChange": true
});
    
function view(id, regie)
{
    var url ='';
    
    $("#sub-menu").html('');
    
    if(regie === 'DGRAD')
    {
            var url ="<?php echo base_url($module.'/taxequalize/display/note'); ?>/"  + id;
    }
          
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#loader-sub-menu").html('');
        $("#sub-menu").html('<div class="box-body">' + data + '</div>');
        //$("#form").addClass('hidden');
        //$("#form").removeClass('hidden');
    });
}


function print_payment(pid){

        var url = '<?php echo base_url($module.'/taximpression/display/attestation'); ?>/' + pid;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
        
}
</script>