<div class="box-body" style="margin-top: -35px;">  
    <?php $chtml->box_body_opening('', true); ?>
        <div class="row">
            <div class="col-sm-12 col-xs-12">
                    <h4>PAIEMENTS DGDA</h4>
                    <p class="page-header"></p>
            </div>    
        </div>
        
        <div class="col-md-12 p-0">
            <?php if(!empty($bulletins)): ?>
                <table id="table" class="table table-striped bg-white">
                    <thead>
                        <tr class="bg-gray">
                            <th>#</th>
                            <th width="50">Date</th>
                            <th>D&eacute;signation</th>
                            <th>B&eacute;n&eacute;ficiaire</th>
                            <th>Recette</th>
                            <th>Montant</th>
                            <th>Commissions</th>
                            <th width="50">Op&eacute;rateur</th>
                            <th><span class="fa fa-fw text-red fa-file-pdf-o f14"></span></th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php 
                                foreach($bulletins as $row):
                                    $agence =  (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
                                    $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                    $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                            ?>
                                    <tr>
                                        <td width="5"><b><?= ++$i;  ?></b></span></td>
                                        <td  width="80" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline == gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?> >
                                            <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?>
                                        </td>
                                        <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                        <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                        <td><?php echo $row->Serie_7.'-'.$row->Number_8; ?></td>
                                        <td class="text-blue">
                                            <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                        </td>
                                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                                        <td width="50"><?php echo '<span  class="text-muted"> '.$operateur.'</span>'; ?></td>
                                        <?php if($row->Status_2==1){ ?>
                                            <td width="25">
                                                <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item"><span class="fa fa-fw text-yellow fa-warning f14"> </span></a>
                                            </td>
                                        <?php }else{ ?>
                                            <td width="25">
                                                <?php if(file_exists(base_url('api/endpoints/sydonia').'/'.$row->Pdfcontent_18)):?>
                                                    <a style="cursor:pointer" onclick="printQuittance('<?php echo $row->Pdfcontent_18; ?>')" ><span class="fa fa-fw text-red fa-file-pdf-o f14"> </span></a>
                                                <?php else: ?>
                                                    <span class="fa fa-fw text-red fa-file-pdf-o f14"> </span>
                                                <?php endif; ?>
                                            </td>
                                        <?php } ?>
                                    </tr>
                            <?php 
                                endforeach; 
                            ?>
                    </tbody>    
                </table>
            <?php else: ?>
                <section id="cat_list" class="text-center">
                    <span class="d-block p-2 "><span class="fa fa-warning text-gray mystyle4 fa-5x" ></span></span>
                    <span class="d-block p-2 "><b>Aucune information suppl&eacute;mentaire trouv&eacute;e</b></span>
                </section>
            <?php endif; ?>
        </div>
    <?php $chtml->box_body_closing(); ?>
</div>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">

$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50,
      "bFilter": true,
      "bLengthChange": true
});
    
function view(id, regie)
{
    var url ='';
    
    $("#sub-menu").html('');
    
    if(regie === 'DGDA')
    {
            var url ="<?php echo base_url($module.'/taxequalize/display/bulletin'); ?>/"  + id;
    }
          
    $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
    $.get(url, function(data, status){
        $("#loader-sub-menu").html('');
        $("#sub-menu").html('<div class="box-body">' + data + '</div>');
        //$("#form").addClass('hidden');
        //$("#form").removeClass('hidden');
    });
}

</script>