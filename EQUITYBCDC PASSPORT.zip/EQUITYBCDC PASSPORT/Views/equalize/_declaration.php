<?php
$userid = $encaissement->Makerid_9;
$feuille = '';
$infos = json_decode($encaissement->Notereference_30, true);
$disabled = "disabled";
$integration_type = json_decode($_SESSION['userdata']['options'], true);
?>

<?php if ($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11, 2, ",", " "); ?>
<?php if ($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28, 2, ",", " "); ?>
<?php if ($_SESSION['Logiref_role'] == 4 && $userid == $_SESSION["userdata"]["user_id"] && $encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == 0) $feuille = ''; ?>


<?php if (isset($_POST['Reference_14']) && $_POST['Reference_14'] != '') {
    $reference = $_POST['Reference_14'];
} elseif (isset($content['Reference_32']) && $content['Reference_32'] != "") {
    $reference = $content['Reference_32'];
} else {
    $reference = "";
} ?> 
<?php if (isset($_POST['Nif_17']) && $_POST['Nif_17'] != '') {
    $nif = $_POST['Nif_17'];
} elseif (isset($content['Nif']) && $content['Nif'] != "") {
    $nif = $content['Nif'];
} else {
    $nif = "";
} ?>
<?php if (isset($client->Designation_5) && $client->Designation_5 != '') {
    $designation = $client->Designation_5;
} elseif (isset($content['Denomination']) && $content['Denomination'] != "") {
    $designation = $content['Denomination'];
} else {
    $designation = "";
} ?>
<?php
if (isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else:
    $taux['Dollar_4'] = 00;
    $taux['Euro_5'] = 00;
    $taux['Rand_6'] = 00;
endif;
if (!isset($infos['totalMontant'])) {
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = $encaissement->Devise_12;
}
?>

<?php echo form_open('', array('id' => 'mainform', 'class' => 'view')); ?>
<style>label {
    min-width: 150px !important;
}</style>
<?php $chtml->box_body_opening('', true); ?>
<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
<input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
                <?php $chtml->box_body_opening('', true); ?>

<div class="box-body">
    <div class="row">
        <div class="col-md-12">
            <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
            <div id="loader"></div>
        </div> 
    </div>
    <div class="row">
        <!------------------------- Beneficiare  ------------------------------>
        <div class="col-md-12"><br/><label><b>Partie 1 : R&eacute;gies financi&egrave;re</b></label><br/></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" required="required"  '); ?>
                <?php if ($encaissement->Id_0 != NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-7">
            <div class="input-group  flex-nowrap" id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16" class="f12"><div id="ServiceId">Service recouvrement</div></label> 
                </span>
                <div class="overflow-hidden flex-grow-1">
                    <?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control " id="service"  required="required" '); ?>
                </div>
            </div>
            <?php if ($encaissement->Id_0 != NULL): ?>
                <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <!-------------------------  Titre de perception  ------------------------------>
        <div class="col-md-12"><br/><label><b>Partie 2 : Titre de paiement</b></label><br/></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-7">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25">Document</label> 
                </span>
                <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                <input type="hidden" name="Notetype_25" value="1">
            </div>
        </div>
    </div>
    <div class="row">
        <div id="bl" class="col-md-12"></div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-7  small-box">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17" class="">Nature paiement</label> 
                </span>
                <?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Infos[NumeroTitre]">Num&eacute;ro de titre</label> 
                </span>
                <?php echo form_input("Infos[NumeroTitre]", set_value("Infos[NumeroTitre]", (isset($infos['NumeroTitre'])) ? $infos['NumeroTitre'] : ''), ' class="form-control" id=""  maxlength="45"'); ?>
            </div>
        </div>
        <div class="col-md-7 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Infos[Motif]">Motif de paiement</label> 
                </span>
                <?php echo form_input("Infos[Motif]", set_value("Infos[Motif]", (isset($infos['Motif'])) ? $infos['Motif'] : ''), ' id="" class="form-control" maxlength="45" required="required" '); ?>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard">Ech&eacute;ance</label> 
                </span>
            <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $infos['standard']), ' class="form-control" id="datepicker3" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28">Montant de la note</label> 
                </span>
                <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
            <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <!------------------------- Payement  ------------------------------>
        <div class="col-md-5"><br/><label><b>Partie 3 : Client, Assujetti ou Contribuable </b></label><span id="info" class="text-red" style="padding-left:90px; "></span></div>
        <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo(isset($infos['accountname'])) ? $infos['accountname'] : ''; ?></span></label></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                </span>
                <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div> 
        <div class="col-md-7">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Designation_14">D&eacute;signation</label> 
                </span>
                <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Mode_19">Mode de paiement</label> 
                </span>
                <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Taux_41">Taux de change</label> 
                </span>
                <?php echo form_input('Taux_41', ($encaissement->Taux_41 != "") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Datevaleur_31">Date paiement</label>
                </span>
                <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                </span>
                <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
            </div>
        </div> 
        <div class="col-md-5">
            <div class="input-group"> 
                <span class="input-group-addon">
                    <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                </span>
                <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                <input type="hidden" name="Infos[accountname]" value="<?php echo(isset($infos['accountname'])) ? $infos['accountname'] : ''; ?>" id="account_name">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Montant_11">Montant &agrave; payer</label> 
                </span>
                <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Commission_23"><div id="commiision">Commission</div></label>
                </span>
                <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Total">Montant total</label> 
                </span>
                    <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown("Infos[totalDevise]", $devises, $infos['totalDevise'], 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
            </div>
        </div>
    </div>

    <!-------------------------  DGI Cotisation  ------------------------------>
    <div id="DGICotisation" style="<?php echo ($encaissement->Typerecette_17 == "IPRIER") ? '' : 'display: none;'; ?>">
        <div class="row">
            <div class="col-md-12"><br /><label>Partie 3 : Informations additionnelle</label><br /></div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="RefDGI">R&eacute;f&eacute;rence DGI</label> 
                    <?php echo form_input("Infos[RefDGI]", set_value("Infos[RefDGI]", isset($infos['RefDGI']) ? $infos['RefDGI'] : ""), 'class="form-control"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="RefONEM">R&eacute;f&eacute;rence ONEM</label> 
                    <?php echo form_input("Infos[RefONEM]", set_value("Infos[RefONEM]", isset($infos['RefONEM']) ? $infos['RefONEM'] : ""), 'class="form-control" '); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="RefINPP">R&eacute;f&eacute;rence INPP</label> 
                    <?php echo form_input("Infos[RefINPP]", set_value("Infos[RefINPP]", isset($infos['RefINPP']) ? $infos['RefINPP'] : ""), 'class="form-control" '); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="RefINSS">R&eacute;f&eacute;rence CNSS</label> 
                    <?php echo form_input("Infos[RefINSS]", set_value("Infos[RefINSS]", isset($infos['RefINSS']) ? $infos['RefINSS'] : ""), 'class="form-control" '); ?>
                </div>
            </div> 
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="QuotasONEM">Quota DGI</label> 
                    <?php echo form_input("Infos[QuotasDGI]", set_value("Infos[QuotasDGI]", isset($infos['QuotasDGI']) ? $infos['QuotasDGI'] : ""), 'class="form-control" id="quota_dgi"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="QuotasONEM">Quatas ONEM</label> 
                    <?php echo form_input("Infos[QuotasONEM]", set_value("Infos[QuotasONEM]", isset($infos['QuotasONEM']) ? $infos['QuotasONEM'] : ""), 'class="form-control" id="quota_onem"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="QuotasINPP">Quotas INPP</label> 
                    <?php echo form_input("Infos[QuotasINPP]", set_value("Infos[QuotasINPP]", isset($infos['QuotasINPP']) ? $infos['QuotasINPP'] : ""), 'class="form-control" id="quota_inpp" '); ?>
                </div>
            </div> 
            <div class="col-md-3">
                <div class="form-group">
                    <label for="QuotasINSS">Quotas CNSS</label> 
                    <?php echo form_input("Infos[QuotasINSS]", set_value("Infos[QuotasINSS]", isset($infos['QuotasINSS']) ? $infos['QuotasINSS'] : ""), 'class="form-control" id="quota_inss" '); ?>
                </div>
            </div> 
        </div>
    </div>
    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
    <div class="row">
        <div class="col-md-12"><br/><label class="page-header">Partie additionnelle : Frais liés aux attestations</label><br /></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="form-check abc-checkbox abc-checkbox-success">
                <input class="form-check-input" id="print_attestation" <?= (isset($infos['PaidATTESTATION']) && $_SESSION['Logiref_role'] != 4) || (isset($encaissement->Printattestation_57) && $encaissement->Printattestation_57 >= 1) ? "disabled":""; ?> type="checkbox" <?= isset($infos['PaidATTESTATION']) ? "checked" : "" ?>  name="Infos[PaidATTESTATION]" value="<?= isset($infos['PaidATTESTATION']) ? $infos['PaidATTESTATION'] : "" ?>" >
                <input type="hidden" name="Infos[PaidATTESTATION]" value="<?= 'FIA' ?>" />
                <label class="form-check-label text-blue font-bold" for="print_attestation">
                    Frais liés à l’impression de l'attestations
                </label>
            </div>
        </div>
        <div class="col-md-7">
            <div class="form-check abc-checkbox">
                <input class="form-check-input" id="print_duplicata" type="checkbox" <?= ($_SESSION['Logiref_role'] == 4) || ($_SESSION['Logiref_role'] != 4 && isset($encaissement->Printattestation_57) && $encaissement->Printattestation_57 == 0) ? "disabled":"" ?>  name="Infos[PaidDUPLICATA]" value="<?= isset($infos['PaidDUPLICATA']) ? $infos['PaidDUPLICATA'] : "" ?>">
                <label class="form-check-label text-blue font-bold" for="print_duplicata">
                    Frais de duplicata d’attestation
                </label>
            </div>
        </div>
    </div>
    <?php endif ?>
    <div class="row">    
        <!------------------------- Repartitions  ------------------------------>
        <div class="col-md-12 "><br/><label><b>Sch&eacute;ma de comptabilisation</b></label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
        <div class="row"><div class="col-md-12" id="loader_scheme"></div></div>
        <div  id="Comptabilisation" class="col-md-12">

        </div>

        <!-------------------------  END  ------------------------------>
    </div>
</div>

<div  class="box-footer clearfix">
    <div class="row">
        <div id="createPaiement" class="col-md-12">
            <!-------------------------  No valider  ------------------------------> 
            <?php if(isset($integration_type['ALL']['batch-integration-regularization'])): ?><button type="button" id='verifier_batch' class="btn btn-primary pull-left"><i class="fa fa-check"></i>&nbsp;&nbsp;Vérifier</button><?php endif; ?>&nbsp;&nbsp;
            <button type="submit" id='enregistrer' class="btn btn-success" <?= isset($validate) ? $validate : "" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Enregistrer";
            else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="delete" class="btn btn-danger" <?= isset($delete) ? $delete : "" ?> ><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <a id="closePanel" type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
        </div>
    </div>
</div>

<?php $chtml->box_body_closing(); ?> 	  

<?php echo form_close(); ?>

<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript"  charset="utf-8">

    const core_banking = '<?php echo $core_banking; ?>';

    $(".select2").select2();

    $("#mainform").submit(function (e) {
        e.preventDefault();
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = "<?php echo base_url($module . '/taxequalize/save/'); ?>/validateDeclaration<?php echo $encaissement->Id_0 > 0 ? '/' . $encaissement->Id_0 : ''; ?>";
        var data = $(this).serialize();
        var message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        scrollUP();
        $.ajax({
                type: 'POST',
                url: url,
                data: data,
                dataType: 'html',
                encode: true,
                success: function (result) {
                    $('#loader').html('');
                    if (result === "E002")
                    {
                        $("#loader").html('');
                        $('#loader').html('<div class="alert aDanger text-white">Desol&eacute;... Enregistrement a &eacute;chou&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    } else
                    {
                        var url = '<?php echo base_url($module . '/taxdeclaration/display/preview'); ?>/' + result;
                        $.get(url, function (data, status) {
                            $('#loader').html(message);
                            $("#pager").html(data);
                        })
                    }
                },
                error: function (error)
                {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });

    });

    $("#closePanel").click(function () {

        $.get("<?php echo base_url($module . '/taxequalize/display/unequalized'); ?>", function (data, status) {
            $("#loader").html('');
            $("#container").html(data);
        });

    });
    
    $("#verifier_batch").click(function(e){
        var url = '<?php echo base_url($module . '/taxequalize/save/verify_batch')?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: {id:1},
            dataType: 'json',
            encode: true,
            success: function (result) {
                if(result=='200'){
                    $('#loader').html('');
                    $('#loader').html('<div class="alert aWarning text-white">Paiement non intégré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    
                    $('#verifier_batch').attr('disabled','disabled');
                    $('#enregistrer').removeAttr('disabled');
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse '+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });
    
    $("#delete").click(function () {

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function (isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taxequalize/save/delete'); ?>/' + reference + '/' + recette + '/DGI';

                $.ajax({
                    type: 'GET',
                    url: url,
                    dataType: 'html',
                    encode: true,
                    success: function (result) {
                        $('#loader').html('');

                        $('#loader').html('<div class="alert aSuccess text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", true);
                        $('#print').prop("disabled", true);
                        $('#schema').prop("disabled", true);
                        $('#delete').prop("disabled", true);
                    },
                    error: function (error) {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        });
    });

    <?php if (isset($encaissement->Id_0) && $encaissement->Id_0 != '' && $encaissement->Id_0 != 0) { ?>
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
    <?php } ?>

    function comptabilisation(ref) {
        $("#loader_scheme").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxequalize/display/get_details_dgi'); ?>/' + ref;
        $.get(url, function (data, status) {
            $('#loader_scheme').html('');
            $("#Comptabilisation").html(data);
        });
    }

    function forcing(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        $("#line_return" + id).html('');
        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'declaration';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'forcing', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnr" + id).addClass('d-none');
                    $("#btnr_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                } 
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse d\''+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function returns(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'declaration';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'reverse', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnex" + id).addClass('d-none');
                    $("#btnex_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                } 
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse d\''+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'declaration';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line"+id).html('');
                    $("#line"+id).html(result.msg);
                    
                    $("#delNo").click(function(){
                        $("#line"+id).html(sHtml);
                        
                        $("#btnr_message"+id).removeClass('d-none');
                        $("#btnv"+id).addClass('d-none');
                    });

                    $("#enregistrer").prop('disabled', false);
                } 
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                        $("#btnr" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify_extourne(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'declaration';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr_message" + id).removeClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                    });

                    $("#enregistrer").prop('disabled', false);
                } 
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>