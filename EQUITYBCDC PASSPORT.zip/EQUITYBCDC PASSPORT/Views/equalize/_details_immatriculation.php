<?php
    $integration_type = json_decode($_SESSION['userdata']['options'], true);
?>
<?php if (!empty($lines)): ?>
    <table id="table" class="table table-hover table-striped">
        <thead>
            <tr class="bg-gray">
                <th width="6%">Id</th>
                <th width="3%">Sens</th>
                <th>D&eacute;bit</th>
                <th>Cr&eacute;dit</th>
                <th>Montant</th>
                <th>Designation</th>
                <?php if (!isset($integration_type['ALL']['batch-integration-regularization'])) : ?>
                    <th width="4%">Action</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lines as $row): ?>
                <tr id="line<?php echo $row->Id_0; ?>" class="<?php if ($row->Compte_9 == '00000000000000000000000') echo 'text-red'; ?>">
                    <td width="6%"><?php echo $row->Id_0; ?></td>
                    <td width="3%"><?php echo $row->Operation_8; ?></td>
                    <td width="16%" class="<?php if ($row->Compte_9 == '00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_9; ?></td>
                    <td width="16%" class="<?php if ($row->Compte_13 == '00000000000000000000000') echo 'text-red'; ?>"><?php echo $row->Compte_13; ?></td>
                    <td><?php echo $row->Devise_11 . " " . number_format($row->Montant_10, 2, ",", " "); ?></td>
                    <td><?php echo $row->Libelle_12; ?></td>
                    <?php if (!isset($integration_type['ALL']['batch-integration-regularization'])) : ?>
                        <?php if ($row->Status_2 == 3 || $row->Status_2 == 1): ?>

                            <td align="center" width="4%" >
                                <a id="btnr<?php echo $row->Id_0; ?>" onclick="forcing('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-success text-white">R&eacute;ssayer</a>
                                <a id="btnr_message<?php echo $row->Id_0; ?>" href="#" onclick=""  class="d-none"><span class="text-green">Int&eacute;gr&eacute;</span></a>
                                <a id="btnv<?php echo $row->Id_0; ?>" onclick="verify('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-primary d-none text-white">V&eacute;rifier</a>
                            </td>

                        <?php elseif ($row->Status_2 == 2): ?>
                            <td align="center" width="4%">
                                <a id="btnex<?php echo $row->Id_0; ?>" onclick="returns('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-danger text-white" > Extourner</a>
                                <a id="btnex_message<?php echo $row->Id_0; ?>" href="#" onclick="" class="d-none"><span class=" text-green"> Extourn&eacute;</span></a>
                                <a id="btnv<?php echo $row->Id_0; ?>" onclick="verify_extourne('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-primary d-none text-white">V&eacute;rifier</a>
                            </td>
                        <?php else: ?>
                            <td align="center" width="4%">
                                <a id="btnv<?php echo $row->Id_0; ?>" onclick="verify('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-primary text-white" >V&eacute;rifier</a>
                                <a id="btnr<?php echo $row->Id_0; ?>" onclick="forcing('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-success d-none text-white">R&eacute;ssayer</a>
                                <a id="btnr_message<?php echo $row->Id_0; ?>" href="#" onclick="" class="d-none"><span class="text-green">Int&eacute;gr&eacute;</span></a>
                                <a id="btnex<?php echo $row->Id_0; ?>" onclick="returns('<?php echo $row->Id_0; ?>')" type="button" class="btn-xs btn-danger d-none text-white" > Extourner</a>
                                <a id="btnex_message<?php echo $row->Id_0; ?>" href="#" onclick="" class="d-none"><span class=" text-green"> Extourn&eacute;</span></a>
                            </td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>