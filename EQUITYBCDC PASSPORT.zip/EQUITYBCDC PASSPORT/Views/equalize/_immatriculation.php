<?php
$userid = $encaissement->Makerid_9;
$feuille = '';
$infos = json_decode($encaissement->Notereference_30, true);
$disabled = "disabled";
$integration_type = json_decode($_SESSION['userdata']['options'], true);
?>

<?php if (isset($encaissement->Type_58) && !is_null($encaissement->Type_58) && $encaissement->Type_58 != ""): ?>
    <div class="alert aWarning text-white" id='mobile_payment_msg'> Ce paiement a &eacute;t&eacute; initi&eacute; en ligne, veuillez cliquer sur le bouton modifier pour completer les informations manquantes.</div>
<?php endif; ?>

<?php
if (isset($infos['accounttax']) && $infos['accounttax'] != "") {
    #when the customer is exempted from tax
    $disabled_1 = "disabled";
    $disabled_2 = "";
} else {
    #when the customer is not exempted from tax
    $disabled_1 = "";
    $disabled_2 = "disabled";
}
$quote_parts = array();
if (!empty($encaissement)):
    $quote_parts = $infos['beneficiaries'];
endif;

$tva = (floatval($encaissement->Commission_23) * 0.16);

$montant_total = $encaissement->Montant_11 + $encaissement->Commission_23 + $tva;

?>

<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}
?>
<?php if ($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11, 2, ",", " "); ?>
<?php if ($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28, 2, ",", " "); ?>
<?php if ($encaissement->Commission_23 > 0) $encaissement->Commission_23 = number_format($encaissement->Commission_23, 2, ",", " "); ?>
<?php if ($_SESSION['Logiref_role'] == 4 && $userid == $_SESSION['userdata']['user_id'] && $encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == 0) $feuille = ''; ?>
<?php //$Standard01='';
?>


<?php if (isset($_POST['Reference_14']) && $_POST['Reference_14'] != '') {
    $reference = $_POST['Reference_14'];
} elseif (isset($content['Reference_32']) && $content['Reference_32'] != "") {
    $reference = $content['Reference_32'];
} else {
    $reference = "";
} ?>
<?php if (isset($_POST['Nif_17']) && $_POST['Nif_17'] != '') {
    $nif = $_POST['Nif_17'];
} elseif (isset($content['Nif']) && $content['Nif'] != "") {
    $nif = $content['Nif'];
} else {
    $nif = "";
} ?>
<?php if (isset($client->Designation_5) && $client->Designation_5 != '') {
    $designation = $client->Designation_5;
} elseif (isset($content['Denomination']) && $content['Denomination'] != "") {
    $designation = $content['Denomination'];
} else {
    $designation = "";
} ?>
<?php
if (isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else:
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if (!isset($infos['totalMontant'])) {
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = $encaissement->Devise_12;
}
?>

<div id="logirad-message"></div>

<?php echo form_open('', array('id' => 'mainform', 'class' => $view)); ?>
    <style>
        label {
            min-width: 150px !important;
        }
    </style>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Infos[Email]" value="<?= isset($infos["Email"]) ? $infos["Email"] : "" ?>" id="email">
    <input type="hidden" name="Infos[Phone]" value="<?= isset($infos["Phone"]) ? $infos["Phone"] : "" ?>" id="phone">
    <input type="hidden" name="Email_54" value="<?= isset($encaissement->Email_54) ? $encaissement->Email_54 : "" ?>" id="">

    <?php $chtml->box_body_opening('', true); ?>

    <div class="box-body">

        <div class="">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader1"></div>
            </div>
        </div>

        <!------------------------- Beneficiare  ------------------------------>
        <div class="row">

            <div class="col-md-12"><br /><span class="f12"><b><label>Partie 1 : R&eacute;gies financi&egrave;re</label></b></span><br /></div>

            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label>
                    </span>
                    <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" required="required"  '); ?>
                    <?php if ($encaissement->Id_0 != NULL): ?>
                        <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group" id="regie0">
                    <span class="input-group-addon">
                        <label for="Service_16">
                            <div id="ServiceId">Service recouvrement</div>
                        </label>
                    </span>
                    <?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control select2" id="service" required="required" '); ?>
                </div>
            </div>

        </div>

        <!-------------------------  Titre de perception  ------------------------------>

        <div class="row">

            <div class="col-md-12"><br /><span class="f12"><b><label>Partie 2 : Titre de paiement</label></b></span><br /></div>

            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26">
                            <div id="TitreId">Num&eacute;ro</div>
                        </label>
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25" required="required" readonly '); ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label>
                    </span>
                    <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
        </div>

        <div id="bl" class="col-md-12"></div>

        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" readonly '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group" id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label>
                    </span>
                    <?php echo form_dropdown('', $recettes, $encaissement->Typerecette_17, 'class="form-control select2" id="recette" disabled="disabled" required="required" '); ?>
                    <input type="hidden" name="Typerecette_17" value="<?= isset($encaissement->Typerecette_17) ? $encaissement->Typerecette_17 : "" ?>">
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Art. budg&eacute;taire</label>
                    </span>
                    <?php echo form_input("Artbudgetaire_18", set_value("Artbudgetaire_18", $encaissement->Artbudgetaire_18), ' class="form-control"  maxlength="25" readonly'); ?>
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label>
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required" readonly'); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <?php echo form_dropdown('', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required" disabled="disabled" '); ?>
                    <input type="hidden" name="Notedevise_29" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                </div>
            </div>
        </div>

        <!------------------------- Payement  ------------------------------>

        <div class="row">
            <div class="col-md-5"><br /><span class="f12"><b><label>Partie 3 : Assujetti ou Contribuable.</label></b></span><br /></div>
            <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px;"></span><br />
                <div style="display: flex; align-items: center; width: 100%;">
                    <label style="margin-bottom: 0;">
                        Intitulé du compte :&nbsp;&nbsp;
                        <span id="accountname"></span>
                    </label>
                    <?php if (isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                        <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                            <span id="" class="text-red f15"></span>&nbsp;&nbsp;<span id="labelNumber" class="text-red f15"></span>
                        </label>
                    <?php elseif (isset($options['ALL']['correspondent-bank-charges-for-dgrad-usd'])): ?>
                        <label style="margin-bottom: 0; white-space: nowrap; margin-left: auto;">
                            Frais de correspondance :&nbsp;&nbsp;
                            <span id="correspondent_fees" class="text-red f15">0.00 </span>&nbsp;&nbsp;<span id="correspondent_fees_currency" class="text-red f15"></span>
                            <input type="hidden" id="correspondent_fees_to_retrieve" name="Infos[correspondent_fees]">
                            <input type="hidden" id="correspondent_fees_to_retrieve_currency" name="Infos[correspondent_fees_currency]">
                        </label>
                    <?php endif; ?>
                </div>
            </div>

            <!--<div class="col-md-3 border"></br><label>Paie pour compte&nbsp;<input type="checkbox" name="Infos[pourcompte]" value="<?php echo (isset($infos['pourcompte'])) ? $infos['pourcompte'] : ''; ?>" <?php echo isset($infos['pourcompte']) ? 'checked' : ''; ?>></label></div>-->

            <input type="hidden" name="Infos[fraisbcc]" value="1" id="infosFbcc">
            <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
        </div>

        <div class="col-md-12 d-none" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux d'echange : </b> <span id="exchange_message"></span></div>
        <div class="col-md-12 d-none" id="trans_bloc"><b>Détails de la transaction: </b> <span id="trans_message"></span></div>

        <div class="row">
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Nif_13">Num&edot;ro imp&ocirc;t</label>
                    </span>
                    <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86" readonly'); ?>
                </div>
            </div>
            <div class="col-md-7 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14">D&eacute;signation</label>
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" readonly'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Mode_19">Mode de paiement</label>
                    </span>
                    <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Taux_41">Taux de change</label>
                    </span>
                    <?php echo form_input('Taux_41', ($encaissement->Taux_41 != "") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    <input type="hidden" value="<?php echo isset($infos['rate_code']) ? $infos['rate_code'] : "" ?>" name="Infos[rate_code]" id="rate_code">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Datevaleur_31">Date paiement</label>
                    </span>
                    <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10" disabled="disabled" required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    <input type="hidden" name="Datevaleur_31" value="<?php echo date('Y-m-d', strtotime($encaissement->Datevaleur_31)) ?>" id="">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Datetrans">Date transaction</label>
                    </span>
                    <?php
                    if (isset($encaissement->Mode_19) && $encaissement->Mode_19 == '5'):
                        $date_trans = isset($infos['Datetrans']) ? $infos['Datetrans'] : "";
                        $date_form = date('d-m-Y', strtotime($date_trans));
                        $readonly = '';
                    else:
                        $readonly = 'disabled';
                        $date_form = '';
                    endif;
                    ?>
                    <?php echo form_input('Infos[Datetrans]', set_value('Infos[Datetrans]', $date_form), ' id="dateTrans" class="form-control" maxlength="10" ' . $readonly); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                    </span>
                    <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Compte_33">
                            <div id="compteLabel">Compte du client</div>
                        </label>
                    </span>
                    <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                    <input type="hidden" name="account_name" value="<?php echo (isset($encaissement->Compte_33)) ? $encaissement->Compte_33 : ''; ?>" id="account_name">
                    <input type="hidden" name="account_currency" value="" disabled="disabled" id="account_currency">
                    <input type="hidden" name="account_balance" value="" disabled="disabled" id="account_balance">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Montant_11">Montant &agrave; payer</label>
                    </span>
                    <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required" readonly'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23">
                            <div id="commiision">Commission</div>
                        </label>
                    </span>
                    <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" '); ?>

                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23">
                            <div id="tva">Tva</div>
                        </label>
                    </span>
                    <?php $tva = (floatval($encaissement->Commission_23) * 0.16); ?>
                    <?php echo form_input('', set_value('', $tva), 'class="form-control" id="feesTva" readonly '); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Total">Montant total</label>
                    </span>
                    <?php echo form_input("montantTotal", set_value('Total', $montant_total), 'class="form-control bg-gray" id="montantTotal"'); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Devise_24', array('USD' => 'USD'), 'USD', 'class="form-control"  required="required" id="commissionDevise" disabled="disabled"'); ?>
                    <input type="hidden" name="Devise_12" value="<?= isset($encaissement->Notedevise_29) ? $encaissement->Notedevise_29 : "" ?>">
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('', $devises, "USD", 'class="form-control"  required="required" disabled="disabled" id="tvaDevise"'); ?>
                </div>
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown("Infos[totalDevise]", array('USD' => 'USD'), 'USD', 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                </div>
                <input type="hidden" name="Devise_24" value="<?php echo isset($encaissement->Devise_24) ? $encaissement->Devise_24 : "" ?>">
            </div>
        </div>

        <!-------------------------  DGI Immatriculation  ------------------------------>
        <div id="DGIQuotepart">

            <label><b>Partie 4 : Informations additionnelle</b></label>

            <div class="row">
                <?php foreach ($quote_parts as $i => $part): ?>
                    <div class="col-md-3 small-box">
                        <div class="form-group">
                            <label><?= esc($part['beneficiary_code']) ?></label>

                            <input type="hidden"
                                name="Infos[beneficiaries][<?= $i ?>][beneficiary]"
                                value="<?= esc($part['beneficiary_code']) ?>">

                            <?= form_input(
                                "Infos[beneficiaries][$i][amount]",
                                set_value("Infos[beneficiaries][$i][amount]", $part['amount']),
                                'class="form-control" readonly'
                            ); ?>

                            <input type="hidden"
                                name="Infos[beneficiaries][<?= $i ?>][currency]"
                                value="<?= esc($part['currency'] ?? 'USD') ?>">
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>

        <!------------------------- Repartitions  ------------------------------>
        <div class="row">
            <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
        </div>
        <div class="row">
            <div id="Comptabilisation" class="col-md-12"></div>
        </div>
        <!-------------------------  END  ------------------------------>
    </div>
    <div class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12 pl-0 pr-0">
            <button type="submit" id='enregistrer' class="btn btn-success" <?= ($validate != "") ? "disabled='disabled'" : "" ?> ><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="closePanel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    </div>
    <?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>

<script type="text/javascript"  charset="utf-8">

    const core_banking = '<?php echo $core_banking; ?>';

    $(".select2").select2();

    $("#mainform").submit(function (e) {
        e.preventDefault();
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = "<?php echo base_url($module . '/taxequalize/save'); ?>/validateImmatriculation<?php echo $encaissement->Id_0 > 0 ? '/' . $encaissement->Id_0 : ''; ?>";
        var data = $(this).serialize();
        var message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        scrollUP();
        $.ajax({
                type: 'POST',
                url: url,
                data: data,
                dataType: 'html',
                encode: true,
                success: function (result) {
                    $('#loader').html('');
                    if (result === "E002")
                    {
                        $("#loader").html('');
                        $('#loader').html('<div class="alert aDanger text-white">Desol&eacute;... Enregistrement a &eacute;chou&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                        var url = '<?php echo base_url($module . '/taximmatriculation/display/preview'); ?>/' + result;
                        $.get(url, function (data, status) {
                            $('#loader').html(message);
                            $("#pager").html(data);
                        });
                    }
                },
                error: function (error)
                {
                    $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });

    });

    $("#closePanel").on("click", function () {
        window.location.href = "<?= base_url($module . '/taxequalize/display/unequalized'); ?>";
    });

    $("#verifier_batch").click(function(e){
        var url = '<?php echo base_url($module . '/taxequalize/save/verify_batch')?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: {id:1},
            dataType: 'json',
            encode: true,
            success: function (result) {
                if(result=='200'){
                    $('#loader').html('');
                    $('#loader').html('<div class="alert aWarning text-white">Paiement non intégré !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                    $('#verifier_batch').attr('disabled','disabled');
                    $('#enregistrer').removeAttr('disabled');
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse '+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#delete").click(function () {

        var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function (isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taxequalize/save/delete'); ?>/' + reference + '/' + recette + '/DGI';

                $.ajax({
                    type: 'GET',
                    url: url,
                    dataType: 'html',
                    encode: true,
                    success: function (result) {
                        $('#loader').html('');

                        $('#loader').html('<div class="alert aSuccess text-white">Paiement supprim&eacute; avec succ&eacute;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", true);
                        $('#print').prop("disabled", true);
                        $('#schema').prop("disabled", true);
                        $('#delete').prop("disabled", true);
                    },
                    error: function (error) {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        });
    });

    <?php if (isset($encaissement->Id_0) && $encaissement->Id_0 != '' && $encaissement->Id_0 != 0) { ?>
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
    <?php } ?>

    function comptabilisation(ref) {
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        var url = '<?php echo base_url($module . '/taxequalize/display/get_details_immatriculation'); ?>/' + ref;
        $.get(url, function (data, status) {
            $("#Comptabilisation").html(data);
        });
    }

    function forcing(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        $("#line_return" + id).html('');
        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'immatriculation';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'forcing', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment_immatriculation'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnr" + id).addClass('d-none');
                    $("#btnr_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                }
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    /*$("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });*/
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse d\''+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });

    }

    function returns(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'immatriculation';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'reverse', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment_immatriculation'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnex" + id).addClass('d-none');
                    $("#btnex_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                }
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    /*$("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });*/
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse d\''+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'immatriculation';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment_immatriculation'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line"+id).html('');
                    $("#line"+id).html(result.msg);

                    /*$("#delNo").click(function(){
                        $("#line"+id).html(sHtml);

                        $("#btnr_message"+id).removeClass('d-none');
                        $("#btnv"+id).addClass('d-none');
                    });*/

                    $("#enregistrer").prop('disabled', false);
                }
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    /*$("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                        $("#btnr" + id).removeClass('d-none');
                    });*/
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify_extourne(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $encaissement->Beneficaire_15; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';
        var designation = '<?php echo $encaissement->Designation_14; ?>';
        var paiementid = '<?php echo $encaissement->Id_0; ?>';
        var branch_code = '<?php echo isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>';
        var object = 'immatriculation';
        var transactionid = id;
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment_immatriculation'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    /*$("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr_message" + id).removeClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                    });*/

                    $("#enregistrer").prop('disabled', false);
                }
                else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    /*$("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });*/
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function scrollUP() {
        $('html, body').animate({
            scrollTop: $("#loader").offset().top
        }, 20);
    }
</script>