
<div class="row" style="margin-top: -50px;">
        <div class="col-md-12">
                <div class="row">
                        <div class="col-md-12 ">
                                <h2 class="f30 text-blue">Paiments regularisés</h2>
                                <p class="page-header"><span class="f12 text-black">Cette section vous permet d'afficher les paiements regularisés.</span></p>     
                        </div>
                </div>
                <div class="row">
                        <div class="col-md-12 p-0">
                                <div class="box-body">
                                        <?php $chtml->box_body_opening("", true);?>
                                                <div class="row">
                                                        <div class="col-md-12">
                                                                <div class="form-group">
                                                                       <label for="type" class="f12 text-black">Selectionner un r&eacute;gie financière</label>
                                                                       <?php echo form_dropdown('type', $regularisations, "", 'class="form-control default-width" id="type" '); ?>
                                                               </div>
                                                        </div>
                                                </div>
                                        <?php $chtml->box_body_closing(); ?>
                                </div>
                        </div>
                    
                        <div id="loader-sub-menu"></div>
                        
                        <div class="col-md-12 mb-5 p-0" id="sub-menu">
                                
                                <section id="cat_list" class="text-center mt-5">
                                        <span class="fa fa-repeat text-navy mystyle4" ></span></br>
                                        <span class="d-block p-2 f12 text-black">Aucun régie sélectionné.</span>
                                </section>
                            
                        </div>
                </div>    
        </div>
</div>

<script type="text/javascript">
    
    $('#type').change(function(){
        var type = $('#type option:selected').val();
        
        if(type != '')
        {
            $("#sub-menu").html('');
            $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            action(type);
        }
    });
    
    
    function action(which) {
        
        //$('#sub-menu').removeClass('p-0');
        
        if (which === 'regularisationDGDA') {
            $.get("<?php echo base_url($module.'/taxequalize/display/regularisation_dgda'); ?>", function(data, status) {
                $("#loader-sub-menu").html('');
                $("#sub-menu").html(data);
            });
        }
        if (which === 'regularisationDGI') {
           $.get("<?php echo base_url($module . '/taxequalize/display/regularisation_dgi'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
       
        if (which === 'regularisationDGRAD') {
           $.get("<?php echo base_url($module . '/taxequalize/display/regularisation_dgrad'); ?>", function(data, status) {
               $("#loader-sub-menu").html('');
               $("#sub-menu").html(data);
           });
        }
      
         
    }

</script>
