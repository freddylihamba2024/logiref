<?php 
$noneButton = " "; 
$maker = $batch_lines->Creator_4;

?>
<div id="message"></div>
<div class="row">
    <div class="col-md-12">
        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "1"): ?> 
            <?php $noneButton = "d-none"; ?>
            <div id="loader2">
                <div class="alert alert-info text-black">
                    Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre intervention.
                    Veuillez vérifier et confirmer le taux de change à appliquer 
                    <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>
                    avant validation, puis cliquez sur le bouton <b>« Traiter »</b> afin de prendre ce taux en compte.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "2"): ?> 
        <div id="loader2">
            <div class="alert alert-info text-black">
                Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre attention.
                Le taux de change a été traité et confirmé. 
                Taux à appliquer : 
                <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>. <br>
                Veuillez cliquer sur le bouton <b>« Valider »</b> afin de finaliser le traitement du paiement.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 4 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ') == "5"): ?> 
                <div id="loader2"><div class="alert alert-info text-black">Le taux publié <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b> pour cette opération n’est pas correct. Veuillez le modifier et confirmer le taux de change à appliquer avant validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
        <?php endif; ?>
    </div>    
</div>

<?php echo form_open('', array('id' => 'main_form', 'class' => '')); ?> 
<style>.input-no-border {border-top: 0 !important; border-left: 0 !important; border-right: 0 !important; background:none !important; padding-left: 0 !important; }</style>
<?php $chtml->box_body_opening('', true); ?>
    <div class="col-md-12">
        <input type="hidden" name="logirefid" value="<?= $batch_lines->Lot_24 ?? 0; ?>" id="batch_id" />

        <div class="col-md-12 p-0">
            <div class="row">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des notes  en lot</h2>
                </div>
                <div class="col-md-7 bRight">
                    <div class="row">
                        <div class="col-md-12">
                            <br/><br/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Service recouvrement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $services["DGRAD"][$batch_lines->Service_8] ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Nature paiement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $recettes[$batch_lines->Recette_9] ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Numéro impôt</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nif_11 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Désignation</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Designation_12 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">intitulé du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $batch_lines->Intitule_21 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Compte du client</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= $batch_lines->Compte_19 . ' ' . $batch_lines->Devise_20; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Mode de paiement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $modes[$batch_lines->Mode_17] ?? "" ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Montant total du lot</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($batch_lines->Montant_13 ?? 0),2,","," "). " ".$batch_lines->Devise_14; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total Commission</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($batch_lines->Commission_15 ?? 0),2,","," "). ' ' .$batch_lines->Devise_16 ; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total TVA</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format((($batch_lines->Commission_15 * 0.16) ?? 0),2,","," "). " " .$batch_lines->Devise_16; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total à payer</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= number_format(($batch_lines->Montanttotal_27 ?? 0),2,","," ")." ". $batch_lines->Devise_14; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total des paiements</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nombrepaiements_26 ; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <?php if (!empty($failds)) : ?>
                        <div class="card p-3">
                            <div class="card-header bg-gray text-white" style="cursor:pointer;" data-toggle="collapse" data-target="#notesCollapse">
                                <h4 class="mb-0">
                                    <i id="toggleIcon" class="fa fa-chevron-down"></i> &nbsp; Liste des notes
                                </h4>
                            </div>

                            <div id="notesCollapse" class="collapse show">
                                <div class="card-body p-0">
                                    <table id="notesTable" class="table table-striped table-hover mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th width="10">#</th>
                                                <th>Référence</th>
                                                <th>Devise</th>
                                                <th>Montant</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; foreach ($failds as $row) : ?>
                                                <tr id="line<?= $i; ?>">
                                                    <td><?= $i; ?></td>
                                                    <td><?= $row->reference  ?></td>
                                                    <td><?= $row->devise; ?></td>
                                                    <td><?= number_format($row->amount, 2, ".", ","); ?></td>
                                                </tr>
                                            <?php $i++; endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div id="footpage" class="clearfix"></div>
                <div class="col-12 border-bottom">
                    <br><br>
                </div>
            </div>
        </div>

        <div class="box-body">
            <!------------------------- Repartitions  ------------------------------>
            <div class="row>">
                <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            </div>
            <div class="row"><div class="col-md-12" id="loader_schema1"></div></div>
            <div class="row">
                <div id="Comptabilisation" class="col-md-12"></div>
            </div>
            <!-------------------------  END  ------------------------------>

            <div  class="box-footer clearfix">
                <div class="row">
                    <div id="createPaiement" class="col-md-12">
                        <!-------------------------  No valider  ------------------------------> 
                        <?php if (isset($integration_type['ALL']['batch-integration-regularization'])) : ?>
                            <button type="button" id='verifier_batch' class="btn btn-primary" ><i class="fa fa-check"></i>&nbsp;&nbsp;Vérifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <?php endif; ?>
                        <button type="submit" id='enregistrer'  class="btn btn-success pull-left" <?= isset($validate) ? $validate : "" ?>><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Enregistrer";
                            else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="print" disabled="disabled" class="btn btn-primary "><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="delete" class="btn btn-danger" <?= isset($delete) ? $delete : "" ?> ><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <a id="cancel"  type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>

<script type="text/javascript"  charset="utf-8">

    $(document).ready(function () {
        $('#notesTable').DataTable({
            paging: true,
            pageLength: 5,
            lengthChange: false,
            searching: false,
            ordering: true,
            info: true,
            autoWidth: false
        });
    });

    $(document).ready(function(){
        // Quand le tableau est ouvert
        $('#notesCollapse').on('shown.bs.collapse', function () {
            $('#toggleIcon').removeClass('fa-chevron-up').addClass('fa-chevron-down');
        });
        // Quand le tableau est fermé
        $('#notesCollapse').on('hidden.bs.collapse', function () {
            $('#toggleIcon').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        });
    });

    $("#main_form").submit(function (e) {
        e.preventDefault();
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        let url = "<?php echo base_url($module . '/taxequalize/save'); ?>/validate_batchnote<?php echo $batch_lines->Id_0 > 0 ? '/'.$batch_lines->Id_0 : ''; ?>";
        let data = $(this).serialize();
        let message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        scrollUP();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (response) {

                if (response.code == 200) {
                    $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                    $("#enregistrer").prop("disabled", true);
                    $("#delete").prop("disabled", true);
                    $("#print").prop("disabled", false);

                } else {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } 
            },
            error: function (error)
            {
                $('#loader').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#delete").click(function () {

        let batchid = '<?php echo $batch_lines->Id_0; ?>';
        let logirefid = '<?php echo $batch_lines->Lot_24; ?>'

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function (isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taxequalize/save/delete_batch'); ?>/' + batchid + '/' + logirefid;

                $.ajax({
                    type: 'GET',
                    url: url,
                    dataType: 'json',
                    encode: true,
                    success: function (response) {
                        $('#loader').html('');

                        if (response.code == 200) {
                            $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                            $("#enregistrer").prop("disabled", true);
                            $("#delete").prop("disabled", true);
                            $("#print").prop("disabled", false);

                        } else {
                            $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        } 
                    },
                    error: function (error) {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        });
    });

    $("#print").click(function () {

        $("#validate").prop("disabled", true);

        let pid = '<?=  $batch_lines->Id_0 ?? '' ?>';
        let base = '<?php echo base_url($module . "/taximpression/display/attestation"); ?>';
        let param = 'batch'

        // Vérifier si param n'est pas null
        var url =  base + '/' + pid + '/' + param;

        // Ouvrir la fenêtre d’impression
        var w = window.open(url, "_blank");

        if (w) {
            // Vérifier que la fenêtre s'est bien ouverte
            $(w).on("load", function () {
                try {
                    // Lancer l'impression automatiquement
                    w.print();

                    $('#message').html('<div class="alert aSuccess text-white">Bravo! Attestation générée et impression lancée...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                } catch (e) {
                    // Si une erreur survient, on réactive le bouton
                    $("#print").prop("disabled", false);

                    $('#message').html('<div class="alert aDanger text-white"> Error : Erreur lors de la génération du PDF. Veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });

            // Gestion du cas où la fenêtre est fermée trop tôt
            var checkClosed = setInterval(function () {
                if (w.closed) {
                    clearInterval(checkClosed);
                    $("#print").prop("disabled", false);
                }
            }, 1000);

        } else {
            // Si le popup a été bloqué
            $("#print").prop("disabled", false);
            
            $('#message').html('<div class="alert aWarning text-white"> Information : Le navigateur a bloqué la génération de l’attestation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });

    $("#cancel").click(function(){
        location.reload(true);
    });


    comptabilisation('<?=  $batch_lines->Lot_24 ?? '' ?>');

    function comptabilisation(logirefid) 
    {
        $("#loader_schema1").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        let url = '<?php echo base_url($module . '/taxequalize/display/get_details_dgrad'); ?>/' + logirefid;
        $.get(url, function (data, status) {
            $("#Comptabilisation").html(data);
        });
    }

    function forcing(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        $("#line_return" + id).html('');
        var regie = '<?php echo $batch_lines->Beneficaire_7; ?>';
        var reference = '<?php echo $batch_lines->Lot_24; ?>';
        var designation = '<?php echo $batch_lines->Designation_12; ?>';
        var paiementid = '<?php echo $batch_lines->Id_0; ?>';
        var branch_code = '';
        var object = 'note';
        var mode = 'batch';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code: branch_code, action: 'forcing', csrf_name: csrf, object: object, transactionid: transactionid, mode:mode};
        $("#line" + id).html(cHtml);

        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnr" + id).addClass('d-none');
                    $("#btnr_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                } else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse '+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function returns(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $batch_lines->Beneficaire_7; ?>';
        var reference = '<?php echo $batch_lines->Lot_24; ?>';
        var designation = '<?php echo $batch_lines->Designation_12; ?>';
        var paiementid = '<?php echo $batch_lines->Id_0; ?>';
        var branch_code = '';
        var object = 'note';
        var mode = 'batch';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();
        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code: branch_code, action: 'reverse', csrf_name: csrf, object: object, transactionid: transactionid, mode:mode};
        $("#line" + id).html(cHtml);

        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(sHtml);
                    $("#btnex" + id).addClass('d-none');
                    $("#btnex_message" + id).removeClass('d-none');

                    $("#enregistrer").prop('disabled', false);
                } else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, il y a eu aucune r&eacute;ponse '+core_banking+', veuillez v&eacute;rifier l\'int&eacute;gration de cette &eacute;criture dans '+core_banking+'!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $batch_lines->Beneficaire_7; ?>';
        var reference = '<?php echo $batch_lines->Lot_24; ?>';
        var designation = '<?php echo $batch_lines->Designation_12; ?>';
        var paiementid = '<?php echo $batch_lines->Id_0; ?>';
        var branch_code = '';
        var object = 'note';
        var mode = 'batch';
        var transactionid = id
        var csrf = $('input[name="csrf_name"]').val();

        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid, mode:mode};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr_message" + id).removeClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                    });

                    $("#enregistrer").prop('disabled', false);
                } else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                        $("#btnr" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function verify_extourne(id)
    {
        var cHtml = '<td colspan=8><div class=""><img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></td></div>';
        var sHtml = $("#line" + id).html();

        var regie = '<?php echo $batch_lines->Beneficaire_7; ?>';
        var reference = '<?php echo $batch_lines->Lot_24; ?>';
        var designation = '<?php echo $batch_lines->Designation_12; ?>';
        var paiementid = '<?php echo $batch_lines->Id_0; ?>';
        var branch_code = '';
        var transactionid = id;
        var mode = 'batch';
        var object = 'note';
        var csrf = $('input[name="csrf_name"]').val();

        var data = {regie: regie, reference: reference, designation: designation, paiementid: paiementid, branch_code:branch_code, action: 'verify', csrf_name: csrf, object: object, transactionid: transactionid, mode:mode};
        $("#line" + id).html(cHtml);
        var url = '<?php echo base_url($module . '/taxequalize/save/regularize_payment'); ?>/' + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function (result) {

                if (result.response === "E200")
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnr_message" + id).removeClass('d-none');
                        $("#btnv" + id).addClass('d-none');
                    });

                    $("#enregistrer").prop('disabled', false);
                } else
                {
                    $("#line" + id).html('');
                    $("#line" + id).html(result.msg);
                    $("#delNo").click(function () {
                        $("#line" + id).html(sHtml);

                        $("#btnex" + id).addClass('d-none');
                        $("#btnv" + id).removeClass('d-none');
                    });
                }
            },
            error: function (error) {

                $('#loader').html('<div class="alert aWarning text-white">Le d&eacute;lai d\'attente de r&eacute;ponse '+core_banking+' est d&eacute;pass&eacute;, !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function scrollUP() 
    {
        $('html, body').animate({
            scrollTop: $("#loader").offset()
        }, 20);
    }


</script>