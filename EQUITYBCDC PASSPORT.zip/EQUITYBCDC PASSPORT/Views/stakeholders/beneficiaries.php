<?php $userid = $this->session->userdata["user_id"];?>
<?php $usertype = $this->session->userdata["user_type"];?>
<div class="col-md-10">
        
        <div class="col-md-12">
                <h1>Gestion des B&eacute;n&eacute;ficiaires</h1>
                <h5 class="page-header"><span class="text-gray">Trouver ici la liste de tous les b&eacute;n&eacute;ficiaires.</span></h5>
        </div>
    
    <div class="col-md-12">
        <div id="loader"></div>
    </div>
    <div class="col-md-12">
        <div class="col-md-12 no-padding">
            <?php $chtml->box_body_opening('', true); ?>
                <?php if(!empty($beneficiaries)): ?>
                        <table id="table" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-blue">
                                    <th>#</th>
                                    <th>Beneficiare</th>
                                    <th>Groupe</th>
                                    <th>Description</th>
                                    <th><span class="fa fa-fw fa-edit f14"></span></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                foreach($beneficiaries as $row){
                                ?>
                                    <tr>
                                        <td width="5"><?php echo $row->Code_7; ?></td>
                                        <td><b><?php echo $row->Description_5; ?></b></td>
                                        <td width="200"><?php if($row->Type_4=='RGF' || $row->Type_4=='BKC') echo '<b><span class="text-blue">'.$types[$row->Type_4].'</span></b>'; else echo ''.$types[$row->Type_4].''; ?></span></td>
                                        <td><?php echo ' '.$row->Comments_6;?></td>
                                        <td width="25">
                                            <?php if($_SESSION['Logiref_role']==0){?>
                                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>')" ><span class="fa fa-fw text-orange fa-pencil f14"> </span></a>
                                            <?php }else {?>
                                            <span class="fa fa-fw text-gray fa-pencil f14"> </span>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>    
                        </table>
                <?php else: ?>
                    <section id="cat_list">
                        <div class="row fontawesome-icon-list min-height-30pct f14 tCenter" style="padding-top: 20px;">
                        <i class="fa fa-fw fa-warning text-gray mystyle4"></i><br/>
                        Aucun b&eacute;n&eacute;ficiaires n'est enregistr&eacute;!<br/>
                        </div>
                    </section>
                <?php endif;?>
            <?php $chtml->box_body_closing(); ?> 	  
        </div>
    </div>
</div>
<div class="col-md-2">
    <div class="col-md-12">
        <a id="add" href="#"><span class="fa fa-fw fa-plus-circle mystyle4"></span></a>
    </div>
    
</div>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/jquery.dataTables.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/plugins/datatables/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script type="text/javascript">
$('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageSize": 50
});

$("#add").click(function(){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
      <?php if($_SESSION['Logiref_role']==444){ ?>
            $.get("<?php echo base_url($module.'/tax/taux'); ?>/publier/", function(data, status){
                $("#loader").html('');
                $("#pager").html(data);
            });
      <?php }else { ?>
            $("#loader").html('<div class="alert alert-warning text-white">Avertissement! vous avez un acc&egraves limit&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
      <?php } ?>
      
});

$("#help").click(function(){
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');
        $("#loader").html('<div class="alert alert-info text-white">D&eacute;sol&eacute! Notre assistant permanent d\'aide personnalis&eacute;e n\'est pas encore disponible...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');   
});


function view(id){
      $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/stakeholders/display/beneficiarie'); ?>/' + id ;
      $.get(url, function(data, status){
            $("#loader").html('');
            $("#fullscreen").html(data);
      });
}
</script>
