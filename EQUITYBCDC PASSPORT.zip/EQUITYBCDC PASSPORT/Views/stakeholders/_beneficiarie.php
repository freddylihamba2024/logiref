<?php if($beneficiairie->Id_0 > 0) $title='Modifier'; else $title ='Nouveau Beneficiaire' ?>

<div class="col-md-2"></div><div class="col-md-2"></div>
<?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
<div class="col-md-12">
    <?php $chtml->box_modal_opening($title, true);?>
        <div id="loader" class="col-md-12"></div>
        <div class="box-body">
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="code">Code</label>
                      <?php echo form_input('code', set_value('code', $beneficiairie->Code_7), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                      <label for="type">Groupe</label>
                      <?php echo form_dropdown('type', $types, set_value('type', $beneficiairie->Type_4), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            <div class="col-md-4">
                <div class="form-group">
                      <label for="description">Beneficiaire</label>
                      <?php echo form_dropdown('description', $beneficiaires, set_value('description', $beneficiairie->	Description_5 ), 'class="form-control" required="required" maxlength="17"'); ?>
                </div>    
            </div>
            <div class="col-md-12">
                <div class="form-group">
                      <label for="comments">Commentaire</label>
                      <?php echo form_textarea(array('name' => 'comments', 'cols' => 40, 'rows' => 2), set_value('comments', $beneficiairie->Comments_6), 'id="description" class="form-control" maxlength="761"  required="required" '); ?>
                </div>    
            </div> 
            
            
            
           
        </div>
        <div id="continue" class="box-footer clearfix">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==1) echo 'Enregistrer..'; else echo 'Validate..'; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning mRight10"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;  
            </div>
            
        </div>
    <?php $chtml->box_body_closing(); ?> 	  
</div>
<?php echo form_close(); ?>



<script type="text/javascript">
 
$('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/stakeholders'); ?>/save/beneficiairie/<?php echo $beneficiairie->Id_0; ?>';
        var data = $(this).serialize();
        var cid = '<?php echo $beneficiairie->Id_0; ?>';
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                    $('#loader').html('');
                    $('#loader').html(result);
                    <?php if($beneficiairie->Id_0 == ''){ ?>
                    $("#mainform").trigger('reset');
                    <?php }?>
                },
                error:function(error){
                    alert('ERROR!' + error);
                }
        });
});

$("#cancel").click(function(){
     closeModal();
});

$("#buttonCloseModal").click(function(){
     closeModal();
});

function closeModal(){
      $.get("<?php echo base_url($module.'/stakeholders/display'); ?>/beneficiaries/", function(data, status){
            $("#loader").html('');
            $("#fullscreen").html(data);
      });
}
</script>
