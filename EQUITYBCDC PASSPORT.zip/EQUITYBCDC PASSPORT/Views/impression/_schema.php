<?php $infos = json_decode($encaissement->Notereference_30, true);?>

<html lang="en"> 
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
  
    <div style=" padding-top: 45px;">
        <h3 align="center" style=" color:black; padding-top: 40px; font: bold caption 1.3em  sans-serif;">&nbsp;&nbsp;&nbsp;&nbsp; <u>BORDEREAU DE VIREMENT</u> <span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</h3>
        <p style=" border-top: 2px dashed black;"></p>
    </div>
<div style="font-size: 1em"> 
        <table style="font-size:10px; font-family: sans-serif;">
            <tr><td></td></tr>
            <tr><td></td></tr>
            <tr><td></td></tr>
            <tr>
                <td><b>AGENCE</b></td>
                <td>: <?php echo (isset($agences) && $agences !="" )? $agences :'..............';?></td>
            </tr>
            <tr>
                <td><b>TRANSACTION N&deg;</b></td>
                <td>: <?= isset($cbs_return) ? $cbs_return : ""; ?> </td>
            </tr>
            <tr>
                <td></td>
                <td>: <?php echo $encaissement->Datevaleur_31;?> </td>
            </tr>
            <tr>
                <td></td>
                <td>: <?php echo $encaissement->Reference_32;?> </td>
            </tr>
            <tr>
                <td><b>INITIER PAR</b></td>
                <td>: <?php echo $users[$encaissement->Makerid_9];?></td>
            </tr>
            <tr>
                <td><b>VALIDER PAR</b></td>
                <td>: <?php echo $users[$encaissement->Checkerid_10 ];?></td>
            </tr>
            <tr><td></td></tr>
            <tr>
                <td><b>CLIENT</b></td>
                <td>: <?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?> </td>
            </tr>
            <tr><td></td></tr>
            <tr>
                <td><b>NUM.COMPTE</b></td>
                <td>: <?php echo $encaissement->Compte_33 ;?> </td>
            </tr>
            <tr>
                <td><b>DEVISE</b></td>
                <td>: <?php echo $encaissement->Devise_12 ?>  </td>
            </tr>
            <tr>
                <td><b>DATE COMPTABLE</b></td>
                <td>: <?php echo $encaissement->Datevaleur_31;?></td>
            </tr>
            
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                 <td><b>B&eacute;n&eacute;ficiaire</b></td>
                <td>: <?php echo $encaissement->Beneficaire_15 ;?></td>
            </tr>
            <tr>
                <td><b>Num&eacute;ro De Compte</b></td>
                <td>: <?php echo $encaissement->Designation_14 ;?> </td>
            </tr>
            <tr><td></td><td></td></tr>
            <tr>
                <td><b>MONTANT EN CHIFFRE</b></td>
                <td>: <?php echo number_format($encaissement->Montant_11,2,","," "); ?></td>
            </tr>
            <tr>
                <td><b>MONTANT EN LETTRE</b></td>
                <td>: <?php echo $number_letter ; ?> </td>
            </tr>
             <tr>
                <td><b>MOTIF</b></td>
                <td>: <?php echo (isset($infos['Motif']))? $infos['Motif'] : ''; ?> </td>
            </tr>
           
        </table>
    
        <div style="padding-top:  50px;">
            <p>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span><b>CAISSIER</b></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span align="right"><b>CLIENT</b></span>

            </p>
            </br></br></br></br></br></br></br></br></br>
        </div>
        <div style="padding-top:  50px;">
            <p style=" border-top: 2px dashed;"></p>
        </div>
        <div style="padding-top:250px;  font-size:12px;" align="justify">
            <p align="center">Solidaire Banque S.A 4, Av, du marché-kinshasa/Gombe-Rép.Dém du Congo<br>Tél : +243 817 070 701 & +243 991 009 0001<br>Site: www.solidairebanque.com (ex. Byblos Bank RDC)</p>
        </div>
        
    
    </div>
</body>
</html>

