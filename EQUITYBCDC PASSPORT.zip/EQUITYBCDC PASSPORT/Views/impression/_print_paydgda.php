<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <td style="font-size:1.2em; font-weight: bold">
            PAIEMENT DGDA
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Service</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>BL</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Quittance</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Client</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Agences</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Saisi</b></td>
    </tr>

    <?php 
        $i=2;
                                        foreach($bulletins as $row){ 
                                            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                                            $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                                            $results = json_decode($row->Results_13);
                                            $recieptDate = explode("/",$results->receiptDate);
                                            $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                                        ?>
                                        <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                                            <td width="50" style="font-size:0.8em;" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                                                <?php echo $row->Integration_16; ?>
                                            </td>
                                            <td style="font-size:0.8em;"><?php echo $services['DGDA'][$row->Office_6]; ?></td>
                                            <td style="font-size:0.8em;"><?php echo 'L'.''.$row->Number_8;?></td>
                                            <td style="font-size:0.8em;"><?php echo $nodeid ; ?></td>
                                            <td class="text-blue" style="font-size:0.8em;"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                                            <td class="text-blue" style="font-size:0.8em;">
                                                <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                                            </td>
                                            <td style="font-size:0.8em;"><?= isset($guichets[$row->Agence_32]) ? $guichets[$row->Agence_32] : "-"; ?></td>
                                            <td style="font-size:0.8em;"><?php echo(isset($users[$row->User_15 ]))?$users[$row->User_15 ]:' - ';?></td>
                                            
                                        </tr>
                                        <?php 
                                            }
                                       ?>
                
                
</table>