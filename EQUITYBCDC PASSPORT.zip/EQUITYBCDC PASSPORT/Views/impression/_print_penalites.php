<!--<style>
    .img
    {
        width: 150px;
        height: 100px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>-->

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php //$page = $_SESSION['account_logo']; ?>
        <?php //if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <!--<td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php //echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php //echo $_SESSION['account_business']; ?>
        </td>-->
        <td style="font-size:1.2em; font-weight: bold">
            Retard de reversement
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Redevable</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>B&eacute;n&eacute;ficiaire</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Recette</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Motant</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Commission</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Op&eacute;rateur</b></td>
    </tr>

    <?php 
        $paiements = 0;
        $commissions = 0;
        $i=2;
        foreach($bulletins as $row)
        {
            $agence = (isset($guichets[$row->Agence_32]))? $guichets[$row->Agence_32] :' - ';
            $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
            $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
            $results = json_decode($row->Results_13);
            $recieptDate = explode("/",$results->receiptDate);
            $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
    ?>
                <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                    <td width="15%" style="font-size:0.8em;"><?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                    <td width="" style="font-size:0.8em;"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                    <td width="" style="font-size:0.8em;"><b><?php echo 'DGDA'; ?></b></td>
                    <td width="" style="font-size:0.8em;"><?php echo '-'; ?></td>
                    <td width="" style="font-size:0.8em;"><?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?></td>
                    <td width="" style="font-size:0.8em;"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                    <td width="" style="font-size:0.8em;"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                </tr>
    <?php 
    
        $i++;   
        }
    ?>
                
    <?php 
        
        foreach($encaissements as $row)
        {
            $guichet = (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ';
            $operateur = (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ';
            $dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
    ?>
                <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                    <td width="15%" style="font-size:0.8em;">  <?php echo strftime('%d-%m-%Y',strtotime($row->Date_1)); ?></td>
                    <td width="" style="font-size:0.8em;"><?=  isset($row->Designation_14) ? $row->Designation_14 : $row->Nif_13; ?></td>
                    <td width="" style="font-size:0.8em;"><b><?php echo $row->Beneficaire_15; ?></b></td>
                    <td width="" style="font-size:0.8em;"><?php echo $row->Typerecette_17; ?></td>
                    <td width="" style="font-size:0.8em;">
                        <?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?> 
                        <?php if($row->Devise_12 == "USD" || $row->Devise_12 =="EUR" || $row->Devise_12=="ZAF") :?>
                          <br/>
                          <span class="text-gray"><?php echo 'CDF '.number_format($row->Contrevaleur_22,2,","," "); ?></span>
                        <?php endif;?>
                    </td>
                    <td width="" style="font-size:0.8em;"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                    <td width="" style="font-size:0.8em;"><?php echo '<span  class="text-gray"> '.$operateur.'</span>'; ?></td>
                </tr>
    <?php 
    
            $paiements = $paiements + $row->Contrevaleur_22;
            $commissions = $commissions + $row->Commission_23;
            $i++;   
        }
    ?>  
                
                
</table>


