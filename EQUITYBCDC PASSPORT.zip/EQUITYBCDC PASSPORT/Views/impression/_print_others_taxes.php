<div>
        <div>
                <h3 style="text-align: center;font-size:18x;" >TAXES A ENVOYER VERS LES AUTRES BANQUES</h3>    
        </div><br>
        <table style=" border-collapse: collapse; width: 100%; font-size:14px;line-height:25px;">
                <thead>
                        <tr style="text-align: center;background-color:#00a7d0 ;padding:5px;">
                                <th style="width: 300px;text-align:start;">Libell&eacute;</th>
                                <th style="width: 100px;text-align:start;">Montant</th>
                                <th style="width: 100px;text-align:start;">Frais bcc</th>
                        </tr>
                </thead>
                <tbody >
                <?php foreach ($taxes as $key=>$row){
                            
                        $agence_src= $_SESSION['Logiref_guichet'];
                ?>
                        <tr style="background-color:#dee2e6;">
                                <td colspan="3"class="bold">
                                    <span class="f15"><b><?php echo $key.'  -  '; ?></b> </span><span class="f15"><b><?php echo isset($beneficiaries[$key][$agence_src]) ? $beneficiaries[$key][$agence_src].'  -  ' : ''; ?></b></span><span class="f15"><b><?php echo isset($comptes[$key]['CDF']) ? $comptes[$key]['CDF'] : ''; ?></b></span>
                                </td>
                                
                            <?php foreach($row as $line) {
                                
                                $frais_bcc = $line->Montant_10 * 0.001;
                                
                            ?>
                                <tr>
                                    <td style="width: 300px;text-align:start;"><?php echo $line->Libelle_12; ?></td>
                                    <td style="width: 100px;text-align:start;"><?php echo $line->Montant_10; ?></td>
                                    <td style="width: 100px;text-align:start;"><?php echo $frais_bcc; ?></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                </tbody>
        </table>
</div>




