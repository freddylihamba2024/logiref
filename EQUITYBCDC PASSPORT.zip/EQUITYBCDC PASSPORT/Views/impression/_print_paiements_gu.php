
<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
            <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business'].' - '.$guichets[$_SESSION['Logiref_guichet']]; ?>
        </td>
        <td style="font-size:1.0em; font-weight: bold">
            PAIEMENTS JOURNALIERS - GUICHET UNIQUE DGDA
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>
<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>N&ordm;</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Bulletin</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Service</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Importateur</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Bordereau</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Quitt.</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Devise</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Montant du bulletin</b></td>
        <td style="border-bottom:1px solid black; font-size:0.7em;"><b>Montant pay&eacute;</b></td>
    </tr>
  <?php
        $user = $this->session->userdata['user_id'];
        $total_general_bls = 0;
        $total_general_paiements = 0;
        
        $total_user = 0;
  
  ?>
    
    <tr>
        <td colspan="9">
            <?php echo(isset($office))? $services[$office]:''; ?>
        </td>
    </tr>
    <tr>
        <td colspan="9">
            <?php echo $users[$user];?>
        </td>
    </tr>
   
    <?php $i=2; $y = 1;    foreach ($bulletins as $row):
        
            $result = json_decode($row->Results_13); 
      
        ?>
            <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                <td style="font-size:0.7em;"><?php echo $y;?></td>
                <td style="font-size:0.7em;"><?php echo $row->Integration_16; ?></td>
                <td style="font-size:0.7em;"><?php echo $row->Serie_7.$row->Number_8; ?></td>
                <td style="font-size:0.7em;"><?php echo $services[$row->Office_6]; ?></td>
                <td style="font-size:0.7em;"><?php echo $row->Designation_23; ?></td>
                <td style="font-size:0.7em;"><?php echo $row->Reference_19; ?></td>
                <td style="font-size:0.7em;"><?php echo $result->receiptSerial.$result->receiptNumber; ?></td>
                <td style="font-size:0.7em;"><?php echo 'CDF'; ?></td>
                <td style="font-size:0.7em;"><?php echo number_format($result->declarationsPaid->amountToBePaid,2,","," "); ?></td>
                <td style="font-size:0.7em;"><?php echo number_format($row->Amount_12,2,","," "); ?></td>
            </tr>
    <?php  
    $i++; 
    $y++; 
    
    $total_general_bls = $total_general_bls + $result->declarationsPaid->amountToBePaid;
    $total_general_paiements = $total_general_paiements + $row->Amount_12;
    
    endforeach;?>
     
    <tr>
        <td colspan="8" style="text-align: right;">Total g&eacute;n&eacute;ral</td>
        <td style="font-size:0.8em;">
          <b><?php echo number_format($total_general_paiements,2,","," ");?></b>
        </td>
        <td style="font-size:0.8em;">
            <b><?php echo number_format($total_general_bls,2,","," ");?></b>
        </td>
    </tr>
</table>




