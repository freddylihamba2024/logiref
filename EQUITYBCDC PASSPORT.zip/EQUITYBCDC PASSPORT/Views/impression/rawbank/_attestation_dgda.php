<?php $infos = json_decode($encaissement->Notereference_30, true);?>

<?php 
        if(isset($infos['accountname']) && $infos['accountname'] !="")
        {
                $account_name = substr($infos['accountname'] , 0, 8);
                
                $boolean = stristr($encaissement->Designation_14, $account_name);
        }
?>

<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px;">
    <table style="width: 100%; font-family: Courier New;">
        <tr>
            <td align ="right">
                <div>
                    <p><?= isset($beneficiaires['Regies'][$encaissement->Beneficaire_15]) ? $beneficiaires['Regies'][$encaissement->Beneficaire_15] : ""; ?> / <?php echo  $encaissement->Id_0;?> / <?php echo gmdate("Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    
    
<span style="padding-top: 300px;">
    <p style="font-family: Courier New; text-align:justify; padding-top: 80px;">
        Nous soussign&eacute;s, <span style="text-transform: uppercase;"><?php echo ' '.  $account_business .' '; ?></span>, attestons(1) par la pr&eacute;sente que 
        <?php if($encaissement->Mode_19 == '5') :?>
            <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
            <table style="font-family: Courier New;">
                    <tr>
                        <td>a effectu&eacute; un paiement de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td>
                    </tr>
                    <tr rowspan="3">
                        <td colspan="3"><?php echo "( ".$number_letter.") "; ?> </td>
                    </tr>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo $encaissement->Typerecette_17; ?></td>
                    </tr>
                   
                    <tr>
                        <td>Suivant la &nbsp;<?php echo $typeDoc[$encaissement->Notetype_25]; ?></td>
                        <td>:</td>
                        <td>&nbsp;N&ordm; <?php echo $encaissement->Noteid_26; ?>  du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement</td>
                        <td>:</td>
                        <td>&nbsp;<?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></span></td>
                    </tr>
            </table>
        <?php else: ?>
                <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> 
                <table style="font-family: Courier New;">
                    <tr>
                        <td>a effectu&eacute; un paiement de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td>
                    </tr>
                    <tr rowspan="2">
                        <td colspan="3"><?php echo "( ".$number_letter.") "; ?> P/C de  <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span></td>
                    </tr>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo $encaissement->Typerecette_17; ?></td>
                    </tr>
                   
                    <tr>
                        <td>Suivant la &nbsp;<?php echo $typeDoc[$encaissement->Notetype_25]; ?></td>
                        <td>:</td>
                        <td>&nbsp;N&ordm; <?php echo $encaissement->Noteid_26; ?>  du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement</td>
                        <td>:</td>
                        <td>&nbsp;<span style="font-weight: bold;"><?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></span></td>
                    </tr>
                </table>
        <?php endif;?>
    </p>
    
    <div style=" padding-top: 20px; font-family: Courier New;">
        <p align="right">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d/%m/%Y',strtotime(gmdate('d/m/Y'))); ?><br>
        </p>
    </div>
    
</span>
</body>
</html>



