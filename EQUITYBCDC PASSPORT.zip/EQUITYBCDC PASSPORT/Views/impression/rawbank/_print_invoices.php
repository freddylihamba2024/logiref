<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
  
</style>

<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <?php $page = $_SESSION['account_logo']; ?>
        <?php if(isset($page) && $page != '') $logo =$page; else $logo = base_url('ikwook_files').'/logos/nologo.png'; ?>
        <td style="width:350px; font-size:1.1em;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
        </td>
        <td style="font-size:1.2em; font-weight: bold; position: absolute">
            &nbsp;&nbsp;RAPPORT DES FACTURES NON VALIDES
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Identifiant</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>R&eacute;f&eacute;rence</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>N° dossier</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Type</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>D&eacute;biteur</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Cr&eacute;diteur</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date statut</b></td>
    </tr>

    <?php $i=2; foreach($invoices as $invoice): ?>
            <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                <td width="9%" style="font-size:0.8em;"><?php echo strftime('%d-%m-%Y',strtotime($invoice->Date_1)); ?></td>
                <td style="font-size:0.8em;"><?php echo $invoice->Factureid_5; ?></td>
                <td style="font-size:0.8em;"><?php echo $invoice->Reference_7; ?></td>
                <td style="font-size:0.8em;"><?php echo $invoice->Refbfu_9; ?></td>
                <td width="15%" style="font-size:0.8em;"><?php echo $invoice->Typefacture_23; ?></td>
                <td width="15%" style="font-size:0.8em;"><?php echo $invoice->Debiteur_25; ?></td>
                <td width="15%" style="font-size:0.8em;"><?php echo $invoice->Creditaire_26; ?></td>
                <td width="15%" style="font-size:0.8em;"><?php  echo 'CDF '.number_format($invoice->Montant_11,2,","," ");?></td>
                <td width="15%" style="font-size:0.8em;"><?php echo strftime('%d-%m-%Y',strtotime($invoice->Datevaleur_13)); ?></td>

            </tr>
    <?php $i++; endforeach; ?>
</table>
