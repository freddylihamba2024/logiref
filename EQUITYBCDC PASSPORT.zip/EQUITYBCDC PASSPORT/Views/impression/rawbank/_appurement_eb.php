<html lang="en">  
    <head>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    </head>
    <title></title>
    <body style="padding: 20px 20px;">
        <table style="width: 100%; font-family: Courier New;">
            <tr>
                <td align ="right">
                    <div>
                        <p>Kinshasa, le 14 Janvier 2020 </p>
                    </div>
                </td>
            </tr>
           
        </table>
        <div style="float:left;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                   N/Réf: /TMB/KIN/OP/AT/YAN/2019
            </p><br>
        </div><br>
       
        <br><br><br><br>
        <div style="float:right;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                <b>PRIME TRUST TRADING SARL</b><br/>
                <b>N°01 AV DE LA pAIX GALLERIES</b> <br>
                <b>PRESIDENTIELLES 6eme Niveau APP</b> <br>
                <b style="text-decoration: underline;">KINSHASA-GOMBE</b>
            </p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br>
        <table style=" font-size:1.0em; font-family: Courier New;">
            <tr rowspan="3">
                <td colspan="3">
                    Messieurs,<br><br>
                    <b>Concerne: Apurement licence d'exportation DECL</b><br>
                </td> 
            </tr>
            <tr rowspan="3">
                <td colspan="3">
                    Nous vous signalons que la déclaration des biens reprose en marge arrive à écheance le date et a été partiellement payée à hauteur de USD montant, soit un solde de devise montant à rapatrier. 
                    En outre, les documents finaux ci-dessous ne nous sont pas parvenus:<br><br>
                    <ul>
                        <li>Le connaissement maritime(B/L)</li>
                        <li>Le connaissement maritime(B/L)</li><!--Recuperation des documents-->
                    </ul> <br>
                    En effet, conformément à l'article 32 alinéa 1 de la nouvelle réglementation du change, le rapatriement des recettes d'une exportation ordinaire doit intervenir au plus tard soixante jours calendriers à dater de la sortie des biens du territoire national pour une destination finale.<br><br><br>
                    Nous vous invitons d'une part, à repatrier le solde USD 11056,14 et d'autre part, à nous transmettre les documents cités c-haut avant la date extreme de validité, à defaut, nous nous verrons dans l'obligation de mettre en charge, toutes les pénalités éventuelles qui nous seraient infligées par la Banque Centrale du Congo pour non-respect de la Réglementation du change.<br><br><br><!-- comment --> 
                    En attendant, veuillez croire, Messieurs, à l'expression de notre franche collaboration <br>
                </td>
            
            </tr>
        </table>
                    <p style="text-decoration: underline; text-align: center;"><b>POUR LA TRUST MERCHANT BANK SA</b></p>

        
        </div>
        
    </body>
    
</html>