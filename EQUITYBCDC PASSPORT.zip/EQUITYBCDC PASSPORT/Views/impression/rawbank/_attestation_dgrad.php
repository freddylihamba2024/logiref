<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<?php 
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
       
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px;">
    <table style="width: 100%; font-family: Courier New;">
        <tr>
            <td align ="right">
                <div>
                    <p><?= isset($beneficiaires['Regies'][$encaissement->Beneficaire_15]) ? $beneficiaires['Regies'][$encaissement->Beneficaire_15] : ""; ?>&nbsp; N&deg;. <?php echo  $encaissement->Id_0;?> / <?php echo gmdate("Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    
    
<span style="padding-top: 300px;">
    <p style="font-size:1.0em; font-family: Courier New; text-align:justify; padding-top: 45px;">
        <?php if($encaissement->Mode_19 == '5') :?>
            <table style=" font-size:0.9em; font-family: Courier New;">
                    
                    <tr rowspan="3">
                        <td colspan="3">
                            Nous soussign&eacute;s, <span style="text-transform: uppercase; font-family: Courier New;"><?php echo ' '.$account_business.' '; ?></span>, attestons(1) par la pr&eacute;sente que <br>
                            <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>a effectu&eacute; un paiement de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td>
                    </tr>
                    <tr rowspan="3">
                        <td colspan="3"><?php echo "( ".$number_letter.") "; ?> </td>
                    </tr>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre</td>
                        <td>:</td>
                        <td>&nbsp;DE&nbsp;<?php echo $encaissement->Typerecette_17; ?></td>
                    </tr>
                   
                    <tr>
                        <td>Suivant la &nbsp;<span style="text-transform: lowercase;"><?php echo $typeDoc[$encaissement->Notetype_25];?></span> &nbsp;N&ordm;</td>
                        <td>:</td>
                        <td><?php echo $encaissement->Noteid_26; ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement</td>
                        <td>:</td>
                        <td>&nbsp;<?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19]?></span></td>
                    </tr>
            </table>
        <?php else: ?>
                <table style=" font-size:1.0em; font-family: Courier New;">
                    <tr rowspan="3">
                        <td colspan="3">
                            Nous soussign&eacute;s, <span><?php echo ' '.$account_business.' '; ?></span>, attestons(1) par la pr&eacute;sente que <br>
                            <?php if(isset($infos['accountname']) && $infos['accountname'] == $encaissement->Designation_14){ ?>
                                <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
                            <?php }else{ ?>
                                <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> P/C  <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
                            <?php } ?>
                        </td>
                    </tr>
                    <tr>
                        <td>a effectu&eacute; un paiement de</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <?php echo "( ".$number_letter.") "; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre </td>
                        <td>:</td>
                        <td>&nbsp;DE&nbsp;<?php echo $encaissement->Typerecette_17; ?></td>
                    </tr>
                   
                    <tr>
                        <td>Suivant la &nbsp;<span style="text-transform: lowercase;"><?php echo $typeDoc[$encaissement->Notetype_25]; ?></span>&nbsp;n&ordm;</td>
                        <td>:</td>
                        <td>&nbsp;<?php echo $encaissement->Noteid_26; ?>  DU <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Notedate_27)); ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement</td>
                        <td>:</td>
                        <td>&nbsp;<?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></td>
                    </tr>
                </table>
        <?php endif;?>
    </p>
    
    <div style=" padding-top: 20px; font-family: Courier New;" align="center">
        
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo ($jour.' '. $months_abrv[$mois] .' '. $annee); ?><br>
        
    </div>
    
</span>
</body>
</html>

