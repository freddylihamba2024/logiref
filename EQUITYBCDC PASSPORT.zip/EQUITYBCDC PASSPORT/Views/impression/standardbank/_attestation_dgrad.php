<?php 
$infos = json_decode($encaissement->Notereference_30, true);
$date_valeur = explode('-', $encaissement->Datevaleur_31);
if (count($date_valeur) == 3) {
    $jour  = $date_valeur[2];
    $mois  = $date_valeur[1];
    $annee = $date_valeur[0];
}
?>

<html lang="fr">
<head>
    <meta charset="UTF-8">
</head>

<body style="margin-top:4.5cm; margin-left:3.8cm; margin-right:3.8cm; margin-bottom:2.5cm; font-family:'Courrier New', serif; font-size:12px; color:#000; line-height:1.5;">

    <div style="padding-top: 80px;margin-left: 5%; margin-right: 5%;">
        <!-- TITRE PRINCIPAL -->
        <div style="text-align:center; font-size:18px; font-weight:bold; text-decoration:underline;">
            ATTESTATION DE PAIEMENT
        </div>

        <div style="text-align:center; font-size:13px; margin-top:10px; text-decoration:underline;">
            N° <?= $number; ?>/DGRAD/<?= gmdate("Y"); ?>
        </div>

        <!-- INTRO -->
        <p style="text-align:justify; font-size:12px; margin-top:30px;">
            Nous soussignés <strong><?= $account_business; ?></strong>, attestons par la présente avoir effectué en faveur de la <strong>D.G.I</strong>, le paiement dont les détails sont repris ci-dessous :
        </p>

        <!-- TABLEAU -->
        <table style="width:100%; margin-top:15px; font-size:12px; border-collapse:collapse;">
            <tr>
                <td style="width:45%; padding:6px 2px;">Donneur d'ordre</td>
                <td style="width:5%; padding:6px 2px;">:</td>
                <td style="width:50%; padding:6px 2px;">
                    <?php if (!isset($infos['pourcompte'])): ?>
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14; ?></strong>
                    <?php else: ?>
                        <strong style="text-transform:uppercase;"><?= $infos['accountname']; ?></strong>
                        &nbsp;P/C&nbsp;
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14; ?></strong>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Mode de paiement / Référence</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $modes[$encaissement->Mode_19] ?? ""; ?> 
                    <?= ($encaissement->Reference_32!="") ? "/ ".$encaissement->Reference_32:"" ?>
                </td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">N° Impôt</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><?= $encaissement->Nif_13; ?></td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">N° titre de paiement</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><?= $encaissement->Noteid_26; ?></td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Nature / Code recette</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><strong><?= $recettes["DGRAD"][$encaissement->Typerecette_17] ?? ''; ?></strong></td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Montant payé</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $encaissement->Devise_12 . ' ' . number_format($encaissement->Montant_11,2,","," "); ?>
                    <?= " ( ".$number_letter.") "; ?>
                </td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Référence de paiement</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><?= ($cbs_return[$instrcutions[0]->Id_0]['Num_evenement']) ?? ""; ?></td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Code Service gestionnaire</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><?= $services[$encaissement->Service_16] ?? "" ; ?></td>
            </tr>
        </table>

        <!-- DATE -->
        <div style="text-align:right; margin-top:80px; font-size:12px; font-weight:bold;">
            <?= isset($ville) && $ville != "" ? ucfirst(strtolower($ville)) : "..............." ?>,
            Le <?= $jour.'/'.$mois.'/'.$annee ?>
        </div>

        <!-- SIGNATURE -->
        <div style="text-align:center; margin-top:5px; font-size:14px;">
            Signatures autorisées
        </div>

        <!-- QR CODE -->
        <div style="text-align:center; margin-top:5px;">
            <?= $qrcode ?>
        </div>

        <!-- NOTE FINALE CENTRÉE -->
        <p style="margin-top:20px; font-size:11px; text-align:center;">
            <u>Note importante :</u>
            Cette attestation n'est valable que si elle est revêtue du
            <strong>cachet de la banque et du QR Code</strong>.
        </p>
    </div>

</body>
</html>
