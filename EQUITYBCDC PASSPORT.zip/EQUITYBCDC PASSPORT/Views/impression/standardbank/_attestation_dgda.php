<?php 

    $infos = json_decode($encaissements->Notereference_30, true);

    #var_dump($infos);die;


    $date_valeur = explode('-',$encaissements->Datevaleur_31 );
    if(count($date_valeur) == 3)
    {
            $jour = $date_valeur[2];
            $mois = $date_valeur[1];
            $annee =$date_valeur[0];
    }

    $date_valeur = explode('-',$encaissements->Datevaleur_31 );
    if(count($date_valeur) == 3)
    {
            $jour = $date_valeur[2];
            $mois = $date_valeur[1];
            $annee =$date_valeur[0];
    }
       
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    
     <div style=" padding-top: 45px;">
        <p><b>Code BCC:&nbsp;2001</b></p>
        <p style=" border-top: 3px solid black;" align="right">
            <br><span style="text-transform: uppercase; padding-top: 5px;"><?php echo (isset($ville) && $ville !="" )? $ville :'..............';?></span>, le <?php echo $jour.'/'. $mois.'/'. $annee; ?><br>
        </p>
    </div>
 
    <div style="padding-top: 20px;">
        <p align="center" style="color:black; padding-top: 40px; font: caption 1.3em  sans-serif;  padding: 2px;"><span >ATTESTATION D'ENCAISSEMENT<br></span><u> Standard Bank DRC/<?= isset($cbs_return['Num_evenement']) ? $cbs_return['Num_evenement'] : ""; ?>/GU/<?php echo $annee; ?><span style="font-weight: bold;"></u></p>
        <p align="center" style="color:black; padding-top: 10px; font: bold caption 1em  sans-serif;">&nbsp;&nbsp;&nbsp;&nbsp; <u>BUREAU GUICHET UNIQUE: N&deg;<?php echo $encaissements->Service_16;?> </u> <span style="font-weight: bold;"> </span> &nbsp;&nbsp;&nbsp;&nbsp;</p>
    </div> 
  
      
    <div style=" border: 3px solid black; height: 200px; font-size: 1.0em; padding-top: 20px;"> 
        <table style="font-size:1em; font-family: sans-serif;">
            <tr rowspan="3">
                <td colspan="3">
                    Nous soussign&eacute;s <span style="font-weight: bold;"><?php echo $account_business; ?>&nbsp;AGENCE:<?php echo (isset($agences) && $agences !="" )? $agences :'..............';?></span>, attestons avoir encaiss&eacute; le paiement &nbsp;en faveur de la r&eacute;gie ci-haut identifi&eacute;e, suivant d&eacute;tails ci-apr&egrave;s:
                </td>
            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Identit&eacute;s Du Client</td>
                <td style="white-space: nowrap;">:
                    <?php if (!isset($infos['pourcompte'])){?>
                        <span style="text-transform: uppercase;"><?php echo $encaissements->Designation_14; ?></span>
                    <?php } else { ?>
                            <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span>&nbsp;P/C DE <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo $encaissements->Designation_14; ?></span>

                    <?php }?>
                </td>
            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td style="white-space: nowrap;">Identit&eacute;s Du D&eacute;clarant</td>
                <td>: <?php echo $encaissements->Noteid_26; ?></td>
            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td style="white-space: nowrap;">Bulletin De Liquidation</td>
                <td>: <?php echo $encaissements->Noteid_26; ?> DU <?php echo strftime('%d/%m/%Y',strtotime($encaissements->Notedate_27)); ?></td>
            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td style="white-space: nowrap;">Quittance</td>
                <td>: <?php echo (isset($infos["quittanceid"]))? $infos["quittanceid"]: ''; ?> DU <?php echo strftime('%d/%m/%Y',strtotime($encaissements->Notedate_27)); ?></td>
            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
           <tr>
                <td>Montant encaiss&eacute;:&nbsp;en chiffres</td>
                <td style="white-space: nowrap;">: <?php echo number_format($encaissements->Montant_11,2,","," "); ?></td>

            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
            
           <tr>
                <td style="white-space: nowrap;">
                     <ul>
                         <li style="white-space: nowrap;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En chiffres:&nbsp;<?php echo $encaissements->Devise_12;?> <?php echo number_format($encaissements->Montant_11,2,","," "); ?> </li><br><br>
                         <li style="white-space: nowrap;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;En lettres&nbsp;:&nbsp; <span style="text-transform: uppercase;"><?php echo $number_letter ; ?> </span></li><br><br><br>
                     </ul>
                </td>

            </tr>
              
            <tr>
                <td></td>
                <td></td>
            </tr>
             <tr>
                <td></td>
                <td></td>
            </tr>
        </table>

       <p>&nbsp;NB: <span align="justify">La pr&eacute;sente n'est pas valable si elle porte des ratures, surchages,transport en &nbsp;marge ou si elle &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;se pr&eacute;sente sous forme de photocopie
              de l'authenticit&eacute; &eacute;tant &nbsp;attest&eacute;e par le timbre, le checker &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;et le sceau de la Banque.</span></p>
           
    </div>
  
       
    
    <p style="font-weight: bold; padding-top: 2px;" align="center">
    <u>Pour la STANDARD BANK DRC</u>
    </p>
</body>

</html>