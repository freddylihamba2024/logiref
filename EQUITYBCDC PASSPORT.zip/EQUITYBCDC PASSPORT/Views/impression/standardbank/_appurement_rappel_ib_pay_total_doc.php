<html lang="en">  
    <head>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    </head>
    <title></title>
    <body style="padding: 20px 20px;">
        <table style="width: 100%; font-family: Courier New;">
            <tr>
                <td align ="right">
                    <div>
                        <p>Kinshasa, le 14 Janvier 2020 </p>
                    </div>
                </td>
            </tr>
           
        </table>
        <div style="float:left;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                   N/Réf: /TMB/KIN/OP/AT/YAN/2019
            </p><br>
        </div><br>
       
        <br><br><br><br>
        <div style="float:right;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                <b>PRIME TRUST TRADING SARL</b><br/>
                <b>N°01 AV DE LA pAIX GALLERIES</b> <br>
                <b>PRESIDENTIELLES 6eme Niveau APP</b> <br>
                <b style="text-decoration: underline;">KINSHASA-GOMBE</b>
            </p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br>
        <table style=" font-size:1.0em; font-family: Courier New;">
            <tr rowspan="3">
                <td colspan="3">
                    Messieurs,<br><br>
                    <b>Concerne: Rappel apurement de vos important</b><br>
                    <span style="text-decoration: underline;">N/Ref: 0048/TMB/KIN/Op/JON/24</span><br>
                </td> 
            </tr>
            <tr rowspan="3">
                <td colspan="3">
                    Nous vous rappelons que votre declaration d'mportation DEC1211939-445IB a ete totalement payee en date du 07-08-2023.<br>
                    
                    Pour nous permettre de cloturer le dossier conformement a l'article	43 alinea 3 dela reglementation du change en vigueur en RDC , nous vous saunions gre de nous transmettre les documents finaux. <br>
                    Il s'agit de:<br>
                    <ul>
                        <li>La facture final</li>
                        <li>Le document de transport</li><!--Recuperation des documents-->
                        <li>L'attestation de vérification à l'importation</li><!--Recuperation des documents-->
                        <li>La declaration de mise en consommation douaniere</li><!--Recuperation des documents-->
          
                    </ul> <br>
                    Nous attirons votre attention sur le fait que les amendes et penalites sont preuves par les tarif et
                    conditions edictes par la Banques Central du congo a l'endroit des importanteurs non regle..<br><br><br><!-- comment --> 

                    Veuillez agreer, Messieurs , l'assurance de notre parfait considération. <br>
                </td>
            
            </tr>
        </table>
                    <p style="text-decoration: underline; text-align: center;"><b>POUR LA TRUST MERCHANT BANK SA</b></p>

        
    </body>
    
</html>