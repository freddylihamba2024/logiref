<?php 

$infos = json_decode($encaissement->Notereference_30, true);?>

<?php 
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
        
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
       
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
 
    
   <div style="padding-top: 20px;">
        <p align="center" style="color:black; padding-top: 40px; font: caption 1.3em  sans-serif;  padding: 2px;"><span ><b>ATTESTATION DE PAIEMENT</b><br></span><u> N&deg;<?= isset($cbs_return["Num_evenement"]) ? $cbs_return["Num_evenement"] : ""; ?><?php echo $annee; ?></u></p><br>
    </div> 
    <table style="font-size:1em; font-family: sans-serif;">
       <tr rowspan="3">
           <td colspan="3">
               Nous soussign&eacute;s <span style="font-weight: bold;"><?php echo $account_business; ?>&nbsp;</span>, attestons par la pr&eacute;sente avoir effectu&eacute; en faveur de la <b>DGI</b> le paiement dont d&eacute;tails ci-dessous:
           </td>
       </tr>
       <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
       <tr>
           <td style="white-space: nowrap;">
                Donneur d'ordre :&nbsp;<?php if (!isset($infos['pourcompte'])){?>
                   <b><span style="text-transform: uppercase; white-space: nowrap;"><?php echo $encaissement->Designation_14; ?></span></b>
               <?php } else { ?>
                       <b><span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span>&nbsp;P/C DE <span style="text-transform: uppercase;" style="font-weight: bold;"><?php echo $encaissement->Designation_14; ?></span></b>

               <?php }?>
           </td>
           <td>
           </td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">Nature de droit : &nbsp;<span><b><?php echo (isset($infos['Motif']))? $infos['Motif'] : ''; ?></span></b></td>
        </tr> 
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">Mode de paiement :&nbsp;<?php echo $encaissement->Nif_13; ?>
        </tr> 
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">Num&eacute;ro D&eacute;claration  :&nbsp;<?php echo $encaissement->Nif_13; ?>
        </tr> 
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">Code Service gestionnaire :&nbsp;<?php echo $services[$encaissement->Service_16] ?>
        </tr> 
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">N&deg; Imp&ocirc;t Fiscal :&nbsp;<?php echo $encaissement->Nif_13; ?></td>
        </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
        </tr>
       <tr>
           <td style="white-space: nowrap;">Montant payé en FC : &nbsp;<?php echo $encaissement->Devise_12;?> <?php echo number_format($encaissement->Montant_11,2,","," "); ?></td>
       </tr>
        <tr>
           <td></td>
           <td></td>
        </tr>
        <tr>
           <td></td>
           <td></td>
       </tr>
        <tr>
            <td style="white-space: nowrap;">R&eacute;f&eacute;rence de paiement : &nbsp;<?= isset($cbs_return["Num_evenement"]) ? $cbs_return["Num_evenement"] : ""; ?></td>
        </tr>
        <tr>
           <td style="white-space: nowrap;">En foi de quoi nous lui délivrons la présente attestation pour faire valoir ce que de droit.</td>
           <td></td>
        </tr>
   </table>
  
       
    <div style="padding-top: 50px;  font-size: 15px;">
        <p align="center">
            </br></br>
            Signatures autoris&eacute;es
        </p></br>
    </div>
    

   
    <div style="padding-top: 100px;  font-size: 15px;">    <p align="justify">
            </br></br></br></br></br></br>
            <u>Note importante</u>
            Cette attestation n'est valable que si elle est revêtue du <b>cachet de la banque et du QR Code</b>
        </p></br>

    </div>


    
</body>

</html>