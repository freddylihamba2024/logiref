<?php 
$infos = json_decode($encaissement->Notereference_30, true);

$date = explode('-', $infos["standard"] ?? "");
if (count($date) == 3) {
    $periode_mois = $date[1];
    $periode_annee = $date[0];
} elseif (count($date) == 2) {
    $periode_mois = $date[0];
    $periode_annee = $date[1];
} else {
    $periode_mois = "";
    $periode_annee = "";
}

$date_valeur = explode('-', $encaissement->Datevaleur_31);
if (count($date_valeur) == 3) {
    $jour = $date_valeur[2];
    $mois = $date_valeur[1];
    $annee = $date_valeur[0];
}
?>

<html lang="fr">
<head>
    <meta charset="UTF-8">
</head>

<body style="margin-top:4.5cm; margin-left:3.8cm; margin-right:3.8cm; margin-bottom:2.5cm; font-family:'Times New Roman', serif; font-size:12px; color:#000; line-height:1.5;">

    <div style="padding-top:60px; margin-left:5%; margin-right:5%;">

        <!-- TITRE -->
        <div style="text-align:center; font-size:18px; font-weight:bold; text-decoration:underline;">
            ATTESTATION DE PAIEMENT
        </div>

        <div style="text-align:center; font-size:13px; margin-top:10px; text-decoration:underline;">
            N° <?= $number; ?>/
                <?php
                if (!empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINPP'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasONEM'])
                ): ?>
                    <?= "DGI" ?>
                <?php elseif (!empty($infos['QuotasINPP'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasONEM'])
                ): ?>
                    <?= "INPP" ?>
                <?php elseif (!empty($infos['QuotasONEM'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasINPP'])
                ): ?>
                    <?= "ONEM" ?>
                <?php elseif (!empty($infos['QuotasINSS'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasONEM'])
                    && empty($infos['QuotasINPP'])
                ): ?>
                    <?= "CNSS" ?>
                <?php else: ?>
                    <?= "DGI, ONEM, INPP et CNSS" ?>
                <?php endif; ?>
                /<?= $annee ?>
        </div>

        <!-- INTRO -->
        <p style="text-align:justify; font-size:10px; margin-top:30px;">
            Nous soussignés <strong><?= $account_business ?></strong>, attestons par la présente
            avoir effectué en faveur de 
            <strong>
                <?php
                if (!empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINPP'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasONEM'])
                ): ?>
                    <?= "la DGI" ?>
                <?php elseif (!empty($infos['QuotasINPP'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasONEM'])
                ): ?>
                    <?= "l' INPP" ?>
                <?php elseif (!empty($infos['QuotasONEM'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasINSS'])
                    && empty($infos['QuotasINPP'])
                ): ?>
                    <?= "l' ONEM" ?>
                <?php elseif (!empty($infos['QuotasINSS'])
                    && empty($infos['QuotasDGI'])
                    && empty($infos['QuotasONEM'])
                    && empty($infos['QuotasINPP'])
                ): ?>
                    <?= "la CNSS" ?>
                <?php else: ?>
                    <?= "la DGI, ONEM, INPP et CNSS" ?>
                <?php endif; ?>
            </strong>, le paiement dont les détails sont repris ci-dessous :
        </p>

        <!-- TABLEAU PRINCIPAL -->
        <table style="width:100%; margin-top:5px; font-size:10px; border-collapse:collapse;">
            <tr>
                <td style="width:45%; padding:6px 2px;">Donneur d'ordre</td>
                <td style="">:</td>
                <td style="width:55%; padding:6px 2px;">
                    <?php if (!isset($infos['pourcompte'])): ?>
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14 ?></strong>
                    <?php else: ?>
                        <strong style="text-transform:uppercase;"><?= $infos['accountname'] ?></strong>
                        &nbsp;P/C&nbsp;
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14 ?></strong>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Nature de droit</td>
                <td style="padding:6px 2px;">:</td>
                <td style="padding:6px 2px;">
                    <strong><?= $recettes["DGI"][$encaissement->Typerecette_17] ?? ''; ?></strong>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Période</td>
                <td style="padding:6px 2px;">:</td>
                <td style="padding:6px 2px;">
                    <strong><?= $months[$periode_mois].'  '.$periode_annee  ?></strong>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Mode de paiement / Référence</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $modes[$encaissement->Mode_19] ?? ""; ?> 
                    <?= ($encaissement->Reference_32!="") ? "/ ".$encaissement->Reference_32:"" ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Numéro Déclaration</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $encaissement->Noteid_26 ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Code Service gestionnaire</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $services[$encaissement->Service_16] ?? "" ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">N° Impôt Fiscal</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $encaissement->Nif_13 ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Montant payé</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $encaissement->Devise_12 . " " . number_format($encaissement->Montant_11,2,","," "); ?>
                    <?= " ( ".$number_letter.") "; ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Référence de paiement</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= ($cbs_return[$instrcutions[0]->Id_0]['Num_evenement']) ?? ""; ?>
                </td>
            </tr>
        </table>

        <!-- TABLEAU DES QUOTAS -->
        <table style="font-size:10px; width:80%; margin:10px auto; border:2px solid #000; border-collapse:collapse; text-align:center;">
            <tr>
                <th style="border:1px solid #000; padding:6px;">Structure bénéficiaire</th>
                <th style="border:1px solid #000; padding:6px;">Montant payé</th>
                <th style="border:1px solid #000; padding:6px;">Mode de paiement</th>
                <th style="border:1px solid #000; padding:6px;">Banque</th>
            </tr>

            <tr>
                <td style="border:1px solid #000; padding:6px;">IPR - EIR (DGI)</td>
                <td style="border:1px solid #000; padding:6px;"><?= $encaissement->Devise_12 . ' ' . number_format(($infos['QuotasDGI'] ?? 0),2,","," "); ?></td>
                <td style="border:1px solid #000; padding:6px;"><strong>ISYS-REGIES</strong></td>
                <td style="border:1px solid #000; padding:6px;"><strong>BCC</strong></td>
            </tr>

            <tr>
                <td style="border:1px solid #000; padding:6px;">ONEM</td>
                <td style="border:1px solid #000; padding:6px;"><?= $encaissement->Devise_12 . ' ' . number_format(($infos['QuotasONEM'] ?? 0),2,","," "); ?></td>
                <td style="border:1px solid #000; padding:6px;"><strong>VIREMENT</strong></td>
                <td style="border:1px solid #000; padding:6px;"><strong>Standard Bank</strong></td>
            </tr>

            <tr>
                <td style="border:1px solid #000; padding:6px;">INPP</td>
                <td style="border:1px solid #000; padding:6px;"><?= $encaissement->Devise_12 . ' ' . number_format(($infos['QuotasINPP'] ?? 0),2,","," "); ?></td>
                <td style="border:1px solid #000; padding:6px;"><strong>VIREMENT</strong></td>
                <td style="border:1px solid #000; padding:6px;"><strong>Standard Bank</strong></td>
            </tr>

            <tr>
                <td style="border:1px solid #000; padding:6px;">CNSS</td>
                <td style="border:1px solid #000; padding:6px;"><?= $encaissement->Devise_12 . ' ' . number_format(($infos['QuotasINSS'] ?? 0),2,","," "); ?></td>
                <td style="border:1px solid #000; padding:6px;"><strong>VIREMENT</strong></td>
                <td style="border:1px solid #000; padding:6px;"><strong>Standard Bank</strong></td>
            </tr>

            <tr>
                <td style="border:1px solid #000; padding:6px;"><strong>TOTAL</strong></td>
                <td style="border:1px solid #000; padding:6px;">
                    <strong><?= number_format(
                        ($infos['QuotasDGI'] ?? 0) + ($infos['QuotasONEM'] ?? 0) + ($infos['QuotasINPP'] ?? 0) + ($infos['QuotasINSS'] ?? 0),
                    2,","," "); ?></strong>
                </td>
                <td colspan="2" style="border:1px solid #000; padding:6px;">
                    <?php if ($encaissement->Devise_12 == 'CDF'):  ?>
                        <em><b>Francs Congolais (CDF)</b></em>
                    <?php else: ?>
                        <em><b>Dollars Americain (USD)</b></em>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <!-- DATE -->
        <div style="text-align:right; margin-top:5px;  font-size:10px; font-weight:bold;">
            <?= isset($ville) && $ville != "" ? ucfirst(strtolower($ville)) : "..............." ?>,
            Le <?= $jour.'/'.$mois.'/'.$annee ?>
        </div>

        <!-- SIGNATURE -->
        <div style="text-align:center; margin-top:5px; font-size:14px;">
            Signatures autorisées
        </div>

        <!-- QR CODE -->
        <div style="text-align:center; margin-top:5px;">
            <?= $qrcode ?>
        </div>

        <!-- NOTE FINALE -->
        <p style="margin-top:5px; font-size:11px; text-align:center;">
            <u>Note importante :</u>
            Cette attestation n'est valable que si elle est revêtue du 
            <strong>cachet de la banque et du QR Code</strong>.
        </p>

    </div>

</body>
</html>
