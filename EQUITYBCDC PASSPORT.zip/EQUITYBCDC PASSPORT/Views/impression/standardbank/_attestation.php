<?php $infos = json_decode($encaissement->Notereference_30, true);?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    <table style="width: 100%">
        <tr>
            <td align ="right">
                <div>
                    <p><?= isset($beneficiaires['Regies'][$encaissement->Beneficaire_15]) ? $beneficiaires['Regies'][$encaissement->Beneficaire_15] : ""; ?> / <?php echo  $encaissement->Id_0;?> / <?php echo gmdate("Y"); ?> </p>
                </div>
            </td>
        </tr>
    </table>
    
    
<span style="padding-top: 300px;">
    <p style="text-align:justify; padding-top: 80px;">
        Nous soussign&eacute;s <span style="text-transform: uppercase;"><?php echo ' '.$this->session->userdata('account_business').' '; ?></span>RDC attestons par la pr&eacute;sente que 
        <?php if($encaissement->Mode_19 == '5') :?>
            le contribuable  <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span> a effectu&eacute;(e) un paiement de <span style="font-weight: bold;"><?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?></span>
            <table>
                <tr>
                    <td>en faveur de la <?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]; ?>  au titre de &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $recettes[$beneficiaires['Regies'][$encaissement->Beneficaire_15]][$encaissement->Typerecette_17]; ?>.</td>
                </tr>
                <tr>
                    <td>Suivant  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp; DEC MENS UNIQUE du <?php echo strftime('%d-%m-%Y',strtotime($encaissement->Notedate_27)); ?></td>
                </tr>
                <tr>
                    <td>Mode de paiement &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?> </td>
                </tr>
            </table>
        <?php else: ?>
            <?php if(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == 'DGI' && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != 'IPRIER'){ ?>
            <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> a effectu&eacute;(e) un paiement de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?> pour le contibuable <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
            <table>
                <tr>
                    <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre de</td>
                    <td>:</td>
                    <td><?php echo $recettes[$beneficiaires['Regies'][$encaissement->Beneficaire_15]][$encaissement->Typerecette_17]; ?>.</td>
                </tr>
                <tr>
                    <td>Suivant</td>
                    <td>:</td>
                    <td>DEC du <?php echo strftime('%d-%m-%Y',strtotime($encaissement->Notedate_27)); ?></td>
                </tr>
                <tr>
                    <td>Mode de paiement </td>
                    <td>:</td>
                    <td><span style="font-weight: bold;"><?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></span></td>
                </tr>
            </table>
            <?php }elseif(isset($encaissement->Beneficaire_15) && $encaissement->Beneficaire_15 == 'DGI' && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'IPRIER'){ ?>
                <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> a effectu&eacute;(e) un paiement de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?> pour le contibuable <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
                <table>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre de</td>
                        <td>:</td>
                        <td>PMT IPR-ONEM-INPP-CNSS</td>
                    </tr>
                    <tr>
                        <td>Suivant</td>
                        <td>:</td>
                        <td>DEC MENS UNIQ DU <?php echo strftime('%d-%m-%Y',strtotime($encaissement->Notedate_27)); ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement:&nbsp; </td>
                        <td>:</td>
                        <td><span style="font-weight: bold;"><?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></span></td>
                    </tr>
                </table>
            <?php }else{ ?>
                <span style="text-transform: uppercase;"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> a effectu&eacute;(e) un paiement de <?php echo 'CDF '.number_format($encaissement->Contrevaleur_22,2,","," "); ?> pour le contibuable <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_14; ?></span>
                <table>
                    <tr>
                        <td>en faveur de la <?php echo $encaissement->Beneficaire_15; ?> au titre de</td>
                        <td>:</td>
                        <td><?php echo $recettes[$beneficiaires['Regies'][$encaissement->Beneficaire_15]][$encaissement->Typerecette_17]; ?>.</td>
                    </tr>
                    <tr>
                        <td>Suivant la &nbsp;<?php echo $typeDoc[$encaissement->Notetype_25]; ?></td>
                        <td>:</td>
                        <td>N&ordm; <?php echo $encaissement->Noteid_26; ?>  du <?php echo strftime('%d-%m-%Y',strtotime($encaissement->Notedate_27)); ?></td>
                    </tr>
                    <tr>
                        <td>Mode de paiement</td>
                        <td>:</td>
                        <td><span style="font-weight: bold;"><?php if (isset($modes[$encaissement->Mode_19]))echo $modes[$encaissement->Mode_19].' '.$encaissement->Reference_32;?></span></td>
                    </tr>
                </table>
            <?php } ?>
        <?php endif;?>
    </p>
    
    <div style=" padding-top: 20px;">
        <p align="right">
            Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo strftime('%d-%m-%Y',strtotime(gmdate('d-m-Y'))); ?>.<br>
        </p>
    </div>
    
</span>
</body>
</html>

