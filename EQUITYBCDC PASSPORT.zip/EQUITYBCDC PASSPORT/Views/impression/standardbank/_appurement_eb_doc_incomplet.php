<html lang="en">  
    <head>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    </head>
    <title></title>
    <body style="padding: 20px 20px;">
        <table style="width: 100%; font-family: Courier New;">
            <tr>
                <td align ="right">
                    <div>
                        <p>Kinshasa, le 14 Janvier 2020 </p>
                    </div>
                </td>
            </tr>
           
        </table>
        <div style="float:left;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                   N/Réf: /TMB/KIN/OP/AT/YAN/2019
            </p><br>
        </div><br>
       
        <br><br><br><br>
        <div style="float:right;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                <b>PRIME TRUST TRADING SARL</b><br/>
                <b>N°01 AV DE LA pAIX GALLERIES</b> <br>
                <b>PRESIDENTIELLES 6eme Niveau APP</b> <br>
                <b style="text-decoration: underline;">KINSHASA-GOMBE</b>
            </p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br>
        <table style=" font-size:1.0em; font-family: Courier New;">
            <tr rowspan="3">
                <td colspan="3">
                    Messieurs,<br><br>
                    <b>Concerne: Apurement de vos exportations</b><br>
                </td> 
            </tr>
            <tr rowspan="3">
                <td colspan="3">
                    Conformément aux dispositions de la réglementation du change en vigueur en RDC en son article 30 alinéa 2, nous vous saurions gré de nous transmettre les documents finaux de vos déclarations d'exportation des biens suivant le tableau en annexe<br><br>
                    <br>
                     Nous attirons votre attention sur le fait que les amendes et pénalités sont prévues par les tarifs et conditions édictés par la Banque Centrale du Congo à l'endroit des importateurs non en règle.<br>
                     
                     Veuillez agréer, <b>Messieurs</b>, l'assurance de notre parfaite considération.<br>
                </td>
            
            </tr>
        </table>
        <p style="text-decoration: underline; text-align: center;"><b>POUR LA TRUST MERCHANT BANK SA</b></p>

        
    </body>
    
</html>