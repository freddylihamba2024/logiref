<html lang="en">  
    <head>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    </head>
    <title></title>
    <body style="padding: 20px 20px;">
        <table style="width: 100%; font-family: Courier New;">
            <tr>
                <td align ="right">
                    <div>
                        <p>Kinshasa, le 14 Janvier 2020 </p>
                    </div>
                </td>
            </tr>
           
        </table>
        <div style="float:left;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                   N/Réf: /TMB/KIN/OP/AT/YAN/2019
            </p><br>
        </div><br>
       
        <br><br><br><br>
        <div style="float:right;width:40%; margin-left:-20px;">
            <p style="font-size: 0.9em; text-align: center;">
                <b>BUSIRA LOMAMI</b><br/>
                <b>N°01 AV DE LA pAIX GALLERIES</b> <br>
                <b>PRESIDENTIELLES 6eme Niveau APP</b> <br>
                <b style="text-decoration: underline;">KINSHASA-LIMETE</b>
            </p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br>
        <table style=" font-size:1.0em; font-family: Courier New;">
            <tr rowspan="3">
                <td colspan="3">
                    Messieurs,<br><br>
                    <b>Concerne: Apurement licence d'exportation DECL</b><br>
                </td> 
            </tr>
            <tr rowspan="3">
                <td colspan="3">
                    Nous vous signalons que la declaration d'exportation des biens reprise en marge arrive a echeance le 18/11/2020 alors q'elles n'as jamais ete apuree faute de rapatriement des fonds et du document d'export ci-dessous:<br><br>
                    <ul>
                        <li> Le certification de verification delivre par L'OCC</li>
                       <!--Recuperation des documents-->
                    </ul> <br>
                    Suivant l'article 32 alinea 2 de la nouvelle regelementation du change, le rapatriement des recettes
                    d'exportation en consignation doit intervenir des la vente de la marchandise et au plus a la date extreme
                    de validite de la declaration modele EB.<br><br><br>
                    Nous vous invitons a rapartrier et nous transmettre le document cites ci-haut avant la date extreme de
                    validite, a defaut, nous nous verrons dans l'obligation de mettre a votre charge , toutes les penilites 
                    eventuelles qui nous seraient infligees par la Banque central du congo pour non respect de la reglementions 
                    du Change.<br><br><br><!-- comment --> 
                    Enttendant, veullez croire, a l'expression de notre franche collaboration.<br>
                </td>
            
            </tr>
        </table>
                    <p style="text-decoration: underline; text-align: center;"><b>POUR LA TRUST MERCHANT BANK SA</b></p>

    
        
    </body>
    
</html>