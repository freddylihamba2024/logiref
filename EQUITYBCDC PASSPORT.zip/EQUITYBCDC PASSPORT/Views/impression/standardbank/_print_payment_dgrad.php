<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
</style>

<table>
        <tr style="margin-left:8px;">
                <td style="width:935px; font-size:1.1em;">
                </td>
                <td style="font-size:1.2em;">
                    <?php echo gmdate('d/m/Y'); ?>
                </td>
        </tr>
        <tr style="margin-left:8px;">
                <?php $page = $_SESSION['account_logo']; ?>
                <?php $logo = (isset($page) && $page != '') ? $page : base_url('ikwook_files').'/logos/nologo.png'; ?>
                <td style="width:350px; font-size:1.1em;">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
                </td>
        </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.1em;  ">RAPPORT DES PAIEMENTS DGRAD</p><br/>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
        <thead>
                <tr>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">#</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Date</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">R&eacute;gies</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Service</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Client</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Montant</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Commissions</td>
                        <td style="border-bottom:1px solid black; font-size:0.8em;">Agences</td>
                </tr>
        </thead>
        <tbody >
                <?php
                        $paiements = 0;
                        $commissions = 0;
                        $suspend = 0;
                        $urgent = 0;
                        $i = 2; $j = 0;

                    foreach($encaissements as $row):
                ?>
                <tr style="<?php if($i%2 == 0) echo "background-color:#ddd"; ?>">
                        <td width="5"><b><?php echo ++$j; ?></b></span></td>
                        <td><?php echo $row->Datevaleur_31?></td>
                        <td><b><?php echo $row->Beneficaire_15; ?></b></td>
                        <td><?php if(isset($services[$row->Service_16])) echo $services[$row->Service_16];?></td>
                        <td class="text-blue"><?php if($row->Designation_14 =="" && $row->Beneficaire_15 =="DGDA") echo "Bulletin de liquidation / ".$row->Nif_13; else echo $row->Designation_14; ?></td>
                        <td class="text-blue"><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?></td>
                        <td class="text-black"><?php echo $row->Devise_24.' '.number_format($row->Commission_23,2,","," "); ?></td>
                        <td><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
                        <?php if($row->Status_2==1 && $row->Checkerid_10==0): ?>
                        <td width="20">
                            <?php if($_SESSION['Logiref_role']==3 && $row->Agence_20==$_SESSION['Logiref_agence']):
                                echo '<span  class="text-red"> En attente </span>';
                            ?>
                            <?php else: ?>
                               <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder f14"> </span></a>
                            <?php endif; ?>
                        </td>
                        <?php else: ?>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', '<?php echo $row->Beneficaire_15; ?>')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                        </td>
                        <?php endif; ?>
                </tr>
                <?php 
                        $i++;
                        $paiements = $paiements + $row->Contrevaleur_22;
                        $commissions = $commissions + $row->Commission_23;
                        if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                        if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;

                    endforeach;
                ?>
        </tbody>
</table>