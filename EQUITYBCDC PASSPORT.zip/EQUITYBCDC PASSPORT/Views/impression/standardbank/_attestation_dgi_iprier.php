<?php 
$infos = json_decode($encaissement->Notereference_30, true);

$date = explode('-', $infos["standard"] ?? "");
if (count($date) == 3) {
    $periode_mois = $date[1];
    $periode_annee = $date[0];
} elseif (count($date) == 2) {
    $periode_mois = $date[0];
    $periode_annee = $date[1];
} else {
    $periode_mois = "";
    $periode_annee = "";
}

$date_valeur = explode('-', $encaissement->Datevaleur_31);
if (count($date_valeur) == 3) {
    $jour = $date_valeur[2];
    $mois = $date_valeur[1];
    $annee = $date_valeur[0];
}
?>

<html lang="fr">
<head>
    <meta charset="UTF-8">
</head>

<body style="margin-top:4.5cm; margin-left:3.8cm; margin-right:3.8cm; margin-bottom:2.5cm; font-family:'Times New Roman', serif; font-size:12px; color:#000; line-height:1.5;">

    <div style="padding-top:80px; margin-left:5%; margin-right:5%;">

        <!-- En-tête -->
        <!-- <table style="width:100%; font-size:12px;">
            <tr>
                <td style="text-align:left; font-weight:bold;">
                    BANQUE : 00029
                </td>
                <td style="text-align:right; font-weight:bold;">
                    <= isset($ville) && $ville != "" ? strtoupper($ville) : "..............." ?>,
                    le <= $jour.'/'.$mois.'/'.$annee ?>
                </td>
            </tr>
        </table> -->

        <!-- Titre principal -->
        <div style="margin-top:40px; text-align:center; font-size:18px; font-weight:bold; text-decoration:underline;">
            ATTESTATION D’ENCAISSEMENT
        </div>

        <div style="text-align:center; font-size:13px; margin-top:10px; text-decoration:underline;">
            <?= $number; ?>/DGI/<?= gmdate("Y"); ?>
        </div>

        <!-- Sous-titre -->
        <p style="margin-top:30px; font-weight:bold; text-align:justify;">
            RÉGIE BÉNÉFICIAIRE :

            <?php
            if (!empty($infos['QuotasDGI'])
                && empty($infos['QuotasINPP'])
                && empty($infos['QuotasINSS'])
                && empty($infos['QuotasONEM'])
            ): ?>
                <?= $beneficiaires['Regies'][$encaissement->Beneficaire_15] ?? "" ?>
                - <?= $service_type[$encaissement->Service_16] ?? "" ?>
                &nbsp;
            <?php elseif (!empty($infos['QuotasINPP'])
                && empty($infos['QuotasDGI'])
                && empty($infos['QuotasINSS'])
                && empty($infos['QuotasONEM'])
            ): ?>
                <?= "INPP" ?>
            <?php elseif (!empty($infos['QuotasONEM'])
                && empty($infos['QuotasDGI'])
                && empty($infos['QuotasINSS'])
                && empty($infos['QuotasINPP'])
            ): ?>
                <?= "ONEM" ?>
            <?php elseif (!empty($infos['QuotasINSS'])
                && empty($infos['QuotasDGI'])
                && empty($infos['QuotasONEM'])
                && empty($infos['QuotasINPP'])
            ): ?>
                <?= "CNSS" ?>
            <?php else: ?>
                <?= $beneficiaires['Regies'][$encaissement->Beneficaire_15] ?? "" ?>
                - <?= $service_type[$encaissement->Service_16] ?? "" ?>
                &nbsp; <?= "ONEM, INPP ET CNSS" ?>
            <?php endif; ?>
        </p>

        <!-- Introduction -->
        <p style="text-align:justify; margin-top:25px;">
            Nous soussignés <strong><?= $account_business ?></strong>, attestons par la présente
            avoir encaissé le paiement en faveur de la régie sus identifiée, suivant les détails ci-après :
        </p>

        <!-- Tableau d'informations -->
        <table style="width:100%; margin-top:25px; font-size:12px; border-collapse:collapse;">
            <tr>
                <td style="width:45%; padding:6px 2px;">Assujetti</td>
                <td style="width:5%; padding:6px 2px;">:</td>
                <td style="width:50%; padding:6px 2px;">
                    <?php if (!isset($infos['pourcompte'])): ?>
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14 ?></strong>
                    <?php else: ?>
                        <strong style="text-transform:uppercase;"><?= $infos['accountname'] ?></strong>
                        &nbsp;P/C&nbsp;
                        <strong style="text-transform:uppercase;"><?= $encaissement->Designation_14 ?></strong>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Numéro Impôt</td>
                <td style="">:</td>
                <td style="padding:6px 2px;"><?= $encaissement->Nif_13 ?></td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Montant payé</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $encaissement->Devise_12 . " " . number_format($encaissement->Montant_11,2,","," "); ?>
                    <?= " ( ".$number_letter.") "; ?>
                </td>
            </tr>

            <tr>
                <td style="padding:6px 2px;">Nature des impositions</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <?= $recettes["DGI"][$encaissement->Typerecette_17] ?? ''; ?>
                </td>
            </tr>
            <tr>
                <td style="padding:6px 2px;">Période</td>
                <td style="">:</td>
                <td style="padding:6px 2px;">
                    <strong><?= $months[$periode_mois].'  '.$periode_annee  ?></strong>
                </td>
            </tr>
        </table>

        <!-- DATE -->
        <div style="text-align:right; margin-top:15px; font-weight:bold;">
            <?= isset($ville) && $ville != "" ? ucfirst(strtolower($ville)) : "..............." ?>,
            Le <?= $jour.'/'.$mois.'/'.$annee ?>
        </div>

        <!-- Signature -->
        <div style="text-align:center; margin-top:50px; font-size:14px;">
            <u>Par Délégation</u>
        </div>

        <!-- QR CODE (ajout comme dans les 2 premières views) -->
        <div style="text-align:center; margin-top:20px;">
            <?= $qrcode ?>
        </div>

        <!-- Note finale -->
        <p style="margin-top:30px; font-size:11px; text-align:center;">
            <u>Note importante :</u>
            Cette attestation n'est valable que si elle est revêtue du
            <strong>cachet de la banque et du QR Code</strong>.
        </p>

    </div>

</body>
</html>
