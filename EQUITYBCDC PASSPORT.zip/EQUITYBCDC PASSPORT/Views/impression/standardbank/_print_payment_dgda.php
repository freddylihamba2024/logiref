<style>
    .img
    {
        width: 150px;
        height: 150px;
        margin-left: -2px
    }
    
    .head{
        border-bottom: 2px solid #000;
        width: 94%;
        margin-left: 2.9%;
    }
</style>

<table>
        <tr style="margin-left:8px;">
                <td style="width:935px; font-size:1.1em;">
                </td>
                <td style="font-size:1.2em;">
                    <?php echo gmdate('d/m/Y'); ?>
                </td>
        </tr>
        <tr style="margin-left:8px;">
                <?php $page = $_SESSION['account_logo']; ?>
                <?php $logo = (isset($page) && $page != '') ? $page : base_url('ikwook_files').'/logos/nologo.png'; ?>
                <td style="width:350px; font-size:1.1em;">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img class='img' src="<?php echo $logo; ?>" alt=""/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['account_business']; ?>
                </td>
        </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.1em;  ">RAPPORT DES PAIEMENTS DGDA</p><br/>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
        <thead>
                <tr>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">#</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Date</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Service</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Client</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Montant</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Commissions</td>
                        <td style="border-bottom:1px solid black; font-size:1.1em; ">Agences</td>
                </tr>
        </thead>
        <tbody >
                <?php
                    $i = 2; $j = 0;
                    
                    foreach($bulletins as $row) :

                        $operateur = (isset($users[$row->User_15]))? $users[$row->User_15] :' - ';
                        $dateTime = new DateTime($row->Integration_16); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+1 day",$date));
                        $results = json_decode($row->Results_13);
                        $recieptDate = explode("/",$results->receiptDate);
                        $nodeid = $recieptDate[2].''.$results->receiptSerial.''.$results->receiptNumber;
                ?>
                <tr style="<?php if($i%2 == 0) echo "background-color:#ddd"; ?>">
                        <td width="5"><b><?php echo ++$j; ?></b></span></td>
                        <td width="50" <?php if($row->Status_2==4) echo 'class="text-green"'; elseif($deadline > gmdate('Y-m-d')) echo 'class="text-black"'; elseif($deadline ==gmdate('Y-m-d')) echo 'class="text-orange"'; elseif($deadline < gmdate('Y-m-d')) echo 'class="text-red"';?>>
                            <?php echo $row->Integration_16; ?>
                        </td>
                        <td><?php echo $services['DGDA'][$row->Office_6]; ?></td>
                        <td class="text-blue"><?php if($row->Designation_23 =="") echo "Bulletin de liquidation / ".$row->Nif_9; else echo $row->Designation_23; ?></td>
                        <td class="text-blue">
                            <?php echo'CDF '.number_format($row->Amount_12,2,","," "); ?> 
                        </td>
                        <td class="text-black"><?php echo 'CDF '.number_format($row->Commission_26,2,","," "); ?></td>
                        <td><?= isset($guichets[$row->Agence_32]) ? $guichets[$row->Agence_32] : "-"; ?></td>
                        <td width="25">
                            <a style="cursor:pointer" onclick="view('<?php echo $row->Id_0; ?>', 'DGDA')" ><span class="fa fa-fw text-green fa-folder-open f14"> </span></a>
                        </td>
                </tr>
            <?php   $i++; endforeach;?>
        </tbody>
</table>