<table style="margin-left:8px;">
    <tr>
        <td style="width:935px; font-size:1.1em;">
        </td>
        <td style="font-size:1.2em;">
             <?php echo gmdate('d/m/Y'); ?>
        </td>
    </tr>
</table>
<table style="margin-left:8px;">
    <tr>
        <td style="font-size:1.2em; font-weight: bold">
            PAIEMENT DGI
        </td>
    </tr>
</table>

<p align="center" style="font-weight:bold; font-size:1.4em;  " class="head"></p><br/>

<table style="border-collapse: collapse;  margin-left:30px; margin-right:30px;" width="100%" cellspace="3" cellpadding="14">
    <tr>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Date</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Recette</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Service</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Client</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Montant</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Agences</b></td>
                                        <td style="border-bottom:1px solid black; font-size:0.8em;"><b>Saisi</b></td>
    </tr>

    <?php 
        $i=2;
                                            $paiements = 0;
                                            $commissions = 0;
                                            $suspend = 0;
                                            $urgent = 0;

                                            foreach ($encaissements as $row){
                                
                                        ?>
                                         <tr style="<?php if($i%2==0)echo"background-color:#ddd"; ?>">
                                            <td style="font-size:0.8em;" width="50"<?php if($row->Datevaleur_31 !==gmdate('Y-m-d')) echo 'class="text-red"'; ?>><?php echo $row->Date_1; ?></td>
                                            <td style="font-size:0.8em;"><b class="text-blue"><?php echo  $row->Typerecette_17; ?></b></td>
                                            <td style="font-size:0.8em;">
                                                <?php //if(isset($services[$row->Service_16])) echo $services[$row->Service_16];?>
                                                <?php  echo $row->Service_16;?>
                                            </td>
                                            <td style="font-size:0.8em;" class="text-blue" width='20%'><?php if($row->Designation_14 =="" && $row->Beneficaire_15 =="DGDA") echo "Bulletin de liquidation / ".$row->Nif_13; else echo $row->Designation_14; ?></td>
                                            <td style="font-size:0.8em;" class="text-blue" width='20%'><?php echo $row->Devise_12.' '.number_format($row->Montant_11,2,","," "); ?></td>
                                            <td style="font-size:0.8em;"><?= isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-"; ?></td>
                                            <td style="font-size:0.8em;"><?php echo(isset($users[$row->Makerid_9]))?$users[$row->Makerid_9]:' - ';?></td>
                                        </tr>
                                        <?php 
                                                $paiements = $paiements + $row->Contrevaleur_22;
                                                $commissions = $commissions + $row->Commission_23;
                                                if($row->Status_2==1 && $row->Checkerid_10==0) $suspend = $suspend + 1;
                                                if($row->Status_2==1 && $row->Checkerid_10==0 && $row->Datevaleur_31 !==gmdate('Y-m-d')) $urgent = $urgent + 1;
                                            } 
                                       ?>
                
                
</table>