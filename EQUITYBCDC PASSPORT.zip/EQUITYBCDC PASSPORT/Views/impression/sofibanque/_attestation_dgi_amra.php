<?php $infos = json_decode($encaissement->Notereference_30, true);
        $date= explode('-',$infos["standard"]);
        if(count($date) == 3)
        {
                $periode_mois = $date[1];
                $periode_annee = $date[0];
        }
        elseif(count($date) == 2)
        {
                $periode_mois = $date[0];
                $periode_annee = $date[1];
        }
        else
        {
                $periode_mois = "";
                $periode_annee = "";
        }
?>

<?php 
        $date_valeur = explode('-',$encaissement->Datevaleur_31 );
        if(count($date_valeur) == 3)
        {
                $jour = $date_valeur[2];
                $mois = $date_valeur[1];
                $annee =$date_valeur[0];
        }
      
?>
<html lang="en">  
<head>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<title></title>
<body style="padding: 20px 20px">
    
        <div style="padding-top: 150px; ">
            <h5 style="color:black; padding-top: 40px; font: bold caption 1em; text-align: center; font-size: 17px; border: 1px solid black; padding: 2px;">ATTESTATION DE PAIEMENT :  <?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]?>/<?php echo $service_type[$encaissement->Service_16] ?>_<?php echo $encaissement->Typerecette_17; ?> N&deg; <?php echo $number.'/'.substr($ville, 0,3); ?> /SFB/ <?php echo gmdate("Y"); ?> <span style="font-weight: bold;"> </span></h5>
            <p style=" padding-top:45px;text-align: justify;">
                La Soci&eacute;t&eacute; Financi&egrave;re de Banque <span style="text-transform: uppercase;">"<?php echo $account_business; ?>&nbsp;" </span> en sigle,<span style="text-transform: uppercase;"></span>&nbsp;atteste avoir encaiss&eacute; en date du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Datevaleur_31)); ?>&nbsp; de notre client:
                <?php if(!isset($infos['pourcompte'])){ ?>
                    <span style="text-transform: uppercase; font-weight: bold;"><?php echo $encaissement->Designation_14; ?></span>,
                <?php }else{ ?>
                    <span style="text-transform: uppercase;font-weight: bold"><?php echo (isset($infos['accountname']))? $infos['accountname'] :''; ?></span> P/C <span style="text-transform: uppercase; font-weight: bold"><?php echo $encaissement->Designation_14; ?> </span>,</span>
                <?php } ?> en faveur de la <?php echo $beneficiaires['Regies'][$encaissement->Beneficaire_15]?>/<?php echo $service_type[$encaissement->Service_16] ?>, la somme de <span style="font-weight: bold;"><?php echo $encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," "); ?> <?php echo " ( ".$number_letter.") "; ?></span>
                au titre de paiement <?php echo (isset($infos['Motif']))? $infos['Motif'] : ''; ?><?php //echo $months[$periode_mois].'  '.$periode_annee;?></span>.
            </p>
			
        </div>

        <div style="padding-top: 50px;  font-size: 15px;">
            <p>Mode de paiement: <?php echo $encaissement->Reference_32; ?></p><br><br>

             <p align="center">
                </br></br>
                En foi de quoi, la pr&eacute;sente attestation lui est d&eacute;livr&eacute;e pour faire valoir ce que de droit.        
            </p></br>

        </div>

        <div style="padding-top: 70px;  font-size: 15px;">
            <p align="right">
                Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo $jour.' '. $months[$mois].' '. $annee; ?>.<br>
            </p>


        </div>


        <div style="padding-top: 80px;  font-size: 15px; ">
            <p align="center">
                </br></br>
                Signatures autoris&eacute;es
            </p></br>
            <p align="center" style="font-style: italic; ">
                </br></br></br></br>

                (Reserv&eacute; &agrave; la banque)
            </p></br>

        </div>
    
        <div style="padding-top: 70px;  font-size: 15px;">
            <p align="right">
                ID :<?= isset($cbs_return['Num_evenement']) ? $cbs_return['Num_evenement'] : "$encaissement->Logirefid_4"; ?> <?php echo substr($ville, 0,3); ?> /SFB/<?php echo $annee; ?><br>
            </p>
        </div>



    
    
    
    
    
</body>
</html>