
    <?php 
        
    ?>

    <?php 
          
    ?>
    <html lang="en">  
        <head>
          <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
          <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
        </head>
        <title></title>
        <body style="padding: 20px 20px">
            
            <div style="padding-top: 150px; ">
                <h5 style="color:black; padding-top: 40px; font: bold caption 1em; text-align: center; font-size: 12px; border: 1px solid black; padding: 2px;">ATTESTATION DE PAIEMENT :  <?php echo "DGDA"?>/ <?php echo $services[$encaissement->Office_6]; ?> N&deg; <?php echo $number.'/'.substr($ville, 0,3); ?> /SFB/ <?php echo gmdate("Y"); ?> <span style="font-weight: bold;"> </span></h5>
                <p style=" padding-top:45px;text-align: justify;">
                    La Soci&eacute;t&eacute; Financi&egrave; de Banque <span style="text-transform: uppercase; ">"<?php echo $account_business; ?>&nbsp;"</span> en sigle <span style="text-transform: uppercase;"></span>&nbsp;atteste avoir encaiss&eacute; en date du <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Integration_16)); ?>&nbsp; de notre client:
                    <?php //if(!isset($infos['pourcompte'])){ ?>
                        <span style="text-transform: uppercase;"><?php echo $encaissement->Designation_23; ?></span>,
                     la somme de <span style="font-weight: bold;"><?php echo "CDF".' '.number_format($encaissement->Amount_12,2,","," "); ?> <?php echo " ( ".$number_letter.") "; ?></span>,  en faveur de la <?php echo $services[$encaissement->Office_6]?>, 
                    au titre de paiement DROIT DE DOUANES <?php //echo $recettes[$encaissement->Beneficaire_15][$encaissement->Typerecette_17]; ?>, suivant <span style="text-transform: lowercase;">le bulletin de liquidation (Note de versement)</span> <span style="text-transform: uppercase;"> n&deg;</span> <?php echo $encaissement->Serie_7.''.$encaissement->Number_8; ?>, du </span> <?php echo strftime('%d/%m/%Y',strtotime($encaissement->Integration_16)); ?>.
                </p>
            </div>
            
            <div style="padding-top: 50px;  font-size: 15px;">
                <p>Mode de paiement: <?php echo $encaissement->Reference_19; ?></p><br><br>
                
                 <p align="center">
                    </br></br>
                    En foi de quoi, la pr&eacute;sente attestation lui est d&eacute;livr&eacute;e pour faire valoir ce que de droit.        
                </p></br>
                
            </div>

            <div style="padding-top: 70px;  font-size: 15px;">
                <p align="right">
                    Fait &agrave; <?php echo (isset($ville) && $ville !="" )? $ville :'..............';?> , le <?php echo $encaissement->Integration_16; ?>.<br>
                </p>
                
                
            </div>
            
            
            <div style="padding-top: 80px;  font-size: 15px;">
                <p align="center">
                    </br></br>
                    Signatures autoris&eacute;es
                </p></br>
                <p align="center" style="font-style: italic;">
                    </br></br></br></br></br></br>
                    
                    (Reserv&eacute; &agrave; la banque)
                </p></br>

            </div>
            
            
            <div style="padding-top: 70px;  font-size: 15px;">
                <p align="right">
					ID :<?= (isset($num_evenement) && $num_evenement!="")  ? $num_evenement : $encaissement->Logirefid_34; ?> <?php //echo substr($ville, 0,3); ?> /SFB/<?php //echo $annee; ?><br>
                </p>
            </div>
            
        </body>
</html>


    
    
    
    
    
  