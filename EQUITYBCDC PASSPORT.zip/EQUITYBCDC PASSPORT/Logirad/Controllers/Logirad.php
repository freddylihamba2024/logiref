<?php 
namespace Modules\Services\Logirad\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Logirad\Models\LogiradModel;

class Logirad extends BaseController {
        
        public $logiradModel;
        
        public function __construct()
	{
		parent::__construct();
                
                $this->logiradModel = new LogiradModel();
	}
        
        public function get_note($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $data_to_send = array();
                $failled = array();
                $infos = array();
                
                /*
                * --------------------------------------------
                * Test all required data 
                * --------------------------------------------
                */
                
                if(!isset($data['Reference_8'])) $failled[] = 'The Reference_8 is not defined';
                else  $reference = $data['Reference_8'];
                
                //if(!isset($data['Service_9'])) $failled[] = 'The Service_9 is not defined';
                //else  $service = $data['Service_9'];
                
                //if(!isset($data['Typerecette_12'])) $failled[] = 'The Typerecette_12 is not defined';
                //else  $recette = $data['Typerecette_12'];
                
                //if(!isset($data['Nifclient_7'])) $failled[] = 'The Nifclient_7 is not defined';
                //else  $nif = $data['Nifclient_7'];
                
                //if(!isset($data['User'])) $failled[] = 'The User is not defined';
                //else  $user = $data['User'];
                
                //if(!isset($data['Agence'])) $failled[] = 'The Agence is not defined';
                //else  $branch = $data['Agence'];
                
                if(count($failled) == 0)
                {
                        /*
                        * --------------------------------------------
                        * Construction of data to send 
                        * --------------------------------------------
                        */

                        ############# Simulations ###############
                        if($data['Reference_8'] == "H393878783653")
                        {
                                $data['designation'] = "MULUMBA Etienne TSHITSHI";
                                $data['dateOrdonnancement'] = "2024-08-29";
                                $data['dateEcheance'] = "2024-08-29";
                                $data['montantOrdonnance'] = "282214.6272";
                                $data['montantPaye'] = "45";
                                $data['solde'] = "282214.6272";
                                $data['numeroImpot'] = "B2500548Z";
                                $data['codeService'] = "0100";
                                $data['codeActe'] = "27421600";
                                $data['devise'] = "CDF";
                                $data['logiradCode'] = "200";
                                $data['logiradDescription'] = "5RG9-6N0MH-XQ1PP-15N9";

                        }
                        else if($data['Reference_8'] == "NP24AA31750")
                        {
                                $data['designation'] = "Mundueri Mavinga Yonise";
                                $data['dateOrdonnancement'] = "2024-07-24";
                                $data['dateEcheance'] = "2024-07-24";
                                $data['montantOrdonnance'] = "282214.6272";
                                $data['montantPaye'] = "";
                                $data['solde'] = "282214.6272";
                                $data['numeroImpot'] = "B2204759Z";
                                $data['codeService'] = "0100";
                                $data['codeActe'] = "27421600";
                                $data['devise'] = "CDF";

                                $data['logiradCode'] = "200";
                                $data['logiradDescription'] = "2RQP-8N3VH-XQ1PP-54M6";

                        }
                        else if($data['Reference_8'] == "NP23AA00001")
                        {
                                $data['designation'] = "SOCIETE IMMOBILIERE NOGUEIRA & CIE";
                                $data['dateOrdonnancement'] = "2023-01-12";
                                $data['dateEcheance'] = "2023-03-31";
                                $data['montantOrdonnance'] = "466387.1";
                                $data['montantPaye'] = "";
                                $data['solde'] = "466387.1";
                                $data['numeroImpot'] = "A0706117H";
                                $data['codeService'] = "SER20";
                                $data['codeActe'] = "27415210";
                                $data['devise'] = "CDF";

                                $data['logiradCode'] = "200";
                                $data['logiradDescription'] = "2RQP-8N3VH-XQ1PP-54M6";

                        }
                        else
                        {
                                return 'E404';
                        }

                        $return = json_encode($data);


                        ############# end of simulations ###############
                        //$checked = $this->logiradModel->checknote($_POST['Reference_8']);

                        //SIMULATION RESPONSE
                        $checked = json_decode($return);
                        
                        if($checked == "E000" || $checked == NULL)
                        {
                                $return = "E000";
                        }
                        else
                        {
                                if(isset($checked->code) && $checked->code !="200")
                                {
                                        $return = "E".$checked->code;
                                }
                                else
                                {
                                        $account = $this->session->userdata['account_id'];
                                        $user = $this->session->userdata['user_id'];
                                        $agence = $_SESSION['Logiref_guichet'];

                                        $result = json_encode($checked);
                                        #$requerant = $checked->requerant;
                                        $requerant = $checked->designation;
                                        #$articleComplet = explode("/",$checked->articleBudgetaire);
                                        #$article = trim($articleComplet[0]);
                                        $article = $checked->codeActe;

                                        $dateordonance = $checked->dateOrdonnancement;
                                        $echeance = $checked->dateEcheance;
                                        #$montantdu = $checked->montantDu;
                                        $montantdu = $checked->montantOrdonnance;
                                        $montant = $checked->montantPaye;
                                        $nif = $checked->numeroImpot;
                                        $service = $checked->codeService;
                                        $recette = $checked->codeActe;
                                        $solde = $checked->solde;
                                        $devise = $checked->devise;
                                        $error = '';
                                        $integration = gmdate('Y-m-d H:i:s');

                                        $data_to_save['Status_2'] = 1;
                                        $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_to_save['Account_3'] = $account;
                                        $data_to_save['Creator_4'] = $user;
                                        $data_to_save['Guichet_7'] = $agence;
                                        $data_to_save['Result_8'] = $result;
                                        $data_to_save['Integration_9'] = $integration;
                                        $data_to_save['Code_10'] = $error;
                                        $data_to_save['Requerant_11'] = $requerant;
                                        $data_to_save['Article_12'] = $article;
                                        $data_to_save['Dateordonance_13'] = $dateordonance;
                                        $data_to_save['Echeance_14'] = $echeance;
                                        $data_to_save['Montantdu_15'] = $montantdu;
                                        $data_to_save['Montantpaye_16'] = $montant;
                                        $data_to_save['Solde_17'] = $solde;
                                        $data_to_save['Devise_18'] = $devise;
                                        $data_to_save['Service_19'] = $service;
                                        $data_to_save['Recette_20'] = $recette;
                                        $data_to_save['Reference_21'] = $reference;
                                        $data_to_save['Nif_22'] = $nif;

                                        # Successful attempt - must be saved in database

                                        $nid = $this->logiradModel->save_note($data_to_save, NULL);

                                        if($nid > 0)
                                        {
                                                $return = $nid;
                                        }
                                        else
                                        {
                                            $return = "E002";
                                        }
                                }
                        }

                        return $return;
                }
                else
                {
                        $return['code'] = 405;
                        $result_to_save = json_encode($failled);

                        $this->logiradModel->save_log("Erreur des donnes invalides: ".$result_to_save, "note");

                        return $return;
                }
        }

        public function get_note_passport($request_data)
        {
               
                // $account = $request_data['Account'];
                $account= isset($this->session->userdata['account_id']) ? $this->session->userdata['account_id']:'';
                $reference = $request_data['Reference_8'];
               
                if(isset($reference) && $reference !="")
                {
                        //$credentials = $this->logiradModel->login($account);

                        //$credentials = json_decode($credentials);

                        $credentials = new \stdClass();
                        $credentials->code = '200';
                        $credentials->token = 'dummy_token';
                        $credentials->type = 'Bearer';

                        if($credentials->code == '200')
                        {
                                $token = $credentials->token;
                                $type = $credentials->type;

                                ################## SIMULATIONS ####################

                                $data = array();
                                if ($reference == "NP24AA31750")
                                {
                                        $data['logiradCode'] = '200';
                                        $data['logiradDescription'] = "2RQP-8N3VH-XQ1PP-54M6";
                                        $data['logiradData']['numeroNotePerception'] = "NP24AA31750";
                                        $data['logiradData']['detailAssujetti']['designation'] = "Mundueri Mavinga Yonise";
                                        $data['logiradData']['detailAssujetti']['numeroImpot'] = "B2204759Z";
                                        $data['logiradData']['detailAssujetti']['telephone'] = "0810159251";
                                        $data['logiradData']['detailAssujetti']['email'] = "yonise5499@cartep.com";

                                        $data['logiradData']['detailTaxation']['numeroNoteTaxation'] = "NC000001721805393";
                                        $data['logiradData']['detailTaxation']['montantTaxe'] = "99";
                                        $data['logiradData']['detailTaxation']['devise'] = "USD";
                                        $data['logiradData']['detailTaxation']['montantTaxeCdf'] = "282214.6272";
                                        $data['logiradData']['detailTaxation']['codeArticleBudgetaire'] = "27421600";
                                        $data['logiradData']['detailTaxation']['libelleArticleBudgetaire'] = "Droits de délivrance du passport ordinaire";

                                        $data['logiradData']['detailTaxation']['quotePart']['comite'] = "7";
                                        $data['logiradData']['detailTaxation']['quotePart']['prestataire'] = "45";
                                        $data['logiradData']['detailTaxation']['quotePart']['service'] = "2";
                                        $data['logiradData']['detailTaxation']['quotePart']['tresorPublic'] = "45";

                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnance'] = "45";
                                        $data['logiradData']['detailOrdonnancement']['devise'] = "USD";
                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnanceCdf'] = "128279.376";
                                        $data['logiradData']['detailOrdonnancement']['dateOrdonnancement'] = "2024-07-24";
                                        $data['logiradData']['detailOrdonnancement']['dateEcheancePaiement'] = "2024-07-24";

                                        $data['logiradData']['detailRecouvrement']['codeService'] = "0100";
                                        $data['logiradData']['detailRecouvrement']['codeRegie'] = "DGRAD";
                                        $data['logiradData']['detailRecouvrement']['tauxChange'] = "2850.6528";
                                }
                                elseif ($reference == "KI02AA0000124")
                                {
                                        $data['logiradCode'] = '200';
                                        $data['logiradDescription'] = "5RG9-6NOMH-XQ1PP-15N9";
                                        $data['logiradData']['numeroNotePerception'] = "KI02AA0000124";
                                        $data['logiradData']['detailAssujetti']['designation'] = "MULUMBA Etienne TSHITSHI";
                                        $data['logiradData']['detailAssujetti']['numeroImpot'] = "B2204759Z";
                                        $data['logiradData']['detailAssujetti']['telephone'] = "0810159251";
                                        $data['logiradData']['detailAssujetti']['email'] = "yonise5499@cartep.com";

                                        $data['logiradData']['detailTaxation']['numeroNoteTaxation'] = "NC000001721805393";
                                        $data['logiradData']['detailTaxation']['montantTaxe'] = "99";
                                        $data['logiradData']['detailTaxation']['devise'] = "USD";
                                        $data['logiradData']['detailTaxation']['montantTaxeCdf'] = "282214.6272";
                                        $data['logiradData']['detailTaxation']['codeArticleBudgetaire'] = "27421600";
                                        $data['logiradData']['detailTaxation']['libelleArticleBudgetaire'] = "Droits de délivrance du passport ordinaire";

                                        $data['logiradData']['detailTaxation']['quotePart']['comite'] = "7";
                                        $data['logiradData']['detailTaxation']['quotePart']['prestataire'] = "45";
                                        $data['logiradData']['detailTaxation']['quotePart']['service'] = "2";
                                        $data['logiradData']['detailTaxation']['quotePart']['tresorPublic'] = "45";

                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnance'] = "45";
                                        $data['logiradData']['detailOrdonnancement']['devise'] = "USD";
                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnanceCdf'] = "128279.376";
                                        $data['logiradData']['detailOrdonnancement']['dateOrdonnancement'] = "2024-07-24";
                                        $data['logiradData']['detailOrdonnancement']['dateEcheancePaiement'] = "2024-07-24";

                                        $data['logiradData']['detailRecouvrement']['codeService'] = "0100";
                                        $data['logiradData']['detailRecouvrement']['codeRegie'] = "DGRAD";
                                        $data['logiradData']['detailRecouvrement']['tauxChange'] = "2850.6528";
                                }
                                elseif ($reference == "KI02AA0000324")
                                {
                                        $data['logiradCode'] = '200';
                                        $data['logiradDescription'] = "5RG9-6NOMH-XQ1PP-15N9";
                                        $data['logiradData']['numeroNotePerception'] = "KI02AA0000324";
                                        $data['logiradData']['detailAssujetti']['designation'] = "KABASELE Herve";
                                        $data['logiradData']['detailAssujetti']['numeroImpot'] = "B1209679Z";
                                        $data['logiradData']['detailAssujetti']['telephone'] = "0810159251";
                                        $data['logiradData']['detailAssujetti']['email'] = "kabasele@cartep.com";

                                        $data['logiradData']['detailTaxation']['numeroNoteTaxation'] = "NC000001721805393";
                                        $data['logiradData']['detailTaxation']['montantTaxe'] = "99";
                                        $data['logiradData']['detailTaxation']['devise'] = "USD";
                                        $data['logiradData']['detailTaxation']['montantTaxeCdf'] = "282214.6272";
                                        $data['logiradData']['detailTaxation']['codeArticleBudgetaire'] = "27421600";
                                        $data['logiradData']['detailTaxation']['libelleArticleBudgetaire'] = "Droits de délivrance du passport ordinaire";

                                        $data['logiradData']['detailTaxation']['quotePart']['comite'] = "7";
                                        $data['logiradData']['detailTaxation']['quotePart']['prestataire'] = "45";
                                        $data['logiradData']['detailTaxation']['quotePart']['service'] = "2";
                                        $data['logiradData']['detailTaxation']['quotePart']['tresorPublic'] = "45";

                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnance'] = "45";
                                        $data['logiradData']['detailOrdonnancement']['devise'] = "USD";
                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnanceCdf'] = "128279.376";
                                        $data['logiradData']['detailOrdonnancement']['dateOrdonnancement'] = "2024-07-24";
                                        $data['logiradData']['detailOrdonnancement']['dateEcheancePaiement'] = "2024-07-24";

                                        $data['logiradData']['detailRecouvrement']['codeService'] = "0100";
                                        $data['logiradData']['detailRecouvrement']['codeRegie'] = "DGRAD";
                                        $data['logiradData']['detailRecouvrement']['tauxChange'] = "2850.6528";
                                }
                                elseif ($reference == "NP23AA00001")
                                {
                                        $data['logiradCode'] = '200';
                                        $data['logiradDescription'] = "2RQP-8N3VH-XQ1PP-54M6";
                                        $data['logiradData']['numeroNotePerception'] = "NP23AA00001";
                                        $data['logiradData']['detailAssujetti']['designation'] = "SOCIETE IMMOBILIERE NOGUERA & CIE";
                                        $data['logiradData']['detailAssujetti']['numeroImpot'] = "A070611H";
                                        $data['logiradData']['detailAssujetti']['telephone'] = "0810159251";
                                        $data['logiradData']['detailAssujetti']['email'] = "yonise5499@cartep.com";

                                        $data['logiradData']['detailTaxation']['numeroNoteTaxation'] = "NC000001721805393";
                                        $data['logiradData']['detailTaxation']['montantTaxe'] = "99";
                                        $data['logiradData']['detailTaxation']['devise'] = "USD";
                                        $data['logiradData']['detailTaxation']['montantTaxeCdf'] = "282214.6272";
                                        $data['logiradData']['detailTaxation']['codeArticleBudgetaire'] = "27421600";
                                        $data['logiradData']['detailTaxation']['libelleArticleBudgetaire'] = "Droits de délivrance du passport ordinaire";

                                        $data['logiradData']['detailTaxation']['quotePart']['comite'] = "7";
                                        $data['logiradData']['detailTaxation']['quotePart']['prestataire'] = "45";
                                        $data['logiradData']['detailTaxation']['quotePart']['service'] = "2";
                                        $data['logiradData']['detailTaxation']['quotePart']['tresorPublic'] = "45";

                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnance'] = "45";
                                        $data['logiradData']['detailOrdonnancement']['devise'] = "USD";
                                        $data['logiradData']['detailOrdonnancement']['montantOrdonnanceCdf'] = "128279.376";
                                        $data['logiradData']['detailOrdonnancement']['dateOrdonnancement'] = "2024-07-24";
                                        $data['logiradData']['detailOrdonnancement']['dateEcheancePaiement'] = "2024-07-24";

                                        $data['logiradData']['detailRecouvrement']['codeService'] = "0100";
                                        $data['logiradData']['detailRecouvrement']['codeRegie'] = "DGRAD";
                                        $data['logiradData']['detailRecouvrement']['tauxChange'] = "2850.6528";
                                }
                                else
                                {
                                        $return = "E604";
                                }
                                $return = json_encode($data);
                              
                                $checked = json_decode($return);
                         
                                /* Webservice CALL
                                * Checknotepassport
                                */
                                //$checked = $this->logiradModel->checknote_passport($reference, $token, $type);

                                if($checked == "E000" || $checked == NULL)
                                {
                                        $return = "E000";
                                }
                                else
                                {
                                        if(isset($checked->logiradCode) && $checked->logiradCode !="200")
                                        {
                                                // $return['code'] = "E".$checked->logiradCode;
                                                // $return['description'] = $checked->logiradDescription;
                                                $return = "E".$checked->logiradCode;
                                        }
                                        else
                                        {

                                                $user = isset($this->session->userdata['user_id'])? $this->session->userdata['user_id'] : '';
                                                $agence = isset($_SESSION['Logiref_guichet']) ? $_SESSION['Logiref_guichet'] :'';

                                                $result = json_encode($checked);
                                                $quote_part= $checked->logiradData->detailTaxation->quotePart;

                                                $requerant = $checked->logiradData->detailAssujetti->designation;
                                                $nif = $checked->logiradData->detailAssujetti->numeroImpot;
                                                $article = $checked->logiradData->detailTaxation->codeArticleBudgetaire;
                                                $quote_part= json_encode($quote_part);
                                                $dateordonance = $checked->logiradData->detailOrdonnancement->dateOrdonnancement;
                                                $echeance = $checked->logiradData->detailOrdonnancement->dateEcheancePaiement;
                                                $montantdu = $checked->logiradData->detailTaxation->montantTaxe;
                                                $montant = $checked->logiradData->detailOrdonnancement->montantOrdonnance;
                                                $solde = $checked->logiradData->detailTaxation->montantTaxe;
                                                $devise = $checked->logiradData->detailTaxation->devise;
                                                $service = $checked->logiradData->detailRecouvrement->codeService;
                                                $recette = $checked->logiradData->detailTaxation->codeArticleBudgetaire;
                                                $error = '';
                                                $integration = gmdate('Y-m-d H:i:s');

                                                $data_to_save = array(
                                                        "Date_1"                => gmdate('Y-m-d H:i:s'),
                                                        "Status_2"              => 1,
                                                        "Account_3"             => $account,
                                                        "Creator_4"             => $user,
                                                        "Guichet_7"             => $agence,
                                                        "Result_8"              => $result,
                                                        "Integration_9"         => $integration,
                                                        "Code_10"               => $error,
                                                        "Requerant_11"          => $requerant,
                                                        "Article_12"            => $article,
                                                        "Dateordonance_13"      => $dateordonance,
                                                        "Echeance_14"           => $echeance,
                                                        "Montantdu_15"          => $montantdu,
                                                        "Montantpaye_16"        => $montant,
                                                        "Solde_17"              => $solde,
                                                        "Devise_18"             => $devise,
                                                        "Service_19"            => $service,
                                                        "Recette_20"            => $recette,
                                                        "Reference_21"          => $reference,
                                                        "Nif_22"                => $nif,
                                                        "Notereference_24"      => $quote_part
                                                );
                                                
                                                # Successful attempt - must be saved in database
                                                $nid = $this->logiradModel->save_note($data_to_save, NULL);

                                                if($nid > 0)
                                                {
                                                        $return = $nid;
                                                }
                                                else
                                                {
                                                        $return = "E002";
                                                }
                                                
                                        }
                                }
                        }
                        else
                        {
                                $return = "E001";
                        }

                }
                else
                {
                    $return = "E22";
                }
                //Return
                return $return;
        }

        public function confirm_note_passport($data)
        {

                $account = $this->session->userdata['account_id'];

                if(isset($data['Reference_32']) && $data['Reference_32'] !="")
                {
                        // $credentials = $this->logiradModel->login($account);

                        // $credentials = json_decode($credentials);

                        $credentials = new \stdClass();
                        $credentials->code = '200';
                        $credentials->token = 'dummy_token';
                        $credentials->type = 'Bearer';

                        if($credentials->code == '200')
                        {
                                $token = $credentials->token;
                                $type = $credentials->type;
                                /* Webservice CALL
                                * Confirmknote
                                */

                                // $checked = $this->logiradModel->confirmnote_passport($data, $token, $type);
                                //$checked = $obj->test_confirmnote_passport($_POST['numeroNotePerception']);

                                $checked = new \stdClass();
                                $checked->logiradCode = "201"; // Set a default value
                                $checked->logiradMessage = "Note confirmed successfully";

                                if($checked == "E000" || $checked == NULL)
                                {
                                        $return = "E000";
                                }
                                else
                                {
                                        $code = isset($checked->logiradCode) ? $checked->logiradCode : "E001";
                                      
                                        //$code = 201;
                                        if(isset($code) && $code == "201")
                                        {
                                                $reference = $data['Reference_32'];
                                                $data_to_update['Status_2']=2;
                                                # Successful attempt - must be saved in database
                                                $nid = $this->logiradModel->update_note_passport($data_to_update,$reference);
                                                
                                                if($nid > 0)
                                                {
                                                        // $return = $nid;
                                                        $return="E200";
                                                }
                                                else
                                                {
                                                        $return = "E002";
                                                }
                                        }
                                        else
                                        {
                                                $return = "E".$checked->logiradCode;
                                        }
                                }
                        }
                        else
                        {
                                $return = "E001";
                        }
                }
                else
                {
                        $return = "E22";
                }

                //Return
                return $return;
        }
        // public function get_note_permis($data)
        // {

        //         //$account = $this->session->userdata['account_id'];

        //         if(isset($data['Reference_8']) && $data['Reference_8'] !="")
        //         {

        //                 //$credentials = $this->logiradModel->login($account);

        //                 //$credentials = json_decode($credentials);

        //                 $credentials = new \stdClass();
        //                 $credentials->code = '200';

        //                 if($credentials->code == '200')
        //                 {
        //                         //$token = $credentials->token;
        //                         //$type = $credentials->type;

        //                         ################## SIMULATIONS ####################

        //                         $row = array();

        //                         if ($data['Reference_8'] == "KI10AC000003225")
        //                         {
        //                                 $row['logiradCode'] = '200';
        //                                 $row['logiradDescription'] = "OK";

        //                                 $row['logiradData']['numeroNotePerception'] = "KI10AC000003225";

        //                                 // Informations du contribuable
        //                                 $row['logiradData']['detailAssujetti']['designation'] = "Munganga Munganga Robert";
        //                                 $row['logiradData']['detailAssujetti']['numeroImpot'] = "C2518955L";
        //                                 $row['logiradData']['detailAssujetti']['telephone'] = "0999960779";
        //                                 $row['logiradData']['detailAssujetti']['email'] = "jmunganga@gmail.com";
        //                                 $row['logiradData']['detailAssujetti']['adresse'] = "Lemba, avenue des plateaux n°5";

        //                                 // Informations du centre
        //                                 $row['logiradData']['detailCentre']['centreLibelle'] = "Conadep/Ndolo 2";
        //                                 $row['logiradData']['detailCentre']['divisionLibelle'] = "";
        //                                 $row['logiradData']['detailCentre']['directionLibelle'] = "";
        //                                 $row['logiradData']['detailCentre']['codeProvince'] = "KI";

        //                                 // Détails de la taxation
        //                                 $row['logiradData']['detailTaxation']['numeroNoteTaxation'] = "KI10AC000003225";
        //                                 $row['logiradData']['detailTaxation']['montantTaxe'] = "71.5";
        //                                 $row['logiradData']['detailTaxation']['devise'] = "USD";
        //                                 $row['logiradData']['detailTaxation']['tauxChange'] = "2860.0354";
        //                                 $row['logiradData']['detailTaxation']['montantTaxeCdf'] = "204492.5311";
        //                                 $row['logiradData']['detailTaxation']['codeArticleBudgetaire'] = "27422120";
        //                                 $row['logiradData']['detailTaxation']['libelleArticleBudgetaire'] = "Droits de délivrance du permis de conduire ou de son duplicata";

        //                                 $row['logiradData']['detailTaxation']['quotePart']['tresor'] = "100";

        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['baseTaxable'] = "1";
        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['tarifId'] = "3";
        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['tarifLibelle'] = "CATéGORIE B : VéHICULE DE 3.5 T MAXIMUM";
        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['taux'] = "71.5";
        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['devise'] = "USD";
        //                                 $row['logiradData']['detailTaxation']['tarifs'][0]['unite'] = "Categorie";

        //                                 // Détails de l’ordonnancement
        //                                 $row['logiradData']['detailOrdonnancement']['montantOrdonnance'] = "71.5";
        //                                 $row['logiradData']['detailOrdonnancement']['devise'] = "USD";
        //                                 $row['logiradData']['detailOrdonnancement']['montantOrdonnanceCdf'] = "204492.5311";
        //                                 $row['logiradData']['detailOrdonnancement']['tauxChange'] = "2860.0354";
        //                                 $row['logiradData']['detailOrdonnancement']['montantTotal'] = "71.5";
        //                                 $row['logiradData']['detailOrdonnancement']['montantTotalCdf'] = "204492.5311";

        //                                 // PDF base64
        //                                 $row['logiradData']['fichierPerception'] = "data:application/pdf;base64,JVBERi0xLjcKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZwovT3V0bGluZXMgMiAwIFIKL1BhZ2VzIDMgMCBSID4+CmVuZG9iagoyIDAgb2JqCjw8IC9UeXBlIC9PdXRsaW5lcyAvQ291bnQgMCA";
        //                         }
        //                         else
        //                         {
        //                                 $return = "E604";
        //                         }

        //                         $return = json_encode($row);
        //                         $checked = json_decode($return);var_dump($checked->logiradData->detailOrdonnancement->dateOrdonnancement); die;

        //                         /* Webservice CALL
        //                         * Checknotepassport
        //                         */
        //                         //$checked = $this->logiradModel->checknote_passport($data['Reference_8'], $token, $type);

        //                         if($checked == "E000" || $checked == NULL)
        //                         {
        //                                 $return = "E000";
        //                         }
        //                         else
        //                         {
        //                                 if(isset($checked->logiradCode) && $checked->logiradCode !="200")
        //                                 {
        //                                         //$return['code'] = "E".$checked->logiradCode;
        //                                         //$return['description'] = $checked->logiradDescription;
        //                                         $return = "E".$checked->logiradCode;
        //                                 }
        //                                 else
        //                                 {
        //                                         $account = $this->session->userdata['account_id'];
        //                                         $user = $this->session->userdata['user_id'];
        //                                         $agence = $_SESSION['Logiref_guichet'];

        //                                         $reference = $data['Reference_8'];

        //                                         $result = json_encode($checked);
        //                                         $quote_part= $checked->logiradData->detailTaxation->quotePart;

        //                                         $requerant = $checked->logiradData->detailAssujetti->designation;
        //                                         $nif = $checked->logiradData->detailAssujetti->numeroImpot;
        //                                         $article = $checked->logiradData->detailTaxation->codeArticleBudgetaire;
        //                                         $quote_part= json_encode($quote_part);
        //                                         $dateordonance = $checked->logiradData->detailOrdonnancement->dateOrdonnancement;
        //                                         $echeance = $checked->logiradData->detailOrdonnancement->dateEcheancePaiement;
        //                                         $montantdu = $checked->logiradData->detailTaxation->montantTaxe;
        //                                         $montant = $checked->logiradData->detailOrdonnancement->montantOrdonnance;
        //                                         $solde = $checked->logiradData->detailTaxation->montantTaxe;
        //                                         $devise = $checked->logiradData->detailTaxation->devise;
        //                                         $service = $checked->logiradData->detailRecouvrement->codeService;
        //                                         $recette = $checked->logiradData->detailTaxation->codeArticleBudgetaire;
        //                                         $error = '';
        //                                         $integration = gmdate('Y-m-d H:i:s');

        //                                         # Successful attempt - must be saved in database
        //                                         $nid = $this->logiradModel->save_note($account, $user, $agence, $result, $integration, $error, $requerant, $article, $dateordonance, $echeance, $montantdu, $montant, $solde, $devise, $service, $recette, $reference, $nif, $quote_part);

        //                                         if($nid > 0)
        //                                         {
        //                                                 $return = $nid;
        //                                         }
        //                                         else
        //                                         {
        //                                                 $return = "E002";
        //                                         }
        //                                 }
        //                         }
        //                 }
        //                 else
        //                 {
        //                         $return = "E001";
        //                 }

        //         }
        //         else
        //         {
        //             $return = "E22";
        //         }
        //         //Return
        //         echo $return;
        // }

        public function get_note_permis($data)
        {
                // Vérifie la présence de Reference_8
                if (!isset($data['Reference_8']) || $data['Reference_8'] === '') {
                        echo "E22";
                        return;
                }

                // Simulation d'auth (ou récupération des credentials)
                $credentials = new \stdClass();
                $credentials->code = '200';

                if ($credentials->code != '200') {
                        echo "E001";
                        return;
                }

                // ################## SIMULATIONS ####################
                $row = [];

                // Simulation pour la référence KI10AC000003225
                if ($data['Reference_8'] === "KI10AC000003225") {

                        $row['logiradCode'] = '200';
                        $row['logiradDescription'] = "OK";

                        $row['logiradData']['numeroNotePerception'] = "KI10AC000003225";

                        // Informations du contribuable
                        $row['logiradData']['detailAssujetti'] = [
                                'designation'   => "Munganga Munganga Robert",
                                'numeroImpot'   => "C2518955L",
                                'telephone'     => "0999960779",
                                'email'         => "jmunganga@gmail.com",
                                'adresse'       => "Lemba, avenue des plateaux n°5"
                        ];

                        // Informations du centre
                        $row['logiradData']['detailCentre'] = [
                                'centreLibelle'     => "Conadep/Ndolo 2",
                                'divisionLibelle'   => "",
                                'directionLibelle'  => "",
                                'codeProvince'      => "KI"
                        ];

                        // Détails de la taxation
                        $row['logiradData']['detailTaxation'] = [
                                'numeroNoteTaxation'    => "KI10AC000003225",
                                'montantTaxe'           => "71.5",
                                'devise'                => "USD",
                                'tauxChange'            => "2860.0354",
                                'montantTaxeCdf'        => "204492.5311",
                                'codeArticleBudgetaire' => "27422120",
                                'libelleArticleBudgetaire'=> "Droits de délivrance du permis de conduire ou de son duplicata",
                        'quotePart' => [
                                'tresor'        => "31.5",
                                'prestataire'   => "35",
                                'fraisbancaire' => "5",
                        ],
                        'tarifs' => [
                                        [
                                                'baseTaxable' => "1",
                                                'tarifId'     => "3",
                                                'tarifLibelle'=> "CATéGORIE B : VéHICULE DE 3.5 T MAXIMUM",
                                                'taux'        => "71.5",
                                                'devise'      => "USD",
                                                'unite'       => "Categorie"
                                        ]
                                ]
                        ];

                        // Détails de l’ordonnancement (dates incluses)
                        $row['logiradData']['detailOrdonnancement'] = [
                                'montantOrdonnance'     => "71.5",
                                'devise'                => "USD",
                                'montantOrdonnanceCdf'  => "204492.5311",
                                'tauxChange'            => "2860.0354",
                                'montantTotal'          => "71.5",
                                'montantTotalCdf'       => "204492.5311",
                                // Fournir des dates dans la simulation pour éviter erreurs
                                'dateOrdonnancement'    => date('Y-m-d'),
                                'dateEcheancePaiement'  => date('Y-m-d', strtotime('+30 days'))
                        ];

                        // Détails du recouvrement (obligatoire dans ta suite)
                        $row['logiradData']['detailRecouvrement'] = [
                                'codeService' => "0100",
                                'codeRegie'   => "DGRAD",
                                'tauxChange'  => "2860.0354"
                        ];

                        // PDF base64 (simulé)
                        $row['logiradData']['fichierPerception'] = "data:application/pdf;base64,JVBERi0xLjcKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZwovT3V0bGluZXMgMiAwIFIKL1BhZ2VzIDMgMCBSID4+CmVuZG9iagoyIDAgb2JqCjw8IC9UeXBlIC9PdXRsaW5lcyAvQ291bnQgMCA";
                } else {
                        // Référence non supportée en simulation
                        echo "E604";
                        return;
                }

                // Encode la simulation en JSON et décode en objet pour imiter le WS
                $return = json_encode($row);
                $checked = json_decode($return);

                // Contrôles basiques
                if ($checked === "E000" || $checked === null) {
                        echo "E000";
                        return;
                }

                if (isset($checked->logiradCode) && $checked->logiradCode != "200") {
                        echo "E" . $checked->logiradCode;
                        return;
                }

                // Récupération des valeurs en protégeant contre les propriétés manquantes
                $account = $this->session->userdata['account_id'] ?? null;
                $user    = $this->session->userdata['user_id'] ?? null;
                $agence  = $_SESSION['Logiref_guichet'] ?? null;
                $reference = $data['Reference_8'];

                $result = json_encode($checked);
                $quote_part = isset($checked->logiradData->detailTaxation->quotePart) ? json_encode($checked->logiradData->detailTaxation->quotePart) : json_encode([]);

                $requerant = $checked->logiradData->detailAssujetti->designation ?? null;
                $nif       = $checked->logiradData->detailAssujetti->numeroImpot ?? null;
                $article   = $checked->logiradData->detailTaxation->codeArticleBudgetaire ?? null;
                $dateordonance = $checked->logiradData->detailOrdonnancement->dateOrdonnancement ?? null;
                $echeance  = $checked->logiradData->detailOrdonnancement->dateEcheancePaiement ?? null;
                $montantdu = $checked->logiradData->detailTaxation->montantTaxe ?? null;
                $montant   = $checked->logiradData->detailOrdonnancement->montantOrdonnance ?? null;
                $solde     = $checked->logiradData->detailTaxation->montantTaxe ?? null;
                $devise    = $checked->logiradData->detailTaxation->devise ?? null;
                $service   = $checked->logiradData->detailRecouvrement->codeService ?? null;
                $recette   = $checked->logiradData->detailTaxation->codeArticleBudgetaire ?? null;
                $error     = '';
                $integration = gmdate('Y-m-d H:i:s');

                $data_to_save = [
                        'Date_1'                => gmdate('Y-m-d H:i:s'),
                        'Status_2'              => 1,
                        'Account_3'             => $account,
                        'Creator_4'             => $user,
                        'Guichet_7'             => $agence,
                        'Result_8'              => $result,
                        'Integration_9'         => $integration,
                        'Code_10'               => $error,
                        'Requerant_11'          => $requerant,
                        'Article_12'            => $article,
                        'Dateordonance_13'      => $dateordonance,
                        'Echeance_14'           => $echeance,
                        'Montantdu_15'          => $montantdu,
                        'Montantpaye_16'        => $montant,
                        'Solde_17'              => $solde,
                        'Devise_18'             => $devise,
                        'Service_19'            => $service,
                        'Recette_20'            => $recette,
                        'Reference_21'          => $reference,
                        'Nif_22'                => $nif,
                        'Notereference_24'      => $quote_part
                ];

                // Appel du modèle pour enregistrer la note (ici on suppose que logiradModel existe)
                $nid = $this->logiradModel->save_note($data_to_save, NULL);

                if ($nid > 0) {
                        return $nid;
                } else {
                        echo "E002";
                }
        }

        public function confirm_note_permis($data)
        {

                $account = $this->session->userdata['account_id'];

                if(isset($data['numeroNotePerception']) && $data['numeroNotePerception'] !="")
                {
                        $credentials = $this->logiradModel->login($account);

                        $credentials = json_decode($credentials);

                        if($credentials->code == '200')
                        {
                                $token = $credentials->token;
                                $type = $credentials->type;
                                /* Webservice CALL
                                * Confirmknote
                                */

                                //$checked = $this->logiradModel->confirmnote_permis($data, $token, $type);

                                $checked = new \stdClass();
                                $checked->logiradCode = 200;

                                if($checked == "E000" || $checked == NULL)
                                {
                                        $return = "E000";
                                }
                                else
                                {
                                        $code = isset($checked->logiradCode) ? $checked->logiradCode : "E001";

                                        $code = 201;

                                        if(isset($code) && $code == "201")
                                        {
                                                $reference = $data['numeroNotePerception'];

                                                # Successful attempt - must be saved in database
                                                $nid = $this->logiradModel->update_note_permis($reference);

                                                if($nid > 0)
                                                {
                                                        //$return = $nid;
                                                        $return="E200";
                                                }
                                                else
                                                {
                                                        $return = "E002";
                                                }
                                        }
                                        else
                                        {
                                                $return = "E".$checked->logiradCode;
                                        }
                                }
                        }
                        else
                        {
                                $return = "E001";
                        }
                }
                else
                {
                        $return = "E22";
                }

                //Return
                return $return;

        }

        public function remove_all_special_characters($texte)
        {
                // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                $texte = preg_replace('/[^a-zA-Z0-9]/', ' ', $texte);

                return $texte;
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */