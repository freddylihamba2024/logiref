<?php 



class logiradClass{
    
        public $pdoMySQL;
	public $limit;
	public $pathr;
	public $host;
	public $dbname;
	public $dba;
	public $pwd;
        
        public $client;
        
        function __construct($account)
        {
                require_once("config.sydonia.php");
                if($account=='44') $this->dbname = "ikwook_cloud_logiref_rawbank_integrations";
                if($account=='46') $this->dbname = "ikwook_cloud_logiref_equitybank_integrations";
                if($account=='45') $this->dbname = "ikwook_cloud_logiref_tmb_integrations";
                
                $this->pdoMySQL = new PDO('mysql:host='.$this->host.';dbname='.$this->dbname.'', $this->dba, $this->pwd);
        }
        
        
        public function close()
        {
		$this->pdoMySQL = NULL;
        }
        
        
        public function checknote($ref)
        {
                //$url = 'http://217.171.94.179:20025/logirad-api/data/v1/noteperception/'.$ref;
                $url = 'http://apilogirad.dgrad.cd/data/v1/noteperception/'.$ref;

                $handle = curl_init();

                curl_setopt_array($handle, array(
                  CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'GET',
                  CURLOPT_HTTPHEADER => array(
                    'token:'.$this->token
                  ),
                ));
                
                if(curl_exec($handle) !== false)
                {
                        $response = curl_exec($handle);
                        curl_close($handle);
                        
                        $this->save_log($response, "response_note");
                        
                        return json_decode($response);
                }
                else
                {
                       return 'E000';
                }
        }
        
        
        public function save_note($account, $user, $agence, $result, $integration, $error, $requerant, $article, $dateordonance, $echeance, $montantdu, $montant, $solde, $devise,$service,$recette,$reference,$nif)
        {
            $q = $this->pdoMySQL->prepare(

                    'INSERT INTO logiref_integration_logirad 
                     (Date_1, Status_2, Account_3, Creator_4, Guichet_7, Result_8, Integration_9, Code_10, Requerant_11, Article_12, Dateordonance_13, Echeance_14, Montantdu_15, Montantpaye_16, Solde_17, Devise_18, Service_19, Recette_20, Reference_21, Nif_22)
                     VALUES 
                     (NOW(), :Status_2, :Account_3, :Creator_4, :Guichet_7, :Result_8, :Integration_9, :Code_10, :Requerant_11, :Article_12, :Dateordonance_13, :Echeance_14, :Montantdu_15, :Montantpaye_16, :Solde_17, :Devise_18, :Service_19, :Recette_20, :Reference_21, :Nif_22)
                     ');
                
                
                $r = $q->execute([
                        "Status_2" => 1,
                        "Account_3" => $account,
                        "Creator_4" => $user,
                        "Guichet_7" => $agence,
                        "Result_8" => $result,
                        "Integration_9" => $integration,
                        "Code_10" => $error,
                        "Requerant_11" => $requerant,
                        "Article_12" => $article,
                        "Dateordonance_13" => $dateordonance,
                        "Echeance_14" => $echeance,
                        "Montantdu_15" => $montantdu,
                        "Montantpaye_16" => $montant,
                        "Solde_17" => $solde,
                        "Devise_18" => $devise,
                        "Service_19" => $service,
                        "Recette_20" => $recette,
                        "Reference_21" => $reference,
                        "Nif_22" => $nif,
                        
                ]);
                
                $id = $this->pdoMySQL->lastInsertId();
                
                return $id;
        }
    
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

