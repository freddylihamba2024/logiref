<?php

namespace Modules\Services\Logirad\Models;
use App\Models\MY_Transaction;

class LogiradModel extends MY_Transaction {

        /* Presentation:
         * Last update
         * By Glodi on the 30.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vos variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
    
        public $token;
	
        
	public function __construct()
	{
		parent::__construct();
                
                $this->token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3IiwiYXVkIjpbNywiV2VkIE5vdiAwMiAwOTo1MzozNSBDRVQgMjAyMiIsInJhd2JhbmsiLCJEMDA4Qzc4RC02RDM0LTRFMkItODc0NS1GODIwNkExQUMxQUQiXSwiaXNzIjoiYXBpIiwiZXhwIjoxNjY3MzgzOTI0LCJpYXQiOjE2NjczODI0MjQsImp0aSI6Ijg5YmI2NWIwLTQ2OTMtNDYxNi05YmQ4LWQ3N2JiZjAwZTM5NiJ9.K3ncQYkJTdcHYgx3K8zGmeSMJ44xSJRxNhDpmdnVoSY";
	}

        public function login($account=NULL)
        {

                #### Invocation du web service
                //$url = " https://apilogirad.dgrad.cd/api/v1/auth/login" //Prod
                $url = "https://217.171.92.177/api/v1/auth/login"; // UAT

                $handle = curl_init();

                if($account !="")
                {
                        # Créer la charge utile JSON
                        if ($account=='46')
                        {
                                $post_fields = json_encode([
                                        "username" => "equitybcdc",
                                        "password" => "=rrY)>Fbr572cU]",
                                ]);
                        }
                }
                else
                {
                        # Créer la charge utile JSON
                        $post_fields = json_encode([
                                "username" => "",
                                "password" => "",
                        ]);
                }

                curl_setopt_array($handle, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'POST',
                        CURLOPT_POSTFIELDS => $post_fields, // Utilisez la charge utile dynamique
                        CURLOPT_HTTPHEADER => array(
                                'Content-Type: application/json',
                                'Cookie: ETH_SESSION=!yB1PLAJlC8vFXodByJBfAYTH5bqF/LHolnEXEeNiclmFITKkh8kORa+Xifa80EvyGSG9Ta8/YlJFqw=='
                        ),
                        CURLOPT_SSL_VERIFYPEER => false, // Désactive la vérification du certificat SSL
                        CURLOPT_SSL_VERIFYHOST => false  // Désactive la vérification du nom d'hôte
                ));

                $response = curl_exec($handle);

                if($response !== false)
                {
                        curl_close($handle);

                        $this->save_log($response, "Login_note");

                        $response = json_decode($response);

                        if(isset($response->logiradCode) && $response->logiradCode =="200")
                        {
                                $result['code'] = $response->logiradCode;
                                $result['token'] = $response->logiradData->token;
                                $result['timeout'] = $response->logiradData->expires_at;
                                $result['type'] = $response->logiradData->type;

                                return json_encode($result);
                        }
                        else
                        {
                                return $response->logiradCode;
                        }

                        #return json_decode($response);
                }
                else
                {
                       return 'E000';
                }
        }


        public function checknote($ref)
        {
                $url = 'https://apilogirad.dgrad.cd/data/v1/noteperception/'.$ref;

                $handle = curl_init();

                curl_setopt_array($handle, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'GET',
                        CURLOPT_HTTPHEADER => array(
                                'token: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3IiwiYXVkIjpbNywiV2VkIE5vdiAwMiAwOTo1MzozNSBDRVQgMjAyMiIsInJhd2JhbmsiLCJEMDA4Qzc4RC02RDM0LTRFMkItODc0NS1GODIwNkExQUMxQUQiXSwiaXNzIjoiYXBpIiwiZXhwIjoxNjY3MzgzOTI0LCJpYXQiOjE2NjczODI0MjQsImp0aSI6Ijg5YmI2NWIwLTQ2OTMtNDYxNi05YmQ4LWQ3N2JiZjAwZTM5NiJ9.K3ncQYkJTdcHYgx3K8zGmeSMJ44xSJRxNhDpmdnVoSY'
                        ),
                ));

                if(curl_exec($handle) !== false)
                {
                        $response = curl_exec($handle);
                        curl_close($handle);
                        
                        $this->save_log($response, "response_note");
                        
                        return json_decode($response);
                }
                else
                {
                       return 'E000';
                }
        }
        
        public function checknote_passport($ref, $token, $type)
        {
                //$url = 'https://217.171.94.180:40015/api/v1/ordonnancement/consultation'; // UAT
                //$url = 'https://apilogirad.dgrad.cd/api/v1/ordonnancement/consultation'; // PROD
            
                $url = 'https://217.171.92.177/api/v1/ordonnancement/consultation'; // UAT
                
                $handle = curl_init();
                # Créer la charge utile JSON
                $post_fields = json_encode([
                    "username" => "equitybcdc",
                    "password" => "=rrY)>Fbr572cU]",
                    //"password" => "=rrY)>Fbr572cU]",
                    "numeroNotePerception" => $ref
                ]);

                curl_setopt_array($handle, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $post_fields,
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Authorization: ' . $type . ' ' . $token,
                        'Cookie: ETH_SESSION=!ior/fQiW7O8ThsTChvSrzlMjym9WiacV/DdjNd2BqWMy0tDi781u4U9TpxMOe8AiwnVcQnwZMGUoHA=='
                    ),
                    CURLOPT_SSL_VERIFYPEER => false, // Désactive la vérification du certificat SSL
                    CURLOPT_SSL_VERIFYHOST => false  // Désactive la vérification du nom d'hôte
                ));

                $response = curl_exec($handle);

                if ($response !== false) 
                {
                        $this->save_log($response, "response_note_passport");
                        curl_close($handle);
      
                        return json_decode($response);
                } 
                else 
                {
                        $error_message = curl_error($handle); // Récupérer le message d'erreur
                        curl_close($handle);
                        
                     
                        $this->save_log($error_message, "error_note"); // Sauvegarder l'erreur dans les logs
                        return 'E000';
                }
        }
        public function confirmnote_passport($data, $token, $type)
        {
                //$url = 'https://217.171.94.180:40015/api/v1/paiement/confirmation'; // UAT
                //$url = 'https://apilogirad.dgrad.cd/api/v1/paiement/confirmation'; // PROD

                $url = 'https://217.171.92.177/api/v1/paiement/confirmation'; // UAT
                $handle = curl_init();
                # Créer la charge utile JSON
                $post_fields = json_encode([
                        "username" => "equitybcdc",
                        "password" => "=rrY)>Fbr572cU]",
                        "numeroNotePerception" => $data['Noteid_26'],
                        "numeroPaiement" => $data['Reference_32'],
                        "datePaiement" => gmdate('Y-m-d H:i:s'),
                        "devise" => $data['Devise_12'],
                        "montant" => $data['Montant_11'],
                        "tauxChange" => $data['Taux_41'],
                        "codeBanque" => "EquityBCDC",
                        "codeAgence" => $data['codeAgence'],
                        "agence" => $data['agence'],
                ]);

                curl_setopt_array($handle, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $post_fields,
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Authorization: ' . $type . ' ' . $token,
                        'Cookie: ETH_SESSION=!ior/fQiW7O8ThsTChvSrzlMjym9WiacV/DdjNd2BqWMy0tDi781u4U9TpxMOe8AiwnVcQnwZMGUoHA=='
                    ),
                    CURLOPT_SSL_VERIFYPEER => false, // Désactive la vérification du certificat SSL
                    CURLOPT_SSL_VERIFYHOST => false  // Désactive la vérification du nom d'hôte
                ));

                $response = curl_exec($handle);

                if ($response !== false) 
                {
                        $this->save_log($response, "response_note_passport");
                        curl_close($handle);
      
                        return json_decode($response);
                } 
                else 
                {
                        $error_message = curl_error($handle); // Récupérer le message d'erreur
                        curl_close($handle);
                        
                     
                        $this->save_log($error_message, "error_note"); // Sauvegarder l'erreur dans les logs
                        return 'E000';
                } 
        }
        
        public function confirmnote_permis($data,$token,$type)
        {
                //$url = 'https://217.171.94.180:40015/api/v1/paiement/confirmation'; // UAT
                //$url = 'https://apilogirad.dgrad.cd/api/v1/paiement/confirmation'; // PROD
            
                $url = 'https://217.171.92.177/api/v1/paiement/confirmation'; // UAT
                $handle = curl_init();
                # Créer la charge utile JSON
                $post_fields = json_encode([
                        "username" => "equitybcdc",
                        "password" => "=rrY)>Fbr572cU]",
                        "numeroNotePerception" => $data['numeroNotePerception'],
                        "numeroPaiement" => $data['numeroPaiement'],
                        "datePaiement" => $data['datePaiement'],
                        "devise" => $data['devise'],
                        "montant" => $data['montant'],
                        "tauxChange" => $data['tauxChange'],
                        "codeBanque" => $data['codeBanque'],
                        "codeAgence" => $data['codeAgence'],
                        "agence" => $data['agence'],
                ]);

                curl_setopt_array($handle, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $post_fields,
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Authorization: ' . $type . ' ' . $token,
                        'Cookie: ETH_SESSION=!ior/fQiW7O8ThsTChvSrzlMjym9WiacV/DdjNd2BqWMy0tDi781u4U9TpxMOe8AiwnVcQnwZMGUoHA=='
                    ),
                    CURLOPT_SSL_VERIFYPEER => false, // Désactive la vérification du certificat SSL
                    CURLOPT_SSL_VERIFYHOST => false  // Désactive la vérification du nom d'hôte
                ));

                $response = curl_exec($handle);

                if ($response !== false) 
                {
                        $this->save_log($response, "response_note_passport");
                        curl_close($handle);
      
                        return json_decode($response);
                } 
                else 
                {
                        $error_message = curl_error($handle); // Récupérer le message d'erreur
                        curl_close($handle);
                        
                     
                        $this->save_log($error_message, "error_note"); // Sauvegarder l'erreur dans les logs
                        return 'E000';
                } 
        }

        public function save_note($data, $id)
        {
                $this->set_table('logiref_integration_logirad', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_note_passport($data, $reference)
        {
                $builder = $this->db->table('logiref_integration_logirad');
                $builder->where('Reference_21', $reference);
                return $builder->update($data);
        }

        //Save Log
        public function save_log($data, $prefix = NULL)
        {
                $name = gmdate('Y-m-d')."_".$prefix;

                $path = ROOTPATH . 'drive/logs/services/Logirad';

                if (is_dir($path)==false)
                {
                        mkdir($path,0777,true);
                }

                $path = $path."/".$name;

                $handle = fopen($path.".logs", 'a+');
                $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                fwrite($handle, $data."\n\n");
                fclose($handle);
        }

}