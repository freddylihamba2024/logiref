<?php

namespace Modules\Branch\Models;

use App\Models\MY_Transaction;

class ComptabilisationModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Glodi on the 22.09.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
       
	
	public function __construct()
	{
		parent::__construct();
	}
        
        public $months = array
                        (
                            '00' => '',
                            '01' => 'Janvier',
                            '02' => 'Fevrier',
                            '03' => 'Mars',
                            '04' => 'Avril',
                            '05' => 'Mai',
                            '06' => 'Juin',
                            '07' => 'Juillet',
                            '08' => 'Aout',
                            '09' => 'Septembre',
                            '10' => 'Octobre',
                            '11' => 'Novembre',
                            '12' => 'Decembre'
                        );
        
        public $months_abrv = array
                        (
                            '00' => '',
                            '01' => 'Jan',
                            '02' => 'Feb',
                            '03' => 'Mar',
                            '04' => 'Apr',
                            '05' => 'May',
                            '06' => 'Ju',
                            '07' => 'Jly',
                            '08' => 'Aug',
                            '09' => 'Sep',
                            '10' => 'Oct',
                            '11' => 'Nov',
                            '12' => 'Dec'
                        );
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="beneficiary_tax_others_banks")
                {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Nivellement_20 = '1' ";
                        
                        $query = $this->db->table('logiref_comptes')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Recette_13']]['Agence_12'] = $row['Bank_21'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('TABLE_NAME')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResult() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Userid_13'];
                        }
                        return $ddmenu;
                }
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_dgda($bl) 
        {
                $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgda')
                        ->select('logiref_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();
                
                return $query->getResult();
        }
        
        public function get_first_instructions_dgda($bl) 
        {
                $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 AND Priority_24 = 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgda')
                        ->select('logiref_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();
                
                return $query->getResult();
        }
        
        
        public function get_comptant_batch_instructions($bl) 
        {
                $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_comptant_batch_cbs_instructions_dgda')
                        ->select('logiref_comptant_batch_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                
                return $query->getResult();
        }
        
        public function get_prepayment_instructions($bl) 
        {
                $st = " Paiementid_4='" . $bl . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->select('logiref_cbs_prepayments_instructions.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_dgi($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                        ->select('logiref_cbs_instructions_dgi.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_attestation_dgi($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 = 1 AND (TypeCompte_25='F' OR TypeCompte_25='T' ) ";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                        ->select('logiref_cbs_instructions_dgi.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();
                
                return $query->getResult();
        }
        
        public function get_instructions_dgi_amr_b($ref) 
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 AND Details_23 = 'AMR-B' ";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                        ->select('logiref_cbs_instructions_dgi.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();
                
                return $query->getResult();
        }
        
        public function get_instructions_dgrad($ref) 
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgrad')
                        ->select('logiref_cbs_instructions_dgrad.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_passeport($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_passeport')
                        ->select('logiref_cbs_instructions_passeport.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_permis($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_permis')
                        ->select('logiref_cbs_instructions_permis.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_immatriculation($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                        ->select('logiref_cbs_instructions_immatriculation.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_immatriculation_siop($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 2 AND  Montant_10 > 0 AND Priority_27 = 0";
                $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                        ->select('logiref_cbs_instructions_immatriculation.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_immatriculation_by_id($id)
        {
                $st = " Paiementid_4='" . $id . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_immatriculation')
                        ->select('logiref_cbs_instructions_immatriculation.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_dgrk($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgrk')
                        ->select('logiref_cbs_instructions_dgrk.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_dgpek($ref)
        {
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_cbs_instructions_dgpek')
                        ->select('logiref_cbs_instructions_dgpek.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_instructions_others_taxes()
        {
                $date = gmdate('Y-m-d');
                $st = " Nivellement_27 = 1";

                $query = $this->db->table('logiref_cbs_instructions_dgda')
                        ->select('logiref_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();

                return $query->getResult();
        }

        public function get_filtre_others($type=NULL, $data=NULL)
        {
                $this->_table_name = '';
                $user = $this->session->userdata['user_id'];
                $guichet =$_SESSION['Logiref_guichet'];
                $date = gmdate('Y-m-d');

                $st = " Status_2 = '1' AND Nivellement_27 = 1";

                #Filtre d'affichage
                if(isset($_POST['Recette']) && $_POST['Recette']!='') $st .= " AND Codetaxe_28='".$_POST['Recette']."' ";
                if((isset($_POST['start']) && $_POST['start']!='') && (isset($_POST['end']) && $_POST['end']!='')) $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Query
                $query = $this->db->table('logiref_cbs_instructions_dgda')
                        ->select('logiref_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->limit('500')
                        ->get();
                return $query->getResult();
        }
        



        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        public function get_use_case($data)
        {
                ##################### Cas 2 ############################################
                //Ordre de paiement: devise compte client === devise recette en CDF === devise commission
                if($data['Devise_34']==$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }

                ##################### Cas 3 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise compte client === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }

                ##################### Cas 4 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise recette === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_12']==$data['Devise_24'])
                {
                        return "case_2";
                }
                elseif($data['Devise_34']==$data['Devise_12'] && $data['Devise_12']!=$data['Devise_24'])
                {
                       return "case_2";
                }
                else
                {
                     return "case_0";
                }
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Instruction de comptabilisation
         * *************************************************************************************************************************SCETION 2
        */
        
        ##################### Cas 1 ###########################################################
        //Paiment au comptant en CDF | Mode is ESPECE
        public function get_instructions_case_1($data, $comptes,$regie, $comptes_recettes_dgi = NULL)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';

                if($regie == "DGPEK" || $regie == "DGRK"){

                        $compte_dst = '00000000000000000000000';

                        if (isset($comptes[$regie]) && is_array($comptes[$regie])) {
                                foreach ($comptes[$regie] as $compte => $devises) {
                                        if (isset($devises[$data['Devise_12']])) {
                                                $compte_dst = $devises[$data['Devise_12']];
                                                break;
                                        }
                                }
                        }

                }
                else{
                        $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000';
                }
                $libelle = $data['Beneficaire_15'].' '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'C', 
                                                'Compte_9'=>$compte_dst, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12']
                                            );
                        $instructions[] = $instruction;
                }
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_cfb, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_tva, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        ##################### Cas 2 ############################################
        //Ordre de paiement: compte client et recette a payer en CDF/ou en USD
        public function get_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL,$bank=NULL)
        {
                $instructions = array();
                $bank = substr($_SESSION['userdata']["account_pageid"], 1);
                $bank_code = ucfirst($bank);

                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 

                if($data['Beneficaire_15'] == "DGDA")
                {
                        $libelle = $data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                }
                elseif($data['Beneficaire_15'] == "DGI")
                {
                        $notereference = json_decode($data['Notereference_30'], true);
                        $standard = explode('-', $notereference['standard']);
                        $periode = isset($standard[0]) ? $standard[0] : "00";
                        $periode = isset($this->months[$periode]) ? $this->months[$periode] : "";

                        $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;

                        //$libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                        $libelle = $data['Designation_14'].' '.$notereference['Motif'];
                }
                elseif($data['Beneficaire_15'] == "DGRAD")
                {
                        $libelle = $data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                }
                else{
                        $libelle = $data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                }

                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
               
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000';
                
                if($data['Beneficaire_15'] == 'DGI')
                {
                        $notereference = json_decode($data['Notereference_30'], true);
                        $libelle = 'Frais bancaire '.$data['Designation_14'].' '.$notereference['Motif'];
                }
                elseif($data['Beneficaire_15'] == 'DGRAD')
                {
                        $libelle = 'Frais bancaire '.$data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                }
                else
                {
                        //$libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                        $libelle = 'Frais bancaire '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                }
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                
                if($data['Beneficaire_15'] == 'DGI')
                {
                        $libelle = 'TVA '.$data['Designation_14'].' '.$notereference['Motif'];
                }
                elseif($data['Beneficaire_15'] == 'DGRAD')
                {
                        $libelle = 'TVA '.$data['Designation_14'].' '.$data['Noteid_26'].' '.$data['Typerecette_17'];
                }
                else
                {
                        //$libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                        $libelle = 'TVA '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];

                }
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                if(isset($data['Typerecette_17']) && $data['Typerecette_17'] == '27022470')
                {
                        #return $instructions;
                        # Montant frais bcc

                        if($data['Devise_12'] == 'CDF')
                        {
                                $montant = $data['Montant_11']*0.0005;
                        }
                        else 
                        {
                                $montant = 0;
                        }

                        # Operation 4: crediter le compte frais bcc
                        $compte_fbc = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];

                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant, 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_fbc
                                            );
                        $instructions[] = $instruction;
                }
                
                return $instructions;
        }
        
        ##################### Cas 2 ############################################
        //Ordre de paiement: compte client et recette a payer en CDF/ou en USD
        public function get_prepaiement_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';

                if($regie == "DGPEK" || $regie == "DGRK"){

                        $compte_dst = '00000000000000000000000';

                        if (isset($comptes[$regie]) && is_array($comptes[$regie])) {
                                foreach ($comptes[$regie] as $compte => $devises) {
                                        if (isset($devises[$data['Devise_12']])) {
                                                $compte_dst = $devises[$data['Devise_12']];
                                                break;
                                        }
                                }
                        }

                }
                else{
                        $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000';
                }

                if($data['Beneficaire_15'] == "DGDA")
                {
                        $libelle = $data['Noteid_26'].' '.$data['Designation_14'];
                }
                elseif($data['Beneficaire_15'] == "DGI")
                {
                        $notereference = json_decode($data['Notereference_30'], true);
                        $standard = explode('-', $notereference['standard']);
                        $periode = isset($standard[0]) ? $standard[0] : "00";
                        $periode = isset($this->months[$periode]) ? $this->months[$periode] : "";
                        
                        $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                }
                elseif($data['Beneficaire_15'] == "DGRAD")
                {
                        $libelle = $data['Noteid_26'].' '.$data['Notedate_27'].' '.$data['Typerecette_17'].' '.$data['Designation_14'];
                } 
               
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        ##################### Cas 3 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_3($data, $comptes,$regie, $comptes_recettes_dgi = NULL)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_dst = 'CPU' : $compte_dst = 'CCV';
                $compte_cdt = isset($comptes[$bank_code][$compte_dst][$data['Devise_34']]) ? $comptes[$bank_code][$compte_dst][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = $data['Montant_11'] / $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                $libelle = $regie.' '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $compte_debit);
                        $instructions[] = $instruction;
                }
                else 
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_cdt, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Compte_13'=>$compte_cdt
                                            );
                        $instructions[] = $instruction;
                }
                
                # Operation 2: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24 '],
                                        'Compte_13'=>$compte_tva
                                    );
                
                $instructions[] = $instruction;
                
                
                # Operation 4: crediter soit le compte passage en USD ou soit le compte guichet unique
                # pour debiter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                
                //Compter a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$regie][$compte_src][$data['Devise_12']]) ? $comptes[$regie][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compter a crediter
                ($regie=="DGDA") ? $compte_dst = 'CGU' : $compte_dst = 'CPT';
                $compte_cdt = isset($comptes[$regie][$compte_dst][$data['Devise_12']]) ? $comptes[$regie][$compte_dst][$data['Devise_12']] : '00000000000000000000000'; 
                
                $libelle = $regie.' '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_cdt
                                    );
                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        ##################### Cas 4 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_4($data, $comptes,$regie, $comptes_recettes_dgi = NULL)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_cdt = 'CPU' : $compte_cdt = 'CCV';
                $compte_dst = isset($comptes[$bank_code][$compte_cdt][$data['Devise_34']]) ? $comptes[$bank_code][$compte_cdt][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = ($data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23'] * 0.16))/ $data['Taux_41'] : $montant_cdt = ($data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23'] * 0.16)) * $data['Taux_41'];
                
                $noteid = isset($data["Noteid_26"]) ? $data["Noteid_26"] : "";
                
                $libelle = $regie.' '.$noteid.' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_cdt, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                
                
                # Operation 2: crediter soit le compte passage en USD ou soit le compte guichet unique
                # pour debiter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                
                //Compte a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compte a crediter
                ($regie=="DGDA") ? $compte_dst = 'CGU' : $compte_dst = 'CPT';
                $compte_cdt = isset($comptes[$regie][$compte_dst][$data['Devise_12']]) ? $comptes[$regie][$compte_dst][$data['Devise_12']] : '00000000000000000000000'; 
                
                $libelle = $regie.' '.$noteid.' '.$data['Designation_14'].' '.$data['Nif_13'];
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_dbt, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_cdt
                                            );
                        $instructions[] = $instruction;
                }
                
                # Operation 3: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_34']]) ? $comptes[$bank_code]['CFB'][$data['Devise_34']] : '000000000000000000000000'; 
                
                //Compte a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                ($data['Devise_34']=="USD") ? $montant_cdt = $data['Montant_11'] / $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                $libelle = 'Frais bancaire '.$noteid.' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 5: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$noteid.' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                
                $instructions[] = $instruction;
                
                
                if($comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $compte_dst);
                        $instructions[] = $instruction;
                }
                
                return $instructions;
        }
        
        
        public function get_instructions_for_roundings($data, $comptes, $amount)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                $compte_dst = isset($comptes[$bank_code]['CTA'][$data['Devise_12']]) ? $comptes[$bank_code]['CTA'][$data['Devise_12']] : '000000000000000000000000';  
                
                if($data['Beneficaire_15'] == "DGDA")
                {
                        $libelle = 'Arrondis '.$data['Service_16'].' '.$data['Noteid_26'].' '.$data['Designation_14'];
                }
                elseif($data['Beneficaire_15'] == "DGI")
                {
                        $notereference = json_decode($data['Notereference_30'], true);
                        
                        //$libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;
                        $libelle = 'Arrondis '.$data['Designation_14'].' '.$notereference['Motif'];
                }
                elseif($data['Beneficaire_15'] == "DGRAD")
                {
                        $libelle = 'Arrondis '.$data['Noteid_26'].' '.$data['Notedate_27'].' '.$data['Typerecette_17'].' '.$data['Designation_14'];
                }
               
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$amount, 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                    );
                
                return $instruction;
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Cles de repartition
         * *************************************************************************************************************************SCETION 2
        */
        
        //DGI Cotisation - IPR 
        public function get_instructions_gu_dgi($data, $comptes,$regie)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                
                $infos = json_decode($data['Notereference_30'], true);
                
                $compte_ONEM = isset($comptes['ONEM']['CPI'][$data['Devise_12']]) ? $comptes['ONEM']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_INPP = isset($comptes['INPP']['CPI'][$data['Devise_12']]) ? $comptes['INPP']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_CNSS = isset($comptes['CNSS']['CPI'][$data['Devise_12']]) ? $comptes['CNSS']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
               
                

                //$libelle = 'ONEM '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $libelle = 'ONEM '.$data['Designation_14'].' '.$infos['Motif'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasONEM'], 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_ONEM
                                    );
                $instructions[] = $instruction;
                
                //$libelle = 'INPP '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                 $libelle = 'INPP '.$data['Designation_14'].' '.$infos['Motif'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasINPP'], 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_INPP 
                                    );
                $instructions[] = $instruction;
                
                
                //$libelle = 'CNSS '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $libelle = 'CNSS '.$data['Designation_14'].' '.$infos['Motif'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['QuotasINSS'], 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_CNSS
                                    );
                $instructions[] = $instruction;

                
                return $instructions;
        }
        	//DGI Vente des plaques - REIMATTRIC
        public function get_instructions_vente_gu_dgi($data, $comptes,$regie, $service_types = NULL, $periode = NULL)
        {
                #var_dump("treses");die;
                $instructions = array();
                $bank_code = 'Rawbank';
                
                $infos = json_decode($data['Notereference_30'], true);
                
                $compte_DGI = isset($comptes['DGI']['CPI'][$data['Devise_12']]) ? $comptes['DGI']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_SYNTELL = isset($comptes['SYNTELL']['CPI'][$data['Devise_12']]) ? $comptes['SYNTELL']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_UTSCH = isset($comptes['UTSCH']['CPI'][$data['Devise_12']]) ? $comptes['UTSCH']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_RTNC = isset($comptes['RTNC']['CPI'][$data['Devise_12']]) ? $comptes['RTNC']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_SONAS = isset($comptes['SONAS']['CPI'][$data['Devise_12']]) ? $comptes['SONAS']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_HOLOGRAMME = isset($comptes['HOLOGRAMME']['CPI'][$data['Devise_12']]) ? $comptes['HOLOGRAMME']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
				
                
                $libelle = 'UTSCH '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantUTSCH'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_UTSCH
                                    );
                $instructions[] = $instruction;
				
				$libelle = 'SYNTELL '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantSYNTELL'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_SYNTELL
                                    );
                $instructions[] = $instruction;
                
				$libelle = 'DGI '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantDGI'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_DGI
                                    );
                $instructions[] = $instruction;
                
                $libelle = 'SONAS '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantSONAS'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_SONAS
                                    );
                $instructions[] = $instruction;
                
                $libelle = 'HOLOGRAME '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantHOLOGRAMME'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_HOLOGRAMME
                                    );
                $instructions[] = $instruction;
                
                 
                $libelle = 'RTNC '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$infos['MontantRTNC'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_RTNC
                                    );
                $instructions[] = $instruction;
                

                return $instructions;
                
               
        }
        
        //Guichet Unique en douane
        public function get_instructions_gu_dgda($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                $regie = 'DGDA';
                $notereference = json_decode($data['Notereference_30'], true);
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']];
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'];
                
                if($compte_dst == $compte_sus)
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst,
                                                'Details_23'=>'Nouvelle taxe',
                                                'Codetaxe_28'=>$data['Typerecette_17']
                                            );
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst,
                                                'Codetaxe_28'=>$data['Typerecette_17']
                                            );
                }
                
                return $instruction;
        }
        
        public function get_instructions_others_banks($compte_src, $comptes, $data)
        {
                $instructions = array();
                $regie = 'DGDA';
                
                $notereference = json_decode($data['Notereference_30'], true);
                
                $tax_amount = $data['Montant_11'] / 1.001;
                $frais_bcc_amount = $tax_amount * 0.001;
                
                $compte_dst = isset($comptes[$data['Typerecette_17']]['CNP']) ? $comptes[$data['Typerecette_17']]['CNP'] : '00000000000000000000000';
                $libelle = 'Frais de nivel B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                
                
                $instruction = array(
                                    'Operation_8'=>'V', 
                                    'Compte_9'=>$compte_src,
                                    'Libelle_12'=>$libelle, 
                                    'Montant_10'=>$tax_amount, 
                                    'Devise_11'=>$data['Devise_12'],
                                    'Compte_13'=>$compte_dst,
                                    'Nivellement_27'=>1,
                                    'Codetaxe_28'=>$data['Typerecette_17']
                                );
                
                $instructions[] = $instruction;
                
                $compte_dst = isset($comptes[$data['Typerecette_17']]['FBC']) ? $comptes[$data['Typerecette_17']]['FBC'] : '00000000000000000000000';
                $libelle = 'Frais BCC B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$notereference['quittanceid'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                
                $instruction = array(
                                    'Operation_8'=>'V', 
                                    'Compte_9'=>$compte_src,
                                    'Libelle_12'=>$libelle, 
                                    'Montant_10'=>$frais_bcc_amount, 
                                    'Devise_11'=>$data['Devise_12'],
                                    'Compte_13'=>$compte_dst,
                                    'Codetaxe_28'=>$data['Typerecette_17']
                                );
                
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        //Guichet Unique en douane
        public function get_prepaiments_instructions_gu_dgda($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Solidaire';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]) && ($data['Typerecette_17'] =='AT3' || $data['Typerecette_17'] =='AT4'))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']];
                        
                        if($data['Typerecette_17']=='AT3' || $data['Typerecette_17']=='AT4')
                        {
                                # Le type de la recette c'est AT3, AT4 mais le service n'est pas defini.
                                $compte_dst = isset($compte_dst['']) ? $compte_dst[''] : $compte_sus;
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                $designation = ($data['Designation_14'] != $data['Designation_14'])? $data['Designation_14'] : $data['Nif_13'];
                
                $libelle = $data['Service_16'].'-'.str_replace(' ', '',$data['Noteid_26']).'-'.$data['Typerecette_17'].'-'.$designation;
                
                if($compte_dst == $compte_sus)
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst,
                                                'Details_23'=>'Nouvelle taxe'
                                            );
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                }
                
                return $instruction;
        }
        
        //Operation de virement du compte CPT Transitoire vers le compte TVA, TVF, TVN, TVO de la dounane
        public function get_instructions_dgi_tva($data, $comptes, $compte_debit = NULL, $service= NULL)
        {
                
                $compte_dst = isset($comptes[$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$data['Typerecette_17']][$data['Devise_12']] : '00000000000000000000000'; 
                
                $notereference = json_decode($data['Notereference_30'], true);
                $standard = explode('-', $notereference['standard']);
                $periode = isset($standard[0]) ? $standard[0] : "00";
                $periode = isset($this->months[$periode]) ? $this->months[$periode] : "";
                
                $libelle = $data['Notedate_27'].' '.$data['Designation_14'].' '.$data['Typerecette_17'].' '.$periode;

                if($compte_debit != NULL)
                {
                                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_debit, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Montant_11'], 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                }
                else
                {
                                $instruction = array(
                                    'Operation_8'=>'V', 
                                    'Compte_9'=>$data['Compte_33'], 
                                    'Libelle_12'=>$libelle, 
                                    'Montant_10'=>$data['Montant_11'], 
                                    'Devise_11'=>$data['Devise_12'],
                                    'Compte_13'=>$compte_dst
                                );
                }
                return $instruction;
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function update_instructions($data, $id) 
        {
                $this->set_table('logiref_cbs_instructions', 'Reference_14', 'Reference_14 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_prepayments_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                $data['Priority_24']=$priority;
                                $data['Reference_14']=$logirefid; 
                                
                                $this->set_table('logiref_cbs_prepayments_instructions', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                if($type=='others') $data['Status_2']=2;
                                else $data['Status_2']=1;
                                
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                $data['Reference_14']=$logirefid;
                                $data['Priority_24']=$priority;
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_first_instructions_dgda($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                $data['Reference_14']= $logirefid;
                                $data['Priority_24']=$priority;
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        
        
            
        public function save_comptant_batch_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                if($type=='others') $data['Status_2']=2;
                                else $data['Status_2']=1;
                                
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                $data['Reference_14']=$logirefid;
                                $data['Priority_24']=$priority;
                                
                                $this->set_table('logiref_comptant_batch_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgi($pid, $paiement, $instructions, $logirefid, $plate=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']= $_SESSION['Logiref_agence'];
                                $data['Guichet_7']= $_SESSION['Logiref_guichet'];
                                $data['Reference_14']=isset($logirefid)? $logirefid: "";//TBD
                                $data['Mode_15']=isset($paiement['Mode_19'])? $paiement['Mode_19'] : "";
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                
                                if (isset($plate)) $data['Plaque_25']=$plate;
                                
                                $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }

                return TRUE;
        }

        public function save_instructions_dgrad($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];

                                $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }

        public function save_instructions_dgrk($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];

                                $this->set_table('logiref_cbs_instructions_dgrk', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }

        public function save_instructions_dgpek($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];

                                $this->set_table('logiref_cbs_instructions_dgpek', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }

        ##################### RBO Methos ######################################


         public function save_rbo_instructions_dgda($pid, $paiement, $instruction, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instruction))
                {
                        $data = array();
                        $data =(array) current($instruction);
                        //Variable d'integration
                        $data['Id_0'] = '';
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');

                        if($type=='others') $data['Status_2']=2;
                        else $data['Status_2']=1;

                        $data['Account_3']= $paiement['Account_3'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Mode_15']=$paiement['Mode_19'];
                        $data['Makerid_16']= $paiement['Makerid_16'];
                        $data['Reference_14']=$logirefid;
                        $data['Priority_24']=$priority;

                        #$data['Type_25']= $paiement['DataType'];

                        $this->set_table('logiref_rbo_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                return TRUE;
        }
        
        public function save_rbo_instructions_dgi($pid, $paiement, $instruction, $logirefid)
        {
                
                //Save instructions
                if(!empty($instruction))
                {
                       
                        $data = array();
                        //$instruction['Id_0'] = '';
                        $data =(array) current($instruction);
                        //Variable d'integration
                        $data['Id_0'] = '';
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $paiement['Account_3'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Reference_14']=$logirefid; //TBD
                        $data['Mode_15']=$paiement['Mode_19'];
                        $data['Makerid_16']=$paiement['Makerid_16'];

                        $this->set_table('logiref_rbo_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                
                return TRUE;
        }
        
        public function save_rbo_instructions_dgrad($pid, $paiement, $instruction, $logirefid)
        {
                 //Save instructions
                if(!empty($instruction))
                {
                        $data = array();
                        $data =(array) current($instruction);
                        //Variable d'integration
                        $data['Id_0'] = '';
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $paiement['Account_3'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $paiement['Banqueid_5'];
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Reference_14']=$logirefid;
                        $data['Mode_15']=$paiement['Mode_19'];
                        $data['Makerid_16']=$paiement['Makerid_16'];

                        $this->set_table('logiref_rbo_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                return TRUE;
        }
        
        public function save_rbo_comptatbilisation_dgda($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                $data['Status_2']=1;
                                
                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']= $paiement['Makerid_16'];
                                $data['Reference_14']=$logirefid;
                                //$data['Priority_24']=$priority;
                                
                                #$data['Type_25']= $paiement['DataType'];
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                
                return TRUE;
        }
        
        public function save_rbo_comptatbilisation_dgi($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                       
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$paiement['Makerid_16'];
                                
                                $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                
                return true;
                
        }
        
        public function save_rbo_comptatbilisation_dgrad($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $paiement['Account_3'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $paiement['Banqueid_5'];
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Reference_14']=$logirefid; //TBD
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$paiement['Makerid_16'];
                                
                                $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        
        
        public function delete_instructions_dgi($id)
	{
//		$this->db->where('Reference_14', $id);
//		return $this->db->delete('logiref_cbs_instructions_dgi');

                $builder = $this->db->table('logiref_cbs_instructions_dgi');
                $condition = ['Reference_14' => $id];

                $builder->where($condition);
                $builder->delete();

                return $builder;
	}

        public function delete_instructions_dgrad($id)
	{
                $builder = $this->db->table('logiref_cbs_instructions_dgrad');
                $condition = ['Reference_14' => $id];

                $builder->where($condition);
                $builder->delete();

                return $builder;
	}

        public function delete_instructions_dgrk($id)
	{
		$builder = $this->db->table('logiref_cbs_instructions_dgrk')
                        ->where(['Reference_14' => $id])
                        ->delete();
                return $builder;
	}

        public function delete_instructions_dgpek($id)
	{
		$builder = $this->db->table('logiref_cbs_instructions_dgpek')
                        ->where(['Reference_14' => $id])
                        ->delete();
                return $builder;
	}

        public function delete_instructions_dgda($id)
	{
                $builder = $this->db->table('logiref_cbs_instructions_dgda');
                $condition = ['Paiementid_4' => $id];

                $builder->where($condition);
                $builder->delete();

                return $builder;
	}

        public function update_instructions_cbs_dgi($ids, $data)
        {
                if (strpos($ids, ',') !== false):
                        $ids =  explode(",", $ids);
                else:
                        $ids = array($ids);
                endif;

                $id = $this->db->table('logiref_cbs_instructions_dgi')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                
                return $id;
        }
        
        public function update_instructions_cbs_dgrad($ids, $data)
        {
                if (strpos($ids, ',') !== false):
                        $ids =  explode(",", $ids);
                else:
                        $ids = array($ids);
                endif;

                $id = $this->db->table('logiref_cbs_instructions_dgrad')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                
                return $id;
        }
        
        public function update_instructions_cbs_dgda($ids, $data)
        {
                if (strpos($ids, ',') !== false):
                        $ids =  explode(",", $ids);
                else:
                        $ids = array($ids);
                endif;

                $id = $this->db->table('logiref_cbs_instructions_dgda')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                
                return $id;
        }
        
        public function update_prepayments_instructions_cbs($ids, $data)
        {
                if (strpos($ids, ',') !== false):
                        $ids =  explode(",", $ids);
                else:
                        $ids = array($ids);
                endif;

                $id = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                
                return $id;
        }

        public function get_cbs_instructions_passport_attempts($id = NULL,$priority = NULL)
        {
                $this->set_table('logiref_cbs_instructions_passeport I', 'I.Id_0', 'I.Id_0 DESC');
                $data = $this->get_by(array('Paiementid_4' => $id,'Priority_27'=>$priority), TRUE);
                if(!empty($data))
                {
                        return $data->Attempts_29;
                }
                else
                {
                        return 0;
                }
        }
        
        public function update_cbs_instructions_passport_attempts($paiement_id, $priority)
        {
                $attempts = $this->get_cbs_instructions_passport_attempts($paiement_id, $priority);
                $data = array(
                        'Attempts_29' => $attempts + 1,
                );
                $builder = $this->db->table('logiref_cbs_instructions_passeport');

                $builder->where("logiref_cbs_instructions_passeport.Paiementid_4 ='".$paiement_id."' AND Priority_27 = '".$priority."'");
                
                return $builder->update($data);
        }
}
