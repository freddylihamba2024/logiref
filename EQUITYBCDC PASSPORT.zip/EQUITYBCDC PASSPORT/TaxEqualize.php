<?php

namespace Modules\Branch\Controllers;

use Modules\Branch\Models\PasseportModel;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\UserModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\AccountModel;
use Modules\Branch\Models\ReportsModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ImmatriculationModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;
use Modules\Services\Logirad\Controllers\Logirad;

class TaxEqualize extends BaseController
{
        /*
        * Presentation:
        * Last update:
        * By Glodi on the 17.10.2023
        * *  *************************************************************************************************************************SECTION 1
        */


    public $menus = array('unequalized', 'equalized','unequalizedpassports');
    public $roles = '5';

    public $role = '';
    public $group = 'banks'; //Banks, Regies, Clients
    public $tva = 0.16;
    public $restrictions = 0; //1 = no access or limited access
    public $module = 'branch';
    public $folder = 'equalize';
    public $finacle=null;
    public $encaissementModel;
    public $integrationModel;
    public $logirefModel;
    public $bulletinsModel;
    public $dataModel;
    public $comptabilisationModel;
    public $immatriculationModel;
    public $ratesModel;
    public $accountModel;
    public $feesModel;
    public $functionalities;
    public $bank;
    public $core_banking;
    public $igor;
    public $amplitude;
    public $synergies;
    public $bsqr;
    public $curlModel;
    public $prepaymentsModel;
    public $branchModel;
    public $userModel;
    public $mainModel;
    public $reportsModel;
    public $amplitude_solidairebanque;
    public $fibridge;
    public $flexcube;
    public $finacle_standardbank;
    public $base_url;
    public $cyclone;

    public $logirad;

    private $passportModel;

        public function __construct()
        {
                parent::__construct();
                /*
                * Module is Branch 
                * function will be set within display function
                * PS: A modifier au besoin!!
                */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->ratesModel = new RatesModel();
                $this->accountModel = new AccountModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->branchModel = new BranchModel();
                $this->userModel = new UserModel();
                $this->mainModel = new MainModel();
                $this->reportsModel = new ReportsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->immatriculationModel=new ImmatriculationModel();
                $this->synergies = new Synergies();
                $this->igor = new Igor();
                $this->amplitude = new Amplitude();
                $this->bsqr = new Bsqr();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->finacle_standardbank =new FinacleStandardBank();
                $this->finacle = new Finacle();
                $this->cyclone = new Cyclone();
                $this->passportModel = new PasseportModel();
                $this->logirad = new Logirad();


                $this->folder = 'equalize';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxequalize';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = strtolower($this->session->userdata["account_cbs"]);
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();
                
                /*
                * Control user access to this module
                * If role is not set to access this module, then access denied
                */

                if ($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                $this->role = isset($_SESSION['Logiref_role'])?$_SESSION['Logiref_role']:"";

                $this->base_url = getenv('LOGIREF_ENTERPRISE_BASE_URL');
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
         */

        public function set($needle)
        {
                if (in_array($needle, $this->menus))
                {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
         */

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "unequalized")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_regulate();
                        $this->data['encaissements_batchs'] = [];
                        $this->data['encaissements_immatriculation'] = $this->reportsModel->get_paiements_immatriculation_to_regulate();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls_to_regulate();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls_to_regulate();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\equalize\unequalized', $this->data);
                }
                elseif ($obj == "equalized")
                {
                        $this->data['regularisations'] = $this->logirefModel->regularisations;
                        echo view('\Modules\Branch\Views\equalize\equalized', $this->data);
                }
                elseif ($obj == "regularisation_dgi")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_regularized_DGI();
                        echo view('\Modules\Branch\Views\equalize\_' . $obj, $this->data);
                }
                elseif ($obj == "regularisation_dgrad")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_regularized_DGRAD();
                        echo view('\Modules\Branch\Views\equalize\_' . $obj, $this->data);
                }
                elseif ($obj == "regularisation_dgda")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['bulletins'] = $this->reportsModel->get_paiements_to_regularized_DGDA();
                        echo view('\Modules\Branch\Views\equalize\_' . $obj, $this->data);
                }
                elseif ($obj == "declaration")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGI", $province = NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGI");
                        $this->data['recettes'] = $recettes["DGI"];

                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);

                        if (empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                        $succes = array();

                        $instructions = $this->comptabilisationModel->get_instructions_dgi($logirefid);

                        foreach ($instructions as $value):
                            $succes[] = $value->Status_2;
                        endforeach;

                        if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))
                        {
                                $this->data['validate'] = '';
                        }
                        else
                        {
                                $this->data['validate'] = 'disabled';
                        }

                        if (!in_array('2', $succes) && !in_array('4', $succes))
                        {
                                $this->data['delete'] = '';
                        }
                        else
                        {
                                $this->data['delete'] = 'disabled';
                        }

                        echo view('\Modules\Branch\Views\equalize\_declaration', $this->data);
                }
                elseif ($obj == "note")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGRAD", $province = NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);

                        if (empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                        $succes = array();

                        $instructions = $this->comptabilisationModel->get_instructions_dgrad($logirefid);

                        foreach ($instructions as $value):
                            $succes[] = $value->Status_2;
                        endforeach;

                        if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) 
                        {
                                $this->data['validate'] = '';
                        }
                        else
                        {
                                $this->data['validate'] = 'disabled';
                        }

                        if (!in_array('2', $succes) && !in_array('4', $succes)) 
                        {
                                $this->data['delete'] = '';
                        }
                        else
                        {
                                $this->data['delete'] = 'disabled';
                        }

                        echo view('\Modules\Branch\Views\equalize\_note', $this->data);
                }
                elseif ($obj == "passport")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGRAD", $province = NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->passportModel->get_paiement_info($id);

                        // if (empty($encaissement))
                        // {
                        //         $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        // }

                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                        $succes = array();

                        $instructions = $this->comptabilisationModel->get_instructions_passeport($logirefid);

                        foreach ($instructions as $value):
                            $succes[] = $value->Status_2;
                        endforeach;

                        if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) 
                        {
                                $this->data['validate'] = '';
                        }
                        else
                        {
                                $this->data['validate'] = 'disabled';
                        }

                        if (!in_array('2', $succes) && !in_array('4', $succes)) 
                        {
                                $this->data['delete'] = '';
                        }
                        else
                        {
                                $this->data['delete'] = 'disabled';
                        }

                        echo view('\Modules\Branch\Views\equalize\_passeport', $this->data);
                }
                elseif ($obj == "immatriculation")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';

                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';

                        $immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);

                        if(in_array($immatriculation->Status_2,['5','6']))
                        {
                                $this->data['validate'] = 'disabled';
                        }
                        else
                        {
                                $this->data['validate'] = '';
                        }

                        $this->data['encaissement'] = $encaissement = $this->immatriculationModel->immatriculation_migrate_note($immatriculation->Id_0);

                        echo view('\Modules\Branch\Views\equalize\_immatriculation', $this->data);
                }
                elseif($obj=="batch_note")
                {
                        $succes = [];

                        $batch_lines = $this->encaissementModel->get_paiement_batch_info($id);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");

                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $notes = json_decode($batch_lines->Paiements_23, true);

                                $i = 1;
                                for($i=1; $i<=count($notes['references']); $i++) 
                                {
                                        $note = new \stdClass();

                                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $note->reference = $notes['references'][$i];
                                        $note->devise = $notes['devises'][$i];
                                        $note->amount = $amount;

                                        $tables[] = $note;
                                }

                                $logirefid = $batch_lines->Lot_24 ?? "";
                                $instructions = $this->comptabilisationModel->get_instructions_dgrad($logirefid);

                                foreach ($instructions as $value):
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) 
                                        $this->data['validate'] = '';
                                else 
                                        $this->data['validate'] = 'disabled';

                                if (!in_array('2', $succes) && !in_array('4', $succes)) 
                                        $this->data['delete'] = '';
                                else 
                                        $this->data['delete'] = 'disabled';


                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $this->data['failds'] = $tables;
                                $this->data['batch_lines'] = $batch_lines;

                                echo view('\Modules\Branch\Views\equalize\_batch_note', $this->data);

                        }
                }
                elseif ($obj == "bulletin")
                {
                        $bl = $id;
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);

                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\equalize\_bulletin', $this->data);
                }
                elseif ($obj == "prepayment")
                {
                        $bl = $id;
                        $bulletin = $this->integrationModel->get_prepaiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\equalize\_prepayment', $this->data);
                }
                elseif($obj == "unequalizedpassports")
                {
                        // var_dump("gjgjhgjhgj");die;
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_passports_to_regulate();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\equalize\unequalizedpassports', $this->data);
                }
                elseif ($obj == "get_details")
                {
                        /* Get data from DB Integration */
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);

                        echo view('\Modules\Branch\Views\equalize\_details_dgda', $this->data);
                }
                elseif ($obj == "get_details_dgi")
                {
                        /* Get data from DB Integration */
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgi($ref);

                        echo view('\Modules\Branch\Views\equalize\_details_dgi', $this->data);
                }
                elseif ($obj == "get_details_immatriculation")
                {
                        /* Get data from DB Integration */
                        $ref = $id;
                        $immatriculation = $this->integrationModel->get_integration_immatriculation_by_logirefid($ref);

                        if($immatriculation->ValidateBySiop_39 == 1):
                                $this->data['lines'] = $this->comptabilisationModel->get_instructions_immatriculation_siop($ref);
                        else:
                                $this->data['lines'] = $this->comptabilisationModel->get_instructions_immatriculation($ref);
                        endif;

                        echo view('\Modules\Branch\Views\equalize\_details_immatriculation', $this->data);
                }
                elseif ($obj == "get_details_dgrad")
                {
                        /* Get data from DB Integration */
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgrad($ref);

                        echo view('\Modules\Branch\Views\equalize\_details_dgrad', $this->data);
                }
                elseif ($obj == "get_details_passport")
                {
                        /* Get data from DB Integration */
                        $ref = $id;
                        
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_passeport($ref);

                        echo view('\Modules\Branch\Views\equalize\_details_passport', $this->data);
                }
                #Default
                elseif ($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
         */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "regularize_payment")
                {
                        $data = $_POST;

                        $action = $data['action'] ?? "";
                        $regie  = $data ["regie"] ?? "";
                        $id     = $data["transactionid"] ?? "";

                        # Enregistrement de l'action de régularisation
                        $this->save('regularisation', $id, $action, $regie);

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'regularize_payment'))
                        {
                                #Invocation of the api transfer
                                $result = $this->{$core_banking}->regularize_payment($data);

                                echo $result;
                        }
                        else
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                elseif ($obj == "regularize_payment_immatriculation")
                {
                        $data = $_POST;

                        $action = $data['action'] ?? "";
                        $regie  = $data ["regie"] ?? "";
                        $id     = $data["transactionid"] ?? "";

                        # Enregistrement de l'action de régularisation
                        $this->save('regularisation_immatriculation', $id, $action, $regie);

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'regularize_payment'))
                        {
                                #Invocation of the api transfer
                                $result = $this->{$core_banking}->regularize_payment($data);

                                echo $result;
                        }
                        else
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                /*elseif($obj=="regularize_payment_immatriculation")
                {
                        $data = $_POST;

                        $integration_immatriculation = $this->integrationModel->get_integration_immatriculation($data['Id_0']);

                        if(!empty($integration_immatriculation))
                        {
                                $id_immatriculation=$integration_immatriculation->Id_0;

                                if($integration_immatriculation->Status_2=='5')
                                {
                                        $this->save('validate_immatriculation',$id_immatriculation,'sequential');
                                }
                                elseif($integration_immatriculation->Status_2=='6')
                                {
                                        $this->save('validate_immatriculation',$id_immatriculation,'single');
                                }
                        }

                }
                elseif($obj=="validate_immatriculation")
                {
                        $error_code = 0;
                        //Formattage des données
                        $return = $this->immatriculationModel->get_data_validation_immatriculation($id);

                        $processing_mode=$arg;

                        if($processing_mode=="sequential")
                        {
                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        //Traitements spécifiques
                                        // Mise à jour du statut de paiement en statut regularisation
                                        // Pour la premiere sequence
                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 5);

                                        $data = $return['data']['firstTrans'];

                                        $core_banking = strtolower($this->core_banking);

                                        $response = $this->{$core_banking}->regularize_immatriculation($data);
                                        $result = json_decode($response, true);
                                        // $result['response']=200;
                                        if(isset($result['response']) && $result['response'] == 200)
                                        {
                                                // Mise à jour du statut de paiement en statut en cours
                                                // Pour la deuxieme sequence
                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 6);

                                                $data = $return['data']['secondTrans'];

                                                $core_banking = strtolower($this->core_banking);

                                                $response = $this->{$core_banking}->regularize_immatriculation($data);

                                                $result = json_decode($response, true);
                                                // var_dump($response);die;
                                                // $result['response']=200;

                                                if(isset($result['response']) && $result['response'] == 200)
                                                {
                                                        // Mise à jour du statut de paiement en statut en cours
                                                        // Pour la confirmation dans Logirad
                                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 7);
                                                }
                                                elseif(isset($return['code']) && $return['code'] == 300)
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->integrationModel->update_integration_immatriculation_attempts($id, 1);

                                                        $error_code = 300;
                                                        $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                }
                                                elseif(isset($return['code']) && $return['code'] == 411)
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->integrationModel->update_integration_immatriculation_attempts($id, 1);

                                                        $error_code = 411;
                                                        $error_description = 'Problème de connexion lors de l\'intégration des écritures dans le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                                }
                                                else
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->integrationModel->update_integration_immatriculation_attempts($id, 1);

                                                        $error_code = $return['code'];
                                                        $error_description = 'Une erreur inconnue est survenue lors de la communication avec le Core Banking. Veuillez contacter le support technique';
                                                }
                                        }
                                        elseif(isset($return['code']) && $return['code'] == 300)
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = 300;
                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }
                                        elseif(isset($return['code']) && $return['code'] == 411)
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = 411;
                                                $error_description = 'Problème de connexion lors de l\'intégration des écritures dans le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                        }
                                        else
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = $return['code'];
                                                $error_description = 'Une erreur inconnue est survenue lors de la communication avec le Core Banking. Veuillez contacter le support technique';
                                        }
                                }
                                else
                                {
                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                        $this->integrationModel->update_integration_immatriculation_attempts($id, 0);
                                        $error_code = $return['code'];
                                        $error_description = 'Une erreur inconnue est survenue lors de la validation. Veuillez réessayer';
                                }

                                //Return utilisateurs
                                if($error_code != 0)
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $id;
                                        $data_return['message'] = 'Bravo ! paiement valid&eacute; avec succ&egrave;s.';
                                }

                                echo json_encode($data_return);
                        }
                        elseif($processing_mode=="single")
                        {
                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        $data = $return['data']['secondTrans'];
                                        //Traitements spécifiques
                                        // Mise à jour du statut de paiement en statut regularisation
                                        // Pour la premiere sequence
                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, $data['Status_2']);

                                        $core_banking = strtolower($this->core_banking);

                                        $response = $this->{$core_banking}->regularize_immatriculation($data);
                                        $result = json_decode($response, true);
                                        // $result['response']=200;
                                        if(isset($result['response']) && $result['response'] == 200)
                                        {
                                                // Mise à jour du statut de paiement en statut en cours
                                                // Pour la deuxieme sequence
                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 7);

                                        }
                                        elseif(isset($return['code']) && $return['code'] == 300)
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = 300;
                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }
                                        elseif(isset($return['code']) && $return['code'] == 411)
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = 411;
                                                $error_description = 'Problème de connexion lors de l\'intégration des écritures dans le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                        }
                                        else
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                $this->integrationModel->update_integration_immatriculation_attempts($id, 0);

                                                $error_code = $return['code'];
                                                $error_description = 'Une erreur inconnue est survenue lors de la communication avec le Core Banking. Veuillez contacter le support technique';
                                        }
                                }
                                else
                                {
                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                        $this->integrationModel->update_integration_immatriculation_attempts($id, 0);
                                        $error_code = $return['code'];
                                        $error_description = 'Une erreur inconnue est survenue lors de la validation. Veuillez réessayer';
                                }

                                //Return utilisateurs
                                if($error_code != 0)
                                {
                                        $data_return['code'] = $error_code;
                                        $data_return['id'] = '';
                                        $data_return['message'] = $error_description;
                                }
                                else
                                {
                                        $data_return['code'] = 200;
                                        $data_return['id'] = $id;
                                        $data_return['message'] = 'Bravo ! paiement valid&eacute; avec succ&egrave;s.';
                                }

                                echo json_encode($data_return);
                        }

                }*/
                elseif ($obj == "verify_batch")
                {
                        echo '200';
                }
                elseif ($obj == "validateImmatriculation")
                {
                        $immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);
                        $code = $this->immatriculationModel->get_return_immatriculation_code($immatriculation->Id_0);

                        if($code == 200)
                        {
                                $return = $this->immatriculationModel->get_data_confirmation_immatriculation();

                                if(isset($return['code']) && $return['code'] == 200)
                                {
                                        $apidata = $return['data'];

                                        $pid = $this->immatriculationModel->update_integration_immatriculation_validation($id, 7);

                                        $confirmation_response = $this->confirm_payment_note($apidata);

                                        if((in_array($confirmation_response['code'], [200, 201])))
                                        {
                                                // Mise à jour du statut de paiement en statut validE et confirmE
                                                if($immatriculation->IntegrationSiopStatus_40 == 1)
                                                {
                                                        $pid = $this->immatriculationModel->update_integration_immatriculation_validation($id, 3);
                                                }
                                                else{
                                                        $pid = $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);
                                                }

                                                $pid_tresor = $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                $pid_propres = $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);

                                                $taximpression = new \Modules\Branch\Controllers\TaxImpression();
                                                $email = $taximpression->display("attestation_immatriculation", $immatriculation->Id_0);

                                                if ($pid && $pid_tresor && $pid_propres) :
                                                        echo $id;
                                                else :
                                                        echo "E002";
                                                endif;
                                        }
                                        else{
                                                echo "E002";
                                        }

                                }
                                else{
                                        echo "E002";
                                }
                        }
                        else
                        {
                                echo "E002";
                        }
                }
                elseif ($obj == "validateDeclaration")
                {
                        $data = array();
                        $data['Status_2'] = 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->userdata["user_id"];
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                        $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);

                        if ($pid) :
                                echo $id;
                        else :
                                echo "E002";
                        endif;
                }
                elseif ($obj == "validateNote")
                {
                        $data = array();
                        $data['Status_2'] = 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->userdata["user_id"];
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                        $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);

                        if ($pid)
                                echo $id;
                        else
                                echo "E002";
                }
                elseif ($obj == "validate_batchnote")
                {
                        $error_code = 0;
                        $error_description = '';
                        $data_return = [];

                        $data_batch_tresor = [];
                        $data_batch_tresor['Status_2'] = '2';
                        $data_batch_tresor['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data_batch_tresor['Changer_6'] = $_SESSION['userdata']['user_id'] ?? "";

                        $pid = $this->encaissementModel->save_payment_tresor_batch($data_batch_tresor, $id);

                        if ($pid)
                        {
                                $logirefid = $_POST['logirefid'] ?? '';

                                $data_tresor = [];
                                $data_tresor['Checkerid_10'] = $_SESSION['userdata']['user_id'] ?? "";
                                $data_tresor['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                {
                                        $encaissement = $this->encaissementModel->get_paiement_tresor_by_logirefid($logirefid);

                                        $infos = json_decode($encaissement->Notereference_30, true);
                                        if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                        if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                        $data_tresor['Notereference_30'] = json_encode( $infos);
                                }

                                $this->encaissementModel->update_payment_tresor_by_ref($data_tresor, $logirefid);
                        }
                        else
                        {
                                $error_code = 'E002';
                                $error_description = 'Paiement non enregistré, un problème est survenu. Veuillez ressaisir.';
                        }

                        # Retour utilisateur
                        if ($error_code != 0)
                        {
                                $data_return = [
                                        'code'    => $error_code,
                                        'id'      => '', 
                                        'message' => $error_description 
                                ];
                        }
                        else
                        {
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $id, 
                                        'message' => 'Bravo ! Paiement enregistré avec succès.' 
                                ]; 
                        }

                        echo json_encode($data_return); exit;

                } 
                elseif ($obj == "validateBulletin") 
                {
                        $bl_data['Status_2'] = '3';
                        $bl = $this->integrationModel->update_bulletin($bl_data, $id);

                        if ($bl)
                                echo $bl;
                        else
                                echo "E002";
                } 
                elseif ($obj == "validate_prepayment") 
                {
                        $bl_data['Status_2'] = '3';
                        $bl = $this->prepaymentsModel->update_prepayement($bl_data, $id);

                        if ($bl)
                                echo $bl;
                        else
                                echo "E002";
                }
                else if ($obj == "delete")
                {
                        $regie = $param;
                        $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;

                        if ($rType == 'TRESOR' || $rType == 'RFTRESD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_tresor($id);
                        } 
                        elseif ($rType == 'PROPRES' || $rType == 'RFPROPD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_propre($id);
                        }

                        if ($pid == $id)
                        {
                                if ($regie == "DGI"):
                                        $this->comptabilisationModel->delete_instructions_dgi($id);
                                elseif ($regie == "DGRAD"):
                                        $this->comptabilisationModel->delete_instructions_dgrad($id);
                                endif;
                        }

                        #Return
                        echo $pid;
                        die;
                }
                else if ($obj == "delete_batch") 
                {
                        $error_code = 0; 
                        $error_description = ''; 
                        $data_return = [];

                        $data_batch_tresor = [];
                        $data_batch_tresor['Status_2'] = '0';
                        $data_batch_tresor['Deletion_29'] = gmdate('Y-m-d H:i:s');
                        $data_batch_tresor['Deletedby_30'] = $_SESSION['userdata']['user_id'] ?? "";

                        $pid = $this->encaissementModel->save_payment_tresor_batch($data_batch_tresor, $id);

                        if ($pid)
                        {
                                $data_tresor = [];
                                $data_tresor['Status_2'] = '0';
                                $data_tresor['Suppression_40'] = gmdate('Y-m-d H:i:s');;

                                $logirefid = $arg;
                                $this->encaissementModel->update_payment_tresor_by_ref($data_tresor, $logirefid);
                        }
                        else 
                        {
                                $error_code = 'E002'; 
                                $error_description = 'Paiement non supprimé, un problème est survenu. Veuillez ressaisir.';
                        }

                        # Retour utilisateur 
                        if ($error_code != 0) 
                        { 
                                $data_return = [ 
                                        'code'    => $error_code, 
                                        'id'      => '', 
                                        'message' => $error_description 
                                ]; 
                        } 
                        else 
                        { 
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $id, 
                                        'message' => 'Bravo ! Paiement supprimé avec succès.' 
                                ]; 
                        }

                        echo json_encode($data_return); exit;

                }
                elseif ($obj == "regularisation")
                {
                        switch ($param)
                        {
                                case 'DGI':
                                        $lines = $this->integrationModel->get_instructions_dgi_by_id($id);
                                        break;
                                case 'DGRAD':
                                        $lines = $this->integrationModel->get_instructions_dgda_by_id($id);
                                        break;
                                case 'DGDA':
                                        $lines = $this->integrationModel->get_instructions_dgda_by_id($id);
                                        break;
                                default:
                                        $lines = [];
                                        break;
                        }

                        if (!empty($lines))
                        {
                                $data['Status_2'] = 1;
                                $data['Date_1']         = gmdate('Y-m-d H:i:s');
                                $data['Account_3']      = $this->session->userdata['account_id'];
                                $data['Paiementid_4']   = $lines->Paiementid_4;
                                $data['Agence_6']       = $lines->Agence_6;
                                $data['Guichet_7']      = $lines->Guichet_7;
                                $data['Operation_8']    = $lines->Operation_8;
                                $data['Compte_9']       = $lines->Compte_9;
                                $data['Montant_10']     = $lines->Montant_10;
                                $data['Devise_11']      = $lines->Devise_11;
                                $data['Libelle_12']     = $lines->Libelle_12;
                                $data['Compte_13']      = $lines->Compte_13;
                                $data['Reference_14']   = $lines->Reference_14;
                                $data['Mode_15']        = $lines->Mode_15;
                                $data['Makerid_16']     = $lines->Makerid_16;
                                $data['Checkerid_17']   = $lines->Checkerid_17;
                                $data['Validation_18']  = $lines->Validation_18;
                                $data['Integration_20'] = gmdate('Y-m-d H:i:s');

                                if ($arg == 'reverse')      $data['Action_21'] = 'Extourne';
                                elseif ($arg == 'forcing')  $data['Action_21'] = 'Regularisation';
                                elseif ($arg == 'verify')   $data['Action_21'] = 'Verification';
                                else                        $data['Action_21'] = '';

                                $this->integrationModel->save_regularisations($data, NULL);
                        }
                }
                elseif ($obj == "regularisation_immatriculation")
                {
                        $lines = $this->integrationModel->get_instructions_immatriculation_by_id($id);

                        if (!empty($lines))
                        {
                                $data['Status_2'] = 1;
                                $data['Date_1']         = gmdate('Y-m-d H:i:s');
                                $data['Account_3']      = $this->session->userdata['account_id'];
                                $data['Paiementid_4']   = $lines->Paiementid_4;
                                $data['Agence_6']       = $lines->Agence_6;
                                $data['Guichet_7']      = $lines->Guichet_7;
                                $data['Operation_8']    = $lines->Operation_8;
                                $data['Compte_9']       = $lines->Compte_9;
                                $data['Montant_10']     = $lines->Montant_10;
                                $data['Devise_11']      = $lines->Devise_11;
                                $data['Libelle_12']     = $lines->Libelle_12;
                                $data['Compte_13']      = $lines->Compte_13;
                                $data['Reference_14']   = $lines->Reference_14;
                                $data['Mode_15']        = $lines->Mode_15;
                                $data['Makerid_16']     = $lines->Makerid_16;
                                $data['Checkerid_17']   = $lines->Checkerid_17;
                                $data['Validation_18']  = $lines->Validation_18;
                                $data['Integration_20'] = gmdate('Y-m-d H:i:s');

                                if ($arg == 'reverse')      $data['Action_21'] = 'Extourne';
                                elseif ($arg == 'forcing')  $data['Action_21'] = 'Regularisation';
                                elseif ($arg == 'verify')   $data['Action_21'] = 'Verification';
                                else                        $data['Action_21'] = '';

                                $this->integrationModel->save_regularisations($data, NULL);
                        }
                }
                elseif ($obj == "validate_passeport") 
                {
                        
                        if ($id > 0 && ($this->role == 2 || $this->role == 3)) 
                        {
                                $return = $this->passportModel->get_data_validation_passport($id);

                                if (isset($return['code']) && $return['code'] == 200) 
                                {
                                        $transaction = array_keys($return['data']);

                                        if (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[0]) 
                                        {
                                                # Cas 1 : première transaction
                                                $data = $return['data'];
                                                $data_return = $this->data('get_first_transaction', $data, $id);
                                             
                                        }
                                        elseif (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[1]) 
                                        {
                                                # Cas 2 : deuxième transaction
                                                $data = $return['data']['secondTrans'];
                                                $data_return = $this->data('get_second_transaction', $data, $id, $return['data']);
                                        }
                                        else 
                                        {
                                                $data_return = [
                                                        'code' => 400,
                                                        'id' => '',
                                                        'message' => 'Transaction invalide ou manquante.'
                                                ];
                                        }
                                } 
                                else 
                                {
                                        $data_return = [
                                                'code' => $return['code'],
                                                'id' => '',
                                                'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        } 
                        else 
                        {
                                $data_return = [
                                        'code' => 403,
                                        'id' => '',
                                        'message' => 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.'
                                ];
                        }

                        echo json_encode($data_return);
                }
                elseif($obj == "confirm_note")
                {
                        if ($id > 0) 
                        {
                                # On appelle directement la confirmation via la méthode data()
                                $return = $this->data('get_confirmation', null, $id);
                                echo json_encode($return);
                        } 
                        else 
                        {
                                echo json_encode([
                                        'code' => 400,
                                        'id' => '',
                                        'message' => 'Identifiant de paiement manquant ou invalide.'
                                ]);
                        }
                }
        
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
         */

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) 
        {
                if ($obj == "get_users")
                {
                        if ($data != "" && $data != NULL) 
                        {
                                $members = $this->userModel->get_members($data);
                        } 
                        else 
                        {
                                $members = $this->userModel->get_members();
                        }

                        $members = $this->userModel->get_members();

                        return $members;
                }
                elseif($obj == "get_first_transaction") 
                {
                        $first_data  = $data['firstTrans'];
                        $second_data = $data['secondTrans'];
                        $id = $arg;

                        # Statut régularisation (1ère séquence)
                        $this->passportModel->update_payment_validation($id, 5);

                        # First transaction
                        $response = $this->{$this->core_banking}->virement_passport($first_data);
                        $first_result = json_decode($response, true);
                        

                        if (isset($first_result['response']) && $first_result['response'] == 200) 
                        {
                                # Statut en cours (2ème séquence)
                                $this->passportModel->update_payment_validation($id, 6);

                                # Second transaction
                                $response = $this->{$this->core_banking}->virement_passport($second_data);
                                $second_result = json_decode($response, true);

                                if (isset($second_result['response']) && $second_result['response'] == 200) 
                                {
                                        # Confirmation
                                        return $this->data('get_confirmation', null, $id, $data);
                                } 
                                else 
                                {
                                        $this->comptabilisationModel->update_cbs_instructions_passport_attempts($id, 1);

                                        return [
                                                'code' => $second_result['response'] ?? 500,
                                                'id' => '',
                                                'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        } 
                        else 
                        {
                                $this->comptabilisationModel->update_cbs_instructions_passport_attempts($id, 0);

                                return [
                                        'code' => $first_result['response'] ?? 500,
                                        'id' => '',
                                        'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                ];
                        }
                }
                elseif ($obj == "get_second_transaction") 
                {
                        $second_data = $data;
                        $id = $arg;

                        # Statut en cours (2ème séquence)
                        $this->passportModel->update_payment_validation($id, 6);

                        # Second transaction
                        $response = $this->{$this->core_banking}->virement_passport($second_data);
                        $result = json_decode($response, true);

                        if (isset($result['response']) && $result['response'] == 200) 
                        {
                                # Confirmation
                                return $this->data('get_confirmation', null, $id);
                        } 
                        else 
                        {
                                $this->comptabilisationModel->update_integration_dgrad_attempts($id, 1);

                                return [
                                        'code' => $result['response'] ?? 500,
                                        'id' => '',
                                        'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                ];
                        }
                }
                elseif ($obj == "get_confirmation") 
                {
                        $id = $arg;
                       
                        $this->passportModel->update_payment_validation($id, 7);

                        $return = $this->passportModel->get_data_confirmation_passport();
                      
                        if (isset($return['code']) && $return['code'] == 200) 
                        {
                                $apidata = $return['data'];

                                #Call api confirmation
                                $response = $this->logirad->confirm_note_passport($apidata);
                               
                                if ($response == "E200" || $response == "CP200") 
                                {
                                        $this->passportModel->update_payment_validation($id, 2);

                                        return [
                                                'code' => 200,
                                                'id' => $id ?? '',
                                                'message' => 'Paiement validé dans Finacle et confirmé avec succès dans Logirad'
                                        ];
                                } 
                                else 
                                {
                                        return [
                                                'code' => $response,
                                                'id' => $id ?? '',
                                                'message' => 'Paiement validé dans Finacle, mais la confirmation n\'a pas abouti dans Logirad.'
                                        ];
                                }
                        } 
                        else 
                        {
                                return [
                                        'code' => $return['code'],
                                        'id' => $id ?? '',
                                        'message' => $return['message']
                                ];
                        }
                }
        }

        public function get_headers($login=null,$password=null)
        {
                $headers=array();
                $response=array();
                $headers=["Content-Type: application/json","X-Account-Id: 44","x-api-key: Kg1b6bX9m3bGX78364448fass8389434faZAqT1Nyi1zVfpz","x-api-channel: le4"];

                $token_response = $this->get_token("admin@castillo.cd","123456",$headers);

                if($token_response != NULL)
                {
                        $token = "Authorization: Bearer ".$token_response;
                        array_push($headers,$token);

                        $response['code']=200;
                        $response['headers']=$headers;
                }
                else
                {
                        $response['code']=500;
                        $response['message']="Erreur survenue lors de la récupération de token";
                }
                return $response;
        }

        public function get_token($login=null,$password=null,$headers=null)
        {
                $post_data['login']=$login;
                $post_data['password']=$password;

                $token_response = $this->curl($this->base_url."auth/login",'POST',$post_data,$headers);

                $result = json_decode($token_response,true);

                if(isset($result['status']) && $result['status']==200)
                {
                        $token = $result['token'];
                }
                else
                {
                        $token = null;
                }
                return $token;
        }

        private function confirm_payment_note($confirmation_data)
        {
                $post_data = [
                        "numeroNotePerception" => $confirmation_data['numeroNotePerception'],
                        "transactionId" => $confirmation_data['transactionId'],
                        "amount" => $confirmation_data['amount'],
                        "currency" => $confirmation_data['currency'],
                        "transactionReference" => $confirmation_data['transactionReference'],
                        "paymentDate" => $confirmation_data['paymentDate'],
                        "bankName" => $confirmation_data['bankName'],
                        "metadata" => [
                                "x" => 1,
                                "y" => 2
                        ]
                ];

                $headers = $this->get_headers();

                $confirmation_response=array();

                if(isset($headers['code']) && $headers['code']==200)
                {
                        $response = $this->curl($this->base_url."inv/payments/confirm-agency-payment","POST",$post_data,$headers['headers']);

                        $result = json_decode($response,true);

                        if(isset($result['status']) && $result['status']==200)
                        {
                                $confirmation_response['code']=200;
                                $confirmation_response['message']="La confirmation de la note de perception est effectuée avec succès";
                        }
                        elseif(isset($result['status']) && $result['status']==400 && (isset($result['messages']['error']) && mb_stripos($result['messages']['error'],"perception a déjà été payée")!==false))
                        {
                                $confirmation_response['code']=201;
                                $confirmation_response['message']="Cette note de perception a été déjà payée";
                        }
                        else
                        {
                                $confirmation_response['code']=$result['status'];
                                $confirmation_response['message']=$result['messages']['error'];
                        }
                }
                else
                {
                        $confirmation_response['code']=500;
                        $confirmation_response['message']='Une erreur est survenue lors de la confirmation de la note de perception';
                }
                return $confirmation_response;
        }

}

/* End of file welcome.php  */
/* Location: /project/activities  */

