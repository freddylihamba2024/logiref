<?php

        namespace Modules\Branch\Controllers;

        use App\Controllers\BaseController;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Branch\Models\IntegrationModel;
        use Modules\Admin\Models\AccountModel;
        use Modules\Branch\Models\DataModel;
        use Modules\Branch\Models\PasseportModel;
        use Modules\Branch\Models\EncaissementModel;
        use Modules\Branch\Models\CurlModel;
        use Modules\Branch\Models\RatesModel;
        use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
        use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
        use Modules\Services\Logirad\Controllers\Logirad;
        use Modules\Services\Bsqr\Controllers\Bsqr;
        use Modules\Services\Igor\Controllers\Igor;
        use Modules\Services\Flexcube\Controllers\Flexcube;
        use Modules\Services\Amplitude\Controllers\Amplitude;
        use Modules\Services\Synergies\Controllers\Synergies;
        use Modules\Services\FIBridge\Controllers\FIBridge;
        use Modules\Services\Finacle\Controllers\Finacle;
        use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
        use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

        class TaxPasseport extends BaseController {
                /*
                * Presentation:
                * Last update:
                * By Papin on the 25.12.2020
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('','','');
                public $role = '5';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'branch';
                public $folder = 'passeports';

                public $bank = '';
                public $bank_uppercase = '';
                public $core_banking = '';
                public $functionalities = array();
                public $options = array();
                public $roles = array();
                public $branch = '';

                public $logirefModel;
                public $encaissementModel;
                public $integrationModel;
                public $comptabilisationModel;
                public $accountsModel;
                public $dataModel;
                public $passeportModel;
                public $curlModel;
                public $ratesModel;
                public $amplitude;
                public $amplitudeSolidaireBanque;
                public $comptabilisation;
                public $bsqr;
                public $igor;
                public $flexcube;
                public $synergies;
                public $fiBridge;
                public $finacle;
                public $finacleStandardBank;
                public $logirad;

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */
                        $this->logirefModel = new LogirefModel();
                        $this->encaissementModel = new EncaissementModel();
                        $this->integrationModel = new IntegrationModel();
                        $this->comptabilisationModel = new ComptabilisationModel();
                        $this->accountsModel = new AccountModel();
                        $this->dataModel = new DataModel();
                        $this->passeportModel = new PasseportModel();
                        $this->curlModel = new CurlModel();
                        $this->comptabilisation = new Comptabilisation();
                        $this->bsqr = new Bsqr();
                        $this->igor = new Igor();
                        $this->flexcube = new Flexcube();
                        $this->synergies = new Synergies();
                        $this->fiBridge = new FIBridge();
                        $this->finacle = new Finacle();
                        $this->finacleStandardBank = new FinacleStandardBank();
                        $this->amplitude = new Amplitude();
                        $this->amplitudeSolidaireBanque = new AmplitudeSolidaireBanque();
                        $this->ratesModel = new RatesModel();
                        $this->logirad = new Logirad();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'taxpasseport';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                        $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                        $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                        $this->data['i'] = 0;

                        $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                        $this->data['deny'] = false;

                        if ($_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else
                        {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }

                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        $this->branch = $_SESSION['Logiref_guichet'];
                        $this->role = $_SESSION['Logiref_role'];

                        if($this->bank != "")
                        {
                                # Enlever @ dans le pageid
                                # Tranformer la premiere lettre en majuscule
                                $this->bank = substr($this->bank, 1);
                                $this->bank_uppercase = ucfirst($this->bank);
                        }

                }


                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Branch\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }


                /*
                * Manages sidebar menu
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */

                public function set($needle)
                {
                        if(in_array($needle, $this->menus))
                        {
                                if($_SESSION['Logiref_role']==4)
                                {
                                        $this->data['sidebar'] = '';
                                }
                                $this->index();
                        }
                }

                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "start")
                        {
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");

                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_passport', $this->data);
                        }
                        elseif ($obj == "verification")
                        {
                                $data = $_POST;
                                $data['Reference_8'] = strtoupper($data['Reference_8']);
                              
                                # Récupération des données locales
                                $integrations = $this->integrationModel->get_note_by_ref($data['Reference_8']);
                        
                                $result = $this->passeportModel->check_existing_payments($integrations, $data);
                               
                                $code         = $result['code'];
                                $html         = $result['html'];
                                $checked      = $result['checked'];
                                $encaissement = $result['encaissement'] ?? null;

                                # Si aucun résultat local → appel CURL externe
                                if ($code == "E200")
                                {
                                        $code = $this->logirad->get_note_passport($data);
                                }

                                # Gestion des codes d'erreur
                                if ($this->data('handle_error_codes', $data, $code))
                                {
                                        echo json_encode(['code' => $code, 'message' => $html ?? null]);
                                        die;
                                }

                                # Succès : récupération de la note via integration_logirad
                                $note = $this->integrationModel->get_paiement_logirad($code);

                                if (!isset($note->Id_0))
                                {
                                        echo json_encode(['code' => 'E406', 'message' => 'Un problème est survenu. Merci de réessayer plus tard.']);
                                        return;
                                }

                                # Préparation des données
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGRAD", NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes', "DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];

                                if ($checked)
                                {
                                        $pid = $encaissement->Id_0;
                                        $this->data['encaissement'] = $this->encaissementModel->get_paiement_info($pid);
                                }
                                else
                                {
                                        $this->data['encaissement'] = $this->dataModel->logirad_migrate_note($code);
                                }
                           
                                $this->data['note_id'] = $code;
                                $this->data['note']    = $note;

                                $htmlView = view('\Modules\Branch\Views\\'.$this->folder.'\_passport_2', $this->data);
                                echo json_encode(['code' => 'SUCCESS', 'html' => $htmlView]);
                        }
                        elseif($obj == "edit")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = '';
                                $this->data['encaissement'] = $encaissement = $this->passeportModel->get_paiement_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_passport_3', $this->data);
                        }
                        elseif($obj == "preview")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = 'view';
                                $this->data['encaissement'] = $encaissement = $this->passeportModel->get_paiement_info($id);
                                
                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_passport_3', $this->data);
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                echo view($this->lang . '_denial', $this->data);
                        }
                }

                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        //Nouvel enregistrement
                        //Tables concernées: tresor, integration
                        if($obj == 'initiation')
                        {
                                if( !empty($_POST) && ($_POST['Id_0'] == NULL || $_POST['Id_0'] == "") && ($this->role == 4 || $this->role == 9))//Conditions maker nouveau
                                {
                                        //Récupération des données
                                        $error_code = 0;
                                        $return = $this->passeportModel->get_data_passeport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Formattage des données
                                                $data  = $return['data'];
                                                $return = $this->passeportModel->get_formatage_data_passeport($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        //Traitements spécifiques
                                                        //Comptabilisation
                                                        $data  = $return['data'];

                                                        $check_existing_reference = $this->passeportModel->check_paiement_tresor_passeport_by_reference($data['Noteid_26']);

                                                        if(isset($check_existing_reference['code']) && $check_existing_reference['code']!='E200')
                                                        {
                                                                $data = array();
                                                                $data['Id_0'] = $check_existing_reference['id'];
                                                        }
                                                        else
                                                        {
                                                                //Enregistrement base de données
                                                                $data['Id_0'] = $this->passeportModel->save_paiement_tresor($data);

                                                                if($data['Id_0'] > 0)
                                                                {
                                                                        $debit_mad_instructions = $this->comptabilisation->get_instructions_passeport_mad($data);

                                                                        if(!empty($debit_mad_instructions))
                                                                        {
                                                                                $first_instruction = $this->comptabilisationModel->save_instructions_passeport($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'], 0);

                                                                                if($first_instruction)
                                                                                {
                                                                                        $debit_sequestre_instructions = $this->comptabilisation->get_instructions_passeport_sequestre($data);

                                                                                        $second_instructions = $this->comptabilisationModel->save_instructions_passeport($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                                        if($second_instructions == false)
                                                                                        {
                                                                                                // breakdown instructions not saved
                                                                                                $error_code = 403;
                                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                        }
                                                                                }
                                                                                else
                                                                                {
                                                                                        // first instruction not saved
                                                                                        $error_code = 402;
                                                                                        $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                }
                                                                        }
                                                                        else{
                                                                                $error_code = 406;
                                                                                $error_description = 'Erreur de construction des instructions de comptabilisation MAD';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        // paiement not saved in the database
                                                                        $error_code = 401;
                                                                        $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                                }
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits d\'initier un paiement, veuillez contacter l\'op&eacute;rateur qui encaisse le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        //Modification enregistrement
                        //Tables concernées: propres, integration
                        elseif($obj == "update")
                        {
                                if( !empty($_POST) && $_POST['Id_0'] > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                                {
                                        //Récupération des données
                                        $error_code = 0;
                                        $return = $this->passeportModel->get_data_passeport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Formattage des données
                                                $data  = $return['data'];
                                                $return = $this->passeportModel->get_formatage_data_passeport($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        $data  = $return['data'];

                                                        $data['Id_0'] = $this->passeportModel->update_payment_tresor($data, $data['Id_0']);

                                                        if($data['Id_0'] > 0)
                                                        {
                                                                //Delete former instructions
                                                                $this->comptabilisationModel->delete_instructions_passeport($data['Id_0']);

                                                                $debit_mad_instructions = $this->comptabilisation->get_instructions_passeport_mad($data);

                                                                if(!empty($debit_mad_instructions))
                                                                {
                                                                        $debit_sequestre_instructions = $this->comptabilisation->get_instructions_passeport_sequestre($data);

                                                                        $first_instruction= $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'],0);

                                                                        if($first_instruction)
                                                                        {
                                                                                $second_instructions = $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                                if($second_instructions == false)
                                                                                {
                                                                                        // breakdown instructions not saved
                                                                                        $error_code = '403';
                                                                                        $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                // first instruction not saved
                                                                                $error_code = '402';
                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                        }
                                                                }
                                                                else{
                                                                        $error_code = 406;
                                                                        $error_description = 'Erreur de construction des instructions de comptabilisation MAD';
                                                                }
                                                        }
                                                        else
                                                        {
                                                                // paiement not saved in the database
                                                                $error_code = '401';
                                                                $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de modifier ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        //Validation
                        //Tables concernées: propres, integration
                        elseif($obj == "validation")//Conditions maker pour modification
                        {
                                
                                if($id > 0 && ($this->role == 2 || $this->role == 3))//Conditions maker pour modification
                                {
                                        $error_code = 0;
                                        //Formattage des données
                                        $return = $this->passeportModel->get_data_validation_passport($id);
                                   
                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Traitements spécifiques

                                                // Mise à jour du statut de paiement en statut regularisation
                                                // Pour la premiere sequence

                                                $this->passeportModel->update_payment_validation($id, 5);

                                                $data = $return['data']['firstTrans'];
                                            
                                                $core_banking = strtolower($this->core_banking);
                                                
                                                $response = $this->{$core_banking}->virement_passport($data);
                                              
                                                $result = json_decode($response, true);

                                                if(isset($result['response']) && $result['response'] == 200)
                                                {
                                                        // Mise à jour du statut de paiement en statut en cours
                                                        // Pour la deuxieme sequence
                                                        $this->passeportModel->update_payment_validation($id, 6);

                                                        $data = $return['data']['secondTrans'];

                                                        $core_banking = strtolower($this->core_banking);
                                                        $response = $this->{$core_banking}->virement_passport($data);
                                              
                                                        $result = json_decode($response, true);
                                                        
                                                        if(isset($result['response']) && $result['response'] == 200)
                                                        {
                                                                // Mise à jour du statut de paiement en statut en cours
                                                                // Pour la confirmation dans Logirad
                                                                $this->passeportModel->update_payment_validation($id, 7);
                                                                //Formattage des données pour la confirmation dans Logirad
                                                                $return = $this->passeportModel->get_data_confirmation_passport();

                                                                if(isset($return['code']) && $return['code'] == 200)
                                                                {

                                                                        $apidata = $return['data'];
                                                                        //$response = $this->logirad->confirm_note_passport($apidata);
                                                                        $response = "E200";

                                                                        if($response == "E200" || $response == "CP200")
                                                                        {
                                                                                // Mise à jour du statut de paiement en statut validE et confirmE
                                                                                $this->passeportModel->update_payment_validation($id, 2);
                                                                        }
                                                                        else
                                                                        {
                                                                                $error_code = $response;
                                                                                $error_description = "Paiement valid&eacute; dans Finacle, Mais la confirmation n'a pas abouti dans Logirad.";
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $error_code = $return['code'];
                                                                        $error_description = $return['message'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                                $this->comptabilisationModel->get_cbs_instructions_passport_attempts($id, 1);

                                                                $error_code = $return['code'];
                                                                $error_description = $return['message'];
                                                        }
                                                }
                                                else
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->comptabilisationModel->update_cbs_instructions_passport_attempts($id, 1);

                                                        $error_code = $return['code'];
                                                        $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                                        echo json_encode($data_return);
                                }
                        }

                        //Suppression
                        //Tables concernées: propres, integration
                        elseif($obj == "deletion")//Conditions maker pour modification
                        {
                                if($id > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                                {
                                        $error_code = 0;
                                        //Récupération des données
                                        $return = $this->passeportModel->get_data_deletion_passport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $data = $return['data'];
                                                // Mise à jour du statut de paiement en statut en supprimé
                                                $pid = $this->encaissementModel->update_payment_tresor_passeport($data, $id);

                                                //Traitements spécifiques
                                                if($pid == 0)
                                                {
                                                        $error_code = 404;
                                                        $error_description = 'Paiement non supprim&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement suppri&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }

                        }

                        //Arret du script
                        //Tables concernées: propres, integration
                        else
                        {

                        }
                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "validate_paiments")
                        {
                                $error = '';
                                if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                                return $error;
                        }
                        elseif($obj == "get_paiment_transid")
                        {
                                $transid = isset($_POST['transID']) ? $_POST['transID'] : "";

                                $paiement = $this->encaissementModel->get_paiement_passeport_by_transactionid($transid);

                                if (!empty($paiement))
                                {
                                        echo '405';
                                }
                                else
                                {
                                        echo '200';
                                }
                        }
                        elseif($obj == "handle_error_codes")
                        {
                                $error_codes = ["E604", "E000", "E002", "E22", "E404", "E405", "E503", "E504", "E505", "E506", "401", "402", "500"];

                                $code = $arg;
                                if (!in_array($code, $error_codes))
                                {
                                        return false;
                                }

                                if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600" && $code == "E404")
                                {
                                        $_SESSION['login_info']['ip']['attempts']++;
                                        if ($_SESSION['login_info']['ip']['attempts'] >= 3)
                                        {
                                                $this->save_ipaddress();
                                                echo json_encode(['code' => 'LOCKOUT', 'message' => 'Nombre maximum de tentatives dépassé.']);
                                                die;
                                        }
                                }
                                else
                                {
                                        $_SESSION['login_info']['ip']['attempts'] = 0;
                                }
                                return true;
                        }
                        elseif($obj == "OBJ ")
                        {

                        }
                }

                public function save_ipaddress()
                {
                        $description = array('Detail'=> '3 tentatives de consultation de passport echouées');

                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = '46';
                        $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];
                        $data['Sessionid_8'] = $this->session->session_id;
                        $data['Observation_9'] = json_encode($description);

                        $this->logirefModel->save_ipaddress($data, NULL);
                }
        }
        /* End of file welcome.php  */
        /* Location: /project/activities  */